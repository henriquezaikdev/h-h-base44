import { Suspense, lazy } from "react";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider } from "@/hooks/useAuth";
import { ThemeProvider } from "@/components/ThemeProvider";
import { ProtectedLayout } from "@/components/layout/ProtectedLayout";
import { queryClient } from "@/lib/queryClient";
import { ErrorBoundary } from "@/components/ErrorBoundary";
import { Loader2 } from "lucide-react";

// Lazy-loaded pages for code splitting
const Index = lazy(() => import("./pages/Index"));
const ActionCenter = lazy(() => import("./pages/ActionCenter"));

const Clients = lazy(() => import("./pages/Clients"));
const ClientDetail = lazy(() => import("./pages/ClientDetail"));
const Goals = lazy(() => import("./pages/Goals"));
const Relatorios = lazy(() => import("./pages/Relatorios"));
const Settings = lazy(() => import("./pages/Settings"));
const ImportQuote = lazy(() => import("./pages/ImportQuote"));
const ImportOrderV2 = lazy(() => import("./pages/ImportOrderV2"));
const Orders = lazy(() => import("./pages/Orders"));
const OrderDetail = lazy(() => import("./pages/OrderDetail"));
const OrderEditApprovals = lazy(() => import("./pages/OrderEditApprovals"));
const Products = lazy(() => import("./pages/Products"));
const SellerEvolution = lazy(() => import("./pages/SellerEvolution"));
const PendingLinks = lazy(() => import("./pages/PendingLinks"));
const ProductDeduplication = lazy(() => import("./pages/ProductDeduplication"));
const ProductPendencias = lazy(() => import("./pages/ProductPendencias"));
const Gestor = lazy(() => import("./pages/Gestor"));
const Compras = lazy(() => import("./pages/Compras"));
const Entregas = lazy(() => import("./pages/Entregas"));
const Abastecimento = lazy(() => import("./pages/Abastecimento"));
const Manutencao = lazy(() => import("./pages/Manutencao"));
const GestaoCompras = lazy(() => import("./pages/GestaoCompras"));
const Profile = lazy(() => import("./pages/Profile"));
const SellerProfileHub = lazy(() => import("./pages/SellerProfileHub"));
const SellerDirectory = lazy(() => import("./pages/SellerDirectory"));
const Auth = lazy(() => import("./pages/Auth"));
const NotFound = lazy(() => import("./pages/NotFound"));
const FeedPage = lazy(() => import("./pages/FeedPage"));
const Mural = lazy(() => import("./pages/Mural"));
const QuotesModule = lazy(() => import("./components/quotes/QuotesModule").then(m => ({ default: m.QuotesModule })));

const RegrasXP = lazy(() => import("./pages/RegrasXP"));
const Estoque = lazy(() => import("./pages/Estoque"));
const FinanceiroPage = lazy(() => import("./pages/Financeiro"));
const SyncLogs = lazy(() => import("./pages/SyncLogs"));
const ProductAlertas = lazy(() => import("./pages/ProductAlertas"));
const DryRun = lazy(() => import("./pages/DryRun"));
const DiagnosticoSync = lazy(() => import("./pages/DiagnosticoSync"));
const SyncVendas = lazy(() => import("./pages/SyncVendas"));
const Sincronizacoes = lazy(() => import("./pages/Sincronizacoes"));
const EstoqueCompras = lazy(() => import("./pages/EstoqueCompras"));
const ListasCompras = lazy(() => import("./pages/ListasCompras"));
const ListaComprasDetalhe = lazy(() => import("./pages/ListaComprasDetalhe"));
const RotinaOperacional = lazy(() => import("./pages/RotinaOperacional"));
const SemanaZero = lazy(() => import("./pages/SemanaZero"));
const Categorias = lazy(() => import("./pages/Categorias"));
const ImportarCategorias = lazy(() => import("./pages/ImportarCategorias"));
const CategoriasPendentes = lazy(() => import("./pages/CategoriasPendentes"));
const DiagnosticoPedidos = lazy(() => import("./pages/DiagnosticoPedidos"));
const EntregadorDashboard = lazy(() => import("./pages/EntregadorDashboard"));
const RH = lazy(() => import("./pages/RH"));

const PageLoader = () => (
  <div className="flex items-center justify-center py-12">
    <Loader2 className="animate-spin h-8 w-8 text-primary" />
  </div>
);

// Per-route error boundary wrapper
const SafeRoute = ({ children }: { children: React.ReactNode }) => (
  <ErrorBoundary>
    <Suspense fallback={<PageLoader />}>
      {children}
    </Suspense>
  </ErrorBoundary>
);

// Main App component
const App = () => (
  <ErrorBoundary>
    <ThemeProvider>
      <QueryClientProvider client={queryClient}>
        <AuthProvider>
          <TooltipProvider>
            <Toaster />
            <Sonner />
            <BrowserRouter>
              <Suspense fallback={<PageLoader />}>
              <Routes>
                <Route path="/auth" element={<SafeRoute><Auth /></SafeRoute>} />
                
                {/* Protected routes with persistent Layout */}
                <Route element={<ProtectedLayout />}>
                  <Route path="/" element={<SafeRoute><ActionCenter /></SafeRoute>} />
                  <Route path="/meu-dia" element={<SafeRoute><ActionCenter /></SafeRoute>} />
                  <Route path="/entregador" element={<SafeRoute><EntregadorDashboard /></SafeRoute>} />
                  <Route path="/perfil" element={<SafeRoute><SellerProfileHub /></SafeRoute>} />
                  <Route path="/dashboard" element={<SafeRoute><Index /></SafeRoute>} />
                  
                  <Route path="/clients" element={<SafeRoute><Clients /></SafeRoute>} />
                  <Route path="/clients/:id" element={<SafeRoute><ClientDetail /></SafeRoute>} />
                  <Route path="/orders" element={<SafeRoute><Orders /></SafeRoute>} />
                  <Route path="/orders/:id" element={<SafeRoute><OrderDetail /></SafeRoute>} />
                  <Route path="/order-approvals" element={<SafeRoute><OrderEditApprovals /></SafeRoute>} />
                  <Route path="/products" element={<SafeRoute><Products /></SafeRoute>} />
                  <Route path="/evolucao-vendedor" element={<SafeRoute><SellerEvolution /></SafeRoute>} />
                  <Route path="/goals" element={<SafeRoute><Goals /></SafeRoute>} />
                  <Route path="/relatorios" element={<SafeRoute><Relatorios /></SafeRoute>} />
                  <Route path="/orcamentos" element={<SafeRoute><QuotesModule /></SafeRoute>} />
                  <Route path="/settings" element={<SafeRoute><Settings /></SafeRoute>} />
                  <Route path="/import" element={<SafeRoute><ImportOrderV2 /></SafeRoute>} />
                  <Route path="/import-quote" element={<SafeRoute><ImportQuote /></SafeRoute>} />
                  <Route path="/pending-links" element={<SafeRoute><PendingLinks /></SafeRoute>} />
                  <Route path="/product-deduplication" element={<SafeRoute><ProductDeduplication /></SafeRoute>} />
                  <Route path="/product-pendencias" element={<SafeRoute><ProductPendencias /></SafeRoute>} />
                  <Route path="/product-alertas" element={<SafeRoute><ProductAlertas /></SafeRoute>} />
                  <Route path="/gestor" element={<SafeRoute><Gestor /></SafeRoute>} />
                  <Route path="/compras" element={<Navigate to="/gestao-compras" replace />} />
                  <Route path="/entregas" element={<SafeRoute><Entregas /></SafeRoute>} />
                  <Route path="/abastecimento" element={<SafeRoute><Abastecimento /></SafeRoute>} />
                  <Route path="/manutencao" element={<SafeRoute><Manutencao /></SafeRoute>} />
                  <Route path="/gestao-compras" element={<SafeRoute><GestaoCompras /></SafeRoute>} />
                  <Route path="/estoque-compras" element={<SafeRoute><EstoqueCompras /></SafeRoute>} />
                  <Route path="/sync-logs" element={<SafeRoute><SyncLogs /></SafeRoute>} />
                  <Route path="/dryrun" element={<SafeRoute><DryRun /></SafeRoute>} />
                  <Route path="/diagnostico-sync" element={<SafeRoute><DiagnosticoSync /></SafeRoute>} />
                  <Route path="/sync-vendas" element={<SafeRoute><SyncVendas /></SafeRoute>} />
                  <Route path="/sincronizacoes" element={<SafeRoute><Sincronizacoes /></SafeRoute>} />
                  <Route path="/perfil/:userId" element={<SafeRoute><SellerProfileHub /></SafeRoute>} />
                  <Route path="/perfil-vendedor/:sellerId" element={<SafeRoute><SellerProfileHub /></SafeRoute>} />
                  <Route path="/diretorio" element={<SafeRoute><SellerDirectory /></SafeRoute>} />
                  <Route path="/feed" element={<SafeRoute><Mural /></SafeRoute>} />
                  <Route path="/mural" element={<SafeRoute><Mural /></SafeRoute>} />
                  
                  <Route path="/regras-xp" element={<SafeRoute><RegrasXP /></SafeRoute>} />
                  <Route path="/estoque" element={<SafeRoute><Estoque /></SafeRoute>} />
                  <Route path="/financeiro" element={<SafeRoute><FinanceiroPage /></SafeRoute>} />
                  <Route path="/listas-compras" element={<SafeRoute><ListasCompras /></SafeRoute>} />
                  <Route path="/listas-compras/:id" element={<SafeRoute><ListaComprasDetalhe /></SafeRoute>} />
                  <Route path="/rotina-produtos" element={<SafeRoute><RotinaOperacional /></SafeRoute>} />
                  <Route path="/semana-zero" element={<SafeRoute><SemanaZero /></SafeRoute>} />
                  <Route path="/categorias" element={<SafeRoute><Categorias /></SafeRoute>} />
                  <Route path="/categorias/importar" element={<SafeRoute><ImportarCategorias /></SafeRoute>} />
                  <Route path="/categorias/pendentes" element={<SafeRoute><CategoriasPendentes /></SafeRoute>} />
                  <Route path="/diagnostico-pedidos" element={<SafeRoute><DiagnosticoPedidos /></SafeRoute>} />
                  <Route path="/rh" element={<SafeRoute><RH /></SafeRoute>} />
                  
                </Route>
                
                <Route path="*" element={<NotFound />} />
              </Routes>
              </Suspense>
            </BrowserRouter>
          </TooltipProvider>
        </AuthProvider>
      </QueryClientProvider>
    </ThemeProvider>
  </ErrorBoundary>
);

export default App;
