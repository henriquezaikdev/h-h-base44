import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { toast } from 'sonner';

const sb = supabase as any;

export interface CampanhaAcceptance {
  id: string;
  campaign_id: string;
  status: string;
  sent_at: string;
  accepted_at: string | null;
  declined_at: string | null;
  campanha_nome: string;
  campanha_descricao: string | null;
  campanha_area: string;
  campanha_tipo: string;
  campanha_modo_validacao: string;
  campanha_percentual_minimo: number;
  foco_geral: string | null;
  descricao_foco: string | null;
  mes_referencia: string | null;
  criterios: { nome: string; descricao: string | null; meta_objetiva: string; peso_percentual: number }[];
}

export function useCampanhaCiencia() {
  const { seller } = useAuth();
  const [acceptances, setAcceptances] = useState<CampanhaAcceptance[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchAll = useCallback(async () => {
    if (!seller?.id) { setLoading(false); return; }
    try {
      const { data: accs } = await sb
        .from('campaign_acceptance')
        .select(`
          id, campaign_id, status, sent_at, accepted_at, declined_at,
          campanhas!campaign_acceptance_campaign_id_fkey(
            nome, descricao, area, tipo, modo_validacao, percentual_minimo, status,
            configuracao_mensal_campanhas!campanhas_configuracao_mensal_id_fkey(foco_geral, descricao_foco, mes_referencia)
          )
        `)
        .eq('user_id', seller.id)
        .in('status', ['pendente', 'aceito', 'recusado']);

      if (accs && accs.length > 0) {
        // Only show for active/encerrada campaigns
        const relevant = accs.filter((a: any) => {
          const campStatus = a.campanhas?.status;
          return campStatus === 'ATIVA' || campStatus === 'ENCERRADA';
        });

        const campaignIds = [...new Set(relevant.map((a: any) => a.campaign_id))];
        const { data: allCrits } = await sb
          .from('criterios_campanha')
          .select('campanha_id, nome, descricao, meta_objetiva, peso_percentual')
          .in('campanha_id', campaignIds);

        const mapped: CampanhaAcceptance[] = relevant.map((a: any) => ({
          id: a.id,
          campaign_id: a.campaign_id,
          status: a.status,
          sent_at: a.sent_at,
          accepted_at: a.accepted_at,
          declined_at: a.declined_at,
          campanha_nome: a.campanhas?.nome || '',
          campanha_descricao: a.campanhas?.descricao,
          campanha_area: a.campanhas?.area || '',
          campanha_tipo: a.campanhas?.tipo || '',
          campanha_modo_validacao: a.campanhas?.modo_validacao || '',
          campanha_percentual_minimo: a.campanhas?.percentual_minimo || 100,
          foco_geral: a.campanhas?.configuracao_mensal_campanhas?.foco_geral,
          descricao_foco: a.campanhas?.configuracao_mensal_campanhas?.descricao_foco,
          mes_referencia: a.campanhas?.configuracao_mensal_campanhas?.mes_referencia,
          criterios: (allCrits || []).filter((c: any) => c.campanha_id === a.campaign_id),
        }));
        setAcceptances(mapped);
      } else {
        setAcceptances([]);
      }
    } catch (err) {
      console.error('Error fetching campaign acceptance:', err);
    } finally {
      setLoading(false);
    }
  }, [seller?.id]);

  useEffect(() => { fetchAll(); }, [fetchAll]);

  const viewDocument = async (campaignId: string, acceptanceId: string) => {
    // Mark viewed_at
    await sb.from('campaign_acceptance').update({
      viewed_at: new Date().toISOString(),
    }).eq('id', acceptanceId).is('viewed_at', null);

    // Fetch document
    const { data: doc } = await sb
      .from('campaign_documents')
      .select('title, content')
      .eq('campaign_id', campaignId)
      .maybeSingle();

    if (doc) return doc as { title: string; content: string };

    // Fallback: build from campaign data
    const { data: camp } = await sb
      .from('campanhas')
      .select('nome, descricao, area, tipo, modo_validacao, percentual_minimo, configuracao_mensal_campanhas!campanhas_configuracao_mensal_id_fkey(foco_geral, descricao_foco, mes_referencia)')
      .eq('id', campaignId)
      .single();

    const { data: crits } = await sb
      .from('criterios_campanha')
      .select('nome, meta_objetiva, peso_percentual')
      .eq('campanha_id', campaignId);

    if (camp) {
      const config = camp.configuracao_mensal_campanhas;
      const content = [
        `CAMPANHA: ${camp.nome}`,
        `Período: ${config?.mes_referencia || '—'}`,
        `Foco: ${config?.foco_geral || '—'}`,
        camp.descricao ? `\nDescrição: ${camp.descricao}` : '',
        `\nÁrea: ${camp.area} | Tipo: ${camp.tipo}`,
        `Validação: ${camp.modo_validacao === 'RIGIDO_100' ? '100% Rígido' : `≥${camp.percentual_minimo}%`}`,
        '\n--- CRITÉRIOS DE PREMIAÇÃO ---',
        ...(crits || []).map((c: any) => `• ${c.nome} — Meta: ${c.meta_objetiva} (Peso: ${c.peso_percentual}%)`),
        '\n--- CONDIÇÃO JURÍDICA ---',
        'Esta campanha possui caráter exclusivamente eventual e não integra salário ou remuneração fixa, conforme legislação trabalhista vigente.',
      ].filter(Boolean).join('\n');
      return { title: camp.nome, content };
    }
    return null;
  };

  const aceitarCampanha = async (acceptanceId: string) => {
    try {
      await sb.from('campaign_acceptance').update({
        status: 'aceito',
        accepted_at: new Date().toISOString(),
      }).eq('id', acceptanceId);
      toast.success('Participação aceita! Boa sorte na campanha.');
      await fetchAll();
    } catch (err: any) {
      toast.error('Erro ao aceitar: ' + err.message);
    }
  };

  const recusarCampanha = async (acceptanceId: string) => {
    try {
      await sb.from('campaign_acceptance').update({
        status: 'recusado',
        declined_at: new Date().toISOString(),
      }).eq('id', acceptanceId);
      toast.info('Participação recusada.');
      await fetchAll();
    } catch (err: any) {
      toast.error('Erro ao recusar: ' + err.message);
    }
  };

  return { acceptances, loading, aceitarCampanha, recusarCampanha, viewDocument, refetch: fetchAll };
}
