import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { format } from 'date-fns';
import { toast } from 'sonner';

export interface CienciaMetaInfo {
  seller_level_id: string;
  seller_id: string;
  seller_name: string;
  status_ciencia: string;
  prazo_ciencia: string | null;
  enviado_para_ciencia_em: string | null;
  ciente_em: string | null;
  versao_documento: number;
  pdf_metas_url: string | null;
  monthly_sales_target: number;
  base_daily_calls: number;
  base_daily_whatsapp: number;
  current_level: string;
}

export function useCienciaMetas(competencia?: string) {
  const { seller, isOwner, isAdmin } = useAuth();
  const [pendingCiencia, setPendingCiencia] = useState<CienciaMetaInfo | null>(null);
  const [allCiencias, setAllCiencias] = useState<CienciaMetaInfo[]>([]);
  const [loading, setLoading] = useState(true);
  const comp = competencia || format(new Date(), 'yyyy-MM');

  const fetchData = useCallback(async () => {
    if (!seller?.id) return;
    setLoading(true);
    try {
      // For the logged-in seller: check if there's a pending ciencia
      const { data: myLevel } = await supabase
        .from('seller_levels')
        .select('id, seller_id, status_ciencia, prazo_ciencia, enviado_para_ciencia_em, ciente_em, versao_documento, pdf_metas_url, monthly_sales_target, base_daily_calls, base_daily_whatsapp, current_level')
        .eq('seller_id', seller.id)
        .maybeSingle();

      if (myLevel && myLevel.status_ciencia === 'AGUARDANDO_CIENCIA') {
        setPendingCiencia({
          seller_level_id: myLevel.id,
          seller_id: myLevel.seller_id,
          seller_name: seller.name,
          status_ciencia: myLevel.status_ciencia,
          prazo_ciencia: myLevel.prazo_ciencia,
          enviado_para_ciencia_em: myLevel.enviado_para_ciencia_em,
          ciente_em: myLevel.ciente_em,
          versao_documento: myLevel.versao_documento,
          pdf_metas_url: myLevel.pdf_metas_url,
          monthly_sales_target: myLevel.monthly_sales_target,
          base_daily_calls: myLevel.base_daily_calls,
          base_daily_whatsapp: myLevel.base_daily_whatsapp,
          current_level: myLevel.current_level,
        });
      } else {
        setPendingCiencia(null);
      }

      // Check expiration
      if (myLevel && myLevel.status_ciencia === 'AGUARDANDO_CIENCIA' && myLevel.prazo_ciencia) {
        const prazo = new Date(myLevel.prazo_ciencia);
        if (new Date() > prazo) {
          // Auto-expire
          await supabase
            .from('seller_levels')
            .update({ status_ciencia: 'EXPIRADA', updated_at: new Date().toISOString() })
            .eq('id', myLevel.id);

          await supabase.from('log_ciencia_metas').insert({
            seller_level_id: myLevel.id,
            acao: 'EXPIRADA',
            user_id: seller.id,
            observacao: 'Expiração automática por prazo excedido',
          });

          // Apply bonus block via discipline_penalties
          await supabase.from('discipline_penalties').insert({
            seller_id: seller.id,
            penalty_type: 'bonus_block',
            reason: 'Sem ciência das metas do mês',
            starts_at: new Date().toISOString(),
            ends_at: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString(), // until resolved
            reduction_percent: 100,
            is_active: true,
          });

          setPendingCiencia(null);
        }
      }

      // For admin: fetch all seller levels with ciencia info (only vendedores)
      if (isOwner || isAdmin) {
        const { data: allLevels } = await supabase
          .from('seller_levels')
          .select('id, seller_id, status_ciencia, prazo_ciencia, enviado_para_ciencia_em, ciente_em, versao_documento, pdf_metas_url, monthly_sales_target, base_daily_calls, base_daily_whatsapp, current_level, sellers!seller_levels_seller_id_fkey(name, role, is_sales_active)')
        
        if (allLevels) {
          const filtered = allLevels.filter((sl: any) => {
            const s = sl.sellers;
            return s?.role === 'vendedor' || s?.is_sales_active === true;
          });
          setAllCiencias(filtered.map((sl: any) => ({
            seller_level_id: sl.id,
            seller_id: sl.seller_id,
            seller_name: sl.sellers?.name || 'N/A',
            status_ciencia: sl.status_ciencia,
            prazo_ciencia: sl.prazo_ciencia,
            enviado_para_ciencia_em: sl.enviado_para_ciencia_em,
            ciente_em: sl.ciente_em,
            versao_documento: sl.versao_documento,
            pdf_metas_url: sl.pdf_metas_url,
            monthly_sales_target: sl.monthly_sales_target,
            base_daily_calls: sl.base_daily_calls,
            base_daily_whatsapp: sl.base_daily_whatsapp,
            current_level: sl.current_level,
          })));
        }
      }
    } catch (err) {
      console.error('Error fetching ciencia:', err);
    } finally {
      setLoading(false);
    }
  }, [seller?.id, isOwner, isAdmin, comp]);

  useEffect(() => { fetchData(); }, [fetchData]);

  const enviarParaCiencia = async (sellerLevelId: string) => {
    if (!seller?.id) return;
    try {
      const { data, error } = await supabase.functions.invoke('generate-metas-pdf', {
        body: {
          seller_level_id: sellerLevelId,
          competencia: comp,
          actor_user_id: seller.id,
          is_resend: false,
        },
      });
      if (error) throw error;
      toast.success('Metas enviadas para ciência com sucesso!');
      await fetchData();
      return data;
    } catch (err: any) {
      toast.error('Erro ao enviar para ciência: ' + err.message);
    }
  };

  const reenviarParaCiencia = async (sellerLevelId: string) => {
    if (!seller?.id) return;
    try {
      const { data, error } = await supabase.functions.invoke('generate-metas-pdf', {
        body: {
          seller_level_id: sellerLevelId,
          competencia: comp,
          actor_user_id: seller.id,
          is_resend: true,
        },
      });
      if (error) throw error;
      
      // Remove bonus block related to "sem ciência"
      await supabase
        .from('discipline_penalties')
        .update({ is_active: false })
        .eq('seller_id', (await supabase.from('seller_levels').select('seller_id').eq('id', sellerLevelId).single()).data?.seller_id || '')
        .eq('reason', 'Sem ciência das metas do mês')
        .eq('is_active', true);

      toast.success('Metas reenviadas para ciência!');
      await fetchData();
      return data;
    } catch (err: any) {
      toast.error('Erro ao reenviar: ' + err.message);
    }
  };

  const darCiencia = async () => {
    if (!seller?.id || !pendingCiencia) return;
    try {
      await supabase
        .from('seller_levels')
        .update({
          status_ciencia: 'CIENTE',
          ciente_em: new Date().toISOString(),
          ciente_por_user_id: seller.id,
          updated_at: new Date().toISOString(),
        })
        .eq('id', pendingCiencia.seller_level_id);

      await supabase.from('log_ciencia_metas').insert({
        seller_level_id: pendingCiencia.seller_level_id,
        acao: 'CIENTE',
        user_id: seller.id,
      });

      // Remove any bonus block for "sem ciência"
      await supabase
        .from('discipline_penalties')
        .update({ is_active: false })
        .eq('seller_id', seller.id)
        .eq('reason', 'Sem ciência das metas do mês')
        .eq('is_active', true);

      toast.success('Ciência registrada com sucesso!');
      setPendingCiencia(null);
      await fetchData();
    } catch (err: any) {
      toast.error('Erro ao registrar ciência: ' + err.message);
    }
  };

  return {
    pendingCiencia,
    allCiencias,
    loading,
    enviarParaCiencia,
    reenviarParaCiencia,
    darCiencia,
    refetch: fetchData,
  };
}
