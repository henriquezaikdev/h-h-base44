import { useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { format, startOfMonth, endOfMonth } from 'date-fns';
import { 
  mapCategoryToKey, 
  getCategoryKeys, 
  DEFAULT_GOALS_BY_PROFILE 
} from '@/lib/categoryConfig';

interface CategoryBonusEligibility {
  categoryKey: string;
  isMet: boolean;
  margin: number;
  isEligible: boolean;
  revenue: number;
  cost: number;
  target: number;
}

const CATEGORY_KEYS = getCategoryKeys();

async function fetchCategoryEligibility(sellerId: string, month: number, year: number): Promise<CategoryBonusEligibility[]> {
  const competencia = `${year}-${String(month).padStart(2, '0')}`;
  const monthStart = startOfMonth(new Date(year, month - 1));
  const monthEnd = endOfMonth(new Date(year, month - 1));

  // Buscar categoria do vendedor
  const { data: levelData } = await supabase
    .from('seller_levels')
    .select('seller_category')
    .eq('seller_id', sellerId)
    .maybeSingle();
  
  const sellerCategory = levelData?.seller_category || 'novato';
  const defaultGoals = DEFAULT_GOALS_BY_PROFILE[sellerCategory] || DEFAULT_GOALS_BY_PROFILE.novato;

  // Buscar metas configuradas
  const { data: goalsData } = await supabase
    .from('category_goals')
    .select('category_key, meta_valor')
    .eq('seller_id', sellerId)
    .eq('competencia', competencia);

  // Buscar vendas por categoria
  const { data: ordersData } = await supabase
    .from('orders')
    .select(`
      id,
      order_items!inner (
        subtotal,
        cost_subtotal,
        is_deleted,
        products (
          category,
          category_id,
          categories:category_id (
            name
          )
        )
      )
    `)
    .eq('seller_id', sellerId)
    .gte('order_date', format(monthStart, 'yyyy-MM-dd'))
    .lte('order_date', format(monthEnd, 'yyyy-MM-dd'))
    .or('is_deleted.is.null,is_deleted.eq.false');

  // Agregar vendas por categoria
  const salesMap: Record<string, { revenue: number; cost: number }> = {};
  
  ordersData?.forEach(order => {
    order.order_items?.forEach((item: any) => {
      if (item.is_deleted) return;
      
      const categoryFromId = item.products?.categories?.name;
      const categoryFromText = item.products?.category;
      const categoryName = categoryFromId || categoryFromText || '';
      const categoryKey = mapCategoryToKey(categoryName);
      
      if (categoryKey) {
        if (!salesMap[categoryKey]) {
          salesMap[categoryKey] = { revenue: 0, cost: 0 };
        }
        salesMap[categoryKey].revenue += item.subtotal || 0;
        salesMap[categoryKey].cost += item.cost_subtotal || 0;
      }
    });
  });

  // Construir elegibilidade para cada categoria
  return CATEGORY_KEYS.map(key => {
    const configured = goalsData?.find(g => g.category_key === key);
    const target = configured?.meta_valor || defaultGoals[key] || 0;
    const categoryData = salesMap[key] || { revenue: 0, cost: 0 };
    
    const margin = categoryData.revenue > 0 
      ? ((categoryData.revenue - categoryData.cost) / categoryData.revenue) * 100 
      : 0;
    
    const isMet = categoryData.revenue >= target;
    const isEligible = isMet && margin >= 40;
    
    return {
      categoryKey: key,
      isMet,
      margin: Math.round(margin * 10) / 10,
      isEligible,
      revenue: categoryData.revenue,
      cost: categoryData.cost,
      target,
    };
  });
}

export function useCategoryEligibility(sellerId: string | null, month: number, year: number) {
  const queryKey = useMemo(() => ['category-eligibility', sellerId, month, year] as const, [sellerId, month, year]);
  
  const query = useQuery({
    queryKey,
    queryFn: () => fetchCategoryEligibility(sellerId!, month, year),
    enabled: !!sellerId,
    staleTime: 1000 * 60 * 2,
    gcTime: 1000 * 60 * 10,
    refetchOnWindowFocus: true,
    refetchOnReconnect: true,
  });

  return {
    categoryEligibility: query.data || [],
    loading: query.isLoading,
    refetch: query.refetch,
  };
}
