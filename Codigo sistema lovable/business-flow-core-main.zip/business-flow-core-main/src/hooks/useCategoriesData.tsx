import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';

export interface CategoryData {
  id: string;
  name: string;
  active: boolean;
  createdAt: string;
  productCount: number;
}

export function useCategoriesData() {
  const [categories, setCategories] = useState<CategoryData[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchCategories = useCallback(async () => {
    setLoading(true);
    try {
      // Get categories
      const { data: catData, error: catError } = await supabase
        .from('categories')
        .select('id, name, active, created_at')
        .order('name');

      if (catError) throw catError;

      // Get product counts per category
      const { data: countData } = await supabase
        .from('products')
        .select('category_id')
        .not('category_id', 'is', null);

      const countMap: Record<string, number> = {};
      countData?.forEach(p => {
        if (p.category_id) {
          countMap[p.category_id] = (countMap[p.category_id] || 0) + 1;
        }
      });

      setCategories((catData || []).map(c => ({
        id: c.id,
        name: c.name,
        active: c.active ?? true,
        createdAt: c.created_at,
        productCount: countMap[c.id] || 0,
      })));
    } catch (error) {
      console.error('Error fetching categories:', error);
    } finally {
      setLoading(false);
    }
  }, []);

  const createCategory = useCallback(async (name: string) => {
    try {
      const { error } = await supabase
        .from('categories')
        .insert({ name: name.trim() });

      if (error) throw error;
      await fetchCategories();
      return { success: true };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }, [fetchCategories]);

  const updateCategory = useCallback(async (id: string, updates: { name?: string; active?: boolean }) => {
    try {
      const { error } = await supabase
        .from('categories')
        .update(updates)
        .eq('id', id);

      if (error) throw error;
      await fetchCategories();
      return { success: true };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }, [fetchCategories]);

  const deleteCategory = useCallback(async (id: string) => {
    try {
      const { error } = await supabase
        .from('categories')
        .delete()
        .eq('id', id);

      if (error) throw error;
      await fetchCategories();
      return { success: true };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }, [fetchCategories]);

  useEffect(() => {
    fetchCategories();
  }, [fetchCategories]);

  // Get only active categories (for dropdowns)
  const activeCategories = categories.filter(c => c.active);

  return {
    categories,
    activeCategories,
    loading,
    refetch: fetchCategories,
    createCategory,
    updateCategory,
    deleteCategory,
  };
}
