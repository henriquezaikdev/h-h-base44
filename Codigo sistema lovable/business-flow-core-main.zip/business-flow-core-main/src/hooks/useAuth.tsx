import { useState, useEffect, useRef, createContext, useContext, ReactNode, useCallback } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase } from '@/integrations/supabase/client';
import { logDiagnostic } from '@/lib/diagnostics';

interface Seller {
  id: string;
  name: string;
  email: string | null;
  role: string;
  avatar_url: string | null;
}

type UserRole = 'owner' | 'admin' | 'user' | null;

interface AuthContextType {
  user: User | null;
  session: Session | null;
  seller: Seller | null;
  role: UserRole;
  isOwner: boolean;
  isAdmin: boolean;
  isAdminOrOwner: boolean;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<{ error: Error | null }>;
  signUp: (email: string, password: string, name: string) => Promise<{ error: Error | null }>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [seller, setSeller] = useState<Seller | null>(null);
  const [role, setRole] = useState<UserRole>(null);
  // IMPORTANTE: loading aqui é APENAS para bootstrap inicial/login.
  // Não deve voltar para true em TOKEN_REFRESHED, senão desmonta a UI e "parece reload".
  const [loading, setLoading] = useState(true);

  const bootstrappedRef = useRef(false);
  
  // SESSION PERSISTENCE BUFFER: Keep last known valid session to prevent flash of unauthenticated content
  const lastKnownSessionRef = useRef<Session | null>(null);
  const lastKnownUserRef = useRef<User | null>(null);

  const isOwner = role === 'owner';
  const isAdmin = role === 'admin' || role === 'owner';
  const isAdminOrOwner = isAdmin;

  useEffect(() => {
    const handleSession = async (event: string, nextSession: Session | null) => {
      // LOG: Track all auth events for debugging
      logDiagnostic({
        type: 'SESSION',
        data: {
          event,
          hasSession: !!nextSession,
          hasLastKnown: !!lastKnownSessionRef.current,
          userId: nextSession?.user?.id?.slice(0, 8) || lastKnownSessionRef.current?.user?.id?.slice(0, 8) || null,
        },
      });
      
      // SESSION PERSISTENCE BUFFER LOGIC:
      // Only clear session/user on explicit SIGNED_OUT event
      // For TOKEN_REFRESHED with null session, keep serving last known session
      // This prevents component tree from unmounting during background token refresh
      
      const isExplicitSignOut = event === 'SIGNED_OUT';
      const isTokenRefreshWithNull = event === 'TOKEN_REFRESHED' && !nextSession;
      
      if (isTokenRefreshWithNull && lastKnownSessionRef.current) {
        // Keep serving the last known session during background re-validation
        // Don't update state, just return - the session will be restored shortly
        console.debug('[Auth] TOKEN_REFRESHED with null session - keeping last known session');
        logDiagnostic({
          type: 'SESSION',
          data: {
            action: 'buffer_active',
            reason: 'TOKEN_REFRESHED with null session',
          },
        });
        return;
      }
      
      if (nextSession) {
        // Update the buffer with valid session
        lastKnownSessionRef.current = nextSession;
        lastKnownUserRef.current = nextSession.user;
      }
      
      if (isExplicitSignOut) {
        // Clear buffer on explicit sign out
        lastKnownSessionRef.current = null;
        lastKnownUserRef.current = null;
        logDiagnostic({
          type: 'SESSION',
          data: {
            action: 'buffer_cleared',
            reason: 'SIGNED_OUT',
          },
        });
      }
      
      // Use buffered session if current is null but we have a buffer (except on explicit sign out)
      const effectiveSession = nextSession || (!isExplicitSignOut ? lastKnownSessionRef.current : null);
      const effectiveUser = effectiveSession?.user ?? null;
      
      setSession(effectiveSession);
      setUser(effectiveUser);

      if (!effectiveUser) {
        setSeller(null);
        setRole(null);

        if (!bootstrappedRef.current) {
          bootstrappedRef.current = true;
          setLoading(false);
        }
        return;
      }

      const shouldFetchProfile =
        !bootstrappedRef.current ||
        event === 'SIGNED_IN' ||
        event === 'INITIAL_SESSION' ||
        event === 'USER_UPDATED';

      // HOTFIX CRÍTICO: Bloquear UI (loading=true) APENAS no bootstrap inicial
      // Após bootstrap, NENHUM evento deve setar loading=true para evitar remount da UI
      // GET_SESSION pode acontecer ao recuperar foco - NÃO deve bloquear UI após bootstrap
      const shouldBlockUI =
        !bootstrappedRef.current && (
          event === 'SIGNED_IN' ||
          event === 'INITIAL_SESSION'
        );

      if (shouldFetchProfile) {
        // HOTFIX: blockUI já é false após bootstrap, então essa checagem é redundante mas segura
        const blockUI = shouldBlockUI;

        if (blockUI) setLoading(true);

        await Promise.all([
          fetchSeller(effectiveUser.id),
          fetchUserRole(effectiveUser.id),
        ]);

        if (blockUI) setLoading(false);
      } else if (!bootstrappedRef.current) {
        setLoading(false);
      }

      if (!bootstrappedRef.current) {
        bootstrappedRef.current = true;
      }
    };

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, nextSession) => {
      void handleSession(event, nextSession);
    });

    // Fallback: garante bootstrap mesmo se INITIAL_SESSION não disparar
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (bootstrappedRef.current) return;
      void handleSession('GET_SESSION', session);
    });

    return () => subscription.unsubscribe();
  }, []);

  const fetchSeller = async (userId: string) => {
    try {
      const { data } = await supabase
        .from('sellers')
        .select('id, name, email, role, avatar_url')
        .eq('user_id', userId)
        .maybeSingle();
      
      if (data) {
        setSeller(data as Seller);
      }
    } catch (error) {
      console.error('Error fetching seller:', error);
    }
  };

  const fetchUserRole = async (userId: string) => {
    try {
      // Buscar role mais alta (owner > admin > user)
      const { data } = await supabase
        .from('user_roles')
        .select('role')
        .eq('user_id', userId)
        .order('role', { ascending: true }); // owner vem antes de admin alfabeticamente? Não, precisamos verificar

      if (data && data.length > 0) {
        // Priorizar owner > admin > user
        const roles = data.map(r => r.role);
        if (roles.includes('owner')) {
          setRole('owner');
        } else if (roles.includes('admin')) {
          setRole('admin');
        } else {
          setRole('user');
        }
      } else {
        setRole('user');
      }
    } catch (error) {
      console.error('Error fetching user role:', error);
      setRole('user');
    }
  };

  const signIn = async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });
    return { error: error as Error | null };
  };

  const signUp = async (email: string, password: string, name: string) => {
    const redirectUrl = `${window.location.origin}/`;
    
    const { error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        emailRedirectTo: redirectUrl,
        data: {
          name,
        },
      },
    });
    return { error: error as Error | null };
  };

  const signOut = async () => {
    await supabase.auth.signOut();
    setSeller(null);
    setRole(null);
  };

  return (
    <AuthContext.Provider value={{ 
      user, 
      session, 
      seller, 
      role,
      isOwner,
      isAdmin, 
      isAdminOrOwner,
      loading, 
      signIn, 
      signUp, 
      signOut 
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}