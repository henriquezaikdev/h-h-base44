import { useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';

export type RadarZone = 'ativo' | 'recompra' | 'atraso' | 'risco';

export interface RadarClient {
  client_id: string;
  client_name: string;
  seller_id: string;
  seller_name?: string;
  zone: RadarZone;
  dias_sem_pedido: number | null;
  prioridade_nivel: string;
  prioridade_score: number;
  motivo_prioridade: string;
  melhor_proxima_acao: string;
  cliente_em_risco: boolean;
  oportunidade_recompra: boolean;
  has_pending_task: boolean;
  contacted_today: boolean;
  ranking_tier: string | null;
  faturamento_total: number;
}

export interface RadarSummary {
  ativos: number;
  recompra: number;
  atraso: number;
  risco: number;
  total: number;
}

function classifyZone(item: any): RadarZone {
  if (item.cliente_em_risco) return 'risco';
  if (item.prioridade_nivel === 'maxima') return 'risco';
  if (item.prioridade_nivel === 'alta') return 'atraso';
  if (item.oportunidade_recompra) return 'recompra';
  if (item.prioridade_nivel === 'media') return 'recompra';
  return 'ativo';
}

export function useCarteiraRadar(options?: { allSellers?: boolean }) {
  const { seller } = useAuth();
  const isTeam = options?.allSellers === true;
  const today = new Date().toISOString().split('T')[0];

  const query = useQuery({
    queryKey: ['carteira-radar', isTeam ? 'team' : seller?.id, today],
    queryFn: async (): Promise<{ clients: RadarClient[]; summary: RadarSummary; sellerNames: Record<string, string> }> => {
      let q = supabase
        .from('client_priority_queue')
        .select('*')
        .eq('queue_date', today)
        .order('prioridade_score', { ascending: false });

      if (!isTeam && seller?.id) {
        q = q.eq('seller_id', seller.id);
      }

      const { data, error } = await q;
      if (error) throw error;
      const rows = data || [];

      // Fetch seller names for team view
      let sellerNames: Record<string, string> = {};
      if (isTeam) {
        const sids = [...new Set(rows.map((r: any) => r.seller_id))];
        if (sids.length > 0) {
          const { data: sellers } = await supabase.from('sellers').select('id, name').in('id', sids);
          if (sellers) sellerNames = Object.fromEntries(sellers.map(s => [s.id, s.name]));
        }
      }

      const clients: RadarClient[] = rows.map((r: any) => ({
        client_id: r.client_id,
        client_name: r.client_name,
        seller_id: r.seller_id,
        seller_name: sellerNames[r.seller_id],
        zone: classifyZone(r),
        dias_sem_pedido: r.dias_sem_pedido,
        prioridade_nivel: r.prioridade_nivel,
        prioridade_score: r.prioridade_score,
        motivo_prioridade: r.motivo_prioridade,
        melhor_proxima_acao: r.melhor_proxima_acao,
        cliente_em_risco: r.cliente_em_risco,
        oportunidade_recompra: r.oportunidade_recompra,
        has_pending_task: r.has_pending_task,
        contacted_today: r.contacted_today,
        ranking_tier: r.ranking_tier,
        faturamento_total: r.faturamento_total ?? 0,
      }));

      const summary: RadarSummary = {
        ativos: clients.filter(c => c.zone === 'ativo').length,
        recompra: clients.filter(c => c.zone === 'recompra').length,
        atraso: clients.filter(c => c.zone === 'atraso').length,
        risco: clients.filter(c => c.zone === 'risco').length,
        total: clients.length,
      };

      return { clients, summary, sellerNames };
    },
    enabled: isTeam || !!seller?.id,
    staleTime: 5 * 60 * 1000,
    refetchOnWindowFocus: false,
  });

  return {
    clients: query.data?.clients || [],
    summary: query.data?.summary || { ativos: 0, recompra: 0, atraso: 0, risco: 0, total: 0 },
    sellerNames: query.data?.sellerNames || {},
    isLoading: query.isLoading,
    refetch: query.refetch,
  };
}
