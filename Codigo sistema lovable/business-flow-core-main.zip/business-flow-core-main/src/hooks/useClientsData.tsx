import { useMemo } from 'react';
import { useQuery, keepPreviousData } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { calculateDaysSinceDate } from '@/lib/utils';

export interface ClientData {
  id: string;
  companyName: string;
  cnpj: string | null;
  phone: string | null;
  status: string;
  classification: string;
  category: string;
  rankingTier: string;
  totalRevenue: number;
  ordersCount: number;
  lastOrderDate: string | null;
  daysSinceLastOrder: number | null;
  sellerId: string | null;
  lastContactAt: string | null;
  isLinkedBranch?: boolean;
  matrixId?: string | null;
  matrixName?: string;
  inheritedFromMatrix?: boolean;
}

export interface PaginatedClientsResult {
  clients: ClientData[];
  totalCount: number;
  totalPages: number;
  currentPage: number;
}

export type ClientClassificationType = 'novo' | 'recorrente' | '60dias' | '90dias' | '120dias' | 'inativo';

export const CLASSIFICATION_CONFIG: Record<ClientClassificationType, { label: string; emoji: string; color: string; bgColor: string; borderColor: string }> = {
  novo: { label: 'Novo', emoji: '🆕', color: 'text-blue-600', bgColor: 'bg-blue-500/10', borderColor: 'border-blue-500/30' },
  recorrente: { label: 'Recorrente', emoji: '🔄', color: 'text-status-active', bgColor: 'bg-status-active/10', borderColor: 'border-status-active/30' },
  '60dias': { label: '60 dias', emoji: '⚠️', color: 'text-amber-600', bgColor: 'bg-amber-500/10', borderColor: 'border-amber-500/30' },
  '90dias': { label: '90 dias', emoji: '⏰', color: 'text-orange-600', bgColor: 'bg-orange-500/10', borderColor: 'border-orange-500/30' },
  '120dias': { label: '120 dias', emoji: '🔴', color: 'text-red-500', bgColor: 'bg-red-500/10', borderColor: 'border-red-500/30' },
  inativo: { label: 'Inativo', emoji: '💤', color: 'text-muted-foreground', bgColor: 'bg-muted', borderColor: 'border-muted-foreground/30' },
};

/**
 * Calcula classificação automática baseada em dias desde última compra:
 * - novo: cliente com apenas 1 pedido (primeira compra)
 * - recorrente: ≤ 45 dias desde último pedido
 * - 60dias: 46-60 dias
 * - 90dias: 61-90 dias
 * - 120dias: 91-120 dias
 * - inativo: > 120 dias
 */
export const calculateClassification = (daysSinceLastOrder: number | null, ordersCount?: number): ClientClassificationType => {
  if (daysSinceLastOrder === null) return 'inativo';
  if (ordersCount === 1 && daysSinceLastOrder <= 90) return 'novo';
  if (daysSinceLastOrder <= 45) return 'recorrente';
  if (daysSinceLastOrder <= 60) return '60dias';
  if (daysSinceLastOrder <= 90) return '90dias';
  if (daysSinceLastOrder <= 120) return '120dias';
  return 'inativo';
};

interface UseClientsDataOptions {
  limit?: number; // 0 = count only, >0 = fetch this many rows (legacy)
  page?: number; // 1-indexed page number
  pageSize?: number; // items per page (default 15)
  statusFilter?: string;
  searchTerm?: string;
  classificationFilter?: string;
  sellerFilter?: string;
  rankingFilter?: string;
  noContactDays?: number;
}

type ClientsCounts = {
  total: number;
  novo: number;
  recorrente: number;
  '60dias': number;
  '90dias': number;
  '120dias': number;
  inativo: number;
};

type ClientsQueryResult = {
  clients: ClientData[];
  totalCount: number;
  counts: ClientsCounts;
};

export function useClientsData(options: UseClientsDataOptions = {}) {
  const {
    limit = 0,
    page = 1,
    pageSize = 15,
    statusFilter = 'all',
    searchTerm = '',
    classificationFilter = 'all',
    sellerFilter = 'all',
    rankingFilter = 'all',
    noContactDays,
  } = options;

  // Effective limit: if page-based, compute from page/pageSize; otherwise use legacy limit
  const effectiveLimit = limit > 0 ? limit : (page > 0 ? pageSize : 0);
  const effectiveOffset = limit > 0 ? 0 : ((page - 1) * pageSize);

  const queryKey = useMemo(
    () => [
      'clients',
      { limit: effectiveLimit, offset: effectiveOffset, statusFilter, searchTerm, classificationFilter, sellerFilter, rankingFilter, noContactDays },
    ] as const,
    [effectiveLimit, effectiveOffset, statusFilter, searchTerm, classificationFilter, sellerFilter, rankingFilter, noContactDays]
  );

  const query = useQuery<ClientsQueryResult>({
    queryKey,
    queryFn: async () => {
      // ── Lightweight count/classification query ──
      // Use a high limit to ensure all rows are fetched for accurate classification counts
      let baseQuery = supabase
        .from('clients')
        .select('id, last_order_date, order_count', { count: 'exact', head: false })
        .eq('is_deleted', false)
        .limit(5000);

      if (statusFilter !== 'all') baseQuery = baseQuery.eq('status', statusFilter);
      if (sellerFilter !== 'all') baseQuery = baseQuery.eq('seller_id', sellerFilter);
      if (searchTerm) {
        const normalizedSearch = searchTerm.trim().replace(/\s+/g, '%');
        baseQuery = baseQuery.or(
          `company_name.ilike.%${normalizedSearch}%,cnpj.ilike.%${normalizedSearch}%,phone.ilike.%${normalizedSearch}%`
        );
      }
      if (noContactDays && noContactDays > 0) {
        const cutoffDate = new Date();
        cutoffDate.setDate(cutoffDate.getDate() - noContactDays);
        const cutoffDateStr = cutoffDate.toISOString().split('T')[0];
        baseQuery = baseQuery.or(`last_contact_at.is.null,last_contact_at.lt.${cutoffDateStr}`);
      }

      const { data: countData, count: totalFiltered } = await baseQuery;

      const orderCountMap = new Map<string, number>();
      countData?.forEach((c: any) => {
        orderCountMap.set(c.id, c.order_count || 0);
      });

      const classificationCounts: Record<ClientClassificationType, number> = {
        novo: 0, recorrente: 0, '60dias': 0, '90dias': 0, '120dias': 0, inativo: 0,
      };

      if (countData) {
        countData.forEach((c: any) => {
          const ordersCount = orderCountMap.get(c.id) || 0;
          const dynamicDays = calculateDaysSinceDate(c.last_order_date);
          const classification = calculateClassification(dynamicDays, ordersCount);
          classificationCounts[classification]++;
        });
      }

      const counts: ClientsCounts = { total: totalFiltered || 0, ...classificationCounts };

      // ── If effectiveLimit is 0, skip data query (count-only mode) ──
      if (effectiveLimit === 0) {
        return { clients: [], totalCount: counts.total, counts };
      }

      // ── Main data query ──
      let dataQuery = supabase
        .from('clients')
        .select('*', { count: 'exact' })
        .eq('is_deleted', false);

      if (statusFilter !== 'all') dataQuery = dataQuery.eq('status', statusFilter);
      if (sellerFilter !== 'all') dataQuery = dataQuery.eq('seller_id', sellerFilter);
      if (searchTerm) {
        const normalizedSearch = searchTerm.trim().replace(/\s+/g, '%');
        dataQuery = dataQuery.or(
          `company_name.ilike.%${normalizedSearch}%,cnpj.ilike.%${normalizedSearch}%,phone.ilike.%${normalizedSearch}%`
        );
      }

      if (classificationFilter === 'recorrente') {
        dataQuery = dataQuery.lte('days_since_last_order', 45);
      } else if (classificationFilter === '60dias') {
        dataQuery = dataQuery.gt('days_since_last_order', 45).lte('days_since_last_order', 60);
      } else if (classificationFilter === '90dias') {
        dataQuery = dataQuery.gt('days_since_last_order', 60).lte('days_since_last_order', 90);
      } else if (classificationFilter === '120dias') {
        dataQuery = dataQuery.gt('days_since_last_order', 90).lte('days_since_last_order', 120);
      } else if (classificationFilter === 'inativo') {
        dataQuery = dataQuery.or('days_since_last_order.gt.120,days_since_last_order.is.null');
      }

      if (rankingFilter === 'top20') dataQuery = dataQuery.eq('ranking_tier', 'top20');
      else if (rankingFilter === 'top100') dataQuery = dataQuery.eq('ranking_tier', 'top100');
      else if (rankingFilter === 'top200') dataQuery = dataQuery.eq('ranking_tier', 'top200');
      else if (rankingFilter === 'top300') dataQuery = dataQuery.eq('ranking_tier', 'top300');
      else if (rankingFilter === 'demais') dataQuery = dataQuery.or('ranking_tier.eq.geral,ranking_tier.eq.eventual,ranking_tier.is.null');

      if (noContactDays && noContactDays > 0) {
        const cutoffDate = new Date();
        cutoffDate.setDate(cutoffDate.getDate() - noContactDays);
        const cutoffDateStr = cutoffDate.toISOString().split('T')[0];
        dataQuery = dataQuery.or(`last_contact_at.is.null,last_contact_at.lt.${cutoffDateStr}`);
        dataQuery = dataQuery.order('last_contact_at', { ascending: true, nullsFirst: true });
      } else {
        dataQuery = dataQuery.order('company_name');
      }

      dataQuery = dataQuery.range(effectiveOffset, effectiveOffset + effectiveLimit - 1);

      const { data: clientsData, count: dataCount } = await dataQuery;

      if (!clientsData) {
        return { clients: [], totalCount: dataCount || 0, counts };
      }

      const clientIds = clientsData.map((c: any) => c.id);
      const clientCountMap = new Map<string, number>();
      clientsData.forEach((c: any) => {
        clientCountMap.set(c.id, c.order_count || 0);
      });

      // BRANCH INHERITANCE
      const branchIds = clientsData
        .filter((c: any) => c.related_client_id)
        .map((c: any) => c.related_client_id);
      const uniqueMatrixIds = [...new Set(branchIds)].filter(Boolean);

      const matrixDataMap = new Map<string, {
        companyName: string;
        lastOrderDate: string | null;
        status: string;
        rankingTier: string | null;
      }>();

      if (uniqueMatrixIds.length > 0) {
        const { data: matrixClients } = await supabase
          .from('clients')
          .select('id, company_name, last_order_date, status, ranking_tier')
          .in('id', uniqueMatrixIds)
          .eq('is_deleted', false);

        const { data: matrixOrderCounts } = await supabase
          .from('orders')
          .select('client_id')
          .in('client_id', uniqueMatrixIds)
          .eq('is_deleted', false);

        const matrixOrderCountMap = new Map<string, number>();
        matrixOrderCounts?.forEach((o: any) => {
          matrixOrderCountMap.set(o.client_id, (matrixOrderCountMap.get(o.client_id) || 0) + 1);
        });

        matrixClients?.forEach((m: any) => {
          matrixDataMap.set(m.id, {
            companyName: m.company_name,
            lastOrderDate: m.last_order_date,
            status: m.status,
            rankingTier: m.ranking_tier,
          });
        });
      }

      let clients: ClientData[] = clientsData.map((c: any) => {
        const ordersCount = clientCountMap.get(c.id) || 0;
        let dynamicDaysSinceOrder = calculateDaysSinceDate(c.last_order_date);
        let dynamicClassification = calculateClassification(dynamicDaysSinceOrder, ordersCount);
        let effectiveStatus = c.status;
        let effectiveRankingTier = c.ranking_tier || 'geral';

        const isLinkedBranch = !!c.related_client_id;
        let matrixName: string | undefined;
        let inheritedFromMatrix = false;

        if (isLinkedBranch && c.related_client_id) {
          const matrixData = matrixDataMap.get(c.related_client_id);
          if (matrixData) {
            matrixName = matrixData.companyName;
            const matrixDaysSinceOrder = calculateDaysSinceDate(matrixData.lastOrderDate);
            if (matrixDaysSinceOrder !== null) {
              if (dynamicDaysSinceOrder === null || matrixDaysSinceOrder < dynamicDaysSinceOrder) {
                dynamicDaysSinceOrder = matrixDaysSinceOrder;
                dynamicClassification = calculateClassification(matrixDaysSinceOrder, ordersCount > 0 ? ordersCount : 2);
                inheritedFromMatrix = true;
              }
            }
            if (matrixData.status === 'ativo' && effectiveStatus !== 'ativo') {
              effectiveStatus = 'ativo';
              inheritedFromMatrix = true;
            }
            const tierPriority: Record<string, number> = { 'top20': 4, 'top100': 3, 'top200': 2, 'geral': 1, 'eventual': 0 };
            const branchPriority = tierPriority[c.ranking_tier || 'geral'] || 0;
            const matrixPriority = tierPriority[matrixData.rankingTier || 'geral'] || 0;
            if (matrixPriority > branchPriority) {
              effectiveRankingTier = matrixData.rankingTier || 'geral';
              inheritedFromMatrix = true;
            }
          }
        }

        return {
          id: c.id,
          companyName: c.company_name,
          cnpj: c.cnpj,
          phone: c.phone,
          status: effectiveStatus,
          classification: dynamicClassification,
          category: c.category,
          rankingTier: effectiveRankingTier,
          totalRevenue: c.total_revenue || 0,
          ordersCount,
          lastOrderDate: c.last_order_date,
          daysSinceLastOrder: dynamicDaysSinceOrder,
          sellerId: c.seller_id,
          lastContactAt: c.last_contact_at,
          isLinkedBranch,
          matrixId: c.related_client_id,
          matrixName,
          inheritedFromMatrix,
        };
      });

      if (classificationFilter === 'novo') {
        clients = clients.filter(c => c.ordersCount === 1);
      } else if (classificationFilter === 'recorrente') {
        clients = clients.filter(c => c.ordersCount > 1);
      }

      return {
        clients,
        totalCount: dataCount || 0,
        counts,
      };
    },
    staleTime: 1000 * 60 * 5,
    refetchOnWindowFocus: false,
    placeholderData: keepPreviousData,
  });

  return {
    clients: query.data?.clients ?? [],
    loading: query.isLoading,
    refetch: query.refetch,
    totalCount: query.data?.totalCount ?? 0,
    counts: query.data?.counts ?? { total: 0, novo: 0, recorrente: 0, '60dias': 0, '90dias': 0, '120dias': 0, inativo: 0 },
  };
}
