import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

interface PaymentTermData {
  avgPaymentDays: number | null;
  loading: boolean;
  totalOrders: number;
}

/**
 * Deriva o prazo de pagamento (em dias) a partir do texto do payment_method
 * quando o campo payment_term_days não está preenchido
 */
function parsePaymentTermFromMethod(method: string | null): number | null {
  if (!method) return null;
  
  const normalized = method.toLowerCase().trim();
  
  // Valores inválidos/não mapeáveis
  if (/^(não informado|outros|null|undefined)/.test(normalized) || normalized === '') {
    return null;
  }
  
  // À vista e similares → 0 dias
  if (/^(à vista|a vista|dinheiro)/.test(normalized)) {
    return 0;
  }
  
  // PIX → 0 dias
  if (/pix/i.test(normalized)) {
    return 0;
  }
  
  // Cartão de Crédito/Débito → 0 dias
  if (/cart[aã]o/i.test(normalized)) {
    return 0;
  }
  
  // Depósito Bancário → 0 dias
  if (/dep[oó]sito/i.test(normalized)) {
    return 0;
  }
  
  // Boleto com prazo específico: "Boleto 28 dias" ou "28/35/42" → extrai o primeiro número
  const boletoMatch = normalized.match(/boleto.*?(\d+)/i);
  if (boletoMatch) {
    return parseInt(boletoMatch[1], 10);
  }
  
  // Boleto genérico sem prazo especificado → assume 28 dias (padrão mercado)
  if (/boleto/i.test(normalized)) {
    return 28;
  }
  
  // Cheque → assume 30 dias
  if (/cheque/i.test(normalized)) {
    return 30;
  }
  
  // Outros valores não mapeáveis
  return null;
}

export function useClientPaymentTerm(clientId: string | null | undefined): PaymentTermData {
  const [avgPaymentDays, setAvgPaymentDays] = useState<number | null>(null);
  const [totalOrders, setTotalOrders] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!clientId) {
      setAvgPaymentDays(null);
      setTotalOrders(0);
      setLoading(false);
      return;
    }

    const fetchPaymentTerm = async () => {
      setLoading(true);
      try {
        // Buscar todos os pedidos do cliente (com payment_method OU payment_term_days)
        const { data, error } = await supabase
          .from('orders')
          .select('payment_term_days, payment_method')
          .eq('client_id', clientId)
          .eq('is_deleted', false);

        if (error) throw error;

        if (data && data.length > 0) {
          // Mapear cada pedido para seu prazo (direto ou derivado)
          const ordersWithTerm = data
            .map(order => {
              // Prioridade: payment_term_days se existir
              if (order.payment_term_days !== null && order.payment_term_days !== undefined) {
                return order.payment_term_days;
              }
              // Fallback: derivar do payment_method
              return parsePaymentTermFromMethod(order.payment_method);
            })
            .filter((term): term is number => term !== null);
          
          setTotalOrders(ordersWithTerm.length);
          
          if (ordersWithTerm.length > 0) {
            const sum = ordersWithTerm.reduce((acc, term) => acc + term, 0);
            const avg = Math.round(sum / ordersWithTerm.length);
            setAvgPaymentDays(avg);
          } else {
            setAvgPaymentDays(null);
          }
        } else {
          setAvgPaymentDays(null);
          setTotalOrders(0);
        }
      } catch (error) {
        console.error('Error fetching payment term:', error);
        setAvgPaymentDays(null);
      } finally {
        setLoading(false);
      }
    };

    fetchPaymentTerm();
  }, [clientId]);

  return { avgPaymentDays, loading, totalOrders };
}
