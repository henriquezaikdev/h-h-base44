import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { format } from 'date-fns';
import { toast } from 'sonner';

export interface ConfiguracaoMensal {
  id: string;
  mes_referencia: string;
  foco_geral: string;
  descricao_foco: string | null;
  status: string;
  versao: number;
  created_at: string;
}

export interface Campanha {
  id: string;
  configuracao_mensal_id: string;
  area: string;
  tipo: string;
  nome: string;
  descricao: string | null;
  modo_validacao: string;
  percentual_minimo: number;
  status: string;
  versao: number;
  pdf_url: string | null;
  created_at: string;
}

export interface CriterioCampanha {
  id: string;
  campanha_id: string;
  nome: string;
  descricao: string | null;
  meta_objetiva: string;
  peso_percentual: number;
  origem_dado: string;
  regra_avaliacao: string | null;
}

export interface MarcacaoCriterio {
  id: string;
  campanha_id: string;
  criterio_id: string;
  user_id: string;
  mes_referencia: string;
  atingiu: boolean;
  marcado_por_user_id: string | null;
  marcado_em: string;
}

export interface StatusCampanhaUsuario {
  id: string;
  campanha_id: string;
  user_id: string;
  mes_referencia: string;
  progresso_percentual: number;
  status: string;
  criterios_atingidos: number;
  criterios_total: number;
  atualizado_em: string;
}

export function useCampanhas(mesRef?: string) {
  const { seller, isOwner, isAdmin } = useAuth();
  const comp = mesRef || format(new Date(), 'yyyy-MM');
  
  const [configuracao, setConfiguracao] = useState<ConfiguracaoMensal | null>(null);
  const [campanhas, setCampanhas] = useState<Campanha[]>([]);
  const [criterios, setCriterios] = useState<CriterioCampanha[]>([]);
  const [marcacoes, setMarcacoes] = useState<MarcacaoCriterio[]>([]);
  const [statusUsuarios, setStatusUsuarios] = useState<StatusCampanhaUsuario[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const { data: config } = await supabase
        .from('configuracao_mensal_campanhas')
        .select('*')
        .eq('mes_referencia', comp)
        .maybeSingle();
      
      setConfiguracao(config as ConfiguracaoMensal | null);

      if (!config) {
        setCampanhas([]);
        setCriterios([]);
        setMarcacoes([]);
        setStatusUsuarios([]);
        setLoading(false);
        return;
      }

      const [campRes, critRes, marcRes, statusRes] = await Promise.all([
        supabase.from('campanhas').select('*').eq('configuracao_mensal_id', config.id),
        supabase.from('criterios_campanha').select('*'),
        supabase.from('marcacao_criterio').select('*').eq('mes_referencia', comp),
        supabase.from('status_campanha_usuario').select('*').eq('mes_referencia', comp),
      ]);

      const camps = (campRes.data || []) as Campanha[];
      setCampanhas(camps);
      
      const campIds = camps.map(c => c.id);
      setCriterios((critRes.data || []).filter((c: any) => campIds.includes(c.campanha_id)) as CriterioCampanha[]);
      setMarcacoes((marcRes.data || []).filter((m: any) => campIds.includes(m.campanha_id)) as MarcacaoCriterio[]);
      setStatusUsuarios((statusRes.data || []).filter((s: any) => campIds.includes(s.campanha_id)) as StatusCampanhaUsuario[]);
    } catch (err) {
      console.error('Error fetching campanhas:', err);
    } finally {
      setLoading(false);
    }
  }, [comp]);

  useEffect(() => { fetchData(); }, [fetchData]);

  // ===== GESTOR ACTIONS =====
  
  const criarConfiguracao = async (foco: string, descricao?: string) => {
    if (!seller?.id) return;
    const { data, error } = await supabase.from('configuracao_mensal_campanhas').insert({
      mes_referencia: comp,
      foco_geral: foco,
      descricao_foco: descricao || null,
      criado_por: seller.id,
    }).select().single();
    if (error) { toast.error('Erro: ' + error.message); return; }
    toast.success('Configuração do mês criada!');
    await fetchData();
    return data;
  };

  const ativarConfiguracao = async () => {
    if (!configuracao || !seller?.id) return;
    const sb = supabase as any;
    await supabase.from('configuracao_mensal_campanhas').update({ status: 'ATIVA' }).eq('id', configuracao.id);
    
    const draftCamps = campanhas.filter(c => c.status === 'RASCUNHO');
    for (const camp of draftCamps) {
      await supabase.from('campanhas').update({ status: 'ATIVA' }).eq('id', camp.id);
    }

    // Fetch active vendedores
    const { data: vendedores } = await supabase
      .from('sellers')
      .select('id')
      .eq('status', 'ATIVO')
      .eq('role', 'vendedor');
    
    const activeCamps = draftCamps.length > 0 ? draftCamps : campanhas.filter(c => c.status === 'ATIVA');

    for (const camp of activeCamps) {
      // Fetch criterios for document generation
      const campCriterios = criterios.filter(c => c.campanha_id === camp.id);

      // Generate campaign document
      const docContent = [
        `CAMPANHA: ${camp.nome}`,
        `Período: ${configuracao.mes_referencia}`,
        `Foco: ${configuracao.foco_geral}`,
        camp.descricao ? `\nDescrição: ${camp.descricao}` : '',
        `\nÁrea: ${camp.area} | Tipo: ${camp.tipo}`,
        `Validação: ${camp.modo_validacao === 'RIGIDO_100' ? '100% Rígido' : `≥${camp.percentual_minimo || 100}%`}`,
        '\n--- CRITÉRIOS DE PREMIAÇÃO ---',
        ...campCriterios.map(c => `• ${c.nome} — Meta: ${c.meta_objetiva} (Peso: ${c.peso_percentual}%)`),
        '\n--- CONDIÇÃO JURÍDICA ---',
        'Esta campanha possui caráter exclusivamente eventual e não integra salário ou remuneração fixa, conforme legislação trabalhista vigente.',
      ].filter(Boolean).join('\n');

      await sb.from('campaign_documents').upsert({
        campaign_id: camp.id,
        title: camp.nome,
        content: docContent,
        created_by: seller.id,
      }, { onConflict: 'campaign_id' }).select();

      // Generate campaign_acceptance for all vendedores
      if (vendedores && vendedores.length > 0) {
        const acceptanceRows = vendedores.map((v: any) => ({
          campaign_id: camp.id,
          user_id: v.id,
          status: 'pendente',
          sent_at: new Date().toISOString(),
        }));
        await sb.from('campaign_acceptance').upsert(acceptanceRows, { onConflict: 'campaign_id,user_id' }).select();
      }
    }

    toast.success('Campanhas ativadas! Ciência enviada para os vendedores.');
    await fetchData();
  };

  const criarCampanha = async (data: Partial<Campanha>) => {
    if (!configuracao || !seller?.id) return;
    const { data: camp, error } = await supabase.from('campanhas').insert({
      configuracao_mensal_id: configuracao.id,
      area: data.area || 'COMERCIAL',
      tipo: data.tipo || 'INDIVIDUAL',
      nome: data.nome || '',
      descricao: data.descricao || null,
      modo_validacao: data.modo_validacao || 'RIGIDO_100',
      percentual_minimo: data.percentual_minimo || 100,
    }).select().single();
    if (error) { toast.error('Erro: ' + error.message); return; }
    toast.success('Campanha criada!');
    await fetchData();
    return camp;
  };

  const adicionarCriterio = async (campanha_id: string, criterio: Partial<CriterioCampanha>) => {
    const { error } = await supabase.from('criterios_campanha').insert({
      campanha_id,
      nome: criterio.nome || '',
      descricao: criterio.descricao || null,
      meta_objetiva: criterio.meta_objetiva || '',
      peso_percentual: criterio.peso_percentual || 0,
      origem_dado: criterio.origem_dado || 'MANUAL',
      regra_avaliacao: criterio.regra_avaliacao || null,
    });
    if (error) { toast.error('Erro: ' + error.message); return; }
    await fetchData();
  };

  const removerCriterio = async (criterioId: string) => {
    await supabase.from('criterios_campanha').delete().eq('id', criterioId);
    await fetchData();
  };

  // ===== MARCAÇÃO MANUAL DE CRITÉRIOS =====
  
  const marcarCriterio = async (campanhaId: string, criterioId: string, userId: string, atingiu: boolean) => {
    if (!seller?.id) return;
    
    await supabase.from('marcacao_criterio').upsert({
      campanha_id: campanhaId,
      criterio_id: criterioId,
      user_id: userId,
      mes_referencia: comp,
      atingiu,
      marcado_por_user_id: seller.id,
      marcado_em: new Date().toISOString(),
    }, { onConflict: 'campanha_id,criterio_id,user_id,mes_referencia' });

    // Recalculate status for this user/campaign
    await recalcularStatus(campanhaId, userId);
    await fetchData();
  };

  const recalcularStatus = async (campanhaId: string, userId: string) => {
    const camp = campanhas.find(c => c.id === campanhaId);
    if (!camp) return;

    const campCriterios = criterios.filter(c => c.campanha_id === campanhaId);
    if (campCriterios.length === 0) return;

    // Fetch fresh marcações for this user/campaign
    const { data: userMarcacoes } = await supabase
      .from('marcacao_criterio')
      .select('*')
      .eq('campanha_id', campanhaId)
      .eq('user_id', userId)
      .eq('mes_referencia', comp);

    let pesoAtingido = 0;
    let criteriosAtingidos = 0;

    for (const crit of campCriterios) {
      const marc = (userMarcacoes || []).find((m: any) => m.criterio_id === crit.id);
      if (marc?.atingiu) {
        pesoAtingido += crit.peso_percentual;
        criteriosAtingidos++;
      }
    }

    const totalPeso = campCriterios.reduce((s, c) => s + c.peso_percentual, 0);
    const progressoPercentual = totalPeso > 0 ? Math.round((pesoAtingido / totalPeso) * 100) : 0;

    let status = 'EM_ANDAMENTO';
    if (camp.status === 'ENCERRADA') {
      if (camp.modo_validacao === 'RIGIDO_100') {
        status = progressoPercentual === 100 ? 'CONQUISTADO' : 'NAO_ATINGIDO';
      } else {
        status = progressoPercentual >= (camp.percentual_minimo || 100) ? 'CONQUISTADO' : 'NAO_ATINGIDO';
      }
    } else {
      // Campaign still active
      if (camp.modo_validacao === 'RIGIDO_100') {
        status = progressoPercentual === 100 ? 'CONQUISTADO' : 'EM_ANDAMENTO';
      } else {
        status = progressoPercentual >= (camp.percentual_minimo || 100) ? 'CONQUISTADO' : 'EM_ANDAMENTO';
      }
    }

    await supabase.from('status_campanha_usuario').upsert({
      campanha_id: campanhaId,
      user_id: userId,
      mes_referencia: comp,
      progresso_percentual: progressoPercentual,
      status,
      criterios_atingidos: criteriosAtingidos,
      criterios_total: campCriterios.length,
      atualizado_em: new Date().toISOString(),
    }, { onConflict: 'campanha_id,user_id,mes_referencia' });
  };

  // ===== HELPERS =====
  
  const getProgressoVendedor = (campanhaId: string, vendedorId: string) => {
    const cached = statusUsuarios.find(s => s.campanha_id === campanhaId && s.user_id === vendedorId);
    if (cached) return { percentual: Number(cached.progresso_percentual), atingidos: cached.criterios_atingidos, total: cached.criterios_total };

    // Fallback: calculate from marcações in memory
    const campCriterios = criterios.filter(c => c.campanha_id === campanhaId);
    if (campCriterios.length === 0) return { percentual: 0, atingidos: 0, total: 0 };
    
    let pesoAtingido = 0;
    let atingidos = 0;
    const totalPeso = campCriterios.reduce((s, c) => s + c.peso_percentual, 0);
    
    for (const crit of campCriterios) {
      const marc = marcacoes.find(m => m.campanha_id === campanhaId && m.criterio_id === crit.id && m.user_id === vendedorId);
      if (marc?.atingiu) {
        pesoAtingido += crit.peso_percentual;
        atingidos++;
      }
    }
    
    return { percentual: totalPeso > 0 ? Math.round((pesoAtingido / totalPeso) * 100) : 0, atingidos, total: campCriterios.length };
  };

  const getStatusVendedor = (campanhaId: string, vendedorId: string) => {
    const cached = statusUsuarios.find(s => s.campanha_id === campanhaId && s.user_id === vendedorId);
    if (cached) return cached.status;

    const camp = campanhas.find(c => c.id === campanhaId);
    if (!camp) return 'EM_ANDAMENTO';
    
    const prog = getProgressoVendedor(campanhaId, vendedorId);
    
    if (camp.status === 'ENCERRADA') {
      if (camp.modo_validacao === 'RIGIDO_100') return prog.percentual === 100 ? 'CONQUISTADO' : 'NAO_ATINGIDO';
      return prog.percentual >= (camp.percentual_minimo || 100) ? 'CONQUISTADO' : 'NAO_ATINGIDO';
    }
    
    if (camp.modo_validacao === 'RIGIDO_100') return prog.percentual === 100 ? 'CONQUISTADO' : 'EM_ANDAMENTO';
    return prog.percentual >= (camp.percentual_minimo || 100) ? 'CONQUISTADO' : 'EM_ANDAMENTO';
  };

  const getMarcacao = (campanhaId: string, criterioId: string, userId: string): boolean | null => {
    const marc = marcacoes.find(m => m.campanha_id === campanhaId && m.criterio_id === criterioId && m.user_id === userId);
    if (!marc) return null;
    return marc.atingiu;
  };

  return {
    configuracao,
    campanhas,
    criterios,
    marcacoes,
    statusUsuarios,
    loading,
    criarConfiguracao,
    ativarConfiguracao,
    criarCampanha,
    adicionarCriterio,
    removerCriterio,
    marcarCriterio,
    getProgressoVendedor,
    getStatusVendedor,
    getMarcacao,
    refetch: fetchData,
  };
}