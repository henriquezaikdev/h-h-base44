import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';

export interface PriorityQueueItem {
  id: string;
  client_id: string;
  client_name: string;
  prioridade_score: number;
  prioridade_nivel: 'maxima' | 'alta' | 'media' | 'baixa';
  motivo_prioridade: string;
  melhor_proxima_acao: string;
  resumo_prioridade: string;
  cliente_em_risco: boolean;
  oportunidade_recompra: boolean;
  data_sugerida: string;
  queue_date: string;
  has_pending_task: boolean;
  contacted_today: boolean;
  ranking_tier: string | null;
  classificacao: string | null;
  faturamento_total: number;
  dias_sem_pedido: number | null;
}

export function useClientPriorityQueue() {
  const { seller } = useAuth();

  const calculateQueue = async (): Promise<PriorityQueueItem[]> => {
    if (!seller?.id) return [];

    const today = new Date().toISOString().split('T')[0];

    // Try to fetch today's cached queue first
    const { data: cached } = await supabase
      .from('client_priority_queue')
      .select('*')
      .eq('seller_id', seller.id)
      .eq('queue_date', today)
      .order('prioridade_score', { ascending: false });

    if (cached && cached.length > 0) {
      return cached as unknown as PriorityQueueItem[];
    }

    // If no cached data, calculate
    const { data, error } = await supabase.functions.invoke('calcular-prioridade-carteira', {
      body: { sellerId: seller.id },
    });

    if (error) throw error;
    return (data?.queue || []) as PriorityQueueItem[];
  };

  const query = useQuery({
    queryKey: ['client-priority-queue', seller?.id],
    queryFn: calculateQueue,
    enabled: !!seller?.id,
    staleTime: 10 * 60 * 1000, // 10 min
    refetchOnWindowFocus: false,
  });

  const refresh = async () => {
    if (!seller?.id) return;
    await supabase.functions.invoke('calcular-prioridade-carteira', {
      body: { sellerId: seller.id },
    });
    query.refetch();
  };

  return {
    queue: query.data || [],
    isLoading: query.isLoading,
    error: query.error,
    refresh,
    topClients: (query.data || []).filter(q => q.prioridade_nivel === 'maxima' || q.prioridade_nivel === 'alta'),
    atRisk: (query.data || []).filter(q => q.cliente_em_risco),
    recompraOportunities: (query.data || []).filter(q => q.oportunidade_recompra),
  };
}
