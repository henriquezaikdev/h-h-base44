import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';

export interface ReplenishmentItem {
  id: string;
  productName: string;
  category: string;
  avgQuantity: number;
  suggestedQuantity: number;
  lastPurchaseDate: Date | null;
  avgIntervalDays: number;
  daysSinceLastPurchase: number;
  status: 'atraso' | 'proximo' | 'normal';
  purchaseCount: number;
  avgUnitPrice: number;
}

interface ProductPurchaseData {
  name: string;
  category: string;
  purchaseDates: Date[];
  quantities: number[];
  unitPrices: number[];
}

// Calcular intervalo médio entre compras (em dias)
function calculateAverageInterval(purchaseDates: Date[]): number {
  if (purchaseDates.length < 2) return 30;
  
  const sorted = [...purchaseDates].sort((a, b) => a.getTime() - b.getTime());
  let totalInterval = 0;
  
  for (let i = 1; i < sorted.length; i++) {
    const diff = Math.floor((sorted[i].getTime() - sorted[i-1].getTime()) / (1000 * 60 * 60 * 24));
    totalInterval += diff;
  }
  
  return Math.round(totalInterval / (sorted.length - 1));
}

// Calcular status de reposição
function getReplenishmentStatus(
  lastPurchaseDate: Date | null,
  avgIntervalDays: number
): 'normal' | 'proximo' | 'atraso' {
  if (!lastPurchaseDate || avgIntervalDays <= 0) return 'normal';
  
  const today = new Date();
  const daysSince = Math.floor((today.getTime() - lastPurchaseDate.getTime()) / (1000 * 60 * 60 * 24));
  
  const proximityThreshold = avgIntervalDays * 0.8;
  
  if (daysSince > avgIntervalDays) {
    return 'atraso';
  } else if (daysSince >= proximityThreshold) {
    return 'proximo';
  }
  return 'normal';
}

// Categorização de produto
const categorizeProduct = (productName: string): string => {
  const name = productName.toLowerCase();
  
  if (name.includes('papel') || name.includes('caneta') || name.includes('lápis') || 
      name.includes('caderno') || name.includes('envelope') || name.includes('grampo') ||
      name.includes('clip') || name.includes('régua') || name.includes('tesoura') ||
      name.includes('cola') || name.includes('fita adesiva') || name.includes('post-it') ||
      name.includes('borracha') || name.includes('apontador') || name.includes('pasta') ||
      name.includes('arquivo') || name.includes('etiqueta')) {
    return 'Papelaria';
  }
  
  if (name.includes('limpa') || name.includes('detergente') || name.includes('desinfetante') ||
      name.includes('alvejante') || name.includes('sabão') || name.includes('esponja') ||
      name.includes('pano') || name.includes('vassoura') || name.includes('rodo') ||
      name.includes('balde') || name.includes('luva') || name.includes('saco de lixo') ||
      name.includes('água sanitária') || name.includes('multiuso') || name.includes('limpador')) {
    return 'Limpeza';
  }
  
  if (name.includes('café') || name.includes('açúcar') || name.includes('adoçante') ||
      name.includes('copo') || name.includes('guardanapo') || name.includes('mexedor') ||
      name.includes('filtro') || name.includes('chá') || name.includes('leite') ||
      name.includes('biscoito') || name.includes('água mineral') || name.includes('garfo') ||
      name.includes('faca') || name.includes('colher') || name.includes('prato')) {
    return 'Copa & Cozinha';
  }
  
  if (name.includes('toner') || name.includes('cartucho') || name.includes('ribbon') ||
      name.includes('mouse') || name.includes('teclado') || name.includes('cabo') ||
      name.includes('pendrive') || name.includes('pilha') || name.includes('bateria') ||
      name.includes('impressora') || name.includes('refil')) {
    return 'Informática / Toner';
  }
  
  if (name.includes('descartável') || name.includes('embalagem') || name.includes('sacola') ||
      name.includes('bobina') || name.includes('filme') || name.includes('alumínio') ||
      name.includes('marmita') || name.includes('isopor') || name.includes('canudo')) {
    return 'Descartáveis / Embalagens';
  }
  
  if (name.includes('papel higiênico') || name.includes('papel toalha') || name.includes('sabonete') ||
      name.includes('álcool') || name.includes('dispenser') || name.includes('higiene')) {
    return 'Higiene';
  }
  
  return 'Outros';
};

export function useClientReplenishment(clientId: string | null, enabled = true) {
  const [items, setItems] = useState<ReplenishmentItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [overdueCount, setOverdueCount] = useState(0);
  const [nearbyCount, setNearbyCount] = useState(0);
  const [hasFetched, setHasFetched] = useState(false);

  const fetchData = useCallback(async () => {
    if (!clientId) {
      setLoading(false);
      return;
    }

    setLoading(true);

    try {
      // Buscar pedidos dos últimos 18 meses
      const eighteenMonthsAgo = new Date();
      eighteenMonthsAgo.setMonth(eighteenMonthsAgo.getMonth() - 18);
      
      const { data: orders } = await supabase
        .from('orders')
        .select('id, order_date')
        .eq('client_id', clientId)
        .gte('order_date', eighteenMonthsAgo.toISOString().split('T')[0]);

      if (!orders || orders.length === 0) {
        setItems([]);
        setLoading(false);
        return;
      }

      const orderIds = orders.map(o => o.id);

      // Buscar itens dos pedidos com info do produto e preço
      const { data: orderItems } = await supabase
        .from('order_items')
        .select(`
          product_name,
          quantity,
          unit_price,
          order_id,
          product_id,
          products (
            category,
            category_id,
            categories (name)
          )
        `)
        .in('order_id', orderIds);

      if (!orderItems || orderItems.length === 0) {
        setItems([]);
        setLoading(false);
        return;
      }

      // Mapear order_id -> order_date
      const orderDateMap = new Map<string, Date>();
      orders.forEach(o => {
        if (o.order_date) {
          orderDateMap.set(o.id, new Date(o.order_date));
        }
      });

      // Agregar produtos
      const productMap = new Map<string, ProductPurchaseData>();

      orderItems.forEach((item: any) => {
        const orderDate = orderDateMap.get(item.order_id);
        if (!orderDate) return;

        const productKey = item.product_name.toLowerCase().trim();

        // Determinar categoria
        let category = 'Outros';
        if (item.products?.categories?.name) {
          category = item.products.categories.name;
        } else if (item.products?.category) {
          category = item.products.category;
        } else {
          category = categorizeProduct(item.product_name);
        }

        if (!productMap.has(productKey)) {
          productMap.set(productKey, {
            name: item.product_name,
            category,
            purchaseDates: [],
            quantities: [],
            unitPrices: [],
          });
        }

        const product = productMap.get(productKey)!;
        product.purchaseDates.push(orderDate);
        product.quantities.push(Number(item.quantity) || 1);
        if (item.unit_price && item.unit_price > 0) {
          product.unitPrices.push(Number(item.unit_price));
        }
      });

      // Calcular status de cada produto
      const today = new Date();
      const replenishmentItems: ReplenishmentItem[] = [];
      const MAX_DAYS_SINCE_PURCHASE = 361; // Não mostrar produtos sem compra há mais de 361 dias

      productMap.forEach((product, key) => {
        if (product.purchaseDates.length < 1) return;

        const sortedDates = [...product.purchaseDates].sort((a, b) => b.getTime() - a.getTime());
        const lastPurchase = sortedDates[0];
        const avgInterval = calculateAverageInterval(product.purchaseDates);
        const daysSince = Math.floor((today.getTime() - lastPurchase.getTime()) / (1000 * 60 * 60 * 24));
        
        // Excluir produtos sem compras há mais de 361 dias
        if (daysSince > MAX_DAYS_SINCE_PURCHASE) return;
        
        const status = getReplenishmentStatus(lastPurchase, avgInterval);

        // Calcular quantidade média
        const avgQty = Math.round(product.quantities.reduce((a, b) => a + b, 0) / product.quantities.length);
        
        // Calcular preço médio de venda
        const avgPrice = product.unitPrices.length > 0 
          ? product.unitPrices.reduce((a, b) => a + b, 0) / product.unitPrices.length 
          : 0;

        replenishmentItems.push({
          id: key,
          productName: product.name,
          category: product.category,
          avgQuantity: avgQty,
          suggestedQuantity: avgQty,
          lastPurchaseDate: lastPurchase,
          avgIntervalDays: avgInterval,
          daysSinceLastPurchase: daysSince,
          status,
          purchaseCount: product.purchaseDates.length,
          avgUnitPrice: Math.round(avgPrice * 100) / 100,
        });
      });

      // Ordenar: atraso primeiro, depois próximo, depois por dias desde última compra
      replenishmentItems.sort((a, b) => {
        const statusOrder = { atraso: 0, proximo: 1, normal: 2 };
        if (statusOrder[a.status] !== statusOrder[b.status]) {
          return statusOrder[a.status] - statusOrder[b.status];
        }
        return b.daysSinceLastPurchase - a.daysSinceLastPurchase;
      });

      setItems(replenishmentItems);
      setOverdueCount(replenishmentItems.filter(i => i.status === 'atraso').length);
      setNearbyCount(replenishmentItems.filter(i => i.status === 'proximo').length);
    } catch (error) {
      console.error('Error fetching client replenishment:', error);
    } finally {
      setLoading(false);
    }
  }, [clientId]);

  useEffect(() => {
    if (enabled && !hasFetched) {
      setHasFetched(true);
      fetchData();
    }
  }, [fetchData, enabled, hasFetched]);

  return {
    items,
    loading: enabled ? loading : false,
    overdueCount,
    nearbyCount,
    refetch: fetchData,
  };
}
