import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { format, startOfMonth, endOfMonth } from 'date-fns';

export interface CEEDinamicoData {
  /** CEE Executado = soma de despesas PJ/EMPRESA pagas no mês */
  ceeExecutado: number;
  /** Despesas pessoais (PF) pagas no mês (excluídas do CEE) */
  despesasPessoais: number;
  /** Total de despesas pagas (todas) */
  totalDespesasPagas: number;
  /** Receita realizada no mês */
  receitaRealizada: number;
  /** Resultado real = Receita - CEE Executado */
  resultadoReal: number;
  /** Loading state */
  loading: boolean;
  /** Competência no formato YYYY-MM */
  competencia: string;
  /** Forçar recálculo */
  refresh: () => void;
}

export function useCEEDinamico(referenceDate?: Date): CEEDinamicoData {
  const [ceeExecutado, setCeeExecutado] = useState(0);
  const [despesasPessoais, setDespesasPessoais] = useState(0);
  const [totalDespesasPagas, setTotalDespesasPagas] = useState(0);
  const [receitaRealizada, setReceitaRealizada] = useState(0);
  const [loading, setLoading] = useState(true);
  const [refreshKey, setRefreshKey] = useState(0);

  const date = referenceDate || new Date();
  const competencia = format(date, 'yyyy-MM');
  const startStr = format(startOfMonth(date), 'yyyy-MM-dd');
  const endStr = format(endOfMonth(date), 'yyyy-MM-dd');

  const refresh = useCallback(() => setRefreshKey(k => k + 1), []);

  useEffect(() => {
    let cancelled = false;

    async function fetchCEE() {
      setLoading(true);
      try {
        // 1) Buscar todas despesas PAGAS no mês com classificação da conta
        const { data: entries } = await supabase
          .from('fin_entries')
          .select('amount_paid, account_name, expense_scope')
          .eq('entry_type', 'PAGAR')
          .eq('status_norm', 'PAGO')
          .eq('is_active', true)
          .gte('paid_date', startStr)
          .lte('paid_date', endStr);

        // 2) Buscar classificação das contas
        const { data: accounts } = await supabase
          .from('fin_accounts')
          .select('account_name, entity_type, expense_scope');

        const accountMap = new Map<string, { entity_type: string; expense_scope: string }>();
        (accounts || []).forEach(a => {
          accountMap.set(a.account_name, {
            entity_type: (a as any).entity_type || 'PJ',
            expense_scope: (a as any).expense_scope || 'EMPRESA',
          });
        });

        let empresa = 0;
        let pessoal = 0;
        let total = 0;

        for (const entry of entries || []) {
          const amt = Number(entry.amount_paid) || 0;
          total += amt;

          // Classificação: prioriza expense_scope do entry, senão herda da conta
          const entryScope = (entry as any).expense_scope;
          const account = entry.account_name ? accountMap.get(entry.account_name) : null;

          let isEmpresa = true;
          if (entryScope === 'PESSOAL') {
            isEmpresa = false;
          } else if (!entryScope && account) {
            if (account.entity_type === 'PF' || account.expense_scope === 'PESSOAL') {
              isEmpresa = false;
            }
          }

          if (isEmpresa) {
            empresa += amt;
          } else {
            pessoal += amt;
          }
        }

        // 3) Buscar receita realizada (contas a RECEBER pagas no mês)
        const { data: recEntries } = await supabase
          .from('fin_entries')
          .select('amount_paid')
          .eq('entry_type', 'RECEBER')
          .eq('status_norm', 'PAGO')
          .eq('is_active', true)
          .gte('paid_date', startStr)
          .lte('paid_date', endStr);

        const receita = (recEntries || []).reduce((sum, e) => sum + (Number(e.amount_paid) || 0), 0);

        if (!cancelled) {
          setCeeExecutado(empresa);
          setDespesasPessoais(pessoal);
          setTotalDespesasPagas(total);
          setReceitaRealizada(receita);
        }
      } catch (err) {
        console.error('[CEE Dinâmico] Erro:', err);
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    fetchCEE();
    return () => { cancelled = true; };
  }, [competencia, startStr, endStr, refreshKey]);

  // Realtime: recalcular quando fin_entries mudar
  useEffect(() => {
    const channel = supabase
      .channel('cee-dinamico')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'fin_entries' },
        () => refresh()
      )
      .subscribe();

    return () => { supabase.removeChannel(channel); };
  }, [refresh]);

  return {
    ceeExecutado,
    despesasPessoais,
    totalDespesasPagas,
    receitaRealizada,
    resultadoReal: receitaRealizada - ceeExecutado,
    loading,
    competencia,
    refresh,
  };
}
