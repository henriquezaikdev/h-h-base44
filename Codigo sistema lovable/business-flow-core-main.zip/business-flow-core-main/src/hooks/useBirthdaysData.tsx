import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';

export interface BirthdayRecord {
  id: string;
  name: string;
  birthday_day: number;
  birthday_month: number;
  daysUntil: number;
  type: 'client' | 'buyer';
  client_id?: string;
  seller_name?: string;
}

export interface IncompleteBirthday {
  id: string;
  name: string;
  birthday_month: number | null;
  birthday_day: number | null;
  type: 'client' | 'buyer';
  client_id?: string;
  client_name?: string;
}

function calculateDaysUntil(day: number, month: number): number {
  const now = new Date();
  const currentYear = now.getFullYear();
  
  let birthdayThisYear = new Date(currentYear, month - 1, day);
  
  if (birthdayThisYear < now) {
    birthdayThisYear = new Date(currentYear + 1, month - 1, day);
  }
  
  const diffTime = birthdayThisYear.getTime() - now.getTime();
  return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
}

export function useBirthdaysData(sellerId?: string | null, daysAhead: number = 7) {
  const [birthdays, setBirthdays] = useState<BirthdayRecord[]>([]);
  const [incompleteBirthdays, setIncompleteBirthdays] = useState<IncompleteBirthday[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchData = useCallback(async () => {
    if (!sellerId) {
      setLoading(false);
      return;
    }

    setLoading(true);
    const upcomingBirthdays: BirthdayRecord[] = [];
    const incomplete: IncompleteBirthday[] = [];

    try {
      // Fetch clients with their birthdays
      const { data: clients } = await supabase
        .from('clients')
        .select('id, company_name, birthday_day, birthday_month, seller_id')
        .eq('seller_id', sellerId)
        .eq('is_deleted', false);

      // Fetch buyers with birthdays for these clients
      const clientIds = clients?.map(c => c.id) || [];
      const { data: buyers } = await supabase
        .from('buyers')
        .select('id, name, birthday_day, birth_month, client_id')
        .in('client_id', clientIds);

      // Create client name map
      const clientNameMap = new Map(clients?.map(c => [c.id, c.company_name]) || []);

      // Process clients
      clients?.forEach(client => {
        const hasDay = client.birthday_day !== null;
        const hasMonth = client.birthday_month !== null;

        if (hasDay && hasMonth) {
          const daysUntil = calculateDaysUntil(client.birthday_day!, client.birthday_month!);
          if (daysUntil >= 0 && daysUntil <= daysAhead) {
            upcomingBirthdays.push({
              id: client.id,
              name: client.company_name,
              birthday_day: client.birthday_day!,
              birthday_month: client.birthday_month!,
              daysUntil,
              type: 'client',
            });
          }
        } else if (hasMonth || hasDay) {
          // Incomplete birthday - has partial info
          incomplete.push({
            id: client.id,
            name: client.company_name,
            birthday_month: client.birthday_month,
            birthday_day: client.birthday_day,
            type: 'client',
          });
        }
      });

      // Process buyers
      buyers?.forEach(buyer => {
        const hasDay = buyer.birthday_day !== null;
        const hasMonth = buyer.birth_month !== null;

        if (hasDay && hasMonth) {
          const daysUntil = calculateDaysUntil(buyer.birthday_day!, buyer.birth_month!);
          if (daysUntil >= 0 && daysUntil <= daysAhead) {
            upcomingBirthdays.push({
              id: buyer.id,
              name: buyer.name,
              birthday_day: buyer.birthday_day!,
              birthday_month: buyer.birth_month!,
              daysUntil,
              type: 'buyer',
              client_id: buyer.client_id,
            });
          }
        } else if (hasMonth || hasDay) {
          // Incomplete birthday
          incomplete.push({
            id: buyer.id,
            name: buyer.name,
            birthday_month: buyer.birth_month,
            birthday_day: buyer.birthday_day,
            type: 'buyer',
            client_id: buyer.client_id,
            client_name: clientNameMap.get(buyer.client_id),
          });
        }
      });

      // Sort by days until birthday
      upcomingBirthdays.sort((a, b) => a.daysUntil - b.daysUntil);

      setBirthdays(upcomingBirthdays);
      setIncompleteBirthdays(incomplete);
    } catch (error) {
      console.error('Error fetching birthdays:', error);
    } finally {
      setLoading(false);
    }
  }, [sellerId, daysAhead]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  return {
    birthdays,
    incompleteBirthdays,
    loading,
    refetch: fetchData,
  };
}
