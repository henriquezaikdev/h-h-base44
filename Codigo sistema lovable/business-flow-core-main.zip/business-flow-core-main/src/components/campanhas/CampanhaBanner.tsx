import { useCampanhaCiencia } from '@/hooks/useCampanhaCiencia';
import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from '@/components/ui/dialog';
import { AlertTriangle, Eye, CheckCircle, XCircle, Clock } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';

export function CampanhaBanner() {
  const { acceptances, loading, aceitarCampanha, recusarCampanha, viewDocument } = useCampanhaCiencia();
  const [docModal, setDocModal] = useState<{ title: string; content: string; acceptanceId: string; status: string } | null>(null);
  const [acting, setActing] = useState(false);

  if (loading || acceptances.length === 0) return null;

  const pending = acceptances.filter(a => a.status === 'pendente');

  const handleView = async (acc: typeof acceptances[0]) => {
    const doc = await viewDocument(acc.campaign_id, acc.id);
    if (doc) {
      setDocModal({ title: doc.title, content: doc.content, acceptanceId: acc.id, status: acc.status });
    }
  };

  const handleAceitar = async () => {
    if (!docModal) return;
    setActing(true);
    await aceitarCampanha(docModal.acceptanceId);
    setActing(false);
    setDocModal(null);
  };

  const handleRecusar = async () => {
    if (!docModal) return;
    setActing(true);
    await recusarCampanha(docModal.acceptanceId);
    setActing(false);
    setDocModal(null);
  };

  if (pending.length === 0) return null;

  return (
    <>
      <Card className="border-amber-300 bg-amber-50/80 dark:bg-amber-950/20 rounded-2xl shadow-sm">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <AlertTriangle className="h-5 w-5 text-amber-600 mt-0.5 shrink-0" />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-amber-800 dark:text-amber-300">
                {pending.length === 1 ? 'Campanha aguardando sua ciência' : `${pending.length} campanhas aguardando sua ciência`}
              </p>
              <p className="text-xs text-amber-700 dark:text-amber-400 mt-0.5">
                Leia o regulamento e aceite ou recuse a participação.
              </p>
              <div className="flex flex-wrap gap-2 mt-2">
                {pending.map(acc => (
                  <Button
                    key={acc.id}
                    size="sm"
                    variant="outline"
                    className="gap-1 text-xs border-amber-300 text-amber-800 hover:bg-amber-100"
                    onClick={() => handleView(acc)}
                  >
                    <Eye className="h-3.5 w-3.5" />
                    {acc.campanha_nome}
                  </Button>
                ))}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Modal do documento */}
      <Dialog open={!!docModal} onOpenChange={(open) => !open && setDocModal(null)}>
        <DialogContent className="max-w-lg max-h-[85vh] flex flex-col">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-base">
              <Eye className="h-4 w-4 text-primary" />
              {docModal?.title || 'Documento da Campanha'}
            </DialogTitle>
            <DialogDescription className="text-xs">
              Leia atentamente antes de aceitar ou recusar.
            </DialogDescription>
          </DialogHeader>
          <ScrollArea className="flex-1 max-h-[50vh]">
            <div className="whitespace-pre-wrap text-sm text-muted-foreground bg-muted/30 rounded-xl p-4 border">
              {docModal?.content}
            </div>
          </ScrollArea>
          {docModal?.status === 'pendente' && (
            <DialogFooter className="gap-2 sm:gap-2">
              <Button
                variant="outline"
                onClick={handleRecusar}
                disabled={acting}
                className="gap-1"
              >
                <XCircle className="h-4 w-4" />
                Recusar participar
              </Button>
              <Button
                onClick={handleAceitar}
                disabled={acting}
                className="gap-1"
              >
                <CheckCircle className="h-4 w-4" />
                Aceitar participar
              </Button>
            </DialogFooter>
          )}
          {docModal?.status === 'aceito' && (
            <div className="flex items-center gap-2 text-sm text-emerald-600 justify-center py-2">
              <CheckCircle className="h-4 w-4" /> Você já aceitou esta campanha.
            </div>
          )}
          {docModal?.status === 'recusado' && (
            <div className="flex items-center gap-2 text-sm text-destructive justify-center py-2">
              <XCircle className="h-4 w-4" /> Você recusou esta campanha.
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
