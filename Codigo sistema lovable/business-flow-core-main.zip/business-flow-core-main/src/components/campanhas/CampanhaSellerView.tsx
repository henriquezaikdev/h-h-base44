import { useState } from 'react';
import { useCampanhas } from '@/hooks/useCampanhas';
import { useCampanhaCiencia } from '@/hooks/useCampanhaCiencia';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from '@/components/ui/dialog';
import { Trophy, CheckCircle, XCircle, Clock, Eye, AlertTriangle } from 'lucide-react';
import { motion } from 'framer-motion';

const STATUS_CONFIG: Record<string, { label: string; color: string; icon: any }> = {
  CONQUISTADO: { label: 'Conquistado', color: 'bg-emerald-100 text-emerald-700 border-emerald-200', icon: CheckCircle },
  EM_ANDAMENTO: { label: 'Em Andamento', color: 'bg-blue-100 text-blue-700 border-blue-200', icon: Clock },
  NAO_ATINGIDO: { label: 'Não Atingido', color: 'bg-red-100 text-red-700 border-red-200', icon: XCircle },
};

interface CampanhaSellerViewProps {
  sellerId: string;
}

export function CampanhaSellerView({ sellerId }: CampanhaSellerViewProps) {
  const { campanhas, criterios, configuracao, loading, getProgressoVendedor, getStatusVendedor, getMarcacao } = useCampanhas();
  const { acceptances, loading: accLoading, aceitarCampanha, recusarCampanha, viewDocument } = useCampanhaCiencia();
  const [docModal, setDocModal] = useState<{ title: string; content: string; acceptanceId: string; status: string } | null>(null);
  const [acting, setActing] = useState(false);

  if (loading || accLoading) {
    return <div className="py-8 text-center text-sm text-muted-foreground animate-pulse">Carregando campanhas...</div>;
  }

  if (!configuracao || configuracao.status === 'RASCUNHO') {
    return (
      <Card className="border-dashed border-2 border-muted-foreground/20">
        <CardContent className="py-16 text-center space-y-4">
          <motion.div initial={{ scale: 0.8 }} animate={{ scale: 1 }} transition={{ type: 'spring', stiffness: 200 }} className="w-16 h-16 mx-auto rounded-2xl bg-primary/10 flex items-center justify-center">
            <Trophy className="h-8 w-8 text-primary/50" />
          </motion.div>
          <div>
            <h3 className="text-lg font-semibold">Nenhuma campanha ativa</h3>
            <p className="text-sm text-muted-foreground mt-1 max-w-md mx-auto">
              Quando houver campanhas ativas, elas aparecerão aqui com critérios, progresso e status.
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  const activeCamps = campanhas.filter(c => c.status === 'ATIVA' || c.status === 'ENCERRADA');

  const getAcceptanceForCampaign = (campaignId: string) =>
    acceptances.find(a => a.campaign_id === campaignId);

  const handleView = async (campaignId: string, acceptanceId: string, status: string) => {
    const doc = await viewDocument(campaignId, acceptanceId);
    if (doc) {
      setDocModal({ title: doc.title, content: doc.content, acceptanceId, status });
    }
  };

  const handleAceitar = async () => {
    if (!docModal) return;
    setActing(true);
    await aceitarCampanha(docModal.acceptanceId);
    setActing(false);
    setDocModal(null);
  };

  const handleRecusar = async () => {
    if (!docModal) return;
    setActing(true);
    await recusarCampanha(docModal.acceptanceId);
    setActing(false);
    setDocModal(null);
  };

  const getAcceptanceBadge = (status: string) => {
    switch (status) {
      case 'aceito':
        return <Badge className="bg-emerald-100 text-emerald-700 border-emerald-200 gap-0.5 text-[10px]"><CheckCircle className="h-3 w-3" /> Aceita</Badge>;
      case 'recusado':
        return <Badge className="bg-red-100 text-red-700 border-red-200 gap-0.5 text-[10px]"><XCircle className="h-3 w-3" /> Recusada</Badge>;
      default:
        return <Badge className="bg-amber-100 text-amber-700 border-amber-200 gap-0.5 text-[10px]"><Clock className="h-3 w-3" /> Pendente</Badge>;
    }
  };

  return (
    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
      {/* Month focus */}
      <Card className="bg-gradient-to-r from-primary/5 to-primary/10 border-primary/20 rounded-2xl">
        <CardContent className="p-4">
          <p className="text-xs font-semibold text-primary uppercase">Foco do Mês</p>
          <p className="text-sm font-medium mt-1">{configuracao.foco_geral}</p>
          {configuracao.descricao_foco && <p className="text-xs text-muted-foreground mt-0.5">{configuracao.descricao_foco}</p>}
        </CardContent>
      </Card>

      {activeCamps.map(camp => {
        const acc = getAcceptanceForCampaign(camp.id);
        const isAccepted = acc?.status === 'aceito';
        const isPending = acc?.status === 'pendente';
        const isDeclined = acc?.status === 'recusado';
        const progresso = getProgressoVendedor(camp.id, sellerId);
        const status = getStatusVendedor(camp.id, sellerId);
        const statusConf = STATUS_CONFIG[status] || STATUS_CONFIG.EM_ANDAMENTO;
        const StatusIcon = statusConf.icon;
        const campCriterios = criterios.filter(c => c.campanha_id === camp.id);

        return (
          <Card key={camp.id} className="bg-card/80 backdrop-blur-sm rounded-2xl shadow-sm border">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-base flex items-center gap-2">
                  <Trophy className="h-4 w-4 text-primary" />
                  {camp.nome}
                </CardTitle>
                <div className="flex items-center gap-1.5">
                  {acc && getAcceptanceBadge(acc.status)}
                  {isAccepted && (
                    <Badge variant="outline" className={`text-[10px] ${statusConf.color} gap-0.5 rounded-lg`}>
                      <StatusIcon className="h-3 w-3" /> {statusConf.label}
                    </Badge>
                  )}
                </div>
              </div>
              <div className="flex items-center gap-2 mt-1">
                <Badge variant="outline" className="text-[10px] rounded-lg">{camp.area}</Badge>
                <Badge variant="outline" className="text-[10px] rounded-lg">{camp.tipo}</Badge>
              </div>
              {camp.descricao && <p className="text-xs text-muted-foreground mt-1">{camp.descricao}</p>}
            </CardHeader>
            <CardContent className="space-y-3">
              {/* Pending acceptance alert */}
              {isPending && acc && (
                <div className="flex items-center gap-3 bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-800 rounded-xl p-3">
                  <AlertTriangle className="h-4 w-4 text-amber-600 shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-medium text-amber-800 dark:text-amber-300">Aceite pendente</p>
                    <p className="text-xs text-amber-700 dark:text-amber-400">Leia o regulamento para participar.</p>
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    className="gap-1 text-xs shrink-0 border-amber-300"
                    onClick={() => handleView(camp.id, acc.id, acc.status)}
                  >
                    <Eye className="h-3.5 w-3.5" /> Ver campanha
                  </Button>
                </div>
              )}

              {/* Declined notice */}
              {isDeclined && acc && (
                <div className="flex items-center gap-3 bg-red-50 dark:bg-red-950/20 border border-red-200 dark:border-red-800 rounded-xl p-3">
                  <XCircle className="h-4 w-4 text-red-500 shrink-0" />
                  <div className="flex-1">
                    <p className="text-xs font-medium text-red-700 dark:text-red-300">Você recusou esta campanha</p>
                  </div>
                  <Button
                    size="sm"
                    variant="ghost"
                    className="gap-1 text-xs shrink-0"
                    onClick={() => handleView(camp.id, acc.id, acc.status)}
                  >
                    <Eye className="h-3.5 w-3.5" /> Ver documento
                  </Button>
                </div>
              )}

              {/* Show progress only if accepted */}
              {isAccepted && (
                <>
                  <div>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="text-muted-foreground">Progresso ({progresso.atingidos}/{progresso.total} critérios)</span>
                      <span className="font-bold">{progresso.percentual}%</span>
                    </div>
                    <Progress value={progresso.percentual} className="h-2 rounded-full" />
                  </div>

                  {campCriterios.map(crit => {
                    const marcacao = getMarcacao(camp.id, crit.id, sellerId);
                    return (
                      <div key={crit.id} className="flex items-center gap-3 bg-muted/50 rounded-xl p-3">
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium">{crit.nome}</p>
                          <p className="text-xs text-muted-foreground">{crit.meta_objetiva}</p>
                        </div>
                        <Badge variant="outline" className="text-[10px] shrink-0">{crit.peso_percentual}%</Badge>
                        {marcacao === true ? (
                          <CheckCircle className="h-4 w-4 text-emerald-500 shrink-0" />
                        ) : marcacao === false ? (
                          <XCircle className="h-4 w-4 text-red-400 shrink-0" />
                        ) : (
                          <Clock className="h-4 w-4 text-muted-foreground/30 shrink-0" />
                        )}
                      </div>
                    );
                  })}
                </>
              )}

              {/* Accepted: show view document button */}
              {isAccepted && acc && (
                <Button
                  size="sm"
                  variant="ghost"
                  className="gap-1 text-xs w-full"
                  onClick={() => handleView(camp.id, acc.id, acc.status)}
                >
                  <Eye className="h-3.5 w-3.5" /> Ver regulamento da campanha
                </Button>
              )}
            </CardContent>
          </Card>
        );
      })}

      {activeCamps.length === 0 && (
        <p className="text-sm text-muted-foreground text-center py-8">Nenhuma campanha disponível para sua área.</p>
      )}

      {/* Document modal */}
      <Dialog open={!!docModal} onOpenChange={(open) => !open && setDocModal(null)}>
        <DialogContent className="max-w-lg max-h-[85vh] flex flex-col">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-base">
              <Eye className="h-4 w-4 text-primary" />
              {docModal?.title || 'Documento da Campanha'}
            </DialogTitle>
            <DialogDescription className="text-xs">
              Leia atentamente o regulamento completo.
            </DialogDescription>
          </DialogHeader>
          <ScrollArea className="flex-1 max-h-[50vh]">
            <div className="whitespace-pre-wrap text-sm text-muted-foreground bg-muted/30 rounded-xl p-4 border">
              {docModal?.content}
            </div>
          </ScrollArea>
          {docModal?.status === 'pendente' && (
            <DialogFooter className="gap-2 sm:gap-2">
              <Button
                variant="outline"
                onClick={handleRecusar}
                disabled={acting}
                className="gap-1"
              >
                <XCircle className="h-4 w-4" />
                Recusar participar
              </Button>
              <Button
                onClick={handleAceitar}
                disabled={acting}
                className="gap-1"
              >
                <CheckCircle className="h-4 w-4" />
                Aceitar participar
              </Button>
            </DialogFooter>
          )}
          {docModal?.status === 'aceito' && (
            <div className="flex items-center gap-2 text-sm text-emerald-600 justify-center py-2">
              <CheckCircle className="h-4 w-4" /> Você já aceitou esta campanha.
            </div>
          )}
          {docModal?.status === 'recusado' && (
            <div className="flex items-center gap-2 text-sm text-destructive justify-center py-2">
              <XCircle className="h-4 w-4" /> Você recusou esta campanha.
            </div>
          )}
        </DialogContent>
      </Dialog>
    </motion.div>
  );
}
