import { useState } from 'react';
import { useIncentiveCampaigns, MODEL_TYPES, METRIC_KEYS, PRIZE_TYPES, IncentiveCampaign } from '@/hooks/useIncentiveCampaigns';
import { useAuth } from '@/hooks/useAuth';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Progress } from '@/components/ui/progress';
import { Trophy, CheckCircle, XCircle, Eye, Loader2 } from 'lucide-react';
import { format, parseISO } from 'date-fns';

export function IncentiveCampaignPublic() {
  const { seller } = useAuth();
  const {
    campaigns, isLoading, getCriteria, getMyParticipation,
    acceptCampaign, declineCampaign, getResults, getParticipants,
  } = useIncentiveCampaigns();

  const [viewRulebook, setViewRulebook] = useState<IncentiveCampaign | null>(null);
  const [accepting, setAccepting] = useState<string | null>(null);
  const [hasRead, setHasRead] = useState(false);

  const activeCampaigns = campaigns.filter(c => c.status === 'ACTIVE' || c.status === 'CLOSED');

  const handleAccept = async (campId: string) => {
    setAccepting(campId);
    await acceptCampaign(campId);
    setAccepting(null);
    setViewRulebook(null);
    setHasRead(false);
  };

  if (isLoading) return <div className="py-8 text-center text-muted-foreground animate-pulse">Carregando campanhas...</div>;

  if (activeCampaigns.length === 0) {
    return (
      <Card className="bg-card/80 backdrop-blur-sm rounded-2xl shadow-sm border border-border/50">
        <CardContent className="p-8 text-center text-muted-foreground text-sm">
          <Trophy className="h-8 w-8 mx-auto mb-2 opacity-30" />
          Nenhuma campanha de incentivo ativa no momento
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-foreground flex items-center gap-2">
        <Trophy className="h-4 w-4 text-[#FF6A00]" /> Campanhas de Incentivo
      </h3>

      {activeCampaigns.map(camp => {
        const criteria = getCriteria(camp.id);
        const myPart = getMyParticipation(camp.id);
        const myResults = getResults(camp.id).find(r => r.user_id === seller?.id);
        const modelInfo = MODEL_TYPES.find(m => m.key === camp.model_type);
        const isAccepted = myPart?.status === 'ACCEPTED';
        const isInvited = myPart?.status === 'INVITED';

        return (
          <Card key={camp.id} className="bg-card/80 backdrop-blur-sm rounded-2xl shadow-sm border border-border/50">
            <CardContent className="p-4 space-y-3">
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-lg">{modelInfo?.icon || '🏆'}</span>
                    <h4 className="font-bold text-sm text-foreground">{camp.title}</h4>
                    <Badge className={`text-[10px] rounded-lg ${camp.status === 'ACTIVE' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'}`}>
                      {camp.status === 'ACTIVE' ? 'Ativa' : 'Encerrada'}
                    </Badge>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    {format(parseISO(camp.start_date), 'dd/MM/yyyy')} — {format(parseISO(camp.end_date), 'dd/MM/yyyy')}
                  </p>
                  {camp.description && <p className="text-xs text-muted-foreground mt-1">{camp.description}</p>}
                </div>
              </div>

              {/* Criteria */}
              <div className="flex flex-wrap gap-1.5">
                {criteria.map(c => (
                  <Badge key={c.id} variant="outline" className="text-[10px] rounded-lg">
                    {METRIC_KEYS.find(m => m.key === c.metric_key)?.label} {c.operator} {c.target_value}
                  </Badge>
                ))}
              </div>

              {/* Prize info */}
              <div className="text-xs text-muted-foreground">
                🎁 Prêmio: {PRIZE_TYPES.find(p => p.key === camp.prize_type)?.label}
                {camp.prize_value > 0 && ` — R$ ${camp.prize_value}`}
                {camp.prize_description && ` (${camp.prize_description})`}
              </div>

              {/* Status / Actions */}
              {isAccepted && (
                <div className="flex items-center gap-2 text-xs">
                  <CheckCircle className="h-3.5 w-3.5 text-emerald-500" />
                  <span className="text-emerald-700 font-medium">Aceite registrado</span>
                  {myResults && (
                    <Badge className={`text-[10px] rounded-lg ml-auto ${myResults.achieved ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'}`}>
                      {myResults.achieved ? '✅ Atingiu' : '⏳ Em andamento'}
                      {myResults.rank_position && ` · #${myResults.rank_position}`}
                    </Badge>
                  )}
                </div>
              )}

              {isInvited && camp.status === 'ACTIVE' && (
                <div className="flex items-center gap-2">
                  <Button size="sm" onClick={() => { setViewRulebook(camp); setHasRead(false); }} className="rounded-xl text-xs gap-1.5">
                    <Eye className="h-3 w-3" /> Ver Regulamento e Aceitar
                  </Button>
                </div>
              )}

              {!myPart && (
                <p className="text-xs text-muted-foreground italic">Você não participa desta campanha</p>
              )}

              {myPart?.status === 'DECLINED' && (
                <p className="text-xs text-red-500 italic flex items-center gap-1">
                  <XCircle className="h-3 w-3" /> Participação recusada
                </p>
              )}
            </CardContent>
          </Card>
        );
      })}

      {/* Rulebook + Acceptance Modal */}
      {viewRulebook && (
        <Dialog open={!!viewRulebook} onOpenChange={() => { setViewRulebook(null); setHasRead(false); }}>
          <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Regulamento — {viewRulebook.title}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <pre className="text-xs whitespace-pre-wrap bg-muted/50 p-4 rounded-xl max-h-80 overflow-y-auto leading-relaxed">
                {viewRulebook.rulebook_text}
              </pre>

              <div className="flex items-start gap-3 p-3 rounded-xl bg-amber-50 border border-amber-200">
                <input
                  type="checkbox"
                  id="read-camp-rules"
                  checked={hasRead}
                  onChange={e => setHasRead(e.target.checked)}
                  className="mt-1 rounded"
                />
                <label htmlFor="read-camp-rules" className="text-xs text-amber-800 cursor-pointer leading-relaxed">
                  Declaro que li e compreendi o regulamento desta campanha ({viewRulebook.title}). Estou ciente das regras, critérios e condições de premiação.
                </label>
              </div>

              <div className="flex gap-2">
                <Button
                  onClick={() => handleAccept(viewRulebook.id)}
                  disabled={!hasRead || accepting === viewRulebook.id}
                  className="flex-1 rounded-xl gap-2"
                >
                  {accepting === viewRulebook.id ? <Loader2 className="h-4 w-4 animate-spin" /> : <CheckCircle className="h-4 w-4" />}
                  Aceitar e Participar
                </Button>
                <Button
                  variant="outline"
                  onClick={async () => { await declineCampaign(viewRulebook.id); setViewRulebook(null); }}
                  className="rounded-xl"
                >
                  Recusar
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
