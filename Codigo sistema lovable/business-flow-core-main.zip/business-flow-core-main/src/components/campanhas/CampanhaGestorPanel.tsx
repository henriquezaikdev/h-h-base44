import { useState, useEffect } from 'react';
import { useCampanhas, Campanha, CriterioCampanha } from '@/hooks/useCampanhas';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Progress } from '@/components/ui/progress';
import {
  Trophy, Plus, Send, Settings, CheckCircle, XCircle, Clock, Users, BarChart3, Trash2,
} from 'lucide-react';
import { toast } from 'sonner';

const AREAS = ['COMERCIAL', 'COMPRAS', 'ADMINISTRATIVO', 'LOGISTICA', 'OUTROS'];

export function CampanhaGestorPanel() {
  const {
    configuracao, campanhas, criterios, marcacoes,
    loading, criarConfiguracao, ativarConfiguracao,
    criarCampanha, adicionarCriterio, removerCriterio,
    marcarCriterio, getProgressoVendedor, getStatusVendedor, getMarcacao, refetch,
  } = useCampanhas();

  const [showCreateConfig, setShowCreateConfig] = useState(false);
  const [focoGeral, setFocoGeral] = useState('');
  const [descFoco, setDescFoco] = useState('');
  const [showCreateCamp, setShowCreateCamp] = useState(false);
  const [newCamp, setNewCamp] = useState({ nome: '', descricao: '', area: 'COMERCIAL', tipo: 'INDIVIDUAL', modo_validacao: 'RIGIDO_100', percentual_minimo: 100 });
  const [selectedCampId, setSelectedCampId] = useState<string | null>(null);
  const [newCrit, setNewCrit] = useState({ nome: '', descricao: '', meta_objetiva: '', peso_percentual: 0 });
  const [showRanking, setShowRanking] = useState<string | null>(null);
  const [sellers, setSellers] = useState<any[]>([]);
  const [areaFilter, setAreaFilter] = useState('TODOS');

  useEffect(() => {
    supabase.from('sellers').select('id, name, role, department, status, is_sales_active')
      .eq('status', 'ATIVO')
      .then(({ data }) => {
        const vendedores = (data || []).filter((s: any) =>
          s.role === 'vendedor' || s.is_sales_active === true
        );
        setSellers(vendedores);
      });
  }, []);

  if (loading) return <div className="py-8 text-center text-sm text-muted-foreground animate-pulse">Carregando...</div>;

  const handleCreateConfig = async () => {
    if (!focoGeral.trim()) return;
    await criarConfiguracao(focoGeral, descFoco);
    setShowCreateConfig(false);
    setFocoGeral('');
    setDescFoco('');
  };

  const handleCreateCamp = async () => {
    if (!newCamp.nome.trim()) return;
    await criarCampanha(newCamp as any);
    setShowCreateCamp(false);
    setNewCamp({ nome: '', descricao: '', area: 'COMERCIAL', tipo: 'INDIVIDUAL', modo_validacao: 'RIGIDO_100', percentual_minimo: 100 });
  };

  const handleAddCriterio = async () => {
    if (!selectedCampId || !newCrit.nome.trim() || !newCrit.peso_percentual) return;
    await adicionarCriterio(selectedCampId, newCrit);
    setNewCrit({ nome: '', descricao: '', meta_objetiva: '', peso_percentual: 0 });
  };

  const filteredCamps = areaFilter === 'TODOS' ? campanhas : campanhas.filter(c => c.area === areaFilter);
  const somaP = (campId: string) => criterios.filter(c => c.campanha_id === campId).reduce((s, c) => s + c.peso_percentual, 0);

  return (
    <div className="space-y-4">
      {/* Config do mês */}
      {!configuracao ? (
        <Card className="border-dashed border-2 border-muted-foreground/20 rounded-2xl">
          <CardContent className="py-12 text-center space-y-4">
            <Settings className="h-10 w-10 mx-auto text-muted-foreground/40" />
            <div>
              <h3 className="text-lg font-semibold">Configurar mês</h3>
              <p className="text-sm text-muted-foreground">Defina o foco do mês e crie campanhas.</p>
            </div>
            <Button onClick={() => setShowCreateConfig(true)} className="rounded-xl gap-2">
              <Plus className="h-4 w-4" /> Criar Configuração
            </Button>
          </CardContent>
        </Card>
      ) : (
        <Card className="bg-card/80 backdrop-blur-sm rounded-2xl shadow-sm border">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-base flex items-center gap-2">
                <Settings className="h-4 w-4 text-primary" />
                {configuracao.mes_referencia} — {configuracao.foco_geral}
              </CardTitle>
              <Badge variant="outline" className={`text-xs rounded-lg ${configuracao.status === 'ATIVA' ? 'bg-emerald-50 text-emerald-700' : configuracao.status === 'ENCERRADA' ? 'bg-muted text-muted-foreground' : 'bg-amber-50 text-amber-700'}`}>
                {configuracao.status}
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            {configuracao.descricao_foco && <p className="text-xs text-muted-foreground">{configuracao.descricao_foco}</p>}
            <div className="flex gap-2">
              {configuracao.status === 'RASCUNHO' && campanhas.length > 0 && (
                <Button
                  size="sm"
                  onClick={ativarConfiguracao}
                  disabled={!campanhas.every(c => somaP(c.id) === 100)}
                  className="rounded-xl gap-1"
                  title={!campanhas.every(c => somaP(c.id) === 100) ? 'Todas as campanhas devem ter soma de pesos = 100%' : ''}
                >
                  <Send className="h-3.5 w-3.5" /> Ativar Campanhas
                </Button>
              )}
              {configuracao.status !== 'ENCERRADA' && (
                <Button size="sm" variant="outline" onClick={() => setShowCreateCamp(true)} className="rounded-xl gap-1">
                  <Plus className="h-3.5 w-3.5" /> Nova Campanha
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Filter */}
      {campanhas.length > 0 && (
        <div className="flex gap-2 flex-wrap">
          <Button size="sm" variant={areaFilter === 'TODOS' ? 'default' : 'outline'} onClick={() => setAreaFilter('TODOS')} className="rounded-xl text-xs">Todos</Button>
          {AREAS.map(a => (
            <Button key={a} size="sm" variant={areaFilter === a ? 'default' : 'outline'} onClick={() => setAreaFilter(a)} className="rounded-xl text-xs">{a}</Button>
          ))}
        </div>
      )}

      {/* Campaigns list */}
      {filteredCamps.map(camp => {
        const campCriterios = criterios.filter(c => c.campanha_id === camp.id);
        const soma = somaP(camp.id);
        const isSelected = selectedCampId === camp.id;

        return (
          <Card key={camp.id} className="bg-card/80 backdrop-blur-sm rounded-2xl shadow-sm border">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm flex items-center gap-2 cursor-pointer" onClick={() => setSelectedCampId(isSelected ? null : camp.id)}>
                  <Trophy className="h-4 w-4 text-primary" />
                  {camp.nome}
                </CardTitle>
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="text-[10px] rounded-lg">{camp.area}</Badge>
                  <Badge variant="outline" className="text-[10px] rounded-lg">{camp.tipo}</Badge>
                  <Badge variant="outline" className={`text-[10px] rounded-lg ${camp.status === 'ATIVA' ? 'bg-emerald-50 text-emerald-700' : 'bg-muted text-muted-foreground'}`}>
                    {camp.status} v{camp.versao}
                  </Badge>
                  {camp.status === 'ATIVA' && (
                    <Button size="sm" variant="ghost" onClick={() => setShowRanking(showRanking === camp.id ? null : camp.id)} className="rounded-xl text-xs gap-1">
                      <BarChart3 className="h-3.5 w-3.5" /> Ranking
                    </Button>
                  )}
                </div>
              </div>
              {soma !== 100 && <p className="text-[10px] text-destructive mt-1">⚠ Soma dos pesos: {soma}% (precisa ser 100%)</p>}
            </CardHeader>

            {/* Criteria management */}
            {isSelected && (
              <CardContent className="space-y-3 border-t pt-3">
                <p className="text-xs font-semibold text-muted-foreground uppercase">Critérios (Soma: {soma}%)</p>
                {campCriterios.map(crit => (
                  <div key={crit.id} className="flex items-center gap-3 bg-muted/50 rounded-xl p-3">
                    <div className="flex-1">
                      <p className="text-sm font-medium">{crit.nome}</p>
                      <p className="text-xs text-muted-foreground">Meta: {crit.meta_objetiva}</p>
                      <p className="text-[10px] text-muted-foreground/60">Origem: {crit.origem_dado || 'MANUAL'}</p>
                    </div>
                    <Badge variant="outline" className="text-xs">{crit.peso_percentual}%</Badge>
                    {camp.status !== 'ENCERRADA' && (
                      <Button size="sm" variant="ghost" onClick={() => removerCriterio(crit.id)} className="h-7 w-7 p-0">
                        <Trash2 className="h-3.5 w-3.5 text-destructive/60" />
                      </Button>
                    )}
                  </div>
                ))}

                {camp.status !== 'ENCERRADA' && (
                  <div className="bg-muted/50 rounded-xl p-3 space-y-2">
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <Label className="text-[10px]">Nome</Label>
                        <Input value={newCrit.nome} onChange={e => setNewCrit(p => ({ ...p, nome: e.target.value }))} className="rounded-xl text-xs h-8" placeholder="Ex: Ligações ≥ 20/dia" />
                      </div>
                      <div>
                        <Label className="text-[10px]">Meta Objetiva</Label>
                        <Input value={newCrit.meta_objetiva} onChange={e => setNewCrit(p => ({ ...p, meta_objetiva: e.target.value }))} className="rounded-xl text-xs h-8" placeholder="≥20 lig/dia" />
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <Label className="text-[10px]">Descrição</Label>
                        <Input value={newCrit.descricao} onChange={e => setNewCrit(p => ({ ...p, descricao: e.target.value }))} className="rounded-xl text-xs h-8" />
                      </div>
                      <div>
                        <Label className="text-[10px]">Peso %</Label>
                        <Input type="number" value={newCrit.peso_percentual} onChange={e => setNewCrit(p => ({ ...p, peso_percentual: Number(e.target.value) }))} className="rounded-xl text-xs h-8" />
                      </div>
                    </div>
                    <Button size="sm" onClick={handleAddCriterio} className="rounded-xl text-xs gap-1">
                      <Plus className="h-3 w-3" /> Adicionar Critério
                    </Button>
                  </div>
                )}
              </CardContent>
            )}

            {/* Ranking + manual marking */}
            {showRanking === camp.id && (
              <CardContent className="space-y-2 border-t pt-3">
                <p className="text-xs font-semibold text-muted-foreground uppercase flex items-center gap-1">
                  <Users className="h-3.5 w-3.5" /> Acompanhamento — {camp.nome}
                </p>
                
                {/* Table header */}
                <div className="grid grid-cols-[1fr_80px_100px_80px] gap-2 text-[10px] text-muted-foreground uppercase font-semibold px-3">
                  <span>Usuário</span>
                  <span className="text-center">Progresso</span>
                  <span className="text-center">Status</span>
                  <span className="text-center">Critérios</span>
                </div>

                {sellers.map(s => {
                  const prog = getProgressoVendedor(camp.id, s.id);
                  const status = getStatusVendedor(camp.id, s.id);
                  const campCrits = criterios.filter(c => c.campanha_id === camp.id);
                  
                  return (
                    <div key={s.id} className="bg-muted/50 rounded-xl p-3 space-y-2">
                      {/* Summary row */}
                      <div className="grid grid-cols-[1fr_80px_100px_80px] gap-2 items-center">
                        <div>
                          <p className="text-sm font-medium">{s.name}</p>
                          <p className="text-[10px] text-muted-foreground">{s.role} · {s.department || '—'}</p>
                        </div>
                        <div className="text-center">
                          <span className="text-sm font-bold">{prog.percentual}%</span>
                        </div>
                        <div className="text-center">
                          <Badge variant="outline" className={`text-[10px] rounded-lg ${
                            status === 'CONQUISTADO' ? 'bg-emerald-50 text-emerald-700' :
                            status === 'NAO_ATINGIDO' ? 'bg-red-50 text-red-700' :
                            'bg-blue-50 text-blue-700'
                          }`}>
                            {status === 'CONQUISTADO' ? '✅ Conquistado' : status === 'NAO_ATINGIDO' ? '❌ Não atingido' : '🔄 Em andamento'}
                          </Badge>
                        </div>
                        <div className="text-center text-xs">
                          {prog.atingidos}/{prog.total}
                        </div>
                      </div>
                      
                      {/* Progress bar */}
                      <Progress value={prog.percentual} className="h-1.5 rounded-full" />
                      
                      {/* Manual marking per criterion */}
                      {campCrits.map(crit => {
                        const marcacao = getMarcacao(camp.id, crit.id, s.id);
                        return (
                          <div key={crit.id} className="flex items-center justify-between text-xs pl-2">
                            <span className="text-muted-foreground">{crit.nome} ({crit.peso_percentual}%)</span>
                            <div className="flex items-center gap-1">
                              <Button
                                size="sm"
                                variant={marcacao === true ? 'default' : 'ghost'}
                                className="h-6 w-6 p-0 rounded-lg"
                                onClick={() => marcarCriterio(camp.id, crit.id, s.id, true)}
                              >
                                <CheckCircle className="h-3.5 w-3.5 text-emerald-500" />
                              </Button>
                              <Button
                                size="sm"
                                variant={marcacao === false ? 'default' : 'ghost'}
                                className="h-6 w-6 p-0 rounded-lg"
                                onClick={() => marcarCriterio(camp.id, crit.id, s.id, false)}
                              >
                                <XCircle className="h-3.5 w-3.5 text-destructive/60" />
                              </Button>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  );
                })}
              </CardContent>
            )}
          </Card>
        );
      })}

      {/* Create Config Dialog */}
      <Dialog open={showCreateConfig} onOpenChange={setShowCreateConfig}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Configuração do Mês</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div>
              <Label>Foco Geral</Label>
              <Input value={focoGeral} onChange={e => setFocoGeral(e.target.value)} placeholder="Ex: Aumentar reativações" className="rounded-xl" />
            </div>
            <div>
              <Label>Descrição</Label>
              <Textarea value={descFoco} onChange={e => setDescFoco(e.target.value)} placeholder="Detalhes..." className="rounded-xl" rows={3} />
            </div>
            <Button onClick={handleCreateConfig} className="w-full rounded-xl">Criar</Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Create Campaign Dialog */}
      <Dialog open={showCreateCamp} onOpenChange={setShowCreateCamp}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Nova Campanha</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div>
              <Label>Nome</Label>
              <Input value={newCamp.nome} onChange={e => setNewCamp(p => ({ ...p, nome: e.target.value }))} placeholder="Ex: Meta de Ligações" className="rounded-xl" />
            </div>
            <div>
              <Label>Descrição</Label>
              <Textarea value={newCamp.descricao} onChange={e => setNewCamp(p => ({ ...p, descricao: e.target.value }))} className="rounded-xl" rows={2} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Área</Label>
                <Select value={newCamp.area} onValueChange={v => setNewCamp(p => ({ ...p, area: v }))}>
                  <SelectTrigger className="rounded-xl"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {AREAS.map(a => <SelectItem key={a} value={a}>{a}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Tipo</Label>
                <Select value={newCamp.tipo} onValueChange={v => setNewCamp(p => ({ ...p, tipo: v }))}>
                  <SelectTrigger className="rounded-xl"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="INDIVIDUAL">Individual</SelectItem>
                    <SelectItem value="SISTEMICA">Sistêmica</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Validação</Label>
                <Select value={newCamp.modo_validacao} onValueChange={v => setNewCamp(p => ({ ...p, modo_validacao: v }))}>
                  <SelectTrigger className="rounded-xl"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="RIGIDO_100">100% Rígido</SelectItem>
                    <SelectItem value="PERCENTUAL_MINIMO">% Mínimo</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              {newCamp.modo_validacao === 'PERCENTUAL_MINIMO' && (
                <div>
                  <Label>% Mínimo</Label>
                  <Input type="number" value={newCamp.percentual_minimo} onChange={e => setNewCamp(p => ({ ...p, percentual_minimo: Number(e.target.value) }))} className="rounded-xl" />
                </div>
              )}
            </div>
            <Button onClick={handleCreateCamp} className="w-full rounded-xl">Criar Campanha</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}