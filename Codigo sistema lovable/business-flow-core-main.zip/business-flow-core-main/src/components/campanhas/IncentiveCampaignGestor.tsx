import { useState, useEffect } from 'react';
import { useIncentiveCampaigns, MODEL_TYPES, METRIC_KEYS, PRIZE_TYPES, IncentiveCampaign } from '@/hooks/useIncentiveCampaigns';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Trophy, Plus, Play, Pause, Archive, Users, Target, CheckCircle, XCircle, Loader2, Trash2 } from 'lucide-react';
import { format, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { toast } from 'sonner';

const STATUS_COLORS: Record<string, string> = {
  DRAFT: 'bg-gray-100 text-gray-700',
  ACTIVE: 'bg-emerald-100 text-emerald-700',
  CLOSED: 'bg-amber-100 text-amber-700',
  ARCHIVED: 'bg-red-100 text-red-700',
};

function generateRulebook(camp: Partial<IncentiveCampaign>, criteriaList: any[]): string {
  const modelLabel = MODEL_TYPES.find(m => m.key === camp.model_type)?.label || camp.model_type;
  const prizeLabel = PRIZE_TYPES.find(p => p.key === camp.prize_type)?.label || camp.prize_type;
  const criteriaText = criteriaList.map((c, i) => {
    const mk = METRIC_KEYS.find(m => m.key === c.metric_key)?.label || c.metric_key;
    return `  ${i + 1}. ${mk} ${c.operator} ${c.target_value} (peso: ${c.weight}%)`;
  }).join('\n');

  return `REGULAMENTO INTERNO — ${camp.title || 'Campanha'}

1. OBJETIVO
Campanha do tipo "${modelLabel}" visando incentivar desempenho por mérito.

2. PERÍODO DE VIGÊNCIA
De ${camp.start_date || '___'} a ${camp.end_date || '___'}.

3. PARTICIPANTES
Público: ${(camp.audience_roles || ['VENDEDOR']).join(', ')}.
Aceite digital obrigatório para participação.

4. CRITÉRIOS DE APURAÇÃO
${criteriaText || '  (a definir)'}

5. PREMIAÇÃO
Tipo: ${prizeLabel}
${camp.prize_description || `Valor: R$ ${camp.prize_value || 0}`}

6. ELEGIBILIDADE
- Ter aceitado o Regulamento do Sistema vigente
- Ter aceitado esta Campanha
- Estar com status ativo durante o período

7. DESEMPATE
Em caso de empate, prevalece quem atingiu primeiro.

8. DISPOSIÇÕES GERAIS
- Esta campanha é uma iniciativa interna de incentivo ao desempenho, de caráter eventual e não habitual.
- Não configura obrigação trabalhista permanente.
- A empresa reserva-se o direito de cancelar ou alterar por motivo operacional justificado.
- Premiação sujeita a aprovação do gestor.

${camp.notes || ''}`;
}

export function IncentiveCampaignGestor() {
  const { seller } = useAuth();
  const {
    campaigns, isLoading, createCampaign, updateCampaign,
    addCriteria, removeCriteria, getCriteria, getParticipants,
    inviteParticipants, getPrizes, updatePrizeStatus, invalidateAll,
  } = useIncentiveCampaigns();

  const [sellers, setSellers] = useState<any[]>([]);
  const [createOpen, setCreateOpen] = useState(false);
  const [detailCampaign, setDetailCampaign] = useState<IncentiveCampaign | null>(null);
  const [tab, setTab] = useState('active');

  // Wizard state
  const [step, setStep] = useState(1);
  const [form, setForm] = useState({
    title: '', model_type: 'MARGEM', start_date: '', end_date: '',
    audience_roles: ['VENDEDOR'], prize_type: 'MONEY' as string, prize_value: 0,
    prize_description: '', notes: '', description: '',
  });
  const [wizardCriteria, setWizardCriteria] = useState<any[]>([]);
  const [newCrit, setNewCrit] = useState({ metric_key: 'MARGEM_MEDIA', operator: '>=', target_value: 0, weight: 100 });
  const [generatedRulebook, setGeneratedRulebook] = useState('');
  const [creating, setCreating] = useState(false);

  useEffect(() => {
    const fetchSellers = async () => {
      const { data } = await supabase.from('sellers').select('id, name, role').or('status.eq.ATIVO,status.is.null');
      setSellers(data || []);
    };
    fetchSellers();
  }, []);

  const resetWizard = () => {
    setStep(1);
    setForm({ title: '', model_type: 'MARGEM', start_date: '', end_date: '', audience_roles: ['VENDEDOR'], prize_type: 'MONEY', prize_value: 0, prize_description: '', notes: '', description: '' });
    setWizardCriteria([]);
    setGeneratedRulebook('');
  };

  // Pre-fill criteria based on model
  const handleModelSelect = (model: string) => {
    setForm(f => ({ ...f, model_type: model }));
    const presets: Record<string, any[]> = {
      MARGEM: [{ metric_key: 'MARGEM_MEDIA', operator: '>=', target_value: 30, weight: 100 }],
      CLIENTE_NOVO: [{ metric_key: 'NOVOS_CLIENTES', operator: '>=', target_value: 5, weight: 100 }],
      TICKET_MEDIO: [{ metric_key: 'TICKET_MEDIO', operator: '>=', target_value: 500, weight: 100 }],
      RETENCAO: [{ metric_key: 'NOVOS_CLIENTES', operator: '>=', target_value: 3, weight: 100 }],
      REDUCAO_ERRO: [{ metric_key: 'ERROS', operator: '<=', target_value: 2, weight: 100 }],
      PRODUTO_FOCO: [{ metric_key: 'FATURAMENTO', operator: '>=', target_value: 10000, weight: 100 }],
      MULTI_METAS: [
        { metric_key: 'MARGEM_MEDIA', operator: '>=', target_value: 25, weight: 40 },
        { metric_key: 'NOVOS_CLIENTES', operator: '>=', target_value: 3, weight: 30 },
        { metric_key: 'ERROS', operator: '<=', target_value: 2, weight: 30 },
      ],
    };
    setWizardCriteria(presets[model] || []);
    setStep(2);
  };

  const handleCreateCampaign = async () => {
    if (!form.title || !form.start_date || !form.end_date) {
      toast.error('Preencha título, data de início e fim');
      return;
    }
    setCreating(true);
    const rb = generatedRulebook || generateRulebook(form, wizardCriteria);
    const camp = await createCampaign({
      ...form,
      rulebook_text: rb,
      requires_acceptance: true,
      visibility: 'PUBLIC',
      approval_required_for_prize: true,
    });
    if (camp) {
      // Add criteria
      for (const c of wizardCriteria) {
        await addCriteria({ campaign_id: camp.id, ...c, scope: 'PERIOD_TOTAL', role_scope: 'BOTH' });
      }
      // Invite participants based on audience
      const eligible = sellers.filter(s => form.audience_roles.includes(s.role?.toUpperCase() || 'VENDEDOR'));
      if (eligible.length > 0) {
        await inviteParticipants(camp.id, eligible.map(s => s.id));
      }
      toast.success('Campanha criada com sucesso!');
      setCreateOpen(false);
      resetWizard();
    }
    setCreating(false);
  };

  const handlePublish = async (campId: string) => {
    await updateCampaign(campId, { status: 'ACTIVE' });
    toast.success('Campanha publicada e participantes notificados!');
  };

  const handleClose = async (campId: string) => {
    await updateCampaign(campId, { status: 'CLOSED' });
    toast.success('Campanha encerrada!');
  };

  const handleArchive = async (campId: string) => {
    await updateCampaign(campId, { status: 'ARCHIVED' });
    toast.success('Campanha arquivada!');
  };

  const filtered = campaigns.filter(c => {
    if (tab === 'active') return c.status === 'ACTIVE' || c.status === 'DRAFT';
    if (tab === 'closed') return c.status === 'CLOSED';
    if (tab === 'archived') return c.status === 'ARCHIVED';
    return true;
  });

  if (isLoading) return <div className="py-8 text-center text-muted-foreground animate-pulse">Carregando campanhas...</div>;

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h3 className="text-base font-bold text-foreground flex items-center gap-2">
          <Trophy className="h-4 w-4 text-[#FF6A00]" /> Campanhas de Incentivo
        </h3>
        <Dialog open={createOpen} onOpenChange={(v) => { setCreateOpen(v); if (!v) resetWizard(); }}>
          <DialogTrigger asChild>
            <Button size="sm" className="rounded-xl gap-1.5">
              <Plus className="h-3.5 w-3.5" /> Criar com Modelo
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Criar Campanha — Passo {step}/5</DialogTitle>
            </DialogHeader>

            {/* STEP 1: Choose model */}
            {step === 1 && (
              <div className="grid grid-cols-2 gap-3">
                {MODEL_TYPES.map(m => (
                  <button
                    key={m.key}
                    onClick={() => handleModelSelect(m.key)}
                    className="p-4 rounded-xl border border-border hover:border-[#FF6A00] hover:bg-[#FF6A00]/5 transition-all text-left"
                  >
                    <span className="text-2xl">{m.icon}</span>
                    <p className="font-semibold text-sm mt-2">{m.label}</p>
                    <p className="text-xs text-muted-foreground">{m.desc}</p>
                  </button>
                ))}
              </div>
            )}

            {/* STEP 2: Period + Title */}
            {step === 2 && (
              <div className="space-y-4">
                <div>
                  <Label>Título da Campanha</Label>
                  <Input value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} placeholder="Ex: Campanha Margem Março" className="rounded-xl" />
                </div>
                <div>
                  <Label>Descrição (opcional)</Label>
                  <Textarea value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} rows={2} className="rounded-xl" />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label>Início</Label>
                    <Input type="date" value={form.start_date} onChange={e => setForm(f => ({ ...f, start_date: e.target.value }))} className="rounded-xl" />
                  </div>
                  <div>
                    <Label>Fim</Label>
                    <Input type="date" value={form.end_date} onChange={e => setForm(f => ({ ...f, end_date: e.target.value }))} className="rounded-xl" />
                  </div>
                </div>
                <div className="flex justify-between pt-2">
                  <Button variant="outline" onClick={() => setStep(1)} className="rounded-xl">Voltar</Button>
                  <Button onClick={() => setStep(3)} disabled={!form.title || !form.start_date || !form.end_date} className="rounded-xl">Próximo</Button>
                </div>
              </div>
            )}

            {/* STEP 3: Criteria */}
            {step === 3 && (
              <div className="space-y-4">
                <p className="text-sm text-muted-foreground">Critérios pré-preenchidos pelo modelo. Ajuste conforme necessário.</p>
                {wizardCriteria.map((c, i) => (
                  <div key={i} className="flex items-center gap-2 p-3 rounded-xl bg-muted/50">
                    <span className="text-xs font-medium flex-1">{METRIC_KEYS.find(m => m.key === c.metric_key)?.label}</span>
                    <Select value={c.operator} onValueChange={v => { const arr = [...wizardCriteria]; arr[i].operator = v; setWizardCriteria(arr); }}>
                      <SelectTrigger className="w-20 rounded-xl h-8 text-xs"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value=">=">&gt;=</SelectItem>
                        <SelectItem value="<=">&lt;=</SelectItem>
                        <SelectItem value="=">=</SelectItem>
                      </SelectContent>
                    </Select>
                    <Input type="number" value={c.target_value} onChange={e => { const arr = [...wizardCriteria]; arr[i].target_value = Number(e.target.value); setWizardCriteria(arr); }} className="w-24 rounded-xl h-8 text-xs" />
                    <span className="text-xs text-muted-foreground">peso:</span>
                    <Input type="number" value={c.weight} onChange={e => { const arr = [...wizardCriteria]; arr[i].weight = Number(e.target.value); setWizardCriteria(arr); }} className="w-16 rounded-xl h-8 text-xs" />
                    <span className="text-xs">%</span>
                    <Button variant="ghost" size="icon" onClick={() => setWizardCriteria(wizardCriteria.filter((_, j) => j !== i))} className="h-6 w-6">
                      <Trash2 className="h-3 w-3 text-red-500" />
                    </Button>
                  </div>
                ))}
                {/* Add new criteria */}
                <div className="flex items-end gap-2">
                  <div className="flex-1">
                    <Label className="text-xs">Métrica</Label>
                    <Select value={newCrit.metric_key} onValueChange={v => setNewCrit(c => ({ ...c, metric_key: v }))}>
                      <SelectTrigger className="rounded-xl h-8 text-xs"><SelectValue /></SelectTrigger>
                      <SelectContent>{METRIC_KEYS.map(m => <SelectItem key={m.key} value={m.key}>{m.label}</SelectItem>)}</SelectContent>
                    </Select>
                  </div>
                  <Input type="number" value={newCrit.target_value} onChange={e => setNewCrit(c => ({ ...c, target_value: Number(e.target.value) }))} className="w-20 rounded-xl h-8 text-xs" placeholder="Valor" />
                  <Button size="sm" variant="outline" className="rounded-xl h-8 text-xs" onClick={() => { setWizardCriteria([...wizardCriteria, { ...newCrit }]); }}>
                    <Plus className="h-3 w-3" /> Add
                  </Button>
                </div>
                <div className="flex justify-between pt-2">
                  <Button variant="outline" onClick={() => setStep(2)} className="rounded-xl">Voltar</Button>
                  <Button onClick={() => setStep(4)} disabled={wizardCriteria.length === 0} className="rounded-xl">Próximo</Button>
                </div>
              </div>
            )}

            {/* STEP 4: Prize */}
            {step === 4 && (
              <div className="space-y-4">
                <div>
                  <Label>Tipo de Premiação</Label>
                  <Select value={form.prize_type} onValueChange={v => setForm(f => ({ ...f, prize_type: v }))}>
                    <SelectTrigger className="rounded-xl"><SelectValue /></SelectTrigger>
                    <SelectContent>{PRIZE_TYPES.map(p => <SelectItem key={p.key} value={p.key}>{p.label}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label>Valor</Label>
                    <Input type="number" value={form.prize_value} onChange={e => setForm(f => ({ ...f, prize_value: Number(e.target.value) }))} className="rounded-xl" />
                  </div>
                  <div>
                    <Label>Descrição do prêmio</Label>
                    <Input value={form.prize_description} onChange={e => setForm(f => ({ ...f, prize_description: e.target.value }))} className="rounded-xl" placeholder="Ex: Top 3 recebem" />
                  </div>
                </div>
                <div>
                  <Label>Público-alvo</Label>
                  <div className="flex gap-2 mt-1">
                    {['VENDEDOR', 'ADMIN'].map(r => (
                      <Button
                        key={r}
                        variant={form.audience_roles.includes(r) ? 'default' : 'outline'}
                        size="sm"
                        className="rounded-xl text-xs"
                        onClick={() => {
                          setForm(f => ({
                            ...f,
                            audience_roles: f.audience_roles.includes(r)
                              ? f.audience_roles.filter(x => x !== r)
                              : [...f.audience_roles, r]
                          }));
                        }}
                      >
                        {r === 'VENDEDOR' ? 'Vendedores' : 'Administrativo'}
                      </Button>
                    ))}
                  </div>
                </div>
                <div className="flex justify-between pt-2">
                  <Button variant="outline" onClick={() => setStep(3)} className="rounded-xl">Voltar</Button>
                  <Button onClick={() => { setGeneratedRulebook(generateRulebook(form, wizardCriteria)); setStep(5); }} className="rounded-xl">Próximo</Button>
                </div>
              </div>
            )}

            {/* STEP 5: Rulebook + Confirm */}
            {step === 5 && (
              <div className="space-y-4">
                <Label>Regulamento (gerado automaticamente — edite se necessário)</Label>
                <Textarea
                  value={generatedRulebook}
                  onChange={e => setGeneratedRulebook(e.target.value)}
                  rows={14}
                  className="rounded-xl text-xs font-mono"
                />
                <div>
                  <Label>Observações adicionais</Label>
                  <Textarea value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} rows={2} className="rounded-xl" />
                </div>
                <div className="flex justify-between pt-2">
                  <Button variant="outline" onClick={() => setStep(4)} className="rounded-xl">Voltar</Button>
                  <Button onClick={handleCreateCampaign} disabled={creating} className="rounded-xl gap-2">
                    {creating ? <Loader2 className="h-4 w-4 animate-spin" /> : <CheckCircle className="h-4 w-4" />}
                    Criar Campanha (Rascunho)
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>

      {/* Tabs */}
      <Tabs value={tab} onValueChange={setTab}>
        <TabsList className="rounded-xl">
          <TabsTrigger value="active" className="rounded-lg text-xs">Ativas / Rascunho</TabsTrigger>
          <TabsTrigger value="closed" className="rounded-lg text-xs">Encerradas</TabsTrigger>
          <TabsTrigger value="archived" className="rounded-lg text-xs">Arquivadas</TabsTrigger>
        </TabsList>
      </Tabs>

      {/* Campaign List */}
      {filtered.length === 0 && (
        <Card className="bg-card/80 backdrop-blur-sm rounded-2xl shadow-sm border border-border/50">
          <CardContent className="p-8 text-center text-muted-foreground text-sm">
            Nenhuma campanha nesta categoria
          </CardContent>
        </Card>
      )}

      {filtered.map(camp => {
        const criteria = getCriteria(camp.id);
        const participants = getParticipants(camp.id);
        const prizes = getPrizes(camp.id);
        const accepted = participants.filter(p => p.status === 'ACCEPTED').length;
        const modelInfo = MODEL_TYPES.find(m => m.key === camp.model_type);

        return (
          <Card key={camp.id} className="bg-card/80 backdrop-blur-sm rounded-2xl shadow-sm border border-border/50">
            <CardContent className="p-4 space-y-3">
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-lg">{modelInfo?.icon || '🏆'}</span>
                    <h4 className="font-bold text-sm text-foreground">{camp.title}</h4>
                    <Badge className={`text-[10px] rounded-lg ${STATUS_COLORS[camp.status]}`}>{camp.status}</Badge>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    {format(parseISO(camp.start_date), 'dd/MM/yyyy')} — {format(parseISO(camp.end_date), 'dd/MM/yyyy')}
                    {' · '}Modelo: {modelInfo?.label}
                    {' · '}Prêmio: {PRIZE_TYPES.find(p => p.key === camp.prize_type)?.label}
                    {camp.prize_value > 0 && ` R$ ${camp.prize_value}`}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="text-[10px] rounded-lg">
                    <Users className="h-3 w-3 mr-1" />
                    {accepted}/{participants.length} aceites
                  </Badge>
                </div>
              </div>

              {/* Criteria summary */}
              <div className="flex flex-wrap gap-1.5">
                {criteria.map(c => (
                  <Badge key={c.id} variant="outline" className="text-[10px] rounded-lg">
                    {METRIC_KEYS.find(m => m.key === c.metric_key)?.label} {c.operator} {c.target_value} ({c.weight}%)
                  </Badge>
                ))}
              </div>

              {/* Actions */}
              <div className="flex gap-2 pt-1">
                {camp.status === 'DRAFT' && (
                  <Button size="sm" onClick={() => handlePublish(camp.id)} className="rounded-xl text-xs gap-1.5">
                    <Play className="h-3 w-3" /> Publicar
                  </Button>
                )}
                {camp.status === 'ACTIVE' && (
                  <Button size="sm" variant="outline" onClick={() => handleClose(camp.id)} className="rounded-xl text-xs gap-1.5">
                    <Pause className="h-3 w-3" /> Encerrar
                  </Button>
                )}
                {camp.status === 'CLOSED' && (
                  <Button size="sm" variant="outline" onClick={() => handleArchive(camp.id)} className="rounded-xl text-xs gap-1.5">
                    <Archive className="h-3 w-3" /> Arquivar
                  </Button>
                )}
                <Button size="sm" variant="ghost" onClick={() => setDetailCampaign(camp)} className="rounded-xl text-xs">
                  Detalhes
                </Button>
              </div>

              {/* Prizes section for closed campaigns */}
              {camp.status === 'CLOSED' && prizes.length > 0 && (
                <div className="border-t pt-2 mt-2">
                  <p className="text-xs font-semibold text-muted-foreground mb-1.5">Prêmios</p>
                  {prizes.map(p => {
                    const sellerName = sellers.find(s => s.id === p.user_id)?.name || 'Colaborador';
                    return (
                      <div key={p.id} className="flex items-center gap-2 py-1">
                        <span className="text-xs flex-1">{sellerName}</span>
                        <Badge className={`text-[10px] rounded-lg ${p.status === 'PAID' || p.status === 'DELIVERED' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'}`}>
                          {p.status}
                        </Badge>
                        {(p.status === 'PENDING' || p.status === 'APPROVED') && (
                          <Button size="sm" variant="outline" className="text-[10px] rounded-lg h-6 px-2" onClick={() => updatePrizeStatus(p.id, camp.prize_type === 'MONEY' ? 'PAID' : 'DELIVERED')}>
                            Marcar {camp.prize_type === 'MONEY' ? 'Pago' : 'Entregue'}
                          </Button>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>
        );
      })}

      {/* Detail modal */}
      {detailCampaign && (
        <Dialog open={!!detailCampaign} onOpenChange={() => setDetailCampaign(null)}>
          <DialogContent className="max-w-lg max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{detailCampaign.title}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <p className="text-xs font-semibold text-muted-foreground mb-1">Regulamento</p>
                <pre className="text-xs whitespace-pre-wrap bg-muted/50 p-3 rounded-xl max-h-60 overflow-y-auto">{detailCampaign.rulebook_text}</pre>
              </div>
              <div>
                <p className="text-xs font-semibold text-muted-foreground mb-1">Participantes</p>
                <div className="space-y-1">
                  {getParticipants(detailCampaign.id).map(p => {
                    const s = sellers.find(sel => sel.id === p.user_id);
                    return (
                      <div key={p.id} className="flex items-center gap-2 text-xs">
                        {p.status === 'ACCEPTED' ? <CheckCircle className="h-3 w-3 text-emerald-500" /> : <XCircle className="h-3 w-3 text-amber-500" />}
                        <span>{s?.name || 'Desconhecido'}</span>
                        <Badge variant="outline" className="text-[9px] rounded-lg">{p.status}</Badge>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
