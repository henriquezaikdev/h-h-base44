import { useState, useMemo, useCallback } from 'react';
import { 
  ShoppingCart, RotateCcw, Package, Eye, CreditCard, 
  HelpCircle, MoreHorizontal, Phone, MessageCircle,
  ChevronDown, ChevronRight, Loader2, Calendar, TrendingUp
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle
} from '@/components/ui/sheet';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger
} from '@/components/ui/collapsible';
import { supabase } from '@/integrations/supabase/client';
import { useQuery } from '@tanstack/react-query';
import { format, startOfMonth, endOfMonth, startOfWeek, endOfWeek, startOfDay, endOfDay } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { useNavigate } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { CONTACT_REASON_OPTIONS, ContactReason, getReasonConfig } from '@/lib/contactReasons';

type PeriodType = 'today' | 'week' | 'month';

interface ContactReasonsWidgetProps {
  sellerId: string;
}

interface ReasonBreakdown {
  reason: ContactReason;
  count: number;
  clients: Array<{
    clientId: string;
    clientName: string;
    count: number;
    lastDate: string;
    channel: 'ligacao' | 'whatsapp' | 'outro';
  }>;
}

// Helper to get São Paulo timezone date range
function getSaoPauloDateRange(period: PeriodType) {
  const now = new Date();
  const spFormatter = new Intl.DateTimeFormat('sv-SE', {
    timeZone: 'America/Sao_Paulo',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  });
  
  const todaySP = spFormatter.format(now);
  const [year, month, day] = todaySP.split('-').map(Number);
  const spDate = new Date(year, month - 1, day);
  
  switch (period) {
    case 'today':
      return { start: todaySP, end: todaySP };
    case 'week': {
      const weekStart = startOfWeek(spDate, { weekStartsOn: 1 }); // Monday
      const weekEnd = endOfWeek(spDate, { weekStartsOn: 1 });
      return { 
        start: format(weekStart, 'yyyy-MM-dd'), 
        end: format(weekEnd, 'yyyy-MM-dd') 
      };
    }
    case 'month': {
      const monthStart = startOfMonth(spDate);
      const monthEnd = endOfMonth(spDate);
      return { 
        start: format(monthStart, 'yyyy-MM-dd'), 
        end: format(monthEnd, 'yyyy-MM-dd') 
      };
    }
  }
}

export function ContactReasonsWidget({ sellerId }: ContactReasonsWidgetProps) {
  const navigate = useNavigate();
  const [period, setPeriod] = useState<PeriodType>('today');
  const [selectedReason, setSelectedReason] = useState<ContactReason | null>(null);
  const [expandedClient, setExpandedClient] = useState<string | null>(null);

  const dateRange = useMemo(() => getSaoPauloDateRange(period), [period]);

  // Fetch contact reasons breakdown
  const { data: reasonsData, isLoading } = useQuery({
    queryKey: ['contact-reasons', sellerId, dateRange.start, dateRange.end],
    queryFn: async () => {
      // Fetch from interactions
      const { data: interactions, error: intError } = await supabase
        .from('interactions')
        .select(`
          id,
          client_id,
          interaction_type,
          interaction_date,
          contact_reason,
          clients!interactions_client_id_fkey(id, company_name)
        `)
        .eq('responsible_seller_id', sellerId)
        .gte('interaction_date', dateRange.start)
        .lte('interaction_date', dateRange.end)
        .or('is_deleted.is.null,is_deleted.eq.false');

      if (intError) throw intError;

      // Fetch from completed tasks
      // Regra de filtro por vendedor (robusta):
      // - Preferir carteira do cliente (client.seller_id) para refletir o vendedor selecionado
      // - Fallback: tarefas sem cliente/join usam created_by_seller_id
      const startIso = `${dateRange.start}T00:00:00-03:00`;
      const endIso = `${dateRange.end}T23:59:59.999-03:00`;

      const tasksByClientQuery = (supabase
        .from('tasks')
        .select(
          `
          id,
          client_id,
          contact_type,
          contact_reason,
          completed_at,
          contact_successful,
          client:clients!tasks_client_id_fkey!inner(id, company_name, seller_id)
        `
        ) as any)
        .eq('status', 'concluida')
        .eq('contact_successful', true)
        .gte('completed_at', startIso)
        .lte('completed_at', endIso)
        .eq('client.seller_id', sellerId);

      const tasksFallbackQuery = (supabase
        .from('tasks')
        .select(
          `
          id,
          client_id,
          contact_type,
          contact_reason,
          completed_at,
          contact_successful,
          clients!tasks_client_id_fkey(id, company_name)
        `
        ) as any)
        .eq('status', 'concluida')
        .eq('contact_successful', true)
        .gte('completed_at', startIso)
        .lte('completed_at', endIso)
        .eq('created_by_seller_id', sellerId)
        .or('is_deleted.is.null,is_deleted.eq.false');

      const [{ data: tasksByClient, error: tasksByClientError }, { data: tasksFallback, error: taskError }] =
        await Promise.all([tasksByClientQuery, tasksFallbackQuery]);

      if (tasksByClientError) throw tasksByClientError;
      if (taskError) throw taskError;

      const mergedTasksMap = new Map<string, any>();
      (tasksByClient || []).forEach((t: any) => mergedTasksMap.set(t.id, {
        ...t,
        clients: t.client, // normalizar para o shape usado abaixo
      }));
      (tasksFallback || []).forEach((t: any) => {
        if (!mergedTasksMap.has(t.id)) mergedTasksMap.set(t.id, t);
      });

      const tasks = Array.from(mergedTasksMap.values());

      // Aggregate by reason
      const reasonMap = new Map<ContactReason, Map<string, { 
        clientId: string; 
        clientName: string; 
        count: number; 
        lastDate: string;
        channel: 'ligacao' | 'whatsapp' | 'outro';
      }>>();

      // Initialize all reasons
      CONTACT_REASON_OPTIONS.forEach(opt => {
        reasonMap.set(opt.value, new Map());
      });

      // Process interactions
      (interactions || []).forEach((int: any) => {
        const reason = (int.contact_reason as ContactReason) || 'RETORNO';
        const clientId = int.client_id;
        const clientName = int.clients?.company_name || 'Cliente';
        const intType = (int.interaction_type || '').toLowerCase();
        const channel: 'ligacao' | 'whatsapp' | 'outro' = 
          intType.includes('ligação') || intType.includes('ligacao') ? 'ligacao' :
          intType.includes('whatsapp') ? 'whatsapp' : 'outro';
        
        // Skip attempts
        if (intType.includes('tentativa')) return;
        if (!intType.includes('ligação') && !intType.includes('ligacao') && !intType.includes('whatsapp')) return;

        const clientsMap = reasonMap.get(reason) || new Map();
        const existing = clientsMap.get(clientId);
        
        if (existing) {
          existing.count++;
          if (int.interaction_date > existing.lastDate) {
            existing.lastDate = int.interaction_date;
          }
        } else {
          clientsMap.set(clientId, {
            clientId,
            clientName,
            count: 1,
            lastDate: int.interaction_date,
            channel
          });
        }
        
        reasonMap.set(reason, clientsMap);
      });

      // Process tasks
      (tasks || []).forEach((task: any) => {
        const reason = (task.contact_reason as ContactReason) || 'RETORNO';
        const clientId = task.client_id;
        const clientName = task.clients?.company_name || 'Cliente';
        const channel: 'ligacao' | 'whatsapp' | 'outro' = task.contact_type === 'ligacao' ? 'ligacao' : 'whatsapp';
        const taskDate = task.completed_at?.split('T')[0] || dateRange.start;

        const clientsMap = reasonMap.get(reason) || new Map();
        const existing = clientsMap.get(clientId);
        
        if (existing) {
          existing.count++;
          if (taskDate > existing.lastDate) {
            existing.lastDate = taskDate;
          }
        } else {
          clientsMap.set(clientId, {
            clientId,
            clientName,
            count: 1,
            lastDate: taskDate,
            channel
          });
        }
        
        reasonMap.set(reason, clientsMap);
      });

      // Convert to array
      const result: ReasonBreakdown[] = [];
      reasonMap.forEach((clientsMap, reason) => {
        const clients = Array.from(clientsMap.values());
        const totalCount = clients.reduce((sum, c) => sum + c.count, 0);
        result.push({
          reason,
          count: totalCount,
          clients: clients.sort((a, b) => b.count - a.count)
        });
      });

      return result.sort((a, b) => b.count - a.count);
    },
    enabled: !!sellerId,
    staleTime: 1000 * 60 * 5, // 5 minutos
    refetchOnWindowFocus: false,
    refetchOnMount: false,
    // Removido refetchInterval para evitar perda de dados em edição
  });

  const totalContacts = useMemo(() => {
    return (reasonsData || []).reduce((sum, r) => sum + r.count, 0);
  }, [reasonsData]);

  const selectedReasonData = useMemo(() => {
    if (!selectedReason || !reasonsData) return null;
    return reasonsData.find(r => r.reason === selectedReason);
  }, [selectedReason, reasonsData]);

  const handleReasonClick = (reason: ContactReason) => {
    setSelectedReason(reason);
    setExpandedClient(null);
  };

  const handleOpenClient = (clientId: string) => {
    setSelectedReason(null);
    navigate(`/clientes/${clientId}`);
  };

  const getPeriodLabel = () => {
    switch (period) {
      case 'today': return 'Hoje';
      case 'week': return 'Esta Semana';
      case 'month': return 'Este Mês';
    }
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="py-8 flex items-center justify-center">
          <Loader2 className="h-6 w-6 animate-spin text-primary" />
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Card className="overflow-hidden">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-base font-medium flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-primary" />
              Motivos dos Contatos
            </CardTitle>
            <Tabs value={period} onValueChange={(v) => setPeriod(v as PeriodType)}>
              <TabsList className="h-8">
                <TabsTrigger value="today" className="text-xs px-2 h-6">Hoje</TabsTrigger>
                <TabsTrigger value="week" className="text-xs px-2 h-6">Semana</TabsTrigger>
                <TabsTrigger value="month" className="text-xs px-2 h-6">Mês</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
          <p className="text-sm text-muted-foreground">
            {totalContacts} contatos • {getPeriodLabel()}
          </p>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2">
            {CONTACT_REASON_OPTIONS.map(opt => {
              const data = reasonsData?.find(r => r.reason === opt.value);
              const count = data?.count || 0;
              const Icon = opt.icon;
              
              return (
                <button
                  key={opt.value}
                  onClick={() => count > 0 && handleReasonClick(opt.value)}
                  disabled={count === 0}
                  className={cn(
                    "p-3 rounded-lg border text-left transition-all",
                    count > 0 ? "cursor-pointer hover:shadow-md hover:border-primary/50" : "opacity-50 cursor-not-allowed",
                    opt.bgColor
                  )}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <Icon className={cn("h-4 w-4", opt.color)} />
                    <span className={cn("text-xs font-medium", opt.color)}>{opt.label}</span>
                  </div>
                  <p className="text-2xl font-bold">{count}</p>
                  {data && data.clients.length > 0 && (
                    <p className="text-xs text-muted-foreground mt-1">
                      {data.clients.length} cliente{data.clients.length > 1 ? 's' : ''}
                    </p>
                  )}
                </button>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Drill-down Sheet */}
      <Sheet open={!!selectedReason} onOpenChange={() => setSelectedReason(null)}>
        <SheetContent side="right" className="w-full sm:max-w-md p-0 flex flex-col">
          <SheetHeader className="p-4 pb-2 border-b border-border shrink-0">
            {selectedReason && (
              <>
                <SheetTitle className="flex items-center gap-2">
                  {(() => {
                    const config = getReasonConfig(selectedReason);
                    const Icon = config.icon;
                    return <Icon className={cn("h-5 w-5", config.color)} />;
                  })()}
                  Contatos — {getReasonConfig(selectedReason).label}
                </SheetTitle>
                <p className="text-sm text-muted-foreground">
                  {getPeriodLabel()} • {selectedReasonData?.count || 0} contatos
                </p>
              </>
            )}
          </SheetHeader>
          
          <ScrollArea className="flex-1">
            <div className="p-4 space-y-2">
              {selectedReasonData?.clients.length === 0 ? (
                <p className="text-center text-muted-foreground py-8">
                  Nenhum contato encontrado
                </p>
              ) : (
                selectedReasonData?.clients.map(client => (
                  <Collapsible
                    key={client.clientId}
                    open={expandedClient === client.clientId}
                    onOpenChange={() => setExpandedClient(
                      expandedClient === client.clientId ? null : client.clientId
                    )}
                  >
                    <div className={cn(
                      "border rounded-lg transition-colors",
                      expandedClient === client.clientId 
                        ? "border-primary/50 bg-primary/5" 
                        : "border-border bg-card"
                    )}>
                      <CollapsibleTrigger asChild>
                        <button className="w-full p-3 flex items-center gap-3 text-left hover:bg-muted/50 rounded-lg">
                          {expandedClient === client.clientId ? (
                            <ChevronDown className="h-4 w-4 text-muted-foreground shrink-0" />
                          ) : (
                            <ChevronRight className="h-4 w-4 text-muted-foreground shrink-0" />
                          )}
                          <div className="flex-1 min-w-0">
                            <p className="font-medium truncate">{client.clientName}</p>
                            <div className="flex items-center gap-2 mt-1 text-xs text-muted-foreground">
                              <Calendar className="h-3 w-3" />
                              <span>Último: {format(new Date(client.lastDate), 'dd/MM')}</span>
                            </div>
                          </div>
                          <div className="flex items-center gap-2 shrink-0">
                            {client.channel === 'ligacao' ? (
                              <Phone className="h-4 w-4 text-blue-500" />
                            ) : (
                              <MessageCircle className="h-4 w-4 text-green-500" />
                            )}
                            <Badge variant="secondary">{client.count}</Badge>
                          </div>
                        </button>
                      </CollapsibleTrigger>
                      <CollapsibleContent>
                        <div className="px-3 pb-3 border-t border-border/50">
                          <Button
                            variant="outline"
                            size="sm"
                            className="w-full mt-3"
                            onClick={() => handleOpenClient(client.clientId)}
                          >
                            Abrir cadastro do cliente
                          </Button>
                        </div>
                      </CollapsibleContent>
                    </div>
                  </Collapsible>
                ))
              )}
            </div>
          </ScrollArea>
        </SheetContent>
      </Sheet>
    </>
  );
}
