import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { FinTaskItem } from '@/hooks/useFinanceiroGestoraData';
import { format, parseISO, isPast, isToday } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Users, UserCheck, Calendar } from 'lucide-react';

interface DelegationSectionProps {
  title: string;
  subtitle: string;
  tasks: FinTaskItem[];
  showField: 'creator' | 'assignee';
  onTaskClick?: (taskId: string) => void;
}

export function DelegationSection({ title, subtitle, tasks, showField, onTaskClick }: DelegationSectionProps) {
  if (tasks.length === 0) {
    return (
      <Card className="border-border/50">
        <CardHeader className="pb-2">
          <CardTitle className="text-base flex items-center gap-2">
            {showField === 'creator' ? <Users className="h-5 w-5 text-purple-500" /> : <UserCheck className="h-5 w-5 text-blue-500" />}
            {title}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-xs text-muted-foreground text-center py-4">Nenhuma tarefa delegada no momento.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-border/50">
      <CardHeader className="pb-2">
        <CardTitle className="text-base flex items-center gap-2">
          {showField === 'creator' ? <Users className="h-5 w-5 text-purple-500" /> : <UserCheck className="h-5 w-5 text-blue-500" />}
          {title}
          <Badge variant="secondary" className="ml-auto">{tasks.length}</Badge>
        </CardTitle>
        <p className="text-xs text-muted-foreground">{subtitle}</p>
      </CardHeader>
      <CardContent className="space-y-2 max-h-[400px] overflow-y-auto">
        {tasks.map(task => {
          const isOverdue = isPast(parseISO(task.task_date)) && !isToday(parseISO(task.task_date));
          const personLabel = showField === 'creator'
            ? `De: ${task.creator_name || 'Desconhecido'}`
            : `Para: ${task.assignee_name || 'Desconhecido'}`;

          return (
            <div
              key={task.id}
              className="p-3 rounded-lg border border-border/40 bg-muted/20 cursor-pointer hover:bg-muted/50 transition-colors"
              onClick={() => onTaskClick?.(task.id)}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="text-sm font-medium truncate flex-1">
                  {task.client_name || task.notes || 'Tarefa Geral'}
                </span>
                <Badge
                  variant={task.priority === 'alta' ? 'destructive' : 'secondary'}
                  className="text-[10px] px-1.5 py-0 ml-2"
                >
                  {task.priority}
                </Badge>
              </div>
              {task.client_name && task.notes && (
                <p className="text-[11px] text-muted-foreground truncate">{task.notes}</p>
              )}
              <div className="flex flex-wrap items-center gap-2 mt-1.5 text-xs text-muted-foreground">
                <span className="font-medium text-foreground/70">{personLabel}</span>
                {task.task_category && (
                  <Badge variant="outline" className="text-[10px]">{task.task_category}</Badge>
                )}
                <span className="flex items-center gap-1">
                  <Calendar className="h-3 w-3" />
                  {format(parseISO(task.task_date), 'dd/MM/yyyy', { locale: ptBR })}
                </span>
                {isOverdue && (
                  <Badge variant="destructive" className="text-[10px] px-1 py-0">Atrasada</Badge>
                )}
              </div>
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
}
