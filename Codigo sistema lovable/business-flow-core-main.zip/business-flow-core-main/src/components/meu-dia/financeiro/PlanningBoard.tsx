import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { FinTaskItem } from '@/hooks/useFinanceiroGestoraData';
import { format, parseISO, isPast, isToday } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import {
  ArrowRight,
  Inbox,
} from 'lucide-react';

interface PlanningBoardProps {
  tasksByBucket: {
    HOJE: FinTaskItem[];
    AMANHA: FinTaskItem[];
    SEMANA: FinTaskItem[];
  };
  onUpdateBucket: (taskId: string, newBucket: string) => void;
  onTaskClick?: (taskId: string) => void;
}

const BUCKET_CONFIG = [
  { key: 'HOJE', label: 'Hoje', color: 'border-primary/30' },
  { key: 'AMANHA', label: 'Amanhã', color: 'border-amber-500/30' },
  { key: 'SEMANA', label: 'Esta Semana', color: 'border-blue-500/30' },
];

const CATEGORY_COLORS: Record<string, string> = {
  FINANCEIRO: 'text-emerald-600 bg-emerald-500/10 border-emerald-500/30',
  COMPRAS: 'text-blue-600 bg-blue-500/10 border-blue-500/30',
  ENTREGAS: 'text-amber-600 bg-amber-500/10 border-amber-500/30',
};

export function PlanningBoard({ tasksByBucket, onUpdateBucket, onTaskClick }: PlanningBoardProps) {
  return (
    <div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {BUCKET_CONFIG.map(bucket => {
          const items = tasksByBucket[bucket.key as keyof typeof tasksByBucket];

          return (
            <Card key={bucket.key} className={`min-h-[200px] ${bucket.color}`}>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm flex items-center justify-between">
                  {bucket.label}
                  <Badge variant="outline">{items.length}</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 max-h-[350px] overflow-y-auto">
                {items.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-8 text-muted-foreground">
                    <Inbox className="h-6 w-6 mb-2 opacity-40" />
                    <p className="text-xs">Nenhuma tarefa</p>
                  </div>
                ) : (
                  items.map(task => {
                    const catColor = CATEGORY_COLORS[task.task_category || ''];
                    const isOverdue = isPast(parseISO(task.task_date)) && !isToday(parseISO(task.task_date));

                    return (
                      <div
                        key={task.id}
                        className="p-2.5 rounded-md bg-muted/30 border border-border/30 text-xs group cursor-pointer hover:bg-muted/50 transition-colors"
                        onClick={() => onTaskClick?.(task.id)}
                      >
                        <div className="flex items-center gap-2 mb-1">
                          {task.task_category && (
                            <Badge variant="outline" className={`text-[10px] ${catColor}`}>
                              {task.task_category}
                            </Badge>
                          )}
                          <span className="font-medium truncate flex-1">{task.client_name}</span>
                          {isOverdue && <Badge variant="destructive" className="text-[10px] px-1 py-0">Atrasada</Badge>}
                        </div>
                        {task.notes && (
                          <p className="text-muted-foreground truncate">{task.notes}</p>
                        )}
                        {/* Move buttons */}
                        <div className="flex gap-1 mt-2 opacity-0 group-hover:opacity-100 transition-opacity"
                          onClick={(e) => e.stopPropagation()}
                        >
                          {BUCKET_CONFIG
                            .filter(b => b.key !== bucket.key)
                            .map(b => (
                              <Button
                                key={b.key}
                                variant="ghost"
                                size="sm"
                                className="h-6 text-[10px] px-2 gap-1"
                                onClick={() => onUpdateBucket(task.id, b.key)}
                              >
                                <ArrowRight className="h-3 w-3" />
                                {b.label}
                              </Button>
                            ))}
                        </div>
                      </div>
                    );
                  })
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
