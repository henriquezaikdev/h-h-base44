import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { RoutineItem, ADMIN_CATEGORIES } from '@/hooks/useFinanceiroGestoraData';
import { toast } from 'sonner';
import {
  RotateCcw,
  Plus,
  Trash2,
  Clock,
} from 'lucide-react';

interface RoutinesCardProps {
  routines: RoutineItem[];
  onAddRoutine: (routine: Omit<RoutineItem, 'id' | 'active' | 'last_generated_date'>) => Promise<any>;
  onRemoveRoutine: (id: string) => void;
}

const FREQ_LABELS: Record<string, string> = {
  DIARIA: 'Diária',
  SEMANAL: 'Semanal',
  MENSAL: 'Mensal',
};

const CATEGORY_LABELS: Record<string, string> = {
  FINANCEIRO: 'Financeiro',
  COMPRAS: 'Compras',
  ESTOQUE: 'Estoque',
  LOGISTICA: 'Logística',
  GESTAO: 'Gestão',
  ADMINISTRATIVO: 'Administrativo',
};

const DAY_NAMES = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];

export function RoutinesCard({ routines, onAddRoutine, onRemoveRoutine }: RoutinesCardProps) {
  const [showForm, setShowForm] = useState(false);
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('FINANCEIRO');
  const [frequency, setFrequency] = useState('DIARIA');
  const [dayOfWeek, setDayOfWeek] = useState<number | null>(null);
  const [dayOfMonth, setDayOfMonth] = useState<number | null>(null);
  const [bucket, setBucket] = useState('HOJE');
  const [priority, setPriority] = useState('media');
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    if (!title.trim()) {
      toast.error('Informe o título da rotina.');
      return;
    }
    if (frequency === 'SEMANAL' && dayOfWeek === null) {
      toast.error('Selecione o dia da semana.');
      return;
    }
    if (frequency === 'MENSAL' && dayOfMonth === null) {
      toast.error('Selecione o dia do mês.');
      return;
    }

    setSaving(true);
    const { error } = await onAddRoutine({
      title: title.trim(),
      task_category: category,
      frequency,
      day_of_week: frequency === 'SEMANAL' ? dayOfWeek : null,
      day_of_month: frequency === 'MENSAL' ? dayOfMonth : null,
      default_bucket: bucket,
      default_priority: priority,
    });

    if (!error) {
      toast.success('Rotina criada!');
      setShowForm(false);
      resetForm();
    } else {
      toast.error('Erro ao criar rotina.');
    }
    setSaving(false);
  };

  const resetForm = () => {
    setTitle('');
    setCategory('FINANCEIRO');
    setFrequency('DIARIA');
    setDayOfWeek(null);
    setDayOfMonth(null);
    setBucket('HOJE');
    setPriority('media');
  };

  return (
    <>
      <Card className="border-border/50">
        <CardHeader className="pb-2">
          <CardTitle className="text-base flex items-center gap-2">
            <RotateCcw className="h-5 w-5 text-primary" />
            Rotinas Fixas
            <Badge variant="secondary" className="ml-auto">{routines.length}</Badge>
            <Button variant="ghost" size="sm" className="h-7 px-2 gap-1" onClick={() => setShowForm(true)}>
              <Plus className="h-3.5 w-3.5" /> Adicionar
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {routines.length === 0 ? (
            <p className="text-xs text-muted-foreground text-center py-4">
              Nenhuma rotina cadastrada. Adicione para nunca mais esquecer tarefas recorrentes.
            </p>
          ) : (
            routines.map(r => (
              <div key={r.id} className="flex items-center gap-3 p-2.5 rounded-md border border-border/30 bg-muted/20">
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{r.title}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge variant="outline" className="text-[10px]">
                      {CATEGORY_LABELS[r.task_category] || r.task_category}
                    </Badge>
                    <span className="text-[10px] text-muted-foreground flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {FREQ_LABELS[r.frequency]}
                      {r.frequency === 'SEMANAL' && r.day_of_week !== null && ` (${DAY_NAMES[r.day_of_week]})`}
                      {r.frequency === 'MENSAL' && r.day_of_month !== null && ` (dia ${r.day_of_month})`}
                    </span>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-7 w-7 p-0 text-muted-foreground hover:text-destructive"
                  onClick={() => onRemoveRoutine(r.id)}
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </Button>
              </div>
            ))
          )}
        </CardContent>
      </Card>

      {/* Add Routine Dialog */}
      <Dialog open={showForm} onOpenChange={setShowForm}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Nova Rotina</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Título *</Label>
              <Input value={title} onChange={e => setTitle(e.target.value)} placeholder="Ex: Conferir pagamentos do dia" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Categoria *</Label>
                <Select value={category} onValueChange={setCategory}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {ADMIN_CATEGORIES.map(cat => (
                      <SelectItem key={cat} value={cat}>{CATEGORY_LABELS[cat] || cat}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Frequência *</Label>
                <Select value={frequency} onValueChange={setFrequency}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="DIARIA">Diária</SelectItem>
                    <SelectItem value="SEMANAL">Semanal</SelectItem>
                    <SelectItem value="MENSAL">Mensal</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            {frequency === 'SEMANAL' && (
              <div>
                <Label>Dia da Semana *</Label>
                <Select value={dayOfWeek !== null ? String(dayOfWeek) : ''} onValueChange={v => setDayOfWeek(Number(v))}>
                  <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
                  <SelectContent>
                    {DAY_NAMES.map((d, i) => <SelectItem key={i} value={String(i)}>{d}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            )}
            {frequency === 'MENSAL' && (
              <div>
                <Label>Dia do Mês *</Label>
                <Input
                  type="number"
                  min={1}
                  max={31}
                  value={dayOfMonth || ''}
                  onChange={e => setDayOfMonth(e.target.value ? Number(e.target.value) : null)}
                />
              </div>
            )}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Bucket padrão</Label>
                <Select value={bucket} onValueChange={setBucket}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="HOJE">Hoje</SelectItem>
                    <SelectItem value="AMANHA">Amanhã</SelectItem>
                    <SelectItem value="SEMANA">Semana</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Prioridade</Label>
                <Select value={priority} onValueChange={setPriority}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="alta">Alta</SelectItem>
                    <SelectItem value="media">Média</SelectItem>
                    <SelectItem value="baixa">Baixa</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowForm(false)}>Cancelar</Button>
            <Button onClick={handleSave} disabled={saving}>
              {saving ? 'Salvando...' : 'Criar Rotina'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
