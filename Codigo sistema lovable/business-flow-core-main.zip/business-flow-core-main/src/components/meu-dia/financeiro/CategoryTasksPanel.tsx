import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { FinTaskItem, ADMIN_CATEGORIES } from '@/hooks/useFinanceiroGestoraData';
import { format, parseISO, isPast, isToday } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import {
  DollarSign,
  Package,
  Warehouse,
  Truck,
  Settings2,
  ClipboardList,
  HelpCircle,
  Calendar,
} from 'lucide-react';

interface CategoryTasksPanelProps {
  tasksByCategory: Record<string, FinTaskItem[]>;
  onTaskClick?: (taskId: string) => void;
  onNewTask?: (category?: string) => void;
}

const CATEGORY_CONFIG: { key: string; label: string; icon: any; color: string }[] = [
  { key: 'FINANCEIRO', label: 'Financeiro', icon: DollarSign, color: 'text-emerald-600 bg-emerald-500/10 border-emerald-500/30' },
  { key: 'COMPRAS', label: 'Compras', icon: Package, color: 'text-blue-600 bg-blue-500/10 border-blue-500/30' },
  { key: 'ESTOQUE', label: 'Estoque', icon: Warehouse, color: 'text-orange-600 bg-orange-500/10 border-orange-500/30' },
  { key: 'LOGISTICA', label: 'Logística', icon: Truck, color: 'text-amber-600 bg-amber-500/10 border-amber-500/30' },
  { key: 'GESTAO', label: 'Gestão', icon: Settings2, color: 'text-violet-600 bg-violet-500/10 border-violet-500/30' },
  { key: 'ADMINISTRATIVO', label: 'Administrativo', icon: ClipboardList, color: 'text-cyan-600 bg-cyan-500/10 border-cyan-500/30' },
  { key: 'SEM_CATEGORIA', label: 'Sem Categoria', icon: HelpCircle, color: 'text-muted-foreground bg-muted/30 border-border' },
];

function TaskRow({ task, onTaskClick }: { task: FinTaskItem; onTaskClick?: (id: string) => void }) {
  const isOverdue = isPast(parseISO(task.task_date)) && !isToday(parseISO(task.task_date));

  return (
    <div
      className="p-2.5 rounded-md bg-muted/20 border border-border/30 text-xs cursor-pointer hover:bg-muted/50 transition-colors"
      onClick={() => onTaskClick?.(task.id)}
    >
      <div className="flex items-center justify-between mb-1">
        <span className="font-medium truncate flex-1">{task.client_name || task.notes || 'Tarefa Geral'}</span>
        <Badge
          variant={task.priority === 'alta' ? 'destructive' : 'secondary'}
          className="text-[10px] px-1.5 py-0 ml-2"
        >
          {task.priority}
        </Badge>
      </div>
      {task.client_name && task.notes && (
        <p className="text-[11px] text-muted-foreground truncate mt-0.5">{task.notes}</p>
      )}
      {task.assignee_name && (
        <p className="text-muted-foreground truncate">Resp: {task.assignee_name}</p>
      )}
      <div className="flex items-center gap-2 mt-1.5 text-muted-foreground">
        <Calendar className="h-3 w-3" />
        {format(parseISO(task.task_date), 'dd/MM', { locale: ptBR })}
        {isOverdue && (
          <Badge variant="destructive" className="text-[10px] px-1 py-0">Atrasada</Badge>
        )}
      </div>
    </div>
  );
}

export function CategoryTasksPanel({ tasksByCategory, onTaskClick, onNewTask }: CategoryTasksPanelProps) {
  // Filter out categories with no tasks except SEM_CATEGORIA which only shows if has items
  const visibleCategories = CATEGORY_CONFIG.filter(c => {
    const items = tasksByCategory[c.key] || [];
    if (c.key === 'SEM_CATEGORIA') return items.length > 0;
    return true; // Always show admin categories
  });

  return (
    <div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {visibleCategories.map(cat => {
          const items = tasksByCategory[cat.key] || [];
          const Icon = cat.icon;

          return (
            <Card key={cat.key} className="border-border/50">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm flex items-center gap-2">
                  <div className={`w-7 h-7 rounded-md flex items-center justify-center border ${cat.color}`}>
                    <Icon className="h-3.5 w-3.5" />
                  </div>
                  {cat.label}
                  <Badge variant="secondary" className="ml-auto">{items.length}</Badge>
                  {onNewTask && (
                    <button
                      onClick={(e) => { e.stopPropagation(); onNewTask(cat.key !== 'SEM_CATEGORIA' ? cat.key : undefined); }}
                      className="text-[10px] text-primary hover:underline ml-1"
                    >
                      + Nova
                    </button>
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 max-h-[300px] overflow-y-auto">
                {items.length === 0 ? (
                  <p className="text-xs text-muted-foreground text-center py-4">Nenhuma tarefa</p>
                ) : (
                  items.map(task => (
                    <TaskRow key={task.id} task={task} onTaskClick={onTaskClick} />
                  ))
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
