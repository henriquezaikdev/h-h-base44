import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { FinTaskItem, UrgencyStats } from '@/hooks/useFinanceiroGestoraData';
import { format, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { toast } from 'sonner';
import {
  CalendarCheck,
  AlertTriangle,
  Flame,
  Package,
  Calendar,
  Archive,
} from 'lucide-react';

interface UrgencyPanelProps {
  urgency: UrgencyStats;
  onTaskClick?: (taskId: string) => void;
  onArchiveTask?: (taskId: string) => void;
}

type ListType = 'vencendoHoje' | 'atrasadas' | 'criticas' | null;

const CARDS = [
  {
    key: 'vencendoHoje' as const,
    label: 'Vencendo Hoje',
    icon: CalendarCheck,
    bgColor: 'bg-destructive/10 border-destructive/30',
    iconColor: 'text-destructive',
  },
  {
    key: 'atrasadas' as const,
    label: 'Atrasadas',
    icon: AlertTriangle,
    bgColor: 'bg-destructive/10 border-destructive/30',
    iconColor: 'text-destructive',
  },
  {
    key: 'criticas' as const,
    label: 'Críticas em Aberto',
    icon: Flame,
    bgColor: 'bg-destructive/10 border-destructive/30',
    iconColor: 'text-destructive',
  },
  {
    key: 'pendencias' as const,
    label: 'Pendências de Processo',
    icon: Package,
    bgColor: 'bg-amber-500/10 border-amber-500/30',
    iconColor: 'text-amber-600',
  },
];

export function UrgencyPanel({ urgency, onTaskClick, onArchiveTask }: UrgencyPanelProps) {
  const [openList, setOpenList] = useState<ListType>(null);

  const getCount = (key: string) => {
    if (key === 'vencendoHoje') return urgency.vencendoHoje.length;
    if (key === 'atrasadas') return urgency.atrasadas.length;
    if (key === 'criticas') return urgency.criticas.length;
    if (key === 'pendencias') return urgency.pendenciasProcesso;
    return 0;
  };

  const getItems = (key: ListType): FinTaskItem[] => {
    if (key === 'vencendoHoje') return urgency.vencendoHoje;
    if (key === 'atrasadas') return urgency.atrasadas;
    if (key === 'criticas') return urgency.criticas;
    return [];
  };

  const handleArchive = async (e: React.MouseEvent, taskId: string) => {
    e.stopPropagation();
    if (onArchiveTask) {
      await onArchiveTask(taskId);
      toast.success('Tarefa arquivada');
    }
  };

  return (
    <>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {CARDS.map(card => {
          const Icon = card.icon;
          const count = getCount(card.key);
          const isClickable = card.key !== 'pendencias';

          return (
            <Card
              key={card.key}
              className={`cursor-pointer border transition-all hover:shadow-md ${card.bgColor} ${count === 0 ? 'opacity-50' : ''}`}
              onClick={() => isClickable && count > 0 && setOpenList(card.key as ListType)}
            >
              <CardContent className="p-4 flex flex-col items-center text-center gap-2">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${card.iconColor} bg-background/60`}>
                  <Icon className="h-5 w-5" />
                </div>
                <span className="text-2xl font-bold text-foreground">{count}</span>
                <span className="text-xs font-medium text-muted-foreground">{card.label}</span>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Detail list modal */}
      <Dialog open={!!openList} onOpenChange={() => setOpenList(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>
              {openList === 'vencendoHoje' && '🔴 Tarefas Vencendo Hoje'}
              {openList === 'atrasadas' && '🔴 Tarefas Atrasadas'}
              {openList === 'criticas' && '🔴 Tarefas Críticas'}
            </DialogTitle>
          </DialogHeader>
          <ScrollArea className="max-h-[400px]">
            <div className="space-y-2">
              {getItems(openList).map(task => (
                <div
                  key={task.id}
                  className="p-3 rounded-lg border border-border/50 bg-muted/30 cursor-pointer hover:bg-muted/60 transition-colors group"
                  onClick={() => {
                    onTaskClick?.(task.id);
                    setOpenList(null);
                  }}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-medium text-sm truncate">{task.client_name}</span>
                    <div className="flex items-center gap-1.5">
                      <Badge variant={task.priority === 'alta' ? 'destructive' : 'secondary'} className="text-[10px]">
                        {task.priority}
                      </Badge>
                      {onArchiveTask && openList === 'atrasadas' && (
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-6 w-6 p-0 opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-destructive"
                          onClick={(e) => handleArchive(e, task.id)}
                          title="Arquivar tarefa"
                        >
                          <Archive className="h-3.5 w-3.5" />
                        </Button>
                      )}
                    </div>
                  </div>
                  {task.notes && <p className="text-xs text-muted-foreground truncate">{task.notes}</p>}
                  <div className="flex items-center gap-1.5 mt-1.5 text-xs text-muted-foreground">
                    <Calendar className="h-3 w-3" />
                    {format(parseISO(task.task_date), 'dd/MM/yyyy', { locale: ptBR })}
                    {task.task_category && (
                      <Badge variant="outline" className="text-[10px] ml-1">{task.task_category}</Badge>
                    )}
                  </div>
                </div>
              ))}
              {getItems(openList).length === 0 && (
                <p className="text-center text-sm text-muted-foreground py-6">Nenhuma tarefa nesta categoria.</p>
              )}
            </div>
          </ScrollArea>
        </DialogContent>
      </Dialog>
    </>
  );
}
