import { useState, useEffect, useCallback } from 'react';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { format, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { cn } from '@/lib/utils';
import {
  CalendarIcon,
  Clock,
  Save,
  Loader2,
  DollarSign,
  ShoppingCart,
  Package,
  Truck,
  Settings,
  ClipboardList,
  Flag,
  UserPlus,
} from 'lucide-react';
import { ADMIN_CATEGORIES, type AdminCategory } from '@/hooks/useFinanceiroGestoraData';
import { awardAdminXP } from '@/lib/adminXpUtils';

interface AdminTaskModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  mode: 'create' | 'edit';
  task?: any;
  sellers: Array<{ id: string; name: string }>;
  onCompleted: () => void;
  preselectedCategory?: string;
}

const CATEGORY_CONFIG: Record<string, { label: string; icon: any; color: string }> = {
  FINANCEIRO: { label: 'Financeiro', icon: DollarSign, color: 'text-emerald-600 bg-emerald-500/10' },
  COMPRAS: { label: 'Compras', icon: ShoppingCart, color: 'text-blue-600 bg-blue-500/10' },
  ESTOQUE: { label: 'Estoque', icon: Package, color: 'text-amber-600 bg-amber-500/10' },
  LOGISTICA: { label: 'Logística', icon: Truck, color: 'text-purple-600 bg-purple-500/10' },
  GESTAO: { label: 'Gestão', icon: Settings, color: 'text-rose-600 bg-rose-500/10' },
  ADMINISTRATIVO: { label: 'Administrativo', icon: ClipboardList, color: 'text-sky-600 bg-sky-500/10' },
};

const FINANCIAL_TYPES = [
  { value: 'CONTAS_PAGAR', label: 'Contas a Pagar' },
  { value: 'CONTAS_RECEBER', label: 'Contas a Receber' },
  { value: 'CONCILIACAO', label: 'Conciliação' },
  { value: 'OUTRO', label: 'Outro' },
];

const PRIORITY_OPTIONS = [
  { value: 'alta', label: 'Alta', color: 'border-red-500 bg-red-500/10 text-red-700' },
  { value: 'media', label: 'Média', color: 'border-amber-500 bg-amber-500/10 text-amber-700' },
  { value: 'baixa', label: 'Baixa', color: 'border-emerald-500 bg-emerald-500/10 text-emerald-700' },
];

const BUCKET_OPTIONS = [
  { value: 'HOJE', label: 'Hoje' },
  { value: 'AMANHA', label: 'Amanhã' },
  { value: 'SEMANA', label: 'Esta Semana' },
  { value: 'PERSONALIZADO', label: 'Personalizado' },
];

export function AdminTaskModal({ open, onOpenChange, mode, task, sellers, onCompleted, preselectedCategory }: AdminTaskModalProps) {
  const { seller } = useAuth();
  const queryClient = useQueryClient();

  // Form state
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<string>('');
  const [taskDate, setTaskDate] = useState<Date | undefined>(new Date());
  const [taskTime, setTaskTime] = useState('');
  const [priority, setPriority] = useState<string>('media');
  const [responsibleId, setResponsibleId] = useState('');
  const [bucket, setBucket] = useState('HOJE');
  const [delegateTo, setDelegateTo] = useState('');
  const [notes, setNotes] = useState('');
  const [saving, setSaving] = useState(false);
  const [datePickerOpen, setDatePickerOpen] = useState(false);

  // Conditional fields
  const [financialType, setFinancialType] = useState('');
  const [relatedProductText, setRelatedProductText] = useState('');
  const [relatedCompraId, setRelatedCompraId] = useState('');
  const [compras, setCompras] = useState<Array<{ id: string; label: string }>>([]);
  const [products, setProducts] = useState<Array<{ id: string; name: string }>>([]);

  // Completion state (edit mode)
  const [completionNotes, setCompletionNotes] = useState('');
  const [completing, setCompleting] = useState(false);

  const getTodayStr = () => format(new Date(), 'yyyy-MM-dd');

  // Load purchase orders when category is COMPRAS
  useEffect(() => {
    if (category === 'COMPRAS' && compras.length === 0) {
      supabase
        .from('compras')
        .select('id, data_compra, valor_total, fornecedores:fornecedor_id(nome_fantasia)')
        .order('data_compra', { ascending: false })
        .limit(50)
        .then(({ data }) => {
          setCompras(
            (data || []).map((c: any) => ({
              id: c.id,
              label: `${c.fornecedores?.nome_fantasia || 'Fornecedor'} — R$ ${(c.valor_total || 0).toFixed(2)} (${c.data_compra})`,
            }))
          );
        });
    }
  }, [category]);

  // Load products when category is ESTOQUE
  useEffect(() => {
    if (category === 'ESTOQUE' && products.length === 0) {
      supabase
        .from('products')
        .select('id, name')
        .order('name')
        .limit(100)
        .then(({ data }) => {
          setProducts((data || []).map((p: any) => ({ id: p.id, name: p.name })));
        });
    }
  }, [category]);

  // Initialize form
  useEffect(() => {
    if (!open) return;

    if (mode === 'edit' && task) {
      setTitle(task.notes || '');
      setCategory(task.task_category || task.taskCategory || '');
      setTaskDate(task.task_date ? parseISO(task.task_date) : task.taskDate ? parseISO(task.taskDate) : new Date());
      setTaskTime(task.task_time || task.taskTime || '');
      setPriority(task.priority || 'media');
      setResponsibleId(task.created_by_seller_id || task.createdBySellerId || '');
      setDelegateTo(task.assigned_to_seller_id || task.assignedToSellerId || '');
      setBucket(task.task_bucket || task.taskBucket || 'HOJE');
      setNotes(task.notes || '');
      setFinancialType(task.financial_type || task.financialType || '');
      setRelatedProductText(task.related_product_text || '');
      setRelatedCompraId(task.related_compra_id || '');
      setCompletionNotes('');
    } else {
      setTitle('');
      setCategory(preselectedCategory || '');
      setTaskDate(new Date());
      setTaskTime('');
      setPriority('media');
      setResponsibleId(seller?.id || '');
      setDelegateTo('');
      setBucket('HOJE');
      setNotes('');
      setFinancialType('');
      setRelatedProductText('');
      setRelatedCompraId('');
      setCompletionNotes('');
    }
  }, [open, mode, task?.id, seller?.id]);

  const handleSave = async () => {
    if (!title.trim()) {
      toast.error('Informe o título da tarefa.');
      return;
    }
    if (!category) {
      toast.error('Selecione a categoria.');
      return;
    }
    if (!taskDate) {
      toast.error('Selecione a data.');
      return;
    }
    if (!responsibleId) {
      toast.error('Selecione o responsável.');
      return;
    }

    setSaving(true);
    try {
      const dateStr = format(taskDate, 'yyyy-MM-dd');
      const taskPayload: Record<string, any> = {
        notes: title.trim(),
        task_category: category,
        task_date: dateStr,
        task_time: taskTime || null,
        priority,
        created_by_seller_id: seller?.id || responsibleId,
        assigned_to_seller_id: delegateTo || responsibleId,
        task_bucket: bucket,
        status: 'pendente',
        contact_type: 'ligacao',
        contact_reason: 'ACOMPANHAMENTO',
        module_type: category === 'COMPRAS' ? 'COMPRA' : 'INTERNA',
        financial_type: category === 'FINANCEIRO' ? financialType : null,
        related_product_text: category === 'ESTOQUE' ? relatedProductText : null,
        related_compra_id: category === 'COMPRAS' && relatedCompraId ? relatedCompraId : null,
      };

      if (mode === 'create') {
        const uniqueKey = `admin_${seller?.id || responsibleId}_${Date.now()}`;
        const { error } = await supabase.from('tasks').insert({ ...taskPayload, unique_key: uniqueKey } as any);
        if (error) throw error;
        toast.success('Tarefa criada com sucesso!');
      } else if (task) {
        const { error } = await supabase.from('tasks').update(taskPayload as any).eq('id', task.id);
        if (error) throw error;
        toast.success('Tarefa atualizada!');
      }

      onOpenChange(false);
      onCompleted();
      queryClient.invalidateQueries({ queryKey: ['tasks'] });
      queryClient.invalidateQueries({ queryKey: ['actionCenter'] });
      queryClient.invalidateQueries({ queryKey: ['fin-gestora-tasks'] });
    } catch (error: any) {
      console.error('Error saving admin task:', error);
      toast.error(error.message || 'Erro ao salvar tarefa');
    } finally {
      setSaving(false);
    }
  };

  const handleComplete = async () => {
    if (!task) return;
    setCompleting(true);
    try {
      const now = new Date();
      const taskDateValue = task.task_date || task.taskDate;
      const isOnTime = taskDateValue && format(now, 'yyyy-MM-dd') <= taskDateValue;

      const { error } = await supabase
        .from('tasks')
        .update({
          status: 'concluida',
          completed_at: now.toISOString(),
          completion_notes: completionNotes || null,
        } as any)
        .eq('id', task.id);

      if (error) throw error;

      // Anti-fraud: check if task was created more than 30 seconds ago
      const createdAt = task.created_at || task.createdAt;
      const createdTime = createdAt ? new Date(createdAt).getTime() : 0;
      const elapsed = now.getTime() - createdTime;

      if (elapsed >= 30000) {
        // Award XP based on on-time vs late
        const xpAmount = isOnTime ? 10 : 3;
        const eventType = isOnTime ? 'ADMIN_TASK_ONTIME' : 'ADMIN_TASK_LATE';
        await awardAdminXP(seller?.id || '', eventType, xpAmount, task.id);
      }

      toast.success('Tarefa concluída!');
      onOpenChange(false);
      onCompleted();
      queryClient.invalidateQueries({ queryKey: ['tasks'] });
      queryClient.invalidateQueries({ queryKey: ['actionCenter'] });
      queryClient.invalidateQueries({ queryKey: ['fin-gestora-tasks'] });
    } catch (error: any) {
      console.error('Error completing task:', error);
      toast.error(error.message || 'Erro ao concluir');
    } finally {
      setCompleting(false);
    }
  };

  const isEditMode = mode === 'edit';
  const isCompleted = isEditMode && task?.status === 'concluida';

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="right" className="w-full sm:max-w-[600px] p-0 flex flex-col overflow-hidden">
        {/* Header */}
        <SheetHeader className="px-6 py-4 border-b shrink-0 bg-gradient-to-r from-primary/5 to-transparent">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                <ClipboardList className="h-5 w-5 text-primary" />
              </div>
              <SheetTitle className="text-lg font-semibold">
                {mode === 'create' ? 'Nova Tarefa Administrativa' : title || 'Editar Tarefa'}
              </SheetTitle>
            </div>
            {!isCompleted && (
              <Button size="sm" onClick={handleSave} disabled={saving} className="gap-2">
                {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                {mode === 'create' ? 'Criar' : 'Salvar'}
              </Button>
            )}
          </div>
        </SheetHeader>

        <ScrollArea className="flex-1">
          <div className="p-6 space-y-5">
            {/* Título */}
            <div className="space-y-2">
              <Label className="text-sm font-medium">Título da Tarefa *</Label>
              <Input
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Descreva a tarefa..."
                disabled={isCompleted}
              />
            </div>

            {/* Categoria */}
            <div className="space-y-2">
              <Label className="text-sm font-medium">Categoria *</Label>
              <div className="grid grid-cols-3 gap-2">
                {ADMIN_CATEGORIES.map((cat) => {
                  const config = CATEGORY_CONFIG[cat];
                  const Icon = config.icon;
                  const isSelected = category === cat;
                  return (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => !isCompleted && setCategory(cat)}
                      className={cn(
                        'flex items-center gap-2 p-2.5 rounded-lg border text-sm font-medium transition-all',
                        isSelected
                          ? 'border-primary bg-primary/10 text-primary ring-1 ring-primary/30'
                          : 'border-border hover:border-primary/40 text-muted-foreground hover:text-foreground'
                      )}
                      disabled={isCompleted}
                    >
                      <Icon className="h-4 w-4 shrink-0" />
                      {config.label}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* CONDITIONAL: Financeiro */}
            {category === 'FINANCEIRO' && (
              <div className="space-y-2 p-3 bg-emerald-500/5 border border-emerald-500/20 rounded-lg">
                <Label className="text-sm font-medium text-emerald-700">Tipo Financeiro</Label>
                <Select value={financialType} onValueChange={setFinancialType} disabled={isCompleted}>
                  <SelectTrigger><SelectValue placeholder="Selecione o tipo..." /></SelectTrigger>
                  <SelectContent>
                    {FINANCIAL_TYPES.map((t) => (
                      <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            {/* CONDITIONAL: Compras */}
            {category === 'COMPRAS' && (
              <div className="space-y-2 p-3 bg-blue-500/5 border border-blue-500/20 rounded-lg">
                <Label className="text-sm font-medium text-blue-700">Vincular Ordem de Compra</Label>
                <Select value={relatedCompraId} onValueChange={setRelatedCompraId} disabled={isCompleted}>
                  <SelectTrigger><SelectValue placeholder="Selecione uma ordem..." /></SelectTrigger>
                  <SelectContent>
                    {compras.map((c) => (
                      <SelectItem key={c.id} value={c.id}>{c.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            {/* CONDITIONAL: Estoque */}
            {category === 'ESTOQUE' && (
              <div className="space-y-2 p-3 bg-amber-500/5 border border-amber-500/20 rounded-lg">
                <Label className="text-sm font-medium text-amber-700">Produto / Item Relacionado</Label>
                <Input
                  value={relatedProductText}
                  onChange={(e) => setRelatedProductText(e.target.value)}
                  placeholder="Nome do produto ou item..."
                  disabled={isCompleted}
                />
                {products.length > 0 && (
                  <Select value="" onValueChange={(v) => setRelatedProductText(v)} disabled={isCompleted}>
                    <SelectTrigger><SelectValue placeholder="Ou selecione do catálogo..." /></SelectTrigger>
                    <SelectContent>
                      {products.map((p) => (
                        <SelectItem key={p.id} value={p.name}>{p.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}
              </div>
            )}

            <Separator />

            {/* Data e Hora */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-sm font-medium">Data *</Label>
                <Popover open={datePickerOpen} onOpenChange={setDatePickerOpen}>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn('w-full justify-start text-left font-normal', !taskDate && 'text-muted-foreground')}
                      disabled={isCompleted}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {taskDate ? format(taskDate, 'dd/MM/yyyy') : 'Selecione...'}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={taskDate}
                      onSelect={(d) => { setTaskDate(d); setDatePickerOpen(false); }}
                      initialFocus
                      className={cn('p-3 pointer-events-auto')}
                    />
                  </PopoverContent>
                </Popover>
              </div>
              <div className="space-y-2">
                <Label className="text-sm font-medium">Hora (opcional)</Label>
                <div className="relative">
                  <Clock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    type="time"
                    value={taskTime}
                    onChange={(e) => setTaskTime(e.target.value)}
                    className="pl-10"
                    disabled={isCompleted}
                  />
                </div>
              </div>
            </div>

            {/* Prioridade */}
            <div className="space-y-2">
              <Label className="text-sm font-medium">Prioridade *</Label>
              <RadioGroup
                value={priority}
                onValueChange={setPriority}
                className="flex gap-2"
                disabled={isCompleted}
              >
                {PRIORITY_OPTIONS.map((p) => (
                  <div key={p.value} className="flex-1">
                    <RadioGroupItem value={p.value} id={`priority-${p.value}`} className="sr-only" />
                    <label
                      htmlFor={`priority-${p.value}`}
                      className={cn(
                        'flex items-center justify-center gap-1.5 p-2 rounded-lg border text-sm font-medium cursor-pointer transition-all',
                        priority === p.value ? p.color + ' ring-1 ring-current/30' : 'border-border text-muted-foreground hover:border-primary/40'
                      )}
                    >
                      <Flag className="h-3.5 w-3.5" />
                      {p.label}
                    </label>
                  </div>
                ))}
              </RadioGroup>
            </div>

            {/* Responsável */}
            <div className="space-y-2">
              <Label className="text-sm font-medium">Responsável *</Label>
              <Select value={responsibleId} onValueChange={setResponsibleId} disabled={isCompleted}>
                <SelectTrigger><SelectValue placeholder="Selecione..." /></SelectTrigger>
                <SelectContent>
                  {sellers.map((s) => (
                    <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Planejamento */}
            <div className="space-y-2">
              <Label className="text-sm font-medium">Planejamento</Label>
              <Select value={bucket} onValueChange={setBucket} disabled={isCompleted}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {BUCKET_OPTIONS.map((b) => (
                    <SelectItem key={b.value} value={b.value}>{b.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <Separator />

            {/* Delegar */}
            <div className="space-y-2">
              <Label className="text-sm font-medium flex items-center gap-1.5">
                <UserPlus className="h-4 w-4" />
                Delegar para (opcional)
              </Label>
              <Select value={delegateTo} onValueChange={setDelegateTo} disabled={isCompleted}>
                <SelectTrigger><SelectValue placeholder="Nenhum — eu mesmo faço" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">Nenhum</SelectItem>
                  {sellers.filter(s => s.id !== seller?.id).map((s) => (
                    <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Observações */}
            <div className="space-y-2">
              <Label className="text-sm font-medium">Observações (opcional)</Label>
              <Textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Detalhes adicionais..."
                rows={3}
                disabled={isCompleted}
              />
            </div>

            {/* Completion section (edit mode, not completed) */}
            {isEditMode && !isCompleted && (
              <>
                <Separator />
                <div className="space-y-3 p-4 bg-emerald-500/5 border border-emerald-500/20 rounded-lg">
                  <h4 className="font-medium text-emerald-700 text-sm">Concluir Tarefa</h4>
                  <Textarea
                    value={completionNotes}
                    onChange={(e) => setCompletionNotes(e.target.value)}
                    placeholder="Notas de conclusão (opcional)..."
                    rows={2}
                  />
                  <Button
                    onClick={handleComplete}
                    disabled={completing}
                    className="w-full gap-2 bg-emerald-600 hover:bg-emerald-700"
                  >
                    {completing ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
                    Marcar como Concluída
                  </Button>
                </div>
              </>
            )}
          </div>
        </ScrollArea>
      </SheetContent>
    </Sheet>
  );
}
