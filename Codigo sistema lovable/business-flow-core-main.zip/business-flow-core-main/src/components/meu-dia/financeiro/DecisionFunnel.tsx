import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { ProcessPendency } from '@/hooks/useFinanceiroGestoraData';
import { format, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { toast } from 'sonner';
import {
  Package,
  Truck,
  DollarSign,
  CheckCircle2,
  Calendar,
  Check,
  Plus,
  ExternalLink,
} from 'lucide-react';

interface DecisionFunnelProps {
  pendenciesByType: {
    COMPRAS: ProcessPendency[];
    ENTREGAS: ProcessPendency[];
    FINANCEIRO: ProcessPendency[];
  };
  onResolve: (pendency: ProcessPendency) => void;
  onAddPendency: (p: { type: string; title: string; description?: string; due_date?: string }) => Promise<any>;
}

const TAB_CONFIG = [
  { key: 'COMPRAS', label: 'Compras', icon: Package, color: 'text-blue-600' },
  { key: 'ENTREGAS', label: 'Entregas', icon: Truck, color: 'text-amber-600' },
  { key: 'FINANCEIRO', label: 'Financeiro', icon: DollarSign, color: 'text-emerald-600' },
];

function PendencyItem({ item, onResolve }: { item: ProcessPendency; onResolve: (p: ProcessPendency) => void }) {
  const navigate = useNavigate();
  const [resolving, setResolving] = useState(false);

  const handleResolve = async (e: React.MouseEvent) => {
    e.stopPropagation();
    setResolving(true);
    await onResolve(item);
    toast.success('Pendência resolvida!');
    setResolving(false);
  };

  const handleOpenOrigin = (e: React.MouseEvent) => {
    e.stopPropagation();
    const rid = item.related_id || item.id;
    if (item.related_type === 'cotacao_itens') {
      navigate(`/compras?cotacao=${rid}`);
    } else {
      navigate(`/compras?solicitacao=${rid}`);
    }
  };

  return (
    <div className="flex items-center gap-3 p-3 rounded-lg border border-border/40 bg-background/60 hover:bg-muted/50 transition-colors group">
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium truncate">{item.title}</p>
        <p className="text-xs text-muted-foreground truncate">{item.origin}</p>
        {item.due_date && (
          <div className="flex items-center gap-1 mt-1 text-xs text-muted-foreground">
            <Calendar className="h-3 w-3" />
            {format(parseISO(item.due_date), 'dd/MM/yyyy', { locale: ptBR })}
          </div>
        )}
      </div>
      <Badge variant="outline" className="text-[10px] shrink-0">{item.status}</Badge>
      <Button
        variant="ghost"
        size="sm"
        className="h-7 px-2 gap-1 text-xs opacity-0 group-hover:opacity-100 transition-opacity"
        onClick={handleOpenOrigin}
      >
        <ExternalLink className="h-3 w-3" />
        Abrir
      </Button>
      {item.source === 'process_pendencies' && (
        <Button
          variant="ghost"
          size="sm"
          className="h-7 px-2 gap-1 text-emerald-600 hover:text-emerald-700 hover:bg-emerald-500/10 opacity-0 group-hover:opacity-100 transition-opacity"
          onClick={handleResolve}
          disabled={resolving}
        >
          <Check className="h-3.5 w-3.5" />
          Resolver
        </Button>
      )}
    </div>
  );
}

export function DecisionFunnel({ pendenciesByType, onResolve, onAddPendency }: DecisionFunnelProps) {
  const totalCount = Object.values(pendenciesByType).reduce((sum, arr) => sum + arr.length, 0);
  const [showAdd, setShowAdd] = useState(false);
  const [newType, setNewType] = useState('FINANCEIRO');
  const [newTitle, setNewTitle] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newDue, setNewDue] = useState('');
  const [saving, setSaving] = useState(false);

  const handleAdd = async () => {
    if (!newTitle.trim()) { toast.error('Informe o título'); return; }
    setSaving(true);
    await onAddPendency({ type: newType, title: newTitle.trim(), description: newDesc || undefined, due_date: newDue || undefined });
    toast.success('Pendência criada!');
    setShowAdd(false);
    setNewTitle(''); setNewDesc(''); setNewDue('');
    setSaving(false);
  };

  if (totalCount === 0) {
    return (
      <Card className="border-emerald-500/30 bg-emerald-500/5">
        <CardContent className="p-6 flex items-center justify-center gap-3 text-emerald-600">
          <CheckCircle2 className="h-5 w-5" />
          <span className="text-sm font-medium">Nenhuma decisão pendente — tudo em dia!</span>
          <Button variant="ghost" size="sm" className="gap-1 ml-4" onClick={() => setShowAdd(true)}>
            <Plus className="h-3.5 w-3.5" /> Adicionar
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Card className="border-border/50">
        <CardHeader className="pb-2">
          <CardTitle className="text-base flex items-center gap-2">
            ⚡ Decisões Pendentes
            <Badge variant="secondary">{totalCount}</Badge>
            <Button variant="ghost" size="sm" className="ml-auto gap-1 h-7 px-2" onClick={() => setShowAdd(true)}>
              <Plus className="h-3.5 w-3.5" /> Nova
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="COMPRAS">
            <TabsList className="grid grid-cols-3 w-full">
              {TAB_CONFIG.map(tab => (
                <TabsTrigger key={tab.key} value={tab.key} className="gap-1.5 text-xs">
                  <tab.icon className={`h-3.5 w-3.5 ${tab.color}`} />
                  {tab.label}
                  {pendenciesByType[tab.key as keyof typeof pendenciesByType].length > 0 && (
                    <Badge variant="destructive" className="text-[10px] px-1 py-0 ml-1">
                      {pendenciesByType[tab.key as keyof typeof pendenciesByType].length}
                    </Badge>
                  )}
                </TabsTrigger>
              ))}
            </TabsList>

            {TAB_CONFIG.map(tab => (
              <TabsContent key={tab.key} value={tab.key} className="mt-3 space-y-2">
                {pendenciesByType[tab.key as keyof typeof pendenciesByType].length === 0 ? (
                  <p className="text-center text-xs text-muted-foreground py-4">Nenhuma pendência</p>
                ) : (
                  pendenciesByType[tab.key as keyof typeof pendenciesByType].map(item => (
                    <PendencyItem key={item.id} item={item} onResolve={onResolve} />
                  ))
                )}
              </TabsContent>
            ))}
          </Tabs>
        </CardContent>
      </Card>

      {/* Add pendency dialog */}
      <Dialog open={showAdd} onOpenChange={setShowAdd}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Nova Pendência</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div>
              <Label>Tipo *</Label>
              <Select value={newType} onValueChange={setNewType}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="FINANCEIRO">Financeiro</SelectItem>
                  <SelectItem value="COMPRAS">Compras</SelectItem>
                  <SelectItem value="ENTREGAS">Entregas</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Título *</Label>
              <Input value={newTitle} onChange={e => setNewTitle(e.target.value)} placeholder="Ex: Conferir pagamento fornecedor X" />
            </div>
            <div>
              <Label>Descrição</Label>
              <Input value={newDesc} onChange={e => setNewDesc(e.target.value)} placeholder="Detalhes opcionais" />
            </div>
            <div>
              <Label>Prazo</Label>
              <Input type="date" value={newDue} onChange={e => setNewDue(e.target.value)} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAdd(false)}>Cancelar</Button>
            <Button onClick={handleAdd} disabled={saving}>{saving ? 'Salvando...' : 'Criar'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
