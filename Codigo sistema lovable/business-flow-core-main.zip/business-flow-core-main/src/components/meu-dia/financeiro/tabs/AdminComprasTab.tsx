import { useState, useMemo } from 'react';
import { Badge } from '@/components/ui/badge';
import { AlertTriangle, ShoppingCart, BarChart3, Settings2 } from 'lucide-react';
import { ProcessPendency } from '@/hooks/useFinanceiroGestoraData';
import { ComprasBuyerKanban } from '@/components/compras/ComprasBuyerKanban';
import { ComprasRelatoriosTab } from '@/components/compras/ComprasRelatoriosTab';
import { ComprasGestaoTab } from '@/components/compras/ComprasGestaoTab';
import { cn } from '@/lib/utils';

interface AdminComprasTabProps {
  pendencies: ProcessPendency[];
}

const SUB_TABS = [
  { key: 'central', label: 'Central do Comprador', icon: ShoppingCart },
  { key: 'gestao', label: 'Gestão', icon: Settings2 },
  { key: 'relatorios', label: 'Relatórios', icon: BarChart3 },
];

export function AdminComprasTab({ pendencies }: AdminComprasTabProps) {
  const [subTab, setSubTab] = useState('central');

  const approvalCount = useMemo(() => {
    return pendencies.filter(p =>
      (p.source === 'solicitacoes' || p.source === 'cotacoes') &&
      ['AGUARDANDO_APROVACAO_SOLICITANTE', 'AGUARDANDO', 'NOVA_SOLICITACAO', 'AGUARDANDO_COMPRADOR'].includes(p.status)
    ).length;
  }, [pendencies]);

  return (
    <div className="space-y-6">
      {/* Alert banner */}
      {approvalCount > 0 && (
        <div className="flex items-center gap-3 p-3.5 rounded-xl bg-amber-50 border border-amber-200 dark:bg-amber-500/10 dark:border-amber-500/30">
          <AlertTriangle className="h-5 w-5 text-amber-600 shrink-0" />
          <p className="text-sm font-medium text-amber-800 dark:text-amber-400">
            {approvalCount} cotação(ões) aguardando sua aprovação
          </p>
        </div>
      )}

      {/* Sub-tabs */}
      <div className="flex gap-1 p-1 bg-muted/50 rounded-lg w-fit">
        {SUB_TABS.map(tab => {
          const Icon = tab.icon;
          const isActive = subTab === tab.key;
          return (
            <button
              key={tab.key}
              onClick={() => setSubTab(tab.key)}
              className={cn(
                'flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-colors',
                isActive
                  ? 'bg-card text-foreground shadow-sm'
                  : 'text-muted-foreground hover:text-foreground'
              )}
            >
              <Icon className="h-4 w-4" />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Content */}
      {subTab === 'central' && <ComprasBuyerKanban />}
      {subTab === 'gestao' && <ComprasGestaoTab />}
      {subTab === 'relatorios' && <ComprasRelatoriosTab />}
    </div>
  );
}
