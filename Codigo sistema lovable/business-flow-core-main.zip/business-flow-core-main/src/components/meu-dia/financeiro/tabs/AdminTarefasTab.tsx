import { useState, useMemo } from 'react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Plus, RefreshCw, CalendarCheck, AlertTriangle, Flame, Package } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { FinTaskItem } from '@/hooks/useFinanceiroGestoraData';
import { CategoryTasksPanel } from '../CategoryTasksPanel';
import { PlanningBoard } from '../PlanningBoard';
import { DelegationSection } from '../DelegationSection';
import { RoutinesCard } from '../RoutinesCard';
import { AdminTaskModal } from '../AdminTaskModal';
import { ComprasDetailSheet } from '@/components/compras/ComprasDetailSheet';

interface AdminTarefasTabProps {
  seller: any;
  sellers: Array<{ id: string; name: string }>;
  finData: any;
  onRefresh: () => void;
}

function getGreeting(): string {
  const hour = new Date().getHours();
  if (hour < 12) return 'Bom dia';
  if (hour < 18) return 'Boa tarde';
  return 'Boa noite';
}

function getFirstName(name?: string): string {
  if (!name) return '';
  return name.split(' ')[0];
}

const METRIC_CARDS = [
  { key: 'hoje', label: 'Vencendo Hoje', icon: CalendarCheck, numColor: 'text-orange-500' },
  { key: 'atrasadas', label: 'Atrasadas', icon: AlertTriangle, numColor: 'text-red-500' },
  { key: 'criticas', label: 'Críticas', icon: Flame, numColor: 'text-red-700' },
  { key: 'pendencias', label: 'Pendências Compras', icon: Package, numColor: 'text-blue-500' },
];

export function AdminTarefasTab({ seller, sellers, finData, onRefresh }: AdminTarefasTabProps) {
  const [taskModalOpen, setTaskModalOpen] = useState(false);
  const [selectedTaskForEdit, setSelectedTaskForEdit] = useState<FinTaskItem | null>(null);
  const [preselectedCategory, setPreselectedCategory] = useState<string | undefined>();
  const [comprasSheetOpen, setComprasSheetOpen] = useState(false);
  const [comprasSolicitacaoId, setComprasSolicitacaoId] = useState<string | null>(null);

  const { urgency, tasks: finTasks, manualTasks, tasksByCategory, tasksByBucket, delegatedToMe, delegatedByMe, routines, updateBucket, addRoutine, removeRoutine, archiveTask } = finData;

  const metrics = useMemo(() => ({
    hoje: urgency.vencendoHoje.length,
    atrasadas: urgency.atrasadas.length,
    criticas: urgency.criticas.length,
    pendencias: urgency.pendenciasProcesso,
  }), [urgency]);

  const handleTaskClick = (taskId: string) => {
    // Search in all tasks (including auto-generated) for ComprasDetailSheet linking
    const found = finTasks?.find((t: FinTaskItem) => t.id === taskId) 
      || (manualTasks as FinTaskItem[])?.find((t: FinTaskItem) => t.id === taskId);
    if (!found) return;

    // If task is linked to a purchase, open the ComprasDetailSheet
    if (found.related_type === 'solicitacoes_compra' && found.related_id) {
      setComprasSolicitacaoId(found.related_id);
      setComprasSheetOpen(true);
      return;
    }
    if (found.related_type === 'cotacao_itens' && found.related_id) {
      // For cotacao_itens, we need to resolve the solicitacao_id
      resolveSolicitacaoFromCotacaoItem(found.related_id);
      return;
    }

    setSelectedTaskForEdit(found);
    setPreselectedCategory(undefined);
    setTaskModalOpen(true);
  };

  const resolveSolicitacaoFromCotacaoItem = async (cotacaoItemId: string) => {
    try {
      const { supabase } = await import('@/integrations/supabase/client');
      const { data } = await supabase
        .from('cotacao_itens')
        .select('cotacao_id, cotacoes_fornecedor:cotacao_id(solicitacao_id)')
        .eq('id', cotacaoItemId)
        .single();
      const solId = (data as any)?.cotacoes_fornecedor?.solicitacao_id;
      if (solId) {
        setComprasSolicitacaoId(solId);
        setComprasSheetOpen(true);
      }
    } catch { /* fallback: do nothing */ }
  };

  const openNewTask = (category?: string) => {
    setSelectedTaskForEdit(null);
    setPreselectedCategory(category);
    setTaskModalOpen(true);
  };

  return (
    <div className="space-y-8">
      {/* HEADER */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-foreground">
            {getGreeting()}, {getFirstName(seller?.name)}
          </h1>
          <p className="text-muted-foreground text-sm mt-0.5">
            {format(new Date(), "EEEE, dd 'de' MMMM", { locale: ptBR })}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button size="sm" onClick={() => openNewTask()} className="gap-1.5">
            <Plus className="h-4 w-4" />
            Nova Tarefa
          </Button>
          <Button variant="ghost" size="sm" onClick={onRefresh} className="gap-1.5">
            <RefreshCw className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* METRIC CARDS */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {METRIC_CARDS.map(card => {
          const Icon = card.icon;
          const count = metrics[card.key as keyof typeof metrics];
          return (
            <div
              key={card.key}
              className="bg-card border border-border/50 rounded-xl p-4 shadow-sm"
            >
              <div className="flex items-start justify-between">
                <Icon className="h-4 w-4 text-muted-foreground" />
              </div>
              <p className={`text-2xl font-bold mt-2 ${card.numColor}`}>{count}</p>
              <p className="text-[11px] uppercase tracking-widest text-muted-foreground mt-1">{card.label}</p>
            </div>
          );
        })}
      </div>

      {/* TASKS BY CATEGORY */}
      <section>
        <h2 className="text-[11px] uppercase tracking-widest text-muted-foreground font-medium mb-4">
          Tarefas por Categoria
        </h2>
        <CategoryTasksPanel
          tasksByCategory={tasksByCategory}
          onTaskClick={handleTaskClick}
          onNewTask={openNewTask}
        />
      </section>

      {/* PLANNING BOARD */}
      <section>
        <h2 className="text-[11px] uppercase tracking-widest text-muted-foreground font-medium mb-4">
          Planejamento
        </h2>
        <PlanningBoard
          tasksByBucket={tasksByBucket}
          onUpdateBucket={updateBucket}
          onTaskClick={handleTaskClick}
        />
      </section>

      {/* DELEGATION */}
      <section>
        <h2 className="text-[11px] uppercase tracking-widest text-muted-foreground font-medium mb-4">
          Delegação
        </h2>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <DelegationSection
            title="Delegadas a mim"
            subtitle="Tarefas atribuídas a você por outros"
            tasks={delegatedToMe}
            showField="creator"
            onTaskClick={handleTaskClick}
          />
          <DelegationSection
            title="Delegadas por mim"
            subtitle="Tarefas que você atribuiu a outros"
            tasks={delegatedByMe}
            showField="assignee"
            onTaskClick={handleTaskClick}
          />
        </div>
      </section>

      {/* ROUTINES */}
      <section>
        <h2 className="text-[11px] uppercase tracking-widest text-muted-foreground font-medium mb-4">
          Rotinas Fixas
        </h2>
        <RoutinesCard routines={routines} onAddRoutine={addRoutine} onRemoveRoutine={removeRoutine} />
      </section>

      {/* TASK MODAL */}
      <AdminTaskModal
        open={taskModalOpen}
        onOpenChange={(open) => {
          setTaskModalOpen(open);
          if (!open) {
            setSelectedTaskForEdit(null);
            setPreselectedCategory(undefined);
          }
        }}
        mode={selectedTaskForEdit ? 'edit' : 'create'}
        task={selectedTaskForEdit}
        sellers={sellers}
        onCompleted={() => {
          setTaskModalOpen(false);
          setSelectedTaskForEdit(null);
          setPreselectedCategory(undefined);
          onRefresh();
        }}
        preselectedCategory={preselectedCategory}
      />

      {/* COMPRAS DETAIL SHEET */}
      {comprasSolicitacaoId && (
        <ComprasDetailSheet
          open={comprasSheetOpen}
          onOpenChange={(open) => {
            setComprasSheetOpen(open);
            if (!open) setComprasSolicitacaoId(null);
          }}
          solicitacaoId={comprasSolicitacaoId}
        />
      )}
    </div>
  );
}
