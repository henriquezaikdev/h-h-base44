import { useMemo, lazy, Suspense } from 'react';
import { format, addDays, parseISO, isToday, isBefore, startOfDay, startOfMonth, endOfMonth } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { DollarSign, TrendingUp, TrendingDown, AlertTriangle, Calendar, Inbox } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { useGestorData } from '@/hooks/useGestorData';
import { ComissoesTable } from '@/components/shared/ComissoesTable';

const FluxoCaixaFuturo = lazy(() => import('@/components/financeiro/FluxoCaixaFuturo').then(m => ({ default: m.FluxoCaixaFuturo })));

function formatCurrency(value: number): string {
  return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
}

interface FinanceItem {
  id: string;
  description: string;
  value: number;
  due_date: string;
  type: 'receber' | 'pagar';
  status: 'pendente' | 'pago' | 'atrasado';
}

export function AdminFinanceiroTab() {
  const { seller } = useAuth();

  const now = new Date();
  const gestorFilters = useMemo(() => ({
    startDate: startOfMonth(now),
    endDate: endOfMonth(now),
    sellerId: null,
    includesPending: true,
  }), []);

  const { sellersResult } = useGestorData(gestorFilters);

  // For now, use process_pendencies with type FINANCEIRO as the data source
  // This can be expanded when a dedicated financial table exists
  const { data: pendencies = [] } = useQuery({
    queryKey: ['admin-financeiro-pendencies', seller?.id],
    enabled: !!seller?.id,
    queryFn: async () => {
      const { data } = await supabase
        .from('process_pendencies')
        .select('*')
        .eq('type', 'FINANCEIRO')
        .in('status', ['ABERTA', 'RESOLVIDA'])
        .order('due_date', { ascending: true });
      return data || [];
    },
  });

  const today = startOfDay(new Date());
  const next7 = addDays(today, 7);

  // Transform pendencies into finance items
  const financeItems: FinanceItem[] = useMemo(() => {
    return pendencies.map((p: any) => {
      const dueDate = p.due_date ? startOfDay(parseISO(p.due_date)) : today;
      const isPaid = p.status === 'RESOLVIDA';
      const isOverdue = !isPaid && isBefore(dueDate, today);
      const isReceber = p.title?.toLowerCase().includes('receber') || p.description?.toLowerCase().includes('receber');

      return {
        id: p.id,
        description: p.title || 'Sem descrição',
        value: 0, // No value field in process_pendencies — placeholder
        due_date: p.due_date || format(today, 'yyyy-MM-dd'),
        type: isReceber ? 'receber' as const : 'pagar' as const,
        status: isPaid ? 'pago' as const : isOverdue ? 'atrasado' as const : 'pendente' as const,
      };
    });
  }, [pendencies]);

  const receberHoje = financeItems.filter(i => i.type === 'receber' && isToday(parseISO(i.due_date)) && i.status !== 'pago');
  const pagarHoje = financeItems.filter(i => i.type === 'pagar' && isToday(parseISO(i.due_date)) && i.status !== 'pago');
  const atrasadosReceber = financeItems.filter(i => i.type === 'receber' && i.status === 'atrasado');
  const atrasadosPagar = financeItems.filter(i => i.type === 'pagar' && i.status === 'atrasado');

  const prox7dias = financeItems.filter(i => {
    const d = parseISO(i.due_date);
    return d >= today && d <= next7 && i.status !== 'pago';
  }).sort((a, b) => a.due_date.localeCompare(b.due_date));

  const vencimentosHojeReceber = financeItems.filter(i => i.type === 'receber' && isToday(parseISO(i.due_date)));
  const vencimentosHojePagar = financeItems.filter(i => i.type === 'pagar' && isToday(parseISO(i.due_date)));

  const summaryCards = [
    { label: 'A Receber Hoje', count: receberHoje.length, color: 'text-emerald-600', icon: TrendingUp },
    { label: 'A Pagar Hoje', count: pagarHoje.length, color: 'text-red-500', icon: TrendingDown },
    { label: 'Em Atraso (Receber)', count: atrasadosReceber.length, color: 'text-emerald-700', icon: AlertTriangle },
    { label: 'Em Atraso (Pagar)', count: atrasadosPagar.length, color: 'text-red-700', icon: AlertTriangle },
  ];

  return (
    <div className="space-y-8">
      {/* Summary cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {summaryCards.map(card => {
          const Icon = card.icon;
          return (
            <div key={card.label} className="bg-card border border-border/50 rounded-xl p-4 shadow-sm">
              <Icon className="h-4 w-4 text-muted-foreground" />
              <p className={`text-2xl font-bold mt-2 ${card.color}`}>{card.count}</p>
              <p className="text-[11px] uppercase tracking-widest text-muted-foreground mt-1">{card.label}</p>
            </div>
          );
        })}
      </div>

      {/* Comissões a Pagar */}
      <ComissoesTable
        items={(sellersResult || []).map(s => ({
          name: s.name,
          revenue: s.revenue,
          marginBruta: s.marginBruta,
          comissaoReal: s.comissaoReal,
          comissaoPercentual: s.comissaoPercentual,
        }))}
      />

      {/* Vencimentos do Dia */}
      <section>
        <h2 className="text-[11px] uppercase tracking-widest text-muted-foreground font-medium mb-4">
          Vencimentos do Dia
        </h2>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* Contas a Receber */}
          <Card className="border-border/50 shadow-sm">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-emerald-600" />
                Contas a Receber
                <Badge variant="secondary" className="ml-auto">{vencimentosHojeReceber.length}</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {vencimentosHojeReceber.length === 0 ? (
                <EmptyState label="Nenhum recebimento hoje" />
              ) : (
                <div className="space-y-2">
                  {vencimentosHojeReceber.map(item => (
                    <FinanceRow key={item.id} item={item} />
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Contas a Pagar */}
          <Card className="border-border/50 shadow-sm">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2">
                <TrendingDown className="h-4 w-4 text-red-500" />
                Contas a Pagar
                <Badge variant="secondary" className="ml-auto">{vencimentosHojePagar.length}</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {vencimentosHojePagar.length === 0 ? (
                <EmptyState label="Nenhum pagamento hoje" />
              ) : (
                <div className="space-y-2">
                  {vencimentosHojePagar.map(item => (
                    <FinanceRow key={item.id} item={item} />
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Próximos 7 dias */}
      <section>
        <h2 className="text-[11px] uppercase tracking-widest text-muted-foreground font-medium mb-4">
          Próximos 7 Dias
        </h2>
        <Card className="border-border/50 shadow-sm">
          <CardContent className="pt-4">
            {prox7dias.length === 0 ? (
              <EmptyState label="Nenhum vencimento nos próximos 7 dias" />
            ) : (
              <div className="space-y-2">
                {prox7dias.map(item => (
                  <div key={item.id} className="flex items-center gap-3 p-2.5 rounded-lg border border-border/30 bg-muted/10">
                    <span className="text-xs text-muted-foreground w-16 shrink-0">
                      {format(parseISO(item.due_date), 'dd/MM', { locale: ptBR })}
                    </span>
                    <Badge
                      className={`text-[10px] px-2 ${item.type === 'receber' ? 'bg-emerald-500/10 text-emerald-700 border-emerald-500/30' : 'bg-red-500/10 text-red-700 border-red-500/30'}`}
                      variant="outline"
                    >
                      {item.type === 'receber' ? 'Receber' : 'Pagar'}
                    </Badge>
                    <span className="text-sm flex-1 truncate">{item.description}</span>
                    <StatusBadge status={item.status} />
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </section>

      {/* Fluxo de Caixa Futuro - Lazy loaded */}
      <Suspense fallback={<div className="h-32 bg-muted animate-pulse rounded-xl" />}>
        <FluxoCaixaFuturo />
      </Suspense>
    </div>
  );
}

function FinanceRow({ item }: { item: FinanceItem }) {
  return (
    <div className="flex items-center justify-between p-2.5 rounded-lg border border-border/30 bg-muted/10">
      <span className="text-sm truncate flex-1">{item.description}</span>
      <div className="flex items-center gap-2 shrink-0">
        <StatusBadge status={item.status} />
      </div>
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const config: Record<string, { label: string; cls: string }> = {
    pago: { label: 'Pago', cls: 'bg-emerald-500/10 text-emerald-700 border-emerald-500/30' },
    pendente: { label: 'Pendente', cls: 'bg-amber-500/10 text-amber-700 border-amber-500/30' },
    atrasado: { label: 'Atrasado', cls: 'bg-red-500/10 text-red-700 border-red-500/30' },
  };
  const c = config[status] || config.pendente;
  return <Badge variant="outline" className={`text-[10px] ${c.cls}`}>{c.label}</Badge>;
}

function EmptyState({ label }: { label: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-8 text-muted-foreground">
      <Inbox className="h-8 w-8 mb-2 opacity-40" />
      <p className="text-xs">{label}</p>
    </div>
  );
}
