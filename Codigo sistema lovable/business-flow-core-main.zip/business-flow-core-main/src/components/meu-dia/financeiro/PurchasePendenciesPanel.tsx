import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Collapsible, CollapsibleTrigger, CollapsibleContent } from '@/components/ui/collapsible';
import { ProcessPendency } from '@/hooks/useFinanceiroGestoraData';
import { format, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Package, ChevronDown, ChevronUp, ExternalLink, Calendar, CheckCircle2 } from 'lucide-react';

interface PurchasePendenciesPanelProps {
  pendencies: ProcessPendency[];
}

const STATUS_LABELS: Record<string, string> = {
  NOVA_SOLICITACAO: 'Nova',
  AGUARDANDO_COMPRADOR: 'Aguardando comprador',
  AGUARDANDO_APROVACAO_SOLICITANTE: 'Aguardando aprovação',
  AGUARDANDO_ENTREGA_FORNECEDOR: 'Aguardando entrega',
  AGUARDANDO: 'Aguardando resposta',
  RECEBIDO: 'Recebido',
  ABERTA: 'Aberta',
};

export function PurchasePendenciesPanel({ pendencies }: PurchasePendenciesPanelProps) {
  const navigate = useNavigate();
  const purchasePendencies = pendencies.filter(p => p.source === 'solicitacoes' || p.source === 'cotacoes');
  const count = purchasePendencies.length;
  const [open, setOpen] = useState(count > 0);

  return (
    <Collapsible open={open} onOpenChange={setOpen}>
      <Card className="border-border/50">
        <CollapsibleTrigger asChild>
          <CardHeader className="pb-2 cursor-pointer hover:bg-muted/30 transition-colors rounded-t-lg">
            <CardTitle className="text-base flex items-center gap-2">
              <Package className="h-5 w-5 text-blue-500" />
              Pendências no Módulo de Compras
              <Badge variant={count > 0 ? 'destructive' : 'secondary'} className="ml-2">{count}</Badge>
              <span className="ml-auto">
                {open ? <ChevronUp className="h-4 w-4 text-muted-foreground" /> : <ChevronDown className="h-4 w-4 text-muted-foreground" />}
              </span>
            </CardTitle>
          </CardHeader>
        </CollapsibleTrigger>
        <CollapsibleContent>
          <CardContent className="pt-0 space-y-2">
            {count === 0 ? (
              <div className="flex items-center justify-center gap-2 py-6 text-emerald-600">
                <CheckCircle2 className="h-5 w-5" />
                <span className="text-sm font-medium">Nenhuma pendência de compras no momento</span>
              </div>
            ) : (
              <>
                <div className="space-y-2 max-h-[350px] overflow-y-auto">
                  {purchasePendencies.map(item => (
                    <div
                      key={item.id}
                      className="p-3 rounded-lg border border-border/40 bg-background/60 hover:bg-muted/30 transition-colors"
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm font-medium truncate flex-1">{item.title}</span>
                        <Badge variant="outline" className="text-[10px] shrink-0 ml-2">
                          {STATUS_LABELS[item.status] || item.status}
                        </Badge>
                      </div>
                      <div className="flex flex-wrap items-center gap-3 text-xs text-muted-foreground mt-1.5">
                        {item.solicitante_nome && (
                          <span>Solicitante: <strong className="text-foreground/80">{item.solicitante_nome}</strong></span>
                        )}
                        {item.data_solicitacao && (
                          <span className="flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            {format(parseISO(item.data_solicitacao), 'dd/MM/yyyy', { locale: ptBR })}
                          </span>
                        )}
                        {item.due_date && (
                          <span className="flex items-center gap-1">
                            Prazo: {format(parseISO(item.due_date), 'dd/MM/yyyy', { locale: ptBR })}
                          </span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
                <div className="pt-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="w-full gap-2"
                    onClick={() => navigate('/compras')}
                  >
                    <ExternalLink className="h-4 w-4" />
                    Ver no módulo de compras
                  </Button>
                </div>
              </>
            )}
          </CardContent>
        </CollapsibleContent>
      </Card>
    </Collapsible>
  );
}
