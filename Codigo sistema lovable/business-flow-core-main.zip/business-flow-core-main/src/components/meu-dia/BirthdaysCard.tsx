import { Cake, AlertCircle, ChevronRight, User } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useBirthdaysData, BirthdayRecord, IncompleteBirthday } from '@/hooks/useBirthdaysData';
import { Skeleton } from '@/components/ui/skeleton';
import { cn } from '@/lib/utils';

interface Props {
  sellerId: string | null;
}

function getBadgeText(days: number): string {
  if (days === 0) return 'Hoje';
  if (days === 1) return 'Amanhã';
  return `Em ${days} dias`;
}

export function BirthdaysCard({ sellerId }: Props) {
  const { birthdays, incompleteBirthdays, loading } = useBirthdaysData(sellerId, 7);

  if (loading) {
    return (
      <div className="bg-card border border-border rounded-xl shadow-hh-sm p-5">
        <Skeleton className="h-5 w-40" />
        <Skeleton className="h-16 w-full mt-3" />
      </div>
    );
  }

  const hasUpcoming = birthdays.length > 0;
  const hasIncomplete = incompleteBirthdays.length > 0;
  if (!hasUpcoming && !hasIncomplete) return null;

  return (
    <div className="bg-card border border-border rounded-xl shadow-hh-sm p-5">
      <div className="flex items-center gap-2 mb-4">
        <span className="text-[11px] uppercase tracking-[0.08em] font-semibold text-muted-foreground">Aniversários</span>
        {hasUpcoming && <span className="hh-badge-accent">{birthdays.length}</span>}
      </div>

      {hasUpcoming && (
        <div className="space-y-1">
          {birthdays.slice(0, 5).map((birthday) => (
            <BirthdayItem key={`${birthday.type}-${birthday.id}`} birthday={birthday} />
          ))}
          {birthdays.length > 5 && (
            <p className="text-[11px] text-center pt-1 text-muted-foreground">+{birthdays.length - 5} outros</p>
          )}
        </div>
      )}

      {hasIncomplete && (
        <div className="flex items-start gap-2 p-3 rounded-lg mt-3 bg-muted border border-border">
          <AlertCircle className="w-3.5 h-3.5 mt-0.5 flex-shrink-0 text-status-warning" />
          <div className="flex-1 min-w-0">
            <p className="text-[12px] font-medium text-foreground">
              {incompleteBirthdays.length} cadastro{incompleteBirthdays.length > 1 ? 's' : ''} incompleto{incompleteBirthdays.length > 1 ? 's' : ''}
            </p>
            <div className="mt-1 flex flex-wrap gap-1">
              {incompleteBirthdays.slice(0, 3).map((item) => (
                <Link key={`incomplete-${item.type}-${item.id}`}
                  to={`/clients/${item.type === 'buyer' ? item.client_id : item.id}`}
                  className="text-[11px] underline text-primary">
                  Completar
                </Link>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function BirthdayItem({ birthday }: { birthday: BirthdayRecord }) {
  const linkTo = birthday.type === 'buyer' && birthday.client_id
    ? `/clients/${birthday.client_id}`
    : `/clients/${birthday.id}`;

  return (
    <Link to={linkTo}
      className="flex items-center gap-3 p-2.5 rounded-lg border border-border transition-all cursor-pointer group bg-card hover:border-border/80 hover:shadow-hh-sm">
      <div className="w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0 bg-muted">
        {birthday.type === 'buyer' ? <User className="w-3.5 h-3.5 text-muted-foreground" /> : <Cake className="w-3.5 h-3.5 text-muted-foreground" />}
      </div>
      <div className="flex-1 min-w-0">
        <p className="font-medium text-[13px] truncate text-foreground">{birthday.name}</p>
        <p className="text-[11px] text-muted-foreground">
          {String(birthday.birthday_day).padStart(2, '0')}/{String(birthday.birthday_month).padStart(2, '0')}
          {birthday.type === 'buyer' && <span className="ml-1">Comprador</span>}
        </p>
      </div>
      <div className="flex items-center gap-2">
        <span className={cn(
          "text-[11px] font-semibold px-2 py-0.5 rounded",
          birthday.daysUntil === 0 ? 'hh-badge-danger' : 'hh-badge-neutral'
        )}>
          {getBadgeText(birthday.daysUntil)}
        </span>
        <ChevronRight className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 transition-opacity text-muted-foreground" />
      </div>
    </Link>
  );
}
