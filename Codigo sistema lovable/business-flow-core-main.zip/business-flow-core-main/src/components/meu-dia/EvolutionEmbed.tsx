import { useState, useEffect, useMemo, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Bird, Loader2, Settings2 } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { isOwnerEmail } from '@/lib/utils';
import { usePermissions } from '@/hooks/usePermissions';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent } from '@/components/ui/tabs';
import { EvolutionPageHeader } from '@/components/evolution/EvolutionPageHeader';
import { EvolutionSellerBar } from '@/components/evolution/EvolutionSellerBar';
import { EvolutionTabs } from '@/components/evolution/EvolutionTabs';
import { PerformanceTab } from '@/components/evolution/tabs/PerformanceTab';
import { CommissionLevelTab } from '@/components/evolution/tabs/CommissionLevelTab';
import { CampaignsTab } from '@/components/evolution/tabs/CampaignsTab';
import { RulesTab } from '@/components/evolution/tabs/RulesTab';
import { useEvolutionData } from '@/hooks/useEvolutionData';
import { useSellerMetrics } from '@/hooks/useSellerMetrics';
import { useCategoryEligibility } from '@/hooks/useCategoryEligibility';
import { usePolicyAcceptance } from '@/hooks/usePolicyAcceptance';
import { format, subMonths, addMonths } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface Seller {
  id: string;
  name: string;
  role: string;
}

export function EvolutionEmbed() {
  const navigate = useNavigate();
  const { user, seller, isAdmin, isOwner } = useAuth();
  const { canAccessEvolutionTab } = usePermissions();
  const currentSellerId = seller?.id || null;
  const [sellers, setSellers] = useState<Seller[]>([]);
  const [selectedSellerId, setSelectedSellerId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState('performance');
  const [selectedDate, setSelectedDate] = useState(new Date());

  const handleTabChange = (tab: string) => setActiveTab(tab);

  const selectedMonth = selectedDate.getMonth() + 1;
  const selectedYear = selectedDate.getFullYear();
  const isCurrentMonth = selectedMonth === new Date().getMonth() + 1 && selectedYear === new Date().getFullYear();

  const {
    level, errors, dailyActivities, salesByMargin,
    currentMonthSales, currentMonthCalls, currentMonthWhatsapp,
    workDaysInMonth, workDaysPassed, previousMonthMet, stars,
    loading, refetch
  } = useEvolutionData(selectedSellerId, selectedMonth, selectedYear);

  const {
    metrics, contactStats, activityRanking, qualityRanking,
    salesRanking, sellerRank, loading: metricsLoading,
  } = useSellerMetrics(selectedSellerId, selectedMonth, selectedYear);

  const { categoryEligibility } = useCategoryEligibility(selectedSellerId, selectedMonth, selectedYear);
  const { hasAcceptedActivePolicy, activePolicy } = usePolicyAcceptance();

  const handlePreviousMonth = () => setSelectedDate(prev => subMonths(prev, 1));
  const handleNextMonth = () => {
    const next = addMonths(selectedDate, 1);
    if (next <= new Date()) setSelectedDate(next);
  };
  const handleCurrentMonth = () => setSelectedDate(new Date());

  useEffect(() => {
    const fetchSellers = async () => {
      const { data } = await supabase
        .from('sellers')
        .select('id, name, role')
        .eq('role', 'vendedor')
        .or('status.eq.ATIVO,status.is.null')
        .order('name');
      
      if (data) {
        setSellers(data);
        if (!selectedSellerId) {
          if (isOwnerEmail(user?.email)) {
            setSelectedSellerId(null);
          } else if (isAdmin) {
            setSelectedSellerId(data[0]?.id || null);
          } else {
            setSelectedSellerId(currentSellerId);
          }
        }
      }
    };
    fetchSellers();
  }, [currentSellerId, isAdmin, selectedSellerId, user?.email]);

  const selectedSeller = sellers.find(s => s.id === selectedSellerId);

  const alerts = useMemo(() => {
    if (!level) return [];
    const alertList: any[] = [];
    const today = new Date();
    const todayStr = format(today, 'yyyy-MM-dd');
    const emptyDays = dailyActivities.filter(d => d.date <= todayStr && d.total === 0).length;
    if (emptyDays >= 3) {
      alertList.push({ id: 'critical-productivity', type: 'danger', title: 'Execução Crítica', description: `${emptyDays} dias sem atividade registrada`, action: 'Bloqueia qualquer benefício' });
    } else if (emptyDays >= 1) {
      alertList.push({ id: 'empty-days-warning', type: 'warning', title: 'Dias Vazios', description: `${emptyDays} dia(s) sem atividade registrada`, action: 'Dias sem atividade contam como falha' });
    }
    if (errors.length === 3) {
      alertList.push({ id: 'error-warning', type: 'warning', title: 'Erro Próximo do Limite', description: '3 erros registrados. O próximo bloqueia a premiação.' });
    }
    if (errors.length >= 4) {
      alertList.push({ id: 'error-blocked', type: 'danger', title: 'Premiação Bloqueada', description: `${errors.length} erros este mês. Premiação perdida.` });
    }
    const salesProgress = (currentMonthSales / (level.monthly_sales_target || 30000)) * 100;
    const expectedProgress = (workDaysPassed / workDaysInMonth) * 100;
    if (salesProgress < expectedProgress * 0.7 && workDaysPassed > 5) {
      alertList.push({ id: 'sales-behind', type: 'warning', title: 'Vendas Abaixo do Esperado', description: `${salesProgress.toFixed(0)}% da meta com ${expectedProgress.toFixed(0)}% do mês`, action: 'Risco de perder sequência' });
    }
    return alertList;
  }, [level, errors, dailyActivities, currentMonthSales, workDaysPassed, workDaysInMonth]);

  const evolutionStatus = useMemo(() => {
    if (!level) return 'stable';
    if (level.consecutive_months_met > 0) return 'rising';
    if (level.consecutive_months_missed > 0) return 'falling';
    return 'stable';
  }, [level]);

  const monthsToPromotion = level ? Math.max(0, 2 - level.consecutive_months_met) : 2;
  const monthsToDemotion = level ? Math.max(0, 2 - level.consecutive_months_missed) : 2;
  const hasPolicyPending = !!activePolicy && !hasAcceptedActivePolicy;

  if (loading && !level) {
    return (
      <div className="flex items-center justify-center min-h-[40vh]">
        <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="flex flex-col items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-primary flex items-center justify-center shadow-lg shadow-primary/25">
            <Loader2 className="h-8 w-8 animate-spin text-white" />
          </div>
          <p className="text-muted-foreground">Carregando evolução...</p>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <EvolutionPageHeader sellerName={selectedSeller?.name} isAdmin={isAdmin} />

      <EvolutionSellerBar
        sellers={sellers}
        selectedSellerId={selectedSellerId}
        onSellerChange={setSelectedSellerId}
        isAdmin={isAdmin}
        showSetup={!level}
        onSetupClick={() => navigate('/settings?tab=goals')}
        onRefetch={refetch}
        selectedDate={selectedDate}
        onPreviousMonth={handlePreviousMonth}
        onNextMonth={handleNextMonth}
        onCurrentMonth={handleCurrentMonth}
        isCurrentMonth={isCurrentMonth}
        showPeriodSelector={true}
      />

      {!level ? (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center py-16 bg-primary/5 rounded-2xl border border-dashed border-primary/20"
        >
          <motion.div initial={{ scale: 0.5 }} animate={{ scale: 1 }} transition={{ type: 'spring', stiffness: 200 }} className="w-20 h-20 mx-auto rounded-2xl bg-primary/10 flex items-center justify-center mb-4">
            <Bird className="h-10 w-10 text-primary/50" />
          </motion.div>
          <h3 className="text-lg font-medium mb-2">Vendedor não configurado</h3>
          <p className="text-muted-foreground text-sm mb-4 max-w-md mx-auto">Configure o nível e metas deste vendedor em Configurações.</p>
          {isAdmin && (
            <Button onClick={() => navigate('/settings?tab=goals')} className="gap-2">
              <Settings2 className="h-4 w-4" /> Configurar em Ajustes
            </Button>
          )}
        </motion.div>
      ) : (
        <Tabs value={activeTab} onValueChange={handleTabChange} className="space-y-6">
          <EvolutionTabs activeTab={activeTab} onTabChange={handleTabChange} canAccessTab={canAccessEvolutionTab} hasPolicyPending={hasPolicyPending} />

          <TabsContent value="performance" className="mt-6">
            <PerformanceTab
              selectedSeller={selectedSeller}
              level={level}
              currentMonthSales={currentMonthSales}
              currentMonthCalls={currentMonthCalls}
              currentMonthWhatsapp={currentMonthWhatsapp}
              workDaysInMonth={workDaysInMonth}
              workDaysPassed={workDaysPassed}
              dailyActivities={dailyActivities}
              alerts={alerts}
              evolutionStatus={evolutionStatus as 'rising' | 'stable' | 'falling'}
              monthsToPromotion={monthsToPromotion}
              monthsToDemotion={monthsToDemotion}
              metrics={metrics}
              salesRanking={salesRanking}
              sellerRank={sellerRank.sales}
              isAdmin={isAdmin}
              selectedMonth={selectedMonth}
              selectedYear={selectedYear}
            />
          </TabsContent>

          <TabsContent value="commission" className="mt-6">
            <CommissionLevelTab
              level={level}
              errors={errors}
              salesByMargin={salesByMargin}
              sellerId={selectedSellerId!}
              sellerName={selectedSeller?.name || ''}
              month={selectedMonth}
              year={selectedYear}
              categoryEligibility={categoryEligibility}
              isAdmin={isAdmin}
              onRefetch={refetch}
              monthlyTarget={level?.monthly_sales_target || 0}
              currentMonthSales={currentMonthSales}
            />
          </TabsContent>

          <TabsContent value="campaigns" className="mt-6">
            <CampaignsTab sellerId={selectedSellerId!} sellerName={selectedSeller?.name || ''} />
          </TabsContent>

          <TabsContent value="rules" className="mt-6">
            <RulesTab />
          </TabsContent>
        </Tabs>
      )}
    </div>
  );
}
