import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { Tag } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface PendingClassificationAlertProps {
  sellerId: string | null;
}

export function PendingClassificationAlert({ sellerId }: PendingClassificationAlertProps) {
  const navigate = useNavigate();
  const [count, setCount] = useState(0);

  useEffect(() => {
    if (!sellerId) return;
    const fetchCount = async () => {
      // Get clients with pending classification that belong to this seller
      const { count: pendingCount } = await supabase
        .from('clients')
        .select('id', { count: 'exact', head: true })
        .eq('seller_id', sellerId)
        .eq('classification_status', 'PENDENTE')
        .eq('is_deleted', false);
      setCount(pendingCount || 0);
    };
    fetchCount();
  }, [sellerId]);

  if (count === 0) return null;

  return (
    <div className="flex items-center gap-3 rounded-lg border border-amber-500/30 bg-amber-500/5 px-4 py-3">
      <div className="flex-shrink-0 w-9 h-9 rounded-lg bg-amber-500/10 flex items-center justify-center">
        <Tag className="h-4 w-4 text-amber-600 dark:text-amber-400" />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium text-foreground">
          {count} cliente{count !== 1 ? 's' : ''} aguardando classificação
        </p>
        <p className="text-xs text-muted-foreground">
          Classifique para contabilizar nas suas metas
        </p>
      </div>
      <Button
        variant="outline"
        size="sm"
        className="text-xs border-amber-500/30 text-amber-700 dark:text-amber-400 hover:bg-amber-500/10"
        onClick={() => navigate('/orders')}
      >
        Classificar agora
      </Button>
    </div>
  );
}
