import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Separator } from '@/components/ui/separator';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { format, parseISO, subDays } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { toast } from 'sonner';
import {
  Package,
  Truck,
  AlertTriangle,
  ClipboardCheck,
  CheckCircle2,
  Loader2,
  Clock,
  ChevronRight,
  Plus,
  XCircle,
  BarChart3,
  RotateCw,
  Boxes,
  Bell,
  ExternalLink,
} from 'lucide-react';

// ─── Types ────────────────────────────────────────────────────────

interface TaskStep {
  label: string;
  done: boolean;
  done_at: string | null;
}

interface LogisticaTask {
  id: string;
  notes: string | null;
  task_date: string;
  status: string;
  priority: string;
  task_steps: TaskStep[] | null;
  client_name: string;
  logistics_type: string | null;
  task_category: string | null;
  operational_error: boolean;
  error_note: string | null;
  client_id: string | null;
  created_by_seller_id: string | null;
  assigned_to_seller_id: string | null;
  source_routine_id: string | null;
  // Linking fields
  source_module: string | null;
  related_type: string | null;
  related_id: string | null;
  created_by_trigger: boolean;
}

interface Routine {
  id: string;
  title: string;
  task_type: string;
  frequency: string;
  day_of_week: number | null;
  day_of_month: number | null;
  default_bucket: string;
  default_priority: string;
  active: boolean;
  default_steps: TaskStep[] | null;
}

// ─── Constants ────────────────────────────────────────────────────

const DEFAULT_LOGISTICA_STEPS: TaskStep[] = [
  { label: 'Conferir produto', done: false, done_at: null },
  { label: 'Conferir quantidade', done: false, done_at: null },
  { label: 'Conferir nota', done: false, done_at: null },
  { label: 'Separar', done: false, done_at: null },
  { label: 'Embalar', done: false, done_at: null },
  { label: 'Liberar/Despachar', done: false, done_at: null },
];

const LOGISTICS_TYPES = [
  { value: 'CONFERENCIA', label: 'Conferência', icon: Package },
  { value: 'SEPARACAO', label: 'Separação', icon: Truck },
  { value: 'EMBALAGEM', label: 'Embalagem', icon: Boxes },
  { value: 'ESTOQUE', label: 'Estoque', icon: ClipboardCheck },
  { value: 'AVISO_COMPRAS', label: 'Aviso Compras', icon: Bell },
  { value: 'CLUBE_VIP', label: 'Clube VIP', icon: CheckCircle2 },
  { value: 'OUTRO', label: 'Outro', icon: Package },
];

// ─── Component ────────────────────────────────────────────────────

// Sub-component for origin button
function OriginButton({ sourceModule, relatedId }: { sourceModule: string; relatedId: string }) {
  const navigate = useNavigate();
  const moduleLabels: Record<string, string> = { compras: 'Compras', cotacao: 'Cotação', entregas: 'Entregas' };
  
  const handleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (sourceModule === 'cotacao') {
      navigate(`/compras?cotacao=${relatedId}`);
    } else {
      navigate(`/compras?solicitacao=${relatedId}`);
    }
  };

  return (
    <Button variant="outline" size="sm" className="gap-1.5 h-7 text-xs" onClick={handleClick}>
      <ExternalLink className="h-3 w-3" />
      {moduleLabels[sourceModule] || 'Origem'}
    </Button>
  );
}

export function MeuDiaLogistica() {
  const { seller } = useAuth();
  const [tasks, setTasks] = useState<LogisticaTask[]>([]);
  const [routines, setRoutines] = useState<Routine[]>([]);
  const [loading, setLoading] = useState(true);
  const [expandedTaskId, setExpandedTaskId] = useState<string | null>(null);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showRoutineModal, setShowRoutineModal] = useState(false);
  const [filterView, setFilterView] = useState<string | null>(null);
  const [generatingRoutines, setGeneratingRoutines] = useState(false);

  // Quick create state
  const [newTitle, setNewTitle] = useState('');
  const [newType, setNewType] = useState('CONFERENCIA');
  const [newDueDate, setNewDueDate] = useState('');
  const [newPriority, setNewPriority] = useState('media');
  const [creating, setCreating] = useState(false);

  // New routine state
  const [routineTitle, setRoutineTitle] = useState('');
  const [routineType, setRoutineType] = useState('OUTRO');
  const [routineFreq, setRoutineFreq] = useState('DIARIA');
  const [routinePriority, setRoutinePriority] = useState('media');
  const [routineBucket, setRoutineBucket] = useState('HOJE');
  const [routineDayOfWeek, setRoutineDayOfWeek] = useState<number | null>(null);
  const [routineDayOfMonth, setRoutineDayOfMonth] = useState<number | null>(null);
  const [creatingRoutine, setCreatingRoutine] = useState(false);

  // Quality KPIs
  const [kpis, setKpis] = useState({ onTimePercent: 0, overdueOpen: 0, errorCount: 0, completedCount: 0 });
  const [recentErrors, setRecentErrors] = useState<{ id: string; notes: string; date: string }[]>([]);

  const today = new Date().toISOString().split('T')[0];

  // ── Fetch all data ──────────────────────────────────────────────
  const fetchData = useCallback(async () => {
    if (!seller?.id) return;
    setLoading(true);
    try {
      // Fetch logistics tasks (category LOGISTICA or assigned to this user)
      const { data: taskData } = await supabase
        .from('tasks')
        .select(`
          id, notes, task_date, status, priority, task_steps, logistics_type,
          task_category, operational_error, error_note,
          client_id, created_by_seller_id, assigned_to_seller_id, source_routine_id,
          source_module, related_type, related_id, created_by_trigger,
          clients!tasks_client_id_fkey(company_name)
        `)
        .eq('is_deleted', false)
        .neq('status', 'concluida')
        .neq('status', 'cancelada')
        .or(`created_by_seller_id.eq.${seller.id},assigned_to_seller_id.eq.${seller.id}`)
        .order('task_date', { ascending: true });

      const formatted: LogisticaTask[] = (taskData || []).map((t: any) => ({
        id: t.id,
        notes: t.notes,
        task_date: t.task_date,
        status: t.status,
        priority: t.priority,
        task_steps: t.task_steps as TaskStep[] | null,
        client_name: t.clients?.company_name || 'N/A',
        logistics_type: t.logistics_type,
        task_category: t.task_category,
        operational_error: t.operational_error || false,
        error_note: t.error_note,
        client_id: t.client_id,
        created_by_seller_id: t.created_by_seller_id,
        assigned_to_seller_id: t.assigned_to_seller_id,
        source_routine_id: t.source_routine_id,
        source_module: t.source_module || null,
        related_type: t.related_type || null,
        related_id: t.related_id || null,
        created_by_trigger: t.created_by_trigger || false,
      }));
      setTasks(formatted);

      // Fetch routines
      const { data: routineData } = await supabase
        .from('routines')
        .select('id, title, task_type, frequency, default_bucket, default_priority, active, default_steps')
        .or(`assigned_to_seller_id.eq.${seller.id},assigned_to_user_id.eq.${seller.id}`)
        .eq('task_category', 'LOGISTICA')
        .order('created_at', { ascending: true });

      setRoutines((routineData || []).map((r: any) => ({
        ...r,
        default_steps: r.default_steps as TaskStep[] | null,
      })));

      // KPIs (30 days)
      const thirtyAgo = subDays(new Date(), 30).toISOString();
      
      const { data: completedTasks } = await supabase
        .from('tasks')
        .select('id, completed_at, task_date')
        .or(`created_by_seller_id.eq.${seller.id},assigned_to_seller_id.eq.${seller.id}`)
        .eq('status', 'concluida')
        .eq('is_deleted', false)
        .gte('completed_at', thirtyAgo);

      const completed = completedTasks || [];
      const onTime = completed.filter(t => t.completed_at && t.task_date && t.completed_at.split('T')[0] <= t.task_date);

      const { count: overdueCount } = await supabase
        .from('tasks')
        .select('id', { count: 'exact', head: true })
        .or(`created_by_seller_id.eq.${seller.id},assigned_to_seller_id.eq.${seller.id}`)
        .neq('status', 'concluida')
        .neq('status', 'cancelada')
        .eq('is_deleted', false)
        .lt('task_date', today);

      const { count: errCount } = await supabase
        .from('tasks')
        .select('id', { count: 'exact', head: true })
        .or(`created_by_seller_id.eq.${seller.id},assigned_to_seller_id.eq.${seller.id}`)
        .eq('operational_error', true)
        .eq('is_deleted', false)
        .gte('completed_at', thirtyAgo);

      setKpis({
        onTimePercent: completed.length > 0 ? Math.round((onTime.length / completed.length) * 100) : 0,
        overdueOpen: overdueCount || 0,
        errorCount: errCount || 0,
        completedCount: completed.length,
      });

      // Recent errors
      const { data: errorData } = await supabase
        .from('tasks')
        .select('id, notes, completed_at')
        .or(`created_by_seller_id.eq.${seller.id},assigned_to_seller_id.eq.${seller.id}`)
        .eq('operational_error', true)
        .eq('is_deleted', false)
        .order('completed_at', { ascending: false })
        .limit(5);

      setRecentErrors((errorData || []).map((e: any) => ({
        id: e.id,
        notes: e.notes || 'Sem descrição',
        date: e.completed_at || '',
      })));
    } catch (error) {
      console.error('Error fetching logistica data:', error);
    } finally {
      setLoading(false);
    }
  }, [seller?.id, today]);

  useEffect(() => { fetchData(); }, [fetchData]);

  // ── Auto-generate routine tasks (1x/day) ───────────────────────
  const generateRoutineTasks = useCallback(async () => {
    if (!seller?.id) return;
    setGeneratingRoutines(true);
    try {
      const activeRoutines = routines.filter(r => r.active);
      if (activeRoutines.length === 0) {
        toast.info('Nenhuma rotina ativa');
        setGeneratingRoutines(false);
        return;
      }

      // Check which routines already have tasks today
      const routineIds = activeRoutines.map(r => r.id);
      const { data: existingToday } = await supabase
        .from('tasks')
        .select('source_routine_id')
        .eq('task_date', today)
        .eq('is_deleted', false)
        .in('source_routine_id', routineIds);

      const alreadyCreated = new Set((existingToday || []).map((t: any) => t.source_routine_id));

      // Determine day of week (0=Sunday) and day of month
      const now = new Date();
      const dayOfWeek = now.getDay();
      const dayOfMonth = now.getDate();

      let created = 0;
      for (const routine of activeRoutines) {
        if (alreadyCreated.has(routine.id)) continue;

        // Check frequency
        if (routine.frequency === 'SEMANAL' && dayOfWeek !== 1) continue; // Monday
        if (routine.frequency === 'MENSAL' && dayOfMonth !== 1) continue; // 1st of month

        const uniqueKey = `routine_${routine.id}_${today}`;
        const steps = routine.default_steps || DEFAULT_LOGISTICA_STEPS;

        const { error } = await supabase.from('tasks').insert({
          notes: routine.title,
          task_date: today,
          priority: routine.default_priority || 'media',
          status: 'pendente',
          contact_type: 'ligacao',
          contact_reason: 'RETORNO',
          task_category: 'LOGISTICA',
          logistics_type: routine.task_type,
          task_steps: steps as any,
          created_by_seller_id: seller.id,
          assigned_to_seller_id: seller.id,
          source_routine_id: routine.id,
          is_deleted: false,
          unique_key: uniqueKey,
          client_id: '00000000-0000-0000-0000-000000000000',
        } as any);

        if (!error) created++;
      }

      if (created > 0) {
        toast.success(`${created} tarefa(s) de rotina criada(s)`);
        fetchData();
      } else {
        toast.info('Todas as rotinas de hoje já foram geradas');
      }
    } catch (err) {
      console.error('Error generating routines:', err);
      toast.error('Erro ao gerar rotinas');
    } finally {
      setGeneratingRoutines(false);
    }
  }, [seller?.id, routines, today, fetchData]);

  // Auto-generate on first load
  useEffect(() => {
    if (!loading && routines.length > 0 && seller?.id) {
      generateRoutineTasks();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loading, routines.length > 0, seller?.id]);

  // ── Step toggle ─────────────────────────────────────────────────
  const handleStepToggle = async (taskId: string, stepIndex: number) => {
    const task = tasks.find(t => t.id === taskId);
    if (!task) return;

    const steps = [...(task.task_steps || DEFAULT_LOGISTICA_STEPS)];
    steps[stepIndex] = {
      ...steps[stepIndex],
      done: !steps[stepIndex].done,
      done_at: !steps[stepIndex].done ? new Date().toISOString() : null,
    };

    const { error } = await supabase
      .from('tasks')
      .update({ task_steps: steps as any })
      .eq('id', taskId);

    if (error) {
      toast.error('Erro ao atualizar passo');
      return;
    }
    setTasks(prev => prev.map(t => t.id === taskId ? { ...t, task_steps: steps } : t));
  };

  // ── Complete task ───────────────────────────────────────────────
  const handleCompleteTask = async (taskId: string) => {
    const task = tasks.find(t => t.id === taskId);
    if (!task) return;

    const steps = task.task_steps || [];
    const pendingSteps = steps.filter(s => !s.done);
    if (pendingSteps.length > 0) {
      toast.error(`${pendingSteps.length} passo(s) pendente(s) — complete o checklist primeiro`);
      return;
    }

    const { error } = await supabase
      .from('tasks')
      .update({ status: 'concluida', completed_at: new Date().toISOString() })
      .eq('id', taskId);

    if (error) {
      toast.error('Erro ao concluir tarefa');
      return;
    }
    toast.success('Tarefa concluída!');
    fetchData();
  };

  // ── Quick create ────────────────────────────────────────────────
  const handleQuickCreate = async () => {
    if (!newTitle.trim() || !newDueDate) {
      toast.error('Preencha título e data');
      return;
    }
    setCreating(true);
    try {
      const uniqueKey = `logistica_${seller?.id}_${Date.now()}`;
      const { error } = await supabase.from('tasks').insert({
        notes: newTitle.trim(),
        task_date: newDueDate,
        priority: newPriority,
        status: 'pendente',
        contact_type: 'ligacao',
        contact_reason: 'RETORNO',
        task_category: 'LOGISTICA',
        logistics_type: newType,
        task_steps: DEFAULT_LOGISTICA_STEPS as any,
        created_by_seller_id: seller?.id,
        assigned_to_seller_id: seller?.id,
        is_deleted: false,
        unique_key: uniqueKey,
        client_id: '00000000-0000-0000-0000-000000000000',
      } as any);

      if (error) throw error;
      toast.success('Tarefa logística criada');
      setShowCreateModal(false);
      setNewTitle('');
      setNewDueDate('');
      setNewPriority('media');
      setNewType('CONFERENCIA');
      fetchData();
    } catch (err: any) {
      toast.error(err.message || 'Erro ao criar tarefa');
    } finally {
      setCreating(false);
    }
  };

  // ── Create routine ──────────────────────────────────────────────
  const handleCreateRoutine = async () => {
    if (!routineTitle.trim()) {
      toast.error('Preencha o título da rotina');
      return;
    }
    if (routineFreq === 'SEMANAL' && routineDayOfWeek === null) {
      toast.error('Selecione o dia da semana');
      return;
    }
    if (routineFreq === 'MENSAL' && routineDayOfMonth === null) {
      toast.error('Selecione o dia do mês');
      return;
    }
    setCreatingRoutine(true);
    try {
      const { error } = await supabase.from('routines').insert({
        title: routineTitle.trim(),
        task_category: 'LOGISTICA',
        task_type: routineType,
        frequency: routineFreq,
        day_of_week: routineFreq === 'SEMANAL' ? routineDayOfWeek : null,
        day_of_month: routineFreq === 'MENSAL' ? routineDayOfMonth : null,
        default_bucket: routineBucket,
        default_priority: routinePriority,
        assigned_to_seller_id: seller?.id,
        assigned_to_user_id: seller?.id,
        active: true,
      } as any);

      if (error) throw error;
      toast.success('Rotina criada');
      setShowRoutineModal(false);
      setRoutineTitle('');
      setRoutineType('OUTRO');
      setRoutineFreq('DIARIA');
      setRoutinePriority('media');
      setRoutineBucket('HOJE');
      setRoutineDayOfWeek(null);
      setRoutineDayOfMonth(null);
      fetchData();
    } catch (err: any) {
      toast.error(err.message || 'Erro ao criar rotina');
    } finally {
      setCreatingRoutine(false);
    }
  };

  // ── Toggle routine active ───────────────────────────────────────
  const toggleRoutineActive = async (routineId: string, active: boolean) => {
    const { error } = await supabase
      .from('routines')
      .update({ active: !active })
      .eq('id', routineId);
    if (error) {
      toast.error('Erro ao alterar rotina');
      return;
    }
    setRoutines(prev => prev.map(r => r.id === routineId ? { ...r, active: !active } : r));
  };

  // ── Computed filtered lists ─────────────────────────────────────
  const conferencias = tasks.filter(t => t.logistics_type === 'CONFERENCIA');
  const separacao = tasks.filter(t => t.logistics_type === 'SEPARACAO' || t.logistics_type === 'EMBALAGEM');
  const estoque = tasks.filter(t => t.logistics_type === 'ESTOQUE');
  const atrasadas = tasks.filter(t => t.task_date < today);

  const displayTasks = filterView === 'conferencias' ? conferencias
    : filterView === 'separacao' ? separacao
    : filterView === 'estoque' ? estoque
    : filterView === 'atrasadas' ? atrasadas
    : [...tasks].sort((a, b) => {
        // Overdue first, then by priority, then by date
        const aOverdue = a.task_date < today ? 0 : 1;
        const bOverdue = b.task_date < today ? 0 : 1;
        if (aOverdue !== bOverdue) return aOverdue - bOverdue;
        const prio: Record<string, number> = { alta: 0, media: 1, baixa: 2 };
        const aPrio = prio[a.priority] ?? 1;
        const bPrio = prio[b.priority] ?? 1;
        if (aPrio !== bPrio) return aPrio - bPrio;
        return a.task_date.localeCompare(b.task_date);
      });

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="animate-spin h-8 w-8 text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Meu Dia — Logística</h1>
          <p className="text-muted-foreground text-sm mt-1">
            {format(new Date(), "EEEE, dd 'de' MMMM", { locale: ptBR })}
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={generateRoutineTasks} disabled={generatingRoutines} className="gap-2">
            {generatingRoutines ? <Loader2 className="h-4 w-4 animate-spin" /> : <RotateCw className="h-4 w-4" />}
            Gerar rotinas de hoje
          </Button>
          <Button onClick={() => setShowCreateModal(true)} className="gap-2">
            <Plus className="h-4 w-4" />
            Nova tarefa
          </Button>
        </div>
      </div>

      {/* BLOCO 1 — Painel de Urgência */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { key: 'conferencias', icon: Package, label: 'Conferências', count: conferencias.length, color: 'text-blue-600' },
          { key: 'separacao', icon: Truck, label: 'Separar / Embalar', count: separacao.length, color: 'text-emerald-600' },
          { key: 'estoque', icon: Boxes, label: 'Estoque', count: estoque.length, color: 'text-purple-600' },
          { key: 'atrasadas', icon: AlertTriangle, label: 'Atrasadas', count: atrasadas.length, color: 'text-red-600' },
        ].map(card => (
          <Card
            key={card.key}
            className={`cursor-pointer transition-all hover:shadow-md ${filterView === card.key ? 'ring-2 ring-primary' : ''}`}
            onClick={() => setFilterView(filterView === card.key ? null : card.key)}
          >
            <CardContent className="p-4 flex items-center gap-3">
              <card.icon className={`h-6 w-6 ${card.color}`} />
              <div className="flex-1">
                <p className="font-bold text-2xl">{card.count}</p>
                <p className="text-xs text-muted-foreground">{card.label}</p>
              </div>
              <ChevronRight className="h-4 w-4 text-muted-foreground" />
            </CardContent>
          </Card>
        ))}
      </div>

      {filterView && (
        <div className="flex items-center gap-2">
          <Badge variant="secondary" className="text-xs">
            Filtro: {filterView === 'conferencias' ? 'Conferências' : filterView === 'separacao' ? 'Separar/Embalar' : filterView === 'estoque' ? 'Estoque' : 'Atrasadas'}
          </Badge>
          <Button variant="ghost" size="sm" onClick={() => setFilterView(null)} className="text-xs h-6">
            Limpar filtro
          </Button>
        </div>
      )}

      {/* BLOCO 2 — Lista Principal "AGORA" */}
      <div>
        <h2 className="text-lg font-semibold mb-3 flex items-center gap-2">
          <ClipboardCheck className="h-5 w-5" />
          {filterView ? `Tarefas Filtradas (${displayTasks.length})` : `Agora — O que fazer (${displayTasks.length})`}
        </h2>
        <div className="space-y-3">
          {displayTasks.length === 0 ? (
            <Card>
              <CardContent className="py-8 text-center text-sm text-muted-foreground">
                {filterView ? 'Nenhuma tarefa nesta categoria' : 'Nenhuma tarefa pendente 🎉'}
              </CardContent>
            </Card>
          ) : (
            displayTasks.map(task => {
              const steps = task.task_steps && task.task_steps.length > 0 ? task.task_steps : DEFAULT_LOGISTICA_STEPS;
              const completedSteps = steps.filter(s => s.done).length;
              const totalSteps = steps.length;
              const isExpanded = expandedTaskId === task.id;
              const allDone = completedSteps === totalSteps;
              const isOverdue = task.task_date < today;
              const priorityColor = task.priority === 'alta' ? 'border-red-500/40 bg-red-500/5'
                : task.priority === 'media' ? 'border-amber-500/30' : '';

              const typeInfo = LOGISTICS_TYPES.find(t => t.value === task.logistics_type);

              return (
                <Card key={task.id} className={`transition-all ${priorityColor} ${isOverdue ? 'border-destructive/40 bg-destructive/5' : ''}`}>
                  <CardContent className="p-4">
                    <div
                      className="flex items-center gap-3 cursor-pointer"
                      onClick={() => setExpandedTaskId(isExpanded ? null : task.id)}
                    >
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                        allDone ? 'bg-emerald-500/10' : 'bg-muted'
                      }`}>
                        {allDone ? (
                          <CheckCircle2 className="h-5 w-5 text-emerald-600" />
                        ) : typeInfo ? (
                          <typeInfo.icon className="h-5 w-5 text-muted-foreground" />
                        ) : (
                          <ClipboardCheck className="h-5 w-5 text-muted-foreground" />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-sm truncate">{task.notes || task.client_name}</p>
                        <div className="flex items-center gap-2 text-xs text-muted-foreground mt-0.5 flex-wrap">
                          <span className="flex items-center gap-1">
                            <Clock className="h-3 w-3" />
                            {format(parseISO(task.task_date), 'dd/MM', { locale: ptBR })}
                          </span>
                          {typeInfo && (
                            <Badge variant="outline" className="text-[10px] px-1 py-0">
                              {typeInfo.label}
                            </Badge>
                          )}
                          {isOverdue && <Badge variant="destructive" className="text-[10px] px-1 py-0">Atrasada</Badge>}
                          {task.priority === 'alta' && <Badge className="text-[10px] px-1 py-0 bg-red-500">Alta</Badge>}
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant={allDone ? 'default' : 'secondary'} className="text-xs">
                          {completedSteps}/{totalSteps}
                        </Badge>
                        {allDone && (
                          <Button
                            size="sm"
                            className="bg-emerald-600 hover:bg-emerald-700 text-white h-8"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleCompleteTask(task.id);
                            }}
                          >
                            <CheckCircle2 className="h-4 w-4 mr-1" />
                            Concluir
                          </Button>
                        )}
                      </div>
                    </div>

                    {/* BLOCO 3 — Checklist visível ao expandir */}
                    {isExpanded && (
                      <div className="mt-4 space-y-2 border-t border-border/50 pt-3">
                        {steps.map((step, idx) => (
                          <div key={idx} className="flex items-center gap-3 py-1.5 px-1">
                            <Checkbox
                              checked={step.done}
                              onCheckedChange={() => handleStepToggle(task.id, idx)}
                            />
                            <span className={`text-sm flex-1 ${step.done ? 'line-through text-muted-foreground' : ''}`}>
                              {step.label}
                            </span>
                            {step.done && step.done_at && (
                              <span className="text-[10px] text-muted-foreground">
                                {format(parseISO(step.done_at), 'HH:mm')}
                              </span>
                            )}
                          </div>
                        ))}
                        <Separator className="my-2" />
                        <div className="flex items-center justify-between">
                          <p className="text-xs text-muted-foreground">
                            {task.client_name !== 'N/A' ? `${task.client_name} • ` : ''}{task.notes || 'Sem observação'}
                          </p>
                          {task.source_module && task.related_id && (
                            <OriginButton sourceModule={task.source_module} relatedId={task.related_id} />
                          )}
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              );
            })
          )}
        </div>
      </div>

      {/* BLOCO — Rotinas */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-base flex items-center gap-2">
              <RotateCw className="h-4 w-4" />
              Rotinas ({routines.filter(r => r.active).length} ativas)
            </CardTitle>
            <Button size="sm" variant="outline" onClick={() => setShowRoutineModal(true)} className="gap-1 h-7 text-xs">
              <Plus className="h-3 w-3" /> Nova Rotina
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-2">
          {routines.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-3">Nenhuma rotina configurada</p>
          ) : (
            routines.map(routine => {
              const typeInfo = LOGISTICS_TYPES.find(t => t.value === routine.task_type);
              return (
                <div key={routine.id} className="flex items-center justify-between py-2 px-2 rounded-lg hover:bg-muted/30">
                  <div className="flex items-center gap-3 flex-1 min-w-0">
                    <Switch
                      checked={routine.active}
                      onCheckedChange={() => toggleRoutineActive(routine.id, routine.active)}
                    />
                    <div className="min-w-0">
                      <p className={`text-sm font-medium truncate ${!routine.active ? 'text-muted-foreground line-through' : ''}`}>
                        {routine.title}
                      </p>
                      <div className="flex items-center gap-2 text-[10px] text-muted-foreground">
                        {typeInfo && <span>{typeInfo.label}</span>}
                        <span>• {routine.frequency === 'DIARIA' ? 'Diária' : routine.frequency === 'SEMANAL' ? `Semanal (${['Dom','Seg','Ter','Qua','Qui','Sex','Sáb'][routine.day_of_week ?? 0]})` : `Mensal (dia ${routine.day_of_month ?? '?'})`}</span>
                        <span>• {routine.default_priority}</span>
                        <span>• {routine.default_priority}</span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </CardContent>
      </Card>

      {/* BLOCO 4 — Qualidade Operacional */}
      <div>
        <h2 className="text-lg font-semibold mb-3 flex items-center gap-2">
          <BarChart3 className="h-5 w-5" />
          Qualidade Operacional — 30 dias
        </h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <Card className="border-emerald-500/20">
            <CardContent className="p-3 text-center">
              <p className="text-2xl font-bold text-emerald-600">{kpis.onTimePercent}%</p>
              <p className="text-xs text-muted-foreground mt-1">No prazo</p>
            </CardContent>
          </Card>
          <Card className="border-blue-500/20">
            <CardContent className="p-3 text-center">
              <p className="text-2xl font-bold">{kpis.completedCount}</p>
              <p className="text-xs text-muted-foreground mt-1">Concluídas</p>
            </CardContent>
          </Card>
          <Card className="border-red-500/20">
            <CardContent className="p-3 text-center">
              <p className="text-2xl font-bold text-red-600">{kpis.overdueOpen}</p>
              <p className="text-xs text-muted-foreground mt-1">Atrasadas abertas</p>
            </CardContent>
          </Card>
          <Card className="border-orange-500/20">
            <CardContent className="p-3 text-center">
              <p className="text-2xl font-bold text-orange-600">{kpis.errorCount}</p>
              <p className="text-xs text-muted-foreground mt-1">Erros operacionais</p>
            </CardContent>
          </Card>
        </div>

        {recentErrors.length > 0 && (
          <div className="mt-3">
            <p className="text-xs font-medium text-muted-foreground mb-2 flex items-center gap-1">
              <XCircle className="h-3 w-3" /> Últimos erros
            </p>
            <div className="space-y-1">
              {recentErrors.map(err => (
                <div key={err.id} className="flex items-center justify-between px-3 py-2 rounded bg-muted/30 text-sm">
                  <span className="truncate flex-1">{err.notes}</span>
                  {err.date && (
                    <span className="text-[10px] text-muted-foreground ml-2 shrink-0">
                      {format(parseISO(err.date), 'dd/MM', { locale: ptBR })}
                    </span>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* ── Quick Create Modal ─────────────────────────────────── */}
      <Dialog open={showCreateModal} onOpenChange={setShowCreateModal}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Package className="h-5 w-5" />
              Nova Tarefa Logística
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 pt-2">
            <div className="space-y-2">
              <Label>Tipo *</Label>
              <Select value={newType} onValueChange={setNewType}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {LOGISTICS_TYPES.map(t => (
                    <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Título *</Label>
              <Input value={newTitle} onChange={e => setNewTitle(e.target.value)} placeholder="Ex: Conferir NF 12345" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label>Data *</Label>
                <Input type="date" value={newDueDate} onChange={e => setNewDueDate(e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Prioridade</Label>
                <Select value={newPriority} onValueChange={setNewPriority}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="alta">Alta</SelectItem>
                    <SelectItem value="media">Média</SelectItem>
                    <SelectItem value="baixa">Baixa</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <Button onClick={handleQuickCreate} disabled={creating} className="w-full gap-2">
              {creating ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
              Criar Tarefa
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* ── New Routine Modal ──────────────────────────────────── */}
      <Dialog open={showRoutineModal} onOpenChange={setShowRoutineModal}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <RotateCw className="h-5 w-5" />
              Nova Rotina Logística
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 pt-2">
            <div className="space-y-2">
              <Label>Título *</Label>
              <Input value={routineTitle} onChange={e => setRoutineTitle(e.target.value)} placeholder="Ex: Conferir chegadas do dia" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label>Tipo</Label>
                <Select value={routineType} onValueChange={setRoutineType}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {LOGISTICS_TYPES.map(t => (
                      <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Frequência</Label>
                <Select value={routineFreq} onValueChange={setRoutineFreq}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="DIARIA">Diária</SelectItem>
                    <SelectItem value="SEMANAL">Semanal</SelectItem>
                    <SelectItem value="MENSAL">Mensal</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            {routineFreq === 'SEMANAL' && (
              <div className="space-y-2">
                <Label>Dia da Semana *</Label>
                <Select value={routineDayOfWeek !== null ? String(routineDayOfWeek) : ''} onValueChange={v => setRoutineDayOfWeek(Number(v))}>
                  <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
                  <SelectContent>
                    {['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'].map((d, i) => (
                      <SelectItem key={i} value={String(i)}>{d}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
            {routineFreq === 'MENSAL' && (
              <div className="space-y-2">
                <Label>Dia do Mês *</Label>
                <Input
                  type="number"
                  min={1}
                  max={31}
                  value={routineDayOfMonth || ''}
                  onChange={e => setRoutineDayOfMonth(e.target.value ? Number(e.target.value) : null)}
                  placeholder="1-31"
                />
              </div>
            )}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label>Prioridade</Label>
                <Select value={routinePriority} onValueChange={setRoutinePriority}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="alta">Alta</SelectItem>
                    <SelectItem value="media">Média</SelectItem>
                    <SelectItem value="baixa">Baixa</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Bucket</Label>
                <Select value={routineBucket} onValueChange={setRoutineBucket}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="HOJE">Hoje</SelectItem>
                    <SelectItem value="AMANHA">Amanhã</SelectItem>
                    <SelectItem value="SEMANA">Semana</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <Button onClick={handleCreateRoutine} disabled={creatingRoutine} className="w-full gap-2">
              {creatingRoutine ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
              Criar Rotina
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
