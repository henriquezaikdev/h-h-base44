import { useState, useCallback, useEffect } from 'react';
import { TasksErrorBoundary } from '@/components/meu-dia/TasksErrorFallback';
import { ProfileHubContent } from '@/components/profile/ProfileHubContent';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useSolicitacoes, useChangeStatus, STATUS_LABELS } from '@/hooks/useComprasData';
import { awardAdminXP, ADMIN_XP_TABLE } from '@/lib/adminXpUtils';
import { createSellerNotification } from '@/hooks/useSellerNotifications';
import { format, parseISO, differenceInSeconds } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { toast } from 'sonner';

import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Switch } from '@/components/ui/switch';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription,
} from '@/components/ui/sheet';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription,
} from '@/components/ui/dialog';
import {
  Collapsible, CollapsibleContent, CollapsibleTrigger,
} from '@/components/ui/collapsible';
import {
  Package, Truck, AlertTriangle, ClipboardCheck, CheckCircle2,
  Loader2, Clock, Plus, Boxes, RotateCw, ChevronDown,
  ClipboardList, PackageCheck, ExternalLink, RefreshCw,
  ListChecks, Calendar, ArrowRight, Info,
} from 'lucide-react';

// ─── CONSTANTS ─────────────────────────────────────────────

const BG_COLOR = '#F0F4F8';
const ACCENT = '#3B82F6';

const LOGISTICS_CATEGORIES = [
  { value: 'CONFERENCIA', label: 'Conferência', icon: Package },
  { value: 'SEPARACAO', label: 'Separação', icon: Truck },
  { value: 'EMBALAGEM', label: 'Embalagem', icon: Boxes },
  { value: 'ESTOQUE', label: 'Estoque', icon: ClipboardCheck },
  { value: 'LOGISTICA', label: 'Logística', icon: Truck },
];

const DEFAULT_STEPS = [
  { label: 'Conferir produto', done: false, done_at: null },
  { label: 'Conferir quantidade', done: false, done_at: null },
  { label: 'Conferir nota', done: false, done_at: null },
  { label: 'Separar', done: false, done_at: null },
  { label: 'Embalar', done: false, done_at: null },
  { label: 'Liberar/Despachar', done: false, done_at: null },
];

interface TaskStep { label: string; done: boolean; done_at: string | null; }

interface LogTask {
  id: string;
  notes: string | null;
  task_date: string;
  status: string;
  priority: string;
  task_steps: TaskStep[] | null;
  client_name: string;
  logistics_type: string | null;
  task_category: string | null;
  created_by_seller_id: string | null;
  assigned_to_seller_id: string | null;
  source_routine_id: string | null;
  source_module: string | null;
  related_id: string | null;
  created_at: string;
}

interface Routine {
  id: string;
  title: string;
  task_type: string;
  frequency: string;
  day_of_week: number | null;
  day_of_month: number | null;
  default_priority: string;
  active: boolean;
  default_steps: TaskStep[] | null;
}

// ─── GREETING ──────────────────────────────────────────────

function getGreeting(name: string) {
  const h = new Date().getHours();
  const g = h < 12 ? 'Bom dia' : h < 18 ? 'Boa tarde' : 'Boa noite';
  return `${g}, ${name}`;
}

// ─── UUID FORMATTER ────────────────────────────────────────
// Replace UUIDs in task titles with short readable codes
const UUID_REGEX = /[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/gi;

function formatTaskTitle(notes: string | null): string {
  if (!notes) return 'Tarefa Geral';
  return notes.replace(UUID_REGEX, (uuid) => `#${uuid.slice(0, 6).toUpperCase()}`);
}

// ─── MAIN COMPONENT ───────────────────────────────────────

export function LogisticaMeuDia() {
  const { seller } = useAuth();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState<'tarefas' | 'estoque' | 'entregas' | 'perfil'>('tarefas');
  const today = format(new Date(), 'yyyy-MM-dd');

  // ── Data queries ─────────────────────────────────────────

  const { data: tasks = [], isLoading: tasksLoading, refetch: refetchTasks } = useQuery({
    queryKey: ['logistica-tasks', seller?.id],
    queryFn: async () => {
      if (!seller?.id) return [];
      const { data } = await supabase
        .from('tasks')
        .select(`id, notes, task_date, status, priority, task_steps, logistics_type,
          task_category, created_by_seller_id, assigned_to_seller_id, source_routine_id,
          source_module, related_id, created_at,
          clients!tasks_client_id_fkey(company_name)`)
        .eq('is_deleted', false)
        .neq('status', 'concluida')
        .neq('status', 'cancelada')
        .or(`created_by_seller_id.eq.${seller.id},assigned_to_seller_id.eq.${seller.id}`)
        .order('task_date', { ascending: true })
        .limit(100);
      return (data || []).map((t: any) => ({
        id: t.id, notes: t.notes, task_date: t.task_date, status: t.status,
        priority: t.priority, task_steps: t.task_steps as TaskStep[] | null,
        client_name: t.clients?.company_name || 'N/A',
        logistics_type: t.logistics_type, task_category: t.task_category,
        created_by_seller_id: t.created_by_seller_id,
        assigned_to_seller_id: t.assigned_to_seller_id,
        source_routine_id: t.source_routine_id,
        source_module: t.source_module || null, related_id: t.related_id || null,
        created_at: t.created_at,
      })) as LogTask[];
    },
    enabled: !!seller?.id,
    staleTime: 1000 * 60 * 2,
  });

  const { data: routines = [], refetch: refetchRoutines } = useQuery({
    queryKey: ['logistica-routines', seller?.id],
    queryFn: async () => {
      if (!seller?.id) return [];
      const { data } = await supabase
        .from('routines')
        .select('id, title, task_type, frequency, day_of_week, day_of_month, default_priority, active, default_steps')
        .or(`assigned_to_seller_id.eq.${seller.id},assigned_to_user_id.eq.${seller.id}`)
        .eq('task_category', 'LOGISTICA')
        .order('created_at', { ascending: true });
      return (data || []).map((r: any) => ({ ...r, default_steps: r.default_steps as TaskStep[] | null })) as Routine[];
    },
    enabled: !!seller?.id,
    staleTime: 1000 * 60 * 5,
  });

  const { data: solicitacoes = [], isLoading: solicitacoesLoading } = useSolicitacoes();
  const changeStatus = useChangeStatus();

  // ── Derived data ────────────────────────────────────────
  // Filter: only show tasks directly assigned to Adriana, exclude auto-generated unless assigned
  const myTasks = tasks.filter(t => {
    const isAssignedToMe = t.assigned_to_seller_id === seller?.id;
    const isCreatedByMe = t.created_by_seller_id === seller?.id;
    // Exclude auto-generated tasks not explicitly assigned to me
    if (t.source_module && !isAssignedToMe) return false;
    return isCreatedByMe || isAssignedToMe;
  });
  const delegatedTasks = tasks.filter(t =>
    t.assigned_to_seller_id === seller?.id && t.created_by_seller_id !== seller?.id
  );
  const conferencias = myTasks.filter(t => t.logistics_type === 'CONFERENCIA');
  const separacao = myTasks.filter(t => t.logistics_type === 'SEPARACAO' || t.logistics_type === 'EMBALAGEM');
  const estoqueTasks = myTasks.filter(t => t.logistics_type === 'ESTOQUE');
  const atrasadas = myTasks.filter(t => t.task_date < today);

  const sortedTasks = [...myTasks].sort((a, b) => {
    const aOver = a.task_date < today ? 0 : 1;
    const bOver = b.task_date < today ? 0 : 1;
    if (aOver !== bOver) return aOver - bOver;
    const p: Record<string, number> = { alta: 0, media: 1, baixa: 2 };
    return (p[a.priority] ?? 1) - (p[b.priority] ?? 1) || a.task_date.localeCompare(b.task_date);
  });

  // Entregas data
  const aguardandoEntrega = solicitacoes.filter((s: any) => s.status === 'AGUARDANDO_ENTREGA_FORNECEDOR');
  const recebidos = solicitacoes.filter((s: any) => s.status === 'RECEBIDO');
  const activeSolicitacoes = solicitacoes.filter((s: any) =>
    !['ENTREGUE', 'CANCELADO'].includes(s.status)
  );

  // Tab badges
  const tarefasBadge = atrasadas.length;
  const entregasBadge = aguardandoEntrega.length;

  // ── Actions ─────────────────────────────────────────────

  const [expandedTaskId, setExpandedTaskId] = useState<string | null>(null);
  const [taskOpenedAt, setTaskOpenedAt] = useState<Record<string, number>>({});
  const [showCreateDrawer, setShowCreateDrawer] = useState(false);
  const [showRoutineModal, setShowRoutineModal] = useState(false);
  const [confirmModal, setConfirmModal] = useState<{ type: 'recebimento' | 'entrega'; id: string; title: string } | null>(null);
  const [confirmObs, setConfirmObs] = useState('');
  const [entregasFilter, setEntregasFilter] = useState<string>('all');

  // New task state
  const [newTitle, setNewTitle] = useState('');
  const [newCategory, setNewCategory] = useState('CONFERENCIA');
  const [newDate, setNewDate] = useState(today);
  const [newPriority, setNewPriority] = useState('media');
  const [newNotes, setNewNotes] = useState('');
  const [newChecklist, setNewChecklist] = useState<string[]>([]);
  const [newChecklistItem, setNewChecklistItem] = useState('');
  const [creating, setCreating] = useState(false);

  // Routine state
  const [routineTitle, setRoutineTitle] = useState('');
  const [routineType, setRoutineType] = useState('CONFERENCIA');
  const [routineFreq, setRoutineFreq] = useState('DIARIA');
  const [routinePriority, setRoutinePriority] = useState('media');
  const [routineDayOfWeek, setRoutineDayOfWeek] = useState<number | null>(null);
  const [routineDayOfMonth, setRoutineDayOfMonth] = useState<number | null>(null);
  const [creatingRoutine, setCreatingRoutine] = useState(false);

  // Track task open time for anti-fraud
  const handleExpandTask = (taskId: string) => {
    if (expandedTaskId === taskId) {
      setExpandedTaskId(null);
    } else {
      setExpandedTaskId(taskId);
      setTaskOpenedAt(prev => ({ ...prev, [taskId]: Date.now() }));
    }
  };

  const handleStepToggle = async (taskId: string, stepIndex: number) => {
    const task = tasks.find(t => t.id === taskId);
    if (!task) return;

    const currentSteps = task.task_steps ?? [];
    if (currentSteps.length === 0) return;

    const steps = [...currentSteps];
    steps[stepIndex] = {
      ...steps[stepIndex],
      done: !steps[stepIndex].done,
      done_at: !steps[stepIndex].done ? new Date().toISOString() : null,
    };

    const { error } = await supabase.from('tasks').update({ task_steps: steps as any }).eq('id', taskId);
    if (error) { toast.error('Erro ao atualizar passo'); return; }
    refetchTasks();
  };

  const handleCompleteTask = async (taskId: string) => {
    const task = tasks.find(t => t.id === taskId);
    if (!task || !seller?.id) return;

    const completedAt = new Date().toISOString();
    const finalSteps = task.task_steps && task.task_steps.length > 0
      ? task.task_steps.map((step) =>
          step.done ? step : { ...step, done: true, done_at: completedAt }
        )
      : task.task_steps;

    const { error } = await supabase
      .from('tasks')
      .update({ status: 'concluida', completed_at: completedAt, task_steps: finalSteps as any })
      .eq('id', taskId);
    if (error) { toast.error('Erro ao concluir tarefa'); return; }

    // Anti-fraud: 30s minimum
    const openedAt = taskOpenedAt[taskId];
    const elapsed = openedAt ? differenceInSeconds(new Date(), new Date(openedAt)) : 999;
    const grantXP = elapsed >= 30;

    if (grantXP) {
      const isOnTime = task.task_date >= today;
      const xp = isOnTime ? ADMIN_XP_TABLE.ADMIN_TASK_ONTIME : ADMIN_XP_TABLE.ADMIN_TASK_LATE;
      const event = isOnTime ? 'ADMIN_TASK_ONTIME' : 'ADMIN_TASK_LATE';
      await awardAdminXP(seller.id, event, xp, taskId);
    }

    toast.success('Tarefa concluída!');
    refetchTasks();
  };

  const handleCreateTask = async () => {
    if (!newTitle.trim() || !newDate || !seller?.id) {
      toast.error('Preencha título e data');
      return;
    }
    setCreating(true);
    try {
      const steps = newChecklist.length > 0
        ? newChecklist.map(label => ({ label, done: false, done_at: null }))
        : DEFAULT_STEPS;
      const { error } = await supabase.from('tasks').insert({
        notes: newTitle.trim(),
        task_date: newDate,
        priority: newPriority,
        status: 'pendente',
        contact_type: 'ligacao',
        contact_reason: 'RETORNO',
        task_category: 'LOGISTICA',
        logistics_type: newCategory,
        task_steps: steps as any,
        created_by_seller_id: seller.id,
        assigned_to_seller_id: seller.id,
        is_deleted: false,
        unique_key: `logistica_${seller.id}_${Date.now()}`,
      } as any);
      if (error) throw error;
      toast.success('Tarefa criada');
      setShowCreateDrawer(false);
      setNewTitle(''); setNewDate(today); setNewPriority('media'); setNewCategory('CONFERENCIA');
      setNewNotes(''); setNewChecklist([]); setNewChecklistItem('');
      refetchTasks();
    } catch (err: any) {
      toast.error(err.message || 'Erro ao criar tarefa');
    } finally {
      setCreating(false);
    }
  };

  // Routine toggle (completed today)
  const [completedRoutines, setCompletedRoutines] = useState<Set<string>>(new Set());
  useEffect(() => {
    // Check which routines already generated tasks today
    const routineTaskIds = new Set(
      tasks.filter(t => t.source_routine_id && t.task_date === today).map(t => t.source_routine_id!)
    );
    setCompletedRoutines(routineTaskIds);
  }, [tasks, today]);

  const handleRoutineToggle = async (routineId: string) => {
    if (completedRoutines.has(routineId) || !seller?.id) return;
    // Create task for this routine
    const routine = routines.find(r => r.id === routineId);
    if (!routine) return;
    const steps = routine.default_steps || DEFAULT_STEPS;
    const { error } = await supabase.from('tasks').insert({
      notes: routine.title,
      task_date: today,
      priority: routine.default_priority || 'media',
      status: 'concluida',
      completed_at: new Date().toISOString(),
      contact_type: 'ligacao',
      contact_reason: 'RETORNO',
      task_category: 'LOGISTICA',
      logistics_type: routine.task_type,
      task_steps: steps.map(s => ({ ...s, done: true, done_at: new Date().toISOString() })) as any,
      created_by_seller_id: seller.id,
      assigned_to_seller_id: seller.id,
      source_routine_id: routineId,
      is_deleted: false,
      unique_key: `routine_${routineId}_${today}`,
      client_id: '00000000-0000-0000-0000-000000000000',
    } as any);
    if (error) {
      if (error.code === '23505') {
        toast.info('Rotina já concluída hoje');
        setCompletedRoutines(prev => new Set(prev).add(routineId));
      } else {
        toast.error('Erro ao concluir rotina');
      }
      return;
    }
    await awardAdminXP(seller.id, 'ADMIN_TASK_ONTIME', ADMIN_XP_TABLE.ADMIN_TASK_ONTIME, routineId);
    setCompletedRoutines(prev => new Set(prev).add(routineId));
    toast.success('Rotina concluída! +10 XP');
    refetchTasks();
  };

  const handleCreateRoutine = async () => {
    if (!routineTitle.trim() || !seller?.id) { toast.error('Preencha o título'); return; }
    if (routineFreq === 'SEMANAL' && routineDayOfWeek === null) { toast.error('Selecione o dia da semana'); return; }
    if (routineFreq === 'MENSAL' && routineDayOfMonth === null) { toast.error('Selecione o dia do mês'); return; }
    setCreatingRoutine(true);
    try {
      const { error } = await supabase.from('routines').insert({
        title: routineTitle.trim(),
        task_category: 'LOGISTICA',
        task_type: routineType,
        frequency: routineFreq,
        day_of_week: routineFreq === 'SEMANAL' ? routineDayOfWeek : null,
        day_of_month: routineFreq === 'MENSAL' ? routineDayOfMonth : null,
        default_bucket: 'HOJE',
        default_priority: routinePriority,
        assigned_to_seller_id: seller.id,
        assigned_to_user_id: seller.id,
        active: true,
      } as any);
      if (error) throw error;
      toast.success('Rotina criada');
      setShowRoutineModal(false);
      setRoutineTitle(''); setRoutineType('CONFERENCIA'); setRoutineFreq('DIARIA');
      setRoutinePriority('media'); setRoutineDayOfWeek(null); setRoutineDayOfMonth(null);
      refetchRoutines();
    } catch (err: any) {
      toast.error(err.message || 'Erro');
    } finally {
      setCreatingRoutine(false);
    }
  };

  // Entregas actions
  const handleConfirmRecebimento = async () => {
    if (!confirmModal || !seller?.id) return;
    changeStatus.mutate(
      { id: confirmModal.id, status: 'RECEBIDO', message: `Recebimento confirmado${confirmObs ? ': ' + confirmObs : ''}` },
      {
        onSuccess: async () => {
          // Notify financeiro_gestora (Anna Cristina)
          const { data: financeiro } = await supabase
            .from('sellers')
            .select('id')
            .eq('department', 'financeiro_gestora')
            .limit(1)
            .maybeSingle();
          if (financeiro?.id) {
            await createSellerNotification(
              financeiro.id,
              '📦 Mercadoria recebida',
              `"${confirmModal.title}" foi recebida. Verifique o financeiro.`,
              'info'
            );
          }
          await awardAdminXP(seller.id, 'ADMIN_FEED_ACTION', 15, confirmModal.id);
          toast.success('Recebimento confirmado! +15 XP');
          setConfirmModal(null);
          setConfirmObs('');
        },
      }
    );
  };

  const handleConfirmEntrega = async () => {
    if (!confirmModal || !seller?.id) return;
    changeStatus.mutate(
      { id: confirmModal.id, status: 'ENTREGUE', message: `Entregue ao cliente${confirmObs ? ': ' + confirmObs : ''}` },
      {
        onSuccess: async () => {
          // Notify responsible seller
          const sol = solicitacoes.find((s: any) => s.id === confirmModal.id) as any;
          const solicitanteId = sol?.solicitante?.id;
          if (solicitanteId) {
            await createSellerNotification(
              solicitanteId,
              '📦 Produto entregue ao cliente',
              `"${confirmModal.title}" foi entregue ao cliente. Faça o follow-up.`,
              'success'
            );
          }
          await awardAdminXP(seller.id, 'ADMIN_FEED_ACTION', 15, confirmModal.id);
          toast.success('Entrega registrada! +15 XP');
          setConfirmModal(null);
          setConfirmObs('');
        },
      }
    );
  };

  // ── Status badge helper ─────────────────────────────────

  function getStatusBadge(taskDate: string) {
    if (taskDate < today) return <Badge className="bg-red-500 text-white text-[10px] px-1.5 py-0">Atrasada</Badge>;
    if (taskDate === today) return <Badge className="bg-orange-500 text-white text-[10px] px-1.5 py-0">Hoje</Badge>;
    return <Badge variant="secondary" className="text-[10px] px-1.5 py-0">Próximos dias</Badge>;
  }

  function getPriorityBadge(priority: string) {
    if (priority === 'alta') return <Badge className="bg-red-100 text-red-700 text-[10px] px-1.5 py-0">Alta</Badge>;
    if (priority === 'baixa') return <Badge className="bg-gray-100 text-gray-600 text-[10px] px-1.5 py-0">Baixa</Badge>;
    return null;
  }

  const categoryIcon = (type: string | null) => {
    const cat = LOGISTICS_CATEGORIES.find(c => c.value === type);
    return cat ? <cat.icon className="h-4 w-4" /> : <ClipboardList className="h-4 w-4" />;
  };

  // ── Loading ─────────────────────────────────────────────

  if (tasksLoading) {
    return (
      <div className="flex items-center justify-center py-16" style={{ background: BG_COLOR }}>
        <Loader2 className="animate-spin h-8 w-8" style={{ color: ACCENT }} />
      </div>
    );
  }

  // ─── TAB CONTENT ────────────────────────────────────────

  const firstName = seller?.name?.split(' ')[0] || 'Adriana';

  return (
    <div className="min-h-screen" style={{ background: BG_COLOR }}>
      <div className="max-w-5xl mx-auto px-4 py-6 space-y-8">

        {/* ── TABS ────────────────────────────────────────── */}
        <div className="flex items-center gap-6 border-b" style={{ borderColor: '#E2E8F0' }}>
          {[
            { key: 'tarefas' as const, label: '📋 Tarefas', badge: tarefasBadge },
            { key: 'estoque' as const, label: '📦 Estoque', badge: 0 },
            { key: 'entregas' as const, label: '🚚 Entregas', badge: entregasBadge },
            { key: 'perfil' as const, label: '👤 Perfil', badge: 0 },
          ].map(tab => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className="relative pb-3 px-1 text-sm transition-colors"
              style={{
                fontWeight: activeTab === tab.key ? 700 : 400,
                color: activeTab === tab.key ? ACCENT : '#64748B',
              }}
            >
              <span className="flex items-center gap-1.5">
                {tab.label}
                {tab.badge > 0 && (
                  <span className="inline-flex items-center justify-center h-5 min-w-[20px] rounded-full bg-red-500 text-white text-[10px] font-bold px-1.5">
                    {tab.badge}
                  </span>
                )}
              </span>
              {activeTab === tab.key && (
                <div className="absolute bottom-0 left-0 right-0 h-[2px] rounded-full" style={{ background: ACCENT }} />
              )}
            </button>
          ))}
        </div>

        {/* ═══════════════ ABA TAREFAS ═══════════════ */}
        {activeTab === 'tarefas' && (
          <TasksErrorBoundary>
          <div className="space-y-8">
            {/* Header */}
            <div className="flex items-center justify-between flex-wrap gap-3">
              <div>
                <h1 className="text-2xl font-bold" style={{ color: '#1E293B' }}>
                  {getGreeting(firstName)}
                </h1>
              </div>
              <p className="text-sm capitalize" style={{ color: '#94A3B8' }}>
                {format(new Date(), "EEEE, d 'de' MMMM 'de' yyyy", { locale: ptBR })}
              </p>
            </div>

            {/* Metrics */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {[
                { icon: Package, label: 'Conferências', count: conferencias.length, color: '#3B82F6' },
                { icon: Truck, label: 'Separar/Embalar', count: separacao.length, color: '#10B981' },
                { icon: Boxes, label: 'Estoque Baixo', count: estoqueTasks.length, color: '#8B5CF6' },
                { icon: AlertTriangle, label: 'Atrasadas', count: atrasadas.length, color: atrasadas.length > 0 ? '#EF4444' : '#94A3B8' },
              ].map((m, i) => (
                <Card key={i} className="bg-white border-0 shadow-sm" style={{ borderRadius: 12 }}>
                  <CardContent className="p-4 flex items-center gap-3">
                    <m.icon className="h-5 w-5" style={{ color: m.color }} />
                    <div>
                      <p className="font-bold text-2xl" style={{ color: m.count > 0 && m.label === 'Atrasadas' ? '#EF4444' : '#1E293B' }}>
                        {m.count}
                      </p>
                      <p className="text-[11px] uppercase tracking-widest" style={{ color: '#94A3B8' }}>{m.label}</p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* AGORA — O QUE FAZER */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <p className="text-[11px] uppercase tracking-widest font-medium" style={{ color: '#94A3B8' }}>
                  Agora — O que fazer
                </p>
                <Button onClick={() => setShowCreateDrawer(true)} size="sm" className="gap-1.5 text-white" style={{ background: ACCENT }}>
                  <Plus className="h-3.5 w-3.5" /> Nova Tarefa
                </Button>
              </div>

              {sortedTasks.length === 0 ? (
                <Card className="bg-white border-0 shadow-sm" style={{ borderRadius: 12 }}>
                  <CardContent className="py-12 text-center">
                    <CheckCircle2 className="h-10 w-10 mx-auto mb-3" style={{ color: '#10B981' }} />
                    <p className="text-sm" style={{ color: '#64748B' }}>Nenhuma tarefa pendente</p>
                  </CardContent>
                </Card>
              ) : (
                <div className="space-y-2">
                  {sortedTasks.map(task => {
                    const hasChecklist = !!task.task_steps && task.task_steps.length > 0;
                    const steps = task.task_steps ?? [];
                    const done = hasChecklist ? steps.filter(s => s.done).length : 0;
                    const total = hasChecklist ? steps.length : 0;
                    const allDone = !hasChecklist || done === total;
                    const isExpanded = expandedTaskId === task.id;

                    return (
                      <Card key={task.id} className="bg-white border-0 shadow-sm overflow-hidden" style={{ borderRadius: 12 }}>
                        <CardContent className="p-4">
                          <div className="flex items-center gap-3 cursor-pointer" onClick={() => handleExpandTask(task.id)}>
                            <div className="w-9 h-9 rounded-lg flex items-center justify-center shrink-0"
                              style={{ background: allDone ? '#D1FAE5' : '#F1F5F9' }}>
                              {allDone ? <CheckCircle2 className="h-4 w-4 text-emerald-600" /> : categoryIcon(task.logistics_type)}
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="font-medium text-sm truncate" style={{ color: '#1E293B' }}>
                                {formatTaskTitle(task.notes)}
                              </p>
                              <div className="flex items-center gap-1.5 mt-1 flex-wrap">
                                {getStatusBadge(task.task_date)}
                                {getPriorityBadge(task.priority)}
                                <span className="text-[10px]" style={{ color: '#94A3B8' }}>
                                  {format(parseISO(task.task_date), 'dd/MM')}
                                </span>
                              </div>
                            </div>
                            <div className="flex items-center gap-2 shrink-0">
                              <Badge variant="secondary" className="text-xs">
                                {hasChecklist ? `${done}/${total}` : 'Sem checklist'}
                              </Badge>
                              <Button
                                size="sm"
                                className="h-7 text-xs text-white"
                                style={{ background: '#10B981' }}
                                onClick={(e) => { e.stopPropagation(); handleCompleteTask(task.id); }}
                              >
                                Concluir
                              </Button>
                            </div>
                          </div>
                          {isExpanded && (
                            <div className="mt-3 pt-3 space-y-1.5" style={{ borderTop: '1px solid #E2E8F0' }}>
                              {hasChecklist ? (
                                steps.map((step, idx) => (
                                  <div key={idx} className="flex items-center gap-2.5 py-1 px-1">
                                    <Checkbox checked={step.done} onCheckedChange={() => handleStepToggle(task.id, idx)} />
                                    <span className={`text-sm flex-1 ${step.done ? 'line-through' : ''}`}
                                      style={{ color: step.done ? '#94A3B8' : '#334155' }}>
                                      {step.label}
                                    </span>
                                    {step.done && step.done_at && (
                                      <span className="text-[10px]" style={{ color: '#94A3B8' }}>
                                        {format(parseISO(step.done_at), 'HH:mm')}
                                      </span>
                                    )}
                                  </div>
                                ))
                              ) : (
                                <p className="text-xs px-1" style={{ color: '#94A3B8' }}>
                                  Esta tarefa não possui checklist.
                                </p>
                              )}
                              {task.source_module && task.related_id && (
                                <div className="pt-2">
                                  <Button variant="outline" size="sm" className="gap-1 h-6 text-[10px]"
                                    onClick={(e) => { e.stopPropagation(); navigate(`/compras?solicitacao=${task.related_id}`); }}>
                                    <ExternalLink className="h-3 w-3" /> Ver origem
                                  </Button>
                                </div>
                              )}
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              )}
            </div>

            {/* ROTINAS FIXAS */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <p className="text-[11px] uppercase tracking-widest font-medium" style={{ color: '#94A3B8' }}>
                  Rotinas Fixas
                </p>
                <Button variant="outline" size="sm" onClick={() => setShowRoutineModal(true)} className="gap-1 h-7 text-xs">
                  <Plus className="h-3 w-3" /> Nova Rotina
                </Button>
              </div>
              {routines.length === 0 ? (
                <Card className="bg-white border-0 shadow-sm" style={{ borderRadius: 12 }}>
                  <CardContent className="py-8 text-center">
                    <RotateCw className="h-8 w-8 mx-auto mb-2" style={{ color: '#CBD5E1' }} />
                    <p className="text-sm" style={{ color: '#64748B' }}>Nenhuma rotina configurada</p>
                  </CardContent>
                </Card>
              ) : (
                <div className="space-y-2">
                  {routines.filter(r => r.active).map(routine => {
                    const isDone = completedRoutines.has(routine.id);
                    const catInfo = LOGISTICS_CATEGORIES.find(c => c.value === routine.task_type);
                    return (
                      <Card key={routine.id} className="bg-white border-0 shadow-sm" style={{ borderRadius: 12 }}>
                        <CardContent className="p-3 flex items-center gap-3">
                          <Switch
                            checked={isDone}
                            onCheckedChange={() => handleRoutineToggle(routine.id)}
                            disabled={isDone}
                            className={isDone ? 'data-[state=checked]:bg-emerald-500' : ''}
                          />
                          <div className="flex-1 min-w-0">
                            <p className={`text-sm font-medium truncate ${isDone ? 'line-through' : ''}`}
                              style={{ color: isDone ? '#94A3B8' : '#1E293B' }}>
                              {routine.title}
                            </p>
                            <div className="flex items-center gap-2 text-[10px]" style={{ color: '#94A3B8' }}>
                              {catInfo && <span>{catInfo.label}</span>}
                              <span>• {routine.frequency === 'DIARIA' ? 'Diária' : routine.frequency === 'SEMANAL' ? 'Semanal' : 'Mensal'}</span>
                              <span>• {routine.default_priority}</span>
                            </div>
                          </div>
                          {isDone && <CheckCircle2 className="h-4 w-4 text-emerald-500 shrink-0" />}
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              )}
            </div>

            {/* DELEGADAS A MIM */}
            {delegatedTasks.length > 0 && (
              <div>
                <p className="text-[11px] uppercase tracking-widest font-medium mb-3" style={{ color: '#94A3B8' }}>
                  Delegadas a mim
                </p>
                <div className="space-y-2">
                  {delegatedTasks.map(task => (
                    <Card key={task.id} className="bg-white border-0 shadow-sm" style={{ borderRadius: 12 }}>
                      <CardContent className="p-3 flex items-center gap-3">
                        {categoryIcon(task.logistics_type)}
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium truncate" style={{ color: '#1E293B' }}>
                            {formatTaskTitle(task.notes)}
                          </p>
                          <div className="flex items-center gap-1.5 mt-0.5 flex-wrap">
                            {getStatusBadge(task.task_date)}
                            <span className="text-[10px]" style={{ color: '#94A3B8' }}>
                              {format(parseISO(task.task_date), 'dd/MM')}
                            </span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            )}
          </div>
          </TasksErrorBoundary>
        )}

        {/* ═══════════════ ABA ESTOQUE ═══════════════ */}
        {activeTab === 'estoque' && (
          <div className="space-y-8">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-lg font-bold" style={{ color: '#1E293B' }}>Estoque — Controle de Mínimos</h2>
                <p className="text-sm capitalize" style={{ color: '#94A3B8' }}>
                  {format(new Date(), "d 'de' MMMM", { locale: ptBR })}
                </p>
              </div>
              <Button variant="outline" size="sm" className="gap-1.5" onClick={() => queryClient.invalidateQueries({ queryKey: ['logistica-tasks'] })}>
                <RefreshCw className="h-3.5 w-3.5" /> Atualizar
              </Button>
            </div>

            <Card className="bg-white border-0 shadow-sm" style={{ borderRadius: 12 }}>
              <CardContent className="py-12 text-center">
                <Boxes className="h-12 w-12 mx-auto mb-3" style={{ color: '#10B981' }} />
                <p className="font-medium text-sm mb-1" style={{ color: '#1E293B' }}>Estoque em dia</p>
                <p className="text-xs" style={{ color: '#94A3B8' }}>
                  O controle de estoque mínimo ainda não possui dados configurados.
                  Configure quantidades mínimas nos produtos para ativar alertas aqui.
                </p>
                <Button variant="outline" size="sm" className="mt-4 gap-1.5" onClick={() => navigate('/products')}>
                  <ArrowRight className="h-3.5 w-3.5" /> Ir para Produtos
                </Button>
              </CardContent>
            </Card>
          </div>
        )}

        {/* ═══════════════ ABA ENTREGAS ═══════════════ */}
        {activeTab === 'entregas' && (
          <div className="space-y-8">
            {/* Aguardando Recebimento */}
            <div>
              <p className="text-[11px] uppercase tracking-widest font-medium mb-3" style={{ color: '#94A3B8' }}>
                Aguardando Recebimento ({aguardandoEntrega.length})
              </p>
              {aguardandoEntrega.length === 0 ? (
                <Card className="bg-white border-0 shadow-sm" style={{ borderRadius: 12 }}>
                  <CardContent className="py-8 text-center">
                    <PackageCheck className="h-8 w-8 mx-auto mb-2" style={{ color: '#CBD5E1' }} />
                    <p className="text-sm" style={{ color: '#64748B' }}>Nenhuma entrega pendente de recebimento</p>
                  </CardContent>
                </Card>
              ) : (
                <div className="space-y-2">
                  {aguardandoEntrega.map((sol: any) => (
                    <Card key={sol.id} className="bg-white border-0 shadow-sm" style={{ borderRadius: 12 }}>
                      <CardContent className="p-4 flex items-center gap-3">
                        <Package className="h-5 w-5 shrink-0" style={{ color: ACCENT }} />
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium truncate" style={{ color: '#1E293B' }}>{sol.titulo}</p>
                          <div className="flex items-center gap-2 text-[10px] mt-0.5" style={{ color: '#94A3B8' }}>
                            <span>{sol.client_name_snapshot || 'Sem cliente'}</span>
                            <span>• {sol.solicitacao_itens?.length || 0} itens</span>
                            <span>• {format(parseISO(sol.created_at), 'dd/MM')}</span>
                          </div>
                        </div>
                        <Button size="sm" className="h-7 text-xs text-white shrink-0" style={{ background: ACCENT }}
                          onClick={() => setConfirmModal({ type: 'recebimento', id: sol.id, title: sol.titulo })}>
                          Confirmar Recebimento
                        </Button>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </div>

            {/* Aguardando Envio ao Cliente */}
            <div>
              <p className="text-[11px] uppercase tracking-widest font-medium mb-3" style={{ color: '#94A3B8' }}>
                Aguardando Envio ao Cliente ({recebidos.length})
              </p>
              {recebidos.length === 0 ? (
                <Card className="bg-white border-0 shadow-sm" style={{ borderRadius: 12 }}>
                  <CardContent className="py-8 text-center">
                    <Truck className="h-8 w-8 mx-auto mb-2" style={{ color: '#CBD5E1' }} />
                    <p className="text-sm" style={{ color: '#64748B' }}>Nenhum item aguardando envio</p>
                  </CardContent>
                </Card>
              ) : (
                <div className="space-y-2">
                  {recebidos.map((sol: any) => (
                    <Card key={sol.id} className="bg-white border-0 shadow-sm" style={{ borderRadius: 12 }}>
                      <CardContent className="p-4 flex items-center gap-3">
                        <Truck className="h-5 w-5 shrink-0" style={{ color: '#10B981' }} />
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium truncate" style={{ color: '#1E293B' }}>{sol.titulo}</p>
                          <div className="flex items-center gap-2 text-[10px] mt-0.5" style={{ color: '#94A3B8' }}>
                            <span>{sol.client_name_snapshot || 'Sem cliente'}</span>
                            <span>• {sol.solicitante?.name || 'N/A'}</span>
                          </div>
                        </div>
                        <Button size="sm" className="h-7 text-xs text-white shrink-0" style={{ background: '#10B981' }}
                          onClick={() => setConfirmModal({ type: 'entrega', id: sol.id, title: sol.titulo })}>
                          Registrar Entrega
                        </Button>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </div>

            {/* Ordens de Compra — Status Geral */}
            <div>
              <p className="text-[11px] uppercase tracking-widest font-medium mb-3" style={{ color: '#94A3B8' }}>
                Ordens de Compra — Status Geral ({activeSolicitacoes.length})
              </p>
              <div className="flex items-center gap-2 mb-3 flex-wrap">
                {['all', 'NOVA_SOLICITACAO', 'EM_COTACAO', 'APROVADA_PARA_COMPRAR', 'AGUARDANDO_ENTREGA_FORNECEDOR', 'RECEBIDO'].map(f => (
                  <Button key={f} variant={entregasFilter === f ? 'default' : 'outline'} size="sm" className="h-7 text-xs"
                    style={entregasFilter === f ? { background: ACCENT } : {}}
                    onClick={() => setEntregasFilter(f)}>
                    {f === 'all' ? 'Todos' : STATUS_LABELS[f] || f}
                  </Button>
                ))}
              </div>
              <div className="space-y-2">
                {(entregasFilter === 'all' ? activeSolicitacoes : activeSolicitacoes.filter((s: any) => s.status === entregasFilter))
                  .map((sol: any) => (
                    <Card key={sol.id} className="bg-white border-0 shadow-sm" style={{ borderRadius: 12 }}>
                      <CardContent className="p-3 flex items-center gap-3">
                        <ClipboardList className="h-4 w-4 shrink-0" style={{ color: '#64748B' }} />
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium truncate" style={{ color: '#1E293B' }}>{sol.titulo}</p>
                          <span className="text-[10px]" style={{ color: '#94A3B8' }}>
                            {sol.client_name_snapshot || ''} • {format(parseISO(sol.created_at), 'dd/MM')}
                          </span>
                        </div>
                        <Badge variant="outline" className="text-[10px] shrink-0">
                          {STATUS_LABELS[sol.status] || sol.status}
                        </Badge>
                        <Button variant="ghost" size="sm" className="h-7 text-xs gap-1"
                          onClick={() => navigate(`/compras?solicitacao=${sol.id}`)}>
                          <ExternalLink className="h-3 w-3" /> Ver
                        </Button>
                      </CardContent>
                    </Card>
                  ))}
              </div>
            </div>

            {/* Central do Comprador */}
            <Collapsible>
              <CollapsibleTrigger asChild>
                <Button variant="ghost" className="w-full justify-between h-10 text-sm font-medium gap-2" style={{ color: '#64748B' }}>
                  <span className="text-[11px] uppercase tracking-widest">Central do Comprador</span>
                  <ChevronDown className="h-4 w-4" />
                </Button>
              </CollapsibleTrigger>
              <CollapsibleContent className="pt-2">
                <Card className="bg-white border-0 shadow-sm" style={{ borderRadius: 12 }}>
                  <CardContent className="p-4">
                    <p className="text-sm mb-3" style={{ color: '#64748B' }}>
                      Acompanhe as solicitações recebidas no módulo de compras.
                    </p>
                    <Button variant="outline" size="sm" className="gap-1.5" onClick={() => navigate('/compras')}>
                      <ExternalLink className="h-3.5 w-3.5" /> Ver no módulo de compras
                    </Button>
                  </CardContent>
                </Card>
              </CollapsibleContent>
            </Collapsible>
          </div>
        )}

        {/* ═══════════ DRAWER NOVA TAREFA ═══════════ */}
        <Sheet open={showCreateDrawer} onOpenChange={setShowCreateDrawer}>
          <SheetContent className="w-full sm:max-w-md overflow-y-auto" style={{ background: 'white' }}>
            <SheetHeader className="mb-6">
              <SheetTitle className="flex items-center gap-2">
                <ClipboardCheck className="h-5 w-5" style={{ color: ACCENT }} />
                Nova Tarefa
              </SheetTitle>
              <SheetDescription>Crie uma tarefa para o departamento de logística</SheetDescription>
            </SheetHeader>
            <div className="space-y-5">
              <div className="space-y-1.5">
                <Label className="text-[11px] uppercase tracking-widest" style={{ color: '#94A3B8' }}>Título *</Label>
                <Input value={newTitle} onChange={e => setNewTitle(e.target.value)} placeholder="Ex: Conferir NF 12345" style={{ borderRadius: 8 }} />
              </div>
              <div className="space-y-1.5">
                <Label className="text-[11px] uppercase tracking-widest" style={{ color: '#94A3B8' }}>Categoria *</Label>
                <Select value={newCategory} onValueChange={setNewCategory}>
                  <SelectTrigger style={{ borderRadius: 8 }}><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {LOGISTICS_CATEGORIES.map(c => (
                      <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label className="text-[11px] uppercase tracking-widest" style={{ color: '#94A3B8' }}>Data *</Label>
                  <Input type="date" value={newDate} onChange={e => setNewDate(e.target.value)} style={{ borderRadius: 8 }} />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-[11px] uppercase tracking-widest" style={{ color: '#94A3B8' }}>Prioridade *</Label>
                  <div className="flex gap-1">
                    {['alta', 'media', 'baixa'].map(p => (
                      <Button key={p} variant={newPriority === p ? 'default' : 'outline'} size="sm"
                        className="flex-1 h-9 text-xs capitalize"
                        style={newPriority === p ? { background: ACCENT } : {}}
                        onClick={() => setNewPriority(p)}>
                        {p === 'media' ? 'Média' : p.charAt(0).toUpperCase() + p.slice(1)}
                      </Button>
                    ))}
                  </div>
                </div>
              </div>
              <div className="space-y-1.5">
                <Label className="text-[11px] uppercase tracking-widest" style={{ color: '#94A3B8' }}>Observações</Label>
                <Textarea value={newNotes} onChange={e => setNewNotes(e.target.value)} placeholder="Observações opcionais..." rows={3} style={{ borderRadius: 8 }} />
              </div>
              <div className="space-y-1.5">
                <Label className="text-[11px] uppercase tracking-widest" style={{ color: '#94A3B8' }}>Checklist</Label>
                <div className="space-y-1.5">
                  {newChecklist.map((item, i) => (
                    <div key={i} className="flex items-center gap-2 text-sm">
                      <ListChecks className="h-3.5 w-3.5" style={{ color: '#94A3B8' }} />
                      <span className="flex-1">{item}</span>
                      <Button variant="ghost" size="sm" className="h-6 w-6 p-0"
                        onClick={() => setNewChecklist(prev => prev.filter((_, idx) => idx !== i))}>×</Button>
                    </div>
                  ))}
                  <div className="flex gap-2">
                    <Input value={newChecklistItem} onChange={e => setNewChecklistItem(e.target.value)}
                      placeholder="Adicionar item..."
                      style={{ borderRadius: 8 }}
                      onKeyDown={e => {
                        if (e.key === 'Enter' && newChecklistItem.trim()) {
                          setNewChecklist(prev => [...prev, newChecklistItem.trim()]);
                          setNewChecklistItem('');
                        }
                      }} />
                    <Button variant="outline" size="sm" className="shrink-0" disabled={!newChecklistItem.trim()}
                      onClick={() => { setNewChecklist(prev => [...prev, newChecklistItem.trim()]); setNewChecklistItem(''); }}>
                      <Plus className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </div>
              </div>
              <Button className="w-full text-white" style={{ background: ACCENT }} disabled={creating} onClick={handleCreateTask}>
                {creating ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
                Criar Tarefa
              </Button>
            </div>
          </SheetContent>
        </Sheet>

        {/* ═══════════ MODAL NOVA ROTINA ═══════════ */}
        <Dialog open={showRoutineModal} onOpenChange={setShowRoutineModal}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <RotateCw className="h-5 w-5" style={{ color: ACCENT }} />
                Nova Rotina
              </DialogTitle>
              <DialogDescription>Configure uma rotina recorrente para logística</DialogDescription>
            </DialogHeader>
            <div className="space-y-4 pt-2">
              <div className="space-y-1.5">
                <Label className="text-[11px] uppercase tracking-widest" style={{ color: '#94A3B8' }}>Título *</Label>
                <Input value={routineTitle} onChange={e => setRoutineTitle(e.target.value)} placeholder="Ex: Conferência matinal" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-[11px] uppercase tracking-widest" style={{ color: '#94A3B8' }}>Categoria</Label>
                <Select value={routineType} onValueChange={setRoutineType}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {LOGISTICS_CATEGORIES.map(c => (
                      <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label className="text-[11px] uppercase tracking-widest" style={{ color: '#94A3B8' }}>Frequência</Label>
                  <Select value={routineFreq} onValueChange={setRoutineFreq}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="DIARIA">Diária</SelectItem>
                      <SelectItem value="SEMANAL">Semanal</SelectItem>
                      <SelectItem value="MENSAL">Mensal</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label className="text-[11px] uppercase tracking-widest" style={{ color: '#94A3B8' }}>Prioridade</Label>
                  <Select value={routinePriority} onValueChange={setRoutinePriority}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="alta">Alta</SelectItem>
                      <SelectItem value="media">Média</SelectItem>
                      <SelectItem value="baixa">Baixa</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              {routineFreq === 'SEMANAL' && (
                <div className="space-y-1.5">
                  <Label className="text-[11px] uppercase tracking-widest" style={{ color: '#94A3B8' }}>Dia da semana</Label>
                  <div className="flex gap-1">
                    {['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'].map((d, i) => (
                      <Button key={i} variant={routineDayOfWeek === i ? 'default' : 'outline'} size="sm"
                        className="flex-1 h-8 text-xs px-1" onClick={() => setRoutineDayOfWeek(i)}
                        style={routineDayOfWeek === i ? { background: ACCENT } : {}}>
                        {d}
                      </Button>
                    ))}
                  </div>
                </div>
              )}
              {routineFreq === 'MENSAL' && (
                <div className="space-y-1.5">
                  <Label className="text-[11px] uppercase tracking-widest" style={{ color: '#94A3B8' }}>Dia do mês</Label>
                  <Input type="number" min={1} max={31} value={routineDayOfMonth ?? ''}
                    onChange={e => setRoutineDayOfMonth(e.target.value ? Number(e.target.value) : null)} />
                </div>
              )}
              <Button className="w-full text-white" style={{ background: ACCENT }} disabled={creatingRoutine} onClick={handleCreateRoutine}>
                {creatingRoutine ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
                Criar Rotina
              </Button>
            </div>
          </DialogContent>
        </Dialog>

        {/* ═══════════ MODAL CONFIRMAÇÃO ═══════════ */}
        <Dialog open={!!confirmModal} onOpenChange={(open) => { if (!open) { setConfirmModal(null); setConfirmObs(''); } }}>
          <DialogContent className="max-w-sm">
            <DialogHeader>
              <DialogTitle>
                {confirmModal?.type === 'recebimento' ? '📦 Confirmar Recebimento' : '🚚 Registrar Entrega ao Cliente'}
              </DialogTitle>
              <DialogDescription>
                {confirmModal?.title}
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 pt-2">
              <div className="space-y-1.5">
                <Label className="text-[11px] uppercase tracking-widest" style={{ color: '#94A3B8' }}>Observações (opcional)</Label>
                <Textarea value={confirmObs} onChange={e => setConfirmObs(e.target.value)} rows={3} placeholder="Alguma observação..." />
              </div>
              <Button className="w-full text-white" style={{ background: confirmModal?.type === 'recebimento' ? ACCENT : '#10B981' }}
                disabled={changeStatus.isPending}
                onClick={confirmModal?.type === 'recebimento' ? handleConfirmRecebimento : handleConfirmEntrega}>
                {changeStatus.isPending ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
                Confirmar
              </Button>
            </div>
          </DialogContent>
        </Dialog>

        {/* ═══════════════ ABA PERFIL ═══════════════ */}
        {activeTab === 'perfil' && seller?.id && (
          <ProfileHubContent
            sellerId={seller.id}
            isOwnProfile={true}
            canSeeDetails={true}
          />
        )}

      </div>
    </div>
  );
}
