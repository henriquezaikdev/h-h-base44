import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, ChevronDown, ChevronUp, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface AIAssistantFieldProps {
  sellerId: string | null;
  tasksCount: number;
  overdueCount: number;
  topClientsCount: number;
}

export function AIAssistantField({ sellerId, tasksCount, overdueCount, topClientsCount }: AIAssistantFieldProps) {
  const [expanded, setExpanded] = useState(false);
  const [loading, setLoading] = useState(false);
  const [suggestion, setSuggestion] = useState<string | null>(null);

  const generateSuggestion = async () => {
    if (!sellerId) return;
    
    setLoading(true);
    try {
      const context = `
        Tarefas pendentes: ${tasksCount}
        Tarefas atrasadas: ${overdueCount}
        Clientes Top que precisam de atenção: ${topClientsCount}
      `;

      const { data, error } = await supabase.functions.invoke('perplexity-assistant', {
        body: {
          mode: 'ask',
          sellerId,
          contextText: context,
          userQuestion: 'Como devo priorizar meu dia de trabalho? Quais tarefas e clientes devo focar primeiro?',
          copyForWhatsApp: false
        }
      });

      if (error) throw error;
      setSuggestion(data?.answer || 'Foque primeiro nas tarefas atrasadas, depois nos clientes Top sem contato recente.');
    } catch (err) {
      console.error('Error generating suggestion:', err);
      // Fallback suggestion
      if (overdueCount > 0) {
        setSuggestion(`Você tem ${overdueCount} tarefa(s) atrasada(s). Priorize resolvê-las antes de novas ações. Foque nos clientes Top 20 primeiro.`);
      } else if (tasksCount > 0) {
        setSuggestion(`Você tem ${tasksCount} tarefa(s) para hoje. Organize por prioridade: Top 20 primeiro, depois Top 100.`);
      } else {
        setSuggestion('Dia tranquilo! Aproveite para prospectar novos clientes ou fazer contatos de manutenção.');
      }
    } finally {
      setLoading(false);
      setExpanded(true);
    }
  };

  return (
    <Card className="border-violet-500/30 bg-card">
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-violet-500/10 border border-violet-500/20 flex items-center justify-center">
              <Sparkles className="h-5 w-5 text-violet-600" />
            </div>
            <div>
              <h3 className="font-medium text-sm">Assistente de Priorização</h3>
              <p className="text-xs text-muted-foreground">
                IA para organizar seu dia
              </p>
            </div>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => {
              if (!suggestion) {
                generateSuggestion();
              } else {
                setExpanded(!expanded);
              }
            }}
            disabled={loading}
            className="gap-2"
          >
            {loading ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                Analisando...
              </>
            ) : suggestion ? (
              <>
                {expanded ? 'Ocultar' : 'Ver sugestão'}
                {expanded ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
              </>
            ) : (
              <>
                <Sparkles className="h-4 w-4" />
                Sugerir prioridades
              </>
            )}
          </Button>
        </div>

        <AnimatePresence>
          {expanded && suggestion && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="overflow-hidden"
            >
              <div className="mt-4 pt-4 border-t border-violet-500/20">
                <p className="text-sm text-foreground leading-relaxed">
                  {suggestion}
                </p>
                <Button
                  variant="link"
                  size="sm"
                  className="text-violet-600 p-0 h-auto mt-2"
                  onClick={generateSuggestion}
                  disabled={loading}
                >
                  Gerar nova sugestão
                </Button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </CardContent>
    </Card>
  );
}
