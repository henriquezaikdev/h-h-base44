import { useState } from 'react';
import { format, parseISO, isPast, isToday } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { ChevronDown, ChevronUp, Phone, MessageCircle, Clock, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';

interface Task {
  id: string;
  clientId: string;
  clientName: string;
  clientRankingTier?: string;
  contactType: string;
  taskDate: string;
  taskTime?: string | null;
  notes?: string | null;
  priority: string;
  status: string;
}

interface TasksTableProps {
  tasks: Task[];
  onComplete: (task: Task) => void;
  onTaskClick: (task: Task) => void;
}

const RANKING_LABELS: Record<string, { label: string; emoji: string }> = {
  top20: { label: 'Top 20', emoji: '🏆' },
  top100: { label: 'Top 100', emoji: '🥈' },
  top200: { label: 'Top 200', emoji: '🥉' },
  eventual: { label: 'Eventual', emoji: '📋' },
};

export const TasksTable = ({ tasks, onComplete, onTaskClick }: TasksTableProps) => {
  const [expanded, setExpanded] = useState(true);

  // Sort by date (oldest/most overdue first)
  const sortedTasks = [...tasks].sort((a, b) => {
    const aDate = parseISO(a.taskDate);
    const bDate = parseISO(b.taskDate);
    return aDate.getTime() - bDate.getTime();
  });

  const overdueCount = sortedTasks.filter(t => {
    const d = parseISO(t.taskDate);
    return isPast(d) && !isToday(d);
  }).length;

  const todayCount = sortedTasks.filter(t => isToday(parseISO(t.taskDate))).length;

  return (
    <div className="rounded-xl border border-border bg-card overflow-hidden">
      {/* Header */}
      <button
        onClick={() => setExpanded(!expanded)}
        className="w-full flex items-center justify-between p-4 hover:bg-muted/20 transition-colors"
      >
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center">
            <Clock className="h-5 w-5 text-primary" />
          </div>
          <div className="text-left">
            <h3 className="font-semibold text-foreground">Tarefas por Vencimento</h3>
            <p className="text-sm text-muted-foreground">
              {sortedTasks.length} tarefas
              {overdueCount > 0 && (
                <span className="text-destructive ml-2">• {overdueCount} atrasadas</span>
              )}
              {todayCount > 0 && (
                <span className="text-amber-600 ml-2">• {todayCount} hoje</span>
              )}
            </p>
          </div>
        </div>
        {expanded ? (
          <ChevronUp className="h-5 w-5 text-muted-foreground" />
        ) : (
          <ChevronDown className="h-5 w-5 text-muted-foreground" />
        )}
      </button>

      {/* Table */}
      {expanded && sortedTasks.length > 0 && (
        <div className="border-t border-border">
          <Table>
            <TableHeader>
              <TableRow className="hover:bg-transparent">
                <TableHead className="w-[50px]">Tipo</TableHead>
                <TableHead>Cliente</TableHead>
                <TableHead className="w-[100px]">Ranking</TableHead>
                <TableHead className="w-[120px]">Data</TableHead>
                <TableHead className="w-[100px]">Prioridade</TableHead>
                <TableHead className="w-[100px] text-right">Ação</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sortedTasks.map((task) => {
                const taskDate = parseISO(task.taskDate);
                const isOverdue = isPast(taskDate) && !isToday(taskDate);
                const isTaskToday = isToday(taskDate);
                const ranking = RANKING_LABELS[task.clientRankingTier || 'eventual'];

                return (
                  <TableRow
                    key={task.id}
                    onClick={() => onTaskClick(task)}
                    className={cn(
                      "cursor-pointer transition-colors",
                      isOverdue && "bg-destructive/5 hover:bg-destructive/10",
                      isTaskToday && !isOverdue && "bg-amber-50/50 dark:bg-amber-950/20 hover:bg-amber-50 dark:hover:bg-amber-950/30"
                    )}
                  >
                    <TableCell>
                      <div className={cn(
                        "w-8 h-8 rounded-lg flex items-center justify-center",
                        task.contactType === 'ligacao' ? 'bg-primary/10' : 'bg-green-500/10'
                      )}>
                        {task.contactType === 'ligacao' ? (
                          <Phone className="h-4 w-4 text-primary" />
                        ) : (
                          <MessageCircle className="h-4 w-4 text-green-600" />
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <span className="font-medium">{task.clientName}</span>
                        {isOverdue && (
                          <AlertTriangle className="h-4 w-4 text-destructive" />
                        )}
                      </div>
                      {task.notes && (
                        <p className="text-xs text-muted-foreground truncate max-w-[200px]">
                          {task.notes}
                        </p>
                      )}
                    </TableCell>
                    <TableCell>
                      <span className="text-sm">
                        {ranking.emoji} {ranking.label}
                      </span>
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-col">
                        <span className={cn(
                          "text-sm font-medium",
                          isOverdue && "text-destructive",
                          isTaskToday && !isOverdue && "text-amber-600"
                        )}>
                          {format(taskDate, "dd/MM/yyyy", { locale: ptBR })}
                        </span>
                        {task.taskTime && (
                          <span className="text-xs text-muted-foreground">
                            {task.taskTime.slice(0, 5)}
                          </span>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant={
                          task.priority === 'alta' ? 'destructive' :
                          task.priority === 'media' ? 'default' : 'secondary'
                        }
                        className="text-xs"
                      >
                        {task.priority === 'alta' ? 'Alta' :
                         task.priority === 'media' ? 'Média' : 'Baixa'}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={(e) => {
                          e.stopPropagation();
                          onComplete(task);
                        }}
                        className="h-8"
                      >
                        Concluir
                      </Button>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      )}

      {expanded && sortedTasks.length === 0 && (
        <div className="p-8 text-center border-t border-border bg-card">
          <p className="text-muted-foreground">Nenhuma tarefa pendente</p>
          <p className="text-xs text-muted-foreground/60 mt-1">Ótimo momento para planejar novas ações!</p>
        </div>
      )}
    </div>
  );
};
