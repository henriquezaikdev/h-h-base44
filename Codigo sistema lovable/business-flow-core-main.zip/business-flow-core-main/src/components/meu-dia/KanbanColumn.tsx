import { motion } from 'framer-motion';
import { Phone, MessageCircle, Clock, AlertTriangle, ExternalLink } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { format, parseISO, isToday, isPast } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface KanbanTask {
  id: string;
  clientId: string;
  clientName: string;
  contactType: string;
  contactReason?: string;
  taskDate: string;
  taskTime: string | null;
  notes: string | null;
  priority: 'alta' | 'media' | 'baixa';
  status: string;
  clientRankingTier?: string;
  clientSellerId?: string | null;
  createdAt?: string;
  completedAt?: string | null;
  createdBySellerId?: string | null;
}

interface KanbanColumnProps {
  title: string;
  emoji: string;
  tasks: KanbanTask[];
  colorClass: string;
  onComplete: (task: KanbanTask) => void;
  onTaskClick?: (task: KanbanTask) => void;
}

const PRIORITY_CONFIG = {
  alta: { className: 'bg-red-500/10 text-red-600 border-red-500/20' },
  media: { className: 'bg-amber-500/10 text-amber-600 border-amber-500/20' },
  baixa: { className: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20' },
};

export function KanbanColumn({ title, emoji, tasks, colorClass, onComplete, onTaskClick }: KanbanColumnProps) {
  const getTaskStatus = (task: KanbanTask) => {
    const taskDate = parseISO(task.taskDate);
    if (isPast(taskDate) && !isToday(taskDate)) return 'atrasada';
    if (isToday(taskDate)) return 'hoje';
    return 'futura';
  };

  const handleTaskClick = (task: KanbanTask) => {
    if (onTaskClick) {
      onTaskClick(task);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex flex-col bg-card rounded-xl border border-border min-h-[400px] max-h-[calc(100vh-280px)]"
    >
      {/* Column Header */}
      <div className={cn(
        "px-4 py-3 rounded-t-xl flex items-center justify-between",
        colorClass
      )}>
        <div className="flex items-center gap-2">
          <span className="text-lg">{emoji}</span>
          <h3 className="font-semibold text-sm text-foreground">{title}</h3>
        </div>
        <Badge variant="secondary" className="text-xs bg-muted/80">
          {tasks.length}
        </Badge>
      </div>

      {/* Column Content */}
      <div className="flex-1 overflow-y-auto p-3 space-y-2 bg-muted/20">
        {tasks.length === 0 ? (
          <div className="text-center py-8">
            <p className="text-sm text-muted-foreground">Nenhuma ação pendente</p>
            <p className="text-xs text-muted-foreground/60 mt-1">Excelente! Continue assim.</p>
          </div>
        ) : (
          tasks.map((task) => {
            const status = getTaskStatus(task);
            const isLigacao = task.contactType === 'ligacao';
            const priorityConfig = PRIORITY_CONFIG[task.priority] || PRIORITY_CONFIG.media;

            return (
              <motion.div
                key={task.id}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                whileHover={{ scale: 1.02 }}
                className={cn(
                  "p-3 rounded-lg border bg-card cursor-pointer transition-all hover:shadow-md",
                  status === 'atrasada' && "border-destructive/40 bg-destructive/5",
                  status === 'hoje' && "border-amber-500/40 bg-amber-50/50 dark:bg-amber-950/20",
                  status === 'futura' && "border-border"
                )}
                onClick={() => handleTaskClick(task)}
              >
                {/* Task Header */}
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div className="flex items-center gap-2 min-w-0">
                    <div className={cn(
                      "w-7 h-7 rounded-md flex items-center justify-center shrink-0 border",
                      isLigacao ? 'bg-primary/10 border-primary/20' : 'bg-green-500/10 border-green-500/20'
                    )}>
                      {isLigacao ? (
                        <Phone className="h-3.5 w-3.5 text-primary" />
                      ) : (
                        <MessageCircle className="h-3.5 w-3.5 text-green-600" />
                      )}
                    </div>
                    <span className="font-semibold text-sm truncate text-foreground">{task.clientName || 'Tarefa Geral'}</span>
                  </div>
                  <Badge variant="outline" className={cn("text-[10px] px-1 h-4 shrink-0", priorityConfig.className)}>
                    {task.priority === 'alta' ? '!' : task.priority === 'media' ? '•' : '○'}
                  </Badge>
                </div>

                {/* Task Details */}
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Clock className="h-3 w-3" />
                  <span>{format(parseISO(task.taskDate), "dd/MM", { locale: ptBR })}</span>
                  {task.taskTime && <span>às {task.taskTime.slice(0, 5)}</span>}
                  {status === 'atrasada' && (
                    <span className="flex items-center gap-1 text-destructive font-medium ml-auto">
                      <AlertTriangle className="h-3 w-3" />
                      Atrasada
                    </span>
                  )}
                </div>

                {/* Notes Preview — improved readability */}
                {task.notes && (
                  <p className="text-xs text-muted-foreground mt-2 line-clamp-2 leading-relaxed">
                    {task.notes}
                  </p>
                )}

                {/* Quick Actions */}
                <div className="flex items-center justify-end gap-1 mt-2 pt-2 border-t border-border/50">
                  <Button
                    size="sm"
                    variant="ghost"
                    className="h-6 text-xs text-primary hover:bg-primary/10"
                    onClick={(e) => {
                      e.stopPropagation();
                      onComplete(task);
                    }}
                  >
                    Concluir
                  </Button>
                </div>
              </motion.div>
            );
          })
        )}
      </div>
    </motion.div>
  );
}