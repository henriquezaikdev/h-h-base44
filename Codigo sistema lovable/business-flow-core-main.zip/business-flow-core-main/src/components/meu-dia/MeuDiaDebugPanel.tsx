import { useEffect, useMemo, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

function saoPauloDayKey(date: Date): string {
  return new Intl.DateTimeFormat('sv-SE', {
    timeZone: 'America/Sao_Paulo',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(date);
}

function saoPauloDayRange(date: Date) {
  const dayKey = saoPauloDayKey(date);
  const startIso = `${dayKey}T00:00:00-03:00`;
  const endIso = `${dayKey}T23:59:59.999-03:00`;
  return { dayKey, startIso, endIso };
}

function isCallType(type: string): boolean {
  const t = (type || '').toLowerCase();
  return t.includes('ligaç') || t.includes('ligac') || t === 'ligacao' || t === 'ligação';
}

function isWhatsappType(type: string): boolean {
  const t = (type || '').toLowerCase();
  return t.includes('whatsapp') || t.includes('whats');
}

type DebugInteraction = {
  id: string;
  interaction_type: string;
  interaction_date: string;
  interaction_time: string | null;
  responsible_seller_id: string;
};

type DebugTask = {
  id: string;
  contact_type: string;
  status: string;
  completed_at: string | null;
  created_by_seller_id: string | null;
  client_id: string;
  client?: { seller_id: string | null } | null;
};

export function MeuDiaDebugPanel({ effectiveSellerId }: { effectiveSellerId: string }) {
  const [loading, setLoading] = useState(false);
  const [interactions, setInteractions] = useState<DebugInteraction[]>([]);
  const [tasks, setTasks] = useState<DebugTask[]>([]);

  const { dayKey, startIso, endIso } = useMemo(() => saoPauloDayRange(new Date()), []);

  const fetchDebug = async () => {
    setLoading(true);
    try {
      const [{ data: interactionsData }, { data: tasksData }] = await Promise.all([
        supabase
          .from('interactions')
          .select('id, interaction_type, interaction_date, interaction_time, responsible_seller_id')
          .eq('responsible_seller_id', effectiveSellerId)
          .eq('interaction_date', dayKey)
          .order('interaction_date', { ascending: false })
          .limit(5),
        supabase
          .from('tasks')
          .select(
            'id, contact_type, status, completed_at, created_by_seller_id, client_id, client:clients!tasks_client_id_fkey(seller_id)'
          )
          .eq('status', 'concluida')
          .gte('completed_at', startIso)
          .lte('completed_at', endIso)
          .eq('client.seller_id', effectiveSellerId)
          .order('completed_at', { ascending: false })
          .limit(5),
      ]);

      setInteractions((interactionsData || []) as DebugInteraction[]);
      setTasks((tasksData || []) as DebugTask[]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDebug();

    const channel = supabase
      .channel(`meu-dia-debug-${effectiveSellerId}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'interactions' }, fetchDebug)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'tasks' }, fetchDebug)
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [effectiveSellerId]);

  const rawCounts = useMemo(() => {
    const interactionsTodayCount = interactions.length;
    const tasksCompletedTodayCount = tasks.length;

    const callsTodayCount =
      interactions.filter((i) => isCallType(i.interaction_type)).length +
      tasks.filter((t) => isCallType(t.contact_type)).length;

    const whatsappTodayCount =
      interactions.filter((i) => isWhatsappType(i.interaction_type)).length +
      tasks.filter((t) => isWhatsappType(t.contact_type)).length;

    return {
      interactionsTodayCount,
      tasksCompletedTodayCount,
      callsTodayCount,
      whatsappTodayCount,
      contactsTodayCount: interactionsTodayCount + tasksCompletedTodayCount,
    };
  }, [interactions, tasks]);

  return (
    <Card className="border-destructive/30 bg-destructive/5">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between gap-3">
          <CardTitle className="text-sm">DEBUG (admin) — Contagens do Meu Dia</CardTitle>
          <Button variant="outline" size="sm" onClick={fetchDebug} disabled={loading}>
            {loading ? 'Atualizando...' : 'Atualizar'}
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex flex-wrap items-center gap-2">
          <Badge variant="secondary">effectiveSellerId: {effectiveSellerId}</Badge>
          <Badge variant="secondary">dayKey: {dayKey}</Badge>
          <Badge variant="secondary">start: {startIso}</Badge>
          <Badge variant="secondary">end: {endIso}</Badge>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
          <div className="p-2 rounded-md bg-card border">
            <div className="text-xs text-muted-foreground">Interações (hoje)</div>
            <div className="text-lg font-semibold">{rawCounts.interactionsTodayCount}</div>
          </div>
          <div className="p-2 rounded-md bg-card border">
            <div className="text-xs text-muted-foreground">Tarefas concl. (hoje)</div>
            <div className="text-lg font-semibold">{rawCounts.tasksCompletedTodayCount}</div>
          </div>
          <div className="p-2 rounded-md bg-card border">
            <div className="text-xs text-muted-foreground">Ligações (hoje)</div>
            <div className="text-lg font-semibold">{rawCounts.callsTodayCount}</div>
          </div>
          <div className="p-2 rounded-md bg-card border">
            <div className="text-xs text-muted-foreground">WhatsApp (hoje)</div>
            <div className="text-lg font-semibold">{rawCounts.whatsappTodayCount}</div>
          </div>
          <div className="p-2 rounded-md bg-card border">
            <div className="text-xs text-muted-foreground">Contatos (hoje)</div>
            <div className="text-lg font-semibold">{rawCounts.contactsTodayCount}</div>
          </div>
        </div>

        <div className="space-y-2">
          <div className="text-xs font-medium text-foreground">Últimas 5 interações usadas</div>
          <pre className="text-xs whitespace-pre-wrap bg-card border rounded-md p-2 overflow-auto max-h-56">
            {JSON.stringify(interactions, null, 2)}
          </pre>
        </div>

        <div className="space-y-2">
          <div className="text-xs font-medium text-foreground">Últimas 5 tarefas concluídas usadas</div>
          <pre className="text-xs whitespace-pre-wrap bg-card border rounded-md p-2 overflow-auto max-h-56">
            {JSON.stringify(tasks, null, 2)}
          </pre>
        </div>
      </CardContent>
    </Card>
  );
}
