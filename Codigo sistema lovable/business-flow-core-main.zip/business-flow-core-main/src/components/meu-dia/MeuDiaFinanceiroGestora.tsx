import { useState, useMemo, lazy, Suspense } from 'react';
import { format } from 'date-fns';
import { TasksErrorBoundary } from '@/components/meu-dia/TasksErrorFallback';
import { ptBR } from 'date-fns/locale';
import { Loader2, Zap, ShoppingCart, DollarSign, User } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { useFinanceiroGestoraData } from '@/hooks/useFinanceiroGestoraData';
import { useAuth } from '@/hooks/useAuth';
import { useSellersData } from '@/hooks/useSellersData';
import { cn } from '@/lib/utils';
import { AdminTarefasTab } from './financeiro/tabs/AdminTarefasTab';
import { AdminComprasTab } from './financeiro/tabs/AdminComprasTab';
import { AdminFinanceiroTab } from './financeiro/tabs/AdminFinanceiroTab';
import { ProfileHubContent } from '@/components/profile/ProfileHubContent';

const TABS = [
  { key: 'tarefas', label: 'Tarefas', icon: Zap },
  { key: 'compras', label: 'Compras', icon: ShoppingCart },
  { key: 'financeiro', label: 'Financeiro', icon: DollarSign },
  { key: 'perfil', label: 'Perfil', icon: User },
] as const;

export function MeuDiaFinanceiroGestora() {
  const { seller } = useAuth();
  const { sellers } = useSellersData();
  const finData = useFinanceiroGestoraData();
  const [activeTab, setActiveTab] = useState<string>('tarefas');

  // Badge counts
  const comprasPendingCount = useMemo(() => {
    return finData.pendencies.filter(p =>
      (p.source === 'solicitacoes' || p.source === 'cotacoes') &&
      ['NOVA_SOLICITACAO', 'AGUARDANDO_COMPRADOR', 'AGUARDANDO'].includes(p.status)
    ).length;
  }, [finData.pendencies]);

  const financeiroPendingCount = useMemo(() => {
    return finData.pendencies.filter(p => p.type === 'FINANCEIRO').length;
  }, [finData.pendencies]);

  const handleRefresh = () => {
    finData.refetch();
  };

  if (finData.loading) {
    return (
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center gap-0 border-b border-border/60 mb-8">
          {TABS.map(tab => {
            const Icon = tab.icon;
            return (
              <div key={tab.key} className="flex items-center gap-2 px-5 py-3.5 text-sm text-muted-foreground">
                <Icon className="h-4 w-4" />
                <div className="h-4 w-16 bg-muted animate-pulse rounded" />
              </div>
            );
          })}
        </div>
        <div className="space-y-4">
          {[1,2,3].map(i => <div key={i} className="h-20 bg-muted animate-pulse rounded-xl" />)}
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto">
      {/* TABS */}
      <div className="flex items-center gap-0 border-b border-border/60 mb-8">
        {TABS.map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.key;
          const badgeCount = tab.key === 'compras' ? comprasPendingCount
            : tab.key === 'financeiro' ? financeiroPendingCount
            : 0;

          return (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={cn(
                'relative flex items-center gap-2 px-5 py-3.5 text-sm font-medium transition-colors',
                isActive
                  ? 'text-foreground font-bold'
                  : 'text-muted-foreground hover:text-foreground'
              )}
            >
              <Icon className="h-4 w-4" />
              {tab.label}
              {badgeCount > 0 && (
                <Badge className="h-5 min-w-[20px] px-1.5 text-[10px] font-bold bg-red-500 text-white border-0">
                  {badgeCount}
                </Badge>
              )}
              {isActive && (
                <span className="absolute bottom-0 left-0 right-0 h-[2.5px] bg-orange-500 rounded-t-full" />
              )}
            </button>
          );
        })}
      </div>

      {/* TAB CONTENT */}
      {activeTab === 'tarefas' && (
        <TasksErrorBoundary>
          <AdminTarefasTab
            seller={seller}
            sellers={sellers}
            finData={finData}
            onRefresh={handleRefresh}
          />
        </TasksErrorBoundary>
      )}
      {activeTab === 'compras' && (
        <AdminComprasTab pendencies={finData.pendencies} />
      )}
      {activeTab === 'financeiro' && (
        <AdminFinanceiroTab />
      )}
      {activeTab === 'perfil' && seller && (
        <ProfileHubContent
          sellerId={seller.id}
          isOwnProfile={true}
          canSeeDetails={true}
        />
      )}
    </div>
  );
}
