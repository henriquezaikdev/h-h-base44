import React, { useState, useMemo, useEffect } from 'react';
import { ProfileHubContent } from '@/components/profile/ProfileHubContent';
import { EvolutionEmbed } from '@/components/meu-dia/EvolutionEmbed';
import { TasksErrorBoundary } from '@/components/meu-dia/TasksErrorFallback';
import { RHHojeCard } from '@/components/rh/RHHojeCard';
import { TaskUnifiedModal } from '@/components/tasks/TaskUnifiedModal';
import { DeleteTaskModal } from '@/components/tasks/DeleteTaskModal';
import { useAuth } from '@/hooks/useAuth';
import { useTasksData, TaskData } from '@/hooks/useTasksData';
import { useSellersData, SellerRow } from '@/hooks/useSellersData';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { format, isToday, isBefore, startOfDay, startOfWeek, endOfWeek, startOfMonth, endOfMonth, differenceInCalendarDays } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import {
  BarChart3, CheckSquare, Users,
  Plus, ChevronDown, ChevronRight,
  Loader2, CheckCircle2, CalendarIcon, Eye, Trash2, Star, Medal, Trophy
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import {
  Drawer, DrawerContent, DrawerHeader, DrawerTitle, DrawerDescription, DrawerClose,
} from '@/components/ui/drawer';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';

type OwnerTab = 'vendas' | 'tarefas' | 'equipe' | 'perfil' | 'evolucao';
type PeriodFilter = 'hoje' | 'semana' | 'mes';

const TASK_CATEGORIES = [
  'Financeiro', 'Comercial', 'Operacional', 'Estoque', 'RH', 'Estratégico', 'Geral',
] as const;

function getGreeting(name: string) {
  const h = new Date().getHours();
  const prefix = h < 12 ? 'Bom dia' : h < 18 ? 'Boa tarde' : 'Boa noite';
  return `${prefix}, ${name.split(' ')[0]}`;
}

function getPeriodRange(period: PeriodFilter) {
  const now = new Date();
  if (period === 'hoje') return { start: startOfDay(now), end: now };
  if (period === 'semana') return { start: startOfWeek(now, { locale: ptBR }), end: endOfWeek(now, { locale: ptBR }) };
  return { start: startOfMonth(now), end: endOfMonth(now) };
}

function MetricCard({ label, value, color = 'neutral' }: { label: string; value: number; color?: 'neutral' | 'warning' | 'danger' | 'success' }) {
  return (
    <div className="h-[72px] flex flex-col justify-between p-4 rounded-xl bg-card border border-border shadow-hh-sm transition-all hover:shadow-hh-md">
      <span className="text-[11px] uppercase tracking-[0.08em] font-semibold text-muted-foreground">{label}</span>
      <span className={cn(
        "text-[22px] font-semibold leading-none",
        value > 0 && color === 'danger' && "text-destructive",
        value > 0 && color === 'warning' && "text-status-warning",
        value > 0 && color === 'success' && "text-status-success",
        (color === 'neutral' || value === 0) && "text-foreground",
      )}>{value}</span>
    </div>
  );
}

function NovaOwnerTaskDrawer({
  open, onOpenChange, sellers, prefillDelegateTo,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  sellers: SellerRow[];
  prefillDelegateTo?: string;
}) {
  const { seller } = useAuth();
  const queryClient = useQueryClient();
  const [saving, setSaving] = useState(false);
  const [titulo, setTitulo] = useState('');
  const [categoria, setCategoria] = useState('Geral');
  const [data, setData] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [prioridade, setPrioridade] = useState<'alta' | 'media' | 'baixa'>('media');
  const [delegarPara, setDelegarPara] = useState(prefillDelegateTo || '__none__');
  const [observacoes, setObservacoes] = useState('');

  const reset = () => {
    setTitulo(''); setCategoria('Geral'); setData(format(new Date(), 'yyyy-MM-dd'));
    setPrioridade('media'); setDelegarPara('__none__'); setObservacoes('');
  };

  const handleSave = async () => {
    if (!titulo.trim()) { toast.error('Título é obrigatório'); return; }
    setSaving(true);
    try {
      const uniqueKey = `owner-${seller?.id}-${Date.now()}`;
      const { error } = await supabase.from('tasks').insert([{
        notes: observacoes || null,
        task_date: data,
        task_time: null,
        contact_type: 'ligacao',
        contact_reason: 'RETORNO',
        priority: prioridade,
        status: 'pendente',
        task_category: categoria,
        created_by_seller_id: seller?.id || null,
        assigned_to_seller_id: delegarPara === '__none__' ? null : delegarPara,
        client_id: null,
        planning_notes: titulo,
        unique_key: uniqueKey,
      }]);
      if (error) throw error;
      toast.success('Tarefa criada com sucesso');
      queryClient.invalidateQueries({ queryKey: ['tasks'] });
      reset();
      onOpenChange(false);
    } catch (e: any) {
      toast.error(e.message || 'Erro ao criar tarefa');
    } finally {
      setSaving(false);
    }
  };

  return (
    <Drawer open={open} onOpenChange={onOpenChange}>
      <DrawerContent className="max-h-[90vh]">
        <DrawerHeader>
          <DrawerTitle className="text-base font-semibold text-foreground">Nova Tarefa</DrawerTitle>
          <DrawerDescription className="text-[13px] text-muted-foreground">Crie uma tarefa e delegue se necessário</DrawerDescription>
        </DrawerHeader>
        <div className="px-6 pb-6 space-y-4 overflow-y-auto">
          <div>
            <label className="text-[11px] uppercase tracking-[0.08em] font-semibold text-muted-foreground">Título *</label>
            <Input value={titulo} onChange={e => setTitulo(e.target.value)} placeholder="Ex: Revisar contratos" className="mt-1" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-[11px] uppercase tracking-[0.08em] font-semibold text-muted-foreground">Categoria</label>
              <Select value={categoria} onValueChange={setCategoria}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {TASK_CATEGORIES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-[11px] uppercase tracking-[0.08em] font-semibold text-muted-foreground">Data</label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className={cn("w-full mt-1 justify-start text-left font-normal", !data && "text-muted-foreground")}>
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {data ? format(new Date(data + 'T12:00:00'), "dd/MM/yyyy") : 'Selecionar data'}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0 z-[10200]" align="start">
                  <Calendar
                    mode="single"
                    selected={data ? new Date(data + 'T12:00:00') : undefined}
                    onSelect={(d) => d && setData(format(d, 'yyyy-MM-dd'))}
                    locale={ptBR}
                    initialFocus
                    className="pointer-events-auto"
                  />
                </PopoverContent>
              </Popover>
            </div>
          </div>
          <div>
            <label className="text-[11px] uppercase tracking-[0.08em] font-semibold text-muted-foreground">Prioridade</label>
            <div className="flex gap-2 mt-1">
              {(['alta', 'media', 'baixa'] as const).map(p => (
                <button key={p} onClick={() => setPrioridade(p)}
                  className={cn(
                    'px-3 py-1.5 rounded text-[11px] font-semibold border transition-colors',
                    prioridade === p && p === 'alta' && 'hh-badge-danger',
                    prioridade === p && p === 'media' && 'hh-badge-warning',
                    prioridade === p && p === 'baixa' && 'hh-badge-neutral',
                    prioridade !== p && 'text-muted-foreground border-border bg-transparent',
                  )}>
                  {p === 'alta' ? 'Alta' : p === 'media' ? 'Média' : 'Baixa'}
                </button>
              ))}
            </div>
          </div>
          <div>
            <label className="text-[11px] uppercase tracking-[0.08em] font-semibold text-muted-foreground">Delegar para</label>
            <Select value={delegarPara} onValueChange={setDelegarPara}>
              <SelectTrigger className="mt-1"><SelectValue placeholder="Ninguém (minha tarefa)" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="__none__">Ninguém (minha tarefa)</SelectItem>
                {sellers.filter(s => s.id !== seller?.id).map(s => (
                  <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <label className="text-[11px] uppercase tracking-[0.08em] font-semibold text-muted-foreground">Observações</label>
            <Textarea value={observacoes} onChange={e => setObservacoes(e.target.value)} placeholder="Detalhes..." className="mt-1" rows={3} />
          </div>
          <div className="flex gap-3 pt-2">
            <DrawerClose asChild>
              <Button variant="outline" className="flex-1">Cancelar</Button>
            </DrawerClose>
            <Button onClick={handleSave} disabled={saving} className="flex-1 gap-2">
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
              Criar Tarefa
            </Button>
          </div>
        </div>
      </DrawerContent>
    </Drawer>
  );
}

export function OwnerTarefasTab({ sellers }: { sellers: SellerRow[] }) {
  const { seller } = useAuth();
  const { tasks, loading } = useTasksData(undefined, seller?.id);
  const queryClient = useQueryClient();
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [expandedGroups, setExpandedGroups] = useState<Record<string, boolean>>({ alta: true, media: true, baixa: false });
  const [delegatePrefill, setDelegatePrefill] = useState('');
  const [queryError, setQueryError] = useState(false);
  const [editingTask, setEditingTask] = useState<TaskData | null>(null);
  const [deletingTaskId, setDeletingTaskId] = useState<string | null>(null);

  const today = startOfDay(new Date());

  const myTasks = useMemo(() =>
    (tasks || []).filter(t => t.status !== 'concluida' && t.createdBySellerId === seller?.id &&
      (!t.assignedToSellerId || t.assignedToSellerId === seller?.id)),
    [tasks, seller?.id]
  );

  const delegatedByMe = useMemo(() =>
    (tasks || []).filter(t => t.createdBySellerId === seller?.id &&
      t.assignedToSellerId && t.assignedToSellerId !== seller?.id &&
      // Show pending OR completed-but-not-confirmed-by-manager
      (t.status === 'pendente' || (t.status === 'concluida' && !t.managerConfirmedAt))),
    [tasks, seller?.id]
  );

  const dueToday = useMemo(() => (tasks || []).filter(t => t.status !== 'concluida' && isToday(new Date(t.taskDate))).length, [tasks]);
  const overdue = useMemo(() => (tasks || []).filter(t => t.status !== 'concluida' &&
    isBefore(new Date(t.taskDate), today)).length, [tasks, today]);

  const groupByPriority = (list: TaskData[]) => {
    const grouped: Record<string, TaskData[]> = { alta: [], media: [], baixa: [] };
    list.forEach(t => grouped[t.priority]?.push(t));
    return grouped;
  };

  const grouped = groupByPriority(myTasks);
  const sellerMap = useMemo(() => {
    const m: Record<string, string> = {};
    sellers.forEach(s => { m[s.id] = s.name; });
    return m;
  }, [sellers]);

  const delegatedGrouped = useMemo(() => {
    const g: Record<string, TaskData[]> = {};
    delegatedByMe.forEach(t => {
      const key = t.assignedToSellerId || 'unknown';
      if (!g[key]) g[key] = [];
      g[key].push(t);
    });
    return g;
  }, [delegatedByMe]);

  const completeTask = async (taskId: string) => {
    await supabase.from('tasks').update({ status: 'concluida', completed_at: new Date().toISOString() }).eq('id', taskId);
    queryClient.invalidateQueries({ queryKey: ['tasks'] });
    queryClient.invalidateQueries({ queryKey: ['actionCenter'] });
    toast.success('Tarefa concluída!');
  };

   const confirmDelegatedTask = async (taskId: string) => {
    await supabase.from('tasks').update({ manager_confirmed_at: new Date().toISOString() } as any).eq('id', taskId);
    queryClient.invalidateQueries({ queryKey: ['tasks'] });
  };

  const completeAndConfirmTask = async (taskId: string) => {
    const now = new Date().toISOString();
    await supabase.from('tasks').update({ 
      status: 'concluida', 
      completed_at: now, 
      manager_confirmed_at: now 
    } as any).eq('id', taskId);
    toast.success('Tarefa concluída e confirmada!');
    queryClient.invalidateQueries({ queryKey: ['tasks'] });
    queryClient.invalidateQueries({ queryKey: ['actionCenter'] });
    toast.success('Tarefa confirmada pelo gestor!');
  };

  const priorityLabel: Record<string, string> = { alta: 'Alta', media: 'Média', baixa: 'Baixa' };

  if (!tasks || tasks.length === 0 && !loading && queryError) {
    return (
      <div className="flex flex-col items-center justify-center py-12 gap-3">
        <p className="text-sm text-muted-foreground">Erro ao carregar tarefas. Tente novamente.</p>
        <Button size="sm" variant="outline" onClick={() => { setQueryError(false); queryClient.invalidateQueries({ queryKey: ['tasks'] }); }}>
          Tentar novamente
        </Button>
      </div>
    );
  }

  if (loading) return <div className="flex justify-center py-12"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>;

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold text-foreground">{getGreeting(seller?.name || 'Gestor')}</h2>
          <p className="text-[13px] capitalize text-muted-foreground">{format(new Date(), "EEEE, d 'de' MMMM 'de' yyyy", { locale: ptBR })}</p>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <MetricCard label="Minhas Tarefas Abertas" value={myTasks.length} />
        <MetricCard label="Vencendo Hoje" value={dueToday} color="warning" />
        <MetricCard label="Atrasadas" value={overdue} color="danger" />
        <MetricCard label="Delegadas Pendentes" value={delegatedByMe.length} />
      </div>

      <div className="rounded-xl p-5 bg-card border border-border shadow-hh-sm">
        <div className="flex items-center justify-between mb-4">
          <span className="text-[11px] uppercase tracking-[0.08em] font-semibold text-muted-foreground">Minhas Tarefas</span>
          <Button size="sm" onClick={() => { setDelegatePrefill(''); setDrawerOpen(true); }} className="gap-1.5 text-[11px]">
            <Plus className="h-3 w-3" /> Nova Tarefa
          </Button>
        </div>
        {myTasks.length === 0 ? (
          <div className="text-center py-6">
            <CheckCircle2 className="h-6 w-6 mx-auto mb-2 text-status-success" />
            <p className="text-[13px] text-muted-foreground">Nenhuma tarefa pendente.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {(['alta', 'media', 'baixa'] as const).map(p => {
              const items = grouped[p];
              if (!items?.length) return null;
              return (
                <div key={p}>
                  <button onClick={() => setExpandedGroups(g => ({ ...g, [p]: !g[p] }))}
                    className="flex items-center gap-2 text-[11px] uppercase tracking-[0.08em] font-semibold text-muted-foreground mb-2">
                    {expandedGroups[p] ? <ChevronDown className="h-3 w-3" /> : <ChevronRight className="h-3 w-3" />}
                    {priorityLabel[p]} ({items.length})
                  </button>
                  {expandedGroups[p] && (
                    <div className="space-y-1 ml-5">
                      {items.map(t => (
                        <div key={t.id} className={cn(
                          "flex items-center justify-between p-3 rounded-lg border transition-all cursor-pointer hover:shadow-sm",
                          isBefore(new Date(t.taskDate), today) ? "border-destructive/20 bg-destructive/5" : "border-border bg-card"
                        )} onClick={() => setEditingTask(t)}>
                          <div className="flex-1 min-w-0">
                            <p className="text-[13px] font-medium truncate text-foreground">{t.clientName || t.planningNotes || t.notes || 'Tarefa Geral'}</p>
                            {(t.clientName && (t.planningNotes || t.notes)) && (
                              <p className="text-[11px] text-muted-foreground truncate mt-0.5">{t.planningNotes || t.notes}</p>
                            )}
                            <div className="flex items-center gap-2 mt-1">
                              {t.taskCategory && <span className="hh-badge-neutral text-[10px]">{t.taskCategory}</span>}
                              <span className="text-[11px] text-muted-foreground">{format(new Date(t.taskDate), 'dd/MM')}</span>
                            </div>
                          </div>
                          <div className="flex items-center gap-1 shrink-0">
                            <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-muted-foreground hover:text-primary" onClick={(e) => { e.stopPropagation(); setEditingTask(t); }}>
                              <Eye className="h-3.5 w-3.5" />
                            </Button>
                            <Button size="sm" variant="ghost" onClick={(e) => { e.stopPropagation(); completeTask(t.id); }} className="h-7 w-7 p-0">
                              <CheckSquare className="h-4 w-4 text-status-success" />
                            </Button>
                            <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-muted-foreground hover:text-destructive" onClick={(e) => { e.stopPropagation(); setDeletingTaskId(t.id); }}>
                              <Trash2 className="h-3.5 w-3.5" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      <div className="rounded-xl p-5 bg-card border border-border shadow-hh-sm">
        <span className="text-[11px] uppercase tracking-[0.08em] font-semibold text-muted-foreground">Delegadas por mim</span>
        {delegatedByMe.length === 0 ? (
          <p className="text-[13px] mt-4 text-center py-4 text-muted-foreground">Nenhuma tarefa delegada</p>
        ) : (
          <div className="space-y-4 mt-4">
            {Object.entries(delegatedGrouped).map(([sellerId, items]) => {
              const hasOverdue = items.some(t => isBefore(new Date(t.taskDate), today));
              return (
                <div key={sellerId}>
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold bg-muted text-muted-foreground">
                      {(sellerMap[sellerId] || '?')[0]}
                    </div>
                    <span className="text-[13px] font-medium text-foreground">{sellerMap[sellerId] || 'Desconhecido'}</span>
                    {hasOverdue && <span className="hh-badge-danger text-[10px]">Atraso</span>}
                  </div>
                  <div className="space-y-1 ml-8">
                    {items.map(t => {
                      const isCompleted = t.status === 'concluida' && !t.managerConfirmedAt;
                      return (
                        <div key={t.id} className={cn(
                          "flex items-center justify-between p-3 rounded-lg border cursor-pointer hover:ring-1 hover:ring-primary/30 transition-all",
                          isCompleted
                            ? "border-emerald-500/40 bg-emerald-500/10"
                            : isBefore(new Date(t.taskDate), today) ? "border-destructive/20 bg-destructive/5" : "border-border bg-card"
                        )} onClick={() => setEditingTask(t)}>
                          <div className="flex-1 min-w-0">
                            <p className="text-[13px] truncate text-foreground">{t.clientName || t.planningNotes || t.notes || 'Tarefa Geral'}</p>
                            <span className="text-[11px] text-muted-foreground">{format(new Date(t.taskDate), 'dd/MM')}</span>
                          </div>
                          {isCompleted ? (
                            <div className="flex items-center gap-2 shrink-0">
                              <span className="text-[10px] font-semibold text-emerald-600 bg-emerald-500/15 px-2 py-0.5 rounded-full">✓ Concluída</span>
                              <Button size="sm" variant="ghost" onClick={(e) => { e.stopPropagation(); confirmDelegatedTask(t.id); }} className="h-7 px-2 text-xs bg-emerald-600 hover:bg-emerald-700 text-white">
                                OK
                              </Button>
                            </div>
                          ) : (
                            <div className="flex items-center gap-2 shrink-0">
                              <span className={cn(
                                "text-[10px]",
                                isBefore(new Date(t.taskDate), today) ? 'hh-badge-danger' : 'hh-badge-neutral'
                              )}>
                                {isBefore(new Date(t.taskDate), today) ? 'Atrasada' : 'Pendente'}
                              </span>
                              <Button size="sm" onClick={(e) => { e.stopPropagation(); completeAndConfirmTask(t.id); }} className="h-7 px-2 text-xs bg-primary hover:bg-primary/90 text-primary-foreground">
                                Concluir
                              </Button>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      <NovaOwnerTaskDrawer open={drawerOpen} onOpenChange={setDrawerOpen} sellers={sellers} prefillDelegateTo={delegatePrefill} />

      {/* Edit task modal */}
      {editingTask && (
        <TaskUnifiedModal
          open={!!editingTask}
          onOpenChange={(open) => !open && setEditingTask(null)}
          mode="edit"
          task={editingTask}
          sellers={sellers}
          onCompleted={() => {
            setEditingTask(null);
            queryClient.invalidateQueries({ queryKey: ['tasks'] });
          }}
        />
      )}

      {/* Delete task - instant for owner */}
      {deletingTaskId && (
        <DeleteTaskModal
          open={!!deletingTaskId}
          onOpenChange={(open) => !open && setDeletingTaskId(null)}
          taskId={deletingTaskId}
          isCompleted={false}
          onDeleted={() => {
            setDeletingTaskId(null);
            queryClient.invalidateQueries({ queryKey: ['tasks'] });
            queryClient.invalidateQueries({ queryKey: ['actionCenter'] });
          }}
        />
      )}
    </div>
  );
}

function OwnerMedalHistory({ sellers, sellerMap }: { sellers: SellerRow[]; sellerMap: Record<string, SellerRow> }) {
  const [medals, setMedals] = useState<any[]>([]);
  const [loadingMedals, setLoadingMedals] = useState(true);
  const [monthFilter, setMonthFilter] = useState<string>('todos');

  useEffect(() => {
    async function fetchMedals() {
      setLoadingMedals(true);
      try {
        const { data, error } = await supabase
          .from('user_medals')
          .select('id, user_id, earned_at, context_json, period_key, medals(id, code, name, tier, description)')
          .gte('earned_at', '2026-01-01T00:00:00')
          .order('earned_at', { ascending: false });
        if (error) throw error;
        setMedals(data || []);
      } catch (err) {
        console.error('Error fetching medal history:', err);
      } finally {
        setLoadingMedals(false);
      }
    }
    fetchMedals();
  }, []);

  const months = useMemo(() => {
    const set = new Set<string>();
    medals.forEach(m => {
      const d = new Date(m.earned_at);
      set.add(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`);
    });
    return Array.from(set).sort().reverse();
  }, [medals]);

  const filteredMedals = useMemo(() => {
    if (monthFilter === 'todos') return medals;
    return medals.filter(m => {
      const d = new Date(m.earned_at);
      return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}` === monthFilter;
    });
  }, [medals, monthFilter]);

  const groupedBySeller = useMemo(() => {
    const map: Record<string, any[]> = {};
    filteredMedals.forEach(m => {
      if (!map[m.user_id]) map[m.user_id] = [];
      map[m.user_id].push(m);
    });
    return Object.entries(map)
      .map(([uid, ms]) => ({ sellerId: uid, name: sellerMap[uid]?.name || 'Desconhecido', medals: ms }))
      .sort((a, b) => b.medals.length - a.medals.length);
  }, [filteredMedals, sellerMap]);

  const tierColor = (tier: string) => {
    if (tier === 'OURO') return 'bg-amber-500/10 text-amber-600 border-amber-500/30';
    if (tier === 'PRATA') return 'bg-slate-400/10 text-slate-500 border-slate-400/30';
    return 'bg-orange-500/10 text-orange-600 border-orange-500/30';
  };

  const monthLabel = (key: string) => {
    const [y, m] = key.split('-');
    const d = new Date(Number(y), Number(m) - 1, 1);
    return format(d, "MMMM 'de' yyyy", { locale: ptBR });
  };

  if (loadingMedals) {
    return (
      <div className="rounded-xl p-5 bg-card border border-border shadow-hh-sm">
        <div className="flex items-center gap-2 mb-3">
          <Trophy className="h-4 w-4 text-amber-500" />
          <span className="text-[11px] uppercase tracking-[0.08em] font-semibold text-muted-foreground">Histórico de Medalhas</span>
        </div>
        <div className="flex justify-center py-4"><Loader2 className="h-5 w-5 animate-spin text-muted-foreground" /></div>
      </div>
    );
  }

  return (
    <div className="rounded-xl p-5 bg-card border border-border shadow-hh-sm">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-4">
        <div className="flex items-center gap-2">
          <Trophy className="h-4 w-4 text-amber-500" />
          <span className="text-[11px] uppercase tracking-[0.08em] font-semibold text-muted-foreground">
            Histórico de Medalhas — Jan/2026 até agora
          </span>
          <Badge variant="outline" className="text-[10px] ml-1">{filteredMedals.length} medalhas</Badge>
        </div>
        <div className="flex gap-1 p-0.5 rounded-md bg-muted border border-border flex-wrap">
          <button onClick={() => setMonthFilter('todos')}
            className={cn("px-3 py-1.5 text-[11px] font-medium rounded transition-colors",
              monthFilter === 'todos' ? "bg-card text-foreground shadow-hh-sm" : "text-muted-foreground")}>
            Todos
          </button>
          {months.map(m => (
            <button key={m} onClick={() => setMonthFilter(m)}
              className={cn("px-3 py-1.5 text-[11px] font-medium rounded transition-colors capitalize",
                monthFilter === m ? "bg-card text-foreground shadow-hh-sm" : "text-muted-foreground")}>
              {monthLabel(m)}
            </button>
          ))}
        </div>
      </div>

      {groupedBySeller.length === 0 ? (
        <p className="text-xs text-muted-foreground text-center py-4">Nenhuma medalha encontrada no período.</p>
      ) : (
        <div className="space-y-4">
          {groupedBySeller.map(({ sellerId, name, medals: sellerMedals }) => (
            <div key={sellerId} className="rounded-lg border border-border p-4">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-7 h-7 rounded-full flex items-center justify-center text-[11px] font-semibold bg-muted text-muted-foreground">
                  {name[0]}
                </div>
                <span className="text-[13px] font-medium text-foreground">{name}</span>
                <Badge variant="outline" className="text-[10px]">{sellerMedals.length}</Badge>
              </div>
              <div className="flex flex-wrap gap-2">
                {sellerMedals.map((um: any) => (
                  <div key={um.id} className={cn("inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-[11px] font-medium", tierColor(um.medals?.tier || 'BRONZE'))}>
                    <Medal className="h-3.5 w-3.5" />
                    <span>{um.medals?.name || 'Medalha'}</span>
                    <span className="text-[9px] opacity-70">
                      {format(new Date(um.earned_at), 'dd/MM', { locale: ptBR })}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function OwnerEquipeTab({ sellers }: { sellers: SellerRow[] }) {
  const { seller: currentSeller } = useAuth();
  const [period, setPeriod] = useState<PeriodFilter>('semana');
  const [expandedCard, setExpandedCard] = useState<string | null>(null);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [delegatePrefill, setDelegatePrefill] = useState('');
  const [praiseTarget, setPraiseTarget] = useState<string | null>(null);
  const [praiseNote, setPraiseNote] = useState('');
  const [praiseLoading, setPraiseLoading] = useState(false);

  const { start, end } = getPeriodRange(period);
  const today = startOfDay(new Date());

  const monthStart = format(startOfMonth(new Date()), 'yyyy-MM-dd');

  const { data: allTasks = [], isLoading } = useQuery({
    queryKey: ['owner-team-tasks', monthStart],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('tasks')
        .select('*, clients!tasks_client_id_fkey(company_name)')
        .eq('is_deleted', false)
        .gte('task_date', monthStart)
        .order('task_date', { ascending: true })
        .limit(1000);
      if (error) throw error;
      return (data || []).map((t: any) => ({
        id: t.id, clientName: t.clients?.company_name || '', taskDate: t.task_date,
        status: t.status, priority: t.priority || 'media', notes: t.notes,
        planningNotes: t.planning_notes, taskCategory: t.task_category,
        createdBySellerId: t.created_by_seller_id, assignedToSellerId: t.assigned_to_seller_id,
        completedAt: t.completed_at,
      }));
    },
    staleTime: 1000 * 60 * 2,
  });

  const activeSellers = sellers.filter(s => (!s.status || s.status === 'ATIVO') && s.id !== currentSeller?.id);
  const sellerMap = useMemo(() => {
    const m: Record<string, SellerRow> = {};
    sellers.forEach(s => { m[s.id] = s; });
    return m;
  }, [sellers]);

  const getSellerTasks = (sellerId: string) =>
    allTasks.filter(t => t.createdBySellerId === sellerId || t.assignedToSellerId === sellerId);
  const getOpenTasks = (sellerId: string) =>
    getSellerTasks(sellerId).filter(t => t.status !== 'concluida');
  const getOverdueTasks = (sellerId: string) =>
    getSellerTasks(sellerId).filter(t => t.status !== 'concluida' && isBefore(new Date(t.taskDate), today));
  const getCompletedInPeriod = (sellerId: string) =>
    getSellerTasks(sellerId).filter(t => t.status === 'concluida' && t.completedAt &&
      new Date(t.completedAt) >= start && new Date(t.completedAt) <= end);

  const teamOpen = allTasks.filter(t => t.status !== 'concluida').length;
  const teamOverdue = allTasks.filter(t => t.status !== 'concluida' && isBefore(new Date(t.taskDate), today)).length;
  const teamCompleted = allTasks.filter(t => t.status === 'concluida' && t.completedAt &&
    new Date(t.completedAt) >= start && new Date(t.completedAt) <= end).length;
  const collaboratorsWithOverdue = activeSellers.filter(s => getOverdueTasks(s.id).length > 0).length;

  const allOverdue = useMemo(() =>
    allTasks
      .filter(t => t.status !== 'concluida' && isBefore(new Date(t.taskDate), today))
      .sort((a, b) => new Date(a.taskDate).getTime() - new Date(b.taskDate).getTime()),
    [allTasks, today]
  );

  if (isLoading) return <div className="flex justify-center py-12"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>;

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
        <div>
          <span className="text-[11px] uppercase tracking-[0.08em] font-semibold text-muted-foreground">Equipe — Visão do Gestor</span>
          <p className="text-[13px] capitalize mt-1 text-muted-foreground">{format(new Date(), "EEEE, d 'de' MMMM", { locale: ptBR })}</p>
        </div>
        <div className="flex gap-1 p-0.5 rounded-md bg-muted border border-border">
          {([['hoje', 'Hoje'], ['semana', 'Esta Semana'], ['mes', 'Este Mês']] as const).map(([val, label]) => (
            <button key={val} onClick={() => setPeriod(val)}
              className={cn(
                "px-3 py-1.5 text-[11px] font-medium rounded transition-colors",
                period === val ? "bg-card text-foreground shadow-hh-sm" : "text-muted-foreground"
              )}>
              {label}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <MetricCard label="Tarefas Abertas" value={teamOpen} />
        <MetricCard label="Atrasadas" value={teamOverdue} color="danger" />
        <MetricCard label="Concluídas no Período" value={teamCompleted} color="success" />
        <MetricCard label="Colaboradores com Atraso" value={collaboratorsWithOverdue} color={collaboratorsWithOverdue > 0 ? 'danger' : 'neutral'} />
      </div>

      <div>
        <span className="text-[11px] uppercase tracking-[0.08em] font-semibold text-muted-foreground">Colaboradores</span>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mt-3">
          {activeSellers.map(s => {
            const open = getOpenTasks(s.id).length;
            const overdueList = getOverdueTasks(s.id);
            const completed = getCompletedInPeriod(s.id).length;
            const hasOverdue = overdueList.length > 0;
            const isExpanded = expandedCard === s.id;

            return (
              <div key={s.id}
                className={cn(
                  "rounded-xl p-4 cursor-pointer transition-all bg-card border shadow-hh-sm hover:shadow-hh-md",
                  hasOverdue ? "border-l-4 border-l-destructive border-t-border border-r-border border-b-border" : "border-l-4 border-l-status-success border-t-border border-r-border border-b-border"
                )}
                onClick={() => setExpandedCard(isExpanded ? null : s.id)}>
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-8 h-8 rounded-full flex items-center justify-center text-[12px] font-semibold bg-muted text-muted-foreground">
                    {s.name[0]}
                  </div>
                  <div>
                    <p className="text-[13px] font-medium text-foreground">{s.name}</p>
                    <span className="text-[10px] text-muted-foreground">{s.role}</span>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-2 text-center">
                  <div>
                    <p className="text-[18px] font-semibold text-foreground">{open}</p>
                    <p className="text-[10px] text-muted-foreground">Abertas</p>
                  </div>
                  <div>
                    <p className={cn("text-[18px] font-semibold", hasOverdue ? "text-destructive" : "text-foreground")}>{overdueList.length}</p>
                    <p className="text-[10px] text-muted-foreground">Atrasadas</p>
                  </div>
                  <div>
                    <p className="text-[18px] font-semibold text-status-success">{completed}</p>
                    <p className="text-[10px] text-muted-foreground">Concluídas</p>
                  </div>
                </div>
                {isExpanded && overdueList.length > 0 && (
                  <div className="mt-3 pt-3 space-y-1 border-t border-border">
                    <span className="text-[10px] uppercase tracking-[0.08em] font-semibold text-destructive">Tarefas atrasadas</span>
                    {overdueList.map(t => (
                      <div key={t.id} className="flex items-center justify-between p-2 rounded-lg border-destructive/20 bg-destructive/5 border">
                        <p className="text-[11px] truncate flex-1 text-foreground">{t.clientName || t.planningNotes || t.notes || 'Tarefa Geral'}</p>
                        <span className="hh-badge-danger text-[10px] ml-2">
                          {Math.abs(differenceInCalendarDays(new Date(t.taskDate), today))}d
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {allOverdue.length > 0 && (
        <div className="rounded-xl p-5 bg-card border border-border shadow-hh-sm">
          <span className="text-[11px] uppercase tracking-[0.08em] font-semibold text-muted-foreground">Tarefas Atrasadas da Equipe</span>
          <div className="space-y-1 mt-3">
            {allOverdue.slice(0, 20).map(t => {
              const owner = sellerMap[t.assignedToSellerId || t.createdBySellerId || ''];
              const daysOverdue = Math.abs(differenceInCalendarDays(new Date(t.taskDate), today));
              return (
                <div key={t.id} className="flex items-center gap-3 p-3 rounded-lg border-destructive/20 bg-destructive/5 border">
                  <div className="w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold shrink-0 bg-muted text-muted-foreground">
                    {(owner?.name || '?')[0]}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-[13px] font-medium truncate text-foreground">{t.clientName || t.planningNotes || t.notes || 'Tarefa Geral'}</p>
                    <p className="text-[11px] text-muted-foreground">{owner?.name || 'Desconhecido'}</p>
                  </div>
                  <span className="hh-badge-danger text-[10px] shrink-0">{daysOverdue}d atraso</span>
                  <Button size="sm" variant="ghost" className="text-[11px] shrink-0 text-primary"
                    onClick={(e) => {
                      e.stopPropagation();
                      setDelegatePrefill(t.assignedToSellerId || t.createdBySellerId || '');
                      setDrawerOpen(true);
                    }}>
                    Delegar
                  </Button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      <NovaOwnerTaskDrawer open={drawerOpen} onOpenChange={setDrawerOpen} sellers={sellers} prefillDelegateTo={delegatePrefill} />

      {/* Praise XP section */}
      <div className="rounded-xl p-5 bg-card border border-border shadow-hh-sm">
        <div className="flex items-center justify-between mb-3">
          <span className="text-[11px] uppercase tracking-[0.08em] font-semibold text-muted-foreground">Creditar Elogio de Cliente</span>
        </div>
        <p className="text-xs text-muted-foreground mb-3">Quando um vendedor comunicar um elogio de cliente, credite +150 XP ao colaborador.</p>
        <div className="flex flex-wrap gap-2">
          {activeSellers
            .sort((a, b) => (a.role === 'logistica' ? -1 : b.role === 'logistica' ? 1 : 0))
            .map(s => (
              <Button
                key={s.id}
                variant={praiseTarget === s.id ? 'default' : 'outline'}
                size="sm"
                className="gap-1.5"
                onClick={() => {
                  setPraiseTarget(praiseTarget === s.id ? null : s.id);
                  setPraiseNote('');
                }}
              >
                <Star className="h-3.5 w-3.5" />
                {s.name.split(' ')[0]}
              </Button>
            ))}
        </div>
        {praiseTarget && (
          <div className="mt-3 flex items-center gap-2">
            <Input
              placeholder="Motivo do elogio (opcional)"
              value={praiseNote}
              onChange={e => setPraiseNote(e.target.value)}
              className="flex-1 h-9 text-sm"
            />
            <Button
              size="sm"
              disabled={praiseLoading}
              onClick={async () => {
                setPraiseLoading(true);
                try {
                  const { error } = await supabase.rpc('grant_praise_xp', {
                    p_seller_id: praiseTarget,
                    p_note: praiseNote || 'Elogio de cliente',
                  });
                  if (error) throw error;
                  const name = sellers.find(s => s.id === praiseTarget)?.name || '';
                  toast.success(`+150 XP creditados para ${name.split(' ')[0]}! ⭐`);
                  setPraiseTarget(null);
                  setPraiseNote('');
                } catch (err) {
                  console.error(err);
                  toast.error('Erro ao creditar XP');
                } finally {
                  setPraiseLoading(false);
                }
              }}
            >
              {praiseLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Creditar +150 XP'}
            </Button>
          </div>
        )}
      </div>

      {/* Medal History Section */}
      <OwnerMedalHistory sellers={activeSellers} sellerMap={sellerMap} />
    </div>
  );
}

export function OwnerMeuDia({ renderVendasTab }: { renderVendasTab: () => React.ReactNode }) {
  const [activeTab, setActiveTab] = useState<OwnerTab>('vendas');
  const { sellers, loading: sellersLoading } = useSellersData();
  const { seller } = useAuth();
  const { tasks, loading: tasksLoading } = useTasksData(undefined, seller?.id);

  const today = startOfDay(new Date());
  const pendingTasks = tasks.filter(t => t.status !== 'concluida');
  const overdueTasks = pendingTasks.filter(t => isBefore(new Date(t.taskDate), today));

  const tabBadge = (tab: OwnerTab) => {
    if (tab === 'tarefas' && overdueTasks.length > 0) return overdueTasks.length;
    return 0;
  };

  const tabs: { key: OwnerTab; label: string }[] = [
    { key: 'vendas', label: 'Vendas' },
    { key: 'tarefas', label: 'Tarefas' },
    { key: 'equipe', label: 'Equipe' },
    { key: 'perfil', label: '👤 Perfil' },
    { key: 'evolucao', label: '📈 Evolução' },
  ];

  // Show skeleton tabs while initial data loads
  if (sellersLoading || tasksLoading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="flex items-center px-8 pt-6 border-b border-border" style={{ gap: '24px' }}>
          {tabs.map(tab => (
            <div key={tab.key} className="pb-3 -mb-px">
              <div className="h-5 w-16 bg-muted animate-pulse rounded" />
            </div>
          ))}
        </div>
        <div className="px-8 py-6 space-y-4">
          <div className="h-8 w-48 bg-muted animate-pulse rounded" />
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[1,2,3,4].map(i => <div key={i} className="h-[72px] bg-muted animate-pulse rounded-xl" />)}
          </div>
          <div className="h-40 bg-muted animate-pulse rounded-xl" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="flex items-center px-8 pt-6 border-b border-border" style={{ gap: '24px' }}>
        {tabs.map(tab => {
          const badge = tabBadge(tab.key);
          const isActive = activeTab === tab.key;
          return (
            <button key={tab.key} onClick={() => setActiveTab(tab.key)}
              className={cn(
                "pb-3 transition-all -mb-px text-[14px]",
                isActive ? "font-semibold text-foreground border-b-2 border-primary" : "font-medium text-muted-foreground border-b-2 border-transparent"
              )}>
              {tab.label}
              {badge > 0 && (
                <span className="ml-1.5 min-w-[18px] h-[18px] inline-flex items-center justify-center rounded-full text-[10px] font-bold px-1 bg-destructive text-white">
                  {badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      <div className="px-8 py-6">
        {activeTab === 'vendas' && renderVendasTab()}
        {activeTab === 'tarefas' && <TasksErrorBoundary><OwnerTarefasTab sellers={sellers} /></TasksErrorBoundary>}
        {activeTab === 'equipe' && <TasksErrorBoundary><OwnerEquipeTab sellers={sellers} /></TasksErrorBoundary>}
        
        {activeTab === 'perfil' && seller?.id && <ProfileHubContent sellerId={seller.id} isOwnProfile={true} canSeeDetails={true} />}
        {activeTab === 'evolucao' && <EvolutionEmbed />}
      </div>
    </div>
  );
}
