import { useState, useMemo, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useCarteiraRadar, RadarClient, RadarZone } from '@/hooks/useCarteiraRadar';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import {
  Loader2, RefreshCw, ExternalLink, MessageSquare, Plus,
  FileText, CheckCircle, AlertTriangle, ShoppingCart, Clock,
  TrendingUp, Activity, ChevronDown, ChevronUp, Radar,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { QuickFeedbackButtons } from '@/components/feedback/QuickFeedbackButtons';

type ZoneFilter = 'todos' | RadarZone;

const ZONE_CONFIG: Record<RadarZone, { label: string; color: string; bgRing: string; dotColor: string }> = {
  ativo: { label: 'Ativos', color: 'text-emerald-600 dark:text-emerald-400', bgRing: 'border-emerald-500/30', dotColor: 'bg-emerald-500' },
  recompra: { label: 'Recompra próxima', color: 'text-amber-600 dark:text-amber-400', bgRing: 'border-amber-500/30', dotColor: 'bg-amber-500' },
  atraso: { label: 'Atraso de compra', color: 'text-orange-600 dark:text-orange-400', bgRing: 'border-orange-500/30', dotColor: 'bg-orange-500' },
  risco: { label: 'Em risco', color: 'text-destructive', bgRing: 'border-destructive/30', dotColor: 'bg-destructive' },
};

const FILTERS: { key: ZoneFilter; label: string }[] = [
  { key: 'todos', label: 'Todos' },
  { key: 'risco', label: 'Em risco' },
  { key: 'atraso', label: 'Atraso' },
  { key: 'recompra', label: 'Recompra' },
  { key: 'ativo', label: 'Ativos' },
];

interface CarteiraRadarProps {
  isTeamView?: boolean;
}

export function CarteiraRadar({ isTeamView = false }: CarteiraRadarProps) {
  const navigate = useNavigate();
  const { clients, summary, sellerNames, isLoading, refetch } = useCarteiraRadar({ allSellers: isTeamView });
  const [filter, setFilter] = useState<ZoneFilter>('todos');
  const [sellerFilter, setSellerFilter] = useState<string | null>(null);
  const [selectedClient, setSelectedClient] = useState<RadarClient | null>(null);
  const [refreshing, setRefreshing] = useState(false);
  const [expanded, setExpanded] = useState(true);

  const filteredClients = useMemo(() => {
    let list = clients;
    if (filter !== 'todos') list = list.filter(c => c.zone === filter);
    if (sellerFilter) list = list.filter(c => c.seller_id === sellerFilter);
    return list;
  }, [clients, filter, sellerFilter]);

  const zoneGroups = useMemo(() => {
    const groups: Record<RadarZone, RadarClient[]> = { risco: [], atraso: [], recompra: [], ativo: [] };
    filteredClients.forEach(c => groups[c.zone].push(c));
    return groups;
  }, [filteredClients]);

  const handleRefresh = async () => {
    setRefreshing(true);
    await refetch();
    setRefreshing(false);
  };

  const sellerOptions = useMemo(() =>
    Object.entries(sellerNames).sort((a, b) => a[1].localeCompare(b[1])),
  [sellerNames]);

  if (isLoading) {
    return (
      <Card className="border-border/40">
        <CardContent className="p-6 flex items-center justify-center gap-2 text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin" />
          <span className="text-sm">Carregando radar...</span>
        </CardContent>
      </Card>
    );
  }

  if (clients.length === 0) return null;

  return (
    <div className="space-y-3">
      {/* Header */}
      <div className="flex items-center justify-between">
        <button onClick={() => setExpanded(!expanded)} className="flex items-center gap-2.5 group">
          <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
            <Radar className="h-4 w-4 text-primary" />
          </div>
          <div className="text-left">
            <h3 className="text-sm font-semibold text-foreground tracking-tight flex items-center gap-1.5">
              Radar da Carteira
              {summary.risco > 0 && (
                <span className="text-[10px] font-bold bg-destructive/10 text-destructive px-1.5 py-0.5 rounded-full">
                  {summary.risco} em risco
                </span>
              )}
              {expanded ? <ChevronUp className="h-3.5 w-3.5 text-muted-foreground" /> : <ChevronDown className="h-3.5 w-3.5 text-muted-foreground" />}
            </h3>
            <p className="text-[11px] text-muted-foreground">{summary.total} clientes analisados</p>
          </div>
        </button>
        <div className="flex items-center gap-2">
          {isTeamView && sellerOptions.length > 0 && (
            <select
              value={sellerFilter || ''}
              onChange={e => setSellerFilter(e.target.value || null)}
              className="h-7 px-2 rounded-lg border border-border/50 bg-background text-[11px] text-foreground"
            >
              <option value="">Todos vendedores</option>
              {sellerOptions.map(([id, name]) => (
                <option key={id} value={id}>{name}</option>
              ))}
            </select>
          )}
          <Button variant="ghost" size="sm" onClick={handleRefresh} disabled={refreshing} className="h-7 text-[11px] gap-1.5 text-muted-foreground">
            <RefreshCw className={cn("h-3 w-3", refreshing && "animate-spin")} />
          </Button>
        </div>
      </div>

      {expanded && (
        <>
          {/* Summary KPIs */}
          <div className="grid grid-cols-4 gap-2">
            <ZoneSummaryCard zone="ativo" count={summary.ativos} total={summary.total} onClick={() => setFilter('ativo')} active={filter === 'ativo'} />
            <ZoneSummaryCard zone="recompra" count={summary.recompra} total={summary.total} onClick={() => setFilter('recompra')} active={filter === 'recompra'} />
            <ZoneSummaryCard zone="atraso" count={summary.atraso} total={summary.total} onClick={() => setFilter('atraso')} active={filter === 'atraso'} />
            <ZoneSummaryCard zone="risco" count={summary.risco} total={summary.total} onClick={() => setFilter('risco')} active={filter === 'risco'} />
          </div>

          {/* Visual Radar */}
          <RadarVisualization groups={zoneGroups} onSelect={setSelectedClient} />

          {/* Filters */}
          <div className="flex gap-1 overflow-x-auto pb-1 scrollbar-hide">
            {FILTERS.map(f => (
              <button
                key={f.key}
                onClick={() => setFilter(f.key)}
                className={cn(
                  "px-2.5 py-1 rounded-full text-[11px] font-medium whitespace-nowrap transition-colors",
                  filter === f.key ? "bg-primary text-primary-foreground" : "bg-muted/60 text-muted-foreground hover:bg-muted"
                )}
              >
                {f.label} {f.key !== 'todos' && `(${f.key === 'ativo' ? summary.ativos : f.key === 'recompra' ? summary.recompra : f.key === 'atraso' ? summary.atraso : summary.risco})`}
              </button>
            ))}
          </div>

          {/* Client List */}
          <div className="space-y-1">
            {filteredClients.slice(0, 20).map(client => (
              <ClientRow key={client.client_id} client={client} showSeller={isTeamView} onClick={() => setSelectedClient(client)} />
            ))}
            {filteredClients.length > 20 && (
              <p className="text-center text-[11px] text-muted-foreground py-2">
                +{filteredClients.length - 20} clientes
              </p>
            )}
            {filteredClients.length === 0 && (
              <p className="text-center text-[12px] text-muted-foreground py-4">Nenhum cliente neste filtro.</p>
            )}
          </div>
        </>
      )}

      {/* Detail Sheet */}
      <Sheet open={!!selectedClient} onOpenChange={(open) => !open && setSelectedClient(null)}>
        <SheetContent className="w-full sm:max-w-md">
          {selectedClient && (
            <ClientDetailPanel client={selectedClient} onOpenClient={() => navigate(`/clients/${selectedClient.client_id}`)} />
          )}
        </SheetContent>
      </Sheet>
    </div>
  );
}

/* ── Radar Visualization ── */
function RadarVisualization({ groups, onSelect }: { groups: Record<RadarZone, RadarClient[]>; onSelect: (c: RadarClient) => void }) {
  const zones: RadarZone[] = ['ativo', 'recompra', 'atraso', 'risco'];

  // Position dots in concentric rings using seeded angles
  const positionDots = useCallback((zoneClients: RadarClient[], ringIndex: number, totalRings: number) => {
    const ringRadius = ((ringIndex + 1) / totalRings) * 45; // percentage of container
    return zoneClients.slice(0, 24).map((c, i) => {
      const angle = (i / Math.max(zoneClients.length, 1)) * 2 * Math.PI + (ringIndex * 0.3);
      const jitter = (((c.prioridade_score * 7) % 10) - 5) * 0.6;
      const r = ringRadius + jitter;
      const x = 50 + r * Math.cos(angle);
      const y = 50 + r * Math.sin(angle);
      return { client: c, x: Math.max(4, Math.min(96, x)), y: Math.max(4, Math.min(96, y)) };
    });
  }, []);

  const allDots = useMemo(() =>
    zones.flatMap((zone, i) => positionDots(groups[zone], i, zones.length)),
  [groups, positionDots]);

  return (
    <div className="relative aspect-square max-w-[320px] mx-auto">
      {/* Concentric rings */}
      {[4, 3, 2, 1].map((ring) => {
        const zone = zones[ring - 1];
        const cfg = ZONE_CONFIG[zone];
        const size = `${(ring / 4) * 100}%`;
        return (
          <div
            key={ring}
            className={cn("absolute rounded-full border-2 transition-all", cfg.bgRing)}
            style={{
              width: size,
              height: size,
              top: `${50 - (ring / 4) * 50}%`,
              left: `${50 - (ring / 4) * 50}%`,
              backgroundColor: ring === 4 ? 'hsl(var(--destructive) / 0.03)' : ring === 3 ? 'hsl(var(--primary) / 0.02)' : 'transparent',
            }}
          />
        );
      })}

      {/* Zone labels */}
      <span className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-[8px] font-semibold text-emerald-600/60 dark:text-emerald-400/60 pointer-events-none">ATIVO</span>
      <span className="absolute top-[28%] left-1/2 -translate-x-1/2 text-[7px] font-medium text-amber-600/50 dark:text-amber-400/50 pointer-events-none">RECOMPRA</span>
      <span className="absolute top-[14%] left-1/2 -translate-x-1/2 text-[7px] font-medium text-orange-600/50 dark:text-orange-400/50 pointer-events-none">ATRASO</span>
      <span className="absolute top-[3%] left-1/2 -translate-x-1/2 text-[7px] font-medium text-destructive/50 pointer-events-none">RISCO</span>

      {/* Client dots */}
      {allDots.map(({ client, x, y }) => {
        const cfg = ZONE_CONFIG[client.zone];
        return (
          <button
            key={client.client_id}
            onClick={() => onSelect(client)}
            className={cn(
              "absolute w-2.5 h-2.5 rounded-full transition-transform hover:scale-[2] hover:z-10 cursor-pointer",
              cfg.dotColor,
              client.ranking_tier?.includes('top') && "ring-1 ring-foreground/20 w-3 h-3"
            )}
            style={{ left: `${x}%`, top: `${y}%`, transform: 'translate(-50%, -50%)' }}
            title={`${client.client_name} — ${cfg.label}`}
          />
        );
      })}
    </div>
  );
}

/* ── Zone Summary Card ── */
function ZoneSummaryCard({ zone, count, total, onClick, active }: {
  zone: RadarZone; count: number; total: number; onClick: () => void; active: boolean;
}) {
  const cfg = ZONE_CONFIG[zone];
  const pct = total > 0 ? Math.round((count / total) * 100) : 0;
  return (
    <button
      onClick={onClick}
      className={cn(
        "p-2.5 rounded-xl border transition-all text-left",
        active ? "border-primary bg-primary/5 ring-1 ring-primary/20" : "border-border/40 hover:border-border/70"
      )}
    >
      <div className="flex items-center gap-1.5 mb-1">
        <span className={cn("w-2 h-2 rounded-full", cfg.dotColor)} />
        <span className="text-[10px] font-medium text-muted-foreground">{cfg.label}</span>
      </div>
      <p className={cn("text-lg font-bold tabular-nums", cfg.color)}>{count}</p>
      <p className="text-[9px] text-muted-foreground">{pct}% da carteira</p>
    </button>
  );
}

/* ── Client Row ── */
function ClientRow({ client, showSeller, onClick }: { client: RadarClient; showSeller: boolean; onClick: () => void }) {
  const cfg = ZONE_CONFIG[client.zone];
  return (
    <div
      onClick={onClick}
      className={cn(
        "flex items-center gap-2.5 p-2 rounded-lg border border-border/30 hover:border-border/60 cursor-pointer transition-colors group",
        client.zone === 'risco' && "border-l-2 border-l-destructive",
        client.zone === 'atraso' && "border-l-2 border-l-orange-500",
      )}
    >
      <span className={cn("w-1.5 h-1.5 rounded-full flex-shrink-0", cfg.dotColor)} />
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-1.5">
          <p className="text-[12px] font-semibold text-foreground truncate">{client.client_name}</p>
          {showSeller && client.seller_name && (
            <span className="text-[9px] text-muted-foreground bg-muted px-1.5 py-0.5 rounded-full flex-shrink-0">{client.seller_name}</span>
          )}
        </div>
        <p className="text-[10px] text-muted-foreground truncate">{client.motivo_prioridade}</p>
      </div>
      <div className="flex items-center gap-2 flex-shrink-0">
        {client.dias_sem_pedido != null && (
          <span className={cn("text-[10px] font-medium tabular-nums",
            client.dias_sem_pedido > 90 ? "text-destructive" : client.dias_sem_pedido > 60 ? "text-amber-600 dark:text-amber-400" : "text-muted-foreground"
          )}>
            {client.dias_sem_pedido}d
          </span>
        )}
        <span className={cn("text-[8px] font-bold uppercase tracking-widest px-1.5 py-0.5 rounded-full", cfg.color, `${cfg.dotColor}/10`)}>
          {cfg.label.split(' ')[0]}
        </span>
      </div>
    </div>
  );
}

/* ── Client Detail Panel ── */
function ClientDetailPanel({ client, onOpenClient }: { client: RadarClient; onOpenClient: () => void }) {
  const cfg = ZONE_CONFIG[client.zone];
  const navigate = useNavigate();

  return (
    <>
      <SheetHeader>
        <SheetTitle className="flex items-center gap-2 text-base">
          <span className={cn("w-2.5 h-2.5 rounded-full", cfg.dotColor)} />
          {client.client_name}
        </SheetTitle>
      </SheetHeader>

      <div className="mt-6 space-y-5">
        {/* Status */}
        <div className="flex items-center gap-2">
          <span className={cn("text-xs font-bold uppercase tracking-widest px-2.5 py-1 rounded-full", cfg.color, `${cfg.dotColor}/10`)}>
            {cfg.label}
          </span>
          {client.ranking_tier && (
            <span className="text-[10px] text-muted-foreground bg-muted px-2 py-0.5 rounded-full uppercase">{client.ranking_tier}</span>
          )}
        </div>

        {/* Key info */}
        <div className="grid grid-cols-2 gap-3">
          <InfoBlock label="Dias sem pedido" value={client.dias_sem_pedido != null ? `${client.dias_sem_pedido} dias` : '—'} />
          <InfoBlock label="Score" value={`${client.prioridade_score}/100`} />
          <InfoBlock label="Faturamento" value={`R$ ${(client.faturamento_total || 0).toLocaleString('pt-BR', { maximumFractionDigits: 0 })}`} />
          <InfoBlock label="Prioridade" value={client.prioridade_nivel.charAt(0).toUpperCase() + client.prioridade_nivel.slice(1)} />
        </div>

        {/* Motivo */}
        <div className="space-y-1">
          <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider">Motivo</p>
          <p className="text-sm text-foreground">{client.motivo_prioridade}</p>
        </div>

        {/* Melhor ação */}
        <div className="space-y-1">
          <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider">Melhor próxima ação</p>
          <div className="flex items-center gap-2 text-sm text-primary font-medium">
            <TrendingUp className="h-4 w-4" />
            {client.melhor_proxima_acao}
          </div>
        </div>

        {/* Badges */}
        <div className="flex flex-wrap gap-1.5">
          {client.cliente_em_risco && (
            <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-destructive bg-destructive/10 px-2 py-1 rounded-full">
              <AlertTriangle className="h-3 w-3" /> Em risco
            </span>
          )}
          {client.oportunidade_recompra && (
            <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-primary bg-primary/10 px-2 py-1 rounded-full">
              <ShoppingCart className="h-3 w-3" /> Recompra
            </span>
          )}
          {client.has_pending_task && (
            <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-muted-foreground bg-muted px-2 py-1 rounded-full">
              <Clock className="h-3 w-3" /> Tarefa ativa
            </span>
          )}
          {client.contacted_today && (
            <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-primary bg-primary/10 px-2 py-1 rounded-full">
              <MessageSquare className="h-3 w-3" /> Contatado hoje
            </span>
          )}
        </div>

        {/* Actions */}
        <div className="grid grid-cols-2 gap-2 pt-2 border-t border-border/40">
          <Button variant="default" size="sm" onClick={onOpenClient} className="gap-1.5 text-xs">
            <ExternalLink className="h-3.5 w-3.5" /> Abrir cliente
          </Button>
          <Button variant="outline" size="sm" onClick={() => navigate(`/clients/${client.client_id}?tab=ai`)} className="gap-1.5 text-xs">
            <MessageSquare className="h-3.5 w-3.5" /> Perguntar à IA
          </Button>
          <Button variant="outline" size="sm" onClick={() => navigate(`/clients/${client.client_id}?tab=tasks`)} className="gap-1.5 text-xs">
            <Plus className="h-3.5 w-3.5" /> Criar tarefa
          </Button>
          <Button variant="outline" size="sm" onClick={() => navigate(`/clients/${client.client_id}?tab=checklist`)} className="gap-1.5 text-xs">
            <CheckCircle className="h-3.5 w-3.5" /> Checklist
          </Button>
        </div>

        {/* Feedback */}
        <div className="space-y-1.5 pt-2 border-t border-border/40">
          <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider">Resultado da ação</p>
          <QuickFeedbackButtons clientId={client.client_id} origem="fila_inteligente" />
        </div>
      </div>
    </>
  );
}

function InfoBlock({ label, value }: { label: string; value: string }) {
  return (
    <div className="p-2.5 rounded-lg bg-muted/40">
      <p className="text-[9px] text-muted-foreground uppercase tracking-wider">{label}</p>
      <p className="text-sm font-semibold text-foreground mt-0.5">{value}</p>
    </div>
  );
}
