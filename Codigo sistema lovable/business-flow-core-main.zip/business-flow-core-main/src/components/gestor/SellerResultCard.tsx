import { motion } from 'framer-motion';
import { Check, AlertTriangle, TrendingUp, TrendingDown, Minus, Settings2 } from 'lucide-react';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';

interface SellerResultCardProps {
  seller: {
    id: string;
    name: string;
    revenue: number;
    profit: number;
    marginBruta: number;
    comissaoReal: number;
    comissaoPercentual: number;
    cdv: number;
    custoHumano: number; // Custo fixo do CPF
    ceeRateio: number;
    resultadoDireto: number;
    resultadoReal: number;
    metaMinima: number; // Break-even estimado
    faturamentoParaSePagar?: number;
    margemMinimaRequerida?: number;
  };
  rank: number;
  isSelected: boolean;
  onSelect: () => void;
  onEditCost: () => void;
}

function formatCurrency(value: number): string {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value);
}

export function SellerResultCard({ seller, rank, isSelected, onSelect, onEditCost }: SellerResultCardProps) {
  // =================================================================
  // STATUS CORRIGIDO CONFORME ARQUITETURA FINANCEIRA
  // =================================================================
  // Status Operacional: vendaFazSentido = Resultado Direto > 0
  // Status "Se paga": Resultado Direto >= Custo Humano
  // Status Financeiro: Resultado Real > 0 = gera lucro
  // =================================================================
  
  const vendaFazSentido = seller.resultadoDireto > 0;
  const sePaga = seller.resultadoDireto >= seller.custoHumano; // Corrigido: compara com custo humano
  const sustentaEmpresa = seller.resultadoReal > 0;
  const empata = seller.resultadoReal >= -500 && seller.resultadoReal <= 500;
  
  // Status visual hierárquico
  let statusColor = 'bg-red-500';
  let statusText = 'Não se paga';
  let StatusIcon = AlertTriangle;
  
  if (!vendaFazSentido) {
    // Venda não faz sentido - CDV > Margem
    statusColor = 'bg-red-700';
    statusText = 'Venda inviável';
    StatusIcon = AlertTriangle;
  } else if (sustentaEmpresa) {
    // Gera lucro real
    statusColor = 'bg-green-500';
    statusText = 'Gera Lucro Real';
    StatusIcon = Check;
  } else if (sePaga && empata) {
    // Se paga mas empata estrutura
    statusColor = 'bg-yellow-500';
    statusText = 'Empata Estrutura';
    StatusIcon = Minus;
  } else if (sePaga && !sustentaEmpresa) {
    // Se paga mas consome estrutura
    statusColor = 'bg-orange-500';
    statusText = 'Consome Estrutura';
    StatusIcon = TrendingDown;
  }
  // else: Não se paga (default)

  // Margem mínima requerida = Custo Humano + CEE Rateio
  const margemMinimaRequerida = seller.margemMinimaRequerida || (seller.custoHumano + seller.ceeRateio);
  
  // Progress para break-even (margem gerada vs margem mínima)
  const progressToBreakeven = margemMinimaRequerida > 0 
    ? Math.min(100, ((seller.marginBruta - seller.cdv) / margemMinimaRequerida) * 100)
    : 100;

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -2, boxShadow: '0 8px 30px rgba(0,0,0,0.12)' }}
      transition={{ duration: 0.2 }}
    >
      <Card 
        className={`cursor-pointer transition-all ${
          isSelected 
            ? 'ring-2 ring-primary shadow-lg' 
            : 'hover:shadow-md'
        }`}
        onClick={onSelect}
      >
        <CardHeader className="pb-2 pt-4 px-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white font-bold text-sm ${
                rank === 1 ? 'bg-amber-500' : rank === 2 ? 'bg-gray-400' : rank === 3 ? 'bg-amber-700' : 'bg-muted-foreground/30'
              }`}>
                {rank}
              </div>
              <div>
                <h3 className="font-semibold text-sm">{seller.name}</h3>
                <div className="flex items-center gap-1 mt-0.5">
                  <div className={`w-2 h-2 rounded-full ${statusColor}`} />
                  <span className="text-xs text-muted-foreground">{statusText}</span>
                </div>
              </div>
            </div>
            <Button 
              variant="ghost" 
              size="icon" 
              className="h-8 w-8"
              onClick={(e) => { e.stopPropagation(); onEditCost(); }}
            >
              <Settings2 className="h-4 w-4" />
            </Button>
          </div>
        </CardHeader>

        <CardContent className="px-4 pb-4 space-y-3">
          {/* Margem Bruta Gerada */}
          <div className="flex justify-between items-center">
            <span className="text-xs text-muted-foreground">Margem Bruta</span>
            <span className="font-semibold text-sm">{formatCurrency(seller.marginBruta)}</span>
          </div>

          {/* CDV (Custo Direto Variável = Comissão) */}
          <div className="flex justify-between items-center">
            <span className="text-xs text-muted-foreground">
              CDV (Comissão {seller.comissaoPercentual.toFixed(1)}%)
            </span>
            <span className="text-sm text-amber-600">-{formatCurrency(seller.cdv)}</span>
          </div>

          {/* Resultado Direto = Margem - CDV */}
          <div className={`flex justify-between items-center p-2 rounded-lg ${vendaFazSentido ? 'bg-green-50' : 'bg-red-50'}`}>
            <span className="text-xs font-medium">Resultado Direto</span>
            <span className={`font-bold ${vendaFazSentido ? 'text-green-600' : 'text-red-600'}`}>
              {formatCurrency(seller.resultadoDireto)}
            </span>
          </div>

          {/* Custo Humano (Fixo) */}
          <div className="flex justify-between items-center">
            <span className="text-xs text-muted-foreground">Custo Humano (Fixo)</span>
            <span className="text-sm text-purple-600">-{formatCurrency(seller.custoHumano)}</span>
          </div>

          {/* CEE Rateio */}
          <div className="flex justify-between items-center">
            <span className="text-xs text-muted-foreground">Rateio Estrutural (CEE)</span>
            <span className="text-sm text-blue-600">-{formatCurrency(seller.ceeRateio)}</span>
          </div>

          {/* Resultado Real */}
          <div className={`flex justify-between items-center p-2 rounded-lg ${
            sustentaEmpresa ? 'bg-green-100' : empata ? 'bg-yellow-50' : 'bg-red-100'
          }`}>
            <div className="flex items-center gap-1">
              <StatusIcon className={`h-4 w-4 ${
                sustentaEmpresa ? 'text-green-600' : empata ? 'text-yellow-600' : 'text-red-600'
              }`} />
              <span className="text-xs font-medium">Resultado Real</span>
            </div>
            <span className={`font-bold ${
              sustentaEmpresa ? 'text-green-700' : empata ? 'text-yellow-700' : 'text-red-700'
            }`}>
              {formatCurrency(seller.resultadoReal)}
            </span>
          </div>

          {/* Break-even: Faturamento estimado para se pagar */}
          {!sustentaEmpresa && (
            <div className="pt-2 space-y-1 border-t border-dashed">
              <div className="flex justify-between text-xs">
                <span className="text-muted-foreground">Faturamento estimado para se pagar</span>
                <span className="font-medium">{formatCurrency(seller.faturamentoParaSePagar || seller.metaMinima)}</span>
              </div>
              <p className="text-[10px] text-muted-foreground italic">
                Estimativa baseada na margem média do período
              </p>
              <div className="grid grid-cols-2 gap-2 mt-2 text-xs">
                <div className="bg-purple-50 rounded p-1.5">
                  <span className="text-muted-foreground">Margem mín. requerida</span>
                  <p className="font-medium text-purple-700">{formatCurrency(margemMinimaRequerida)}</p>
                </div>
                <div className={`rounded p-1.5 ${seller.resultadoDireto >= margemMinimaRequerida ? 'bg-green-50' : 'bg-red-50'}`}>
                  <span className="text-muted-foreground">Margem gerada</span>
                  <p className={`font-medium ${seller.resultadoDireto >= margemMinimaRequerida ? 'text-green-700' : 'text-red-700'}`}>
                    {formatCurrency(seller.resultadoDireto)}
                  </p>
                </div>
              </div>
              <Progress value={Math.max(0, progressToBreakeven)} className="h-1.5 mt-2" />
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
}
