import { useState, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Loader2, 
  Send, 
  Calendar, 
  CalendarDays,
  Copy,
  Check,
  Sparkles,
  MessageSquare
} from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import type { SellerResult } from '@/hooks/useGestorData';
import type { Layer5Analysis } from './Layer5StrategicAnalysis';
import ReactMarkdown from 'react-markdown';

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  period?: string;
}

interface SellerAnalysisChatProps {
  seller: SellerResult;
  layer5Analysis?: Layer5Analysis;
}

function buildSellerDataJson(seller: SellerResult, layer5Analysis?: Layer5Analysis) {
  // Usar meta REAL de seller_levels, não metaMinima (break-even)
  const metaMensal = seller.monthlySalesTarget || layer5Analysis?.metaMensal || 30000;
  const eficienciaMeta = metaMensal > 0 ? (seller.revenue / metaMensal) * 100 : 0;
  
  return {
    periodo: "MÊS",
    vendedor: {
      id: seller.id,
      nome: seller.name,
      // NOVO: nível do vendedor (ovo, pena, aguia) da Evolução
      nivel: seller.level || 'ovo',
      status_financeiro: seller.statusFinanceiro,
      status_label: seller.statusLabel,
    },
    metricas: {
      faturamento: seller.revenue,
      margem_bruta: seller.marginBruta,
      margem_percent: seller.marginPercent,
      resultado_direto: seller.resultadoDireto,
      resultado_real: seller.resultadoReal,
      pedidos: seller.ordersCount,
      ticket_medio: seller.avgTicket,
      // CORRIGIDO: contatos agora usam mesma lógica da Evolução
      contatos_total: seller.contacts,
      ligacoes: seller.calls,
      whatsapp: seller.whatsapp,
      taxa_conversao: seller.conversionRate,
    },
    custos: {
      cdv_comissao: seller.cdv,
      custo_humano: seller.custoHumano,
      cee_rateio: seller.ceeRateio,
    },
    status: {
      se_paga: seller.sePaga,
      sustenta_empresa: seller.sustentaEmpresa,
      gera_lucro: seller.geraLucro,
      venda_faz_sentido: seller.vendaFazSentido,
    },
    metas: {
      // CORRIGIDO: usar meta real de seller_levels
      meta_mensal_vendas: metaMensal,
      meta_diaria_ligacoes: seller.dailyCallsTarget || 18,
      meta_diaria_whatsapp: seller.dailyWhatsappTarget || 15,
      eficiencia_meta: eficienciaMeta,
      faturamento_para_se_pagar: seller.faturamentoParaSePagar,
    },
    decisao_gerencial: layer5Analysis?.decisaoGerencial || 'analisar',
    decisao_gerencial_descricao: layer5Analysis?.decisaoGerencialDescricao || '',
  };
}

export function SellerAnalysisChat({ seller, layer5Analysis }: SellerAnalysisChatProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const generateAnalysis = useCallback(async (period: 'day' | 'month') => {
    setLoading(true);
    
    const dataJson = buildSellerDataJson(seller, layer5Analysis);
    
    try {
      const { data, error } = await supabase.functions.invoke('perplexity-assistant', {
        body: {
          mode: 'manager_seller_analysis',
          period: period === 'day' ? 'day' : 'month_current',
          sellerId: seller.id,
          dataJson,
        }
      });

      if (error) throw error;

      const newMessage: ChatMessage = {
        id: crypto.randomUUID(),
        role: 'assistant',
        content: data.answer || 'Sem resposta.',
        timestamp: new Date(),
        period: period === 'day' ? 'HOJE' : 'MÊS',
      };

      setMessages(prev => [...prev, newMessage]);
    } catch (err) {
      console.error('Error generating analysis:', err);
      toast.error('Erro ao gerar análise');
    } finally {
      setLoading(false);
    }
  }, [seller, layer5Analysis]);

  const sendQuestion = useCallback(async () => {
    if (!input.trim() || loading) return;

    const userMessage: ChatMessage = {
      id: crypto.randomUUID(),
      role: 'user',
      content: input.trim(),
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setLoading(true);

    const dataJson = buildSellerDataJson(seller, layer5Analysis);

    try {
      const { data, error } = await supabase.functions.invoke('perplexity-assistant', {
        body: {
          mode: 'manager_seller_analysis',
          period: 'month_current',
          sellerId: seller.id,
          dataJson,
          userQuestion: input.trim(),
        }
      });

      if (error) throw error;

      const assistantMessage: ChatMessage = {
        id: crypto.randomUUID(),
        role: 'assistant',
        content: data.answer || 'Sem resposta.',
        timestamp: new Date(),
      };

      setMessages(prev => [...prev, assistantMessage]);
    } catch (err) {
      console.error('Error sending question:', err);
      toast.error('Erro ao enviar pergunta');
    } finally {
      setLoading(false);
    }
  }, [input, loading, seller, layer5Analysis]);

  const copyToClipboard = useCallback((id: string, content: string) => {
    navigator.clipboard.writeText(content);
    setCopiedId(id);
    toast.success('Copiado!');
    setTimeout(() => setCopiedId(null), 2000);
  }, []);

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="p-4 border-b bg-background">
        <div className="flex items-center gap-2 mb-3">
          <Sparkles className="h-4 w-4 text-primary" />
          <span className="font-medium text-sm">Análise IA</span>
        </div>
        
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => generateAnalysis('day')}
            disabled={loading}
            className="flex-1"
          >
            <Calendar className="h-4 w-4 mr-2" />
            Análise do Dia
          </Button>
          <Button
            variant="default"
            size="sm"
            onClick={() => generateAnalysis('month')}
            disabled={loading}
            className="flex-1"
          >
            <CalendarDays className="h-4 w-4 mr-2" />
            Análise do Mês
          </Button>
        </div>
      </div>

      {/* Messages */}
      <ScrollArea className="flex-1 p-4">
        {messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center py-12">
            <MessageSquare className="h-12 w-12 text-muted-foreground/30 mb-4" />
            <p className="text-sm text-muted-foreground">
              Clique em "Análise do Dia" ou "Análise do Mês" para gerar um diagnóstico deste vendedor.
            </p>
            <p className="text-xs text-muted-foreground mt-2">
              Você também pode fazer perguntas específicas no campo abaixo.
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {messages.map((msg) => (
              <Card 
                key={msg.id}
                className={cn(
                  'relative',
                  msg.role === 'user' && 'bg-primary/5 border-primary/20'
                )}
              >
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      {msg.role === 'assistant' && (
                        <Sparkles className="h-3 w-3 text-primary" />
                      )}
                      <span className="text-xs text-muted-foreground">
                        {msg.role === 'assistant' ? 'IA H&H' : 'Você'}
                      </span>
                      {msg.period && (
                        <Badge variant="outline" className="text-[10px] py-0">
                          {msg.period}
                        </Badge>
                      )}
                    </div>
                    {msg.role === 'assistant' && (
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-6 w-6"
                        onClick={() => copyToClipboard(msg.id, msg.content)}
                      >
                        {copiedId === msg.id ? (
                          <Check className="h-3 w-3 text-emerald-500" />
                        ) : (
                          <Copy className="h-3 w-3" />
                        )}
                      </Button>
                    )}
                  </div>
                  <div className="prose prose-sm max-w-none dark:prose-invert">
                    <ReactMarkdown>{msg.content}</ReactMarkdown>
                  </div>
                </CardContent>
              </Card>
            ))}
            
            {loading && (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="h-6 w-6 animate-spin text-primary" />
              </div>
            )}
          </div>
        )}
      </ScrollArea>

      {/* Input */}
      <div className="p-4 border-t bg-background">
        <div className="flex gap-2">
          <Textarea
            placeholder="Faça uma pergunta sobre este vendedor..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                sendQuestion();
              }
            }}
            className="min-h-[60px] resize-none"
            disabled={loading}
          />
          <Button
            size="icon"
            onClick={sendQuestion}
            disabled={!input.trim() || loading}
            className="shrink-0 h-[60px] w-[60px]"
          >
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
