import { useState, useEffect, useMemo } from 'react';
import { motion } from 'framer-motion';
import { Chrome, TrendingUp, Users, DollarSign, Target, ArrowRight, Info, Pencil, Check, X, Loader2, ChevronDown } from 'lucide-react';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Table, TableBody, TableCell, TableFooter, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

interface GoogleAdsROIPanelProps {
  startDate: Date;
  endDate: Date;
  investimento: number;
  companyCostId?: string;
  onInvestimentoChange?: (newValue: number) => void;
}

interface GoogleClientData {
  id: string;
  companyName: string;
  totalRevenue: number;
  totalProfit: number;
  orderCount: number;
  firstOrderDate: string | null;
}

function formatCurrency(value: number): string {
  return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
}

export function GoogleAdsROIPanel({ startDate, endDate, investimento, companyCostId, onInvestimentoChange }: GoogleAdsROIPanelProps) {
  console.log('[GoogleAdsROIPanel] companyCostId:', companyCostId, 'investimento:', investimento);
  const [loading, setLoading] = useState(true);
  const [clientsData, setClientsData] = useState<GoogleClientData[]>([]);
  
  // Estados para edição inline
  const [editMode, setEditMode] = useState(false);
  const [investimentoLocal, setInvestimentoLocal] = useState(investimento);
  const [saving, setSaving] = useState(false);
  const [showClientsList, setShowClientsList] = useState(false);

  // Sincronizar estado local quando prop mudar
  useEffect(() => {
    setInvestimentoLocal(investimento);
  }, [investimento]);

  async function handleSaveInvestimento() {
    if (!companyCostId) {
      toast.error('Erro: configuração de custos não encontrada');
      return;
    }
    
    setSaving(true);
    try {
      const { error } = await (supabase as any)
        .from('company_costs')
        .update({ google_ads_estrutural: investimentoLocal })
        .eq('id', companyCostId);
      
      if (error) throw error;
      
      toast.success('Investimento atualizado!');
      onInvestimentoChange?.(investimentoLocal);
      setEditMode(false);
    } catch (err) {
      console.error('Erro ao salvar investimento:', err);
      toast.error('Erro ao salvar investimento');
    } finally {
      setSaving(false);
    }
  }

  function handleCancelEdit() {
    setInvestimentoLocal(investimento);
    setEditMode(false);
  }

  const periodLabel = useMemo(() => {
    return format(startDate, 'MMMM yyyy', { locale: ptBR });
  }, [startDate]);

  useEffect(() => {
    fetchGoogleClientsWithMargin();
  }, [startDate, endDate]);

  async function fetchGoogleClientsWithMargin() {
    setLoading(true);
    try {
      const startStr = format(startDate, 'yyyy-MM-dd');
      const endStr = format(endDate, 'yyyy-MM-dd');

      // Buscar clientes Google
      const { data: clientsRaw, error: clientsError } = await (supabase as any)
        .from('clients')
        .select('id, company_name, first_order_date')
        .eq('is_from_google', true)
        .eq('is_deleted', false);

      if (clientsError) throw clientsError;

      const clients = clientsRaw || [];
      if (clients.length === 0) {
        setClientsData([]);
        setLoading(false);
        return;
      }

      const clientIds = clients.map((c: any) => c.id);

      // Buscar pedidos desses clientes no período
      const { data: ordersRaw, error: ordersError } = await (supabase as any)
        .from('orders')
        .select('id, client_id, total, lucro_bruto_real')
        .in('client_id', clientIds)
        .gte('order_date', startStr)
        .lte('order_date', endStr)
        .eq('is_deleted', false);

      if (ordersError) throw ordersError;
      const orders = ordersRaw || [];

      // Usar lucro_bruto_real do banco (já com CMV Real = custo + 15%)
      const orderProfitMap = new Map<string, { revenue: number; profit: number }>();
      orders.forEach((o: any) => {
        orderProfitMap.set(o.id, { 
          revenue: o.total || 0, 
          profit: o.lucro_bruto_real || 0 
        });
      });

      // Agregar por cliente
      const clientMap = new Map<string, GoogleClientData>();
      clients.forEach((c: any) => {
        clientMap.set(c.id, {
          id: c.id,
          companyName: c.company_name || 'Cliente sem nome',
          totalRevenue: 0,
          totalProfit: 0,
          orderCount: 0,
          firstOrderDate: c.first_order_date
        });
      });

      orders.forEach((o: any) => {
        const client = clientMap.get(o.client_id);
        const orderData = orderProfitMap.get(o.id);
        if (client && orderData) {
          client.totalRevenue += orderData.revenue;
          client.totalProfit += orderData.profit;
          client.orderCount += 1;
        }
      });

      // Filtrar apenas clientes que tiveram pedidos no período
      const activeClients = Array.from(clientMap.values()).filter(c => c.orderCount > 0);
      setClientsData(activeClients);
    } catch (err) {
      console.error('Error fetching Google clients ROI data:', err);
    } finally {
      setLoading(false);
    }
  }

  const stats = useMemo(() => {
    const totalClients = clientsData.length;
    const totalRevenue = clientsData.reduce((sum, c) => sum + c.totalRevenue, 0);
    const totalProfit = clientsData.reduce((sum, c) => sum + c.totalProfit, 0);
    const marginPercent = totalRevenue > 0 ? (totalProfit / totalRevenue) * 100 : 0;
    const avgTicket = totalClients > 0 ? totalRevenue / totalClients : 0;
    
    // Cálculos de ROI
    const roi = investimento > 0 ? ((totalProfit - investimento) / investimento) * 100 : 0;
    const cpa = investimento > 0 && totalClients > 0 ? investimento / totalClients : 0;
    const returnPerReal = investimento > 0 ? totalProfit / investimento : 0;
    
    // Status do ROI
    const roiStatus = roi >= 100 ? 'excellent' : roi >= 50 ? 'good' : roi >= 0 ? 'neutral' : 'negative';

    return { 
      totalClients, 
      totalRevenue, 
      totalProfit, 
      marginPercent, 
      avgTicket,
      roi,
      cpa,
      returnPerReal,
      roiStatus
    };
  }, [clientsData, investimento]);

  // Ordenar clientes por lucro (maior para menor)
  const sortedClients = useMemo(() => {
    return [...clientsData].sort((a, b) => b.totalProfit - a.totalProfit);
  }, [clientsData]);

  if (loading) {
    return (
      <Card className="border-blue-500/20">
        <CardHeader className="pb-2">
          <div className="flex items-center gap-2">
            <Chrome className="h-5 w-5 text-blue-500" />
            <Skeleton className="h-6 w-40" />
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-4 gap-4">
            {[...Array(4)].map((_, i) => (
              <Skeleton key={i} className="h-20" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  const roiColorClasses = {
    excellent: 'text-emerald-600 bg-emerald-50',
    good: 'text-blue-600 bg-blue-50',
    neutral: 'text-amber-600 bg-amber-50',
    negative: 'text-red-600 bg-red-50'
  };

  const roiBorderClasses = {
    excellent: 'border-emerald-300',
    good: 'border-blue-300',
    neutral: 'border-amber-300',
    negative: 'border-red-300'
  };

  return (
    <motion.section
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
    >
      <Card className="border-blue-500/20 bg-gradient-to-br from-blue-500/5 via-background to-blue-500/10">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-500/10 rounded-xl flex items-center justify-center">
                <Chrome className="h-5 w-5 text-blue-500" />
              </div>
              <div>
                <CardTitle className="text-lg flex items-center gap-2">
                  ROI Google Ads
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger>
                        <Info className="h-4 w-4 text-muted-foreground" />
                      </TooltipTrigger>
                      <TooltipContent className="max-w-xs">
                        <p>Retorno sobre investimento em Google Ads. Compara o lucro bruto dos clientes Google com o valor investido em marketing.</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </CardTitle>
                <p className="text-sm text-muted-foreground capitalize">{periodLabel}</p>
              </div>
            </div>
            
            <Badge variant="outline" className={cn(
              'text-sm font-semibold px-3 py-1',
              roiBorderClasses[stats.roiStatus],
              roiColorClasses[stats.roiStatus]
            )}>
              {stats.roi >= 0 ? '+' : ''}{stats.roi.toFixed(0)}% ROI
            </Badge>
          </div>
        </CardHeader>
        
        <CardContent className="space-y-4">
          {/* KPIs principais */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {/* Investido - Editável */}
            <Card className="border-purple-200 bg-purple-50/50 dark:bg-purple-950/20">
              <CardContent className="pt-3 pb-3">
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center gap-2">
                    <DollarSign className="h-4 w-4 text-purple-500" />
                    <p className="text-xs text-purple-700 dark:text-purple-400 uppercase tracking-wide">Investido</p>
                  </div>
                  {!editMode && companyCostId && (
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="h-6 w-6 p-0"
                      onClick={() => setEditMode(true)}
                    >
                      <Pencil className="h-3 w-3 text-purple-500" />
                    </Button>
                  )}
                </div>
                
                {editMode ? (
                  <div className="space-y-2">
                    <div className="flex items-center gap-1">
                      <span className="text-sm text-purple-600 font-medium">R$</span>
                      <Input
                        type="text"
                        inputMode="decimal"
                        value={investimentoLocal}
                        onChange={(e) => {
                          const val = e.target.value.replace(/[^\d.,]/g, '').replace(',', '.');
                          setInvestimentoLocal(parseFloat(val) || 0);
                        }}
                        className="h-8 text-lg font-bold text-purple-600 bg-white/80"
                        autoFocus
                      />
                    </div>
                    <div className="flex items-center gap-1">
                      <Button
                        size="sm"
                        variant="default"
                        className="h-7 px-2 bg-purple-600 hover:bg-purple-700"
                        onClick={handleSaveInvestimento}
                        disabled={saving}
                      >
                        {saving ? <Loader2 className="h-3 w-3 animate-spin" /> : <Check className="h-3 w-3" />}
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="h-7 px-2"
                        onClick={handleCancelEdit}
                        disabled={saving}
                      >
                        <X className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                ) : (
                  <>
                    <p className="text-xl font-bold text-purple-600">{formatCurrency(investimento)}</p>
                    <p className="text-xs text-muted-foreground">no período</p>
                  </>
                )}
              </CardContent>
            </Card>

            {/* Faturamento */}
            <Card className="border-blue-200 bg-blue-50/50 dark:bg-blue-950/20">
              <CardContent className="pt-3 pb-3">
                <div className="flex items-center gap-2 mb-1">
                  <TrendingUp className="h-4 w-4 text-blue-500" />
                  <p className="text-xs text-blue-700 dark:text-blue-400 uppercase tracking-wide">Faturamento</p>
                </div>
                <p className="text-xl font-bold text-blue-600">{formatCurrency(stats.totalRevenue)}</p>
                <p className="text-xs text-muted-foreground">{stats.totalClients} cliente{stats.totalClients !== 1 ? 's' : ''}</p>
              </CardContent>
            </Card>

            {/* Lucro Bruto */}
            <Card className="border-emerald-200 bg-emerald-50/50 dark:bg-emerald-950/20">
              <CardContent className="pt-3 pb-3">
                <div className="flex items-center gap-2 mb-1">
                  <Target className="h-4 w-4 text-emerald-500" />
                  <p className="text-xs text-emerald-700 dark:text-emerald-400 uppercase tracking-wide">Lucro Bruto</p>
                </div>
                <p className="text-xl font-bold text-emerald-600">{formatCurrency(stats.totalProfit)}</p>
                <p className="text-xs text-muted-foreground">margem {stats.marginPercent.toFixed(1)}%</p>
              </CardContent>
            </Card>

            {/* ROI */}
            <Card className={cn('border-2', roiBorderClasses[stats.roiStatus])}>
              <CardContent className={cn('pt-3 pb-3 rounded-lg', roiColorClasses[stats.roiStatus])}>
                <div className="flex items-center gap-2 mb-1">
                  <ArrowRight className="h-4 w-4" />
                  <p className="text-xs uppercase tracking-wide">ROI</p>
                </div>
                <p className="text-xl font-bold">
                  {stats.roi >= 0 ? '+' : ''}{stats.roi.toFixed(0)}%
                </p>
                <p className="text-xs opacity-80">retorno</p>
              </CardContent>
            </Card>
          </div>

          {/* Detalhamento */}
          <Card className="bg-muted/30 border-border/50">
            <CardContent className="py-3">
              <h4 className="text-sm font-semibold mb-2 flex items-center gap-2">
                <Info className="h-4 w-4 text-muted-foreground" />
                Detalhamento
              </h4>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                <div>
                  <p className="text-muted-foreground">Clientes Google</p>
                  <p className="font-semibold">{stats.totalClients} no período</p>
                </div>
                <div>
                  <p className="text-muted-foreground">CPA médio</p>
                  <p className="font-semibold">{formatCurrency(stats.cpa)} por cliente</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Retorno por R$1</p>
                  <p className="font-semibold">R$ {stats.returnPerReal.toFixed(2)}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Ticket médio</p>
                  <p className="font-semibold">{formatCurrency(stats.avgTicket)}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Lista de clientes Google expansível */}
          {stats.totalClients > 0 && (
            <Collapsible open={showClientsList} onOpenChange={setShowClientsList}>
              <Card className="bg-muted/30 border-border/50 overflow-hidden">
                <CollapsibleTrigger asChild>
                  <CardHeader className="cursor-pointer hover:bg-muted/50 transition-colors py-3">
                    <div className="flex items-center justify-between">
                      <h4 className="text-sm font-semibold flex items-center gap-2">
                        <Users className="h-4 w-4 text-blue-500" />
                        Clientes Google ({stats.totalClients})
                      </h4>
                      <ChevronDown className={cn(
                        "h-4 w-4 text-muted-foreground transition-transform duration-200",
                        showClientsList && "rotate-180"
                      )} />
                    </div>
                  </CardHeader>
                </CollapsibleTrigger>
                
                <CollapsibleContent>
                  <CardContent className="pt-0">
                    <div className="rounded-md border">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Cliente</TableHead>
                            <TableHead className="text-right">Faturamento</TableHead>
                            <TableHead className="text-right">Lucro</TableHead>
                            <TableHead className="text-right">Margem</TableHead>
                            <TableHead className="text-right">Pedidos</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {sortedClients.map(client => {
                            const margin = client.totalRevenue > 0 
                              ? (client.totalProfit / client.totalRevenue) * 100 
                              : 0;
                            return (
                              <TableRow key={client.id}>
                                <TableCell className="font-medium">
                                  {client.companyName}
                                </TableCell>
                                <TableCell className="text-right">
                                  {formatCurrency(client.totalRevenue)}
                                </TableCell>
                                <TableCell className="text-right text-emerald-600 dark:text-emerald-400 font-medium">
                                  {formatCurrency(client.totalProfit)}
                                </TableCell>
                                <TableCell className="text-right">
                                  {margin.toFixed(1)}%
                                </TableCell>
                                <TableCell className="text-right">
                                  {client.orderCount}
                                </TableCell>
                              </TableRow>
                            );
                          })}
                        </TableBody>
                        <TableFooter>
                          <TableRow className="font-semibold bg-muted/50">
                            <TableCell>TOTAL</TableCell>
                            <TableCell className="text-right">
                              {formatCurrency(stats.totalRevenue)}
                            </TableCell>
                            <TableCell className="text-right text-emerald-600 dark:text-emerald-400">
                              {formatCurrency(stats.totalProfit)}
                            </TableCell>
                            <TableCell className="text-right">
                              {stats.marginPercent.toFixed(1)}%
                            </TableCell>
                            <TableCell className="text-right">
                              {clientsData.reduce((sum, c) => sum + c.orderCount, 0)}
                            </TableCell>
                          </TableRow>
                        </TableFooter>
                      </Table>
                    </div>
                  </CardContent>
                </CollapsibleContent>
              </Card>
            </Collapsible>
          )}

          {/* Dica - só mostra se não puder editar inline */}
          {!companyCostId && (
            <div className="flex items-center gap-2 text-xs text-muted-foreground bg-muted/30 rounded-lg p-2">
              <Info className="h-4 w-4 shrink-0" />
              <p>
                Para alterar o investimento: Fase 2 (CEE) → Sistemas e Tecnologia → <strong>Google Ads (estrutural)</strong>
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </motion.section>
  );
}
