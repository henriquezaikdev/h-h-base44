import { useState, useEffect, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { Users, Sparkles, Store, MapPin, ChevronRight, Loader2 } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { supabase } from '@/integrations/supabase/client';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';

interface ClientsByOriginReportProps {
  startDate: Date;
  endDate: Date;
  sellerId?: string | null;
}

interface OriginStats {
  origem: string;
  count: number;
  clients: Array<{
    id: string;
    company_name: string;
    seller_name: string;
    created_at: string;
  }>;
}

const ORIGIN_CONFIG: Record<string, { label: string; icon: typeof Users; color: string }> = {
  conquistado: {
    label: 'Conquistado',
    icon: Sparkles,
    color: 'text-emerald-500 bg-emerald-500/10 border-emerald-500/30',
  },
  google: {
    label: 'Google',
    icon: MapPin,
    color: 'text-blue-500 bg-blue-500/10 border-blue-500/30',
  },
  porta_loja: {
    label: 'Porta de Loja',
    icon: Store,
    color: 'text-purple-500 bg-purple-500/10 border-purple-500/30',
  },
};

export function ClientsByOriginReport({ startDate, endDate, sellerId }: ClientsByOriginReportProps) {
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState<OriginStats[]>([]);
  const [expandedOrigin, setExpandedOrigin] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        let query = supabase
          .from('clients')
          .select(`
            id,
            company_name,
            origem,
            created_at,
            sellers!clients_seller_id_fkey(name)
          `)
          .eq('is_deleted', false)
          .in('origem', ['conquistado', 'google', 'porta_loja'])
          .gte('created_at', format(startDate, 'yyyy-MM-dd'))
          .lte('created_at', format(endDate, 'yyyy-MM-dd') + 'T23:59:59');

        if (sellerId) {
          query = query.eq('seller_id', sellerId);
        }

        const { data, error } = await query.order('created_at', { ascending: false });

        if (error) {
          console.error('Error fetching clients by origin:', error);
          return;
        }

        // Agrupar por origem
        const grouped: Record<string, OriginStats> = {
          conquistado: { origem: 'conquistado', count: 0, clients: [] },
          google: { origem: 'google', count: 0, clients: [] },
          porta_loja: { origem: 'porta_loja', count: 0, clients: [] },
        };

        (data || []).forEach((client: any) => {
          const origem = client.origem || 'conquistado';
          if (grouped[origem]) {
            grouped[origem].count++;
            grouped[origem].clients.push({
              id: client.id,
              company_name: client.company_name,
              seller_name: (client.sellers as any)?.name || 'Sem vendedor',
              created_at: client.created_at,
            });
          }
        });

        setStats(Object.values(grouped));
      } catch (error) {
        console.error('Error:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [startDate, endDate, sellerId]);

  const totalClients = useMemo(() => stats.reduce((sum, s) => sum + s.count, 0), [stats]);

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Users className="h-5 w-5" />
            Clientes por Origem
          </CardTitle>
        </CardHeader>
        <CardContent className="flex items-center justify-center py-8">
          <Loader2 className="h-6 w-6 animate-spin text-primary" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-base">
            <Users className="h-5 w-5 text-primary" />
            Clientes por Origem
          </CardTitle>
          <Badge variant="outline">
            {totalClients} novo{totalClients !== 1 ? 's' : ''}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        {stats.map((stat) => {
          const config = ORIGIN_CONFIG[stat.origem];
          const IconComponent = config?.icon || Users;
          const isExpanded = expandedOrigin === stat.origem;

          return (
            <div key={stat.origem} className="space-y-2">
              <button
                onClick={() => setExpandedOrigin(isExpanded ? null : stat.origem)}
                className={cn(
                  'w-full flex items-center justify-between p-3 rounded-lg border transition-all',
                  config?.color || 'bg-muted',
                  'hover:shadow-sm'
                )}
              >
                <div className="flex items-center gap-3">
                  <IconComponent className="h-5 w-5" />
                  <span className="font-medium">{config?.label || stat.origem}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="secondary" className="font-bold">
                    {stat.count}
                  </Badge>
                  <ChevronRight
                    className={cn(
                      'h-4 w-4 transition-transform',
                      isExpanded && 'rotate-90'
                    )}
                  />
                </div>
              </button>

              {isExpanded && stat.clients.length > 0 && (
                <ScrollArea className="h-[200px] rounded-lg border bg-muted/30 p-2">
                  <div className="space-y-1">
                    {stat.clients.map((client) => (
                      <Link
                        key={client.id}
                        to={`/clients/${client.id}`}
                        className="flex items-center justify-between p-2 rounded-md hover:bg-muted transition-colors"
                      >
                        <div className="min-w-0 flex-1">
                          <p className="text-sm font-medium truncate">
                            {client.company_name}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {client.seller_name} • {format(new Date(client.created_at), 'dd/MM/yyyy')}
                          </p>
                        </div>
                        <ChevronRight className="h-4 w-4 text-muted-foreground shrink-0" />
                      </Link>
                    ))}
                  </div>
                </ScrollArea>
              )}

              {isExpanded && stat.clients.length === 0 && (
                <div className="p-4 text-center text-sm text-muted-foreground rounded-lg border bg-muted/30">
                  Nenhum cliente neste período
                </div>
              )}
            </div>
          );
        })}

        {totalClients === 0 && (
          <div className="py-8 text-center text-muted-foreground">
            <Users className="h-10 w-10 mx-auto mb-2 opacity-30" />
            <p className="text-sm">Nenhum cliente novo neste período</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
