import { useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  TrendingUp, 
  TrendingDown,
  DollarSign,
  Percent,
  Phone,
  ShoppingCart,
  Target,
  Users,
  ArrowRight,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Info
} from 'lucide-react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { cn } from '@/lib/utils';
import type { SellerResult } from '@/hooks/useGestorData';
import type { Layer5Analysis } from './Layer5StrategicAnalysis';
import { SellerKPIRow } from './SellerKPIRow';
import { SellerProgressChart } from './SellerProgressChart';
import { EffortResultFlow } from './EffortResultFlow';
import { SellerBreakEvenCard } from './SellerBreakEvenCard';

interface SellerAnalysisDashboardProps {
  seller: SellerResult;
  layer5Analysis?: Layer5Analysis;
}

function formatCurrency(value: number): string {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value);
}

function formatPercent(value: number): string {
  return `${value.toFixed(1)}%`;
}

export function SellerAnalysisDashboard({ seller, layer5Analysis }: SellerAnalysisDashboardProps) {
  const kpis = useMemo(() => [
    {
      label: 'Faturamento',
      value: formatCurrency(seller.revenue),
      icon: DollarSign,
      color: 'text-emerald-600',
      bg: 'bg-emerald-50',
    },
    {
      label: 'Margem %',
      value: formatPercent(seller.marginPercent),
      icon: Percent,
      color: seller.marginPercent >= 30 ? 'text-emerald-600' : 'text-amber-600',
      bg: seller.marginPercent >= 30 ? 'bg-emerald-50' : 'bg-amber-50',
    },
    {
      label: 'Contatos',
      value: seller.contacts.toString(),
      icon: Phone,
      color: 'text-blue-600',
      bg: 'bg-blue-50',
    },
    {
      label: 'Resultado Real',
      value: formatCurrency(seller.resultadoReal),
      icon: seller.resultadoReal >= 0 ? TrendingUp : TrendingDown,
      color: seller.resultadoReal >= 0 ? 'text-emerald-600' : 'text-red-600',
      bg: seller.resultadoReal >= 0 ? 'bg-emerald-50' : 'bg-red-50',
    },
  ], [seller]);

  const statusItems = useMemo(() => [
    {
      label: 'Venda Faz Sentido',
      description: 'Resultado Direto > 0',
      status: seller.vendaFazSentido,
      tooltip: 'A venda gera resultado direto positivo antes da estrutura.',
    },
    {
      label: 'Se Paga',
      description: 'Resultado Direto ≥ Custo Humano',
      status: seller.sePaga,
      tooltip: 'O vendedor cobre o próprio custo direto.',
    },
    {
      label: 'Sustenta Empresa',
      description: 'Resultado Real > 0',
      status: seller.sustentaEmpresa,
      tooltip: 'O vendedor ajuda a cobrir também a estrutura da empresa.',
    },
    {
      label: 'Gera Lucro',
      description: 'Resultado Real > Meta Mínima',
      status: seller.geraLucro,
      tooltip: 'Depois de tudo, ainda sobra resultado positivo.',
    },
  ], [seller]);

  // Usar meta REAL de seller_levels, não metaMinima (break-even)
  const metaMensal = seller.monthlySalesTarget || layer5Analysis?.metaMensal || 30000;
  const eficienciaMeta = metaMensal > 0 ? (seller.revenue / metaMensal) * 100 : 0;

  return (
    <ScrollArea className="h-full">
      <div className="p-6 space-y-6">
        {/* KPIs Row */}
        <SellerKPIRow kpis={kpis} />

        {/* Status Cards */}
        <div className="grid grid-cols-4 gap-3">
          {statusItems.map((item, idx) => (
            <TooltipProvider key={idx}>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Card className={cn(
                    'border-2 cursor-help',
                    item.status ? 'border-emerald-200 bg-emerald-50/50' : 'border-red-200 bg-red-50/50'
                  )}>
                    <CardContent className="p-3 flex items-center gap-3">
                      {item.status ? (
                        <CheckCircle2 className="h-5 w-5 text-emerald-600 shrink-0" />
                      ) : (
                        <XCircle className="h-5 w-5 text-red-600 shrink-0" />
                      )}
                      <div>
                        <p className="text-sm font-medium">{item.label}</p>
                        <p className="text-xs text-muted-foreground">{item.description}</p>
                      </div>
                    </CardContent>
                  </Card>
                </TooltipTrigger>
                <TooltipContent className="max-w-xs">
                  <p className="text-xs">{item.tooltip}</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          ))}
        </div>

        {/* Progress Chart */}
        <SellerProgressChart
          revenue={seller.revenue}
          meta={metaMensal}
          eficiencia={eficienciaMeta}
        />

        {/* FASES DE BREAK-EVEN */}
        <SellerBreakEvenCard
          custoDirecto={seller.custoHumano + seller.cdv}
          metaFase1={seller.metaFase1}
          ceeRateio={seller.ceeRateio}
          metaFase2={seller.metaFase2}
          fase3Rateio={seller.fase3Rateio}
          metaFase3={seller.metaFase3}
          receita={seller.revenue}
          margemRealPercent={seller.margemRealPercent}
          commissionEnabled={seller.commissionEnabled}
        />

        {/* Effort → Result Flow */}
        <div>
          <p className="text-xs text-muted-foreground mb-2">
            Este fluxo mostra o caminho do dinheiro: o que entra na venda, o que sai em custos e o que realmente sobra.
          </p>
          <EffortResultFlow
            margemBruta={seller.marginBruta}
            cdv={seller.cdv}
            custoHumano={seller.custoHumano}
            ceeRateio={seller.ceeRateio}
            fase3Rateio={seller.fase3Rateio}
            resultadoReal={seller.resultadoReal}
            receita={seller.revenue}
          />
        </div>

        {/* Detailed Metrics */}
        <div className="grid grid-cols-2 gap-4">
          {/* Vendas */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2">
                <ShoppingCart className="h-4 w-4 text-primary" />
                Vendas
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Pedidos</span>
                <span className="font-medium">{seller.ordersCount}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Ticket Médio</span>
                <span className="font-medium">{formatCurrency(seller.avgTicket)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Taxa de Conversão</span>
                <span className="font-medium">{formatPercent(seller.conversionRate)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Margem Bruta</span>
                <span className="font-medium">{formatCurrency(seller.marginBruta)}</span>
              </div>
            </CardContent>
          </Card>

          {/* Atividade */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2">
                <Users className="h-4 w-4 text-primary" />
                Atividade
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Contatos Totais</span>
                <span className="font-medium">{seller.contacts}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Ligações</span>
                <span className="font-medium">{seller.calls}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">WhatsApp</span>
                <span className="font-medium">{seller.whatsapp}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Contatos/Pedido</span>
                <span className="font-medium">
                  {seller.ordersCount > 0 
                    ? (seller.contacts / seller.ordersCount).toFixed(1) 
                    : '-'}
                </span>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Custos Breakdown */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <DollarSign className="h-4 w-4 text-primary" />
              Composição de Custos
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-5 gap-3">
              <div className="text-center p-3 rounded-lg bg-amber-50 border border-amber-200">
                <p className="text-xs text-amber-700 mb-1">CDV (Comissão)</p>
                <p className="text-lg font-bold text-amber-800">{formatCurrency(seller.cdv)}</p>
                <p className="text-xs text-amber-600">
                  {seller.revenue > 0 ? ((seller.cdv / seller.revenue) * 100).toFixed(1) : '0'}% da receita
                </p>
              </div>
              <div className="text-center p-3 rounded-lg bg-blue-50 border border-blue-200">
                <p className="text-xs text-blue-700 mb-1">Custo Humano</p>
                <p className="text-lg font-bold text-blue-800">{formatCurrency(seller.custoHumano)}</p>
                <p className="text-xs text-blue-600">
                  {seller.revenue > 0 ? ((seller.custoHumano / seller.revenue) * 100).toFixed(1) : '0'}% da receita
                </p>
              </div>
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <div className="text-center p-3 rounded-lg bg-purple-50 border border-purple-200 cursor-help">
                      <p className="text-xs text-purple-700 mb-1 flex items-center justify-center gap-1">
                        CEE Rateio
                        <Info className="h-3 w-3" />
                      </p>
                      <p className="text-lg font-bold text-purple-800">{formatCurrency(seller.ceeRateio)}</p>
                      <p className="text-xs text-purple-600">
                        {seller.revenue > 0 ? ((seller.ceeRateio / seller.revenue) * 100).toFixed(1) : '0'}% da receita
                      </p>
                    </div>
                  </TooltipTrigger>
                  <TooltipContent className="max-w-xs">
                    <p className="text-xs">Parcela da estrutura fixa da empresa atribuída a este vendedor pela participação dele no negócio. Não é salário do vendedor.</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
              <div className="text-center p-3 rounded-lg bg-fuchsia-50 border border-fuchsia-200">
                <p className="text-xs text-fuchsia-700 mb-1">Fase 3 (Desp. Finais)</p>
                <p className="text-lg font-bold text-fuchsia-800">{formatCurrency(seller.fase3Rateio)}</p>
                <p className="text-xs text-fuchsia-600">
                  {seller.revenue > 0 ? ((seller.fase3Rateio / seller.revenue) * 100).toFixed(1) : '0'}% da receita
                </p>
              </div>
              <div className={cn(
                "text-center p-3 rounded-lg border",
                seller.resultadoReal >= 0 
                  ? "bg-emerald-50 border-emerald-200" 
                  : "bg-red-50 border-red-200"
              )}>
                <p className={cn(
                  "text-xs mb-1",
                  seller.resultadoReal >= 0 ? "text-emerald-700" : "text-red-700"
                )}>Resultado Real</p>
                <p className={cn(
                  "text-lg font-bold",
                  seller.resultadoReal >= 0 ? "text-emerald-800" : "text-red-800"
                )}>{formatCurrency(seller.resultadoReal)}</p>
                <p className={cn(
                  "text-xs",
                  seller.resultadoReal >= 0 ? "text-emerald-600" : "text-red-600"
                )}>
                  {seller.sustentaEmpresa ? 'Sustenta' : 'Não sustenta'}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Break-even por Fase */}
        {!seller.sustentaEmpresa && (
          <Card className="border-amber-200 bg-amber-50/50">
            <CardContent className="p-4 flex items-start gap-3">
              <AlertCircle className="h-5 w-5 text-amber-600 shrink-0 mt-0.5" />
              <div>
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <p className="font-medium text-amber-800 cursor-help underline decoration-dashed">
                        Ponto de equilíbrio não atingido
                      </p>
                    </TooltipTrigger>
                    <TooltipContent className="max-w-xs">
                      <p className="text-xs">É o ponto em que a venda cobre integralmente a fase analisada.</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
                <p className="text-sm text-amber-700 mt-1">
                  Com a margem real atual, este vendedor ainda não vendeu o suficiente para cobrir todas as fases.
                </p>
                <div className="text-sm text-amber-700 mt-2 space-y-1">
                  {seller.revenue < seller.metaFase1 && (
                    <p>Na <strong>Fase 1</strong>, precisaria faturar <strong>{formatCurrency(seller.metaFase1)}</strong> para se pagar.</p>
                  )}
                  {seller.revenue < seller.metaFase2 && (
                    <p>Na <strong>Fase 2</strong>, precisaria faturar <strong>{formatCurrency(seller.metaFase2)}</strong> para cobrir também a estrutura.</p>
                  )}
                  {seller.revenue < seller.metaFase3 && (
                    <p>Na <strong>Fase 3</strong>, precisaria faturar <strong>{formatCurrency(seller.metaFase3)}</strong> para cobrir também as despesas finais.</p>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </ScrollArea>
  );
}
