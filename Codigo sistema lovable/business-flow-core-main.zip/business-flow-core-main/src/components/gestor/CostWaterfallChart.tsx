import { useMemo } from 'react';
import { motion } from 'framer-motion';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer,
  Cell,
  ReferenceLine
} from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Droplets, TrendingDown, ArrowRight } from 'lucide-react';
import { cn } from '@/lib/utils';

interface CostWaterfallChartProps {
  lucroBruto: number;
  cdvTotal: number;
  custoHumano: number;
  ceeTotal: number;
  resultadoReal: number;
  className?: string;
}

const formatCurrency = (value: number) =>
  new Intl.NumberFormat('pt-BR', { 
    style: 'currency', 
    currency: 'BRL', 
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(value);

export function CostWaterfallChart({
  lucroBruto,
  cdvTotal,
  custoHumano,
  ceeTotal,
  resultadoReal,
  className
}: CostWaterfallChartProps) {
  
  // Construir dados para waterfall usando técnica de stacked bars
  const waterfallData = useMemo(() => {
    // Calcular posições acumuladas para o efeito waterfall
    const afterCDV = lucroBruto - cdvTotal;
    const afterHumano = afterCDV - custoHumano;
    const afterCEE = afterHumano - ceeTotal;
    
    return [
      {
        name: 'Lucro Bruto',
        value: lucroBruto,
        displayValue: lucroBruto,
        offset: 0,
        type: 'income' as const,
        description: 'Receita - Custo dos Produtos'
      },
      {
        name: 'CDV (Comissão)',
        value: cdvTotal,
        displayValue: -cdvTotal,
        offset: afterCDV,
        type: 'expense' as const,
        description: 'Custo Direto Variável'
      },
      {
        name: 'Custo Humano',
        value: custoHumano,
        displayValue: -custoHumano,
        offset: afterHumano,
        type: 'expense' as const,
        description: 'Salários + Encargos + Benefícios'
      },
      {
        name: 'CEE',
        value: ceeTotal,
        displayValue: -ceeTotal,
        offset: afterCEE,
        type: 'expense' as const,
        description: 'Custo Estrutural da Empresa'
      },
      {
        name: 'Resultado Real',
        value: Math.abs(resultadoReal),
        displayValue: resultadoReal,
        offset: 0,
        type: resultadoReal >= 0 ? 'result_positive' as const : 'result_negative' as const,
        description: 'Lucro Líquido Real'
      }
    ];
  }, [lucroBruto, cdvTotal, custoHumano, ceeTotal, resultadoReal]);

  // Calcular percentuais para insights
  const insights = useMemo(() => {
    if (lucroBruto <= 0) return null;
    
    const cdvPercent = (cdvTotal / lucroBruto) * 100;
    const humanoPercent = (custoHumano / lucroBruto) * 100;
    const ceePercent = (ceeTotal / lucroBruto) * 100;
    const totalCostsPercent = cdvPercent + humanoPercent + ceePercent;
    
    // Identificar maior consumidor
    const costs = [
      { name: 'CDV', value: cdvTotal, percent: cdvPercent },
      { name: 'Custo Humano', value: custoHumano, percent: humanoPercent },
      { name: 'CEE', value: ceeTotal, percent: ceePercent }
    ];
    const biggestCost = costs.reduce((a, b) => a.value > b.value ? a : b);
    
    return {
      cdvPercent,
      humanoPercent,
      ceePercent,
      totalCostsPercent,
      biggestCost,
      isDeficit: resultadoReal < 0,
      deficit: Math.abs(resultadoReal)
    };
  }, [lucroBruto, cdvTotal, custoHumano, ceeTotal, resultadoReal]);

  // Cores usando tokens semânticos via CSS variables
  const getBarColor = (type: string) => {
    switch (type) {
      case 'income':
        return 'hsl(var(--emerald))';
      case 'expense':
        return 'hsl(var(--rose))';
      case 'result_positive':
        return 'hsl(var(--violet))';
      case 'result_negative':
        return 'hsl(var(--rose))';
      default:
        return 'hsl(var(--muted))';
    }
  };

  // Custom Tooltip
  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      const isPositive = data.displayValue >= 0;
      const percent = lucroBruto > 0 
        ? Math.abs((data.value / lucroBruto) * 100)
        : 0;
      
      return (
        <div className="bg-popover/95 backdrop-blur-sm border border-border rounded-lg p-3 shadow-xl">
          <p className="font-semibold text-foreground">{data.name}</p>
          <p className="text-xs text-muted-foreground mb-1">{data.description}</p>
          <p className={cn(
            'text-lg font-bold',
            isPositive ? 'text-emerald' : 'text-rose'
          )}>
            {isPositive ? '+' : ''}{formatCurrency(data.displayValue)}
          </p>
          {data.type !== 'income' && data.type !== 'result_positive' && data.type !== 'result_negative' && (
            <p className="text-xs text-muted-foreground mt-1">
              Consome {percent.toFixed(1)}% do Lucro Bruto
            </p>
          )}
        </div>
      );
    }
    return null;
  };

  // Domínio do eixo X
  const maxValue = Math.max(lucroBruto, Math.abs(resultadoReal)) * 1.1;
  const minValue = resultadoReal < 0 ? resultadoReal * 1.1 : 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
    >
      <Card className={cn('overflow-hidden', className)}>
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-lg bg-violet/10">
                <Droplets className="h-5 w-5 text-violet" />
              </div>
              <div>
                <CardTitle className="text-base">Composição do Resultado</CardTitle>
                <p className="text-xs text-muted-foreground">
                  Como o lucro bruto é consumido pelos custos
                </p>
              </div>
            </div>
            
            {/* Indicador de resultado */}
            <div className={cn(
              'px-3 py-1.5 rounded-full text-sm font-semibold',
              resultadoReal >= 0 
                ? 'bg-emerald/10 text-emerald' 
                : 'bg-rose/10 text-rose'
            )}>
              {resultadoReal >= 0 ? '+' : ''}{formatCurrency(resultadoReal)}
            </div>
          </div>
        </CardHeader>
        
        <CardContent className="pt-4">
          {/* Gráfico Waterfall */}
          <div className="h-[280px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                layout="vertical"
                data={waterfallData}
                margin={{ top: 10, right: 30, left: 100, bottom: 10 }}
              >
                <XAxis 
                  type="number" 
                  domain={[minValue, maxValue]}
                  tickFormatter={(value) => `${(value / 1000).toFixed(0)}k`}
                  tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }}
                  axisLine={{ stroke: 'hsl(var(--border))' }}
                />
                <YAxis 
                  type="category" 
                  dataKey="name"
                  tick={{ fontSize: 12, fill: 'hsl(var(--foreground))' }}
                  axisLine={false}
                  tickLine={false}
                  width={95}
                />
                <Tooltip content={<CustomTooltip />} cursor={{ fill: 'hsl(var(--muted)/0.3)' }} />
                
                {/* Linha de referência no zero */}
                <ReferenceLine 
                  x={0} 
                  stroke="hsl(var(--border))" 
                  strokeWidth={2}
                  strokeDasharray="4 4"
                />
                
                {/* Barra invisível para offset (efeito waterfall) */}
                <Bar 
                  dataKey="offset" 
                  stackId="waterfall" 
                  fill="transparent"
                  isAnimationActive={false}
                />
                
                {/* Barra colorida com valor */}
                <Bar 
                  dataKey="value" 
                  stackId="waterfall"
                  radius={[0, 4, 4, 0]}
                  isAnimationActive={true}
                  animationDuration={800}
                  animationEasing="ease-out"
                >
                  {waterfallData.map((entry, index) => (
                    <Cell 
                      key={`cell-${index}`} 
                      fill={getBarColor(entry.type)}
                      opacity={0.9}
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
          
          {/* Insights no rodapé */}
          {insights && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5 }}
              className="mt-4 pt-4 border-t border-border"
            >
              {/* Fluxo visual de consumo */}
              <div className="flex items-center justify-between text-xs mb-3">
                <div className="flex items-center gap-1.5">
                  <div className="w-3 h-3 rounded-full bg-emerald" />
                  <span className="text-muted-foreground">Entrada</span>
                </div>
                <ArrowRight className="h-3 w-3 text-muted-foreground" />
                <div className="flex items-center gap-1.5">
                  <div className="w-3 h-3 rounded-full bg-rose" />
                  <span className="text-muted-foreground">Custos ({insights.totalCostsPercent.toFixed(0)}%)</span>
                </div>
                <ArrowRight className="h-3 w-3 text-muted-foreground" />
                <div className="flex items-center gap-1.5">
                  <div className={cn(
                    'w-3 h-3 rounded-full',
                    resultadoReal >= 0 ? 'bg-violet' : 'bg-rose'
                  )} />
                  <span className="text-muted-foreground">Resultado</span>
                </div>
              </div>
              
              {/* Insight principal */}
              <div className={cn(
                'p-3 rounded-lg text-sm',
                insights.isDeficit ? 'bg-rose/10' : 'bg-emerald/10'
              )}>
                <div className="flex items-start gap-2">
                  <TrendingDown className={cn(
                    'h-4 w-4 mt-0.5 shrink-0',
                    insights.isDeficit ? 'text-rose' : 'text-emerald'
                  )} />
                  <div>
                    {insights.isDeficit ? (
                      <p className="text-rose">
                        <span className="font-semibold">Déficit de {formatCurrency(insights.deficit)}.</span>
                        {' '}Maior consumidor: <span className="font-medium">{insights.biggestCost.name}</span> ({insights.biggestCost.percent.toFixed(1)}% do lucro bruto)
                      </p>
                    ) : (
                      <p className="text-emerald">
                        <span className="font-semibold">Margem saudável!</span>
                        {' '}Após todos os custos, sobram {formatCurrency(resultadoReal)} ({((resultadoReal / lucroBruto) * 100).toFixed(1)}% do lucro bruto)
                      </p>
                    )}
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
}
