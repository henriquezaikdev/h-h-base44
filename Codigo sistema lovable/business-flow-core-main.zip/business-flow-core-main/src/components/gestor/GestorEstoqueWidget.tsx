import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { Package, AlertTriangle } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';

interface CriticalProduct {
  id: string;
  name: string;
  stock_quantity: number;
  days_until_stockout: number | null;
}

export function GestorEstoqueWidget() {
  const [products, setProducts] = useState<CriticalProduct[]>([]);
  const [totalCritical, setTotalCritical] = useState(0);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const load = async () => {
      // Get products with stock settings
      const { data: prods } = await supabase
        .from('products')
        .select('id, name, stock_quantity')
        .eq('active', true)
        .gt('stock_quantity', 0);

      const { data: settings } = await supabase
        .from('stock_settings')
        .select('product_id, min_stock');

      if (!prods) { setLoading(false); return; }

      const settingsMap = new Map((settings || []).map((s: any) => [s.product_id, s]));

      // Identify critical products by min_stock only (no N+1 RPC calls)
      const critical: CriticalProduct[] = [];

      for (const p of prods) {
        const s = settingsMap.get(p.id);
        const qty = Number(p.stock_quantity) || 0;
        const minStock = s?.min_stock ?? 0;

        if (minStock > 0 && qty <= minStock) {
          critical.push({ id: p.id, name: p.name, stock_quantity: qty, days_until_stockout: null });
        }
      }

      // Sort by most critical (lowest stock)
      critical.sort((a, b) => a.stock_quantity - b.stock_quantity);

      setTotalCritical(critical.length);
      setProducts(critical.slice(0, 5));
      setLoading(false);
    };

    load();
  }, []);

  if (loading || totalCritical === 0) return null;

  return (
    <div className="bg-card rounded-xl border border-red-500/30 shadow-sm p-5 space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Package className="h-5 w-5 text-destructive" />
          <h3 className="font-semibold text-sm">Estoque Crítico</h3>
          <Badge variant="destructive" className="text-xs">{totalCritical}</Badge>
        </div>
        <Button variant="ghost" size="sm" onClick={() => navigate('/estoque')} className="text-xs">
          Ver tudo
        </Button>
      </div>
      <div className="space-y-2">
        {products.map(p => (
          <div key={p.id} className="flex items-center justify-between text-sm">
            <span className="truncate max-w-[200px]">{p.name}</span>
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="text-xs">{p.stock_quantity} un</Badge>
              <AlertTriangle className="h-3.5 w-3.5 text-destructive" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
