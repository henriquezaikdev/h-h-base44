import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTeamPriorityQueue, SellerQueueSummary } from '@/hooks/useTeamPriorityQueue';
import type { PriorityQueueItem } from '@/hooks/useClientPriorityQueue';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import {
  Loader2, AlertTriangle, TrendingUp, ShoppingCart, Users, Target,
  ChevronDown, ChevronUp, ExternalLink, CheckCircle, MessageSquare,
  RefreshCw, Flame, Eye, Clock,
} from 'lucide-react';
import { cn } from '@/lib/utils';

type FilterType = 'todos' | 'criticos' | 'sem_acao' | 'risco' | 'recompra' | 'tarefa' | 'trabalhados';

const FILTERS: { key: FilterType; label: string }[] = [
  { key: 'todos', label: 'Todos' },
  { key: 'criticos', label: 'Máxima/Alta' },
  { key: 'sem_acao', label: 'Sem ação' },
  { key: 'risco', label: 'Em risco' },
  { key: 'recompra', label: 'Recompra' },
  { key: 'tarefa', label: 'Com tarefa' },
  { key: 'trabalhados', label: 'Trabalhados' },
];

const NIVEL_CONFIG: Record<string, { label: string; cls: string; dot: string }> = {
  maxima: { label: 'Máxima', cls: 'text-destructive bg-destructive/10', dot: 'bg-destructive' },
  alta: { label: 'Alta', cls: 'text-amber-600 dark:text-amber-400 bg-amber-500/10', dot: 'bg-amber-500' },
  media: { label: 'Média', cls: 'text-primary bg-primary/10', dot: 'bg-primary' },
  baixa: { label: 'Baixa', cls: 'text-muted-foreground bg-muted', dot: 'bg-muted-foreground/40' },
};

export function GestorFilaComercialTab() {
  const navigate = useNavigate();
  const { data, isLoading, refetch } = useTeamPriorityQueue();
  const [filter, setFilter] = useState<FilterType>('todos');
  const [sellerFilter, setSellerFilter] = useState<string | null>(null);
  const [refreshing, setRefreshing] = useState(false);
  const [view, setView] = useState<'vendedores' | 'criticos'>('vendedores');

  const handleRefresh = async () => {
    setRefreshing(true);
    await refetch();
    setRefreshing(false);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="h-6 w-6 animate-spin text-primary" />
      </div>
    );
  }

  if (!data || data.allItems.length === 0) {
    return (
      <Card className="border-border/40">
        <CardContent className="py-12 text-center text-muted-foreground text-sm">
          Nenhuma fila calculada para hoje. As filas são geradas quando os vendedores acessam o Meu Dia.
        </CardContent>
      </Card>
    );
  }

  const { totals, sellers } = data;

  return (
    <div className="space-y-6">
      {/* Summary KPIs */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        <SummaryCard icon={Flame} label="Prioridade Máxima" value={totals.maxima} color="text-destructive" bg="bg-destructive/10" />
        <SummaryCard icon={AlertTriangle} label="Prioridade Alta" value={totals.alta} color="text-amber-600 dark:text-amber-400" bg="bg-amber-500/10" />
        <SummaryCard icon={Eye} label="Críticos sem ação" value={totals.criticos_sem_acao} color="text-destructive" bg="bg-destructive/10" />
        <SummaryCard icon={ShoppingCart} label="Oportunidades" value={totals.oportunidades} color="text-primary" bg="bg-primary/10" />
        <SummaryCard icon={Users} label="Vendedores críticos" value={totals.vendedores_criticos} color="text-foreground" bg="bg-muted" />
      </div>

      {/* Controls */}
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex gap-1.5">
          <button
            onClick={() => setView('vendedores')}
            className={cn("px-3 py-1.5 rounded-lg text-xs font-medium transition-colors",
              view === 'vendedores' ? "bg-primary text-primary-foreground" : "bg-muted/60 text-muted-foreground hover:bg-muted"
            )}
          >
            Por vendedor
          </button>
          <button
            onClick={() => setView('criticos')}
            className={cn("px-3 py-1.5 rounded-lg text-xs font-medium transition-colors",
              view === 'criticos' ? "bg-destructive text-destructive-foreground" : "bg-muted/60 text-muted-foreground hover:bg-muted"
            )}
          >
            Críticos sem ação
          </button>
        </div>

        <div className="flex items-center gap-2">
          {/* Seller filter */}
          <select
            value={sellerFilter || ''}
            onChange={e => setSellerFilter(e.target.value || null)}
            className="h-8 px-2 rounded-lg border border-border/50 bg-background text-xs text-foreground"
          >
            <option value="">Todos vendedores</option>
            {sellers.map(s => (
              <option key={s.seller_id} value={s.seller_id}>{s.seller_name}</option>
            ))}
          </select>
          <Button variant="ghost" size="sm" onClick={handleRefresh} disabled={refreshing} className="h-8 text-xs gap-1.5">
            <RefreshCw className={cn("h-3 w-3", refreshing && "animate-spin")} />
            Atualizar
          </Button>
        </div>
      </div>

      {/* Filters */}
      <div className="flex gap-1 overflow-x-auto pb-1 scrollbar-hide">
        {FILTERS.map(f => (
          <button
            key={f.key}
            onClick={() => setFilter(f.key)}
            className={cn(
              "px-2.5 py-1 rounded-full text-[11px] font-medium whitespace-nowrap transition-colors",
              filter === f.key ? "bg-primary text-primary-foreground" : "bg-muted/60 text-muted-foreground hover:bg-muted"
            )}
          >
            {f.label}
          </button>
        ))}
      </div>

      {/* Content */}
      {view === 'vendedores' ? (
        <SellerView
          sellers={sellers}
          filter={filter}
          sellerFilter={sellerFilter}
          onOpenClient={(id) => navigate(`/clients/${id}`)}
        />
      ) : (
        <CriticalClientsView
          data={data}
          sellerFilter={sellerFilter}
          onOpenClient={(id) => navigate(`/clients/${id}`)}
        />
      )}
    </div>
  );
}

function SummaryCard({ icon: Icon, label, value, color, bg }: { icon: any; label: string; value: number; color: string; bg: string }) {
  return (
    <Card className="border-border/40">
      <CardContent className="p-3 flex items-center gap-3">
        <div className={cn("w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0", bg)}>
          <Icon className={cn("h-4 w-4", color)} />
        </div>
        <div>
          <p className={cn("text-xl font-bold tabular-nums", color)}>{value}</p>
          <p className="text-[10px] text-muted-foreground leading-tight">{label}</p>
        </div>
      </CardContent>
    </Card>
  );
}

function SellerView({ sellers, filter, sellerFilter, onOpenClient }: {
  sellers: SellerQueueSummary[];
  filter: FilterType;
  sellerFilter: string | null;
  onOpenClient: (id: string) => void;
}) {
  const filtered = sellerFilter ? sellers.filter(s => s.seller_id === sellerFilter) : sellers;

  return (
    <div className="space-y-3">
      {filtered.map(seller => (
        <SellerBlock key={seller.seller_id} seller={seller} filter={filter} onOpenClient={onOpenClient} />
      ))}
    </div>
  );
}

function SellerBlock({ seller, filter, onOpenClient }: {
  seller: SellerQueueSummary;
  filter: FilterType;
  onOpenClient: (id: string) => void;
}) {
  const [open, setOpen] = useState(false);

  const filteredItems = useMemo(() => {
    let items = seller.items;
    switch (filter) {
      case 'criticos': items = items.filter(i => i.prioridade_nivel === 'maxima' || i.prioridade_nivel === 'alta'); break;
      case 'sem_acao': items = items.filter(i => !i.contacted_today && !i.has_pending_task); break;
      case 'risco': items = items.filter(i => i.cliente_em_risco); break;
      case 'recompra': items = items.filter(i => i.oportunidade_recompra); break;
      case 'tarefa': items = items.filter(i => i.has_pending_task); break;
      case 'trabalhados': items = items.filter(i => i.contacted_today); break;
    }
    return items;
  }, [seller.items, filter]);

  const execPercent = seller.total > 0
    ? Math.round((seller.trabalhados_hoje / seller.total) * 100)
    : 0;

  return (
    <Collapsible open={open} onOpenChange={setOpen}>
      <Card className={cn(
        "border-border/40 transition-colors",
        seller.maxima > 0 && "border-l-2 border-l-destructive",
      )}>
        <CollapsibleTrigger asChild>
          <CardHeader className="p-3 cursor-pointer hover:bg-muted/30 transition-colors">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                  <span className="text-xs font-bold text-primary">{seller.seller_name.charAt(0)}</span>
                </div>
                <div>
                  <p className="text-sm font-semibold text-foreground">{seller.seller_name}</p>
                  <div className="flex items-center gap-2 mt-0.5">
                    {seller.maxima > 0 && <span className="text-[9px] font-bold text-destructive bg-destructive/10 px-1.5 py-0.5 rounded-full">{seller.maxima} máxima</span>}
                    {seller.alta > 0 && <span className="text-[9px] font-bold text-amber-600 dark:text-amber-400 bg-amber-500/10 px-1.5 py-0.5 rounded-full">{seller.alta} alta</span>}
                    {seller.sem_acao > 0 && <span className="text-[9px] font-medium text-muted-foreground bg-muted px-1.5 py-0.5 rounded-full">{seller.sem_acao} sem ação</span>}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                {/* Execution indicator */}
                <div className="text-right hidden sm:block">
                  <p className="text-[10px] text-muted-foreground">Execução</p>
                  <div className="flex items-center gap-1.5">
                    <div className="w-16 h-1.5 bg-muted rounded-full overflow-hidden">
                      <div
                        className={cn("h-full rounded-full transition-all",
                          execPercent >= 70 ? "bg-primary" : execPercent >= 40 ? "bg-amber-500" : "bg-destructive"
                        )}
                        style={{ width: `${execPercent}%` }}
                      />
                    </div>
                    <span className="text-[10px] font-semibold tabular-nums text-foreground">{execPercent}%</span>
                  </div>
                  <p className="text-[9px] text-muted-foreground">{seller.trabalhados_hoje}/{seller.total} trabalhados</p>
                </div>
                {open ? <ChevronUp className="h-4 w-4 text-muted-foreground" /> : <ChevronDown className="h-4 w-4 text-muted-foreground" />}
              </div>
            </div>
          </CardHeader>
        </CollapsibleTrigger>
        <CollapsibleContent>
          <CardContent className="px-3 pb-3 pt-0 space-y-1.5">
            {filteredItems.length === 0 ? (
              <p className="text-xs text-muted-foreground text-center py-3">Nenhum cliente neste filtro.</p>
            ) : (
              filteredItems.map(item => (
                <QueueItemRow key={item.client_id} item={item} onOpen={() => onOpenClient(item.client_id)} />
              ))
            )}
          </CardContent>
        </CollapsibleContent>
      </Card>
    </Collapsible>
  );
}

function CriticalClientsView({ data, sellerFilter, onOpenClient }: {
  data: { allItems: (PriorityQueueItem & { seller_id?: string })[]; sellers: SellerQueueSummary[] };
  sellerFilter: string | null;
  onOpenClient: (id: string) => void;
}) {
  const sellerMap = useMemo(() => {
    const map: Record<string, string> = {};
    data.sellers.forEach(s => { map[s.seller_id] = s.seller_name; });
    return map;
  }, [data.sellers]);

  const critical = useMemo(() => {
    let items = data.allItems.filter(i =>
      (i.prioridade_nivel === 'maxima' || i.prioridade_nivel === 'alta') &&
      !i.contacted_today && !i.has_pending_task
    );
    if (sellerFilter) items = items.filter(i => (i as any).seller_id === sellerFilter);
    return items;
  }, [data.allItems, sellerFilter]);

  if (critical.length === 0) {
    return (
      <Card className="border-border/40">
        <CardContent className="py-8 text-center text-sm text-muted-foreground">
          <CheckCircle className="h-6 w-6 mx-auto mb-2 text-primary" />
          Nenhum cliente crítico sem ação no momento.
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-1.5">
      <p className="text-xs text-destructive font-semibold">{critical.length} clientes críticos aguardando ação</p>
      {critical.map(item => (
        <QueueItemRow
          key={item.client_id}
          item={item}
          sellerName={sellerMap[(item as any).seller_id]}
          onOpen={() => onOpenClient(item.client_id)}
        />
      ))}
    </div>
  );
}

function QueueItemRow({ item, sellerName, onOpen }: { item: PriorityQueueItem; sellerName?: string; onOpen: () => void }) {
  const nivel = NIVEL_CONFIG[item.prioridade_nivel] || NIVEL_CONFIG.baixa;

  return (
    <div
      onClick={onOpen}
      className={cn(
        "flex items-center gap-3 p-2.5 rounded-lg border border-border/30 hover:border-border/60 cursor-pointer transition-colors group",
        item.prioridade_nivel === 'maxima' && "border-l-2 border-l-destructive",
        item.prioridade_nivel === 'alta' && "border-l-2 border-l-amber-500",
      )}
    >
      <span className={cn("w-1.5 h-1.5 rounded-full flex-shrink-0", nivel.dot)} />

      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <p className="text-[12px] font-semibold text-foreground truncate">{item.client_name}</p>
          {sellerName && <span className="text-[9px] text-muted-foreground bg-muted px-1.5 py-0.5 rounded-full flex-shrink-0">{sellerName}</span>}
          <span className={cn("text-[8px] font-bold uppercase tracking-widest px-1.5 py-0.5 rounded-full flex-shrink-0", nivel.cls)}>{nivel.label}</span>
        </div>
        <p className="text-[10px] text-muted-foreground truncate mt-0.5">{item.motivo_prioridade}</p>
      </div>

      <div className="flex items-center gap-2 flex-shrink-0">
        {/* Status badges */}
        <div className="hidden sm:flex items-center gap-1">
          {item.cliente_em_risco && <AlertTriangle className="h-3 w-3 text-destructive" />}
          {item.oportunidade_recompra && <ShoppingCart className="h-3 w-3 text-primary" />}
          {item.has_pending_task && <Clock className="h-3 w-3 text-muted-foreground" />}
          {item.contacted_today && <MessageSquare className="h-3 w-3 text-primary" />}
        </div>

        {item.dias_sem_pedido != null && (
          <span className={cn("text-[10px] font-medium tabular-nums",
            item.dias_sem_pedido > 90 ? "text-destructive" : item.dias_sem_pedido > 60 ? "text-amber-600 dark:text-amber-400" : "text-muted-foreground"
          )}>
            {item.dias_sem_pedido}d
          </span>
        )}

        <div className="flex items-center gap-1 text-[10px] text-primary font-medium">
          <TrendingUp className="h-3 w-3" />
          <span className="hidden md:inline truncate max-w-[120px]">{item.melhor_proxima_acao}</span>
        </div>

        <ExternalLink className="h-3 w-3 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
      </div>
    </div>
  );
}
