import { useMemo } from 'react';
import { Target, TrendingUp, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { cn } from '@/lib/utils';
import type { SellerROI } from '@/hooks/useGestorData';

interface BreakEvenPanelProps {
  sellers: SellerROI[];
}

function formatCurrency(value: number): string {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value);
}

interface BreakEvenData {
  sellerId: string;
  sellerName: string;
  revenue: number;
  profit: number;
  cost: number;
  marginPercent: number;
  breakEvenRevenue: number;
  profitAfterCost: number;
  marginAfterCost: number;
  progressPercent: number;
  remaining: number;
  status: 'achieved' | 'close' | 'far' | 'no-cost';
}

export function BreakEvenPanel({ sellers }: BreakEvenPanelProps) {
  const breakEvenData = useMemo<BreakEvenData[]>(() => {
    return sellers.map((seller) => {
      const marginPercent = seller.revenue > 0 ? (seller.profit / seller.revenue) * 100 : 0;
      
      // Break-even = custo / margem média
      const breakEvenRevenue = marginPercent > 0 
        ? (seller.periodCost / (marginPercent / 100))
        : 0;
      
      const profitAfterCost = seller.profit - seller.periodCost;
      const marginAfterCost = seller.revenue > 0 
        ? (profitAfterCost / seller.revenue) * 100 
        : 0;
      
      const progressPercent = breakEvenRevenue > 0 
        ? Math.min(100, (seller.revenue / breakEvenRevenue) * 100)
        : seller.periodCost > 0 ? 0 : 100;
      
      const remaining = Math.max(0, breakEvenRevenue - seller.revenue);

      let status: 'achieved' | 'close' | 'far' | 'no-cost' = 'far';
      if (seller.periodCost === 0) {
        status = 'no-cost';
      } else if (progressPercent >= 100) {
        status = 'achieved';
      } else if (progressPercent >= 70) {
        status = 'close';
      }

      return {
        sellerId: seller.id,
        sellerName: seller.name,
        revenue: seller.revenue,
        profit: seller.profit,
        cost: seller.periodCost,
        marginPercent,
        breakEvenRevenue,
        profitAfterCost,
        marginAfterCost,
        progressPercent,
        remaining,
        status,
      };
    }).filter(d => d.cost > 0); // Só mostrar quem tem custo configurado
  }, [sellers]);

  if (breakEvenData.length === 0) {
    return (
      <Card className="border-amber-500/30 bg-amber-500/5">
        <CardContent className="py-6 text-center">
          <AlertTriangle className="h-8 w-8 mx-auto text-amber-500 mb-2" />
          <p className="text-sm text-muted-foreground">
            Nenhum vendedor com custo configurado. Configure os custos para ver o break-even.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-primary/20">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-lg">
          <Target className="h-5 w-5 text-primary" />
          Break-Even & Lucro Real
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {breakEvenData.map((data) => (
            <div 
              key={data.sellerId} 
              className={cn(
                'p-4 rounded-lg border',
                data.status === 'achieved' && 'border-emerald-500/30 bg-emerald-500/5',
                data.status === 'close' && 'border-amber-500/30 bg-amber-500/5',
                data.status === 'far' && 'border-destructive/30 bg-destructive/5',
              )}
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  {data.status === 'achieved' ? (
                    <CheckCircle2 className="h-4 w-4 text-emerald-500" />
                  ) : data.status === 'close' ? (
                    <TrendingUp className="h-4 w-4 text-amber-500" />
                  ) : (
                    <AlertTriangle className="h-4 w-4 text-destructive" />
                  )}
                  <span className="font-medium">{data.sellerName}</span>
                </div>
                <div className="text-right">
                  <span className={cn(
                    'text-lg font-bold',
                    data.profitAfterCost >= 0 ? 'text-emerald-500' : 'text-destructive'
                  )}>
                    {formatCurrency(data.profitAfterCost)}
                  </span>
                  <span className="text-xs text-muted-foreground ml-1">
                    lucro real
                  </span>
                </div>
              </div>

              <Progress 
                value={data.progressPercent} 
                className={cn(
                  'h-2 mb-2',
                  data.status === 'achieved' && '[&>div]:bg-emerald-500',
                  data.status === 'close' && '[&>div]:bg-amber-500',
                  data.status === 'far' && '[&>div]:bg-destructive',
                )}
              />

              <div className="flex justify-between text-xs text-muted-foreground">
                <div className="space-x-3">
                  <span>Receita: {formatCurrency(data.revenue)}</span>
                  <span>Custo: {formatCurrency(data.cost)}</span>
                  <span>Margem: {data.marginPercent.toFixed(1)}%</span>
                </div>
                <div>
                  {data.status === 'achieved' ? (
                    <span className="text-emerald-500 font-medium">
                      ✓ Meta atingida! (+{formatCurrency(data.revenue - data.breakEvenRevenue)} excedente)
                    </span>
                  ) : (
                    <span>
                      Break-even: {formatCurrency(data.breakEvenRevenue)} 
                      <span className="text-destructive ml-1">
                        (faltam {formatCurrency(data.remaining)})
                      </span>
                    </span>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}