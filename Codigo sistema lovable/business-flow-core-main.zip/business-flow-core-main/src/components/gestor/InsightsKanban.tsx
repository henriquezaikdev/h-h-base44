import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Clock, ShoppingBag, Loader2, ChevronRight, Users, AlertCircle } from 'lucide-react';
import { motion } from 'framer-motion';
import { supabase } from '@/integrations/supabase/client';
import { differenceInDays, format } from 'date-fns';
import { cn } from '@/lib/utils';

interface ClientInsight {
  id: string;
  company_name: string;
  daysSince: number;
  seller_name: string;
}

export function InsightsKanban() {
  const [noContact15, setNoContact15] = useState<ClientInsight[]>([]);
  const [recurrentNoOrder45, setRecurrentNoOrder45] = useState<ClientInsight[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchInsights = async () => {
      setLoading(true);
      try {
        const today = new Date();
        const date15DaysAgo = format(new Date(today.getTime() - 15 * 24 * 60 * 60 * 1000), 'yyyy-MM-dd');
        const date45DaysAgo = format(new Date(today.getTime() - 45 * 24 * 60 * 60 * 1000), 'yyyy-MM-dd');

        // Clientes sem contato há mais de 15 dias
        const { data: noContact } = await supabase
          .from('clients')
          .select(`
            id,
            company_name,
            last_contact_at,
            sellers:seller_id (name)
          `)
          .eq('is_deleted', false)
          .or(`last_contact_at.is.null,last_contact_at.lt.${date15DaysAgo}`)
          .order('last_contact_at', { ascending: true, nullsFirst: true })
          .limit(10);

        // Clientes recorrentes sem pedido há mais de 45 dias
        const { data: noOrder } = await supabase
          .from('clients')
          .select(`
            id,
            company_name,
            last_order_date,
            sellers:seller_id (name)
          `)
          .eq('is_deleted', false)
          .eq('classification', 'recorrente')
          .or(`last_order_date.is.null,last_order_date.lt.${date45DaysAgo}`)
          .order('last_order_date', { ascending: true, nullsFirst: true })
          .limit(10);

        setNoContact15(
          (noContact || []).map((c: any) => ({
            id: c.id,
            company_name: c.company_name,
            daysSince: c.last_contact_at 
              ? differenceInDays(today, new Date(c.last_contact_at))
              : 999,
            seller_name: c.sellers?.name || 'Sem vendedor',
          }))
        );

        setRecurrentNoOrder45(
          (noOrder || []).map((c: any) => ({
            id: c.id,
            company_name: c.company_name,
            daysSince: c.last_order_date
              ? differenceInDays(today, new Date(c.last_order_date))
              : 999,
            seller_name: c.sellers?.name || 'Sem vendedor',
          }))
        );
      } catch (error) {
        console.error('Error fetching insights:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchInsights();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="h-6 w-6 animate-spin text-primary" />
      </div>
    );
  }

  const columns = [
    {
      title: 'Sem Contato há 15+ dias',
      icon: Clock,
      items: noContact15,
      color: 'amber',
      emptyMessage: 'Nenhum cliente nessa situação 🎉',
      dayLabel: 'dias sem contato',
    },
    {
      title: 'Recorrentes sem Pedido há 45+ dias',
      icon: ShoppingBag,
      items: recurrentNoOrder45,
      color: 'destructive',
      emptyMessage: 'Nenhum cliente nessa situação 🎉',
      dayLabel: 'dias sem pedido',
    },
  ];

  return (
    <div className="flex gap-4 overflow-x-auto pb-2 -mx-4 px-4">
      {columns.map((column, colIndex) => {
        const IconComponent = column.icon;
        const colorClasses = {
          amber: {
            header: 'bg-amber-500/10 border-amber-500/30',
            icon: 'text-amber-500',
            badge: 'bg-amber-500/10 text-amber-500',
          },
          destructive: {
            header: 'bg-destructive/10 border-destructive/30',
            icon: 'text-destructive',
            badge: 'bg-destructive/10 text-destructive',
          },
        }[column.color];

        return (
          <motion.div
            key={column.title}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: colIndex * 0.1 }}
            className="min-w-[350px] flex-1"
          >
            {/* Column Header */}
            <div className={cn(
              'flex items-center gap-2 p-3 rounded-t-xl border',
              colorClasses.header
            )}>
              <IconComponent className={cn('h-5 w-5', colorClasses.icon)} />
              <h3 className="font-semibold text-sm">{column.title}</h3>
              <span className={cn(
                'ml-auto px-2 py-0.5 rounded-full text-xs font-medium',
                colorClasses.badge
              )}>
                {column.items.length}
              </span>
            </div>

            {/* Column Cards */}
            <div className="bg-muted/20 border-x border-b rounded-b-xl p-3 space-y-2 min-h-[200px] max-h-[400px] overflow-y-auto">
              {column.items.length === 0 ? (
                <div className="text-center py-8 text-sm text-muted-foreground">
                  {column.emptyMessage}
                </div>
              ) : (
                column.items.map((item, idx) => (
                  <motion.div
                    key={item.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: colIndex * 0.1 + idx * 0.03 }}
                  >
                    <Link
                      to={`/clientes/${item.id}`}
                      className="flex items-center justify-between bg-card rounded-lg border p-3 transition-all duration-200 hover:shadow-md hover:border-primary/40 group"
                    >
                      <div className="min-w-0 flex-1">
                        <p className="font-medium text-sm truncate group-hover:text-primary transition-colors">
                          {item.company_name}
                        </p>
                        <div className="flex items-center gap-2 text-xs text-muted-foreground mt-0.5">
                          <Users className="h-3 w-3" />
                          <span>{item.seller_name}</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <span className={cn(
                          'px-2 py-1 rounded-md text-xs font-medium',
                          colorClasses.badge
                        )}>
                          {item.daysSince >= 999 ? '∞' : item.daysSince}d
                        </span>
                        <ChevronRight className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-colors" />
                      </div>
                    </Link>
                  </motion.div>
                ))
              )}
            </div>
          </motion.div>
        );
      })}
    </div>
  );
}
