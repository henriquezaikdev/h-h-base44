import { useMemo, useState } from 'react';
import { 
  Activity, 
  AlertTriangle, 
  Rocket, 
  BarChart3,
  Award,
  Settings 
} from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { cn } from '@/lib/utils';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { Layer5StrategicAnalysis, calculateLayer5Analysis } from './Layer5StrategicAnalysis';
import { Phase1CostPanel } from './Phase1CostPanel';
import { SellerResult } from '@/hooks/useGestorData';

interface GestorVendedoresTabProps {
  kpis: {
    revenue: number;
    lucroRealTotal?: number;
    marginPercent: number;
    totalCEE?: number;
    totalFase3?: number;
  };
  sellersResult: SellerResult[];
  activeSellersCount: number;
  onOpenAwardStars: () => void;
  onAnalyzeSeller: (seller: SellerResult) => void;
  onEditFase2?: () => void;
  onEditFase3?: () => void;
}

export function GestorVendedoresTab({
  kpis,
  sellersResult,
  activeSellersCount,
  onOpenAwardStars,
  onAnalyzeSeller,
  onEditFase2,
  onEditFase3,
}: GestorVendedoresTabProps) {
  const [costSheetOpen, setCostSheetOpen] = useState(false);
  const [selectedCostSeller, setSelectedCostSeller] = useState<SellerResult | null>(null);

  const formatCurrency = (value: number) => 
    new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL', minimumFractionDigits: 0 }).format(value);

  // Análise da Camada 5
  const layer5Analyses = useMemo(() => {
    if (!sellersResult.length) return [];
    return calculateLayer5Analysis(sellersResult);
  }, [sellersResult]);

  // Alertas inteligentes derivados das fases
  const alerts = useMemo(() => {
    const alertList: { type: 'critical' | 'warning' | 'info'; message: string; count?: number }[] = [];
    
    if (!sellersResult.length) return alertList;
    
    const naoSePagam = sellersResult.filter(s => !s.sePaga).length;
    if (naoSePagam > 0) {
      alertList.push({
        type: 'critical',
        message: `${naoSePagam} vendedor${naoSePagam > 1 ? 'es' : ''} não cobre${naoSePagam > 1 ? 'm' : ''} o próprio custo`,
        count: naoSePagam
      });
    }
    
    const naoSustentam = sellersResult.filter(s => s.sePaga && !s.sustentaEmpresa).length;
    if (naoSustentam > 0) {
      alertList.push({
        type: 'warning',
        message: `${naoSustentam} vendedor${naoSustentam > 1 ? 'es' : ''} não sustenta${naoSustentam > 1 ? 'm' : ''} a estrutura`,
        count: naoSustentam
      });
    }
    
    const riscoLayer5 = layer5Analyses.filter(a => a.decisaoGerencial === 'risco').length;
    if (riscoLayer5 > 0) {
      alertList.push({
        type: 'critical',
        message: `${riscoLayer5} vendedor${riscoLayer5 > 1 ? 'es' : ''} em situação de RISCO`,
        count: riscoLayer5
      });
    }
    
    const semCustoConfig = sellersResult.filter(s => !s.hasCostConfig).length;
    if (semCustoConfig > 0) {
      alertList.push({
        type: 'info',
        message: `${semCustoConfig} vendedor${semCustoConfig > 1 ? 'es' : ''} sem custo configurado`,
        count: semCustoConfig
      });
    }
    
    return alertList;
  }, [sellersResult, layer5Analyses]);

  // Resumo de decisões da Camada 5
  const decisaoSummary = useMemo(() => {
    const escalar = layer5Analyses.filter(a => a.decisaoGerencial === 'escalar').length;
    const ajustarProcesso = layer5Analyses.filter(a => a.decisaoGerencial === 'ajustar_processo').length;
    const ajustarMargem = layer5Analyses.filter(a => a.decisaoGerencial === 'ajustar_margem').length;
    const risco = layer5Analyses.filter(a => a.decisaoGerencial === 'risco').length;
    return { escalar, ajustarProcesso, ajustarMargem, risco };
  }, [layer5Analyses]);

  return (
    <div className="space-y-6">
      {/* 1) PAINEL DE SAÚDE DO NEGÓCIO */}
      <section>
        <div className="flex items-center gap-2 mb-4">
          <Activity className="h-5 w-5 text-primary" />
          <h2 className="text-lg font-semibold">Saúde do Negócio</h2>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          {/* Receita */}
          <Card className="border-primary/30">
            <CardContent className="pt-4">
              <p className="text-xs text-muted-foreground uppercase tracking-wide">Receita</p>
              <p className="text-2xl font-bold">{formatCurrency(kpis.revenue)}</p>
            </CardContent>
          </Card>
          
          {/* Resultado Real */}
          <Card className={cn(
            'border-2',
            (kpis.lucroRealTotal || 0) >= 0 
              ? 'border-emerald-500/50 bg-emerald-500/10 dark:border-emerald-400/30 dark:bg-emerald-400/5' 
              : 'border-destructive/50 bg-destructive/10 dark:border-destructive/30 dark:bg-destructive/5'
          )}>
            <CardContent className="pt-4">
              <p className="text-xs text-muted-foreground uppercase tracking-wide">Resultado Real</p>
              <p className={cn(
                'text-2xl font-bold',
                (kpis.lucroRealTotal || 0) >= 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-destructive'
              )}>
                {formatCurrency(kpis.lucroRealTotal || 0)}
              </p>
            </CardContent>
          </Card>
          
          {/* Margem Média */}
          <Card>
            <CardContent className="pt-4">
              <p className="text-xs text-muted-foreground uppercase tracking-wide">Margem Média</p>
              <p className="text-2xl font-bold">{kpis.marginPercent.toFixed(1)}%</p>
            </CardContent>
          </Card>
          
          {/* Custos por Fase */}
          <Card className="border-purple-500/30 bg-purple-500/5 dark:border-purple-400/20 dark:bg-purple-400/5 col-span-2 md:col-span-1">
            <CardContent className="pt-4 space-y-2">
              <p className="text-xs text-purple-700 dark:text-purple-400 uppercase tracking-wide font-semibold">Custos por Fase</p>
              
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">Fase 2 (CEE)</span>
                <div className="flex items-center gap-1.5">
                  <span className="text-sm font-semibold">{formatCurrency(kpis.totalCEE || 0)}</span>
                  {onEditFase2 && (
                    <button onClick={onEditFase2} className="text-muted-foreground hover:text-foreground transition-colors">
                      <Settings className="h-3.5 w-3.5" />
                    </button>
                  )}
                </div>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">Fase 3 (Final)</span>
                <div className="flex items-center gap-1.5">
                  <span className="text-sm font-semibold">{formatCurrency(kpis.totalFase3 || 0)}</span>
                  {onEditFase3 && (
                    <button onClick={onEditFase3} className="text-muted-foreground hover:text-foreground transition-colors">
                      <Settings className="h-3.5 w-3.5" />
                    </button>
                  )}
                </div>
              </div>
              
              <div className="border-t border-border/50 pt-1.5 flex items-center justify-between">
                <span className="text-xs font-medium text-purple-700 dark:text-purple-400">Total</span>
                <span className="text-base font-bold text-purple-600 dark:text-purple-400">
                  {formatCurrency((kpis.totalCEE || 0) + (kpis.totalFase3 || 0))}
                </span>
              </div>
            </CardContent>
          </Card>
          
          {/* Status Vendedores */}
          <Card>
            <CardContent className="pt-4">
              <p className="text-xs text-muted-foreground uppercase tracking-wide">Vendedores</p>
              <div className="flex items-center gap-2 mt-1">
                <span className="text-2xl font-bold">{activeSellersCount}</span>
                <div className="flex gap-1 text-xs">
                  <Badge variant="outline" className="border-emerald-500/50 text-emerald-700 dark:text-emerald-400">
                    {sellersResult.filter(s => s.sustentaEmpresa).length} ok
                  </Badge>
                  <Badge variant="outline" className="border-destructive/50 text-destructive">
                    {sellersResult.filter(s => !s.sePaga).length} ⚠
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* ALERTAS INTELIGENTES */}
      {alerts.length > 0 && (
        <section>
          <div className="flex items-center gap-2 mb-3">
            <AlertTriangle className="h-5 w-5 text-amber-500" />
            <h2 className="text-lg font-semibold">Alertas Inteligentes</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
            {alerts.map((alert, idx) => (
              <Card 
                key={idx} 
                className={cn(
                  'border-l-4',
                  alert.type === 'critical' && 'border-l-destructive bg-destructive/10 dark:bg-destructive/5',
                  alert.type === 'warning' && 'border-l-amber-500 bg-amber-500/10 dark:bg-amber-500/5',
                  alert.type === 'info' && 'border-l-blue-500 bg-blue-500/10 dark:bg-blue-500/5'
                )}
              >
                <CardContent className="py-3 flex items-center gap-3">
                  <AlertTriangle className={cn(
                    'h-4 w-4 shrink-0',
                    alert.type === 'critical' && 'text-destructive',
                    alert.type === 'warning' && 'text-amber-500',
                    alert.type === 'info' && 'text-blue-500'
                  )} />
                  <span className="text-sm">{alert.message}</span>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>
      )}

      {/* DECISÃO GERENCIAL - CAMADA 5 */}
      <section>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Rocket className="h-5 w-5 text-primary" />
            <h2 className="text-lg font-semibold">Decisão Gerencial (Camada 5)</h2>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <Badge variant="outline" className="border-emerald-500/50 text-emerald-700 dark:text-emerald-400">
              {decisaoSummary.escalar} Escalar
            </Badge>
            <Badge variant="outline" className="border-amber-500/50 text-amber-700 dark:text-amber-400">
              {decisaoSummary.ajustarProcesso} Ajustar Proc.
            </Badge>
            <Badge variant="outline" className="border-orange-500/50 text-orange-700 dark:text-orange-400">
              {decisaoSummary.ajustarMargem} Ajustar Margem
            </Badge>
            <Badge variant="outline" className="border-destructive/50 text-destructive">
              {decisaoSummary.risco} Risco
            </Badge>
          </div>
        </div>
        <Layer5StrategicAnalysis 
          sellers={sellersResult} 
          onAnalyzeSeller={onAnalyzeSeller}
        />
      </section>

      {/* RESULTADO REAL POR VENDEDOR - Tabela */}
      <section>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5 text-primary" />
            <h2 className="text-lg font-semibold">Resultado Real por Vendedor</h2>
          </div>
          <Button 
            variant="outline" 
            size="sm"
            onClick={onOpenAwardStars}
            className="gap-2"
          >
            <Award className="h-4 w-4" />
            Atribuir Estrelas
          </Button>
        </div>
        
        <p className="text-xs text-muted-foreground mb-3">
          Esta tabela mostra quanto cada vendedor vendeu, quanto custou para a empresa e se ele sustenta ou não a operação.
        </p>
        <Card>
          <ScrollArea className="h-[400px]">
            <Table>
              <TableHeader className="sticky top-0 bg-background">
                <TableRow>
                  <TableHead className="w-8">#</TableHead>
                  <TableHead>Vendedor</TableHead>
                  <TableHead className="text-right">Faturamento</TableHead>
                  <TableHead className="text-right">Margem Bruta</TableHead>
                  <TableHead className="text-right">
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger className="flex items-center justify-end gap-1">
                          CDV
                          <AlertTriangle className="h-3 w-3 text-amber-500" />
                        </TooltipTrigger>
                        <TooltipContent className="max-w-xs">
                          <p className="font-semibold">Custo Direto Variável</p>
                          <p className="text-xs text-muted-foreground">Parte variável da venda, principalmente comissão.</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </TableHead>
                  <TableHead className="text-right">
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger className="flex items-center justify-end gap-1">
                          Res. Direto
                        </TooltipTrigger>
                        <TooltipContent className="max-w-xs">
                          <p className="font-semibold">Resultado Direto</p>
                          <p className="text-xs text-muted-foreground">O que sobra da margem depois de tirar os custos variáveis da venda.</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </TableHead>
                  <TableHead className="text-right">
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger className="flex items-center justify-end gap-1">
                          Custo Humano
                        </TooltipTrigger>
                        <TooltipContent className="max-w-xs">
                          <p className="font-semibold">Custo Humano (Fixo)</p>
                          <p className="text-xs text-muted-foreground">Custo do vendedor com salário, encargos, benefícios e itens individuais.</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </TableHead>
                  <TableHead className="text-right">
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger className="flex items-center justify-end gap-1">
                          CEE Rateio
                        </TooltipTrigger>
                        <TooltipContent className="max-w-xs">
                          <p className="font-semibold">Custo Estrutural da Empresa</p>
                          <p className="text-xs text-muted-foreground">Parte da estrutura fixa da empresa distribuída para este vendedor conforme a participação dele.</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </TableHead>
                  <TableHead className="text-right">
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger className="flex items-center justify-end gap-1">
                          Resultado Real
                        </TooltipTrigger>
                        <TooltipContent className="max-w-xs">
                          <p className="font-semibold">Resultado Real</p>
                          <p className="text-xs text-muted-foreground">O que sobra ou falta depois de descontar custos variáveis, custo humano e estrutura rateada.</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </TableHead>
                  <TableHead className="text-center">Status</TableHead>
                  <TableHead className="text-center w-12">Custos</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {sellersResult.map((seller, index) => (
                  <TableRow key={seller.id} className="hover:bg-muted/50">
                    <TableCell className="font-medium text-muted-foreground">
                      {index + 1}
                    </TableCell>
                    <TableCell className="font-medium">
                      <div className="flex items-center gap-2">
                        {seller.name}
                        {seller.statusFinanceiro === 'divergente' && (
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger>
                                <AlertTriangle className="h-4 w-4 text-amber-500" />
                              </TooltipTrigger>
                              <TooltipContent>
                                <p>Dados divergentes - verifique margem</p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        )}
                      </div>
                    </TableCell>
                    <TableCell className="text-right">{formatCurrency(seller.revenue)}</TableCell>
                    <TableCell className="text-right">{formatCurrency(seller.marginBruta)}</TableCell>
                    <TableCell className="text-right text-amber-600 dark:text-amber-400">{formatCurrency(seller.cdv)}</TableCell>
                    <TableCell className={cn(
                      'text-right font-medium',
                      seller.resultadoDireto >= 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-destructive'
                    )}>
                      {formatCurrency(seller.resultadoDireto)}
                    </TableCell>
                    <TableCell className="text-right text-purple-600 dark:text-purple-400">{formatCurrency(seller.custoHumano)}</TableCell>
                    <TableCell className="text-right text-blue-600 dark:text-blue-400">{formatCurrency(seller.ceeRateio)}</TableCell>
                    <TableCell className={cn(
                      'text-right font-semibold',
                      seller.resultadoReal >= 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-destructive'
                    )}>
                      {formatCurrency(seller.resultadoReal)}
                    </TableCell>
                    <TableCell className="text-center">
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger>
                            {seller.statusFinanceiro === 'gera_lucro' ? (
                              <Badge className="bg-emerald-500 text-white">Gera Lucro</Badge>
                            ) : seller.statusFinanceiro === 'sustenta' ? (
                              <Badge className="bg-blue-500 text-white">Sustenta</Badge>
                            ) : seller.statusFinanceiro === 'se_paga' ? (
                              <Badge className="bg-amber-500 text-white">Se Paga</Badge>
                            ) : seller.statusFinanceiro === 'divergente' ? (
                              <Badge className="bg-gray-500 text-white">Divergente</Badge>
                            ) : (
                              <Badge className="bg-destructive text-destructive-foreground">Não Se Paga</Badge>
                            )}
                          </TooltipTrigger>
                          <TooltipContent side="left">
                            <p className="font-semibold">{seller.statusLabel}</p>
                            {seller.statusFinanceiro === 'gera_lucro' && (
                              <p className="text-xs">Resultado Real &gt; 0 com folga</p>
                            )}
                            {seller.statusFinanceiro === 'sustenta' && (
                              <p className="text-xs">Resultado Real ≥ 0</p>
                            )}
                            {seller.statusFinanceiro === 'se_paga' && (
                              <p className="text-xs">Resultado Direto ≥ Custo Humano</p>
                            )}
                            {seller.statusFinanceiro === 'nao_se_paga' && (
                              <p className="text-xs">Resultado Direto &lt; Custo Humano</p>
                            )}
                            {seller.statusFinanceiro === 'divergente' && (
                              <p className="text-xs">Divergência &gt;5% na margem - verifique dados</p>
                            )}
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </TableCell>
                    <TableCell className="text-center">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-7 w-7"
                        onClick={() => {
                          setSelectedCostSeller(seller);
                          setCostSheetOpen(true);
                        }}
                      >
                        <Settings className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </ScrollArea>
        </Card>
      </section>

      {/* Sheet de Custos do Vendedor */}
      <Sheet open={costSheetOpen} onOpenChange={setCostSheetOpen}>
        <SheetContent side="right" className="w-full sm:max-w-2xl overflow-y-auto">
          <SheetHeader>
            <SheetTitle>Custos – {selectedCostSeller?.name}</SheetTitle>
          </SheetHeader>
          {selectedCostSeller && (
            <div className="mt-4">
              <Phase1CostPanel
                sellerId={selectedCostSeller.id}
                sellerName={selectedCostSeller.name}
                sellerRevenue={selectedCostSeller.revenue}
                marginBruta={selectedCostSeller.marginBruta}
                comissaoReal={selectedCostSeller.cdv}
                comissaoPercentual={selectedCostSeller.revenue > 0 ? (selectedCostSeller.cdv / selectedCostSeller.revenue) * 100 : 0}
                onCostCalculated={() => {}}
              />
            </div>
          )}
        </SheetContent>
      </Sheet>
    </div>
  );
}
