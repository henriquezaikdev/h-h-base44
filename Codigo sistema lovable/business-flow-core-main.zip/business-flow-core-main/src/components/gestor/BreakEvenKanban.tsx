import { useMemo } from 'react';
import { Target, TrendingUp, AlertTriangle, CheckCircle2, ArrowRight } from 'lucide-react';
import { motion } from 'framer-motion';
import { Progress } from '@/components/ui/progress';
import { cn } from '@/lib/utils';
import type { SellerROI } from '@/hooks/useGestorData';

interface BreakEvenKanbanProps {
  sellers: SellerROI[];
}

function formatCurrency(value: number): string {
  if (value >= 1000000) {
    return `R$ ${(value / 1000000).toFixed(1)}M`;
  }
  if (value >= 1000) {
    return `R$ ${(value / 1000).toFixed(0)}K`;
  }
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value);
}

interface BreakEvenData {
  sellerId: string;
  sellerName: string;
  revenue: number;
  profit: number;
  cost: number;
  marginPercent: number;
  breakEvenRevenue: number;
  profitAfterCost: number;
  progressPercent: number;
  remaining: number;
  status: 'achieved' | 'close' | 'far';
}

export function BreakEvenKanban({ sellers }: BreakEvenKanbanProps) {
  const breakEvenData = useMemo<BreakEvenData[]>(() => {
    return sellers
      .filter(seller => seller.periodCost > 0)
      .map((seller) => {
        const marginPercent = seller.revenue > 0 ? (seller.profit / seller.revenue) * 100 : 0;
        const breakEvenRevenue = marginPercent > 0 
          ? (seller.periodCost / (marginPercent / 100))
          : 0;
        
        const profitAfterCost = seller.profit - seller.periodCost;
        const progressPercent = breakEvenRevenue > 0 
          ? Math.min(100, (seller.revenue / breakEvenRevenue) * 100)
          : 0;
        
        const remaining = Math.max(0, breakEvenRevenue - seller.revenue);

        let status: 'achieved' | 'close' | 'far' = 'far';
        if (progressPercent >= 100) {
          status = 'achieved';
        } else if (progressPercent >= 70) {
          status = 'close';
        }

        return {
          sellerId: seller.id,
          sellerName: seller.name,
          revenue: seller.revenue,
          profit: seller.profit,
          cost: seller.periodCost,
          marginPercent,
          breakEvenRevenue,
          profitAfterCost,
          progressPercent,
          remaining,
          status,
        };
      });
  }, [sellers]);

  const achieved = breakEvenData.filter(d => d.status === 'achieved');
  const close = breakEvenData.filter(d => d.status === 'close');
  const far = breakEvenData.filter(d => d.status === 'far');

  if (breakEvenData.length === 0) {
    return (
      <div className="rounded-xl border border-dashed border-amber-500/30 bg-amber-500/5 p-8 text-center">
        <AlertTriangle className="h-10 w-10 mx-auto text-amber-500 mb-3" />
        <p className="text-sm text-muted-foreground">
          Nenhum vendedor com custo configurado. Configure os custos para ver o break-even.
        </p>
      </div>
    );
  }

  const columns = [
    {
      title: 'Meta Atingida',
      icon: CheckCircle2,
      items: achieved,
      color: 'emerald',
      emptyMessage: 'Ninguém ainda',
    },
    {
      title: 'Próximo do Break-Even',
      icon: TrendingUp,
      items: close,
      color: 'amber',
      emptyMessage: 'Ninguém nessa faixa',
    },
    {
      title: 'Precisa Melhorar',
      icon: AlertTriangle,
      items: far,
      color: 'destructive',
      emptyMessage: 'Ninguém nessa faixa',
    },
  ];

  return (
    <div className="flex gap-4 overflow-x-auto pb-2 -mx-4 px-4">
      {columns.map((column, colIndex) => {
        const IconComponent = column.icon;
        const colorClasses = {
          emerald: {
            header: 'bg-emerald-500/10 border-emerald-500/30',
            icon: 'text-emerald-500',
            card: 'border-emerald-500/20 hover:border-emerald-500/40',
            progress: '[&>div]:bg-emerald-500',
          },
          amber: {
            header: 'bg-amber-500/10 border-amber-500/30',
            icon: 'text-amber-500',
            card: 'border-amber-500/20 hover:border-amber-500/40',
            progress: '[&>div]:bg-amber-500',
          },
          destructive: {
            header: 'bg-destructive/10 border-destructive/30',
            icon: 'text-destructive',
            card: 'border-destructive/20 hover:border-destructive/40',
            progress: '[&>div]:bg-destructive',
          },
        }[column.color];

        return (
          <motion.div
            key={column.title}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: colIndex * 0.1 }}
            className="min-w-[300px] flex-1"
          >
            {/* Column Header */}
            <div className={cn(
              'flex items-center gap-2 p-3 rounded-t-xl border',
              colorClasses.header
            )}>
              <IconComponent className={cn('h-5 w-5', colorClasses.icon)} />
              <h3 className="font-semibold">{column.title}</h3>
              <span className="ml-auto text-sm text-muted-foreground">
                {column.items.length}
              </span>
            </div>

            {/* Column Cards */}
            <div className="bg-muted/20 border-x border-b rounded-b-xl p-3 space-y-3 min-h-[200px]">
              {column.items.length === 0 ? (
                <div className="text-center py-8 text-sm text-muted-foreground">
                  {column.emptyMessage}
                </div>
              ) : (
                column.items.map((data, idx) => (
                  <motion.div
                    key={data.sellerId}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: colIndex * 0.1 + idx * 0.05 }}
                    className={cn(
                      'bg-card rounded-lg border p-3 transition-all duration-200 hover:shadow-md',
                      colorClasses.card
                    )}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium text-sm">{data.sellerName}</span>
                      <span className={cn(
                        'text-sm font-bold',
                        data.profitAfterCost >= 0 ? 'text-emerald-500' : 'text-destructive'
                      )}>
                        {formatCurrency(data.profitAfterCost)}
                      </span>
                    </div>

                    <Progress 
                      value={data.progressPercent} 
                      className={cn('h-2 mb-2', colorClasses.progress)}
                    />

                    <div className="flex justify-between text-xs text-muted-foreground">
                      <span>{formatCurrency(data.revenue)}</span>
                      <span className="flex items-center gap-1">
                        <ArrowRight className="h-3 w-3" />
                        {formatCurrency(data.breakEvenRevenue)}
                      </span>
                    </div>

                    {data.status === 'achieved' && (
                      <div className="mt-2 text-xs text-emerald-500 font-medium">
                        +{formatCurrency(data.revenue - data.breakEvenRevenue)} excedente
                      </div>
                    )}
                    {data.status !== 'achieved' && data.remaining > 0 && (
                      <div className="mt-2 text-xs text-muted-foreground">
                        Faltam {formatCurrency(data.remaining)}
                      </div>
                    )}
                  </motion.div>
                ))
              )}
            </div>
          </motion.div>
        );
      })}
    </div>
  );
}
