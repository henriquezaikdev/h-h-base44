import { useState } from 'react';
import {
  AlertTriangle,
  Shield,
  FileText,
  Users,
  Plus,
  ChevronDown,
  ChevronUp,
  Calendar,
  CheckCircle2,
  XCircle,
  Target,
  MessageSquare,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Progress } from '@/components/ui/progress';
import { cn } from '@/lib/utils';
import { useHRActions, usePDIRecommendations } from '@/hooks/useHRActions';
import { toast } from '@/hooks/use-toast';
import { format } from 'date-fns';

interface Seller {
  id: string;
  name: string;
}

interface GestorHRTabProps {
  sellers: Seller[];
}

export function GestorHRTab({ sellers }: GestorHRTabProps) {
  const { actions, createAdvertencia, createPDI, createOneOnOne, cancelAction, loading } = useHRActions();
  const { recommendations } = usePDIRecommendations();
  const [showAdvModal, setShowAdvModal] = useState(false);
  const [showPdiModal, setShowPdiModal] = useState(false);
  const [showOneOnOneModal, setShowOneOnOneModal] = useState(false);
  const [expandedAction, setExpandedAction] = useState<string | null>(null);
  const [cancelId, setCancelId] = useState<string | null>(null);
  const [cancelReason, setCancelReason] = useState('');

  // Advertência form
  const [advForm, setAdvForm] = useState({
    targetUserId: '',
    severity: 'MEDIA',
    title: '',
    summary: '',
    details: '',
    correctiveAction: '',
    correctionDeadline: '',
  });

  // PDI form
  const [pdiForm, setPdiForm] = useState({
    targetUserId: '',
    title: '',
    summary: '',
    items: [
      { area: 'Pontualidade', goalText: '', metricType: '%NO_PRAZO', targetValue: 85, deadlineDate: '' },
      { area: 'Disciplina', goalText: '', metricType: 'ZERO_CRITICAS', targetValue: 0, deadlineDate: '' },
    ],
  });

  // 1:1 form
  const [ooForm, setOoForm] = useState({
    targetUserId: '',
    title: '',
    summary: '',
    meetingDate: '',
    items: [{ topic: '', decision: '', nextStep: '', ownerUserId: '', dueDate: '' }],
  });

  const handleCreateAdv = async () => {
    try {
      await createAdvertencia({
        ...advForm,
        evidencePayload: { SCORE_SNAPSHOT: { captured_at: new Date().toISOString() } },
      });
      toast({ title: 'Advertência registrada', description: 'O colaborador será notificado.' });
      setShowAdvModal(false);
      setAdvForm({ targetUserId: '', severity: 'MEDIA', title: '', summary: '', details: '', correctiveAction: '', correctionDeadline: '' });
    } catch (err: any) {
      toast({ title: 'Erro', description: err.message, variant: 'destructive' });
    }
  };

  const handleCreatePDI = async () => {
    try {
      await createPDI({
        targetUserId: pdiForm.targetUserId,
        title: pdiForm.title,
        summary: pdiForm.summary,
        items: pdiForm.items.map(i => ({
          area: i.area,
          goalText: i.goalText,
          metricType: i.metricType,
          targetValue: i.targetValue,
          deadlineDate: i.deadlineDate,
        })),
      });
      toast({ title: 'PDI criado', description: 'Plano de desenvolvimento registrado.' });
      setShowPdiModal(false);
    } catch (err: any) {
      toast({ title: 'Erro', description: err.message, variant: 'destructive' });
    }
  };

  const handleCreateOneOnOne = async () => {
    try {
      await createOneOnOne({
        targetUserId: ooForm.targetUserId,
        title: ooForm.title,
        summary: ooForm.summary,
        meetingDate: ooForm.meetingDate,
        items: ooForm.items.filter(i => i.topic).map(i => ({
          topic: i.topic,
          decision: i.decision,
          nextStep: i.nextStep,
          ownerUserId: i.ownerUserId || undefined,
          dueDate: i.dueDate || undefined,
        })),
      });
      toast({ title: '1:1 registrado', description: 'Próximos passos criados como tarefas.' });
      setShowOneOnOneModal(false);
    } catch (err: any) {
      toast({ title: 'Erro', description: err.message, variant: 'destructive' });
    }
  };

  const handleCancel = async () => {
    if (!cancelId || !cancelReason) return;
    await cancelAction(cancelId, cancelReason);
    toast({ title: 'Ação cancelada' });
    setCancelId(null);
    setCancelReason('');
  };

  const getSellerName = (id: string) => sellers.find(s => s.id === id)?.name || 'Desconhecido';
  const getTypeIcon = (type: string) => {
    if (type === 'ADVERTENCIA') return <AlertTriangle className="h-4 w-4 text-destructive" />;
    if (type === 'PDI') return <Target className="h-4 w-4 text-amber-500" />;
    return <MessageSquare className="h-4 w-4 text-blue-500" />;
  };
  const getStatusBadge = (status: string) => {
    const map: Record<string, { label: string; variant: 'default' | 'secondary' | 'destructive' | 'outline' }> = {
      ATIVA: { label: 'Ativa', variant: 'destructive' },
      CONCLUIDA: { label: 'Concluída', variant: 'secondary' },
      CANCELADA: { label: 'Cancelada', variant: 'outline' },
      RASCUNHO: { label: 'Rascunho', variant: 'outline' },
    };
    const cfg = map[status] || { label: status, variant: 'outline' as const };
    return <Badge variant={cfg.variant}>{cfg.label}</Badge>;
  };

  const activeActions = actions.filter(a => a.status === 'ATIVA');
  const historyActions = actions.filter(a => a.status !== 'ATIVA');

  return (
    <div className="space-y-6">
      {/* ACTION BUTTONS */}
      <div className="flex items-center gap-3 flex-wrap">
        <Button onClick={() => setShowAdvModal(true)} variant="destructive" size="sm" className="gap-2">
          <AlertTriangle className="h-4 w-4" /> Registrar Advertência
        </Button>
        <Button onClick={() => setShowPdiModal(true)} variant="outline" size="sm" className="gap-2">
          <Target className="h-4 w-4" /> Abrir PDI
        </Button>
        <Button onClick={() => setShowOneOnOneModal(true)} variant="outline" size="sm" className="gap-2">
          <MessageSquare className="h-4 w-4" /> Registrar 1:1
        </Button>
      </div>

      {/* PDI RECOMMENDATIONS */}
      {recommendations.length > 0 && (
        <Card className="border-amber-500/50 bg-amber-500/5">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <Shield className="h-4 w-4 text-amber-500" />
              Recomendações de PDI
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {recommendations.map(rec => (
              <div key={rec.sellerId} className="flex items-center justify-between p-2 rounded-lg bg-background border">
                <div>
                  <span className="font-medium text-sm">{rec.sellerName}</span>
                  <span className="text-xs text-muted-foreground ml-2">— {rec.reason}</span>
                </div>
                <Button
                  size="sm"
                  variant="outline"
                  className="gap-1 text-xs"
                  onClick={() => {
                    setPdiForm(prev => ({
                      ...prev,
                      targetUserId: rec.sellerId,
                      title: `PDI - ${rec.sellerName}`,
                      summary: `Abertura baseada em: ${rec.reason}`,
                    }));
                    setShowPdiModal(true);
                  }}
                >
                  <Plus className="h-3 w-3" /> Abrir PDI
                </Button>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* ACTIVE ACTIONS */}
      <section>
        <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
          <FileText className="h-4 w-4" />
          Ações Ativas ({activeActions.length})
        </h3>
        {activeActions.length === 0 ? (
          <Card><CardContent className="py-6 text-center text-sm text-muted-foreground">Nenhuma ação de RH ativa.</CardContent></Card>
        ) : (
          <div className="space-y-2">
            {activeActions.map(action => (
              <Card key={action.id} className="border-l-4 border-l-destructive/50">
                <CardContent className="py-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {getTypeIcon(action.type)}
                      <span className="font-medium text-sm">{action.title}</span>
                      {action.severity && (
                        <Badge variant="outline" className={cn(
                          action.severity === 'GRAVE' && 'border-destructive text-destructive',
                          action.severity === 'MEDIA' && 'border-amber-500 text-amber-600',
                          action.severity === 'LEVE' && 'border-blue-500 text-blue-600',
                        )}>
                          {action.severity}
                        </Badge>
                      )}
                      {getStatusBadge(action.status)}
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-muted-foreground">{getSellerName(action.target_user_id)}</span>
                      <Button variant="ghost" size="sm" onClick={() => setExpandedAction(expandedAction === action.id ? null : action.id)}>
                        {expandedAction === action.id ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                      </Button>
                      <Button variant="ghost" size="sm" onClick={() => setCancelId(action.id)}>
                        <XCircle className="h-4 w-4 text-muted-foreground" />
                      </Button>
                    </div>
                  </div>
                  {expandedAction === action.id && (
                    <div className="mt-3 pt-3 border-t space-y-2 text-sm">
                      {action.summary && <p><strong>Resumo:</strong> {action.summary}</p>}
                      {action.details && <p><strong>Detalhes:</strong> {action.details}</p>}
                      {action.corrective_action && <p><strong>Ação corretiva:</strong> {action.corrective_action}</p>}
                      {action.correction_deadline && <p><strong>Prazo:</strong> {format(new Date(action.correction_deadline), 'dd/MM/yyyy')}</p>}
                      <p className="text-xs text-muted-foreground">Criado por {getSellerName(action.created_by_user_id)} em {format(new Date(action.created_at), 'dd/MM/yyyy HH:mm')}</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </section>

      {/* HISTORY */}
      {historyActions.length > 0 && (
        <section>
          <h3 className="text-sm font-semibold mb-3 text-muted-foreground">Histórico ({historyActions.length})</h3>
          <div className="space-y-1">
            {historyActions.slice(0, 10).map(action => (
              <div key={action.id} className="flex items-center justify-between py-2 px-3 rounded bg-muted/30 text-sm">
                <div className="flex items-center gap-2">
                  {getTypeIcon(action.type)}
                  <span>{action.title}</span>
                  <span className="text-xs text-muted-foreground">— {getSellerName(action.target_user_id)}</span>
                </div>
                {getStatusBadge(action.status)}
              </div>
            ))}
          </div>
        </section>
      )}

      {/* ADVERTÊNCIA MODAL */}
      <Dialog open={showAdvModal} onOpenChange={setShowAdvModal}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-destructive" /> Registrar Advertência
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Colaborador</Label>
              <Select value={advForm.targetUserId} onValueChange={v => setAdvForm(p => ({ ...p, targetUserId: v }))}>
                <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
                <SelectContent>{sellers.map(s => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div>
              <Label>Gravidade</Label>
              <Select value={advForm.severity} onValueChange={v => setAdvForm(p => ({ ...p, severity: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="LEVE">Leve</SelectItem>
                  <SelectItem value="MEDIA">Média</SelectItem>
                  <SelectItem value="GRAVE">Grave</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Título</Label>
              <Input value={advForm.title} onChange={e => setAdvForm(p => ({ ...p, title: e.target.value }))} placeholder="Ex: Atrasos recorrentes" />
            </div>
            <div>
              <Label>Resumo</Label>
              <Textarea value={advForm.summary} onChange={e => setAdvForm(p => ({ ...p, summary: e.target.value }))} rows={2} placeholder="Breve descrição" />
            </div>
            <div>
              <Label>Detalhes</Label>
              <Textarea value={advForm.details} onChange={e => setAdvForm(p => ({ ...p, details: e.target.value }))} rows={3} placeholder="Descrição completa" />
            </div>
            <div>
              <Label>Ação corretiva esperada</Label>
              <Textarea value={advForm.correctiveAction} onChange={e => setAdvForm(p => ({ ...p, correctiveAction: e.target.value }))} rows={2} />
            </div>
            <div>
              <Label>Prazo para correção</Label>
              <Input type="date" value={advForm.correctionDeadline} onChange={e => setAdvForm(p => ({ ...p, correctionDeadline: e.target.value }))} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAdvModal(false)}>Cancelar</Button>
            <Button variant="destructive" onClick={handleCreateAdv} disabled={!advForm.targetUserId || !advForm.title}>Registrar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* PDI MODAL */}
      <Dialog open={showPdiModal} onOpenChange={setShowPdiModal}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Target className="h-5 w-5 text-amber-500" /> Abrir PDI
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Colaborador</Label>
              <Select value={pdiForm.targetUserId} onValueChange={v => setPdiForm(p => ({ ...p, targetUserId: v }))}>
                <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
                <SelectContent>{sellers.map(s => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div>
              <Label>Título</Label>
              <Input value={pdiForm.title} onChange={e => setPdiForm(p => ({ ...p, title: e.target.value }))} />
            </div>
            <div>
              <Label>Resumo</Label>
              <Textarea value={pdiForm.summary} onChange={e => setPdiForm(p => ({ ...p, summary: e.target.value }))} rows={2} />
            </div>
            <Separator />
            <h4 className="text-sm font-semibold">Itens do PDI</h4>
            {pdiForm.items.map((item, idx) => (
              <Card key={idx} className="p-3">
                <div className="space-y-2">
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <Label className="text-xs">Área</Label>
                      <Input value={item.area} onChange={e => {
                        const items = [...pdiForm.items];
                        items[idx].area = e.target.value;
                        setPdiForm(p => ({ ...p, items }));
                      }} />
                    </div>
                    <div>
                      <Label className="text-xs">Prazo</Label>
                      <Input type="date" value={item.deadlineDate} onChange={e => {
                        const items = [...pdiForm.items];
                        items[idx].deadlineDate = e.target.value;
                        setPdiForm(p => ({ ...p, items }));
                      }} />
                    </div>
                  </div>
                  <div>
                    <Label className="text-xs">Meta</Label>
                    <Input value={item.goalText} onChange={e => {
                      const items = [...pdiForm.items];
                      items[idx].goalText = e.target.value;
                      setPdiForm(p => ({ ...p, items }));
                    }} placeholder="Ex: Subir % no prazo para 85%" />
                  </div>
                </div>
              </Card>
            ))}
            <Button variant="outline" size="sm" onClick={() => setPdiForm(p => ({
              ...p,
              items: [...p.items, { area: '', goalText: '', metricType: '', targetValue: 0, deadlineDate: '' }],
            }))}>
              <Plus className="h-3 w-3 mr-1" /> Adicionar item
            </Button>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowPdiModal(false)}>Cancelar</Button>
            <Button onClick={handleCreatePDI} disabled={!pdiForm.targetUserId || !pdiForm.title}>Criar PDI</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 1:1 MODAL */}
      <Dialog open={showOneOnOneModal} onOpenChange={setShowOneOnOneModal}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <MessageSquare className="h-5 w-5 text-blue-500" /> Registrar 1:1
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Colaborador</Label>
              <Select value={ooForm.targetUserId} onValueChange={v => setOoForm(p => ({ ...p, targetUserId: v }))}>
                <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
                <SelectContent>{sellers.map(s => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div>
              <Label>Título</Label>
              <Input value={ooForm.title} onChange={e => setOoForm(p => ({ ...p, title: e.target.value }))} placeholder="Ex: 1:1 Semanal" />
            </div>
            <div>
              <Label>Data/Hora</Label>
              <Input type="datetime-local" value={ooForm.meetingDate} onChange={e => setOoForm(p => ({ ...p, meetingDate: e.target.value }))} />
            </div>
            <div>
              <Label>Resumo</Label>
              <Textarea value={ooForm.summary} onChange={e => setOoForm(p => ({ ...p, summary: e.target.value }))} rows={2} />
            </div>
            <Separator />
            <h4 className="text-sm font-semibold">Tópicos & Próximos Passos</h4>
            {ooForm.items.map((item, idx) => (
              <Card key={idx} className="p-3 space-y-2">
                <div>
                  <Label className="text-xs">Tópico</Label>
                  <Input value={item.topic} onChange={e => {
                    const items = [...ooForm.items];
                    items[idx].topic = e.target.value;
                    setOoForm(p => ({ ...p, items }));
                  }} />
                </div>
                <div>
                  <Label className="text-xs">Decisão</Label>
                  <Input value={item.decision} onChange={e => {
                    const items = [...ooForm.items];
                    items[idx].decision = e.target.value;
                    setOoForm(p => ({ ...p, items }));
                  }} />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <Label className="text-xs">Próximo passo (vira tarefa)</Label>
                    <Input value={item.nextStep} onChange={e => {
                      const items = [...ooForm.items];
                      items[idx].nextStep = e.target.value;
                      setOoForm(p => ({ ...p, items }));
                    }} />
                  </div>
                  <div>
                    <Label className="text-xs">Prazo</Label>
                    <Input type="date" value={item.dueDate} onChange={e => {
                      const items = [...ooForm.items];
                      items[idx].dueDate = e.target.value;
                      setOoForm(p => ({ ...p, items }));
                    }} />
                  </div>
                </div>
                <div>
                  <Label className="text-xs">Responsável</Label>
                  <Select value={item.ownerUserId} onValueChange={v => {
                    const items = [...ooForm.items];
                    items[idx].ownerUserId = v;
                    setOoForm(p => ({ ...p, items }));
                  }}>
                    <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
                    <SelectContent>{sellers.map(s => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
              </Card>
            ))}
            <Button variant="outline" size="sm" onClick={() => setOoForm(p => ({
              ...p,
              items: [...p.items, { topic: '', decision: '', nextStep: '', ownerUserId: '', dueDate: '' }],
            }))}>
              <Plus className="h-3 w-3 mr-1" /> Adicionar tópico
            </Button>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowOneOnOneModal(false)}>Cancelar</Button>
            <Button onClick={handleCreateOneOnOne} disabled={!ooForm.targetUserId || !ooForm.title}>Registrar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* CANCEL DIALOG */}
      <Dialog open={!!cancelId} onOpenChange={() => setCancelId(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Cancelar Ação de RH</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <Label>Motivo do cancelamento (obrigatório)</Label>
            <Textarea value={cancelReason} onChange={e => setCancelReason(e.target.value)} rows={3} />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCancelId(null)}>Voltar</Button>
            <Button variant="destructive" onClick={handleCancel} disabled={cancelReason.length < 5}>Cancelar Ação</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
