import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, TrendingDown, BarChart3, Loader2 } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { supabase } from '@/integrations/supabase/client';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  AreaChart,
  Area,
  Legend,
  ReferenceLine
} from 'recharts';
import { format, subMonths, startOfMonth, endOfMonth } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { cn } from '@/lib/utils';

interface MonthlyData {
  month: string;
  monthLabel: string;
  revenue: number;
  profit: number;
  margin: number;
  lucroReal: number;
  custoTotal: number;
}

type MetricType = 'lucroReal' | 'revenue' | 'margin';

export function GestorHistoryChart() {
  const [data, setData] = useState<MonthlyData[]>([]);
  const [loading, setLoading] = useState(true);
  const [metric, setMetric] = useState<MetricType>('lucroReal');

  useEffect(() => {
    const fetchHistoricalData = async () => {
      setLoading(true);
      
      try {
        const months: MonthlyData[] = [];
        const today = new Date();

        // Fetch last 6 months
        for (let i = 5; i >= 0; i--) {
          const monthDate = subMonths(today, i);
          const startDate = startOfMonth(monthDate);
          const endDate = endOfMonth(monthDate);
          
          const startStr = format(startDate, 'yyyy-MM-dd');
          const endStr = format(endDate, 'yyyy-MM-dd');

          // Fetch orders for this month
          const { data: ordersData } = await supabase
            .from('orders')
            .select('total')
            .gte('order_date', startStr)
            .lte('order_date', endStr);

          // Fetch company costs
          const { data: companyCosts } = await supabase
            .from('company_costs')
            .select('*')
            .limit(1)
            .maybeSingle();

          // Fetch seller costs
          const { data: sellerCosts } = await supabase
            .from('seller_costs')
            .select('custo_mensal_calculado');

          const revenue = ordersData?.reduce((sum, o) => sum + (o.total || 0), 0) || 0;
          
          // Estimate profit as 25% of revenue (simplified)
          const profit = revenue * 0.25;
          const margin = revenue > 0 ? (profit / revenue) * 100 : 25;

          // Calculate total costs (simplified)
          let ceeTotal = 0;
          if (companyCosts) {
            const cc = companyCosts as Record<string, unknown>;
            ceeTotal = Object.entries(cc)
              .filter(([key]) => !['id', 'created_at', 'updated_at'].includes(key))
              .reduce((sum, [_, val]) => sum + (typeof val === 'number' ? val : 0), 0);
          }

          let custoHumanoTotal = 0;
          if (sellerCosts) {
            custoHumanoTotal = sellerCosts.reduce((sum, sc) => {
              return sum + (sc.custo_mensal_calculado || 0);
            }, 0);
          }

          const custoTotal = ceeTotal + custoHumanoTotal;
          const lucroReal = profit - custoTotal;

          months.push({
            month: format(monthDate, 'yyyy-MM'),
            monthLabel: format(monthDate, 'MMM', { locale: ptBR }),
            revenue,
            profit,
            margin,
            lucroReal,
            custoTotal
          });
        }

        setData(months);
      } catch (error) {
        console.error('Error fetching historical data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchHistoricalData();
  }, []);

  const formatCurrency = (value: number) => {
    if (Math.abs(value) >= 1000000) {
      return `R$ ${(value / 1000000).toFixed(1)}M`;
    }
    if (Math.abs(value) >= 1000) {
      return `R$ ${(value / 1000).toFixed(0)}K`;
    }
    return `R$ ${value.toFixed(0)}`;
  };

  const getMetricConfig = () => {
    switch (metric) {
      case 'lucroReal':
        return {
          label: 'Resultado Real',
          dataKey: 'lucroReal',
          color: 'hsl(var(--status-success))',
          negativeColor: 'hsl(var(--destructive))',
          format: formatCurrency
        };
      case 'revenue':
        return {
          label: 'Receita',
          dataKey: 'revenue',
          color: 'hsl(var(--primary))',
          negativeColor: 'hsl(var(--primary))',
          format: formatCurrency
        };
      case 'margin':
        return {
          label: 'Margem %',
          dataKey: 'margin',
          color: 'hsl(var(--accent))',
          negativeColor: 'hsl(var(--destructive))',
          format: (v: number) => `${v.toFixed(1)}%`
        };
    }
  };

  const config = getMetricConfig();

  // Calculate trend
  const lastTwoMonths = data.slice(-2);
  const trend = lastTwoMonths.length === 2 
    ? lastTwoMonths[1][config.dataKey as keyof MonthlyData] as number - (lastTwoMonths[0][config.dataKey as keyof MonthlyData] as number)
    : 0;
  const trendPercent = lastTwoMonths.length === 2 && (lastTwoMonths[0][config.dataKey as keyof MonthlyData] as number) !== 0
    ? (trend / Math.abs(lastTwoMonths[0][config.dataKey as keyof MonthlyData] as number)) * 100
    : 0;

  const CustomTooltip = ({ active, payload, label }: { active?: boolean; payload?: Array<{ value: number }>; label?: string }) => {
    if (active && payload && payload.length) {
      const value = payload[0].value;
      return (
        <div className="bg-popover/95 backdrop-blur-sm border border-border rounded-lg p-3 shadow-lg">
          <p className="text-xs text-muted-foreground uppercase tracking-wide mb-1">
            {label}
          </p>
          <p className={cn(
            "text-lg font-bold",
            metric === 'lucroReal' && value < 0 ? "text-destructive" : "text-foreground"
          )}>
            {config.format(value)}
          </p>
        </div>
      );
    }
    return null;
  };

  if (loading) {
    return (
      <Card className="border-border/50">
        <CardContent className="flex items-center justify-center h-[300px]">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </CardContent>
      </Card>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.2 }}
    >
      <Card className="border-border/50 overflow-hidden">
        <CardHeader className="pb-2">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-primary/10">
                <BarChart3 className="h-5 w-5 text-primary" />
              </div>
              <div>
                <CardTitle className="text-lg">Evolução Histórica</CardTitle>
                <p className="text-sm text-muted-foreground">Últimos 6 meses</p>
              </div>
            </div>

            <div className="flex items-center gap-4">
              {/* Trend Indicator */}
              <div className={cn(
                "flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm font-medium",
                trend >= 0 
                  ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400"
                  : "bg-destructive/10 text-destructive"
              )}>
                {trend >= 0 ? (
                  <TrendingUp className="h-4 w-4" />
                ) : (
                  <TrendingDown className="h-4 w-4" />
                )}
                <span>{trendPercent >= 0 ? '+' : ''}{trendPercent.toFixed(1)}%</span>
              </div>

              {/* Metric Selector */}
              <Tabs value={metric} onValueChange={(v) => setMetric(v as MetricType)}>
                <TabsList className="grid grid-cols-3 h-9">
                  <TabsTrigger value="lucroReal" className="text-xs px-2">
                    Resultado
                  </TabsTrigger>
                  <TabsTrigger value="revenue" className="text-xs px-2">
                    Receita
                  </TabsTrigger>
                  <TabsTrigger value="margin" className="text-xs px-2">
                    Margem
                  </TabsTrigger>
                </TabsList>
              </Tabs>
            </div>
          </div>
        </CardHeader>
        <CardContent className="pt-4">
          <div className="h-[280px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorPositive" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(var(--status-success))" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="hsl(var(--status-success))" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorNegative" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(var(--destructive))" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="hsl(var(--destructive))" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorPrimary" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorAccent" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(var(--accent))" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="hsl(var(--accent))" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid 
                  strokeDasharray="3 3" 
                  stroke="hsl(var(--border))" 
                  vertical={false}
                />
                <XAxis 
                  dataKey="monthLabel" 
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 12 }}
                  dy={10}
                />
                <YAxis 
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 12 }}
                  tickFormatter={(value) => config.format(value)}
                  width={80}
                />
                <Tooltip content={<CustomTooltip />} />
                {metric === 'lucroReal' && (
                  <ReferenceLine y={0} stroke="hsl(var(--border))" strokeDasharray="3 3" />
                )}
                <Area
                  type="monotone"
                  dataKey={config.dataKey}
                  stroke={config.color}
                  strokeWidth={2}
                  fill={
                    metric === 'lucroReal' ? 'url(#colorPositive)' :
                    metric === 'revenue' ? 'url(#colorPrimary)' :
                    'url(#colorAccent)'
                  }
                  dot={{ fill: config.color, strokeWidth: 2, r: 4 }}
                  activeDot={{ r: 6, strokeWidth: 0 }}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
