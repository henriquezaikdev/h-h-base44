import { useMemo } from 'react';
import { 
  User, 
  TrendingUp, 
  AlertTriangle, 
  CheckCircle2, 
  Trophy,
  Target,
  DollarSign,
  XCircle
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

// =============================================================================
// FASE 3 - CUSTO HUMANO INDIVIDUAL
// Custo mensal real de cada colaborador (CPF)
// NÃO inclui rateio do CEE - isso fica na Fase 4
// =============================================================================

export interface SellerHumanCost {
  sellerId: string;
  sellerName: string;
  
  // Dados de custo (da tabela seller_costs)
  salarioBase: number;
  encargosValor: number;
  beneficios: number; // VA + VT + VR + Plano Saúde
  ajudaCusto: number;
  ferramentas: number; // CRM + Telefonia + WhatsApp + Discador + Outras
  deslocamento: number; // Combustível + Reembolso + Viagens
  outrosFixos: number;
  
  // Dados de performance (do período)
  receitaGerada: number;
  margemGerada: number;
  comissaoReal: number; // Calculada automaticamente
}

export interface Phase3Result {
  sellerId: string;
  sellerName: string;
  custoHumanoTotal: number;
  pontoEquilibrio: number;
  status: 'nao_se_paga' | 'se_paga' | 'sustenta' | 'gera_lucro';
  statusLabel: string;
  percentualMeta: number;
  resultadoDireto: number;
}

interface Phase3HumanCostProps {
  sellers: SellerHumanCost[];
  margemMediaEmpresa: number; // % de margem média da empresa
}

function formatCurrency(value: number): string {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  }).format(value);
}

function getStatusConfig(status: Phase3Result['status']) {
  switch (status) {
    case 'gera_lucro':
      return {
        label: 'Gera Lucro Real',
        color: 'bg-green-500',
        textColor: 'text-green-700',
        bgColor: 'bg-green-50',
        borderColor: 'border-green-200',
        icon: Trophy,
        description: 'Colaborador gera lucro além de se pagar e sustentar o CEE'
      };
    case 'sustenta':
      return {
        label: 'Sustenta a Empresa',
        color: 'bg-blue-500',
        textColor: 'text-blue-700',
        bgColor: 'bg-blue-50',
        borderColor: 'border-blue-200',
        icon: CheckCircle2,
        description: 'Colaborador cobre seus custos e ajuda a pagar o CEE'
      };
    case 'se_paga':
      return {
        label: 'Se Paga',
        color: 'bg-amber-500',
        textColor: 'text-amber-700',
        bgColor: 'bg-amber-50',
        borderColor: 'border-amber-200',
        icon: Target,
        description: 'Colaborador cobre exatamente seus custos diretos'
      };
    case 'nao_se_paga':
    default:
      return {
        label: 'Não Se Paga',
        color: 'bg-red-500',
        textColor: 'text-red-700',
        bgColor: 'bg-red-50',
        borderColor: 'border-red-200',
        icon: XCircle,
        description: 'Colaborador custa mais do que gera de margem'
      };
  }
}

function calculateStatus(
  resultadoDireto: number, 
  custoHumano: number,
  ceeRateioPorVendedor: number = 0
): Phase3Result['status'] {
  // Resultado após CEE (para classificação completa)
  const resultadoAposCEE = resultadoDireto - ceeRateioPorVendedor;
  
  if (resultadoDireto < 0) {
    return 'nao_se_paga';
  } else if (resultadoDireto >= 0 && resultadoDireto < ceeRateioPorVendedor) {
    return 'se_paga';
  } else if (resultadoAposCEE >= 0 && resultadoAposCEE < custoHumano * 0.3) {
    return 'sustenta';
  } else {
    return 'gera_lucro';
  }
}

export function calculatePhase3Results(
  sellers: SellerHumanCost[],
  margemMediaEmpresa: number,
  ceeRateioPorVendedor: number = 0
): Phase3Result[] {
  return sellers.map(seller => {
    // Custo Humano Total (sem comissão - a comissão é custo variável direto)
    const custoHumanoFixo = 
      seller.salarioBase +
      seller.encargosValor +
      seller.beneficios +
      seller.ajudaCusto +
      seller.ferramentas +
      seller.deslocamento +
      seller.outrosFixos;
    
    // Custo total incluindo comissão
    const custoHumanoTotal = custoHumanoFixo + seller.comissaoReal;
    
    // Ponto de Equilíbrio = Custo Humano / Margem Média (%)
    // Se margem média é 25%, precisa vender X para gerar margem = custo
    const margemDecimal = margemMediaEmpresa / 100;
    const pontoEquilibrio = margemDecimal > 0 
      ? custoHumanoTotal / margemDecimal 
      : 0;
    
    // Resultado Direto = Margem Gerada - Custo Humano Total
    const resultadoDireto = seller.margemGerada - custoHumanoTotal;
    
    // Status
    const status = calculateStatus(resultadoDireto, custoHumanoTotal, ceeRateioPorVendedor);
    const statusConfig = getStatusConfig(status);
    
    // Percentual da meta (quanto do ponto de equilíbrio atingiu)
    const percentualMeta = pontoEquilibrio > 0 
      ? (seller.receitaGerada / pontoEquilibrio) * 100 
      : 0;
    
    return {
      sellerId: seller.sellerId,
      sellerName: seller.sellerName,
      custoHumanoTotal,
      pontoEquilibrio,
      status,
      statusLabel: statusConfig.label,
      percentualMeta,
      resultadoDireto,
    };
  });
}

export function Phase3HumanCostCard({ result }: { result: Phase3Result }) {
  const statusConfig = getStatusConfig(result.status);
  const StatusIcon = statusConfig.icon;
  
  return (
    <Card className={`${statusConfig.bgColor} ${statusConfig.borderColor} border-2`}>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <User className="h-4 w-4 text-muted-foreground" />
            <CardTitle className="text-sm font-medium">{result.sellerName}</CardTitle>
          </div>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger>
                <Badge className={`${statusConfig.color} text-white`}>
                  <StatusIcon className="h-3 w-3 mr-1" />
                  {result.statusLabel}
                </Badge>
              </TooltipTrigger>
              <TooltipContent>
                <p className="text-sm">{statusConfig.description}</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        {/* Custo Humano Total */}
        <div className="flex justify-between items-center">
          <span className="text-xs text-muted-foreground">Custo Humano Total</span>
          <span className="font-semibold">{formatCurrency(result.custoHumanoTotal)}</span>
        </div>
        
        {/* Ponto de Equilíbrio */}
        <div className="flex justify-between items-center">
          <span className="text-xs text-muted-foreground">Ponto de Equilíbrio</span>
          <span className="font-semibold text-primary">{formatCurrency(result.pontoEquilibrio)}</span>
        </div>
        
        {/* Resultado Direto */}
        <div className="flex justify-between items-center">
          <span className="text-xs text-muted-foreground">Resultado Direto</span>
          <span className={`font-bold ${result.resultadoDireto >= 0 ? 'text-green-600' : 'text-red-600'}`}>
            {formatCurrency(result.resultadoDireto)}
          </span>
        </div>
        
        {/* Barra de progresso */}
        <div className="space-y-1">
          <div className="flex justify-between text-xs">
            <span className="text-muted-foreground">Progresso Meta</span>
            <span className={statusConfig.textColor}>{result.percentualMeta.toFixed(0)}%</span>
          </div>
          <Progress 
            value={Math.min(result.percentualMeta, 100)} 
            className="h-2"
          />
        </div>
      </CardContent>
    </Card>
  );
}

export function Phase3Summary({ results }: { results: Phase3Result[] }) {
  const summary = useMemo(() => {
    const total = results.length;
    const geramLucro = results.filter(r => r.status === 'gera_lucro').length;
    const sustentam = results.filter(r => r.status === 'sustenta').length;
    const sePagam = results.filter(r => r.status === 'se_paga').length;
    const naoSePagam = results.filter(r => r.status === 'nao_se_paga').length;
    
    const custoHumanoTotal = results.reduce((sum, r) => sum + r.custoHumanoTotal, 0);
    const resultadoDiretoTotal = results.reduce((sum, r) => sum + r.resultadoDireto, 0);
    
    return {
      total,
      geramLucro,
      sustentam,
      sePagam,
      naoSePagam,
      custoHumanoTotal,
      resultadoDiretoTotal,
    };
  }, [results]);
  
  return (
    <Card className="border-2 border-primary/30 bg-primary/5">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-medium flex items-center gap-2">
          <DollarSign className="h-4 w-4 text-primary" />
          Fase 3 - Custo Humano Individual (Resumo)
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
          <div className="text-center p-3 bg-background rounded-lg">
            <p className="text-xs text-muted-foreground">Custo Humano Total</p>
            <p className="text-xl font-bold text-primary">{formatCurrency(summary.custoHumanoTotal)}</p>
          </div>
          <div className="text-center p-3 bg-background rounded-lg">
            <p className="text-xs text-muted-foreground">Resultado Direto</p>
            <p className={`text-xl font-bold ${summary.resultadoDiretoTotal >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              {formatCurrency(summary.resultadoDiretoTotal)}
            </p>
          </div>
          <div className="text-center p-3 bg-background rounded-lg">
            <p className="text-xs text-muted-foreground">Colaboradores</p>
            <p className="text-xl font-bold">{summary.total}</p>
          </div>
          <div className="text-center p-3 bg-background rounded-lg">
            <p className="text-xs text-muted-foreground">Custo Médio</p>
            <p className="text-xl font-bold">
              {formatCurrency(summary.total > 0 ? summary.custoHumanoTotal / summary.total : 0)}
            </p>
          </div>
        </div>
        
        {/* Status breakdown */}
        <div className="grid grid-cols-4 gap-2">
          <div className="flex items-center gap-2 p-2 rounded bg-green-50 border border-green-200">
            <Trophy className="h-4 w-4 text-green-600" />
            <div>
              <p className="text-lg font-bold text-green-700">{summary.geramLucro}</p>
              <p className="text-[10px] text-green-600">Geram Lucro</p>
            </div>
          </div>
          <div className="flex items-center gap-2 p-2 rounded bg-blue-50 border border-blue-200">
            <CheckCircle2 className="h-4 w-4 text-blue-600" />
            <div>
              <p className="text-lg font-bold text-blue-700">{summary.sustentam}</p>
              <p className="text-[10px] text-blue-600">Sustentam</p>
            </div>
          </div>
          <div className="flex items-center gap-2 p-2 rounded bg-amber-50 border border-amber-200">
            <Target className="h-4 w-4 text-amber-600" />
            <div>
              <p className="text-lg font-bold text-amber-700">{summary.sePagam}</p>
              <p className="text-[10px] text-amber-600">Se Pagam</p>
            </div>
          </div>
          <div className="flex items-center gap-2 p-2 rounded bg-red-50 border border-red-200">
            <XCircle className="h-4 w-4 text-red-600" />
            <div>
              <p className="text-lg font-bold text-red-700">{summary.naoSePagam}</p>
              <p className="text-[10px] text-red-600">Não Se Pagam</p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export function Phase3HumanCost({ sellers, margemMediaEmpresa }: Phase3HumanCostProps) {
  const results = useMemo(() => 
    calculatePhase3Results(sellers, margemMediaEmpresa),
    [sellers, margemMediaEmpresa]
  );
  
  if (sellers.length === 0) {
    return (
      <Card className="border-dashed">
        <CardContent className="py-8 text-center text-muted-foreground">
          <User className="h-8 w-8 mx-auto mb-2 opacity-50" />
          <p>Nenhum colaborador configurado</p>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <div className="space-y-4">
      <Phase3Summary results={results} />
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {results.map(result => (
          <Phase3HumanCostCard key={result.sellerId} result={result} />
        ))}
      </div>
    </div>
  );
}
