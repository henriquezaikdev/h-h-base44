import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Star, Loader2, Award, Sparkles } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { createSellerNotification } from '@/hooks/useSellerNotifications';

interface Seller {
  id: string;
  name: string;
}

interface AwardStarsModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  sellers: Seller[];
  onSuccess?: () => void;
}

type StarType = 'bronze' | 'silver' | 'gold';

const STAR_CONFIG: Record<StarType, { label: string; color: string; emoji: string }> = {
  bronze: { label: 'Bronze', color: 'bg-amber-600', emoji: '🥉' },
  silver: { label: 'Prata', color: 'bg-gray-400', emoji: '🥈' },
  gold: { label: 'Ouro', color: 'bg-yellow-500', emoji: '🥇' },
};

export function AwardStarsModal({ open, onOpenChange, sellers, onSuccess }: AwardStarsModalProps) {
  const [selectedSellerId, setSelectedSellerId] = useState<string>('');
  const [starType, setStarType] = useState<StarType>('bronze');
  const [quantity, setQuantity] = useState<number>(1);
  const [reason, setReason] = useState<string>('');
  const [saving, setSaving] = useState(false);

  const handleSubmit = async () => {
    if (!selectedSellerId) {
      toast.error('Selecione um vendedor');
      return;
    }

    if (quantity < 1 || quantity > 10) {
      toast.error('Quantidade deve ser entre 1 e 10');
      return;
    }

    setSaving(true);

    try {
      // Check if seller already has a stars record
      const { data: existing, error: fetchError } = await supabase
        .from('seller_stars')
        .select('*')
        .eq('seller_id', selectedSellerId)
        .maybeSingle();

      if (fetchError) throw fetchError;

      const columnName = `${starType}_stars` as 'bronze_stars' | 'silver_stars' | 'gold_stars';

      if (existing) {
        // Update existing record
        const { error: updateError } = await supabase
          .from('seller_stars')
          .update({
            [columnName]: (existing[columnName] || 0) + quantity,
            updated_at: new Date().toISOString(),
          })
          .eq('seller_id', selectedSellerId);

        if (updateError) throw updateError;
      } else {
        // Create new record
        const { error: insertError } = await supabase
          .from('seller_stars')
          .insert({
            seller_id: selectedSellerId,
            bronze_stars: starType === 'bronze' ? quantity : 0,
            silver_stars: starType === 'silver' ? quantity : 0,
            gold_stars: starType === 'gold' ? quantity : 0,
            current_streak: 0,
          });

        if (insertError) throw insertError;
      }

      const sellerName = sellers.find(s => s.id === selectedSellerId)?.name || 'Vendedor';
      
      // Criar notificação para o vendedor
      const notificationTitle = `${STAR_CONFIG[starType].emoji} Você ganhou ${quantity} estrela${quantity > 1 ? 's' : ''} ${STAR_CONFIG[starType].label}!`;
      const notificationMessage = reason 
        ? `Motivo: ${reason}` 
        : `Reconhecimento por seu desempenho. Continue assim!`;
      
      await createSellerNotification(
        selectedSellerId,
        notificationTitle,
        notificationMessage,
        'stars',
        { star_type: starType, quantity, reason }
      );
      
      toast.success(
        <div className="flex items-center gap-2">
          <span>{STAR_CONFIG[starType].emoji}</span>
          <span>
            {quantity} estrela{quantity > 1 ? 's' : ''} {STAR_CONFIG[starType].label} atribuída{quantity > 1 ? 's' : ''} para {sellerName}
          </span>
        </div>
      );

      // Reset form
      setSelectedSellerId('');
      setStarType('bronze');
      setQuantity(1);
      setReason('');
      onOpenChange(false);
      onSuccess?.();
    } catch (error) {
      console.error('Error awarding stars:', error);
      toast.error('Erro ao atribuir estrelas');
    } finally {
      setSaving(false);
    }
  };

  const handleClose = () => {
    if (!saving) {
      setSelectedSellerId('');
      setStarType('bronze');
      setQuantity(1);
      setReason('');
      onOpenChange(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Award className="h-5 w-5 text-amber-500" />
            Atribuir Estrelas
          </DialogTitle>
          <DialogDescription>
            Reconheça o desempenho de um vendedor atribuindo estrelas manualmente.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          {/* Seller Selection */}
          <div className="space-y-2">
            <Label>Vendedor</Label>
            <Select value={selectedSellerId} onValueChange={setSelectedSellerId}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione um vendedor..." />
              </SelectTrigger>
              <SelectContent>
                {sellers.map((seller) => (
                  <SelectItem key={seller.id} value={seller.id}>
                    {seller.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Star Type Selection */}
          <div className="space-y-2">
            <Label>Tipo de Estrela</Label>
            <div className="flex gap-2">
              {(Object.keys(STAR_CONFIG) as StarType[]).map((type) => (
                <button
                  key={type}
                  type="button"
                  onClick={() => setStarType(type)}
                  className={`flex-1 p-3 rounded-lg border-2 transition-all ${
                    starType === type
                      ? 'border-primary bg-primary/10'
                      : 'border-border hover:border-primary/50'
                  }`}
                >
                  <div className="text-center">
                    <span className="text-2xl">{STAR_CONFIG[type].emoji}</span>
                    <p className="text-xs font-medium mt-1">{STAR_CONFIG[type].label}</p>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Quantity */}
          <div className="space-y-2">
            <Label>Quantidade</Label>
            <div className="flex items-center gap-3">
              <Input
                type="number"
                min={1}
                max={10}
                value={quantity}
                onChange={(e) => setQuantity(Math.min(10, Math.max(1, parseInt(e.target.value) || 1)))}
                className="w-24"
              />
              <div className="flex items-center gap-1">
                {Array.from({ length: Math.min(quantity, 5) }).map((_, i) => (
                  <Star key={i} className="h-5 w-5 fill-amber-400 text-amber-400" />
                ))}
                {quantity > 5 && (
                  <Badge variant="secondary" className="ml-1">
                    +{quantity - 5}
                  </Badge>
                )}
              </div>
            </div>
          </div>

          {/* Reason (optional) */}
          <div className="space-y-2">
            <Label>Motivo (opcional)</Label>
            <Textarea
              placeholder="Ex: Meta de vendas batida, excelência no atendimento..."
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              rows={2}
            />
          </div>
        </div>

        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={handleClose} disabled={saving}>
            Cancelar
          </Button>
          <Button onClick={handleSubmit} disabled={saving || !selectedSellerId}>
            {saving ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Salvando...
              </>
            ) : (
              <>
                <Sparkles className="h-4 w-4 mr-2" />
                Atribuir Estrelas
              </>
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
