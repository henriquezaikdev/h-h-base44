import { useState, useEffect } from 'react';
import { ArrowRightLeft, Users, CheckSquare, Loader2, CheckCircle2 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useSellersData } from '@/hooks/useSellersData';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';

interface TransferirCarteiraModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  sellerOrigem: { id: string; name: string; status?: string } | null;
  onSuccess: () => void;
}

interface TransferResult {
  success: boolean;
  message?: string;
  clientes_transferidos?: number;
  tarefas_transferidas?: number;
}

export function TransferirCarteiraModal({
  open,
  onOpenChange,
  sellerOrigem,
  onSuccess,
}: TransferirCarteiraModalProps) {
  const { activeSellers } = useSellersData(false);
  const [destinoId, setDestinoId] = useState<string>('');
  const [transferirClientes, setTransferirClientes] = useState(true);
  const [transferirTarefasAbertas, setTransferirTarefasAbertas] = useState(true);
  const [transferirTarefasFuturas, setTransferirTarefasFuturas] = useState(true);
  const [observacoes, setObservacoes] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<TransferResult | null>(null);

  // Filtrar para não mostrar o vendedor origem como opção de destino
  const availableDestinos = activeSellers.filter(s => s.id !== sellerOrigem?.id);

  // Reset quando abrir/fechar
  useEffect(() => {
    if (open) {
      setDestinoId('');
      setTransferirClientes(true);
      setTransferirTarefasAbertas(true);
      setTransferirTarefasFuturas(true);
      setObservacoes('');
      setResult(null);
    }
  }, [open]);

  async function handleTransferir() {
    if (!sellerOrigem || !destinoId) {
      toast.error('Selecione o vendedor de destino');
      return;
    }

    if (!transferirClientes && !transferirTarefasAbertas && !transferirTarefasFuturas) {
      toast.error('Selecione pelo menos uma opção de transferência');
      return;
    }

    setLoading(true);
    try {
      const { data, error } = await supabase.rpc('transferir_carteira', {
        p_origem_id: sellerOrigem.id,
        p_destino_id: destinoId,
        p_transferir_clientes: transferirClientes,
        p_transferir_tarefas_abertas: transferirTarefasAbertas,
        p_transferir_tarefas_futuras: transferirTarefasFuturas,
        p_observacoes: observacoes.trim() || null,
      });

      if (error) throw error;

      const transferResult = data as unknown as TransferResult;
      if (!transferResult.success) {
        throw new Error(transferResult.message || 'Erro na transferência');
      }

      setResult(transferResult);
      toast.success('Carteira transferida com sucesso!');
      onSuccess();
    } catch (err: any) {
      console.error('Erro ao transferir carteira:', err);
      toast.error(err.message || 'Erro ao transferir carteira');
    } finally {
      setLoading(false);
    }
  }

  const destinoSeller = availableDestinos.find(s => s.id === destinoId);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ArrowRightLeft className="h-5 w-5 text-blue-500" />
            Transferir Carteira
          </DialogTitle>
          <DialogDescription>
            Transferir clientes e tarefas de <strong>{sellerOrigem?.name}</strong> para outro vendedor.
          </DialogDescription>
        </DialogHeader>

        {result ? (
          // Resultado da transferência
          <div className="space-y-4">
            <div className="bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800 rounded-lg p-6 text-center">
              <CheckCircle2 className="h-12 w-12 text-emerald-600 mx-auto mb-3" />
              <h3 className="text-lg font-semibold text-emerald-800 dark:text-emerald-200 mb-2">
                Transferência Concluída!
              </h3>
              <div className="grid grid-cols-2 gap-4 mt-4">
                <div className="bg-white dark:bg-emerald-900/30 rounded-lg p-3">
                  <Users className="h-5 w-5 text-emerald-600 mx-auto mb-1" />
                  <p className="text-2xl font-bold text-emerald-700 dark:text-emerald-300">
                    {result.clientes_transferidos || 0}
                  </p>
                  <p className="text-sm text-emerald-600 dark:text-emerald-400">Clientes</p>
                </div>
                <div className="bg-white dark:bg-emerald-900/30 rounded-lg p-3">
                  <CheckSquare className="h-5 w-5 text-emerald-600 mx-auto mb-1" />
                  <p className="text-2xl font-bold text-emerald-700 dark:text-emerald-300">
                    {result.tarefas_transferidas || 0}
                  </p>
                  <p className="text-sm text-emerald-600 dark:text-emerald-400">Tarefas</p>
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button onClick={() => onOpenChange(false)}>Fechar</Button>
            </DialogFooter>
          </div>
        ) : (
          // Formulário de transferência
          <div className="space-y-4">
            {/* Seletor de destino */}
            <div className="space-y-2">
              <Label htmlFor="destino">Transferir para *</Label>
              <Select value={destinoId} onValueChange={setDestinoId}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione o vendedor de destino" />
                </SelectTrigger>
                <SelectContent>
                  {availableDestinos.map((seller) => (
                    <SelectItem key={seller.id} value={seller.id}>
                      {seller.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {availableDestinos.length === 0 && (
                <p className="text-sm text-amber-600">
                  Não há vendedores ativos disponíveis para transferência.
                </p>
              )}
            </div>

            {/* Opções de transferência */}
            <div className="space-y-3">
              <Label>O que transferir:</Label>
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <Checkbox
                    id="clientes"
                    checked={transferirClientes}
                    onCheckedChange={(checked) => setTransferirClientes(!!checked)}
                  />
                  <Label htmlFor="clientes" className="font-normal cursor-pointer">
                    Clientes (responsável atual)
                  </Label>
                </div>
                <div className="flex items-center gap-2">
                  <Checkbox
                    id="tarefasAbertas"
                    checked={transferirTarefasAbertas}
                    onCheckedChange={(checked) => setTransferirTarefasAbertas(!!checked)}
                  />
                  <Label htmlFor="tarefasAbertas" className="font-normal cursor-pointer">
                    Tarefas abertas/atrasadas (até hoje)
                  </Label>
                </div>
                <div className="flex items-center gap-2">
                  <Checkbox
                    id="tarefasFuturas"
                    checked={transferirTarefasFuturas}
                    onCheckedChange={(checked) => setTransferirTarefasFuturas(!!checked)}
                  />
                  <Label htmlFor="tarefasFuturas" className="font-normal cursor-pointer">
                    Tarefas futuras (após hoje)
                  </Label>
                </div>
              </div>
            </div>

            {/* Info box */}
            <div className="bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800 rounded-lg p-3 text-sm text-blue-800 dark:text-blue-200">
              <p className="font-medium mb-1">Regras da transferência:</p>
              <ul className="list-disc list-inside space-y-0.5 text-blue-700 dark:text-blue-300">
                <li>Tarefas concluídas/canceladas <strong>não</strong> são transferidas</li>
                <li>Vendas antigas permanecem vinculadas ao vendedor original</li>
                <li>O histórico é preservado integralmente</li>
              </ul>
            </div>

            {/* Observações */}
            <div className="space-y-2">
              <Label htmlFor="observacoes">Observações (opcional)</Label>
              <Textarea
                id="observacoes"
                placeholder="Ex: Motivo da transferência, contexto..."
                value={observacoes}
                onChange={(e) => setObservacoes(e.target.value)}
                rows={2}
              />
            </div>

            <DialogFooter className="gap-2">
              <Button
                variant="outline"
                onClick={() => onOpenChange(false)}
                disabled={loading}
              >
                Cancelar
              </Button>
              <Button
                onClick={handleTransferir}
                disabled={loading || !destinoId}
              >
                {loading ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin mr-2" />
                    Transferindo...
                  </>
                ) : (
                  <>
                    <ArrowRightLeft className="h-4 w-4 mr-2" />
                    Executar Transferência
                  </>
                )}
              </Button>
            </DialogFooter>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}