import { useState } from 'react';
import { UserX, AlertTriangle, Loader2 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';

interface InativarVendedorModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  seller: { id: string; name: string } | null;
  onSuccess: () => void;
}

export function InativarVendedorModal({
  open,
  onOpenChange,
  seller,
  onSuccess,
}: InativarVendedorModalProps) {
  const [motivo, setMotivo] = useState('');
  const [loading, setLoading] = useState(false);

  async function handleInativar() {
    if (!seller) return;

    setLoading(true);
    try {
      const { data, error } = await supabase.rpc('inativar_vendedor', {
        p_seller_id: seller.id,
        p_motivo: motivo.trim() || null,
      });

      if (error) throw error;

      const result = data as { success: boolean; message: string };
      if (!result.success) {
        throw new Error(result.message || 'Erro ao inativar vendedor');
      }

      toast.success(`Vendedor "${seller.name}" inativado com sucesso`);
      setMotivo('');
      onOpenChange(false);
      onSuccess();
    } catch (err: any) {
      console.error('Erro ao inativar vendedor:', err);
      toast.error(err.message || 'Erro ao inativar vendedor');
    } finally {
      setLoading(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-destructive">
            <UserX className="h-5 w-5" />
            Inativar Vendedor
          </DialogTitle>
          <DialogDescription>
            Você está prestes a inativar o vendedor <strong>{seller?.name}</strong>.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 rounded-lg p-4">
            <div className="flex items-start gap-3">
              <AlertTriangle className="h-5 w-5 text-amber-600 shrink-0 mt-0.5" />
              <div className="text-sm text-amber-800 dark:text-amber-200">
                <p className="font-medium mb-1">O que acontece ao inativar:</p>
                <ul className="list-disc list-inside space-y-1 text-amber-700 dark:text-amber-300">
                  <li>O vendedor não aparecerá mais em filtros operacionais</li>
                  <li>Não será contabilizado em metas/rankings atuais</li>
                  <li>Todo o histórico de vendas e atividades será preservado</li>
                  <li>Você poderá transferir a carteira para outro vendedor</li>
                </ul>
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="motivo">Motivo da inativação (opcional)</Label>
            <Textarea
              id="motivo"
              placeholder="Ex: Desligamento, afastamento, mudança de função..."
              value={motivo}
              onChange={(e) => setMotivo(e.target.value)}
              rows={3}
            />
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            disabled={loading}
          >
            Cancelar
          </Button>
          <Button
            variant="destructive"
            onClick={handleInativar}
            disabled={loading}
          >
            {loading ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
                Inativando...
              </>
            ) : (
              <>
                <UserX className="h-4 w-4 mr-2" />
                Inativar Vendedor
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}