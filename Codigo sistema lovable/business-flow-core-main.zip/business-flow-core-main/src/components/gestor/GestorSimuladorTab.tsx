import { Lightbulb } from 'lucide-react';
import { WhatIfSimulator } from './WhatIfSimulator';

interface GestorSimuladorTabProps {
  currentRevenue: number;
  currentMargin: number;
  currentProfit: number;
  currentCustoHumano: number;
  currentCEE: number;
  currentImpostos: number;
  currentLucroReal: number;
  currentSellersCount: number;
  avgRevenuePerSeller: number;
}

export function GestorSimuladorTab({
  currentRevenue,
  currentMargin,
  currentProfit,
  currentCustoHumano,
  currentCEE,
  currentImpostos,
  currentLucroReal,
  currentSellersCount,
  avgRevenuePerSeller,
}: GestorSimuladorTabProps) {
  return (
    <div className="space-y-6">
      {/* Header da Aba */}
      <div className="flex items-center gap-2">
        <Lightbulb className="h-5 w-5 text-primary" />
        <h2 className="text-lg font-semibold">Simulador What-If</h2>
        <span className="text-sm text-muted-foreground">
          — Projete cenários de crescimento e otimização
        </span>
      </div>

      {/* What-If Simulator */}
      <WhatIfSimulator 
        currentRevenue={currentRevenue}
        currentMargin={currentMargin}
        currentProfit={currentProfit}
        currentCustoHumano={currentCustoHumano}
        currentCEE={currentCEE}
        currentImpostos={currentImpostos}
        currentLucroReal={currentLucroReal}
        currentSellersCount={currentSellersCount}
        avgRevenuePerSeller={avgRevenuePerSeller}
      />
    </div>
  );
}
