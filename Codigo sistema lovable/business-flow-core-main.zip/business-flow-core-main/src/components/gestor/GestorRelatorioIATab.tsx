import { useState, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Brain, Loader2, Send, RefreshCw, Sparkles, MessageSquare, Copy, Check, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import ReactMarkdown from 'react-markdown';
import { format, startOfMonth, endOfMonth, subDays } from 'date-fns';

interface Props {
  startDate: Date;
  endDate: Date;
}

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

type StrategicStatus = 'idle' | 'saudavel' | 'atencao' | 'critico';

const STATUS_CONFIG: Record<StrategicStatus, { label: string; emoji: string; color: string }> = {
  idle: { label: 'Aguardando diagnóstico', emoji: '⏳', color: 'bg-muted text-muted-foreground' },
  saudavel: { label: 'Saudável', emoji: '🟢', color: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-400' },
  atencao: { label: 'Atenção', emoji: '🟡', color: 'bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-400' },
  critico: { label: 'Crítico', emoji: '🔴', color: 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400' },
};

function detectStatus(text: string): StrategicStatus {
  const lower = text.toLowerCase();
  if (lower.includes('🔴') || lower.includes('crítico') || lower.includes('critico')) return 'critico';
  if (lower.includes('🟡') || lower.includes('atenção') || lower.includes('atencao')) return 'atencao';
  if (lower.includes('🟢') || lower.includes('saudável') || lower.includes('saudavel')) return 'saudavel';
  return 'atencao'; // default after diagnostic
}

export function GestorRelatorioIATab({ startDate, endDate }: Props) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [strategicStatus, setStrategicStatus] = useState<StrategicStatus>('idle');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const abortRef = useRef<AbortController | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  const streamResponse = useCallback(async (
    userMessages: { role: string; content: string }[],
    isDiagnostic: boolean,
    sd: string,
    ed: string,
  ) => {
    setLoading(true);
    abortRef.current = new AbortController();

    let fullText = '';
    const assistantId = crypto.randomUUID();

    // Add placeholder assistant message
    setMessages(prev => [...prev, { id: assistantId, role: 'assistant', content: '', timestamp: new Date() }]);

    try {
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/gestor-ia-strategic`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
          },
          body: JSON.stringify({
            messages: userMessages,
            startDate: sd,
            endDate: ed,
            isDiagnostic,
          }),
          signal: abortRef.current.signal,
        }
      );

      if (response.status === 429) {
        toast.error('Limite de requisições atingido. Aguarde um momento.');
        setMessages(prev => prev.filter(m => m.id !== assistantId));
        return;
      }
      if (response.status === 402) {
        toast.error('Créditos insuficientes. Adicione créditos ao workspace.');
        setMessages(prev => prev.filter(m => m.id !== assistantId));
        return;
      }
      if (!response.ok || !response.body) throw new Error('Falha ao gerar análise');

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let textBuffer = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        textBuffer += decoder.decode(value, { stream: true });

        let newlineIndex: number;
        while ((newlineIndex = textBuffer.indexOf('\n')) !== -1) {
          let line = textBuffer.slice(0, newlineIndex);
          textBuffer = textBuffer.slice(newlineIndex + 1);
          if (line.endsWith('\r')) line = line.slice(0, -1);
          if (line.startsWith(':') || line.trim() === '') continue;
          if (!line.startsWith('data: ')) continue;
          const jsonStr = line.slice(6).trim();
          if (jsonStr === '[DONE]') break;
          try {
            const parsed = JSON.parse(jsonStr);
            const content = parsed.choices?.[0]?.delta?.content;
            if (content) {
              fullText += content;
              setMessages(prev => prev.map(m => m.id === assistantId ? { ...m, content: fullText } : m));
            }
          } catch {
            textBuffer = line + '\n' + textBuffer;
            break;
          }
        }
      }

      // Flush remaining
      if (textBuffer.trim()) {
        for (let raw of textBuffer.split('\n')) {
          if (!raw || !raw.startsWith('data: ')) continue;
          const jsonStr = raw.slice(6).trim();
          if (jsonStr === '[DONE]') continue;
          try {
            const parsed = JSON.parse(jsonStr);
            const content = parsed.choices?.[0]?.delta?.content;
            if (content) fullText += content;
          } catch { /* ignore */ }
        }
        setMessages(prev => prev.map(m => m.id === assistantId ? { ...m, content: fullText } : m));
      }

      // Detect strategic status from diagnostic
      if (isDiagnostic && fullText) {
        setStrategicStatus(detectStatus(fullText));
      }
    } catch (err: any) {
      if (err.name !== 'AbortError') {
        toast.error(err.message || 'Erro ao gerar análise');
        setMessages(prev => prev.filter(m => m.id !== assistantId));
      }
    } finally {
      setLoading(false);
    }
  }, []);

  const handleDiagnostic = useCallback(() => {
    const sd = format(startDate, 'yyyy-MM-dd');
    const ed = format(endDate, 'yyyy-MM-dd');
    
    const userMsg: ChatMessage = {
      id: crypto.randomUUID(),
      role: 'user',
      content: `🔍 **Diagnóstico Estratégico Completo** — Período: ${format(startDate, 'dd/MM/yyyy')} a ${format(endDate, 'dd/MM/yyyy')}`,
      timestamp: new Date(),
    };
    setMessages(prev => [...prev, userMsg]);

    const aiMessages = [
      ...messages.map(m => ({ role: m.role, content: m.content })),
      { role: 'user', content: `Execute o Diagnóstico Estratégico Completo para o período de ${sd} a ${ed}. Analise todos os módulos, detecte riscos, concentrações, tendências e gere o relatório estruturado completo com status final (🟢/🟡/🔴).` },
    ];

    streamResponse(aiMessages, true, sd, ed);
  }, [startDate, endDate, messages, streamResponse]);

  const handleSend = useCallback(() => {
    if (!input.trim() || loading) return;
    const text = input.trim();
    setInput('');

    const userMsg: ChatMessage = {
      id: crypto.randomUUID(),
      role: 'user',
      content: text,
      timestamp: new Date(),
    };
    setMessages(prev => [...prev, userMsg]);

    const sd = format(startDate, 'yyyy-MM-dd');
    const ed = format(endDate, 'yyyy-MM-dd');

    const aiMessages = [
      ...messages.map(m => ({ role: m.role, content: m.content })),
      { role: 'user', content: text },
    ];

    streamResponse(aiMessages, false, sd, ed);
  }, [input, loading, startDate, endDate, messages, streamResponse]);

  const copyToClipboard = useCallback((id: string, content: string) => {
    navigator.clipboard.writeText(content);
    setCopiedId(id);
    toast.success('Copiado!');
    setTimeout(() => setCopiedId(null), 2000);
  }, []);

  const statusCfg = STATUS_CONFIG[strategicStatus];

  return (
    <div className="space-y-6">
      {/* Header with Status */}
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <h2 className="text-xl font-semibold text-foreground flex items-center gap-2">
              <Brain className="w-5 h-5 text-primary" />
              Agente Estratégico IA
            </h2>
            <p className="text-sm text-muted-foreground">
              Análise global com acesso a todos os módulos do sistema
            </p>
          </div>

          {/* Strategic Status Badge */}
          <Badge className={cn('gap-1.5 py-1.5 px-3 text-sm font-medium', statusCfg.color)}>
            <span>{statusCfg.emoji}</span>
            {statusCfg.label}
          </Badge>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-3">
          <Button
            onClick={handleDiagnostic}
            disabled={loading}
            className="gap-2"
            size="lg"
          >
            <Zap className="w-4 h-4" />
            Rodar Diagnóstico Estratégico
          </Button>
          <div className="flex items-center text-xs text-muted-foreground bg-muted/50 rounded-lg px-3">
            Período: {format(startDate, 'dd/MM/yyyy')} — {format(endDate, 'dd/MM/yyyy')}
          </div>
        </div>
      </motion.div>

      {/* Chat Area */}
      <Card className="border border-border/50 bg-card">
        <CardContent className="p-0">
          <ScrollArea className="h-[500px] p-4" ref={scrollRef}>
            {messages.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-center py-16">
                <MessageSquare className="h-12 w-12 text-muted-foreground/30 mb-4" />
                <p className="text-sm text-muted-foreground font-medium mb-1">
                  Agente Estratégico pronto
                </p>
                <p className="text-xs text-muted-foreground max-w-md">
                  Clique em "Rodar Diagnóstico Estratégico" para análise completa, ou faça perguntas sobre qualquer área do negócio: financeiro, comercial, compras, estoque, entregas...
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {messages.map((msg) => (
                  <div key={msg.id} className={cn(
                    'relative rounded-xl p-4',
                    msg.role === 'user' 
                      ? 'bg-primary/5 border border-primary/20 ml-8' 
                      : 'bg-muted/30 border border-border/30 mr-4'
                  )}>
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        {msg.role === 'assistant' && <Sparkles className="h-3 w-3 text-primary" />}
                        <span className="text-xs font-medium text-muted-foreground">
                          {msg.role === 'assistant' ? 'Agente IA' : 'Você'}
                        </span>
                        <span className="text-[10px] text-muted-foreground/60">
                          {format(msg.timestamp, 'HH:mm')}
                        </span>
                      </div>
                      {msg.role === 'assistant' && msg.content && (
                        <Button variant="ghost" size="icon" className="h-6 w-6"
                          onClick={() => copyToClipboard(msg.id, msg.content)}>
                          {copiedId === msg.id ? <Check className="h-3 w-3 text-emerald-500" /> : <Copy className="h-3 w-3" />}
                        </Button>
                      )}
                    </div>
                    {msg.role === 'assistant' && !msg.content && loading ? (
                      <div className="flex items-center gap-2 py-4">
                        <Loader2 className="h-4 w-4 animate-spin text-primary" />
                        <span className="text-sm text-muted-foreground">Analisando dados...</span>
                      </div>
                    ) : (
                      <div className="prose prose-sm max-w-none dark:prose-invert prose-headings:text-foreground prose-p:text-muted-foreground prose-strong:text-foreground prose-li:text-muted-foreground">
                        <ReactMarkdown>{msg.content}</ReactMarkdown>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>

          {/* Input */}
          <div className="p-4 border-t border-border/30 bg-background/50">
            <div className="flex gap-2">
              <Textarea
                placeholder="Pergunte sobre financeiro, comercial, compras, estoque, entregas..."
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSend();
                  }
                }}
                className="min-h-[50px] max-h-[120px] resize-none"
                disabled={loading}
              />
              <Button
                size="icon"
                onClick={handleSend}
                disabled={!input.trim() || loading}
                className="shrink-0 h-[50px] w-[50px]"
              >
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
