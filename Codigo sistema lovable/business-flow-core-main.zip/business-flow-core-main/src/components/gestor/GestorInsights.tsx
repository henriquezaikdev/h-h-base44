import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Lightbulb, AlertTriangle, TrendingDown, ExternalLink } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { format, subDays } from 'date-fns';

interface ClientInsight {
  id: string;
  company_name: string;
  days_since_last_contact?: number;
  days_since_last_order?: number;
  seller_name?: string;
}

export function GestorInsights() {
  const [noContact15, setNoContact15] = useState<ClientInsight[]>([]);
  const [recurrentNoOrder45, setRecurrentNoOrder45] = useState<ClientInsight[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchInsights = async () => {
      setLoading(true);

      try {
        // Clients without contact 15+ days
        const { data: noContactData } = await supabase
          .from('clients')
          .select(`
            id, 
            company_name, 
            last_contact_at,
            sellers!clients_seller_id_fkey(name)
          `)
          .is('is_deleted', false)
          .or(`last_contact_at.is.null,last_contact_at.lt.${format(subDays(new Date(), 15), 'yyyy-MM-dd')}`)
          .order('last_contact_at', { ascending: true, nullsFirst: true })
          .limit(10);

        if (noContactData) {
          setNoContact15(noContactData.map(c => ({
            id: c.id,
            company_name: c.company_name,
            days_since_last_contact: c.last_contact_at 
              ? Math.floor((Date.now() - new Date(c.last_contact_at).getTime()) / (1000 * 60 * 60 * 24))
              : null,
            seller_name: (c.sellers as any)?.name,
          })));
        }

        // Recurrent clients without order 45+ days
        const { data: recurrentData } = await supabase
          .from('clients')
          .select(`
            id, 
            company_name, 
            days_since_last_order,
            sellers!clients_seller_id_fkey(name)
          `)
          .is('is_deleted', false)
          .eq('classification', 'recorrente')
          .or(`last_order_date.is.null,last_order_date.lt.${format(subDays(new Date(), 45), 'yyyy-MM-dd')}`)
          .order('days_since_last_order', { ascending: false, nullsFirst: true })
          .limit(10);

        if (recurrentData) {
          setRecurrentNoOrder45(recurrentData.map(c => ({
            id: c.id,
            company_name: c.company_name,
            days_since_last_order: c.days_since_last_order,
            seller_name: (c.sellers as any)?.name,
          })));
        }
      } catch (error) {
        console.error('Error fetching insights:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchInsights();
  }, []);

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="animate-pulse space-y-3">
            <div className="h-4 bg-muted rounded w-1/3"></div>
            <div className="h-4 bg-muted rounded w-2/3"></div>
            <div className="h-4 bg-muted rounded w-1/2"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
      <Card className="border-amber-500/30">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <AlertTriangle className="h-4 w-4 text-amber-500" />
            Top 10 - Sem Contato 15+ dias
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 max-h-[300px] overflow-y-auto">
          {noContact15.length === 0 ? (
            <p className="text-sm text-muted-foreground">Nenhum cliente nesta situação 🎉</p>
          ) : (
            noContact15.map((client) => (
              <div 
                key={client.id}
                className="flex items-center justify-between p-2 rounded-lg bg-muted/50 hover:bg-muted transition-colors"
              >
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-sm truncate">{client.company_name}</p>
                  <p className="text-xs text-muted-foreground">
                    {client.seller_name || 'Sem vendedor'} • 
                    {client.days_since_last_contact 
                      ? ` ${client.days_since_last_contact} dias`
                      : ' Nunca contatado'}
                  </p>
                </div>
                <Link to={`/clients/${client.id}`}>
                  <Button size="sm" variant="ghost" className="h-7 px-2">
                    <ExternalLink className="h-3 w-3" />
                  </Button>
                </Link>
              </div>
            ))
          )}
        </CardContent>
      </Card>

      <Card className="border-destructive/30">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <TrendingDown className="h-4 w-4 text-destructive" />
            Top 10 - Recorrentes s/ Pedido 45+ dias
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 max-h-[300px] overflow-y-auto">
          {recurrentNoOrder45.length === 0 ? (
            <p className="text-sm text-muted-foreground">Nenhum cliente nesta situação 🎉</p>
          ) : (
            recurrentNoOrder45.map((client) => (
              <div 
                key={client.id}
                className="flex items-center justify-between p-2 rounded-lg bg-muted/50 hover:bg-muted transition-colors"
              >
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-sm truncate">{client.company_name}</p>
                  <p className="text-xs text-muted-foreground">
                    {client.seller_name || 'Sem vendedor'} • 
                    {client.days_since_last_order 
                      ? ` ${client.days_since_last_order} dias sem pedido`
                      : ' Nunca comprou'}
                  </p>
                </div>
                <Link to={`/clients/${client.id}`}>
                  <Button size="sm" variant="ghost" className="h-7 px-2">
                    <ExternalLink className="h-3 w-3" />
                  </Button>
                </Link>
              </div>
            ))
          )}
        </CardContent>
      </Card>
    </div>
  );
}
