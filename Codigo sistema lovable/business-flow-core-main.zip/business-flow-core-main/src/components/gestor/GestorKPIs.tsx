import { 
  DollarSign, 
  ShoppingCart, 
  TrendingUp, 
  Phone, 
  MessageCircle, 
  Users, 
  AlertTriangle,
  Clock
} from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import type { GestorKPIs as GestorKPIsType } from '@/hooks/useGestorData';

interface GestorKPIsProps {
  kpis: GestorKPIsType;
}

function formatCurrency(value: number): string {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value);
}

function formatNumber(value: number): string {
  return new Intl.NumberFormat('pt-BR').format(value);
}

function calculateVariation(current: number, prev: number): { value: number; isPositive: boolean } {
  if (prev === 0) return { value: 0, isPositive: true };
  const variation = ((current - prev) / prev) * 100;
  return { value: Math.abs(variation), isPositive: variation >= 0 };
}

interface KPICardProps {
  title: string;
  value: string;
  icon: React.ElementType;
  variation?: { value: number; isPositive: boolean };
  variant?: 'default' | 'warning' | 'danger';
}

function KPICard({ title, value, icon: Icon, variation, variant = 'default' }: KPICardProps) {
  const bgColor = {
    default: 'bg-card',
    warning: 'bg-amber-500/10 border-amber-500/30',
    danger: 'bg-destructive/10 border-destructive/30',
  }[variant];

  const iconColor = {
    default: 'text-primary',
    warning: 'text-amber-500',
    danger: 'text-destructive',
  }[variant];

  return (
    <Card className={cn('border', bgColor)}>
      <CardContent className="p-4">
        <div className="flex items-start justify-between">
          <div className="space-y-1">
            <p className="text-xs text-muted-foreground uppercase tracking-wide">{title}</p>
            <p className="text-2xl font-bold">{value}</p>
            {variation && variation.value > 0 && (
              <p className={cn(
                'text-xs font-medium',
                variation.isPositive ? 'text-emerald-500' : 'text-destructive'
              )}>
                {variation.isPositive ? '▲' : '▼'} {variation.value.toFixed(1)}%
              </p>
            )}
          </div>
          <div className={cn('p-2 rounded-lg bg-background/50', iconColor)}>
            <Icon className="h-5 w-5" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export function GestorKPIs({ kpis }: GestorKPIsProps) {
  const revenueVar = calculateVariation(kpis.revenue, kpis.revenuePrev);
  const ordersVar = calculateVariation(kpis.ordersCount, kpis.ordersCountPrev);
  const ticketVar = calculateVariation(kpis.avgTicket, kpis.avgTicketPrev);
  const profitVar = calculateVariation(kpis.profit, kpis.profitPrev);

  return (
    <div className="space-y-4">
      <h2 className="text-lg font-semibold flex items-center gap-2">
        <TrendingUp className="h-5 w-5 text-primary" />
        KPIs Executivos
      </h2>
      
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-3">
        <KPICard
          title="Receita"
          value={formatCurrency(kpis.revenue)}
          icon={DollarSign}
          variation={revenueVar}
        />
        <KPICard
          title="Nº Pedidos"
          value={formatNumber(kpis.ordersCount)}
          icon={ShoppingCart}
          variation={ordersVar}
        />
        <KPICard
          title="Ticket Médio"
          value={formatCurrency(kpis.avgTicket)}
          icon={TrendingUp}
          variation={ticketVar}
        />
        <KPICard
          title="Lucro"
          value={formatCurrency(kpis.profit)}
          icon={DollarSign}
          variation={profitVar}
        />
        <KPICard
          title="Margem %"
          value={`${kpis.marginPercent.toFixed(1)}%`}
          icon={TrendingUp}
        />
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-3">
        <KPICard
          title="Contatos Totais"
          value={formatNumber(kpis.totalContacts)}
          icon={Users}
        />
        <KPICard
          title="Ligações"
          value={formatNumber(kpis.totalCalls)}
          icon={Phone}
        />
        <KPICard
          title="WhatsApp"
          value={formatNumber(kpis.totalWhatsapp)}
          icon={MessageCircle}
        />
        <KPICard
          title="Sem Contato 15d+"
          value={formatNumber(kpis.clientsNoContact15Days)}
          icon={AlertTriangle}
          variant={kpis.clientsNoContact15Days > 10 ? 'warning' : 'default'}
        />
        <KPICard
          title="Recorrentes s/ Pedido 45d+"
          value={formatNumber(kpis.recurrentNoOrder45Days)}
          icon={Clock}
          variant={kpis.recurrentNoOrder45Days > 5 ? 'danger' : 'default'}
        />
      </div>
    </div>
  );
}
