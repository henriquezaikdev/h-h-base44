import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { ArrowRight, TrendingUp, TrendingDown, Minus, Info, Percent, Receipt } from 'lucide-react';
import { cn } from '@/lib/utils';

interface EffortResultFlowProps {
  margemBruta: number;
  impostosVendas?: number;
  cdv: number;
  custoHumano: number;
  ceeRateio: number;
  fase3Rateio?: number;
  resultadoReal: number;
  receita?: number;
}

function formatCurrency(value: number): string {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value);
}

interface StepInfo {
  label: string;
  value: number;
  textColor: string;
  bgColor: string;
  borderColor: string;
  icon: typeof TrendingUp;
  isDeduction?: boolean;
  isSubtotal?: boolean;
  isFinal?: boolean;
  explanation: string;
}

export function EffortResultFlow({
  margemBruta,
  impostosVendas = 0,
  cdv,
  custoHumano,
  ceeRateio,
  fase3Rateio = 0,
  resultadoReal,
  receita = 0,
}: EffortResultFlowProps) {
  // Cálculos intermediários
  const margemPosImpostos = margemBruta - impostosVendas;
  const resultadoDireto = margemPosImpostos - cdv;
  const resultadoAposCusto = resultadoDireto - custoHumano;
  
  const steps: StepInfo[] = [
    {
      label: 'Margem Bruta',
      value: margemBruta,
      textColor: 'text-emerald-700 dark:text-emerald-400',
      bgColor: 'bg-emerald-50 dark:bg-emerald-950/30',
      borderColor: 'border-emerald-200 dark:border-emerald-800',
      icon: TrendingUp,
      explanation: 'Dinheiro que sobra da venda depois de tirar o custo da mercadoria.',
    },
  ];

  // Impostos sobre vendas (se houver)
  if (impostosVendas > 0) {
    steps.push({
      label: 'Impostos s/ Vendas',
      value: -impostosVendas,
      textColor: 'text-rose-700 dark:text-rose-400',
      bgColor: 'bg-rose-50 dark:bg-rose-950/30',
      borderColor: 'border-rose-200 dark:border-rose-800',
      icon: Receipt,
      isDeduction: true,
      explanation: 'ICMS, ST, DAS/Simples, etc. Impostos que incidem sobre a venda. Não é CMV.',
    });
  }

  steps.push(
    {
      label: 'CDV (Comissão)',
      value: -cdv,
      textColor: 'text-amber-700 dark:text-amber-400',
      bgColor: 'bg-amber-50 dark:bg-amber-950/30',
      borderColor: 'border-amber-200 dark:border-amber-800',
      icon: Percent,
      isDeduction: true,
      explanation: 'Parte variável da venda, principalmente comissão.',
    },
    {
      label: 'Resultado Direto',
      value: resultadoDireto,
      textColor: resultadoDireto >= 0 ? 'text-blue-700 dark:text-blue-400' : 'text-rose-700 dark:text-rose-400',
      bgColor: resultadoDireto >= 0 ? 'bg-blue-50 dark:bg-blue-950/30' : 'bg-rose-50 dark:bg-rose-950/30',
      borderColor: resultadoDireto >= 0 ? 'border-blue-200 dark:border-blue-800' : 'border-rose-200 dark:border-rose-800',
      icon: resultadoDireto >= 0 ? TrendingUp : TrendingDown,
      isSubtotal: true,
      explanation: 'O que sobra depois de tirar os custos variáveis da venda.',
    },
    {
      label: 'Custo Humano',
      value: -custoHumano,
      textColor: 'text-blue-700 dark:text-blue-400',
      bgColor: 'bg-blue-50 dark:bg-blue-950/30',
      borderColor: 'border-blue-200 dark:border-blue-800',
      icon: Minus,
      isDeduction: true,
      explanation: 'Custo mensal deste vendedor para a empresa.',
    },
    {
      label: 'CEE Fase 2',
      value: -ceeRateio,
      textColor: 'text-violet-700 dark:text-violet-400',
      bgColor: 'bg-violet-50 dark:bg-violet-950/30',
      borderColor: 'border-violet-200 dark:border-violet-800',
      icon: Minus,
      isDeduction: true,
      explanation: 'Parte da estrutura fixa operacional da empresa atribuída a este vendedor (proporcional à meta).',
    },
  );

  if (fase3Rateio > 0) {
    steps.push({
      label: 'Fase 3',
      value: -fase3Rateio,
      textColor: 'text-fuchsia-700 dark:text-fuchsia-400',
      bgColor: 'bg-fuchsia-50 dark:bg-fuchsia-950/30',
      borderColor: 'border-fuchsia-200 dark:border-fuchsia-800',
      icon: Minus,
      isDeduction: true,
      explanation: 'Despesas finais (pró-labore, empréstimos) atribuídas a este vendedor (proporcional à meta).',
    });
  }

  steps.push(
    {
      label: 'Resultado Real',
      value: resultadoReal,
      textColor: resultadoReal >= 0 ? 'text-emerald-800 dark:text-emerald-300' : 'text-rose-800 dark:text-rose-300',
      bgColor: resultadoReal >= 0 ? 'bg-emerald-100 dark:bg-emerald-950/50' : 'bg-rose-100 dark:bg-rose-950/50',
      borderColor: resultadoReal >= 0 ? 'border-emerald-300 dark:border-emerald-700' : 'border-rose-300 dark:border-rose-700',
      icon: resultadoReal >= 0 ? TrendingUp : TrendingDown,
      isFinal: true,
      explanation: 'Saldo final depois de tirar todos os custos.',
    },
  );

  const totalCustos = impostosVendas + cdv + custoHumano + ceeRateio + fase3Rateio;

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-sm flex items-center gap-2">
          <ArrowRight className="h-4 w-4 text-primary" />
          Esforço → Resultado (Waterfall)
        </CardTitle>
      </CardHeader>
      <CardContent>
        <TooltipProvider>
          <div className="flex items-stretch gap-2 overflow-x-auto pb-2">
            {steps.map((step, idx) => {
              const Icon = step.icon;
              const isLast = idx === steps.length - 1;
              
              return (
                <div key={idx} className="flex items-center">
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <div className={cn(
                        'flex flex-col items-center justify-between p-3 rounded-lg border-2 min-w-[120px] cursor-help transition-all hover:shadow-md',
                        step.bgColor,
                        step.borderColor,
                        step.isFinal && 'ring-2 ring-offset-2',
                        step.isFinal && (step.value >= 0 ? 'ring-emerald-400 dark:ring-emerald-600' : 'ring-rose-400 dark:ring-rose-600')
                      )}>
                        <div className="flex items-center gap-1 mb-1">
                          <Icon className={cn('h-3 w-3', step.textColor)} />
                          <span className="text-[10px] font-medium text-muted-foreground uppercase tracking-wide">
                            {step.label}
                          </span>
                          <Info className="h-2.5 w-2.5 text-muted-foreground/50" />
                        </div>
                        <span className={cn(
                          'text-lg font-bold',
                          step.textColor,
                          step.isDeduction && 'opacity-80'
                        )}>
                          {formatCurrency(step.value)}
                        </span>
                        {receita > 0 && step.isDeduction && (
                          <span className="text-[10px] text-muted-foreground">
                            {(Math.abs(step.value) / receita * 100).toFixed(1)}% da receita
                          </span>
                        )}
                        {step.isSubtotal && (
                          <span className="text-[10px] text-muted-foreground mt-1">
                            (qualidade da venda)
                          </span>
                        )}
                        {step.isFinal && (
                          <span className="text-[10px] text-muted-foreground mt-1">
                            {step.value >= 0 ? '✓ Sustenta' : '✗ Não sustenta'}
                          </span>
                        )}
                      </div>
                    </TooltipTrigger>
                    <TooltipContent side="bottom" className="max-w-[200px]">
                      <p className="text-xs">{step.explanation}</p>
                    </TooltipContent>
                  </Tooltip>
                  
                  {!isLast && (
                    <ArrowRight className="h-4 w-4 text-muted-foreground mx-1 shrink-0" />
                  )}
                </div>
              );
            })}
          </div>
        </TooltipProvider>
        
        {/* Summary */}
        <div className="mt-4 pt-3 border-t grid grid-cols-3 gap-4 text-center text-xs">
          <div>
            <p className="text-muted-foreground">Entrada</p>
            <p className="font-semibold text-emerald-600 dark:text-emerald-400">{formatCurrency(margemBruta)}</p>
          </div>
          <div>
            <p className="text-muted-foreground">Custos Totais</p>
            <p className="font-semibold text-rose-600 dark:text-rose-400">{formatCurrency(totalCustos)}</p>
          </div>
          <div>
            <p className="text-muted-foreground">Lucro Líquido</p>
            <p className={cn(
              'font-semibold',
              resultadoReal >= 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'
            )}>{formatCurrency(resultadoReal)}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
