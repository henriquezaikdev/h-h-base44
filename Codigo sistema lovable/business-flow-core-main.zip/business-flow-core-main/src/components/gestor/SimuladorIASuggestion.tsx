import { useState } from 'react';
import { Lightbulb, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { formatCurrency } from '@/lib/utils';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface AIContext {
  totalRevenue: number;
  avgMarginPercent: number;
  ceeTotal: number;
  activeSellers: number;
  avgSellerCost: number;
  avgSellerRevenue: number;
  metaVendas: number;
}

interface AISuggestion {
  salario_sugerido_min: number;
  salario_sugerido_max: number;
  custo_total_estimado: number;
  meta_minima_para_se_pagar: number;
  meta_minima_para_lucro: number;
  analise: string;
  viabilidade: 'VIAVEL' | 'RISCO' | 'INVIAVEL';
}

const viabilidadeConfig: Record<string, { label: string; color: string }> = {
  VIAVEL: { label: 'Viável', color: 'bg-emerald-600 text-white' },
  RISCO: { label: 'Risco', color: 'bg-yellow-500 text-black' },
  INVIAVEL: { label: 'Inviável', color: 'bg-red-600 text-white' },
};

export function SimuladorIASuggestion({ context }: { context: AIContext }) {
  const [loading, setLoading] = useState(false);
  const [suggestion, setSuggestion] = useState<AISuggestion | null>(null);

  const handleSuggest = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('simulador-contratacao-ia', {
        body: context,
      });

      if (error) throw error;
      if (data?.error) throw new Error(data.error);

      setSuggestion(data as AISuggestion);
    } catch (err: any) {
      console.error('AI suggestion error:', err);
      toast.error('Erro ao consultar IA. Tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  const fmt = (v: number) => formatCurrency(v);
  const cfg = suggestion ? viabilidadeConfig[suggestion.viabilidade] || viabilidadeConfig.RISCO : null;

  return (
    <div className="space-y-4">
      <div className="flex justify-center">
        <Button onClick={handleSuggest} disabled={loading} variant="outline" className="gap-2">
          {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Lightbulb className="h-4 w-4" />}
          💡 Sugerir Salário com IA
        </Button>
      </div>

      {suggestion && cfg && (
        <Card>
          <CardContent className="p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="font-semibold">Sugestão da IA</h4>
              <Badge className={cfg.color}>{cfg.label}</Badge>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-3 rounded-lg border">
                <p className="text-xs text-muted-foreground">Faixa Salarial Sugerida</p>
                <p className="text-lg font-bold">
                  {fmt(suggestion.salario_sugerido_min)} — {fmt(suggestion.salario_sugerido_max)}
                </p>
              </div>
              <div className="p-3 rounded-lg border">
                <p className="text-xs text-muted-foreground">Custo Total Estimado</p>
                <p className="text-lg font-bold">{fmt(suggestion.custo_total_estimado)}</p>
              </div>
              <div className="p-3 rounded-lg border">
                <p className="text-xs text-muted-foreground">Meta Mínima para se Pagar</p>
                <p className="text-lg font-bold">{fmt(suggestion.meta_minima_para_se_pagar)}</p>
              </div>
              <div className="p-3 rounded-lg border">
                <p className="text-xs text-muted-foreground">Meta Mínima para Gerar Lucro</p>
                <p className="text-lg font-bold">{fmt(suggestion.meta_minima_para_lucro)}</p>
              </div>
            </div>

            <div className="p-4 rounded-lg bg-muted/50 text-sm whitespace-pre-line">
              {suggestion.analise}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
