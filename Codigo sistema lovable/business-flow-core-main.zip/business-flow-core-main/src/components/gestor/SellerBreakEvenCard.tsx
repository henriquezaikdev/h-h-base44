import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Badge } from '@/components/ui/badge';
import { User, Building2, Landmark, Info, CheckCircle2, AlertTriangle } from 'lucide-react';
import { cn } from '@/lib/utils';

interface SellerBreakEvenCardProps {
  custoDirecto: number;
  metaFase1: number;
  ceeRateio: number;
  metaFase2: number;
  fase3Rateio: number;
  metaFase3: number;
  receita: number;
  margemRealPercent: number;
  commissionEnabled: boolean;
}

function formatCurrency(value: number): string {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value);
}

function PhaseCard({
  icon: Icon,
  title,
  subtitle,
  tooltip,
  custos,
  meta,
  realizado,
  colorScheme,
}: {
  icon: React.ElementType;
  title: string;
  subtitle: string;
  tooltip: string;
  custos: { label: string; value: number }[];
  meta: number;
  realizado: number;
  colorScheme: 'emerald' | 'blue' | 'violet';
}) {
  const falta = Math.max(0, meta - realizado);
  const excedente = Math.max(0, realizado - meta);
  const atingida = realizado >= meta;

  const colorMap = {
    emerald: {
      border: 'border-emerald-200',
      bg: 'bg-emerald-50/50',
      text: 'text-emerald-700',
      bold: 'text-emerald-800',
    },
    blue: {
      border: 'border-blue-200',
      bg: 'bg-blue-50/50',
      text: 'text-blue-700',
      bold: 'text-blue-800',
    },
    violet: {
      border: 'border-violet-200',
      bg: 'bg-violet-50/50',
      text: 'text-violet-700',
      bold: 'text-violet-800',
    },
  };

  const colors = colorMap[colorScheme];

  return (
    <Card className={cn(
      'border-2',
      atingida ? colors.border : 'border-amber-200',
      atingida ? colors.bg : 'bg-amber-50/50'
    )}>
      <CardHeader className="pb-2">
        <CardTitle className="text-sm flex items-center gap-2">
          <Icon className="h-4 w-4 text-primary" />
          {title}
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Info className="h-3.5 w-3.5 text-muted-foreground cursor-help" />
              </TooltipTrigger>
              <TooltipContent className="max-w-xs">
                <p className="text-xs">{tooltip}</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </CardTitle>
        <p className="text-xs text-muted-foreground">{subtitle}</p>
      </CardHeader>
      <CardContent>
        {/* Composição de custos desta fase */}
        <div className={cn('grid gap-2 mb-3', custos.length <= 2 ? 'grid-cols-2' : 'grid-cols-3')}>
          {custos.map((item, idx) => (
            <div key={idx} className="text-center p-2 bg-background rounded-lg border">
              <p className="text-[10px] text-muted-foreground uppercase tracking-wide">{item.label}</p>
              <p className="text-sm font-bold">{formatCurrency(item.value)}</p>
            </div>
          ))}
        </div>

        {/* Meta / Realizado / Falta */}
        <div className="grid grid-cols-3 gap-3 pt-3 border-t">
          <div className="text-center">
            <p className="text-[10px] text-muted-foreground uppercase">Alvo do mês</p>
            <p className={cn('text-lg font-bold', colors.bold)}>{formatCurrency(meta)}</p>
          </div>
          <div className="text-center">
            <p className="text-[10px] text-muted-foreground uppercase">Realizado</p>
            <p className="text-lg font-bold">{formatCurrency(realizado)}</p>
          </div>
          <div className="text-center">
            <p className="text-[10px] text-muted-foreground uppercase">{atingida ? 'Excedente' : 'Falta'}</p>
            <p className={cn(
              'text-lg font-bold',
              atingida ? 'text-emerald-600' : 'text-amber-600'
            )}>
              {formatCurrency(atingida ? excedente : falta)}
            </p>
          </div>
        </div>

        {/* Status */}
        <div className="mt-2 pt-2 border-t flex items-center gap-2 text-xs text-muted-foreground">
          {atingida ? (
            <>
              <CheckCircle2 className="h-3.5 w-3.5 text-emerald-500" />
              <span>Meta desta fase atingida</span>
            </>
          ) : (
            <>
              <AlertTriangle className="h-3.5 w-3.5 text-amber-500" />
              <span>Faltam {formatCurrency(falta)} para atingir esta fase</span>
            </>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

export function SellerBreakEvenCard({
  custoDirecto,
  metaFase1,
  ceeRateio,
  metaFase2,
  fase3Rateio,
  metaFase3,
  receita,
  margemRealPercent,
  commissionEnabled,
}: SellerBreakEvenCardProps) {
  return (
    <div className="space-y-3">
      {/* FASE 1 */}
      <PhaseCard
        icon={User}
        title="FASE 1 — Pagar o próprio custo"
        subtitle="Quanto este vendedor precisa vender no mês para pagar apenas o próprio custo direto."
        tooltip="Inclui salário, encargos, benefícios, ferramentas, deslocamento e comissão (quando ativa). Usa a margem real que já considera CMV, imposto e logística."
        custos={[
          { label: 'Custo direto', value: custoDirecto },
        ]}
        meta={metaFase1}
        realizado={receita}
        colorScheme="emerald"
      />

      {/* FASE 2 */}
      <PhaseCard
        icon={Building2}
        title="FASE 2 — Pagar o próprio custo + estrutura operacional"
        subtitle="Além do próprio custo, inclui a parte da estrutura fixa operacional da empresa atribuída a este vendedor."
        tooltip="O rateio é proporcional à meta do vendedor. CEE Limpo = apenas estrutura operacional, sem pró-labore ou empréstimos."
        custos={[
          { label: 'Custo direto', value: custoDirecto },
          { label: 'CEE rateado', value: ceeRateio },
        ]}
        meta={metaFase2}
        realizado={receita}
        colorScheme="blue"
      />

      {/* FASE 3 */}
      <PhaseCard
        icon={Landmark}
        title="FASE 3 — Pagar fases anteriores + despesas finais"
        subtitle="Acrescenta despesas finais da empresa: pró-labore, empréstimos e parcelamentos."
        tooltip="Despesas finais rateadas proporcionalmente à meta do vendedor. Só nesta fase o vendedor cobre toda a operação."
        custos={[
          { label: 'Total Fase 1', value: custoDirecto },
          { label: 'CEE Fase 2', value: ceeRateio },
          { label: 'Desp. finais', value: fase3Rateio },
        ]}
        meta={metaFase3}
        realizado={receita}
        colorScheme="violet"
      />

      {!commissionEnabled && (
        <Badge variant="outline" className="text-[10px] text-amber-600 border-amber-300">
          Comissão desativada — modo salário fixo
        </Badge>
      )}

      <p className="text-[10px] text-muted-foreground text-center">
        Margem real usada: {margemRealPercent.toFixed(1)}% (já inclui CMV, imposto e logística)
      </p>
    </div>
  );
}
