import { useMemo } from 'react';
import { 
  Rocket, 
  AlertTriangle, 
  TrendingUp, 
  TrendingDown,
  Settings,
  XCircle,
  Target,
  Gauge,
  BarChart3,
  Scale,
  Info,
  Eye
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { cn } from '@/lib/utils';
import type { SellerResult } from '@/hooks/useGestorData';

// =============================================================================
// CAMADA 5 - META, EFICIÊNCIA, POTENCIAL E ESCALA
// Camada analítica GERENCIAL de leitura apenas
// NÃO altera nenhum cálculo financeiro das fases anteriores
// =============================================================================

export interface Layer5Analysis {
  sellerId: string;
  sellerName: string;
  
  // Dados base (somente leitura das fases anteriores)
  metaMensal: number;
  faturamentoReal: number;
  margemBruta: number;
  resultadoReal: number;
  ceeRateio: number;
  
  // Cálculos da Camada 5 (analíticos, sem alterar base)
  eficienciaMeta: number; // % (faturamento / meta)
  eficienciaMetaStatus: 'abaixo' | 'desenvolvimento' | 'cumprida' | 'alta';
  eficienciaMetaLabel: string;
  
  qualidadeResultado: number; // % (resultado real / faturamento)
  
  eficienciaEstrutural: number; // resultado real / CEE rateio
  
  potencialEscala: number; // indicador composto
  potencialEscalaLabel: string;
  
  // Decisão Gerencial
  decisaoGerencial: 'escalar' | 'ajustar_processo' | 'ajustar_margem' | 'risco';
  decisaoGerencialLabel: string;
  decisaoGerencialDescricao: string;
}

interface Layer5Props {
  sellers: SellerResult[];
  metasPorVendedor?: Map<string, number>; // metas individuais se existirem
  onAnalyzeSeller?: (seller: SellerResult) => void;
}

function formatCurrency(value: number): string {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value);
}

function formatPercent(value: number): string {
  return `${value.toFixed(1)}%`;
}

function getEficienciaMetaConfig(eficiencia: number) {
  if (eficiencia >= 120) {
    return { status: 'alta' as const, label: 'Alta Performance', color: 'text-emerald-600', bg: 'bg-emerald-50', border: 'border-emerald-200' };
  }
  if (eficiencia >= 100) {
    return { status: 'cumprida' as const, label: 'Meta Cumprida', color: 'text-blue-600', bg: 'bg-blue-50', border: 'border-blue-200' };
  }
  if (eficiencia >= 70) {
    return { status: 'desenvolvimento' as const, label: 'Em Desenvolvimento', color: 'text-amber-600', bg: 'bg-amber-50', border: 'border-amber-200' };
  }
  return { status: 'abaixo' as const, label: 'Abaixo do Esperado', color: 'text-red-600', bg: 'bg-red-50', border: 'border-red-200' };
}

function getPotencialLabel(potencial: number): string {
  if (potencial >= 1.5) return 'Alto Potencial';
  if (potencial >= 1.0) return 'Potencial Moderado';
  if (potencial >= 0.5) return 'Baixo Potencial';
  return 'Não Escalável';
}

function getDecisaoGerencial(
  resultadoReal: number, 
  eficienciaMeta: number
): { decisao: Layer5Analysis['decisaoGerencial']; label: string; descricao: string } {
  const eficienciaAlta = eficienciaMeta >= 70;
  const resultadoPositivo = resultadoReal > 0;
  
  if (resultadoPositivo && eficienciaAlta) {
    return {
      decisao: 'escalar',
      label: 'ESCALAR',
      descricao: 'Este vendedor cobre seus custos diretos, sustenta a estrutura da empresa e apresenta margem suficiente para crescimento.',
    };
  }
  if (resultadoPositivo && !eficienciaAlta) {
    return {
      decisao: 'ajustar_processo',
      label: 'AJUSTAR PROCESSO',
      descricao: 'O vendedor possui potencial, mas os processos comerciais precisam ser ajustados para melhorar conversão, rotina e eficiência.',
    };
  }
  if (!resultadoPositivo && eficienciaAlta) {
    return {
      decisao: 'ajustar_margem',
      label: 'AJUSTAR PREÇO/MARGEM',
      descricao: 'O volume existe, porém a margem das vendas não sustenta adequadamente a estrutura.',
    };
  }
  return {
    decisao: 'risco',
    label: 'RISCO / REAVALIAR',
    descricao: 'O vendedor não cobre seus custos diretos ou gera prejuízo operacional na configuração atual.',
  };
}

function getDecisaoIcon(decisao: Layer5Analysis['decisaoGerencial']) {
  switch (decisao) {
    case 'escalar': return Rocket;
    case 'ajustar_processo': return Settings;
    case 'ajustar_margem': return TrendingUp;
    case 'risco': return AlertTriangle;
  }
}

function getDecisaoBadge(decisao: Layer5Analysis['decisaoGerencial']) {
  switch (decisao) {
    case 'escalar':
      return { color: 'bg-emerald-500 text-white', textColor: 'text-emerald-700' };
    case 'ajustar_processo':
      return { color: 'bg-amber-500 text-white', textColor: 'text-amber-700' };
    case 'ajustar_margem':
      return { color: 'bg-orange-500 text-white', textColor: 'text-orange-700' };
    case 'risco':
      return { color: 'bg-red-500 text-white', textColor: 'text-red-700' };
  }
}

export function calculateLayer5Analysis(
  sellers: SellerResult[],
  metasPorVendedor?: Map<string, number>
): Layer5Analysis[] {
  return sellers.map(seller => {
    // CORRIGIDO: Meta mensal usa seller_levels.monthly_sales_target como fonte primária
    // Não usar metaMinima (que é break-even) nem revenue * 1.1 (que é estimativa)
    const metaMensal = metasPorVendedor?.get(seller.id) || seller.monthlySalesTarget || 30000;
    
    // Eficiência de Meta = Faturamento Real / Meta Mensal
    const eficienciaMeta = metaMensal > 0 ? (seller.revenue / metaMensal) * 100 : 0;
    const eficienciaConfig = getEficienciaMetaConfig(eficienciaMeta);
    
    // Qualidade de Resultado = Resultado Real / Faturamento Real
    const qualidadeResultado = seller.revenue > 0 
      ? (seller.resultadoReal / seller.revenue) * 100 
      : 0;
    
    // Eficiência Estrutural = Resultado Real / CEE Rateio
    const eficienciaEstrutural = seller.ceeRateio > 0 
      ? seller.resultadoReal / seller.ceeRateio 
      : 0;
    
    // Potencial de Escala = (Resultado Real / Meta) x Eficiência Estrutural
    const resultadoMetaRatio = metaMensal > 0 ? seller.resultadoReal / metaMensal : 0;
    const potencialEscala = resultadoMetaRatio * Math.max(0, eficienciaEstrutural);
    
    // Decisão Gerencial
    const decisao = getDecisaoGerencial(seller.resultadoReal, eficienciaMeta);
    
    return {
      sellerId: seller.id,
      sellerName: seller.name,
      metaMensal,
      faturamentoReal: seller.revenue,
      margemBruta: seller.marginBruta,
      resultadoReal: seller.resultadoReal,
      ceeRateio: seller.ceeRateio,
      eficienciaMeta,
      eficienciaMetaStatus: eficienciaConfig.status,
      eficienciaMetaLabel: eficienciaConfig.label,
      qualidadeResultado,
      eficienciaEstrutural,
      potencialEscala,
      potencialEscalaLabel: getPotencialLabel(potencialEscala),
      decisaoGerencial: decisao.decisao,
      decisaoGerencialLabel: decisao.label,
      decisaoGerencialDescricao: decisao.descricao,
    };
  });
}

function Layer5SellerCard({ 
  analysis, 
  seller,
  onAnalyze 
}: { 
  analysis: Layer5Analysis; 
  seller: SellerResult;
  onAnalyze?: (seller: SellerResult) => void;
}) {
  const DecisaoIcon = getDecisaoIcon(analysis.decisaoGerencial);
  const badgeStyle = getDecisaoBadge(analysis.decisaoGerencial);
  const eficienciaConfig = getEficienciaMetaConfig(analysis.eficienciaMeta);
  
  return (
    <Card className={cn('border-2', eficienciaConfig.border, eficienciaConfig.bg)}>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm font-medium flex items-center gap-2">
            <Gauge className="h-4 w-4 text-muted-foreground" />
            {analysis.sellerName}
          </CardTitle>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger>
                <Badge className={badgeStyle.color}>
                  <DecisaoIcon className="h-3 w-3 mr-1" />
                  {analysis.decisaoGerencialLabel}
                </Badge>
              </TooltipTrigger>
              <TooltipContent side="left" className="max-w-xs">
                <p className="text-sm">{analysis.decisaoGerencialDescricao}</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        {/* Meta e Faturamento */}
        <div className="grid grid-cols-2 gap-2 text-xs">
          <div>
            <span className="text-muted-foreground">Meta</span>
            <p className="font-semibold">{formatCurrency(analysis.metaMensal)}</p>
          </div>
          <div>
            <span className="text-muted-foreground">Faturado</span>
            <p className="font-semibold">{formatCurrency(analysis.faturamentoReal)}</p>
          </div>
        </div>
        
        {/* Eficiência de Meta */}
        <div className="space-y-1">
          <div className="flex justify-between items-center text-xs">
            <span className="text-muted-foreground flex items-center gap-1">
              <Target className="h-3 w-3" />
              Eficiência de Meta
            </span>
            <span className={cn('font-medium', eficienciaConfig.color)}>
              {formatPercent(analysis.eficienciaMeta)}
            </span>
          </div>
          <Progress 
            value={Math.min(analysis.eficienciaMeta, 150)} 
            max={150}
            className="h-2"
          />
          <p className={cn('text-[10px]', eficienciaConfig.color)}>
            {analysis.eficienciaMetaLabel}
          </p>
        </div>
        
        {/* Indicadores */}
        <div className="grid grid-cols-2 gap-2 pt-2 border-t">
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger className="text-left">
                <div className="text-xs">
                  <span className="text-muted-foreground flex items-center gap-1">
                    <BarChart3 className="h-3 w-3" />
                    Qualidade
                  </span>
                  <p className={cn(
                    'font-semibold',
                    analysis.qualidadeResultado >= 0 ? 'text-emerald-600' : 'text-red-600'
                  )}>
                    {formatPercent(analysis.qualidadeResultado)}
                  </p>
                </div>
              </TooltipTrigger>
              <TooltipContent>
                <p>Resultado Real / Faturamento</p>
                <p className="text-muted-foreground">Mede lucro saudável vs sacrifício de margem</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
          
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger className="text-left">
                <div className="text-xs">
                  <span className="text-muted-foreground flex items-center gap-1">
                    <Scale className="h-3 w-3" />
                    Efic. Estrutural
                  </span>
                  <p className={cn(
                    'font-semibold',
                    analysis.eficienciaEstrutural >= 1 ? 'text-emerald-600' : 
                    analysis.eficienciaEstrutural >= 0 ? 'text-amber-600' : 'text-red-600'
                  )}>
                    {analysis.eficienciaEstrutural.toFixed(2)}x
                  </p>
                </div>
              </TooltipTrigger>
              <TooltipContent>
                <p>Resultado Real / CEE Rateado</p>
                <p className="text-muted-foreground">&gt;1 = sustenta a estrutura com excedente</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
        
        {/* Potencial de Escala */}
        <div className="pt-2 border-t">
          <div className="flex justify-between items-center">
            <span className="text-xs text-muted-foreground flex items-center gap-1">
              <Rocket className="h-3 w-3" />
              Potencial de Escala
            </span>
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Badge variant="outline" className={cn(
                    'text-xs cursor-help',
                    analysis.potencialEscala >= 1.5 ? 'border-emerald-300 text-emerald-700' :
                    analysis.potencialEscala >= 1.0 ? 'border-blue-300 text-blue-700' :
                    analysis.potencialEscala >= 0.5 ? 'border-amber-300 text-amber-700' :
                    'border-red-300 text-red-700'
                  )}>
                    {analysis.potencialEscalaLabel}
                  </Badge>
                </TooltipTrigger>
                <TooltipContent className="max-w-xs">
                  {analysis.potencialEscala >= 1.5 ? (
                    <p className="text-xs">Mesmo vendendo, ainda não há folga suficiente para ampliar operação com segurança.</p>
                  ) : analysis.potencialEscala < 0.5 ? (
                    <p className="text-xs">Mesmo vendendo, ainda não há folga suficiente para ampliar operação com segurança.</p>
                  ) : (
                    <p className="text-xs">Indicador composto de potencial de crescimento baseado em meta, resultado e eficiência estrutural.</p>
                  )}
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
        </div>
        
        {/* Analyze Button */}
        {onAnalyze && (
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="outline"
                  size="sm"
                  className="w-full mt-2"
                  onClick={() => onAnalyze(seller)}
                >
                  <Eye className="h-3 w-3 mr-2" />
                  Analisar Vendedor
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p className="text-xs">Abre a análise detalhada deste vendedor, mostrando faturamento, custos, estrutura e leitura gerencial.</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        )}
      </CardContent>
    </Card>
  );
}

function Layer5Summary({ analyses }: { analyses: Layer5Analysis[] }) {
  const summary = useMemo(() => {
    const total = analyses.length;
    const escalar = analyses.filter(a => a.decisaoGerencial === 'escalar').length;
    const ajustarProcesso = analyses.filter(a => a.decisaoGerencial === 'ajustar_processo').length;
    const ajustarMargem = analyses.filter(a => a.decisaoGerencial === 'ajustar_margem').length;
    const risco = analyses.filter(a => a.decisaoGerencial === 'risco').length;
    
    const altaPerformance = analyses.filter(a => a.eficienciaMetaStatus === 'alta').length;
    const metaCumprida = analyses.filter(a => a.eficienciaMetaStatus === 'cumprida').length;
    const desenvolvimento = analyses.filter(a => a.eficienciaMetaStatus === 'desenvolvimento').length;
    const abaixo = analyses.filter(a => a.eficienciaMetaStatus === 'abaixo').length;
    
    const altoPotencial = analyses.filter(a => a.potencialEscala >= 1.5).length;
    
    return {
      total,
      escalar,
      ajustarProcesso,
      ajustarMargem,
      risco,
      altaPerformance,
      metaCumprida,
      desenvolvimento,
      abaixo,
      altoPotencial,
    };
  }, [analyses]);
  
  return (
    <Card className="border-2 border-primary/30 bg-gradient-to-r from-primary/5 to-transparent">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-medium flex items-center gap-2">
          <TrendingUp className="h-4 w-4 text-primary" />
          Camada 5 - Análise Estratégica (Resumo)
        </CardTitle>
      </CardHeader>
      <CardContent>
        {/* Matriz de Decisão */}
        <div className="mb-4">
          <p className="text-xs text-muted-foreground mb-2 font-medium">Matriz de Decisão Gerencial</p>
          <div className="grid grid-cols-4 gap-2">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <div className="flex items-center gap-2 p-2 rounded bg-emerald-50 border border-emerald-200 cursor-help">
                    <Rocket className="h-4 w-4 text-emerald-600" />
                    <div>
                      <p className="text-lg font-bold text-emerald-700">{summary.escalar}</p>
                      <p className="text-[10px] text-emerald-600">Escalar</p>
                    </div>
                  </div>
                </TooltipTrigger>
                <TooltipContent className="max-w-xs">
                  <p className="text-xs">Este vendedor cobre seu custo direto, ajuda a pagar a estrutura da empresa e apresenta espaço para crescimento com segurança.</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <div className="flex items-center gap-2 p-2 rounded bg-amber-50 border border-amber-200 cursor-help">
                    <Settings className="h-4 w-4 text-amber-600" />
                    <div>
                      <p className="text-lg font-bold text-amber-700">{summary.ajustarProcesso}</p>
                      <p className="text-[10px] text-amber-600">Ajustar Proc.</p>
                    </div>
                  </div>
                </TooltipTrigger>
                <TooltipContent className="max-w-xs">
                  <p className="text-xs">O vendedor tem potencial, mas precisa melhorar processo comercial, rotina, conversão ou disciplina operacional.</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <div className="flex items-center gap-2 p-2 rounded bg-orange-50 border border-orange-200 cursor-help">
                    <TrendingDown className="h-4 w-4 text-orange-600" />
                    <div>
                      <p className="text-lg font-bold text-orange-700">{summary.ajustarMargem}</p>
                      <p className="text-[10px] text-orange-600">Ajustar Margem</p>
                    </div>
                  </div>
                </TooltipTrigger>
                <TooltipContent className="max-w-xs">
                  <p className="text-xs">O vendedor vende, mas a margem das vendas não está sustentando a operação como deveria.</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <div className="flex items-center gap-2 p-2 rounded bg-red-50 border border-red-200 cursor-help">
                    <XCircle className="h-4 w-4 text-red-600" />
                    <div>
                      <p className="text-lg font-bold text-red-700">{summary.risco}</p>
                      <p className="text-[10px] text-red-600">Risco</p>
                    </div>
                  </div>
                </TooltipTrigger>
                <TooltipContent className="max-w-xs">
                  <p className="text-xs">O vendedor ainda não cobre adequadamente os custos e precisa de revisão imediata.</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
        </div>
        
        {/* Eficiência de Meta */}
        <div className="mb-4">
          <p className="text-xs text-muted-foreground mb-2 font-medium">Eficiência de Meta</p>
          <div className="grid grid-cols-4 gap-2">
            <div className="text-center p-2 rounded bg-emerald-50 border border-emerald-200">
              <p className="text-lg font-bold text-emerald-700">{summary.altaPerformance}</p>
              <p className="text-[10px] text-emerald-600">Alta Perf. (≥120%)</p>
            </div>
            <div className="text-center p-2 rounded bg-blue-50 border border-blue-200">
              <p className="text-lg font-bold text-blue-700">{summary.metaCumprida}</p>
              <p className="text-[10px] text-blue-600">Cumprida (100-119%)</p>
            </div>
            <div className="text-center p-2 rounded bg-amber-50 border border-amber-200">
              <p className="text-lg font-bold text-amber-700">{summary.desenvolvimento}</p>
              <p className="text-[10px] text-amber-600">Em Desenv. (70-99%)</p>
            </div>
            <div className="text-center p-2 rounded bg-red-50 border border-red-200">
              <p className="text-lg font-bold text-red-700">{summary.abaixo}</p>
              <p className="text-[10px] text-red-600">Abaixo (&lt;70%)</p>
            </div>
          </div>
        </div>
        
        {/* Destaque */}
        <div className="p-3 bg-primary/10 rounded-lg flex items-start gap-2">
          <Info className="h-4 w-4 text-primary mt-0.5 shrink-0" />
          <div className="text-xs">
            <p className="font-medium text-primary">
              {summary.altoPotencial} vendedor{summary.altoPotencial !== 1 ? 'es' : ''} com alto potencial de escala
            </p>
            <p className="text-muted-foreground mt-1">
              Esta camada é analítica e não altera os cálculos financeiros das Fases 0-4.
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export function Layer5StrategicAnalysis({ sellers, metasPorVendedor, onAnalyzeSeller }: Layer5Props) {
  const analyses = useMemo(() => 
    calculateLayer5Analysis(sellers, metasPorVendedor),
    [sellers, metasPorVendedor]
  );
  
  // Ordenar por decisão gerencial (escalar primeiro, risco por último)
  const sortedAnalyses = useMemo(() => {
    const order = { escalar: 0, ajustar_processo: 1, ajustar_margem: 2, risco: 3 };
    return [...analyses].sort((a, b) => 
      order[a.decisaoGerencial] - order[b.decisaoGerencial]
    );
  }, [analyses]);
  
  if (sellers.length === 0) {
    return (
      <Card className="border-dashed">
        <CardContent className="py-8 text-center text-muted-foreground">
          <Gauge className="h-8 w-8 mx-auto mb-2 opacity-50" />
          <p>Nenhum vendedor para análise</p>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <div className="space-y-4">
      <Layer5Summary analyses={analyses} />
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {sortedAnalyses.map(analysis => {
          const seller = sellers.find(s => s.id === analysis.sellerId);
          return seller ? (
            <Layer5SellerCard 
              key={analysis.sellerId} 
              analysis={analysis} 
              seller={seller}
              onAnalyze={onAnalyzeSeller}
            />
          ) : null;
        })}
      </div>
    </div>
  );
}
