import { useState, useEffect, useMemo } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Shield, Search, Calendar, User, Filter } from 'lucide-react';
import { format, subDays } from 'date-fns';
import { ptBR } from 'date-fns/locale';

const sb = supabase as any;

interface AuditEvent {
  id: string;
  type: string;
  category: string;
  actor_name: string;
  target_name: string;
  description: string;
  created_at: string;
  meta: any;
}

const CATEGORY_CONFIG: Record<string, { label: string; color: string; icon: string }> = {
  XP: { label: 'XP', color: 'bg-blue-100 text-blue-700', icon: '⚡' },
  HCOIN: { label: 'HCoin', color: 'bg-amber-100 text-amber-700', icon: '🪙' },
  ESTRELA: { label: 'Estrela', color: 'bg-purple-100 text-purple-700', icon: '⭐' },
  NIVEL: { label: 'Nível', color: 'bg-emerald-100 text-emerald-700', icon: '📊' },
  CAMPANHA: { label: 'Campanha', color: 'bg-pink-100 text-pink-700', icon: '🏆' },
  LOJA: { label: 'Loja', color: 'bg-orange-100 text-orange-700', icon: '🛍️' },
  RECONHECIMENTO: { label: 'Reconhecimento', color: 'bg-rose-100 text-rose-700', icon: '❤️' },
  REGULAMENTO: { label: 'Regulamento', color: 'bg-gray-100 text-gray-700', icon: '📋' },
  SISTEMA: { label: 'Sistema', color: 'bg-slate-100 text-slate-700', icon: '⚙️' },
};

export function GestorAuditoriaTab() {
  const [events, setEvents] = useState<AuditEvent[]>([]);
  const [sellers, setSellers] = useState<{ id: string; name: string }[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterSeller, setFilterSeller] = useState('all');
  const [filterCategory, setFilterCategory] = useState('all');
  const [filterSearch, setFilterSearch] = useState('');
  const [filterDays, setFilterDays] = useState('30');

  useEffect(() => {
    fetchSellers();
    fetchAuditData();
  }, [filterDays]);

  const fetchSellers = async () => {
    const { data } = await supabase.from('sellers').select('id, name').eq('status', 'ATIVO').order('name');
    setSellers(data || []);
  };

  const fetchAuditData = async () => {
    setLoading(true);
    const since = subDays(new Date(), parseInt(filterDays)).toISOString();
    const allEvents: AuditEvent[] = [];

    // Fetch from multiple log tables in parallel
    const [xpLogs, hcoinLogs, starLogs, levelLogs, shopOrders, rulebookAccepts] = await Promise.all([
      // XP logs
      sb.from('xp_log').select('id, user_id, event_type, xp_delta, meta_json, created_at')
        .gte('created_at', since).order('created_at', { ascending: false }).limit(200),
      // HCoin logs
      sb.from('hcoins_log').select('id, seller_id, event_type, amount, description, created_at')
        .gte('created_at', since).order('created_at', { ascending: false }).limit(200),
      // Star ledger
      sb.from('star_ledger').select('id, seller_id, star_type, delta, reason, created_at, granted_by')
        .gte('created_at', since).order('created_at', { ascending: false }).limit(200),
      // Level changes
      sb.from('sales_level_log').select('id, user_id, from_level, to_level, reason, changed_at')
        .gte('changed_at', since).order('changed_at', { ascending: false }).limit(100),
      // Shop orders
      sb.from('shop_orders').select('id, user_id, item_name, status, total_price, created_at')
        .gte('created_at', since).order('created_at', { ascending: false }).limit(100),
      // Rulebook accepts
      sb.from('rulebook_acceptance').select('id, user_id, accepted_at')
        .gte('accepted_at', since).order('accepted_at', { ascending: false }).limit(100),
    ]);

    const sellerMap = new Map<string, string>();
    (await supabase.from('sellers').select('id, name')).data?.forEach((s: any) => sellerMap.set(s.id, s.name));
    const getName = (id: string) => sellerMap.get(id) || 'Desconhecido';

    // Process XP
    (xpLogs.data || []).forEach((l: any) => {
      const desc = l.meta_json?.description || '';
      allEvents.push({
        id: l.id, type: l.event_type, category: 'XP',
        actor_name: '', target_name: getName(l.user_id),
        description: `${l.event_type}: ${l.xp_delta > 0 ? '+' : ''}${l.xp_delta} XP${desc ? ' — ' + desc : ''}`,
        created_at: l.created_at, meta: l,
      });
    });

    // Process HCoins
    (hcoinLogs.data || []).forEach((l: any) => allEvents.push({
      id: l.id, type: l.event_type, category: 'HCOIN',
      actor_name: '', target_name: getName(l.seller_id),
      description: `${l.event_type}: ${l.amount > 0 ? '+' : ''}${l.amount} HCoins${l.description ? ' — ' + l.description : ''}`,
      created_at: l.created_at, meta: l,
    }));

    // Process Stars
    (starLogs.data || []).forEach((l: any) => allEvents.push({
      id: l.id, type: 'STAR_' + l.star_type, category: 'ESTRELA',
      actor_name: l.granted_by ? getName(l.granted_by) : 'Sistema',
      target_name: getName(l.seller_id),
      description: `${l.delta > 0 ? '+' : ''}${l.delta} ⭐${l.star_type}${l.reason ? ' — ' + l.reason : ''}`,
      created_at: l.created_at, meta: l,
    }));

    // Process Levels
    (levelLogs.data || []).forEach((l: any) => allEvents.push({
      id: l.id, type: 'LEVEL_CHANGE', category: 'NIVEL',
      actor_name: 'Sistema', target_name: getName(l.user_id),
      description: `Nível: ${l.from_level || '—'} → ${l.to_level}${l.reason ? ' (' + l.reason + ')' : ''}`,
      created_at: l.changed_at, meta: l,
    }));

    // Process Shop
    (shopOrders.data || []).forEach((l: any) => allEvents.push({
      id: l.id, type: 'SHOP_' + l.status, category: 'LOJA',
      actor_name: getName(l.user_id), target_name: '',
      description: `Loja: ${l.item_name} (${l.status}) — ${l.total_price} HCoins`,
      created_at: l.created_at, meta: l,
    }));

    // Process Rulebook
    (rulebookAccepts.data || []).forEach((l: any) => allEvents.push({
      id: l.id, type: 'RULEBOOK_ACCEPT', category: 'REGULAMENTO',
      actor_name: getName(l.user_id), target_name: '',
      description: `Aceite do regulamento registrado`,
      created_at: l.accepted_at, meta: l,
    }));

    // Sort by date desc
    allEvents.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
    setEvents(allEvents);
    setLoading(false);
  };

  const filtered = useMemo(() => {
    return events.filter(e => {
      if (filterCategory !== 'all' && e.category !== filterCategory) return false;
      if (filterSeller !== 'all') {
        const sellerName = sellers.find(s => s.id === filterSeller)?.name || '';
        if (!e.target_name.includes(sellerName) && !e.actor_name.includes(sellerName)) return false;
      }
      if (filterSearch) {
        const q = filterSearch.toLowerCase();
        if (!e.description.toLowerCase().includes(q) && !e.target_name.toLowerCase().includes(q) && !e.actor_name.toLowerCase().includes(q)) return false;
      }
      return true;
    });
  }, [events, filterCategory, filterSeller, filterSearch, sellers]);

  return (
    <div className="space-y-4">
      <Card className="bg-card/80 backdrop-blur-sm rounded-2xl shadow-sm border border-border/50">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <Shield className="h-4 w-4 text-primary" /> Modo Auditoria
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Filters */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <div>
              <Label className="text-xs">Colaborador</Label>
              <Select value={filterSeller} onValueChange={setFilterSeller}>
                <SelectTrigger className="rounded-xl h-9 text-xs"><SelectValue placeholder="Todos" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos</SelectItem>
                  {sellers.map(s => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Categoria</Label>
              <Select value={filterCategory} onValueChange={setFilterCategory}>
                <SelectTrigger className="rounded-xl h-9 text-xs"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas</SelectItem>
                  {Object.entries(CATEGORY_CONFIG).map(([k, v]) => (
                    <SelectItem key={k} value={k}>{v.icon} {v.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Período</Label>
              <Select value={filterDays} onValueChange={setFilterDays}>
                <SelectTrigger className="rounded-xl h-9 text-xs"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="7">7 dias</SelectItem>
                  <SelectItem value="30">30 dias</SelectItem>
                  <SelectItem value="90">90 dias</SelectItem>
                  <SelectItem value="180">180 dias</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Busca</Label>
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-muted-foreground" />
                <Input
                  value={filterSearch}
                  onChange={e => setFilterSearch(e.target.value)}
                  className="rounded-xl h-9 text-xs pl-8"
                  placeholder="Buscar..."
                />
              </div>
            </div>
          </div>

          {/* Summary */}
          <div className="flex items-center gap-3 text-xs text-muted-foreground">
            <span>{filtered.length} eventos encontrados</span>
            <div className="flex gap-1.5 flex-wrap">
              {Object.entries(CATEGORY_CONFIG).map(([k, v]) => {
                const count = filtered.filter(e => e.category === k).length;
                if (count === 0) return null;
                return (
                  <Badge key={k} variant="outline" className={`text-[9px] rounded-lg ${v.color}`}>
                    {v.icon} {count}
                  </Badge>
                );
              })}
            </div>
          </div>

          {/* Timeline */}
          {loading ? (
            <div className="py-12 text-center text-muted-foreground animate-pulse text-sm">Carregando logs...</div>
          ) : (
            <ScrollArea className="h-[500px]">
              <div className="space-y-1.5">
                {filtered.length === 0 && (
                  <div className="py-12 text-center text-muted-foreground text-sm">Nenhum evento encontrado</div>
                )}
                {filtered.map(e => {
                  const cat = CATEGORY_CONFIG[e.category] || CATEGORY_CONFIG.SISTEMA;
                  return (
                    <div key={e.id} className="flex items-start gap-3 p-2.5 rounded-xl hover:bg-muted/40 transition-colors">
                      <span className="text-sm mt-0.5">{cat.icon}</span>
                      <div className="flex-1 min-w-0">
                        <p className="text-xs text-foreground leading-relaxed">{e.description}</p>
                        <div className="flex items-center gap-2 mt-0.5">
                          {e.target_name && (
                            <span className="text-[10px] text-muted-foreground flex items-center gap-0.5">
                              <User className="h-2.5 w-2.5" /> {e.target_name}
                            </span>
                          )}
                          <span className="text-[10px] text-muted-foreground flex items-center gap-0.5">
                            <Calendar className="h-2.5 w-2.5" />
                            {format(new Date(e.created_at), "dd/MM HH:mm", { locale: ptBR })}
                          </span>
                        </div>
                      </div>
                      <Badge className={`text-[9px] rounded-lg shrink-0 ${cat.color}`}>{cat.label}</Badge>
                    </div>
                  );
                })}
              </div>
            </ScrollArea>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
