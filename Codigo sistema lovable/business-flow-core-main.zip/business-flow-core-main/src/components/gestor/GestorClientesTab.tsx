import { Users } from 'lucide-react';
import { GoogleAdsROIPanel } from './GoogleAdsROIPanel';
import { ClientsByOriginReport } from './ClientsByOriginReport';
import { Top20AlertsPanel } from './Top20AlertsPanel';
import { Top20PerformancePanel } from './Top20PerformancePanel';

interface GestorClientesTabProps {
  startDate: Date;
  endDate: Date;
  sellerId: string | null;
  googleAdsInvestment: number;
  companyCostId?: string;
  onInvestimentoChange: () => void;
}

export function GestorClientesTab({
  startDate,
  endDate,
  sellerId,
  googleAdsInvestment,
  companyCostId,
  onInvestimentoChange,
}: GestorClientesTabProps) {
  return (
    <div className="space-y-6">
      {/* Header da Aba */}
      <div className="flex items-center gap-2">
        <Users className="h-5 w-5 text-primary" />
        <h2 className="text-lg font-semibold">Análise de Clientes</h2>
      </div>

      {/* ALERTAS TOP 20 - Prioridade máxima */}
      <Top20AlertsPanel sellerId={sellerId} />

      {/* PERFORMANCE TOP 20 + CONCENTRAÇÃO */}
      <Top20PerformancePanel 
        startDate={startDate}
        endDate={endDate}
        sellerId={sellerId}
      />

      {/* ROI GOOGLE ADS */}
      <GoogleAdsROIPanel 
        startDate={startDate}
        endDate={endDate}
        investimento={googleAdsInvestment || 0}
        companyCostId={companyCostId}
        onInvestimentoChange={onInvestimentoChange}
      />

      {/* RELATÓRIO DE CLIENTES POR ORIGEM */}
      <ClientsByOriginReport
        startDate={startDate}
        endDate={endDate}
        sellerId={sellerId}
      />
    </div>
  );
}
