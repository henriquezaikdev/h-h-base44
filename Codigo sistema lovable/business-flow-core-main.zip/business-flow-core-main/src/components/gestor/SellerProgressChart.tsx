import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Target, TrendingUp, TrendingDown, AlertCircle } from 'lucide-react';
import { cn } from '@/lib/utils';

interface SellerProgressChartProps {
  revenue: number;
  meta: number;
  eficiencia: number;
}

function formatCurrency(value: number): string {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value);
}

function getStatusConfig(eficiencia: number) {
  if (eficiencia >= 120) {
    return { 
      label: 'Alta Performance', 
      color: 'text-emerald-600', 
      bg: 'bg-emerald-50',
      border: 'border-emerald-200',
      icon: TrendingUp,
      progressColor: 'bg-emerald-500'
    };
  }
  if (eficiencia >= 100) {
    return { 
      label: 'Meta Cumprida', 
      color: 'text-blue-600', 
      bg: 'bg-blue-50',
      border: 'border-blue-200',
      icon: Target,
      progressColor: 'bg-blue-500'
    };
  }
  if (eficiencia >= 70) {
    return { 
      label: 'Em Desenvolvimento', 
      color: 'text-amber-600', 
      bg: 'bg-amber-50',
      border: 'border-amber-200',
      icon: AlertCircle,
      progressColor: 'bg-amber-500'
    };
  }
  return { 
    label: 'Abaixo do Esperado', 
    color: 'text-red-600', 
    bg: 'bg-red-50',
    border: 'border-red-200',
    icon: TrendingDown,
    progressColor: 'bg-red-500'
  };
}

export function SellerProgressChart({ revenue, meta, eficiencia }: SellerProgressChartProps) {
  const config = getStatusConfig(eficiencia);
  const StatusIcon = config.icon;
  const progressValue = Math.min(eficiencia, 150);
  const gap = meta - revenue;

  return (
    <Card className={cn('border-2', config.border)}>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm flex items-center gap-2">
            <Target className="h-4 w-4 text-primary" />
            Progresso da Meta
          </CardTitle>
          <Badge className={cn(config.bg, config.color, 'border-0')}>
            <StatusIcon className="h-3 w-3 mr-1" />
            {config.label}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Progress Bar */}
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Faturamento</span>
            <span className="font-medium">{formatCurrency(revenue)}</span>
          </div>
          <div className="relative">
            <Progress 
              value={progressValue} 
              max={150}
              className="h-4"
            />
            {/* Meta marker */}
            <div 
              className="absolute top-0 h-full w-0.5 bg-foreground/50"
              style={{ left: `${(100 / 150) * 100}%` }}
            />
          </div>
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>0%</span>
            <span className="font-medium">Meta: {formatCurrency(meta)}</span>
            <span>150%</span>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-4 pt-2 border-t">
          <div className="text-center">
            <p className="text-xs text-muted-foreground">Eficiência</p>
            <p className={cn('text-lg font-bold', config.color)}>
              {eficiencia.toFixed(0)}%
            </p>
          </div>
          <div className="text-center">
            <p className="text-xs text-muted-foreground">
              {gap > 0 ? 'Falta' : 'Excedente'}
            </p>
            <p className={cn(
              'text-lg font-bold',
              gap > 0 ? 'text-amber-600' : 'text-emerald-600'
            )}>
              {formatCurrency(Math.abs(gap))}
            </p>
          </div>
          <div className="text-center">
            <p className="text-xs text-muted-foreground">Meta</p>
            <p className="text-lg font-bold text-muted-foreground">
              {formatCurrency(meta)}
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
