import { useMemo } from 'react';
import { TrendingUp, Activity, Target, ShieldCheck, Coins, Info } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { cn } from '@/lib/utils';
import type { SellerROI, UsageQuality } from '@/hooks/useGestorData';

interface SellerPotentialScoreProps {
  seller: SellerROI;
  quality: UsageQuality | undefined;
  dailyContactsTarget: number;
  periodDays: number;
}

interface ScoreAxis {
  name: string;
  icon: typeof Activity;
  score: number;
  maxScore: number;
  details: string;
}

function getClassification(score: number): { label: string; color: string; recommendation: string } {
  if (score >= 80) {
    return {
      label: 'Escalar Agora',
      color: 'text-emerald-500',
      recommendation: 'Aumentar carteira e metas. Vendedor em alta performance.',
    };
  }
  if (score >= 60) {
    return {
      label: 'Escalar com Ajustes',
      color: 'text-amber-500',
      recommendation: 'Potencial identificado. Investir em treinamento e processos.',
    };
  }
  if (score >= 40) {
    return {
      label: 'Manter e Corrigir',
      color: 'text-orange-500',
      recommendation: 'Identificar gaps específicos. Acompanhamento próximo necessário.',
    };
  }
  return {
    label: 'Reavaliar',
    color: 'text-destructive',
    recommendation: 'Rever carteira, ticket, mix de produtos e custos. Avaliar viabilidade.',
  };
}

function getRecommendations(
  activityScore: number,
  conversionScore: number,
  roiRevenue: number
): string[] {
  const recommendations: string[] = [];

  if (activityScore >= 15 && conversionScore < 15) {
    recommendations.push('Alta atividade, baixa conversão: Treinar abordagem e qualificar carteira');
  }
  if (activityScore < 15 && conversionScore >= 15) {
    recommendations.push('Potencial subutilizado: Aumentar volume de contatos');
  }
  if (roiRevenue < 2) {
    recommendations.push('ROI baixo: Rever carteira, ticket médio, mix de produtos e custos');
  }

  return recommendations;
}

export function SellerPotentialScore({
  seller,
  quality,
  dailyContactsTarget,
  periodDays,
}: SellerPotentialScoreProps) {
  const scores = useMemo<ScoreAxis[]>(() => {
    // Eixo 1: Atividade (0-25)
    const contactsExpected = dailyContactsTarget * periodDays;
    const contactsRatio = contactsExpected > 0 ? seller.contacts / contactsExpected : 0;
    const activityScore = Math.min(25, Math.round(contactsRatio * 25));

    // Eixo 2: Conversão (0-25)
    const conversionIdeal = 15; // 15% é considerado bom
    const conversionRatio = Math.min(1, seller.conversionRate / conversionIdeal);
    const conversionScore = Math.round(conversionRatio * 25);

    // Eixo 3: Qualidade (0-25)
    const qualityMetrics = quality || {
      tasksOnTimePercent: 100,
      overdueReturns: 0,
      avgObservationLength: 0,
      tasksWithoutObservation: 0,
    };
    
    let qualityScore = 0;
    qualityScore += Math.round((qualityMetrics.tasksOnTimePercent / 100) * 10);
    qualityScore += qualityMetrics.overdueReturns === 0 ? 5 : Math.max(0, 5 - qualityMetrics.overdueReturns);
    qualityScore += qualityMetrics.avgObservationLength >= 20 ? 5 : Math.round((qualityMetrics.avgObservationLength / 20) * 5);
    qualityScore += qualityMetrics.tasksWithoutObservation === 0 ? 5 : Math.max(0, 5 - qualityMetrics.tasksWithoutObservation);
    qualityScore = Math.min(25, qualityScore);

    // Eixo 4: Economia (0-25)
    let economyScore = 0;
    if (seller.periodCost > 0) {
      const profitAfterCost = seller.profit - seller.periodCost;
      
      // ROI Receita (0-10)
      if (seller.roiRevenue >= 3) economyScore += 10;
      else if (seller.roiRevenue >= 2) economyScore += 7;
      else if (seller.roiRevenue >= 1) economyScore += 4;
      
      // Lucro após custo (0-10)
      if (profitAfterCost > seller.periodCost) economyScore += 10;
      else if (profitAfterCost > 0) economyScore += 6;
      else economyScore += 0;
      
      // Custo por pedido razoável (0-5)
      const costPerOrder = seller.ordersCount > 0 ? seller.periodCost / seller.ordersCount : 999999;
      if (costPerOrder < 100) economyScore += 5;
      else if (costPerOrder < 200) economyScore += 3;
      else economyScore += 1;
    } else {
      economyScore = 12; // Neutro se não há custo configurado
    }
    economyScore = Math.min(25, economyScore);

    return [
      {
        name: 'Atividade',
        icon: Activity,
        score: activityScore,
        maxScore: 25,
        details: `${seller.contacts} contatos (meta: ${contactsExpected})`,
      },
      {
        name: 'Conversão',
        icon: Target,
        score: conversionScore,
        maxScore: 25,
        details: `${seller.conversionRate.toFixed(1)}% (ideal: ${conversionIdeal}%)`,
      },
      {
        name: 'Qualidade',
        icon: ShieldCheck,
        score: qualityScore,
        maxScore: 25,
        details: `${qualityMetrics.tasksOnTimePercent.toFixed(0)}% no prazo, ${qualityMetrics.overdueReturns} retornos vencidos`,
      },
      {
        name: 'Economia',
        icon: Coins,
        score: economyScore,
        maxScore: 25,
        details: `ROI: ${seller.roiRevenue.toFixed(1)}x`,
      },
    ];
  }, [seller, quality, dailyContactsTarget, periodDays]);

  const totalScore = scores.reduce((sum, s) => sum + s.score, 0);
  const classification = getClassification(totalScore);
  const recommendations = getRecommendations(
    scores[0].score,
    scores[1].score,
    seller.roiRevenue
  );

  return (
    <Card className="border-primary/20">
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center justify-between text-base">
          <div className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-primary" />
            Score Potencial: {seller.name}
          </div>
          <div className="flex items-center gap-2">
            <span className="text-3xl font-bold">{totalScore}</span>
            <span className="text-muted-foreground">/100</span>
            <Badge variant="outline" className={cn('ml-2', classification.color)}>
              {classification.label}
            </Badge>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Progress bars por eixo */}
        <div className="grid grid-cols-4 gap-4">
          {scores.map((axis) => (
            <TooltipProvider key={axis.name}>
              <Tooltip>
                <TooltipTrigger className="text-left">
                  <div className="space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="flex items-center gap-1 text-muted-foreground">
                        <axis.icon className="h-3 w-3" />
                        {axis.name}
                      </span>
                      <span className="font-medium">{axis.score}/{axis.maxScore}</span>
                    </div>
                    <Progress value={(axis.score / axis.maxScore) * 100} className="h-2" />
                  </div>
                </TooltipTrigger>
                <TooltipContent>
                  <p>{axis.details}</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          ))}
        </div>

        {/* Recomendação principal */}
        <div className="flex items-start gap-2 p-3 bg-muted/50 rounded-lg">
          <Info className="h-4 w-4 mt-0.5 text-muted-foreground shrink-0" />
          <div className="text-sm">
            <p className="font-medium">{classification.recommendation}</p>
            {recommendations.length > 0 && (
              <ul className="mt-1 text-muted-foreground list-disc list-inside">
                {recommendations.map((rec, i) => (
                  <li key={i}>{rec}</li>
                ))}
              </ul>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}