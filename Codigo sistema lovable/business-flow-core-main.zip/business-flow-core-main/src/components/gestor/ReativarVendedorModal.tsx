import { useState } from 'react';
import { UserCheck, Loader2 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

interface ReativarVendedorModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  seller: { id: string; name: string; motivo_inativacao?: string | null } | null;
  onSuccess: () => void;
}

export function ReativarVendedorModal({
  open,
  onOpenChange,
  seller,
  onSuccess,
}: ReativarVendedorModalProps) {
  const [loading, setLoading] = useState(false);

  async function handleReativar() {
    if (!seller) return;

    setLoading(true);
    try {
      const { data, error } = await supabase.rpc('reativar_vendedor', {
        p_seller_id: seller.id,
      });

      if (error) throw error;

      const result = data as { success: boolean; message: string };
      if (!result.success) {
        throw new Error(result.message || 'Erro ao reativar vendedor');
      }

      toast.success(`Vendedor "${seller.name}" reativado com sucesso`);
      onOpenChange(false);
      onSuccess();
    } catch (err: any) {
      console.error('Erro ao reativar vendedor:', err);
      toast.error(err.message || 'Erro ao reativar vendedor');
    } finally {
      setLoading(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-emerald-600">
            <UserCheck className="h-5 w-5" />
            Reativar Vendedor
          </DialogTitle>
          <DialogDescription>
            Você está prestes a reativar o vendedor <strong>{seller?.name}</strong>.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {seller?.motivo_inativacao && (
            <div className="bg-muted/50 rounded-lg p-3">
              <p className="text-sm text-muted-foreground mb-1">Motivo da inativação:</p>
              <p className="text-sm">{seller.motivo_inativacao}</p>
            </div>
          )}

          <div className="bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800 rounded-lg p-4 text-sm text-emerald-800 dark:text-emerald-200">
            <p className="font-medium mb-1">Ao reativar:</p>
            <ul className="list-disc list-inside space-y-1 text-emerald-700 dark:text-emerald-300">
              <li>O vendedor voltará a aparecer em filtros operacionais</li>
              <li>Será incluído em metas e rankings atuais</li>
              <li>Poderá receber novas tarefas e clientes</li>
            </ul>
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            disabled={loading}
          >
            Cancelar
          </Button>
          <Button
            onClick={handleReativar}
            disabled={loading}
            className="bg-emerald-600 hover:bg-emerald-700"
          >
            {loading ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
                Reativando...
              </>
            ) : (
              <>
                <UserCheck className="h-4 w-4 mr-2" />
                Reativar Vendedor
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}