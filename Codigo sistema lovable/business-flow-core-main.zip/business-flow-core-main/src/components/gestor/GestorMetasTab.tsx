import { useState, useEffect, useCallback } from 'react';
import {
  Target,
  Save,
  RotateCcw,
  Copy,
  Users,
  History,
  Edit3,
  CheckSquare,
  ChevronDown,
  ChevronUp,
  Loader2,
  AlertTriangle,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Separator } from '@/components/ui/separator';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { ScrollArea } from '@/components/ui/scroll-area';
import { toast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';

interface SellerMeta {
  seller_id: string;
  seller_name: string;
  status: string;
  current_level: string;
  monthly_sales_target: number;
  base_daily_calls: number;
  base_daily_whatsapp: number;
  min_contacts_percent: number;
  require_contacts_for_level_up: boolean;
  evaluate_contacts_by_monthly_avg: boolean;
  updated_at: string;
}

interface AuditEntry {
  id: string;
  seller_id: string;
  seller_name?: string;
  changed_by_user_id: string;
  changed_by_name?: string;
  field_name: string;
  old_value: string | null;
  new_value: string | null;
  created_at: string;
}

const FIELD_LABELS: Record<string, string> = {
  monthly_sales_target: 'Meta Comercial (R$)',
  base_daily_calls: 'Meta Ligações/dia',
  base_daily_whatsapp: 'Meta WhatsApp/dia',
  min_contacts_percent: 'Mín. Contatos (%)',
  require_contacts_for_level_up: 'Exigir contatos p/ subir nível',
  evaluate_contacts_by_monthly_avg: 'Avaliar por média mensal',
  current_level: 'Nível',
};

export function GestorMetasTab() {
  const { seller: currentSeller } = useAuth();
  const [sellers, setSellers] = useState<SellerMeta[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState<string | null>(null);
  const [editedValues, setEditedValues] = useState<Record<string, Partial<SellerMeta>>>({});
  const [selectedSellers, setSelectedSellers] = useState<Set<string>>(new Set());
  const [expandedSeller, setExpandedSeller] = useState<string | null>(null);
  const [auditLog, setAuditLog] = useState<AuditEntry[]>([]);
  const [auditLoading, setAuditLoading] = useState(false);
  const [showAuditModal, setShowAuditModal] = useState(false);
  const [auditSellerId, setAuditSellerId] = useState<string | null>(null);

  // Bulk action state
  const [showBulkModal, setShowBulkModal] = useState(false);
  const [bulkValues, setBulkValues] = useState({
    monthly_sales_target: '',
    base_daily_calls: '',
    base_daily_whatsapp: '',
    min_contacts_percent: '',
  });

  // Copy model state
  const [showCopyModal, setShowCopyModal] = useState(false);
  const [copySource, setCopySource] = useState('');
  const [copyTarget, setCopyTarget] = useState('');

  const fetchSellers = useCallback(async () => {
    setLoading(true);
    try {
      const { data: sellersData } = await supabase
        .from('sellers')
        .select('id, name, status')
        .in('role', ['vendedor', 'master'])
        .order('name');

      if (!sellersData) return;

      const { data: levelsData } = await supabase
        .from('seller_levels')
        .select('seller_id, current_level, monthly_sales_target, base_daily_calls, base_daily_whatsapp, min_contacts_percent, require_contacts_for_level_up, evaluate_contacts_by_monthly_avg, updated_at');

      const levelsMap = new Map((levelsData || []).map(l => [l.seller_id, l]));

      const merged: SellerMeta[] = sellersData.map(s => {
        const level = levelsMap.get(s.id);
        return {
          seller_id: s.id,
          seller_name: s.name,
          status: s.status || 'ATIVO',
          current_level: (level?.current_level as string) || 'ovo',
          monthly_sales_target: level?.monthly_sales_target || 30000,
          base_daily_calls: level?.base_daily_calls || 18,
          base_daily_whatsapp: level?.base_daily_whatsapp || 12,
          min_contacts_percent: Number(level?.min_contacts_percent) || 80,
          require_contacts_for_level_up: level?.require_contacts_for_level_up ?? true,
          evaluate_contacts_by_monthly_avg: level?.evaluate_contacts_by_monthly_avg ?? true,
          updated_at: level?.updated_at || '',
        };
      });

      setSellers(merged);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchSellers(); }, [fetchSellers]);

  const getEditedValue = (sellerId: string, field: keyof SellerMeta) => {
    return editedValues[sellerId]?.[field];
  };

  const getValue = (seller: SellerMeta, field: keyof SellerMeta) => {
    const edited = getEditedValue(seller.seller_id, field);
    return edited !== undefined ? edited : seller[field];
  };

  const setFieldValue = (sellerId: string, field: keyof SellerMeta, value: any) => {
    setEditedValues(prev => ({
      ...prev,
      [sellerId]: { ...prev[sellerId], [field]: value },
    }));
  };

  const hasChanges = (sellerId: string) => {
    return editedValues[sellerId] && Object.keys(editedValues[sellerId]).length > 0;
  };

  const revertChanges = (sellerId: string) => {
    setEditedValues(prev => {
      const next = { ...prev };
      delete next[sellerId];
      return next;
    });
  };

  const logAuditChanges = async (sellerId: string, changes: Record<string, { old: any; new: any }>) => {
    if (!currentSeller?.id) return;
    const entries = Object.entries(changes).map(([field, vals]) => ({
      seller_id: sellerId,
      changed_by_user_id: currentSeller.id,
      field_name: field,
      old_value: String(vals.old ?? ''),
      new_value: String(vals.new ?? ''),
    }));

    await supabase.from('seller_meta_audit_log').insert(entries);
  };

  const saveSeller = async (sellerId: string) => {
    const edited = editedValues[sellerId];
    if (!edited) return;

    setSaving(sellerId);
    try {
      const seller = sellers.find(s => s.seller_id === sellerId)!;
      const changes: Record<string, { old: any; new: any }> = {};

      const updateData: Record<string, any> = {};

      const numericFields = ['monthly_sales_target', 'base_daily_calls', 'base_daily_whatsapp', 'min_contacts_percent'] as const;
      const boolFields = ['require_contacts_for_level_up', 'evaluate_contacts_by_monthly_avg'] as const;

      for (const f of numericFields) {
        if (edited[f] !== undefined && Number(edited[f]) !== seller[f]) {
          updateData[f] = Number(edited[f]);
          changes[f] = { old: seller[f], new: Number(edited[f]) };
        }
      }

      for (const f of boolFields) {
        if (edited[f] !== undefined && edited[f] !== seller[f]) {
          updateData[f] = edited[f];
          changes[f] = { old: seller[f], new: edited[f] };
        }
      }

      if (Object.keys(updateData).length === 0) {
        toast({ title: 'Sem alterações' });
        setSaving(null);
        return;
      }

      updateData.updated_at = new Date().toISOString();

      // Upsert seller_levels
      const { error } = await supabase
        .from('seller_levels')
        .upsert({
          seller_id: sellerId,
          ...updateData,
        }, { onConflict: 'seller_id' });

      if (error) throw error;

      await logAuditChanges(sellerId, changes);

      // Clear edited state
      revertChanges(sellerId);
      await fetchSellers();
      toast({ title: 'Metas salvas', description: `${Object.keys(changes).length} campo(s) atualizado(s)` });
    } catch (err: any) {
      toast({ title: 'Erro ao salvar', description: err.message, variant: 'destructive' });
    } finally {
      setSaving(null);
    }
  };

  // Bulk save
  const handleBulkApply = async () => {
    if (selectedSellers.size === 0) {
      toast({ title: 'Selecione vendedores', variant: 'destructive' });
      return;
    }

    const updates: Record<string, any> = {};
    if (bulkValues.monthly_sales_target) updates.monthly_sales_target = Number(bulkValues.monthly_sales_target);
    if (bulkValues.base_daily_calls) updates.base_daily_calls = Number(bulkValues.base_daily_calls);
    if (bulkValues.base_daily_whatsapp) updates.base_daily_whatsapp = Number(bulkValues.base_daily_whatsapp);
    if (bulkValues.min_contacts_percent) updates.min_contacts_percent = Number(bulkValues.min_contacts_percent);

    if (Object.keys(updates).length === 0) {
      toast({ title: 'Preencha ao menos um campo', variant: 'destructive' });
      return;
    }

    setSaving('bulk');
    try {
      for (const sellerId of selectedSellers) {
        const seller = sellers.find(s => s.seller_id === sellerId);
        if (!seller) continue;

        const changes: Record<string, { old: any; new: any }> = {};
        for (const [k, v] of Object.entries(updates)) {
          changes[k] = { old: (seller as any)[k], new: v };
        }

        await supabase
          .from('seller_levels')
          .upsert({ seller_id: sellerId, ...updates, updated_at: new Date().toISOString() }, { onConflict: 'seller_id' });

        await logAuditChanges(sellerId, changes);
      }

      await fetchSellers();
      setShowBulkModal(false);
      setSelectedSellers(new Set());
      setBulkValues({ monthly_sales_target: '', base_daily_calls: '', base_daily_whatsapp: '', min_contacts_percent: '' });
      toast({ title: 'Metas em massa aplicadas', description: `${selectedSellers.size} vendedores atualizados` });
    } catch (err: any) {
      toast({ title: 'Erro', description: err.message, variant: 'destructive' });
    } finally {
      setSaving(null);
    }
  };

  // Copy model
  const handleCopyModel = async () => {
    if (!copySource || !copyTarget || copySource === copyTarget) {
      toast({ title: 'Selecione origem e destino diferentes', variant: 'destructive' });
      return;
    }

    const source = sellers.find(s => s.seller_id === copySource);
    if (!source) return;

    setSaving('copy');
    try {
      const updates = {
        monthly_sales_target: source.monthly_sales_target,
        base_daily_calls: source.base_daily_calls,
        base_daily_whatsapp: source.base_daily_whatsapp,
        min_contacts_percent: source.min_contacts_percent,
        require_contacts_for_level_up: source.require_contacts_for_level_up,
        evaluate_contacts_by_monthly_avg: source.evaluate_contacts_by_monthly_avg,
        updated_at: new Date().toISOString(),
      };

      const target = sellers.find(s => s.seller_id === copyTarget)!;
      const changes: Record<string, { old: any; new: any }> = {};
      for (const [k, v] of Object.entries(updates)) {
        if (k === 'updated_at') continue;
        changes[k] = { old: (target as any)[k], new: v };
      }

      await supabase.from('seller_levels').upsert({ seller_id: copyTarget, ...updates }, { onConflict: 'seller_id' });
      await logAuditChanges(copyTarget, changes);

      await fetchSellers();
      setShowCopyModal(false);
      toast({ title: 'Modelo copiado', description: `Metas de ${source.seller_name} copiadas para ${target.seller_name}` });
    } catch (err: any) {
      toast({ title: 'Erro', description: err.message, variant: 'destructive' });
    } finally {
      setSaving(null);
    }
  };

  // Audit history
  const openAudit = async (sellerId?: string) => {
    setAuditSellerId(sellerId || null);
    setShowAuditModal(true);
    setAuditLoading(true);
    try {
      let query = supabase
        .from('seller_meta_audit_log')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(50);

      if (sellerId) query = query.eq('seller_id', sellerId);

      const { data } = await query;

      // Get seller names
      const sellerIds = new Set((data || []).flatMap(d => [d.seller_id, d.changed_by_user_id]));
      const { data: namesData } = await supabase
        .from('sellers')
        .select('id, name')
        .in('id', Array.from(sellerIds));

      const namesMap = new Map((namesData || []).map(n => [n.id, n.name]));

      setAuditLog((data || []).map(d => ({
        ...d,
        seller_name: namesMap.get(d.seller_id) || '—',
        changed_by_name: namesMap.get(d.changed_by_user_id) || '—',
      })));
    } finally {
      setAuditLoading(false);
    }
  };

  const toggleSelectAll = () => {
    const activeSellers = sellers.filter(s => s.status === 'ATIVO');
    if (selectedSellers.size === activeSellers.length) {
      setSelectedSellers(new Set());
    } else {
      setSelectedSellers(new Set(activeSellers.map(s => s.seller_id)));
    }
  };

  const toggleSelect = (id: string) => {
    setSelectedSellers(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const levelLabel = (l: string) => {
    const map: Record<string, string> = { ovo: '🥚 Ovo', pena: '🪶 Pena', aguia: '🦅 Águia' };
    return map[l.toLowerCase()] || l;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  const activeSellers = sellers.filter(s => s.status === 'ATIVO');
  const inactiveSellers = sellers.filter(s => s.status !== 'ATIVO');

  return (
    <div className="space-y-6">
      {/* Header Actions */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <h2 className="text-lg font-bold flex items-center gap-2">
          <Target className="h-5 w-5 text-primary" />
          Metas & Regras (por vendedor)
        </h2>
        <div className="flex items-center gap-2 flex-wrap">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowBulkModal(true)}
            disabled={selectedSellers.size === 0}
            className="gap-2"
          >
            <Users className="h-4 w-4" />
            Ação em Massa ({selectedSellers.size})
          </Button>
          <Button variant="outline" size="sm" onClick={() => setShowCopyModal(true)} className="gap-2">
            <Copy className="h-4 w-4" />
            Copiar Modelo
          </Button>
          <Button variant="outline" size="sm" onClick={() => openAudit()} className="gap-2">
            <History className="h-4 w-4" />
            Histórico
          </Button>
        </div>
      </div>

      {/* Main Table */}
      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-10">
                  <Checkbox
                    checked={selectedSellers.size === activeSellers.length && activeSellers.length > 0}
                    onCheckedChange={toggleSelectAll}
                  />
                </TableHead>
                <TableHead>Vendedor</TableHead>
                <TableHead>Nível</TableHead>
                <TableHead className="text-right">Meta Comercial (R$)</TableHead>
                <TableHead className="text-right">Ligações/dia</TableHead>
                <TableHead className="text-right">WhatsApp/dia</TableHead>
                <TableHead className="text-right">Mín. Contatos</TableHead>
                <TableHead className="text-center">Atualizado</TableHead>
                <TableHead className="text-center">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {activeSellers.map(seller => {
                const isExpanded = expandedSeller === seller.seller_id;
                const changed = hasChanges(seller.seller_id);
                const isSaving = saving === seller.seller_id;

                return (
                  <>
                    <TableRow key={seller.seller_id} className={cn(changed && 'bg-primary/5')}>
                      <TableCell>
                        <Checkbox
                          checked={selectedSellers.has(seller.seller_id)}
                          onCheckedChange={() => toggleSelect(seller.seller_id)}
                        />
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <span className="font-medium text-sm">{seller.seller_name}</span>
                          {changed && <Badge variant="outline" className="text-[10px] py-0">editado</Badge>}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="secondary" className="text-xs">{levelLabel(seller.current_level)}</Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <Input
                          type="number"
                          className="w-28 text-right h-8 text-sm ml-auto"
                          value={getValue(seller, 'monthly_sales_target') as number}
                          onChange={e => setFieldValue(seller.seller_id, 'monthly_sales_target', e.target.value)}
                        />
                      </TableCell>
                      <TableCell className="text-right">
                        <Input
                          type="number"
                          className="w-20 text-right h-8 text-sm ml-auto"
                          value={getValue(seller, 'base_daily_calls') as number}
                          onChange={e => setFieldValue(seller.seller_id, 'base_daily_calls', e.target.value)}
                        />
                      </TableCell>
                      <TableCell className="text-right">
                        <Input
                          type="number"
                          className="w-20 text-right h-8 text-sm ml-auto"
                          value={getValue(seller, 'base_daily_whatsapp') as number}
                          onChange={e => setFieldValue(seller.seller_id, 'base_daily_whatsapp', e.target.value)}
                        />
                      </TableCell>
                      <TableCell className="text-right">
                        <Input
                          type="number"
                          className="w-20 text-right h-8 text-sm ml-auto"
                          value={getValue(seller, 'min_contacts_percent') as number}
                          onChange={e => setFieldValue(seller.seller_id, 'min_contacts_percent', e.target.value)}
                          min={0}
                          max={100}
                        />
                      </TableCell>
                      <TableCell className="text-center text-xs text-muted-foreground">
                        {seller.updated_at ? format(new Date(seller.updated_at), 'dd/MM HH:mm') : '—'}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1 justify-center">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => saveSeller(seller.seller_id)}
                            disabled={!changed || isSaving}
                            className="h-7 w-7 p-0"
                          >
                            {isSaving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => revertChanges(seller.seller_id)}
                            disabled={!changed}
                            className="h-7 w-7 p-0"
                          >
                            <RotateCcw className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => setExpandedSeller(isExpanded ? null : seller.seller_id)}
                            className="h-7 w-7 p-0"
                          >
                            {isExpanded ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => openAudit(seller.seller_id)}
                            className="h-7 w-7 p-0"
                          >
                            <History className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>

                    {/* Expanded editor */}
                    {isExpanded && (
                      <TableRow key={`${seller.seller_id}-expanded`}>
                        <TableCell colSpan={9}>
                          <div className="p-4 bg-muted/30 rounded-lg space-y-4">
                            <h4 className="text-sm font-semibold flex items-center gap-2">
                              <Edit3 className="h-4 w-4" />
                              Editor Individual — {seller.seller_name}
                            </h4>

                            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                              <div>
                                <Label className="text-xs">Meta Comercial Mensal (R$)</Label>
                                <Input
                                  type="number"
                                  value={getValue(seller, 'monthly_sales_target') as number}
                                  onChange={e => setFieldValue(seller.seller_id, 'monthly_sales_target', e.target.value)}
                                />
                              </div>
                              <div>
                                <Label className="text-xs">Meta Ligações (diária)</Label>
                                <Input
                                  type="number"
                                  value={getValue(seller, 'base_daily_calls') as number}
                                  onChange={e => setFieldValue(seller.seller_id, 'base_daily_calls', e.target.value)}
                                />
                              </div>
                              <div>
                                <Label className="text-xs">Meta WhatsApp (diária)</Label>
                                <Input
                                  type="number"
                                  value={getValue(seller, 'base_daily_whatsapp') as number}
                                  onChange={e => setFieldValue(seller.seller_id, 'base_daily_whatsapp', e.target.value)}
                                />
                              </div>
                              <div>
                                <Label className="text-xs">Mín. Contatos para Nível (%)</Label>
                                <Input
                                  type="number"
                                  min={0}
                                  max={100}
                                  value={getValue(seller, 'min_contacts_percent') as number}
                                  onChange={e => setFieldValue(seller.seller_id, 'min_contacts_percent', e.target.value)}
                                />
                              </div>
                            </div>

                            <Separator />

                            <div className="space-y-3">
                              <h5 className="text-xs font-semibold text-muted-foreground">Regras de Elegibilidade</h5>
                              <div className="flex items-center gap-3">
                                <Switch
                                  checked={getValue(seller, 'require_contacts_for_level_up') as boolean}
                                  onCheckedChange={v => setFieldValue(seller.seller_id, 'require_contacts_for_level_up', v)}
                                />
                                <Label className="text-sm">Exigir mín. contatos para subir nível</Label>
                              </div>
                              <div className="flex items-center gap-3">
                                <Switch
                                  checked={getValue(seller, 'evaluate_contacts_by_monthly_avg') as boolean}
                                  onCheckedChange={v => setFieldValue(seller.seller_id, 'evaluate_contacts_by_monthly_avg', v)}
                                />
                                <Label className="text-sm">Avaliar contatos por média mensal</Label>
                              </div>
                            </div>

                            <div className="flex gap-2 pt-2">
                              <Button size="sm" onClick={() => saveSeller(seller.seller_id)} disabled={!changed || isSaving} className="gap-2">
                                {isSaving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                                Salvar
                              </Button>
                              <Button size="sm" variant="outline" onClick={() => revertChanges(seller.seller_id)} disabled={!changed} className="gap-2">
                                <RotateCcw className="h-4 w-4" /> Reverter
                              </Button>
                            </div>
                          </div>
                        </TableCell>
                      </TableRow>
                    )}
                  </>
                );
              })}

              {inactiveSellers.length > 0 && (
                <>
                  <TableRow>
                    <TableCell colSpan={9} className="text-center text-xs text-muted-foreground py-2 bg-muted/20">
                      Inativos ({inactiveSellers.length})
                    </TableCell>
                  </TableRow>
                  {inactiveSellers.map(seller => (
                    <TableRow key={seller.seller_id} className="opacity-50">
                      <TableCell />
                      <TableCell><span className="text-sm">{seller.seller_name}</span></TableCell>
                      <TableCell><Badge variant="outline" className="text-xs">{levelLabel(seller.current_level)}</Badge></TableCell>
                      <TableCell className="text-right text-sm">{seller.monthly_sales_target.toLocaleString('pt-BR')}</TableCell>
                      <TableCell className="text-right text-sm">{seller.base_daily_calls}</TableCell>
                      <TableCell className="text-right text-sm">{seller.base_daily_whatsapp}</TableCell>
                      <TableCell className="text-right text-sm">{seller.min_contacts_percent}%</TableCell>
                      <TableCell />
                      <TableCell />
                    </TableRow>
                  ))}
                </>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Bulk Action Modal */}
      <Dialog open={showBulkModal} onOpenChange={setShowBulkModal}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" /> Ação em Massa ({selectedSellers.size} vendedores)
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">Preencha apenas os campos que deseja alterar. Campos vazios não serão modificados.</p>
            <div>
              <Label>Meta Comercial (R$)</Label>
              <Input type="number" value={bulkValues.monthly_sales_target} onChange={e => setBulkValues(p => ({ ...p, monthly_sales_target: e.target.value }))} placeholder="Ex: 35000" />
            </div>
            <div>
              <Label>Meta Ligações/dia</Label>
              <Input type="number" value={bulkValues.base_daily_calls} onChange={e => setBulkValues(p => ({ ...p, base_daily_calls: e.target.value }))} placeholder="Ex: 18" />
            </div>
            <div>
              <Label>Meta WhatsApp/dia</Label>
              <Input type="number" value={bulkValues.base_daily_whatsapp} onChange={e => setBulkValues(p => ({ ...p, base_daily_whatsapp: e.target.value }))} placeholder="Ex: 12" />
            </div>
            <div>
              <Label>Percentual Mínimo Contatos (%)</Label>
              <Input type="number" value={bulkValues.min_contacts_percent} onChange={e => setBulkValues(p => ({ ...p, min_contacts_percent: e.target.value }))} placeholder="Ex: 80" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowBulkModal(false)}>Cancelar</Button>
            <Button onClick={handleBulkApply} disabled={saving === 'bulk'}>
              {saving === 'bulk' ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
              Aplicar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Copy Model Modal */}
      <Dialog open={showCopyModal} onOpenChange={setShowCopyModal}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Copy className="h-5 w-5" /> Copiar Modelo de Metas
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Copiar DE (origem)</Label>
              <Select value={copySource} onValueChange={setCopySource}>
                <SelectTrigger><SelectValue placeholder="Selecione vendedor" /></SelectTrigger>
                <SelectContent>
                  {activeSellers.map(s => (
                    <SelectItem key={s.seller_id} value={s.seller_id}>{s.seller_name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Copiar PARA (destino)</Label>
              <Select value={copyTarget} onValueChange={setCopyTarget}>
                <SelectTrigger><SelectValue placeholder="Selecione vendedor" /></SelectTrigger>
                <SelectContent>
                  {activeSellers.filter(s => s.seller_id !== copySource).map(s => (
                    <SelectItem key={s.seller_id} value={s.seller_id}>{s.seller_name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            {copySource && (
              <Card className="p-3 bg-muted/30">
                <p className="text-xs font-semibold mb-1">Metas que serão copiadas:</p>
                {(() => {
                  const src = sellers.find(s => s.seller_id === copySource);
                  if (!src) return null;
                  return (
                    <div className="text-xs space-y-1 text-muted-foreground">
                      <p>Meta Comercial: R$ {src.monthly_sales_target.toLocaleString('pt-BR')}</p>
                      <p>Ligações/dia: {src.base_daily_calls}</p>
                      <p>WhatsApp/dia: {src.base_daily_whatsapp}</p>
                      <p>Mín. Contatos: {src.min_contacts_percent}%</p>
                    </div>
                  );
                })()}
              </Card>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCopyModal(false)}>Cancelar</Button>
            <Button onClick={handleCopyModel} disabled={!copySource || !copyTarget || saving === 'copy'}>
              {saving === 'copy' ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
              Copiar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Audit History Modal */}
      <Dialog open={showAuditModal} onOpenChange={setShowAuditModal}>
        <DialogContent className="max-w-2xl max-h-[80vh]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <History className="h-5 w-5" />
              Histórico de Alterações
              {auditSellerId && sellers.find(s => s.seller_id === auditSellerId) && (
                <Badge variant="secondary">{sellers.find(s => s.seller_id === auditSellerId)?.seller_name}</Badge>
              )}
            </DialogTitle>
          </DialogHeader>
          <ScrollArea className="max-h-[60vh]">
            {auditLoading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-6 w-6 animate-spin" />
              </div>
            ) : auditLog.length === 0 ? (
              <p className="text-center text-sm text-muted-foreground py-8">Nenhum registro encontrado.</p>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Data</TableHead>
                    <TableHead>Vendedor</TableHead>
                    <TableHead>Campo</TableHead>
                    <TableHead>De</TableHead>
                    <TableHead>Para</TableHead>
                    <TableHead>Alterado por</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {auditLog.map(entry => (
                    <TableRow key={entry.id}>
                      <TableCell className="text-xs">{format(new Date(entry.created_at), 'dd/MM/yy HH:mm')}</TableCell>
                      <TableCell className="text-xs font-medium">{entry.seller_name}</TableCell>
                      <TableCell className="text-xs">{FIELD_LABELS[entry.field_name] || entry.field_name}</TableCell>
                      <TableCell className="text-xs text-muted-foreground">{entry.old_value}</TableCell>
                      <TableCell className="text-xs font-medium">{entry.new_value}</TableCell>
                      <TableCell className="text-xs">{entry.changed_by_name}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </ScrollArea>
        </DialogContent>
      </Dialog>
    </div>
  );
}
