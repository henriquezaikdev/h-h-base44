import { useState, useEffect, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { 
  Crown, 
  TrendingUp,
  TrendingDown,
  Minus,
  ChevronRight,
  Loader2,
  DollarSign,
  BarChart3
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { supabase } from '@/integrations/supabase/client';
import { format, startOfMonth, endOfMonth, subMonths } from 'date-fns';
import { cn } from '@/lib/utils';

interface Top20PerformancePanelProps {
  startDate: Date;
  endDate: Date;
  sellerId?: string | null;
}

interface ClientPerformance {
  id: string;
  company_name: string;
  seller_name: string;
  total_revenue: number;
  period_revenue: number;
  period_profit: number;
  period_margin: number;
  prev_period_revenue: number;
  variation_percent: number;
  rank: number;
}

export function Top20PerformancePanel({ startDate, endDate, sellerId }: Top20PerformancePanelProps) {
  const [loading, setLoading] = useState(true);
  const [clients, setClients] = useState<ClientPerformance[]>([]);
  const [concentrationPercent, setConcentrationPercent] = useState(0);
  const [totalPeriodRevenue, setTotalPeriodRevenue] = useState(0);

  useEffect(() => {
    const fetchPerformance = async () => {
      setLoading(true);
      try {
        // Buscar clientes Top 20
        let clientQuery = supabase
          .from('clients')
          .select(`
            id,
            company_name,
            total_revenue,
            seller_id,
            sellers!clients_seller_id_fkey(name)
          `)
          .eq('is_deleted', false)
          .eq('ranking_tier', 'top20')
          .order('total_revenue', { ascending: false });

        if (sellerId) {
          clientQuery = clientQuery.eq('seller_id', sellerId);
        }

        const { data: clientsData, error: clientsError } = await clientQuery;

        if (clientsError) {
          console.error('Error fetching Top 20 clients:', clientsError);
          return;
        }

        // Calcular período anterior (mesmo intervalo, mês anterior)
        const prevStartDate = subMonths(startDate, 1);
        const prevEndDate = subMonths(endDate, 1);

        // Buscar receita do período atual e anterior para cada cliente
        const clientIds = (clientsData || []).map((c: any) => c.id);

        if (clientIds.length === 0) {
          setClients([]);
          setLoading(false);
          return;
        }

        // Receita período atual - incluir lucro_bruto_real do banco (já com 15% descontado)
        const { data: currentOrders } = await supabase
          .from('orders')
          .select('id, client_id, total, lucro_bruto_real')
          .in('client_id', clientIds)
          .eq('is_deleted', false)
          .gte('order_date', format(startDate, 'yyyy-MM-dd'))
          .lte('order_date', format(endDate, 'yyyy-MM-dd'));

        // Receita período anterior
        const { data: prevOrders } = await supabase
          .from('orders')
          .select('client_id, total')
          .in('client_id', clientIds)
          .eq('is_deleted', false)
          .gte('order_date', format(prevStartDate, 'yyyy-MM-dd'))
          .lte('order_date', format(prevEndDate, 'yyyy-MM-dd'));

        // Receita total do período (todos os clientes)
        let totalQuery = supabase
          .from('orders')
          .select('total')
          .eq('is_deleted', false)
          .gte('order_date', format(startDate, 'yyyy-MM-dd'))
          .lte('order_date', format(endDate, 'yyyy-MM-dd'));

        if (sellerId) {
          totalQuery = totalQuery.eq('seller_id', sellerId);
        }

        const { data: allOrders } = await totalQuery;
        const totalRevenue = (allOrders || []).reduce((sum: number, o: any) => sum + (o.total || 0), 0);
        setTotalPeriodRevenue(totalRevenue);

        // Agregar receita e lucro por cliente
        const currentByClient: Record<string, { revenue: number; profit: number }> = {};
        const prevByClient: Record<string, number> = {};

        (currentOrders || []).forEach((o: any) => {
          if (!currentByClient[o.client_id]) {
            currentByClient[o.client_id] = { revenue: 0, profit: 0 };
          }
          currentByClient[o.client_id].revenue += (o.total || 0);
          // Usar lucro_bruto_real do banco (já com CMV Real = custo + 15%)
          currentByClient[o.client_id].profit += (o.lucro_bruto_real || 0);
        });

        (prevOrders || []).forEach((o: any) => {
          prevByClient[o.client_id] = (prevByClient[o.client_id] || 0) + (o.total || 0);
        });

        // Montar lista de performance
        const performanceList: ClientPerformance[] = (clientsData || []).map((client: any, index: number) => {
          const clientData = currentByClient[client.id] || { revenue: 0, profit: 0 };
          const periodRevenue = clientData.revenue;
          const periodProfit = clientData.profit;
          const periodMargin = periodRevenue > 0 ? (periodProfit / periodRevenue) * 100 : 0;
          const prevPeriodRevenue = prevByClient[client.id] || 0;
          const variation = prevPeriodRevenue > 0 
            ? ((periodRevenue - prevPeriodRevenue) / prevPeriodRevenue) * 100
            : (periodRevenue > 0 ? 100 : 0);

          return {
            id: client.id,
            company_name: client.company_name,
            seller_name: (client.sellers as any)?.name || 'Sem vendedor',
            total_revenue: client.total_revenue || 0,
            period_revenue: periodRevenue,
            period_profit: periodProfit,
            period_margin: periodMargin,
            prev_period_revenue: prevPeriodRevenue,
            variation_percent: variation,
            rank: index + 1,
          };
        });

        // Ordenar por receita do período
        performanceList.sort((a, b) => b.period_revenue - a.period_revenue);

        // Recalcular ranks
        performanceList.forEach((c, i) => c.rank = i + 1);

        // Calcular concentração
        const top20Revenue = performanceList.reduce((sum, c) => sum + c.period_revenue, 0);
        const concentration = totalRevenue > 0 ? (top20Revenue / totalRevenue) * 100 : 0;
        setConcentrationPercent(concentration);

        setClients(performanceList);
      } catch (error) {
        console.error('Error:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchPerformance();
  }, [startDate, endDate, sellerId]);

  const formatCurrency = (value: number) =>
    new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL', minimumFractionDigits: 0 }).format(value);

  const top20Revenue = clients.reduce((sum, c) => sum + c.period_revenue, 0);

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <BarChart3 className="h-5 w-5 text-primary" />
            Performance Top 20
          </CardTitle>
        </CardHeader>
        <CardContent className="flex items-center justify-center py-8">
          <Loader2 className="h-6 w-6 animate-spin text-primary" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-base">
            <BarChart3 className="h-5 w-5 text-primary" />
            Performance Top 20 no Período
          </CardTitle>
        </div>
        
        {/* Indicador de Concentração */}
        <div className="mt-3 p-3 rounded-lg bg-muted/50 border">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-muted-foreground">Concentração de Receita</span>
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger>
                  <Badge 
                    variant="outline" 
                    className={cn(
                      concentrationPercent > 50 ? 'border-amber-500 text-amber-600' : 'border-emerald-500 text-emerald-600'
                    )}
                  >
                    {concentrationPercent.toFixed(1)}%
                  </Badge>
                </TooltipTrigger>
                <TooltipContent>
                  <p className="text-xs">
                    {concentrationPercent > 50 
                      ? 'Alta concentração - risco de dependência'
                      : 'Carteira bem distribuída'}
                  </p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
          <Progress 
            value={concentrationPercent} 
            className={cn(
              'h-2',
              concentrationPercent > 50 ? '[&>div]:bg-amber-500' : '[&>div]:bg-emerald-500'
            )}
          />
          <div className="flex justify-between mt-2 text-xs text-muted-foreground">
            <span>Top 20: {formatCurrency(top20Revenue)}</span>
            <span>Total: {formatCurrency(totalPeriodRevenue)}</span>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {clients.length > 0 ? (
          <div className="space-y-2">
            {clients.slice(0, 10).map((client) => (
              <Link
                key={client.id}
                to={`/clients/${client.id}`}
                className="flex items-center justify-between p-3 rounded-lg border hover:bg-muted/50 transition-colors"
              >
                <div className="flex items-center gap-3 min-w-0 flex-1">
                  <div className={cn(
                    'w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold shrink-0',
                    client.rank <= 3 
                      ? 'bg-amber-500 text-white' 
                      : 'bg-muted text-muted-foreground'
                  )}>
                    {client.rank}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-medium truncate">{client.company_name}</p>
                    <p className="text-xs text-muted-foreground">{client.seller_name}</p>
                  </div>
                </div>
                <div className="flex items-center gap-4 shrink-0">
                  {/* Margem Real */}
                  <div className="text-right">
                    <p className={cn(
                      'text-sm font-semibold',
                      client.period_margin >= 15 && 'text-emerald-600 dark:text-emerald-400',
                      client.period_margin >= 0 && client.period_margin < 15 && 'text-amber-600 dark:text-amber-400',
                      client.period_margin < 0 && 'text-destructive'
                    )}>
                      {client.period_margin.toFixed(1)}%
                    </p>
                    <p className="text-[10px] text-muted-foreground">margem real</p>
                  </div>
                  {/* Receita */}
                  <div className="text-right">
                    <p className="text-sm font-semibold">{formatCurrency(client.period_revenue)}</p>
                    <div className="flex items-center justify-end gap-1">
                      {client.variation_percent > 0 ? (
                        <TrendingUp className="h-3 w-3 text-emerald-500" />
                      ) : client.variation_percent < 0 ? (
                        <TrendingDown className="h-3 w-3 text-destructive" />
                      ) : (
                        <Minus className="h-3 w-3 text-muted-foreground" />
                      )}
                      <span className={cn(
                        'text-xs font-medium',
                        client.variation_percent > 0 && 'text-emerald-600 dark:text-emerald-400',
                        client.variation_percent < 0 && 'text-destructive',
                        client.variation_percent === 0 && 'text-muted-foreground'
                      )}>
                        {client.variation_percent > 0 && '+'}
                        {client.variation_percent.toFixed(0)}%
                      </span>
                    </div>
                  </div>
                  <ChevronRight className="h-4 w-4 text-muted-foreground" />
                </div>
              </Link>
            ))}
            
            {clients.length > 10 && (
              <p className="text-xs text-center text-muted-foreground pt-2">
                +{clients.length - 10} clientes Top 20
              </p>
            )}
          </div>
        ) : (
          <div className="py-8 text-center text-muted-foreground">
            <Crown className="h-10 w-10 mx-auto mb-2 opacity-30" />
            <p className="text-sm">Nenhum cliente Top 20 encontrado</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
