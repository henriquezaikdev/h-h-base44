import { CheckCircle2, Clock, FileText, Calendar, AlertTriangle } from 'lucide-react';
import { motion } from 'framer-motion';
import { Progress } from '@/components/ui/progress';
import { cn } from '@/lib/utils';
import type { UsageQuality } from '@/hooks/useGestorData';

interface UsageQualityCardsProps {
  data: UsageQuality[];
}

function getQualityScore(quality: UsageQuality): number {
  let score = 0;
  
  // Tasks on time (max 25)
  score += Math.min(25, (quality.tasksOnTimePercent / 100) * 25);
  
  // No overdue returns (max 25)
  score += quality.overdueReturns === 0 ? 25 : Math.max(0, 25 - quality.overdueReturns * 5);
  
  // Good observation length (max 25)
  score += Math.min(25, (quality.avgObservationLength / 50) * 25);
  
  // Active days (max 25)
  score += Math.max(0, 25 - quality.daysWithoutInteraction * 5);
  
  return Math.round(score);
}

function getScoreConfig(score: number) {
  if (score >= 80) return { label: 'Excelente', color: 'emerald', emoji: '🌟' };
  if (score >= 60) return { label: 'Bom', color: 'primary', emoji: '👍' };
  if (score >= 40) return { label: 'Regular', color: 'amber', emoji: '⚠️' };
  return { label: 'Crítico', color: 'destructive', emoji: '🚨' };
}

export function UsageQualityCards({ data }: UsageQualityCardsProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
      {data.map((quality, index) => {
        const score = getQualityScore(quality);
        const scoreConfig = getScoreConfig(score);
        
        const colorClasses = {
          emerald: {
            ring: 'ring-emerald-500/20',
            bg: 'bg-emerald-500/5',
            text: 'text-emerald-500',
            progress: '[&>div]:bg-emerald-500',
          },
          primary: {
            ring: 'ring-primary/20',
            bg: 'bg-primary/5',
            text: 'text-primary',
            progress: '[&>div]:bg-primary',
          },
          amber: {
            ring: 'ring-amber-500/20',
            bg: 'bg-amber-500/5',
            text: 'text-amber-500',
            progress: '[&>div]:bg-amber-500',
          },
          destructive: {
            ring: 'ring-destructive/20',
            bg: 'bg-destructive/5',
            text: 'text-destructive',
            progress: '[&>div]:bg-destructive',
          },
        }[scoreConfig.color];

        return (
          <motion.div
            key={quality.sellerId}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
            whileHover={{ y: -2, transition: { duration: 0.2 } }}
            className={cn(
              'rounded-xl border bg-card p-4 transition-all duration-200 hover:shadow-md',
              `ring-1 ${colorClasses.ring}`
            )}
          >
            {/* Header */}
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold truncate max-w-[150px]">{quality.sellerName}</h3>
              <div className={cn(
                'flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium',
                colorClasses.bg,
                colorClasses.text
              )}>
                <span>{scoreConfig.emoji}</span>
                <span>{score}</span>
              </div>
            </div>

            {/* Score Progress */}
            <div className="mb-4">
              <Progress value={score} className={cn('h-2', colorClasses.progress)} />
            </div>

            {/* Metrics Grid */}
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="flex items-center gap-2">
                <div className={cn(
                  'p-1.5 rounded-lg',
                  quality.tasksOnTimePercent >= 80 ? 'bg-emerald-500/10' : 'bg-amber-500/10'
                )}>
                  <CheckCircle2 className={cn(
                    'h-3.5 w-3.5',
                    quality.tasksOnTimePercent >= 80 ? 'text-emerald-500' : 'text-amber-500'
                  )} />
                </div>
                <div>
                  <p className="text-muted-foreground">No prazo</p>
                  <p className="font-medium">{quality.tasksOnTimePercent.toFixed(0)}%</p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <div className={cn(
                  'p-1.5 rounded-lg',
                  quality.overdueReturns === 0 ? 'bg-emerald-500/10' : 'bg-destructive/10'
                )}>
                  <Clock className={cn(
                    'h-3.5 w-3.5',
                    quality.overdueReturns === 0 ? 'text-emerald-500' : 'text-destructive'
                  )} />
                </div>
                <div>
                  <p className="text-muted-foreground">Vencidos</p>
                  <p className="font-medium">{quality.overdueReturns}</p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <div className={cn(
                  'p-1.5 rounded-lg',
                  quality.avgObservationLength >= 30 ? 'bg-emerald-500/10' : 'bg-muted'
                )}>
                  <FileText className={cn(
                    'h-3.5 w-3.5',
                    quality.avgObservationLength >= 30 ? 'text-emerald-500' : 'text-muted-foreground'
                  )} />
                </div>
                <div>
                  <p className="text-muted-foreground">Obs. média</p>
                  <p className="font-medium">{quality.avgObservationLength.toFixed(0)} chars</p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <div className={cn(
                  'p-1.5 rounded-lg',
                  quality.daysWithoutInteraction <= 2 ? 'bg-emerald-500/10' : 'bg-amber-500/10'
                )}>
                  <Calendar className={cn(
                    'h-3.5 w-3.5',
                    quality.daysWithoutInteraction <= 2 ? 'text-emerald-500' : 'text-amber-500'
                  )} />
                </div>
                <div>
                  <p className="text-muted-foreground">Dias s/ ação</p>
                  <p className="font-medium">{quality.daysWithoutInteraction}</p>
                </div>
              </div>
            </div>

            {/* Tasks without observation alert */}
            {quality.tasksWithoutObservation > 0 && (
              <div className="mt-3 flex items-center gap-2 text-xs text-amber-500 bg-amber-500/10 rounded-lg p-2">
                <AlertTriangle className="h-3.5 w-3.5" />
                <span>{quality.tasksWithoutObservation} tarefas sem observação</span>
              </div>
            )}
          </motion.div>
        );
      })}
    </div>
  );
}
