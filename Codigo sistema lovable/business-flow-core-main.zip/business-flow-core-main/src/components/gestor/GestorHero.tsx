import { useMemo } from 'react';
import { motion } from 'framer-motion';
import { Crown, Building2, TrendingUp, Info, ArrowDown, ArrowUp, Minus } from 'lucide-react';
import { getGreetingIcon } from '@/components/ui/animated-weather-icons';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { BorderBeam } from '@/components/ui/border-beam';
import { HoverCard, HoverCardContent, HoverCardTrigger } from '@/components/ui/hover-card';
import { cn } from '@/lib/utils';

interface GestorHeroProps {
  ceeTotal: number;
  lucroRealTotal: number;
  lucroBruto?: number;
  custoHumano?: number;
  onOpenCompanyCosts: () => void;
  userName?: string;
  className?: string;
}

function formatCurrency(value: number): string {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value);
}

export function GestorHero({ 
  ceeTotal, 
  lucroRealTotal,
  lucroBruto = 0,
  custoHumano = 0,
  onOpenCompanyCosts,
  userName = "Gestor",
  className 
}: GestorHeroProps) {
  const currentDate = new Date();
  
  const greeting = useMemo(() => {
    const hour = currentDate.getHours();
    if (hour < 12) return "Bom dia";
    if (hour < 18) return "Boa tarde";
    return "Boa noite";
  }, []);

  const formattedDate = currentDate.toLocaleDateString('pt-BR', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  });

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { type: "spring" as const, stiffness: 100, damping: 15 }
    }
  };

  const isPositive = lucroRealTotal >= 0;

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className={cn(
        "relative w-full overflow-hidden rounded-2xl",
        "bg-gradient-to-br from-card via-card/95 to-card/90",
        "border border-border/50",
        className
      )}
    >
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-[0.03] pointer-events-none -z-10">
        <div 
          className="absolute inset-0"
          style={{
            backgroundImage: `radial-gradient(circle at 1px 1px, currentColor 1px, transparent 0)`,
            backgroundSize: '24px 24px'
          }}
        />
      </div>

      {/* Gradient Orbs */}
      <div className="absolute -top-24 -right-24 w-48 h-48 bg-amber-500/20 rounded-full blur-3xl pointer-events-none -z-10" />
      <div className="absolute -bottom-24 -left-24 w-48 h-48 bg-primary/20 rounded-full blur-3xl pointer-events-none -z-10" />

      {/* Content */}
      <div className="relative z-10 p-6 md:p-8">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
          {/* Left: Greeting & Title */}
          <motion.div variants={itemVariants} className="flex-1">
            <div className="flex items-center gap-3 mb-3">
              <motion.div 
                className="p-3 rounded-xl bg-gradient-to-br from-amber-500/20 to-orange-500/20 border border-amber-500/30"
                whileHover={{ scale: 1.05, rotate: 5 }}
                transition={{ type: "spring", stiffness: 400 }}
              >
                <Crown className="h-6 w-6 text-amber-500" />
              </motion.div>
              <div className="flex items-center gap-2">
                {getGreetingIcon(currentDate.getHours(), 22)}
                <span className="text-sm font-medium text-amber-600 dark:text-amber-400">
                  {greeting}, {userName}
                </span>
              </div>
            </div>
            <h1 className="text-2xl md:text-3xl font-bold text-foreground mb-2">
              Painel de Decisão Executiva
            </h1>
            <p className="text-sm text-muted-foreground capitalize">
              {formattedDate}
            </p>
          </motion.div>

          {/* Right: Quick Stats + Actions */}
          <motion.div 
            variants={itemVariants}
            className="flex flex-col sm:flex-row items-start sm:items-center gap-4"
          >
            {/* Resultado Real Mini Card with Breakdown */}
            <HoverCard openDelay={100} closeDelay={100}>
              <HoverCardTrigger asChild>
                <motion.div
                  whileHover={{ scale: 1.02, y: -2 }}
                  className={cn(
                    "flex items-center gap-3 px-4 py-3 rounded-xl cursor-help",
                    "border backdrop-blur-sm transition-all duration-300",
                    isPositive 
                      ? "bg-emerald/10 border-emerald/30 hover:border-emerald/50"
                      : "bg-rose/10 border-rose/30 hover:border-rose/50"
                  )}
                >
                  <div className={cn(
                    "p-2 rounded-lg",
                    isPositive ? "bg-emerald/20" : "bg-rose/20"
                  )}>
                    <TrendingUp className={cn(
                      "w-4 h-4",
                      isPositive ? "text-emerald" : "text-rose"
                    )} />
                  </div>
                  <div>
                    <div className="flex items-center gap-1">
                      <p className="text-xs text-muted-foreground">Resultado Real</p>
                      <Info className="w-3 h-3 text-muted-foreground/60" />
                    </div>
                    <p className={cn(
                      "text-lg font-bold",
                      isPositive ? "text-emerald dark:text-emerald" : "text-rose"
                    )}>
                      {formatCurrency(lucroRealTotal)}
                    </p>
                  </div>
                </motion.div>
              </HoverCardTrigger>
              <HoverCardContent 
                align="end" 
                className="w-72 p-4 bg-card/95 backdrop-blur-md border-border/50"
              >
                <div className="space-y-3">
                  <h4 className="font-semibold text-sm flex items-center gap-2">
                    <TrendingUp className="w-4 h-4 text-primary" />
                    Composição do Resultado
                  </h4>
                  
                  <div className="space-y-2">
                    {/* Lucro Bruto */}
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-2">
                        <ArrowUp className="w-3.5 h-3.5 text-emerald" />
                        <span className="text-muted-foreground">Lucro Bruto</span>
                      </div>
                      <span className="font-medium text-emerald">
                        +{formatCurrency(lucroBruto)}
                      </span>
                    </div>
                    
                    {/* Custo Humano */}
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-2">
                        <ArrowDown className="w-3.5 h-3.5 text-amber" />
                        <span className="text-muted-foreground">Custo Humano</span>
                      </div>
                      <span className="font-medium text-amber">
                        -{formatCurrency(custoHumano)}
                      </span>
                    </div>
                    
                    {/* CEE */}
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-2">
                        <ArrowDown className="w-3.5 h-3.5 text-violet" />
                        <span className="text-muted-foreground">Custos Estruturais (CEE)</span>
                      </div>
                      <span className="font-medium text-violet">
                        -{formatCurrency(ceeTotal)}
                      </span>
                    </div>
                  </div>
                  
                  {/* Divider */}
                  <div className="border-t border-border/50 pt-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Minus className={cn(
                          "w-3.5 h-3.5",
                          isPositive ? "text-emerald" : "text-rose"
                        )} />
                        <span className="font-medium">Resultado Real</span>
                      </div>
                      <span className={cn(
                        "font-bold text-base",
                        isPositive ? "text-emerald" : "text-rose"
                      )}>
                        {formatCurrency(lucroRealTotal)}
                      </span>
                    </div>
                  </div>
                  
                  {/* Insight */}
                  {!isPositive && (
                    <div className="pt-2 text-xs text-muted-foreground bg-rose/5 p-2 rounded-lg border border-rose/20">
                      💡 Faltam <span className="font-semibold text-rose">{formatCurrency(Math.abs(lucroRealTotal))}</span> para atingir o break-even.
                    </div>
                  )}
                </div>
              </HoverCardContent>
            </HoverCard>

            {/* Company Costs Button */}
            <Button 
              variant="outline" 
              className="gap-2 bg-card/50 backdrop-blur-sm hover:bg-card border-border/50 hover:border-primary/30"
              onClick={onOpenCompanyCosts}
            >
              <Building2 className="h-4 w-4" />
              Custos da Empresa
              <Badge variant="secondary" className="ml-1 bg-purple-500/10 text-purple-600 dark:text-purple-400 border-purple-500/20">
                {formatCurrency(ceeTotal)}/mês
              </Badge>
            </Button>
          </motion.div>
        </div>
      </div>

      {/* Border Beam Effect */}
      <BorderBeam 
        size={300} 
        duration={12} 
        colorFrom="hsl(45, 100%, 50%)" 
        colorTo="hsl(var(--primary))"
        borderWidth={1.5}
      />
    </motion.div>
  );
}
