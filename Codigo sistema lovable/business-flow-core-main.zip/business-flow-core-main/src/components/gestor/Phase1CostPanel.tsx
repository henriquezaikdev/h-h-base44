import { useState, useEffect, useMemo } from 'react';
import { motion } from 'framer-motion';
import { User, HelpCircle, DollarSign, Briefcase, Car, Wrench, ChevronDown, ChevronUp, Check, AlertTriangle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface SellerCostData {
  id?: string;
  seller_id: string;
  // Salário
  salario_base: number;
  // Benefícios
  vale_alimentacao: number;
  vale_transporte: number;
  vale_refeicao: number;
  plano_saude: number;
  ajuda_custo: number;
  // Encargos
  encargos_habilitado: boolean;
  encargos_percentual: number;
  provisao_ferias_13_percentual: number;
  // Ferramentas
  crm: number;
  telefonia: number;
  whatsapp_tool: number;
  discador: number;
  outras_ferramentas: number;
  // Deslocamento
  combustivel: number;
  reembolso_viagens: number;
  viagens: number;
  // Legacy
  internet_telefone: number;
  aluguel_rateio: number;
  outros_fixos: number;
  // Commission toggle
  commission_enabled: boolean;
}

interface Phase1CostPanelProps {
  sellerId: string;
  sellerName: string;
  sellerRevenue: number;
  marginBruta: number;
  comissaoReal: number; // Comissão calculada automaticamente
  comissaoPercentual: number; // % efetivo de comissão
  onCostCalculated: (cdv: number, resultadoDireto: number) => void;
}

const defaultCost: Omit<SellerCostData, 'seller_id'> = {
  salario_base: 0,
  vale_alimentacao: 0,
  vale_transporte: 0,
  vale_refeicao: 0,
  plano_saude: 0,
  ajuda_custo: 0,
  encargos_habilitado: false,
  encargos_percentual: 35,
  provisao_ferias_13_percentual: 16.7,
  crm: 0,
  telefonia: 0,
  whatsapp_tool: 0,
  discador: 0,
  outras_ferramentas: 0,
  combustivel: 0,
  reembolso_viagens: 0,
  viagens: 0,
  internet_telefone: 0,
  aluguel_rateio: 0,
  outros_fixos: 0,
  commission_enabled: true,
};

function formatCurrency(value: number): string {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  }).format(value);
}

function HelpTooltip({ text }: { text: string }) {
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <HelpCircle className="h-4 w-4 text-muted-foreground cursor-help" />
        </TooltipTrigger>
        <TooltipContent className="max-w-xs">
          <p className="text-sm">{text}</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

export function Phase1CostPanel({ 
  sellerId, 
  sellerName, 
  sellerRevenue,
  marginBruta,
  comissaoReal,
  comissaoPercentual,
  onCostCalculated 
}: Phase1CostPanelProps) {
  const [cost, setCost] = useState<SellerCostData>({ ...defaultCost, seller_id: sellerId });
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [expandedSections, setExpandedSections] = useState<string[]>(['salario']);

  useEffect(() => {
    loadCost();
  }, [sellerId]);

  const loadCost = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('seller_costs')
        .select('*')
        .eq('seller_id', sellerId)
        .maybeSingle();

      if (error) throw error;

      if (data) {
        setCost({
          id: data.id,
          seller_id: data.seller_id,
          salario_base: data.salario_base || 0,
          vale_alimentacao: (data as any).vale_alimentacao || 0,
          vale_transporte: data.vale_transporte || 0,
          vale_refeicao: data.vale_refeicao || 0,
          plano_saude: data.plano_saude || 0,
          ajuda_custo: data.ajuda_custo || 0,
          encargos_habilitado: (data as any).encargos_habilitado || false,
          encargos_percentual: data.encargos_percentual || 35,
          provisao_ferias_13_percentual: data.provisao_ferias_13_percentual || 16.7,
          crm: (data as any).crm || 0,
          telefonia: (data as any).telefonia || 0,
          whatsapp_tool: (data as any).whatsapp_tool || 0,
          discador: (data as any).discador || 0,
          outras_ferramentas: (data as any).outras_ferramentas || 0,
          combustivel: (data as any).combustivel || 0,
          reembolso_viagens: (data as any).reembolso_viagens || 0,
          viagens: (data as any).viagens || 0,
          internet_telefone: data.internet_telefone || 0,
          aluguel_rateio: data.aluguel_rateio || 0,
          outros_fixos: data.outros_fixos || 0,
          commission_enabled: (data as any).commission_enabled !== false,
        });
      } else {
        setCost({ ...defaultCost, seller_id: sellerId });
      }
    } catch (error) {
      console.error('Error loading seller cost:', error);
    } finally {
      setLoading(false);
    }
  };

  // =================================================================
  // NOVA ARQUITETURA FINANCEIRA CORRIGIDA
  // =================================================================
  // CDV (Fase 1) = APENAS custos variáveis (comissão)
  // Custo Humano (Fase 3) = Custos fixos do CPF
  // =================================================================
  const calculations = useMemo(() => {
    // =============================================
    // FASE 1 - CDV (Custo Direto Variável)
    // APENAS custos que existem SE vender
    // =============================================
    const cdv = comissaoReal; // CDV = APENAS comissão

    // =============================================
    // FASE 3 - Custo Humano (custos fixos do CPF)
    // =============================================
    // 1. Salário Base
    const salarioTotal = cost.salario_base;
    
    // 2. Encargos (se habilitado)
    const encargosValor = cost.encargos_habilitado 
      ? (cost.salario_base * (cost.encargos_percentual / 100)) + 
        (cost.salario_base * (cost.provisao_ferias_13_percentual / 100))
      : 0;
    
    // 3. Benefícios
    const beneficios = cost.vale_alimentacao + cost.vale_transporte + 
      cost.vale_refeicao + cost.plano_saude + cost.ajuda_custo;
    
    // 4. Ferramentas
    const ferramentas = cost.crm + cost.telefonia + cost.whatsapp_tool + 
      cost.discador + cost.outras_ferramentas;
    
    // 5. Deslocamento
    const deslocamento = cost.combustivel + cost.reembolso_viagens + cost.viagens;
    
    // Custo Humano = custos FIXOS (NÃO inclui comissão)
    const custoHumano = salarioTotal + encargosValor + beneficios + ferramentas + deslocamento;
    
    // =============================================
    // RESULTADO DIRETO (Fase 1) = Margem Bruta - CDV
    // Mede a qualidade da VENDA (sem custos fixos)
    // =============================================
    const resultadoDireto = marginBruta - cdv;
    const vendaFazSentido = resultadoDireto > 0;
    
    // =============================================
    // SE PAGA = Resultado Direto >= Custo Humano
    // (ou seja, a venda paga o CPF)
    // =============================================
    const sePaga = resultadoDireto >= custoHumano;
    
    return {
      cdv,
      custoHumano,
      salarioTotal,
      encargosValor,
      beneficios,
      ferramentas,
      deslocamento,
      resultadoDireto,
      vendaFazSentido,
      sePaga,
    };
  }, [cost, marginBruta, comissaoReal]);

  useEffect(() => {
    onCostCalculated(calculations.cdv, calculations.resultadoDireto);
  }, [calculations.cdv, calculations.resultadoDireto, onCostCalculated]);

  const handleChange = (field: keyof SellerCostData, value: number | boolean) => {
    setCost(prev => ({ ...prev, [field]: value }));
  };

  const toggleSection = (section: string) => {
    setExpandedSections(prev => 
      prev.includes(section) 
        ? prev.filter(s => s !== section)
        : [...prev, section]
    );
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const payload = {
        seller_id: sellerId,
        salario_base: cost.salario_base,
        vale_alimentacao: cost.vale_alimentacao,
        vale_transporte: cost.vale_transporte,
        vale_refeicao: cost.vale_refeicao,
        plano_saude: cost.plano_saude,
        ajuda_custo: cost.ajuda_custo,
        encargos_habilitado: cost.encargos_habilitado,
        encargos_percentual: cost.encargos_percentual,
        provisao_ferias_13_percentual: cost.provisao_ferias_13_percentual,
        crm: cost.crm,
        telefonia: cost.telefonia,
        whatsapp_tool: cost.whatsapp_tool,
        discador: cost.discador,
        outras_ferramentas: cost.outras_ferramentas,
        combustivel: cost.combustivel,
        reembolso_viagens: cost.reembolso_viagens,
        viagens: cost.viagens,
        internet_telefone: cost.internet_telefone,
        aluguel_rateio: cost.aluguel_rateio,
        outros_fixos: cost.outros_fixos,
        commission_enabled: cost.commission_enabled,
        custo_mensal_calculado: calculations.cdv,
      };

      if (cost.id) {
        const { error } = await supabase
          .from('seller_costs')
          .update(payload)
          .eq('id', cost.id);
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('seller_costs')
          .insert(payload);
        if (error) throw error;
      }

      await supabase
        .from('sellers')
        .update({ monthly_cost: calculations.cdv })
        .eq('id', sellerId);

      toast.success('Custos salvos com sucesso!');
    } catch (error: any) {
      console.error('Error saving seller cost:', error);
      toast.error('Erro ao salvar custos: ' + error.message);
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return <div className="py-8 text-center text-muted-foreground">Carregando...</div>;
  }

  return (
    <div className="space-y-4">
      {/* Header com resultado */}
      <Card className={`border-2 ${calculations.sePaga ? 'border-green-500/50 bg-green-50/50' : 'border-red-500/50 bg-red-50/50'}`}>
        <CardContent className="pt-4">
          <div className="flex items-center justify-between">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <div className="cursor-help">
                    <p className="text-sm text-muted-foreground">Resultado Direto</p>
                    <p className={`text-2xl font-bold ${calculations.sePaga ? 'text-green-600' : 'text-red-600'}`}>
                      {formatCurrency(calculations.resultadoDireto)}
                    </p>
                  </div>
                </TooltipTrigger>
                <TooltipContent className="max-w-xs">
                  <p className="text-xs">Mostra o que sobra da margem depois de tirar os custos variáveis da venda, antes da estrutura geral da empresa.</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
            <div className={`p-3 rounded-full ${calculations.sePaga ? 'bg-green-100' : 'bg-red-100'}`}>
              {calculations.sePaga ? (
                <Check className="h-6 w-6 text-green-600" />
              ) : (
                <AlertTriangle className="h-6 w-6 text-red-600" />
              )}
            </div>
          </div>
          <p className={`text-sm mt-2 ${calculations.sePaga ? 'text-green-700' : 'text-red-700'}`}>
            {calculations.sePaga 
              ? '✓ Venda cobre custos fixos + variáveis' 
              : `✗ Falta ${formatCurrency(calculations.custoHumano - calculations.resultadoDireto)} para cobrir custo humano`}
          </p>
        </CardContent>
      </Card>

      {/* Resumo Nova Arquitetura */}
      <Card className="border-primary/30 bg-primary/5">
        <CardContent className="pt-4 space-y-2">
          <div className="grid grid-cols-2 gap-4 text-sm">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <div className="cursor-help">
                    <p className="text-xs text-muted-foreground">CDV Variável do Vendedor</p>
                    <p className="font-bold text-amber-600">{formatCurrency(calculations.cdv)}</p>
                  </div>
                </TooltipTrigger>
                <TooltipContent className="max-w-xs">
                  <p className="text-xs">Custos variáveis ligados à venda, principalmente comissão.</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <div className="cursor-help">
                    <p className="text-xs text-muted-foreground">Custo Humano do Vendedor</p>
                    <p className="font-bold text-purple-600">{formatCurrency(calculations.custoHumano)}</p>
                  </div>
                </TooltipTrigger>
                <TooltipContent className="max-w-xs">
                  <p className="text-xs">Custos mensais fixos deste vendedor, como salário, encargos e benefícios.</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
          <div className="pt-2 border-t">
            <p className="text-xs text-muted-foreground">Resultado Direto (Margem - CDV)</p>
            <p className={`font-bold ${calculations.vendaFazSentido ? 'text-emerald-600' : 'text-red-600'}`}>
              {formatCurrency(calculations.resultadoDireto)}
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Seções de entrada */}
      <div className="space-y-3">
        {/* Salário */}
        <Collapsible open={expandedSections.includes('salario')} onOpenChange={() => toggleSection('salario')}>
          <Card>
            <CollapsibleTrigger className="w-full">
              <CardHeader className="py-3 flex flex-row items-center justify-between">
                <div className="flex items-center gap-2">
                  <User className="h-4 w-4 text-primary" />
                  <CardTitle className="text-sm font-medium">Salário Base</CardTitle>
                  <HelpTooltip text="Valor fixo pago ao vendedor independentemente de venda." />
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-semibold">{formatCurrency(cost.salario_base)}</span>
                  {expandedSections.includes('salario') ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                </div>
              </CardHeader>
            </CollapsibleTrigger>
            <CollapsibleContent>
              <CardContent className="pt-0">
                <div className="space-y-2">
                  <Label>Salário Base (R$)</Label>
                  <Input
                    type="number"
                    value={cost.salario_base}
                    onChange={(e) => handleChange('salario_base', Number(e.target.value))}
                  />
                </div>
              </CardContent>
            </CollapsibleContent>
          </Card>
        </Collapsible>

        {/* Comissão - READ ONLY - Calculada automaticamente do CRM */}
        <Card className="border-amber-200 bg-amber-50/50">
          <CardHeader className="py-3 flex flex-row items-center justify-between">
            <div className="flex items-center gap-2">
              <DollarSign className="h-4 w-4 text-amber-600" />
              <CardTitle className="text-sm font-medium">Comissão Real</CardTitle>
              <HelpTooltip text="A comissão é calculada automaticamente com base nas regras do CRM e nas vendas reais do vendedor no período. Não é editável manualmente." />
            </div>
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2">
                <Label htmlFor="commission-toggle" className="text-xs text-muted-foreground cursor-pointer">
                  Comissão ativa
                </Label>
                <Switch
                  id="commission-toggle"
                  checked={cost.commission_enabled}
                  onCheckedChange={(checked) => handleChange('commission_enabled', checked)}
                />
              </div>
              <span className="text-sm font-semibold text-amber-600">
                {cost.commission_enabled ? formatCurrency(comissaoReal) : 'R$ 0'}
              </span>
            </div>
          </CardHeader>
          <CardContent className="pt-0">
            {!cost.commission_enabled && (
              <div className="mb-3 p-2 bg-amber-100 border border-amber-300 rounded-md flex items-center gap-2">
                <AlertTriangle className="h-4 w-4 text-amber-600" />
                <span className="text-xs text-amber-800 font-medium">Comissão desativada (modo salário fixo)</span>
              </div>
            )}
            <div className="grid grid-cols-2 gap-4">
              <div className="p-3 bg-white rounded-lg border border-amber-200">
                <p className="text-xs text-muted-foreground">Valor da Comissão</p>
                <p className="text-lg font-bold text-amber-600">
                  {cost.commission_enabled ? formatCurrency(comissaoReal) : formatCurrency(0)}
                </p>
              </div>
              <div className="p-3 bg-white rounded-lg border border-amber-200">
                <p className="text-xs text-muted-foreground">% Efetivo sobre Receita</p>
                <p className="text-lg font-bold text-amber-600">
                  {cost.commission_enabled ? `${comissaoPercentual.toFixed(2)}%` : '0.00%'}
                </p>
              </div>
            </div>
            <p className="text-xs text-amber-700 mt-2 flex items-center gap-1">
              <AlertTriangle className="h-3 w-3" />
              {cost.commission_enabled 
                ? 'Valor calculado automaticamente com base nas vendas do período'
                : 'Comissão temporariamente desligada — vendedor em modo salário fixo'}
            </p>
          </CardContent>
        </Card>

        {/* Benefícios */}
        <Collapsible open={expandedSections.includes('beneficios')} onOpenChange={() => toggleSection('beneficios')}>
          <Card>
            <CollapsibleTrigger className="w-full">
              <CardHeader className="py-3 flex flex-row items-center justify-between">
                <div className="flex items-center gap-2">
                  <Briefcase className="h-4 w-4 text-primary" />
                  <CardTitle className="text-sm font-medium">Benefícios</CardTitle>
                  <HelpTooltip text="Custos obrigatórios ou concedidos ao vendedor para manter a operação." />
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-semibold">{formatCurrency(calculations.beneficios)}</span>
                  {expandedSections.includes('beneficios') ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                </div>
              </CardHeader>
            </CollapsibleTrigger>
            <CollapsibleContent>
              <CardContent className="pt-0 grid grid-cols-3 gap-3">
                <div className="space-y-2">
                  <Label>Vale-alimentação</Label>
                  <Input
                    type="number"
                    value={cost.vale_alimentacao}
                    onChange={(e) => handleChange('vale_alimentacao', Number(e.target.value))}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Vale-transporte</Label>
                  <Input
                    type="number"
                    value={cost.vale_transporte}
                    onChange={(e) => handleChange('vale_transporte', Number(e.target.value))}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Vale-refeição</Label>
                  <Input
                    type="number"
                    value={cost.vale_refeicao}
                    onChange={(e) => handleChange('vale_refeicao', Number(e.target.value))}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Plano de saúde</Label>
                  <Input
                    type="number"
                    value={cost.plano_saude}
                    onChange={(e) => handleChange('plano_saude', Number(e.target.value))}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Ajuda de custo</Label>
                  <Input
                    type="number"
                    value={cost.ajuda_custo}
                    onChange={(e) => handleChange('ajuda_custo', Number(e.target.value))}
                  />
                </div>
              </CardContent>
            </CollapsibleContent>
          </Card>
        </Collapsible>

        {/* Encargos */}
        <Collapsible open={expandedSections.includes('encargos')} onOpenChange={() => toggleSection('encargos')}>
          <Card>
            <CollapsibleTrigger className="w-full">
              <CardHeader className="py-3 flex flex-row items-center justify-between">
                <div className="flex items-center gap-2">
                  <CardTitle className="text-sm font-medium">Encargos Trabalhistas</CardTitle>
                  <HelpTooltip text="Custos trabalhistas que a empresa assume sobre a folha." />
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-semibold">{formatCurrency(calculations.encargosValor)}</span>
                  {expandedSections.includes('encargos') ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                </div>
              </CardHeader>
            </CollapsibleTrigger>
            <CollapsibleContent>
              <CardContent className="pt-0 space-y-4">
                <div className="flex items-center justify-between">
                  <Label>Habilitar cálculo de encargos</Label>
                  <Switch
                    checked={cost.encargos_habilitado}
                    onCheckedChange={(checked) => handleChange('encargos_habilitado', checked)}
                  />
                </div>
                {cost.encargos_habilitado && (
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-2">
                      <Label>INSS/FGTS (%)</Label>
                      <Input
                        type="number"
                        step="0.1"
                        value={cost.encargos_percentual}
                        onChange={(e) => handleChange('encargos_percentual', Number(e.target.value))}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Férias/13º (%)</Label>
                      <Input
                        type="number"
                        step="0.1"
                        value={cost.provisao_ferias_13_percentual}
                        onChange={(e) => handleChange('provisao_ferias_13_percentual', Number(e.target.value))}
                      />
                    </div>
                  </div>
                )}
              </CardContent>
            </CollapsibleContent>
          </Card>
        </Collapsible>

        {/* Ferramentas */}
        <Collapsible open={expandedSections.includes('ferramentas')} onOpenChange={() => toggleSection('ferramentas')}>
          <Card>
            <CollapsibleTrigger className="w-full">
              <CardHeader className="py-3 flex flex-row items-center justify-between">
                <div className="flex items-center gap-2">
                  <Wrench className="h-4 w-4 text-primary" />
                  <CardTitle className="text-sm font-medium">Ferramentas por Usuário</CardTitle>
                  <HelpTooltip text="Ferramentas utilizadas exclusivamente pelo vendedor." />
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-semibold">{formatCurrency(calculations.ferramentas)}</span>
                  {expandedSections.includes('ferramentas') ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                </div>
              </CardHeader>
            </CollapsibleTrigger>
            <CollapsibleContent>
              <CardContent className="pt-0 grid grid-cols-3 gap-3">
                <div className="space-y-2">
                  <Label>CRM</Label>
                  <Input
                    type="number"
                    value={cost.crm}
                    onChange={(e) => handleChange('crm', Number(e.target.value))}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Telefonia</Label>
                  <Input
                    type="number"
                    value={cost.telefonia}
                    onChange={(e) => handleChange('telefonia', Number(e.target.value))}
                  />
                </div>
                <div className="space-y-2">
                  <Label>WhatsApp</Label>
                  <Input
                    type="number"
                    value={cost.whatsapp_tool}
                    onChange={(e) => handleChange('whatsapp_tool', Number(e.target.value))}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Discador</Label>
                  <Input
                    type="number"
                    value={cost.discador}
                    onChange={(e) => handleChange('discador', Number(e.target.value))}
                  />
                </div>
                <div className="space-y-2 col-span-2">
                  <Label>Outras ferramentas</Label>
                  <Input
                    type="number"
                    value={cost.outras_ferramentas}
                    onChange={(e) => handleChange('outras_ferramentas', Number(e.target.value))}
                  />
                </div>
              </CardContent>
            </CollapsibleContent>
          </Card>
        </Collapsible>

        {/* Deslocamento */}
        <Collapsible open={expandedSections.includes('deslocamento')} onOpenChange={() => toggleSection('deslocamento')}>
          <Card>
            <CollapsibleTrigger className="w-full">
              <CardHeader className="py-3 flex flex-row items-center justify-between">
                <div className="flex items-center gap-2">
                  <Car className="h-4 w-4 text-primary" />
                  <CardTitle className="text-sm font-medium">Deslocamento Individual</CardTitle>
                  <HelpTooltip text="Custos de locomoção diretamente atribuídos ao vendedor." />
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-semibold">{formatCurrency(calculations.deslocamento)}</span>
                  {expandedSections.includes('deslocamento') ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                </div>
              </CardHeader>
            </CollapsibleTrigger>
            <CollapsibleContent>
              <CardContent className="pt-0 grid grid-cols-3 gap-3">
                <div className="space-y-2">
                  <Label>Combustível</Label>
                  <Input
                    type="number"
                    value={cost.combustivel}
                    onChange={(e) => handleChange('combustivel', Number(e.target.value))}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Reembolso/KM</Label>
                  <Input
                    type="number"
                    value={cost.reembolso_viagens}
                    onChange={(e) => handleChange('reembolso_viagens', Number(e.target.value))}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Viagens</Label>
                  <Input
                    type="number"
                    value={cost.viagens}
                    onChange={(e) => handleChange('viagens', Number(e.target.value))}
                  />
                </div>
              </CardContent>
            </CollapsibleContent>
          </Card>
        </Collapsible>
      </div>

      {/* Resumo CDV */}
      <Card className="border-primary/30 bg-primary/5">
        <CardContent className="pt-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
            <div className="p-2 bg-background rounded-lg">
              <p className="text-xs text-muted-foreground">Salário + Encargos</p>
              <p className="font-bold">{formatCurrency(calculations.salarioTotal + calculations.encargosValor)}</p>
            </div>
            <div className="p-2 bg-background rounded-lg">
              <p className="text-xs text-muted-foreground">Benefícios</p>
              <p className="font-bold">{formatCurrency(calculations.beneficios)}</p>
            </div>
            <div className="p-2 bg-amber-100 rounded-lg">
              <p className="text-xs text-muted-foreground">Comissão Real</p>
              <p className="font-bold text-amber-600">{formatCurrency(comissaoReal)}</p>
            </div>
            <div className="p-2 bg-primary/20 rounded-lg">
              <p className="text-xs text-muted-foreground">CDV Total</p>
              <p className="text-xl font-bold text-primary">{formatCurrency(calculations.cdv)}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <p className="text-xs text-muted-foreground text-center px-4">
        Este modal mostra apenas o custo direto do vendedor. A estrutura geral da empresa é analisada separadamente no painel.
      </p>

      <Button onClick={handleSave} disabled={saving} className="w-full">
        {saving ? 'Salvando...' : 'Salvar Custos do Vendedor'}
      </Button>
    </div>
  );
}
