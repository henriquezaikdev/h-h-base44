import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { BarChart3, Zap, Coins, Star, Diamond, Trophy, Users, AlertTriangle } from 'lucide-react';
import { format, startOfMonth, endOfMonth } from 'date-fns';

const sb = supabase as any;

interface DashboardKPIs {
  totalXpMonth: number;
  totalHcoinsConverted: number;
  totalHcoinsSpent: number;
  totalStarsGranted: number;
  totalCrystals: number;
  activeCampaigns: number;
  pendingAcceptances: number;
  pendingRulebook: number;
  activeUsers: number;
  shopPendingOrders: number;
}

export function GestorDashboardTab() {
  const [kpis, setKpis] = useState<DashboardKPIs | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboard();
  }, []);

  const fetchDashboard = async () => {
    const now = new Date();
    const monthStart = format(startOfMonth(now), 'yyyy-MM-dd');
    const monthEnd = format(endOfMonth(now), 'yyyy-MM-dd');

    const [xpRes, hcoinsConvRes, hcoinsSpentRes, starsRes, crystalsRes, campaignsRes, campAcceptRes, rulebookRes, activeRes, shopRes] = await Promise.all([
      sb.from('xp_log').select('xp_delta').gte('created_at', monthStart + 'T00:00:00').lte('created_at', monthEnd + 'T23:59:59'),
      sb.from('hcoins_log').select('amount').eq('event_type', 'CONVERSION').gte('created_at', monthStart + 'T00:00:00'),
      sb.from('hcoins_log').select('amount').eq('event_type', 'SHOP_PURCHASE').gte('created_at', monthStart + 'T00:00:00'),
      sb.from('star_ledger').select('delta').gt('delta', 0).gte('created_at', monthStart + 'T00:00:00'),
      sb.from('crystal_awards').select('id', { count: 'exact', head: true }),
      sb.from('incentive_campaigns').select('id', { count: 'exact', head: true }).eq('status', 'ACTIVE'),
      sb.from('incentive_campaign_participants').select('id', { count: 'exact', head: true }).eq('status', 'INVITED'),
      sb.from('rulebook').select('id').eq('is_active', true).limit(1),
      supabase.from('sellers').select('id', { count: 'exact', head: true }).eq('status', 'ATIVO'),
      sb.from('shop_orders').select('id', { count: 'exact', head: true }).eq('status', 'PENDING'),
    ]);

    const totalXp = (xpRes.data || []).reduce((sum: number, l: any) => sum + (l.xp_delta || 0), 0);
    const totalConv = (hcoinsConvRes.data || []).reduce((sum: number, l: any) => sum + Math.abs(l.amount || 0), 0);
    const totalSpent = (hcoinsSpentRes.data || []).reduce((sum: number, l: any) => sum + Math.abs(l.amount || 0), 0);
    const totalStars = (starsRes.data || []).reduce((sum: number, l: any) => sum + (l.delta || 0), 0);

    setKpis({
      totalXpMonth: totalXp,
      totalHcoinsConverted: totalConv,
      totalHcoinsSpent: totalSpent,
      totalStarsGranted: totalStars,
      totalCrystals: crystalsRes.count || 0,
      activeCampaigns: campaignsRes.count || 0,
      pendingAcceptances: campAcceptRes.count || 0,
      pendingRulebook: 0,
      activeUsers: activeRes.count || 0,
      shopPendingOrders: shopRes.count || 0,
    });
    setLoading(false);
  };

  if (loading || !kpis) {
    return <div className="py-12 text-center text-muted-foreground animate-pulse text-sm">Carregando dashboard...</div>;
  }

  const cards = [
    { label: 'XP gerado no mês', value: kpis.totalXpMonth.toLocaleString('pt-BR'), icon: Zap, color: 'text-blue-600', bg: 'bg-blue-50' },
    { label: 'HCoins convertidos', value: kpis.totalHcoinsConverted.toLocaleString('pt-BR'), icon: Coins, color: 'text-amber-600', bg: 'bg-amber-50' },
    { label: 'HCoins gastos (Loja)', value: kpis.totalHcoinsSpent.toLocaleString('pt-BR'), icon: Coins, color: 'text-orange-600', bg: 'bg-orange-50' },
    { label: 'Estrelas concedidas', value: kpis.totalStarsGranted.toString(), icon: Star, color: 'text-purple-600', bg: 'bg-purple-50' },
    { label: 'Cristais acumulados', value: kpis.totalCrystals.toString(), icon: Diamond, color: 'text-cyan-600', bg: 'bg-cyan-50' },
    { label: 'Campanhas ativas', value: kpis.activeCampaigns.toString(), icon: Trophy, color: 'text-emerald-600', bg: 'bg-emerald-50' },
    { label: 'Colaboradores ativos', value: kpis.activeUsers.toString(), icon: Users, color: 'text-slate-600', bg: 'bg-slate-50' },
    { label: 'Aceites pendentes', value: kpis.pendingAcceptances.toString(), icon: AlertTriangle, color: kpis.pendingAcceptances > 0 ? 'text-red-600' : 'text-emerald-600', bg: kpis.pendingAcceptances > 0 ? 'bg-red-50' : 'bg-emerald-50' },
  ];

  return (
    <div className="space-y-4">
      <Card className="bg-card/80 backdrop-blur-sm rounded-2xl shadow-sm border border-border/50">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <BarChart3 className="h-4 w-4 text-primary" /> Dashboard Estratégico — Cultura & Gamificação
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {cards.map((c, i) => {
              const Icon = c.icon;
              return (
                <div key={i} className={`${c.bg} rounded-2xl p-4 border border-border/30`}>
                  <div className="flex items-center gap-2 mb-2">
                    <Icon className={`h-4 w-4 ${c.color}`} />
                    <span className="text-[10px] text-muted-foreground font-medium uppercase tracking-wide">{c.label}</span>
                  </div>
                  <p className={`text-2xl font-bold ${c.color}`}>{c.value}</p>
                </div>
              );
            })}
          </div>

          {(kpis.pendingAcceptances > 0 || kpis.shopPendingOrders > 0) && (
            <div className="mt-4 space-y-2">
              {kpis.pendingAcceptances > 0 && (
                <div className="flex items-center gap-2 p-3 rounded-xl bg-amber-50 border border-amber-200">
                  <AlertTriangle className="h-4 w-4 text-amber-600" />
                  <span className="text-xs text-amber-800">
                    {kpis.pendingAcceptances} participante(s) ainda não aceitaram campanhas ativas
                  </span>
                </div>
              )}
              {kpis.shopPendingOrders > 0 && (
                <div className="flex items-center gap-2 p-3 rounded-xl bg-blue-50 border border-blue-200">
                  <AlertTriangle className="h-4 w-4 text-blue-600" />
                  <span className="text-xs text-blue-800">
                    {kpis.shopPendingOrders} pedido(s) da Loja aguardando aprovação
                  </span>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
