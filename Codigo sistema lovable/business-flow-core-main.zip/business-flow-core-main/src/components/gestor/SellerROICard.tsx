import { Settings2, TrendingUp, AlertTriangle, XCircle, AlertCircle, Phone, MessageCircle, ShoppingCart } from 'lucide-react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { cn } from '@/lib/utils';
import type { SellerROI } from '@/hooks/useGestorData';

interface SellerROICardProps {
  seller: SellerROI;
  rank: number;
  isSelected: boolean;
  onSelect: () => void;
  onEditCost: () => void;
}

function formatCurrency(value: number): string {
  if (value >= 1000000) {
    return `R$ ${(value / 1000000).toFixed(1)}M`;
  }
  if (value >= 1000) {
    return `R$ ${(value / 1000).toFixed(0)}K`;
  }
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value);
}

function getRankBadge(rank: number) {
  if (rank === 1) return { emoji: '🥇', className: 'bg-amber-500/10 text-amber-500 border-amber-500/30' };
  if (rank === 2) return { emoji: '🥈', className: 'bg-slate-400/10 text-slate-400 border-slate-400/30' };
  if (rank === 3) return { emoji: '🥉', className: 'bg-orange-600/10 text-orange-600 border-orange-600/30' };
  return { emoji: `#${rank}`, className: 'bg-muted text-muted-foreground border-muted' };
}

function getStatusConfig(status: 'viable' | 'attention' | 'inviable', hasCost: boolean) {
  if (!hasCost) {
    return {
      label: 'Sem custo',
      className: 'bg-muted/50 text-muted-foreground border-muted',
      icon: AlertCircle,
      ringColor: 'ring-muted/20',
    };
  }

  const configs = {
    viable: {
      label: 'Viável',
      className: 'bg-emerald-500/10 text-emerald-500 border-emerald-500/30',
      icon: TrendingUp,
      ringColor: 'ring-emerald-500/20',
    },
    attention: {
      label: 'Atenção',
      className: 'bg-amber-500/10 text-amber-500 border-amber-500/30',
      icon: AlertTriangle,
      ringColor: 'ring-amber-500/20',
    },
    inviable: {
      label: 'Inviável',
      className: 'bg-destructive/10 text-destructive border-destructive/30',
      icon: XCircle,
      ringColor: 'ring-destructive/20',
    },
  };

  return configs[status];
}

export function SellerROICard({ seller, rank, isSelected, onSelect, onEditCost }: SellerROICardProps) {
  const hasCost = seller.periodCost > 0;
  const rankConfig = getRankBadge(rank);
  const statusConfig = getStatusConfig(seller.viabilityStatus, hasCost);
  const StatusIcon = statusConfig.icon;

  // Calculate conversion progress (max 20% is 100% of bar)
  const conversionProgress = Math.min(100, (seller.conversionRate / 20) * 100);

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      whileHover={{ y: -4, transition: { duration: 0.2 } }}
      onClick={onSelect}
      className={cn(
        'relative rounded-xl border bg-card p-4 cursor-pointer transition-all duration-200',
        isSelected 
          ? 'ring-2 ring-primary border-primary shadow-lg' 
          : 'hover:border-primary/40 hover:shadow-md',
        !hasCost && 'border-dashed border-amber-500/50'
      )}
    >
      {/* Header */}
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-2">
          <Badge variant="outline" className={cn('text-xs', rankConfig.className)}>
            {rankConfig.emoji}
          </Badge>
          <h3 className="font-semibold truncate max-w-[120px]">{seller.name}</h3>
        </div>
        <Button
          variant="ghost"
          size="icon"
          className={cn(
            'h-7 w-7 shrink-0',
            !hasCost && 'text-amber-500 hover:text-amber-600 animate-pulse'
          )}
          onClick={(e) => {
            e.stopPropagation();
            onEditCost();
          }}
        >
          <Settings2 className="h-4 w-4" />
        </Button>
      </div>

      {/* Main Metrics */}
      <div className="space-y-3">
        {/* Revenue & Profit */}
        <div className="grid grid-cols-2 gap-2">
          <div className="bg-muted/30 rounded-lg p-2">
            <p className="text-[10px] uppercase text-muted-foreground tracking-wider">Receita</p>
            <p className="text-lg font-bold text-primary">{formatCurrency(seller.revenue)}</p>
          </div>
          <div className="bg-muted/30 rounded-lg p-2">
            <p className="text-[10px] uppercase text-muted-foreground tracking-wider">Lucro</p>
            <p className={cn(
              'text-lg font-bold',
              seller.profit > 0 ? 'text-emerald-500' : 'text-destructive'
            )}>
              {formatCurrency(seller.profit)}
            </p>
          </div>
        </div>

        {/* Activity Icons */}
        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1">
              <Phone className="h-3 w-3" />
              {seller.calls}
            </span>
            <span className="flex items-center gap-1">
              <MessageCircle className="h-3 w-3" />
              {seller.whatsapp}
            </span>
            <span className="flex items-center gap-1">
              <ShoppingCart className="h-3 w-3" />
              {seller.ordersCount}
            </span>
          </div>
          <span className="font-medium">{seller.avgTicket > 0 ? formatCurrency(seller.avgTicket) : '-'}</span>
        </div>

        {/* Conversion Progress */}
        <div>
          <div className="flex items-center justify-between text-xs mb-1">
            <span className="text-muted-foreground">Conversão</span>
            <span className="font-medium">{seller.conversionRate.toFixed(1)}%</span>
          </div>
          <Progress 
            value={conversionProgress} 
            className="h-1.5 [&>div]:bg-primary"
          />
        </div>

        {/* ROI & Status Footer */}
        <div className="flex items-center justify-between pt-2 border-t">
          <div className="flex items-center gap-1.5">
            <StatusIcon className={cn('h-4 w-4', statusConfig.className.split(' ')[1])} />
            <Badge variant="outline" className={cn('text-xs', statusConfig.className)}>
              {statusConfig.label}
            </Badge>
          </div>
          <div className="text-right">
            {hasCost ? (
              <div className="flex items-baseline gap-1">
                <span className={cn(
                  'text-lg font-bold',
                  seller.roiRevenue >= 3 ? 'text-emerald-500' :
                  seller.roiRevenue >= 2 ? 'text-amber-500' : 'text-destructive'
                )}>
                  {seller.roiRevenue.toFixed(1)}x
                </span>
                <span className="text-[10px] text-muted-foreground">ROI</span>
              </div>
            ) : (
              <span className="text-xs text-amber-500">Configure custo →</span>
            )}
          </div>
        </div>
      </div>

      {/* Selected Indicator */}
      {isSelected && (
        <motion.div
          layoutId="selectedIndicator"
          className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-8 h-1 bg-primary rounded-full"
        />
      )}
    </motion.div>
  );
}
