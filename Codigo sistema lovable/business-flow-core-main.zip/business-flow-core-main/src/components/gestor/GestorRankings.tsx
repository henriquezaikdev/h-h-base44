import { motion } from 'framer-motion';
import { TrendingUp, TrendingDown, Trophy, AlertTriangle, Check, Minus } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

interface SellerResult {
  id: string;
  name: string;
  revenue: number;
  profit: number;
  marginBruta: number;
  comissaoReal: number;
  comissaoPercentual: number;
  cdv: number;
  ceeRateio: number;
  resultadoDireto: number;
  resultadoReal: number;
}

interface GestorRankingsProps {
  sellers: SellerResult[];
}

function formatCurrency(value: number): string {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value);
}

export function GestorRankings({ sellers }: GestorRankingsProps) {
  // Ranking por Resultado Direto
  const rankingDireto = [...sellers].sort((a, b) => b.resultadoDireto - a.resultadoDireto);
  
  // Ranking por Resultado Real
  const rankingReal = [...sellers].sort((a, b) => b.resultadoReal - a.resultadoReal);
  
  // Categorias
  const naoSePagam = sellers.filter(s => s.resultadoDireto < 0);
  const sePagamMasNaoSustentam = sellers.filter(s => s.resultadoDireto > 0 && s.resultadoReal < 0);
  const geramLucroReal = sellers.filter(s => s.resultadoReal > 0);

  return (
    <div className="space-y-6">
      {/* Cards de Resumo */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <motion.div whileHover={{ scale: 1.02 }}>
          <Card className="border-green-200 bg-green-50/50">
            <CardContent className="pt-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-green-700 font-medium">Geram Lucro Real</p>
                  <p className="text-3xl font-bold text-green-600">{geramLucroReal.length}</p>
                </div>
                <div className="p-3 rounded-full bg-green-100">
                  <Trophy className="h-6 w-6 text-green-600" />
                </div>
              </div>
              <div className="mt-2 flex flex-wrap gap-1">
                {geramLucroReal.slice(0, 3).map(s => (
                  <Badge key={s.id} variant="secondary" className="bg-green-100 text-green-700 text-xs">
                    {s.name.split(' ')[0]}
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div whileHover={{ scale: 1.02 }}>
          <Card className="border-yellow-200 bg-yellow-50/50">
            <CardContent className="pt-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-yellow-700 font-medium">Se Pagam, Mas...</p>
                  <p className="text-3xl font-bold text-yellow-600">{sePagamMasNaoSustentam.length}</p>
                </div>
                <div className="p-3 rounded-full bg-yellow-100">
                  <Minus className="h-6 w-6 text-yellow-600" />
                </div>
              </div>
              <p className="text-xs text-yellow-600 mt-2">
                Não sustentam a estrutura
              </p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div whileHover={{ scale: 1.02 }}>
          <Card className="border-red-200 bg-red-50/50">
            <CardContent className="pt-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-red-700 font-medium">Não Se Pagam</p>
                  <p className="text-3xl font-bold text-red-600">{naoSePagam.length}</p>
                </div>
                <div className="p-3 rounded-full bg-red-100">
                  <AlertTriangle className="h-6 w-6 text-red-600" />
                </div>
              </div>
              <div className="mt-2 flex flex-wrap gap-1">
                {naoSePagam.slice(0, 3).map(s => (
                  <Badge key={s.id} variant="secondary" className="bg-red-100 text-red-700 text-xs">
                    {s.name.split(' ')[0]}
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Rankings lado a lado */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Ranking por Resultado Direto */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-primary" />
              Ranking: Resultado Direto
            </CardTitle>
            <p className="text-xs text-muted-foreground">Quem se paga com a própria margem</p>
          </CardHeader>
          <CardContent className="space-y-2">
            {rankingDireto.map((seller, index) => (
              <div 
                key={seller.id}
                className={`flex items-center justify-between p-2 rounded-lg ${
                  seller.resultadoDireto > 0 ? 'bg-green-50' : 'bg-red-50'
                }`}
              >
                <div className="flex items-center gap-2">
                  <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                    index === 0 ? 'bg-amber-500 text-white' : 
                    index === 1 ? 'bg-gray-400 text-white' : 
                    index === 2 ? 'bg-amber-700 text-white' : 
                    'bg-muted text-muted-foreground'
                  }`}>
                    {index + 1}
                  </span>
                  <span className="text-sm font-medium">{seller.name}</span>
                </div>
                <span className={`text-sm font-bold ${
                  seller.resultadoDireto > 0 ? 'text-green-600' : 'text-red-600'
                }`}>
                  {formatCurrency(seller.resultadoDireto)}
                </span>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Ranking por Resultado Real */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <Trophy className="h-4 w-4 text-primary" />
              Ranking: Resultado Real
            </CardTitle>
            <p className="text-xs text-muted-foreground">Quem sustenta a empresa de verdade</p>
          </CardHeader>
          <CardContent className="space-y-2">
            {rankingReal.map((seller, index) => {
              const sustenta = seller.resultadoReal > 0;
              const empata = seller.resultadoReal >= -500 && seller.resultadoReal <= 500;
              
              return (
                <div 
                  key={seller.id}
                  className={`flex items-center justify-between p-2 rounded-lg ${
                    sustenta ? 'bg-green-50' : empata ? 'bg-yellow-50' : 'bg-red-50'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                      index === 0 ? 'bg-amber-500 text-white' : 
                      index === 1 ? 'bg-gray-400 text-white' : 
                      index === 2 ? 'bg-amber-700 text-white' : 
                      'bg-muted text-muted-foreground'
                    }`}>
                      {index + 1}
                    </span>
                    <span className="text-sm font-medium">{seller.name}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    {sustenta && <Check className="h-4 w-4 text-green-600" />}
                    {!sustenta && !empata && <TrendingDown className="h-4 w-4 text-red-600" />}
                    <span className={`text-sm font-bold ${
                      sustenta ? 'text-green-600' : empata ? 'text-yellow-600' : 'text-red-600'
                    }`}>
                      {formatCurrency(seller.resultadoReal)}
                    </span>
                  </div>
                </div>
              );
            })}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
