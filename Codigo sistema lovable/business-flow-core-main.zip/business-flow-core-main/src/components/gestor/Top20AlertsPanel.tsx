import { useState, useEffect, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { 
  Crown, 
  AlertTriangle, 
  Phone, 
  Clock, 
  TrendingDown,
  ChevronRight,
  Loader2,
  Eye,
  UserX,
  Calendar
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { supabase } from '@/integrations/supabase/client';
import { differenceInDays, format } from 'date-fns';
import { cn } from '@/lib/utils';

interface Top20AlertsPanelProps {
  sellerId?: string | null;
}

interface ClientAlert {
  id: string;
  company_name: string;
  seller_name: string;
  seller_id: string | null;
  days_since_contact: number | null;
  days_since_order: number | null;
  last_contact_at: string | null;
  last_order_date: string | null;
  total_revenue: number;
  alert_type: 'no_contact' | 'entering_risk' | 'inactive' | 'no_orders_period';
  priority: number;
}

const ALERT_CONFIG = {
  no_contact: {
    label: 'Sem contato há 15+ dias',
    icon: Phone,
    color: 'border-l-amber-500 bg-amber-500/10 dark:bg-amber-500/5',
    iconColor: 'text-amber-500',
    badge: 'bg-amber-500',
  },
  entering_risk: {
    label: 'Entrando em risco (46-60 dias)',
    icon: Clock,
    color: 'border-l-orange-500 bg-orange-500/10 dark:bg-orange-500/5',
    iconColor: 'text-orange-500',
    badge: 'bg-orange-500',
  },
  inactive: {
    label: 'Inativo (90+ dias sem compra)',
    icon: TrendingDown,
    color: 'border-l-destructive bg-destructive/10 dark:bg-destructive/5',
    iconColor: 'text-destructive',
    badge: 'bg-destructive',
  },
  no_orders_period: {
    label: 'Sem pedidos no período',
    icon: UserX,
    color: 'border-l-purple-500 bg-purple-500/10 dark:bg-purple-500/5',
    iconColor: 'text-purple-500',
    badge: 'bg-purple-500',
  },
};

export function Top20AlertsPanel({ sellerId }: Top20AlertsPanelProps) {
  const [loading, setLoading] = useState(true);
  const [clients, setClients] = useState<ClientAlert[]>([]);
  const [expandedType, setExpandedType] = useState<string | null>(null);

  useEffect(() => {
    const fetchTop20Alerts = async () => {
      setLoading(true);
      try {
        // Buscar clientes Top 20
        let query = supabase
          .from('clients')
          .select(`
            id,
            company_name,
            last_contact_at,
            last_order_date,
            days_since_last_order,
            total_revenue,
            seller_id,
            sellers!clients_seller_id_fkey(name)
          `)
          .eq('is_deleted', false)
          .eq('ranking_tier', 'top20')
          .order('total_revenue', { ascending: false });

        if (sellerId) {
          query = query.eq('seller_id', sellerId);
        }

        const { data, error } = await query;

        if (error) {
          console.error('Error fetching Top 20 clients:', error);
          return;
        }

        const now = new Date();
        const alerts: ClientAlert[] = [];

        (data || []).forEach((client: any) => {
          const daysSinceContact = client.last_contact_at 
            ? differenceInDays(now, new Date(client.last_contact_at))
            : null;
          const daysSinceOrder = client.days_since_last_order || 
            (client.last_order_date 
              ? differenceInDays(now, new Date(client.last_order_date))
              : null);

          const baseAlert = {
            id: client.id,
            company_name: client.company_name,
            seller_name: (client.sellers as any)?.name || 'Sem vendedor',
            seller_id: client.seller_id,
            days_since_contact: daysSinceContact,
            days_since_order: daysSinceOrder,
            last_contact_at: client.last_contact_at,
            last_order_date: client.last_order_date,
            total_revenue: client.total_revenue || 0,
          };

          // Alerta: Inativo (90+ dias sem compra)
          if (daysSinceOrder !== null && daysSinceOrder > 90) {
            alerts.push({
              ...baseAlert,
              alert_type: 'inactive',
              priority: 1,
            });
          }
          // Alerta: Entrando em risco (46-60 dias)
          else if (daysSinceOrder !== null && daysSinceOrder >= 46 && daysSinceOrder <= 90) {
            alerts.push({
              ...baseAlert,
              alert_type: 'entering_risk',
              priority: 2,
            });
          }
          // Alerta: Sem contato há 15+ dias
          else if (daysSinceContact !== null && daysSinceContact >= 15) {
            alerts.push({
              ...baseAlert,
              alert_type: 'no_contact',
              priority: 3,
            });
          }
          // Alerta: Nunca teve contato registrado
          else if (daysSinceContact === null && daysSinceOrder !== null && daysSinceOrder > 30) {
            alerts.push({
              ...baseAlert,
              alert_type: 'no_contact',
              priority: 4,
            });
          }
        });

        // Ordenar por prioridade
        alerts.sort((a, b) => a.priority - b.priority);
        setClients(alerts);
      } catch (error) {
        console.error('Error:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchTop20Alerts();
  }, [sellerId]);

  // Agrupar por tipo de alerta
  const alertsByType = useMemo(() => {
    const grouped: Record<string, ClientAlert[]> = {
      inactive: [],
      entering_risk: [],
      no_contact: [],
      no_orders_period: [],
    };

    clients.forEach(client => {
      if (grouped[client.alert_type]) {
        grouped[client.alert_type].push(client);
      }
    });

    return grouped;
  }, [clients]);

  const totalAlerts = clients.length;

  const formatCurrency = (value: number) =>
    new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL', minimumFractionDigits: 0 }).format(value);

  if (loading) {
    return (
      <Card className="border-2 border-amber-500/30">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Crown className="h-5 w-5 text-amber-500" />
            Alertas Top 20
          </CardTitle>
        </CardHeader>
        <CardContent className="flex items-center justify-center py-8">
          <Loader2 className="h-6 w-6 animate-spin text-primary" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-2 border-amber-500/30">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-base">
            <Crown className="h-5 w-5 text-amber-500" />
            Alertas Top 20 — Clientes Estratégicos
          </CardTitle>
          {totalAlerts > 0 ? (
            <Badge variant="destructive" className="animate-pulse">
              {totalAlerts} alerta{totalAlerts !== 1 ? 's' : ''}
            </Badge>
          ) : (
            <Badge variant="outline" className="border-emerald-500 text-emerald-600">
              Tudo OK ✓
            </Badge>
          )}
        </div>
        <p className="text-sm text-muted-foreground">
          Pontos críticos nos seus clientes mais importantes que podem estar passando despercebidos
        </p>
      </CardHeader>
      <CardContent className="space-y-3">
        {Object.entries(alertsByType).map(([type, alertClients]) => {
          if (alertClients.length === 0) return null;
          
          const config = ALERT_CONFIG[type as keyof typeof ALERT_CONFIG];
          const IconComponent = config?.icon || AlertTriangle;
          const isExpanded = expandedType === type;

          return (
            <div key={type} className="space-y-2">
              <button
                onClick={() => setExpandedType(isExpanded ? null : type)}
                className={cn(
                  'w-full flex items-center justify-between p-3 rounded-lg border-l-4 border transition-all',
                  config?.color,
                  'hover:shadow-sm'
                )}
              >
                <div className="flex items-center gap-3">
                  <IconComponent className={cn('h-5 w-5', config?.iconColor)} />
                  <span className="font-medium text-sm">{config?.label}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Badge className={cn('text-white', config?.badge)}>
                    {alertClients.length}
                  </Badge>
                  <ChevronRight
                    className={cn(
                      'h-4 w-4 transition-transform text-muted-foreground',
                      isExpanded && 'rotate-90'
                    )}
                  />
                </div>
              </button>

              {isExpanded && (
                <ScrollArea className="h-[250px] rounded-lg border bg-card/50 p-2">
                  <div className="space-y-1">
                    {alertClients.map((client) => (
                      <Link
                        key={client.id}
                        to={`/clients/${client.id}`}
                        className="flex items-center justify-between p-3 rounded-md hover:bg-muted/50 transition-colors border border-transparent hover:border-border"
                      >
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-2">
                            <Crown className="h-3.5 w-3.5 text-amber-500 shrink-0" />
                            <p className="text-sm font-medium truncate">
                              {client.company_name}
                            </p>
                          </div>
                          <div className="flex items-center gap-2 mt-1 text-xs text-muted-foreground">
                            <span>{client.seller_name}</span>
                            <span>•</span>
                            <span className="font-medium text-foreground">
                              {formatCurrency(client.total_revenue)}
                            </span>
                          </div>
                        </div>
                        <div className="text-right shrink-0 ml-2">
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <div className="flex flex-col items-end gap-1">
                                  {client.days_since_order !== null && (
                                    <Badge variant="outline" className="text-xs">
                                      <Calendar className="h-3 w-3 mr-1" />
                                      {client.days_since_order}d s/ compra
                                    </Badge>
                                  )}
                                  {client.days_since_contact !== null && (
                                    <Badge variant="outline" className="text-xs">
                                      <Phone className="h-3 w-3 mr-1" />
                                      {client.days_since_contact}d s/ contato
                                    </Badge>
                                  )}
                                </div>
                              </TooltipTrigger>
                              <TooltipContent side="left">
                                <div className="space-y-1 text-xs">
                                  {client.last_order_date && (
                                    <p>Último pedido: {format(new Date(client.last_order_date), 'dd/MM/yyyy')}</p>
                                  )}
                                  {client.last_contact_at && (
                                    <p>Último contato: {format(new Date(client.last_contact_at), 'dd/MM/yyyy')}</p>
                                  )}
                                </div>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        </div>
                      </Link>
                    ))}
                  </div>
                </ScrollArea>
              )}
            </div>
          );
        })}

        {totalAlerts === 0 && (
          <div className="py-8 text-center">
            <div className="w-12 h-12 rounded-full bg-emerald-500/10 flex items-center justify-center mx-auto mb-3">
              <Crown className="h-6 w-6 text-emerald-500" />
            </div>
            <p className="text-sm font-medium text-emerald-600 dark:text-emerald-400">
              Todos os clientes Top 20 estão bem acompanhados!
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              Nenhum alerta de contato ou inatividade
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
