import { useState } from 'react';
import { Trophy, TrendingUp, AlertTriangle, XCircle, ChevronDown, ChevronUp, Settings2, AlertCircle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { cn } from '@/lib/utils';
import type { SellerROI } from '@/hooks/useGestorData';

interface SellerROITableProps {
  sellers: SellerROI[];
  onSelectSeller: (sellerId: string) => void;
  onEditCost?: (sellerId: string, sellerName: string, revenue: number) => void;
}

type SortField = 'revenue' | 'profit' | 'roiRevenue' | 'conversionRate' | 'contacts';
type SortDirection = 'asc' | 'desc';

function formatCurrency(value: number): string {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value);
}

function getViabilityBadge(status: 'viable' | 'attention' | 'inviable' | 'no-cost', hasCost: boolean) {
  if (!hasCost) {
    return (
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger>
            <Badge variant="outline" className="gap-1 bg-muted/50 text-muted-foreground border-muted">
              <AlertCircle className="h-3 w-3" />
              Sem custo
            </Badge>
          </TooltipTrigger>
          <TooltipContent>
            <p>Configure os custos para calcular ROI real</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    );
  }

  const config = {
    viable: { 
      label: 'Viável', 
      className: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
      icon: TrendingUp 
    },
    attention: { 
      label: 'Atenção', 
      className: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
      icon: AlertTriangle 
    },
    inviable: { 
      label: 'Inviável', 
      className: 'bg-destructive/20 text-destructive border-destructive/30',
      icon: XCircle 
    },
    'no-cost': {
      label: '—',
      className: 'bg-muted text-muted-foreground',
      icon: AlertCircle
    },
  };

  const { label, className, icon: Icon } = config[status];
  return (
    <Badge variant="outline" className={cn('gap-1', className)}>
      <Icon className="h-3 w-3" />
      {label}
    </Badge>
  );
}

export function SellerROITable({ sellers, onSelectSeller, onEditCost }: SellerROITableProps) {
  const [sortField, setSortField] = useState<SortField>('revenue');
  const [sortDirection, setSortDirection] = useState<SortDirection>('desc');

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('desc');
    }
  };

  const sortedSellers = [...sellers].sort((a, b) => {
    const aValue = a[sortField];
    const bValue = b[sortField];
    const multiplier = sortDirection === 'asc' ? 1 : -1;
    return (aValue - bValue) * multiplier;
  });

  const SortIcon = ({ field }: { field: SortField }) => {
    if (sortField !== field) return null;
    return sortDirection === 'asc' ? 
      <ChevronUp className="h-3 w-3 inline ml-1" /> : 
      <ChevronDown className="h-3 w-3 inline ml-1" />;
  };

  return (
    <Card className="border-primary/20">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-lg">
          <Trophy className="h-5 w-5 text-amber-500" />
          ROI por Vendedor
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="hover:bg-transparent">
                <TableHead className="w-8">#</TableHead>
                <TableHead>Vendedor</TableHead>
                <TableHead className="text-center">Contatos</TableHead>
                <TableHead className="text-center">Ligações</TableHead>
                <TableHead className="text-center">WhatsApp</TableHead>
                <TableHead className="text-center">Pedidos</TableHead>
                <TableHead 
                  className="text-right cursor-pointer hover:text-primary"
                  onClick={() => handleSort('revenue')}
                >
                  Receita <SortIcon field="revenue" />
                </TableHead>
                <TableHead 
                  className="text-right cursor-pointer hover:text-primary"
                  onClick={() => handleSort('profit')}
                >
                  Lucro <SortIcon field="profit" />
                </TableHead>
                <TableHead className="text-right">Ticket</TableHead>
                <TableHead 
                  className="text-center cursor-pointer hover:text-primary"
                  onClick={() => handleSort('conversionRate')}
                >
                  Conv. <SortIcon field="conversionRate" />
                </TableHead>
                <TableHead className="text-right">Custo</TableHead>
                <TableHead 
                  className="text-center cursor-pointer hover:text-primary"
                  onClick={() => handleSort('roiRevenue')}
                >
                  ROI <SortIcon field="roiRevenue" />
                </TableHead>
                <TableHead className="text-center">Status</TableHead>
                <TableHead className="text-center w-10"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sortedSellers.map((seller, index) => {
                const hasCost = seller.periodCost > 0;
                return (
                  <TableRow 
                    key={seller.id}
                    className="cursor-pointer hover:bg-muted/50"
                    onClick={() => onSelectSeller(seller.id)}
                  >
                    <TableCell className="font-medium text-muted-foreground">
                      {index + 1}
                    </TableCell>
                    <TableCell className="font-medium">
                      {seller.name}
                    </TableCell>
                    <TableCell className="text-center">{seller.contacts}</TableCell>
                    <TableCell className="text-center">{seller.calls}</TableCell>
                    <TableCell className="text-center">{seller.whatsapp}</TableCell>
                    <TableCell className="text-center font-medium">{seller.ordersCount}</TableCell>
                    <TableCell className="text-right font-semibold text-primary">
                      {formatCurrency(seller.revenue)}
                    </TableCell>
                    <TableCell className={cn(
                      'text-right font-medium',
                      seller.profit > 0 ? 'text-emerald-500' : 'text-destructive'
                    )}>
                      {formatCurrency(seller.profit)}
                    </TableCell>
                    <TableCell className="text-right">
                      {formatCurrency(seller.avgTicket)}
                    </TableCell>
                    <TableCell className="text-center">
                      {seller.conversionRate.toFixed(1)}%
                    </TableCell>
                    <TableCell className={cn(
                      'text-right',
                      hasCost ? 'text-muted-foreground' : 'text-amber-500'
                    )}>
                      {hasCost ? formatCurrency(seller.periodCost) : '—'}
                    </TableCell>
                    <TableCell className="text-center">
                      {hasCost ? (
                        <span className={cn(
                          'font-bold',
                          seller.roiRevenue >= 3 ? 'text-emerald-500' :
                          seller.roiRevenue >= 2 ? 'text-amber-500' : 'text-destructive'
                        )}>
                          {seller.roiRevenue.toFixed(1)}x
                        </span>
                      ) : (
                        <span className="text-muted-foreground">—</span>
                      )}
                    </TableCell>
                    <TableCell className="text-center">
                      {getViabilityBadge(seller.viabilityStatus, hasCost)}
                    </TableCell>
                    <TableCell className="text-center">
                      <Button
                        variant="ghost"
                        size="icon"
                        className={cn(
                          'h-7 w-7',
                          !hasCost && 'text-amber-500 hover:text-amber-600'
                        )}
                        onClick={(e) => {
                          e.stopPropagation();
                          onEditCost?.(seller.id, seller.name, seller.revenue);
                        }}
                      >
                        <Settings2 className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}
