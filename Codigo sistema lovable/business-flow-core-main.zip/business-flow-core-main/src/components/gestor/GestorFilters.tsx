import { Users } from 'lucide-react';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { PeriodFilter } from '@/components/ui/PeriodFilter';
import { UsePeriodFilterReturn } from '@/hooks/usePeriodFilter';
import type { GestorFilters as GestorFiltersType } from '@/hooks/useGestorData';

interface Seller {
  id: string;
  name: string;
}

interface GestorFiltersProps {
  filters: GestorFiltersType;
  onFiltersChange: (filters: GestorFiltersType) => void;
  sellers: Seller[];
  periodFilter: UsePeriodFilterReturn;
}

export function GestorFilters({ filters, onFiltersChange, sellers, periodFilter }: GestorFiltersProps) {
  const handleSellerChange = (value: string) => {
    onFiltersChange({ 
      ...filters, 
      sellerId: value === 'all' ? null : value 
    });
  };

  const selectedSeller = filters.sellerId 
    ? sellers.find(s => s.id === filters.sellerId)?.name 
    : null;

  return (
    <div className="flex flex-wrap items-center gap-2">
      {/* Period Filter */}
      <PeriodFilter filter={periodFilter} />

      {/* Divider */}
      <div className="h-6 w-px bg-border" />

      {/* Seller Select */}
      <div className="flex items-center gap-2">
        <Users className="h-4 w-4 text-muted-foreground" />
        <Select 
          value={filters.sellerId || 'all'} 
          onValueChange={handleSellerChange}
        >
          <SelectTrigger className="w-[180px] h-9 bg-muted/30 border-0">
            <SelectValue placeholder="Vendedor" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos os Vendedores</SelectItem>
            {sellers.map(seller => (
              <SelectItem key={seller.id} value={seller.id}>
                {seller.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Divider */}
      <div className="h-6 w-px bg-border" />

      {/* Include Pending Toggle */}
      <div className="flex items-center gap-2">
        <Switch 
          id="include-pending"
          checked={filters.includesPending}
          onCheckedChange={(checked) => 
            onFiltersChange({ ...filters, includesPending: checked })
          }
          className="scale-90"
        />
        <Label htmlFor="include-pending" className="text-xs cursor-pointer text-muted-foreground">
          Incluir pendentes
        </Label>
      </div>

      {/* Active Filters Summary */}
      {selectedSeller && (
        <Badge variant="secondary" className="ml-auto">
          <Users className="h-3 w-3 mr-1" />
          {selectedSeller}
        </Badge>
      )}
    </div>
  );
}
