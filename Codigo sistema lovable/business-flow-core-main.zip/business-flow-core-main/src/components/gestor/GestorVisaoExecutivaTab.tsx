import { motion } from 'framer-motion';
import { 
  TrendingUp, TrendingDown, DollarSign, Receipt, 
  Wallet, Target, ArrowUpRight, ArrowDownRight, Minus
} from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import type { GestorKPIs } from '@/hooks/useGestorData';

interface Props {
  kpis: GestorKPIs;
  ceeTotal: number;
}

function fmt(value: number): string {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value);
}

function pct(value: number): string {
  return `${value.toFixed(1)}%`;
}

interface KPICardProps {
  label: string;
  value: string;
  icon: React.ReactNode;
  trend?: 'up' | 'down' | 'neutral';
  trendLabel?: string;
  accent?: 'emerald' | 'rose' | 'amber' | 'primary' | 'violet';
  delay?: number;
}

function KPICard({ label, value, icon, trend, trendLabel, accent = 'primary', delay = 0 }: KPICardProps) {
  const accentStyles = {
    emerald: 'from-emerald-500/10 to-emerald-500/5 border-emerald-500/20',
    rose: 'from-rose-500/10 to-rose-500/5 border-rose-500/20',
    amber: 'from-amber-500/10 to-amber-500/5 border-amber-500/20',
    primary: 'from-primary/10 to-primary/5 border-primary/20',
    violet: 'from-violet-500/10 to-violet-500/5 border-violet-500/20',
  };

  const iconBgStyles = {
    emerald: 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400',
    rose: 'bg-rose-500/15 text-rose-600 dark:text-rose-400',
    amber: 'bg-amber-500/15 text-amber-600 dark:text-amber-400',
    primary: 'bg-primary/15 text-primary',
    violet: 'bg-violet-500/15 text-violet-600 dark:text-violet-400',
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.4, ease: 'easeOut' }}
    >
      <Card className={cn(
        'border bg-gradient-to-br transition-all duration-300 hover:shadow-md hover:-translate-y-0.5',
        accentStyles[accent]
      )}>
        <CardContent className="p-5">
          <div className="flex items-start justify-between mb-3">
            <div className={cn('p-2.5 rounded-xl', iconBgStyles[accent])}>
              {icon}
            </div>
            {trend && (
              <div className={cn(
                'flex items-center gap-1 text-xs font-medium px-2 py-1 rounded-full',
                trend === 'up' && 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400',
                trend === 'down' && 'bg-rose-500/10 text-rose-600 dark:text-rose-400',
                trend === 'neutral' && 'bg-muted text-muted-foreground'
              )}>
                {trend === 'up' && <ArrowUpRight className="w-3 h-3" />}
                {trend === 'down' && <ArrowDownRight className="w-3 h-3" />}
                {trend === 'neutral' && <Minus className="w-3 h-3" />}
                {trendLabel}
              </div>
            )}
          </div>
          <p className="text-sm text-muted-foreground mb-1">{label}</p>
          <p className="text-2xl font-bold tracking-tight text-foreground">{value}</p>
        </CardContent>
      </Card>
    </motion.div>
  );
}

export function GestorVisaoExecutivaTab({ kpis, ceeTotal }: Props) {
  const cmv = kpis.revenue - kpis.profit;
  const despesasTotal = kpis.totalCustoHumano + ceeTotal + kpis.totalImpostosVendas;
  const revenueGrowth = kpis.revenuePrev > 0
    ? ((kpis.revenue - kpis.revenuePrev) / kpis.revenuePrev) * 100
    : 0;
  const profitGrowth = kpis.profitPrev > 0
    ? ((kpis.profit - kpis.profitPrev) / kpis.profitPrev) * 100
    : 0;

  const revTrend: 'up' | 'down' | 'neutral' = revenueGrowth > 1 ? 'up' : revenueGrowth < -1 ? 'down' : 'neutral';
  const profTrend: 'up' | 'down' | 'neutral' = profitGrowth > 1 ? 'up' : profitGrowth < -1 ? 'down' : 'neutral';

  // Meta vs Real ratio
  const metaPercent = kpis.pontoEquilibrio > 0
    ? (kpis.revenue / kpis.pontoEquilibrio) * 100
    : 0;

  return (
    <div className="space-y-8">
      {/* Title */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="space-y-1"
      >
        <h2 className="text-xl font-semibold text-foreground">Visão Executiva</h2>
        <p className="text-sm text-muted-foreground">Resumo dos indicadores principais do período</p>
      </motion.div>

      {/* KPI Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
        <KPICard
          label="Receita do Mês"
          value={fmt(kpis.revenue)}
          icon={<DollarSign className="w-5 h-5" />}
          trend={revTrend}
          trendLabel={`${revenueGrowth > 0 ? '+' : ''}${pct(revenueGrowth)}`}
          accent="primary"
          delay={0}
        />
        <KPICard
          label="CMV (Custo da Mercadoria)"
          value={fmt(cmv)}
          icon={<Receipt className="w-5 h-5" />}
          accent="amber"
          delay={0.05}
        />
        <KPICard
          label="Despesas Totais"
          value={fmt(despesasTotal)}
          icon={<TrendingDown className="w-5 h-5" />}
          accent="rose"
          delay={0.1}
        />
        <KPICard
          label="Lucro Líquido (Resultado Real)"
          value={fmt(kpis.lucroRealTotal)}
          icon={<TrendingUp className="w-5 h-5" />}
          trend={kpis.lucroRealTotal >= 0 ? 'up' : 'down'}
          trendLabel={kpis.lucroRealTotal >= 0 ? 'Positivo' : 'Negativo'}
          accent={kpis.lucroRealTotal >= 0 ? 'emerald' : 'rose'}
          delay={0.15}
        />
        <KPICard
          label="Margem Bruta"
          value={pct(kpis.marginPercent)}
          icon={<Wallet className="w-5 h-5" />}
          accent="violet"
          delay={0.2}
        />
        <KPICard
          label="Meta vs Real"
          value={`${pct(metaPercent)} do Break-even`}
          icon={<Target className="w-5 h-5" />}
          trend={metaPercent >= 100 ? 'up' : 'down'}
          trendLabel={kpis.statusPontoEquilibrio === 'LUCRO' ? 'Acima' : kpis.statusPontoEquilibrio === 'EMPATE' ? 'Empate' : 'Abaixo'}
          accent={metaPercent >= 100 ? 'emerald' : 'amber'}
          delay={0.25}
        />
      </div>

      {/* Composition Summary */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
      >
        <Card className="border border-border/50 bg-card/50">
          <CardContent className="p-6">
            <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-4">
              Composição do Resultado
            </h3>
            <div className="space-y-3">
              {[
                { label: 'Receita Bruta', value: kpis.revenue, color: 'text-primary' },
                { label: '(-) CMV', value: -cmv, color: 'text-amber-600 dark:text-amber-400' },
                { label: '(=) Lucro Bruto', value: kpis.profit, color: 'text-emerald-600 dark:text-emerald-400', bold: true },
                { label: '(-) Impostos sobre Vendas', value: -kpis.totalImpostosVendas, color: 'text-rose-500' },
                { label: '(-) Custo Humano (CDV + Fixo)', value: -kpis.totalCustoHumano, color: 'text-rose-500' },
                { label: '(-) Custos Estruturais (CEE)', value: -ceeTotal, color: 'text-violet-600 dark:text-violet-400' },
                { label: '(=) Resultado Real', value: kpis.lucroRealTotal, color: kpis.lucroRealTotal >= 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-500', bold: true, border: true },
              ].map((item, i) => (
                <div
                  key={i}
                  className={cn(
                    'flex items-center justify-between py-2',
                    item.border && 'border-t border-border pt-3 mt-2'
                  )}
                >
                  <span className={cn('text-sm', item.bold ? 'font-semibold text-foreground' : 'text-muted-foreground')}>
                    {item.label}
                  </span>
                  <span className={cn('text-sm font-mono', item.bold ? 'font-bold text-base' : 'font-medium', item.color)}>
                    {fmt(item.value)}
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
