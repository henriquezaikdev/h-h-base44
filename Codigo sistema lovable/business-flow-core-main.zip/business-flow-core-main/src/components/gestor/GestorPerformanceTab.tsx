import { useMemo, useState } from 'react';
import {
  Target,
  TrendingUp,
  AlertTriangle,
  Trophy,
  Activity,
  Shield,
  Users,
  BarChart3,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { useExecutiveSummary } from '@/hooks/useGoalsData';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  Legend,
} from 'recharts';

export function GestorPerformanceTab() {
  const { summary, loading } = useExecutiveSummary();
  const [showTrend, setShowTrend] = useState(true);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Activity className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!summary) {
    return (
      <Card>
        <CardContent className="py-12 text-center">
          <Target className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
          <p className="text-muted-foreground">Sem dados de performance disponíveis.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* 1) VISÃO GERAL DA SEMANA */}
      <section>
        <div className="flex items-center gap-2 mb-4">
          <Activity className="h-5 w-5 text-primary" />
          <h2 className="text-lg font-semibold">Visão Geral da Semana</h2>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card className="border-primary/30">
            <CardContent className="pt-4">
              <p className="text-xs text-muted-foreground uppercase tracking-wide">Score Médio</p>
              <p className={cn(
                'text-3xl font-bold',
                summary.avgScore >= 70 ? 'text-emerald-600 dark:text-emerald-400'
                  : summary.avgScore >= 50 ? 'text-amber-600 dark:text-amber-400'
                  : 'text-destructive'
              )}>
                {summary.avgScore}
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-4">
              <p className="text-xs text-muted-foreground uppercase tracking-wide">% No Prazo</p>
              <p className="text-3xl font-bold">{summary.pctOnTime}%</p>
              <Progress value={summary.pctOnTime} className="mt-2 h-1.5" />
            </CardContent>
          </Card>

          <Card className={cn(
            summary.totalCriticalOverdue > 0 && 'border-destructive/50 bg-destructive/5'
          )}>
            <CardContent className="pt-4">
              <p className="text-xs text-muted-foreground uppercase tracking-wide">Críticas Vencidas</p>
              <p className={cn(
                'text-3xl font-bold',
                summary.totalCriticalOverdue > 0 ? 'text-destructive' : 'text-emerald-600 dark:text-emerald-400'
              )}>
                {summary.totalCriticalOverdue}
              </p>
            </CardContent>
          </Card>

          <Card className={cn(
            summary.totalOperationalErrors > 0 && 'border-amber-500/50 bg-amber-500/5'
          )}>
            <CardContent className="pt-4">
              <p className="text-xs text-muted-foreground uppercase tracking-wide">Erros Operacionais</p>
              <p className={cn(
                'text-3xl font-bold',
                summary.totalOperationalErrors > 0 ? 'text-amber-600 dark:text-amber-400' : 'text-emerald-600 dark:text-emerald-400'
              )}>
                {summary.totalOperationalErrors}
              </p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* 2) TOP PERFORMERS */}
      <section>
        <div className="flex items-center gap-2 mb-4">
          <Trophy className="h-5 w-5 text-amber-500" />
          <h2 className="text-lg font-semibold">Top Performers</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Top Score */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2">
                <Target className="h-4 w-4 text-primary" />
                Score
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {summary.topByScore.map((s, i) => (
                <div key={i} className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className={cn(
                      'text-xs font-bold w-5 h-5 rounded-full flex items-center justify-center',
                      i === 0 ? 'bg-amber-500 text-white' : 'bg-muted text-muted-foreground'
                    )}>
                      {i + 1}
                    </span>
                    <span className="text-sm font-medium">{s.name.split(' ')[0]}</span>
                  </div>
                  <Badge variant="outline">{s.score}</Badge>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Top Consistency */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-emerald-500" />
                Pontualidade
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {summary.topByConsistency.map((s, i) => (
                <div key={i} className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className={cn(
                      'text-xs font-bold w-5 h-5 rounded-full flex items-center justify-center',
                      i === 0 ? 'bg-emerald-500 text-white' : 'bg-muted text-muted-foreground'
                    )}>
                      {i + 1}
                    </span>
                    <span className="text-sm font-medium">{s.name.split(' ')[0]}</span>
                  </div>
                  <Badge variant="outline">{s.value}%</Badge>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Top Quality */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2">
                <Shield className="h-4 w-4 text-blue-500" />
                Qualidade
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {summary.topByQuality.map((s, i) => (
                <div key={i} className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className={cn(
                      'text-xs font-bold w-5 h-5 rounded-full flex items-center justify-center',
                      i === 0 ? 'bg-blue-500 text-white' : 'bg-muted text-muted-foreground'
                    )}>
                      {i + 1}
                    </span>
                    <span className="text-sm font-medium">{s.name.split(' ')[0]}</span>
                  </div>
                  <Badge variant="outline">{s.value}</Badge>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </section>

      {/* 3) ALERTAS DE GESTÃO */}
      {summary.managementAlerts.length > 0 && (
        <section>
          <div className="flex items-center gap-2 mb-3">
            <AlertTriangle className="h-5 w-5 text-amber-500" />
            <h2 className="text-lg font-semibold">Alertas de Gestão</h2>
          </div>
          <div className="space-y-2">
            {summary.managementAlerts.map((alert, idx) => (
              <Card
                key={idx}
                className={cn(
                  'border-l-4',
                  alert.type === 'danger' && 'border-l-destructive bg-destructive/5',
                  alert.type === 'warning' && 'border-l-amber-500 bg-amber-500/5',
                  alert.type === 'info' && 'border-l-blue-500 bg-blue-500/5'
                )}
              >
                <CardContent className="py-3 flex items-center gap-3">
                  <AlertTriangle className={cn(
                    'h-4 w-4 shrink-0',
                    alert.type === 'danger' && 'text-destructive',
                    alert.type === 'warning' && 'text-amber-500',
                    alert.type === 'info' && 'text-blue-500'
                  )} />
                  <span className="text-sm">{alert.message}</span>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>
      )}

      {/* 4) EVOLUÇÃO SEMANAL */}
      <section>
        <Button
          variant="ghost"
          className="flex items-center gap-2 mb-3 p-0 h-auto"
          onClick={() => setShowTrend(!showTrend)}
        >
          <BarChart3 className="h-5 w-5 text-primary" />
          <h2 className="text-lg font-semibold">Evolução Semanal (8 semanas)</h2>
          {showTrend ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
        </Button>

        {showTrend && summary.weeklyTrend.length > 0 && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Score trend */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">Score Médio & % No Prazo</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={220}>
                  <LineChart data={summary.weeklyTrend}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                    <XAxis dataKey="week" className="text-xs" />
                    <YAxis domain={[0, 100]} className="text-xs" />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="avgScore" name="Score" stroke="hsl(var(--primary))" strokeWidth={2} dot={{ r: 3 }} />
                    <Line type="monotone" dataKey="pctOnTime" name="% Prazo" stroke="hsl(142, 76%, 36%)" strokeWidth={2} dot={{ r: 3 }} />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Errors trend */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">Erros Operacionais por Semana</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={220}>
                  <BarChart data={summary.weeklyTrend}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                    <XAxis dataKey="week" className="text-xs" />
                    <YAxis className="text-xs" />
                    <Tooltip />
                    <Bar dataKey="errors" name="Erros" fill="hsl(var(--destructive))" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        )}
      </section>
    </div>
  );
}
