import { useState, useCallback } from 'react';
import { 
  TrendingUp, 
  Building2,
  Users,
  Eye,
  ChevronRight
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { cn } from '@/lib/utils';
import { GestorHistoryChart } from './GestorHistoryChart';
import { CostWaterfallChart } from './CostWaterfallChart';
import { ComissoesTable } from '@/components/shared/ComissoesTable';
import { BreakEvenCard } from './BreakEvenCard';
import { Phase2CompanyCosts } from './Phase2CompanyCosts';
import { Phase1CostPanel } from './Phase1CostPanel';
import { SellerResultCard } from './SellerResultCard';
import { GestorKPICards } from './GestorKPICards';
import { GestorConfigMensal } from '@/hooks/useGestorConfig';
import { SellerResult, GestorKPIs } from '@/hooks/useGestorData';
import { useAuth } from '@/hooks/useAuth';
import { SimuladorContratacao } from './SimuladorContratacao';

interface GestorFinanceiroTabProps {
  kpis: GestorKPIs;
  sellersResult: SellerResult[];
  activeSellersCount: number;
  gestorConfig: GestorConfigMensal | null;
  selectedSellerId: string | null;
  onSelectSeller: (sellerId: string) => void;
}

export function GestorFinanceiroTab({
  kpis,
  sellersResult,
  activeSellersCount,
  gestorConfig,
  selectedSellerId,
  onSelectSeller,
}: GestorFinanceiroTabProps) {
  const { isOwner } = useAuth();
  const [companyCostsOpen, setCompanyCostsOpen] = useState(false);
  const [costSheetOpen, setCostSheetOpen] = useState(false);
  const [selectedSeller, setSelectedSeller] = useState<{
    id: string;
    name: string;
    revenue: number;
    marginBruta: number;
    comissaoReal: number;
    comissaoPercentual: number;
  } | null>(null);
  const [detailsExpanded, setDetailsExpanded] = useState(false);

  const handleEditCost = (seller: { id: string; name: string; revenue: number; marginBruta: number; comissaoReal: number; comissaoPercentual: number }) => {
    setSelectedSeller(seller);
    setCostSheetOpen(true);
  };

  const handleCostCalculated = useCallback(() => {
    // Update will happen automatically via refreshData
  }, []);

  const handleCompanyCostCalculated = useCallback(() => {
    // Update will happen automatically via refreshData
  }, []);

  return (
    <div className="space-y-6">
      {/* PONTO DE EQUILÍBRIO */}
      <BreakEvenCard
        receita={kpis.revenue}
        lucroBruto={kpis.profit || 0}
        ceeLimpo={gestorConfig?.despesas_fixas_base || 24026.49}
        prolaboreTotal={gestorConfig?.prolabore_total || 14956.45}
        emprestimosTotal={gestorConfig?.emprestimos_total || 7000.00}
        impostosVendas={kpis.totalImpostosVendas || 0}
        custoHumanoTotal={kpis.totalCustoHumano || 0}
        cdvTotal={kpis.totalCDV || 0}
      />

      {/* GRÁFICO HISTÓRICO */}
      <section>
        <div className="flex items-center gap-2 mb-4">
          <TrendingUp className="h-5 w-5 text-primary" />
          <h2 className="text-lg font-semibold">Histórico de Margem</h2>
        </div>
        <GestorHistoryChart />
      </section>

      {/* COMISSÕES A PAGAR */}
      <ComissoesTable
        items={sellersResult.map(s => ({
          name: s.name,
          revenue: s.revenue,
          marginBruta: s.marginBruta,
          comissaoReal: s.comissaoReal,
          comissaoPercentual: s.comissaoPercentual,
        }))}
      />

      {/* WATERFALL - COMPOSIÇÃO DO RESULTADO */}
      <CostWaterfallChart
        lucroBruto={kpis.profit || 0}
        cdvTotal={kpis.totalCDV || 0}
        custoHumano={kpis.totalCustoHumano || 0}
        ceeTotal={(kpis.totalCEE || 0) + (kpis.totalFase3 || 0)}
        resultadoReal={kpis.lucroRealTotal || 0}
      />

      {/* BOTÃO PARA CONFIGURAR CEE */}
      <div className="flex justify-center">
        <Button 
          variant="outline" 
          onClick={() => setCompanyCostsOpen(true)}
          className="gap-2"
        >
          <Building2 className="h-4 w-4" />
          Configurar CEE (Custo Estrutural da Empresa)
        </Button>
      </div>

      {/* DRILL-DOWN - Análises Detalhadas */}
      <section>
        <Collapsible open={detailsExpanded} onOpenChange={setDetailsExpanded}>
          <CollapsibleTrigger asChild>
            <Button variant="outline" className="w-full gap-2">
              <Eye className="h-4 w-4" />
              {detailsExpanded ? 'Ocultar' : 'Ver'} Análises Detalhadas
              <ChevronRight className={cn(
                'h-4 w-4 transition-transform',
                detailsExpanded && 'rotate-90'
              )} />
            </Button>
          </CollapsibleTrigger>
          <CollapsibleContent className="mt-4 space-y-6">
            {/* KPIs Executivos Detalhados */}
            <div>
              <div className="flex items-center gap-2 mb-4">
                <TrendingUp className="h-5 w-5 text-primary" />
                <h3 className="text-md font-semibold">KPIs Executivos Detalhados</h3>
              </div>
              <GestorKPICards kpis={kpis} />
            </div>

            {/* Cards de Vendedores com Configuração */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <Users className="h-5 w-5 text-primary" />
                  <h3 className="text-md font-semibold">Cards de Vendedores (Configurar Custos)</h3>
                </div>
                <span className="text-xs text-muted-foreground">
                  Clique em ⚙️ para configurar custos
                </span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                {sellersResult.map((seller, index) => (
                  <SellerResultCard
                    key={seller.id}
                    seller={seller}
                    rank={index + 1}
                    isSelected={selectedSellerId === seller.id}
                    onSelect={() => onSelectSeller(seller.id)}
                    onEditCost={() => handleEditCost({
                      id: seller.id,
                      name: seller.name,
                      revenue: seller.revenue,
                      marginBruta: seller.marginBruta,
                      comissaoReal: seller.comissaoReal,
                      comissaoPercentual: seller.comissaoPercentual,
                    })}
                  />
                ))}
              </div>
            </div>
          </CollapsibleContent>
        </Collapsible>
      </section>

      {/* Sheet para Custo do Vendedor (Fase 1) */}
      <Sheet open={costSheetOpen} onOpenChange={setCostSheetOpen}>
        <SheetContent className="w-full sm:max-w-xl overflow-y-auto">
          <SheetHeader>
            <SheetTitle className="flex items-center gap-2">
              <Users className="h-5 w-5 text-primary" />
              FASE 1 — Custo Direto do Vendedor
            </SheetTitle>
            <p className="text-sm text-muted-foreground">
              {selectedSeller?.name}
            </p>
          </SheetHeader>
          
          {selectedSeller && (
            <div className="mt-6">
              <Phase1CostPanel
                sellerId={selectedSeller.id}
                sellerName={selectedSeller.name}
                sellerRevenue={selectedSeller.revenue}
                marginBruta={selectedSeller.marginBruta}
                comissaoReal={selectedSeller.comissaoReal || 0}
                comissaoPercentual={selectedSeller.comissaoPercentual || 0}
                onCostCalculated={handleCostCalculated}
              />
            </div>
          )}
        </SheetContent>
      </Sheet>

      {/* SIMULADOR DE CONTRATAÇÃO - Owner only */}
      {isOwner && (
        <SimuladorContratacao
          kpis={kpis}
          sellersResult={sellersResult}
          activeSellersCount={activeSellersCount}
        />
      )}

      {/* Sheet para Custos da Empresa (Fase 2) */}
      <Sheet open={companyCostsOpen} onOpenChange={setCompanyCostsOpen}>
        <SheetContent className="w-full sm:max-w-xl overflow-y-auto">
          <SheetHeader>
            <SheetTitle className="flex items-center gap-2">
              <Building2 className="h-5 w-5 text-primary" />
              FASE 2 — Custo Estrutural da Empresa (CEE)
            </SheetTitle>
            <p className="text-sm text-muted-foreground">
              Rateado entre {activeSellersCount} vendedores ativos
            </p>
          </SheetHeader>
          
          <div className="mt-6">
            <Phase2CompanyCosts
              activeSellersCount={activeSellersCount}
              onCostCalculated={handleCompanyCostCalculated}
            />
          </div>
        </SheetContent>
      </Sheet>
    </div>
  );
}
