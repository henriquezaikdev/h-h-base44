import { CheckCircle, AlertTriangle, FileText, Calendar } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Progress } from '@/components/ui/progress';
import { cn } from '@/lib/utils';
import type { UsageQuality } from '@/hooks/useGestorData';

interface UsageQualityPanelProps {
  data: UsageQuality[];
}

export function UsageQualityPanel({ data }: UsageQualityPanelProps) {
  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-lg">
          <CheckCircle className="h-5 w-5 text-emerald-500" />
          Qualidade de Uso do Sistema
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="hover:bg-transparent">
                <TableHead>Vendedor</TableHead>
                <TableHead className="text-center">Tarefas no Prazo</TableHead>
                <TableHead className="text-center">
                  <span className="flex items-center justify-center gap-1">
                    <AlertTriangle className="h-3 w-3 text-amber-500" />
                    Retornos Vencidos
                  </span>
                </TableHead>
                <TableHead className="text-center">
                  <span className="flex items-center justify-center gap-1">
                    <FileText className="h-3 w-3" />
                    Média Obs. (chars)
                  </span>
                </TableHead>
                <TableHead className="text-center">Tarefas s/ Obs</TableHead>
                <TableHead className="text-center">
                  <span className="flex items-center justify-center gap-1">
                    <Calendar className="h-3 w-3" />
                    Dias s/ Interação
                  </span>
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {data.map((seller) => (
                <TableRow key={seller.sellerId}>
                  <TableCell className="font-medium">{seller.sellerName}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Progress 
                        value={seller.tasksOnTimePercent} 
                        className={cn(
                          'h-2 w-20',
                          seller.tasksOnTimePercent >= 80 ? '[&>div]:bg-emerald-500' :
                          seller.tasksOnTimePercent >= 50 ? '[&>div]:bg-amber-500' : '[&>div]:bg-destructive'
                        )}
                      />
                      <span className={cn(
                        'text-sm font-medium',
                        seller.tasksOnTimePercent >= 80 ? 'text-emerald-500' :
                        seller.tasksOnTimePercent >= 50 ? 'text-amber-500' : 'text-destructive'
                      )}>
                        {seller.tasksOnTimePercent.toFixed(0)}%
                      </span>
                    </div>
                  </TableCell>
                  <TableCell className="text-center">
                    <span className={cn(
                      'font-medium',
                      seller.overdueReturns === 0 ? 'text-emerald-500' :
                      seller.overdueReturns <= 3 ? 'text-amber-500' : 'text-destructive'
                    )}>
                      {seller.overdueReturns}
                    </span>
                  </TableCell>
                  <TableCell className="text-center">
                    <span className={cn(
                      'font-medium',
                      seller.avgObservationLength >= 50 ? 'text-emerald-500' :
                      seller.avgObservationLength >= 20 ? 'text-amber-500' : 'text-muted-foreground'
                    )}>
                      {seller.avgObservationLength.toFixed(0)}
                    </span>
                  </TableCell>
                  <TableCell className="text-center">
                    <span className={cn(
                      'font-medium',
                      seller.tasksWithoutObservation === 0 ? 'text-emerald-500' :
                      seller.tasksWithoutObservation <= 5 ? 'text-amber-500' : 'text-destructive'
                    )}>
                      {seller.tasksWithoutObservation}
                    </span>
                  </TableCell>
                  <TableCell className="text-center">
                    <span className={cn(
                      'font-medium',
                      seller.daysWithoutInteraction === 0 ? 'text-emerald-500' :
                      seller.daysWithoutInteraction <= 2 ? 'text-amber-500' : 'text-destructive'
                    )}>
                      {seller.daysWithoutInteraction}
                    </span>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}
