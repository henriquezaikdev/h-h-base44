import { 
  DollarSign, 
  ShoppingCart, 
  TrendingUp, 
  TrendingDown,
  Phone, 
  MessageCircle, 
  Users, 
  AlertTriangle,
  Clock,
  Percent
} from 'lucide-react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';
import type { GestorKPIs } from '@/hooks/useGestorData';

interface GestorKPICardsProps {
  kpis: GestorKPIs;
}

function formatCurrency(value: number): string {
  if (value >= 1000000) {
    return `R$ ${(value / 1000000).toFixed(1)}M`;
  }
  if (value >= 1000) {
    return `R$ ${(value / 1000).toFixed(0)}K`;
  }
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value);
}

function formatNumber(value: number): string {
  return new Intl.NumberFormat('pt-BR').format(value);
}

function calculateVariation(current: number, prev: number): { value: number; isPositive: boolean } {
  if (prev === 0) return { value: 0, isPositive: true };
  const variation = ((current - prev) / prev) * 100;
  return { value: Math.abs(variation), isPositive: variation >= 0 };
}

interface KPICardProps {
  title: string;
  value: string;
  icon: React.ElementType;
  variation?: { value: number; isPositive: boolean };
  variant?: 'default' | 'success' | 'warning' | 'danger';
  size?: 'normal' | 'large';
  delay?: number;
}

function KPICard({ title, value, icon: Icon, variation, variant = 'default', size = 'normal', delay = 0 }: KPICardProps) {
  const bgColors = {
    default: 'bg-card hover:border-primary/40',
    success: 'bg-emerald-500/5 border-emerald-500/20 hover:border-emerald-500/40',
    warning: 'bg-amber-500/5 border-amber-500/20 hover:border-amber-500/40',
    danger: 'bg-destructive/5 border-destructive/20 hover:border-destructive/40',
  };

  const iconColors = {
    default: 'text-primary bg-primary/10',
    success: 'text-emerald-500 bg-emerald-500/10',
    warning: 'text-amber-500 bg-amber-500/10',
    danger: 'text-destructive bg-destructive/10',
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.3, ease: "easeOut" }}
      whileHover={{ y: -2, transition: { duration: 0.2 } }}
      className={cn(
        'rounded-xl border p-4 transition-all duration-200 cursor-default',
        bgColors[variant],
        size === 'large' && 'p-6'
      )}
    >
      <div className="flex items-start justify-between">
        <div className="space-y-2">
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
            {title}
          </p>
          <p className={cn(
            'font-bold tracking-tight',
            size === 'large' ? 'text-3xl' : 'text-2xl'
          )}>
            {value}
          </p>
          {variation && variation.value > 0 && (
            <div className={cn(
              'flex items-center gap-1 text-xs font-medium',
              variation.isPositive ? 'text-emerald-500' : 'text-destructive'
            )}>
              {variation.isPositive ? (
                <TrendingUp className="h-3 w-3" />
              ) : (
                <TrendingDown className="h-3 w-3" />
              )}
              <span>{variation.value.toFixed(1)}% vs anterior</span>
            </div>
          )}
        </div>
        <div className={cn(
          'p-3 rounded-xl',
          iconColors[variant]
        )}>
          <Icon className={cn('h-5 w-5', size === 'large' && 'h-6 w-6')} />
        </div>
      </div>
    </motion.div>
  );
}

export function GestorKPICards({ kpis }: GestorKPICardsProps) {
  const revenueVar = calculateVariation(kpis.revenue, kpis.revenuePrev);
  const ordersVar = calculateVariation(kpis.ordersCount, kpis.ordersCountPrev);
  const ticketVar = calculateVariation(kpis.avgTicket, kpis.avgTicketPrev);
  const profitVar = calculateVariation(kpis.profit, kpis.profitPrev);

  return (
    <div className="space-y-4">
      {/* Row 1: Main Financial KPIs - Larger */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <KPICard
          title="Receita Total"
          value={formatCurrency(kpis.revenue)}
          icon={DollarSign}
          variation={revenueVar}
          variant="default"
          size="large"
          delay={0}
        />
        <KPICard
          title="Lucro Bruto"
          value={formatCurrency(kpis.profit)}
          icon={TrendingUp}
          variation={profitVar}
          variant={kpis.profit > 0 ? 'success' : 'danger'}
          size="large"
          delay={0.05}
        />
        <KPICard
          title="Nº Pedidos"
          value={formatNumber(kpis.ordersCount)}
          icon={ShoppingCart}
          variation={ordersVar}
          size="large"
          delay={0.1}
        />
        <KPICard
          title="Ticket Médio"
          value={formatCurrency(kpis.avgTicket)}
          icon={DollarSign}
          variation={ticketVar}
          size="large"
          delay={0.15}
        />
      </div>

      {/* Row 2: Activity & Alerts - Smaller */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        <KPICard
          title="Margem %"
          value={`${kpis.marginPercent.toFixed(1)}%`}
          icon={Percent}
          variant={kpis.marginPercent >= 20 ? 'success' : kpis.marginPercent >= 10 ? 'warning' : 'danger'}
          delay={0.2}
        />
        <KPICard
          title="Contatos Totais"
          value={formatNumber(kpis.totalContacts)}
          icon={Users}
          delay={0.25}
        />
        <KPICard
          title="Ligações"
          value={formatNumber(kpis.totalCalls)}
          icon={Phone}
          delay={0.3}
        />
        <KPICard
          title="Sem Contato 15d+"
          value={formatNumber(kpis.clientsNoContact15Days)}
          icon={AlertTriangle}
          variant={kpis.clientsNoContact15Days > 10 ? 'warning' : 'default'}
          delay={0.35}
        />
        <KPICard
          title="Recorrentes s/ Pedido 45d+"
          value={formatNumber(kpis.recurrentNoOrder45Days)}
          icon={Clock}
          variant={kpis.recurrentNoOrder45Days > 5 ? 'danger' : 'default'}
          delay={0.4}
        />
      </div>
    </div>
  );
}
