import { useState, useMemo } from 'react';
import { Calculator, ChevronRight, User, Building2, Target, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Separator } from '@/components/ui/separator';
import { cn, formatCurrency } from '@/lib/utils';
import { GestorKPIs, SellerResult } from '@/hooks/useGestorData';
import { SimuladorIASuggestion } from './SimuladorIASuggestion';

interface SimuladorContratacaoProps {
  kpis: GestorKPIs;
  sellersResult: SellerResult[];
  activeSellersCount: number;
}

export function SimuladorContratacao({ kpis, sellersResult, activeSellersCount }: SimuladorContratacaoProps) {
  const [open, setOpen] = useState(false);

  // Form state
  const [nome, setNome] = useState('');
  const [salario, setSalario] = useState(0);
  const [encargosPercent, setEncargosPercent] = useState(35);
  const [provisaoPercent, setProvisaoPercent] = useState(22);
  const [beneficios, setBeneficios] = useState(0);
  const [ferramentas, setFerramentas] = useState(0);
  const [deslocamento, setDeslocamento] = useState(0);
  const [margemMedia, setMargemMedia] = useState(32);
  const [comissaoMedia, setComissaoMedia] = useState(2);

  // Check if required fields are filled
  const hasRequiredFields = salario > 0;

  // Calculations
  const calc = useMemo(() => {
    const encargosValor = salario * (encargosPercent / 100);
    const provisaoValor = salario * (provisaoPercent / 100);
    const custoTrabalhista = salario + encargosValor + provisaoValor;
    const custoTotalVendedor = custoTrabalhista + beneficios + ferramentas + deslocamento;

    const ceeTotal = kpis.totalCEE || 0;
    const vendedoresNoCalculo = activeSellersCount + 1; // +1 = novo vendedor
    const ceeRateioEstimado = vendedoresNoCalculo > 0 ? ceeTotal / vendedoresNoCalculo : 0;

    // Margem líquida operacional = margem% - comissão%
    const margemLiquidaOperacional = (margemMedia - comissaoMedia) / 100;

    // Pontos de equilíbrio
    const pontoEquilibrioDireto = margemLiquidaOperacional > 0
      ? custoTotalVendedor / margemLiquidaOperacional
      : 0;

    const pontoEquilibrioCompleto = margemLiquidaOperacional > 0
      ? (custoTotalVendedor + ceeRateioEstimado) / margemLiquidaOperacional
      : 0;

    // Status: só "Venda Inviável" quando margem líquida <= 0 E campos preenchidos
    const isInviavel = margemLiquidaOperacional <= 0 && hasRequiredFields;

    return {
      encargosValor,
      provisaoValor,
      custoTrabalhista,
      custoTotalVendedor,
      ceeTotal,
      vendedoresNoCalculo,
      ceeRateioEstimado,
      margemLiquidaOperacional,
      pontoEquilibrioDireto,
      pontoEquilibrioCompleto,
      isInviavel,
    };
  }, [salario, encargosPercent, provisaoPercent, beneficios, ferramentas, deslocamento, margemMedia, comissaoMedia, kpis.totalCEE, activeSellersCount, hasRequiredFields]);

  // Context for AI
  const aiContext = useMemo(() => {
    const avgSellerRevenue = activeSellersCount > 0 ? kpis.revenue / activeSellersCount : 0;
    const avgSellerCost = activeSellersCount > 0 ? kpis.totalCustoHumano / activeSellersCount : 0;
    return {
      totalRevenue: kpis.revenue,
      avgMarginPercent: kpis.revenue > 0 ? (kpis.profit / kpis.revenue) * 100 : 0,
      ceeTotal: kpis.totalCEE || 0,
      activeSellers: activeSellersCount,
      avgSellerCost,
      avgSellerRevenue,
      metaVendas: calc.pontoEquilibrioCompleto,
    };
  }, [kpis, activeSellersCount, calc.pontoEquilibrioCompleto]);

  const fmt = (v: number) => formatCurrency(v);
  const dash = '—';

  return (
    <section>
      <Collapsible open={open} onOpenChange={setOpen}>
        <CollapsibleTrigger asChild>
          <Button variant="outline" className="w-full gap-2">
            <Calculator className="h-4 w-4" />
            🧮 {open ? 'Ocultar' : 'Ver'} Simulador de Contratação
            <ChevronRight className={cn('h-4 w-4 transition-transform', open && 'rotate-90')} />
          </Button>
        </CollapsibleTrigger>
        <CollapsibleContent className="mt-4 space-y-6">
          <TooltipProvider>

            {/* Badge de status — só aparece quando inviável */}
            {calc.isInviavel && (
              <div className="flex justify-end">
                <Badge className="bg-destructive text-destructive-foreground">Venda Inviável</Badge>
              </div>
            )}

            {/* ════════════════════════════════════════════ */}
            {/* BLOCO A — CUSTO DO VENDEDOR */}
            {/* ════════════════════════════════════════════ */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-base">
                  <User className="h-5 w-5 text-primary" />
                  Custo do Vendedor
                </CardTitle>
                <p className="text-xs text-muted-foreground">Quanto custa mensalmente contratar este vendedor</p>
              </CardHeader>
              <CardContent className="space-y-5">
                {/* Inputs */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  <InputField label="Nome do candidato" hint="Opcional — para referência" value={nome} onChange={setNome} type="text" />
                  <InputField label="Salário bruto (R$)" hint="Valor contratado do vendedor" value={salario} onChange={setSalario} />
                  <InputField label="Encargos da empresa (%)" hint="Contribuição da empresa sobre a folha" value={encargosPercent} onChange={setEncargosPercent} />
                  <InputField label="Provisão férias/13º (%)" hint="Reserva para férias e 13º salário" value={provisaoPercent} onChange={setProvisaoPercent} />
                  <InputField label="Benefícios mensais (R$)" hint="VT, VR, VA, plano de saúde, etc." value={beneficios} onChange={setBeneficios} />
                  <InputField label="Ferramentas mensais (R$)" hint="CRM, telefonia, software, etc." value={ferramentas} onChange={setFerramentas} />
                  <InputField label="Deslocamento mensal (R$)" hint="Combustível, reembolso de viagens" value={deslocamento} onChange={setDeslocamento} />
                </div>

                <Separator />

                {/* Outputs calculados */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <ResultItem
                    label="Encargos (R$)"
                    value={hasRequiredFields ? fmt(calc.encargosValor) : dash}
                    hint="Contribuição da empresa sobre a folha"
                  />
                  <ResultItem
                    label="Provisão (R$)"
                    value={hasRequiredFields ? fmt(calc.provisaoValor) : dash}
                    hint="Reserva para férias e 13º salário"
                  />
                  <ResultItem
                    label="Custo trabalhista"
                    value={hasRequiredFields ? fmt(calc.custoTrabalhista) : dash}
                    hint="Custo contratual total com a CLT"
                    highlight
                  />
                  <ResultItem
                    label="Custo total do vendedor"
                    value={hasRequiredFields ? fmt(calc.custoTotalVendedor) : dash}
                    hint="Custo mensal completo da contratação"
                    highlight
                    primary
                  />
                </div>
              </CardContent>
            </Card>

            {/* ════════════════════════════════════════════ */}
            {/* BLOCO B — RATEIO ESTRUTURAL */}
            {/* ════════════════════════════════════════════ */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-base">
                  <Building2 className="h-5 w-5 text-primary" />
                  Rateio Estrutural
                </CardTitle>
                <p className="text-xs text-muted-foreground">
                  Parcela do custo fixo da empresa atribuída a este vendedor
                </p>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <ResultItem
                    label="CEE total da empresa"
                    value={fmt(calc.ceeTotal)}
                    hint="Custo estrutural fixo total da empresa"
                  />
                  <ResultItem
                    label="Vendedores no cálculo"
                    value={String(calc.vendedoresNoCalculo)}
                    hint="Baseado em perfis com is_sales_active = true"
                  />
                  <ResultItem
                    label="Rateio por vendedor"
                    value={fmt(calc.ceeRateioEstimado)}
                    hint="Custo estrutural rateado para análise gerencial"
                    highlight
                    primary
                  />
                </div>

                <div className="p-3 rounded-lg bg-muted/50 border border-border/50">
                  <p className="text-xs text-muted-foreground italic">
                    💡 O rateio estrutural não é salário. É o peso do custo fixo da empresa proporcional a cada vendedor.
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* ════════════════════════════════════════════ */}
            {/* BLOCO C — PONTO DE EQUILÍBRIO */}
            {/* ════════════════════════════════════════════ */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-base">
                  <Target className="h-5 w-5 text-primary" />
                  Ponto de Equilíbrio do Vendedor
                </CardTitle>
                <p className="text-xs text-muted-foreground">Quanto ele precisa vender para cobrir seu custo</p>
              </CardHeader>
              <CardContent className="space-y-5">
                {/* Inputs de margem e comissão */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <InputField
                    label="Margem média esperada (%)"
                    hint="Percentual de lucro bruto sobre vendas"
                    value={margemMedia}
                    onChange={setMargemMedia}
                    max={100}
                  />
                  <InputField
                    label="Comissão média (%)"
                    hint="Percentual de comissão sobre vendas"
                    value={comissaoMedia}
                    onChange={setComissaoMedia}
                    max={100}
                  />
                </div>

                <Separator />

                {/* 1. Custo Direto */}
                <div>
                  <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-3">
                    1. Custo Direto do Vendedor
                  </p>
                  <ResultItem
                    label="Venda mínima para pagar salário e custo direto"
                    value={hasRequiredFields && calc.margemLiquidaOperacional > 0 ? fmt(calc.pontoEquilibrioDireto) : dash}
                    hint="Faturamento mínimo para cobrir apenas o custo do vendedor"
                    highlight
                    badge="Custo Direto"
                    badgeColor="bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/30"
                  />
                </div>

                <Separator />

                {/* 2. Custo Completo Gerencial */}
                <div>
                  <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-3">
                    2. Custo Completo Gerencial
                  </p>
                  <ResultItem
                    label="Venda mínima para cobrir também o rateio estrutural"
                    value={hasRequiredFields && calc.margemLiquidaOperacional > 0 ? fmt(calc.pontoEquilibrioCompleto) : dash}
                    hint="Custo do vendedor + rateio estrutural da empresa"
                    highlight
                    primary
                    badge="Custo Completo"
                    badgeColor="bg-violet-500/10 text-violet-600 dark:text-violet-400 border-violet-500/30"
                  />
                </div>
              </CardContent>
            </Card>

            {/* AI SUGGESTION */}
            <SimuladorIASuggestion context={aiContext} />
          </TooltipProvider>
        </CollapsibleContent>
      </Collapsible>
    </section>
  );
}

// ─── Componentes Auxiliares ───────────────────────────────────────

function InputField({ label, hint, value, onChange, type = 'number', max }: {
  label: string;
  hint: string;
  value: string | number;
  onChange: (v: any) => void;
  type?: 'text' | 'number';
  max?: number;
}) {
  return (
    <div className="space-y-1.5">
      <Label className="text-sm">{label}</Label>
      <Input
        type={type}
        min={0}
        max={max}
        value={type === 'number' ? (value || '') : value}
        onChange={e => onChange(type === 'number' ? Number(e.target.value) : e.target.value)}
        placeholder={type === 'text' ? hint : undefined}
      />
      <p className="text-[11px] text-muted-foreground leading-tight">{hint}</p>
    </div>
  );
}

function ResultItem({ label, value, hint, highlight, primary, positive, negative, badge, badgeColor }: {
  label: string;
  value: string;
  hint: string;
  highlight?: boolean;
  primary?: boolean;
  positive?: boolean;
  negative?: boolean;
  badge?: string;
  badgeColor?: string;
}) {
  return (
    <div className={cn(
      'p-3 rounded-lg border',
      highlight && !primary && 'border-border bg-muted/50',
      primary && 'border-primary bg-primary/5',
    )}>
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-1.5 min-w-0">
          <p className="text-xs text-muted-foreground truncate">{label}</p>
          <Tooltip>
            <TooltipTrigger asChild>
              <Info className="h-3 w-3 text-muted-foreground/60 cursor-help flex-shrink-0" />
            </TooltipTrigger>
            <TooltipContent side="top" className="max-w-xs text-xs">
              {hint}
            </TooltipContent>
          </Tooltip>
        </div>
        {badge && (
          <Badge variant="outline" className={cn('text-[10px] px-1.5 py-0 h-5 flex-shrink-0', badgeColor)}>
            {badge}
          </Badge>
        )}
      </div>
      <p className={cn(
        'text-lg font-bold mt-0.5',
        positive && 'text-emerald-600 dark:text-emerald-400',
        negative && 'text-destructive',
        value === '—' && 'text-muted-foreground/40',
      )}>
        {value}
      </p>
    </div>
  );
}
