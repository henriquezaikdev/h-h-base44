import { useState, useEffect, useMemo } from 'react';
import { Calculator, DollarSign, Percent, Building2, User, Award } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface SellerCost {
  id?: string;
  seller_id: string;
  salario_base: number;
  encargos_percentual: number;
  provisao_ferias_13_percentual: number;
  ajuda_custo: number;
  vale_transporte: number;
  vale_refeicao: number;
  plano_saude: number;
  internet_telefone: number;
  aluguel_rateio: number;
  outros_fixos: number;
  comissao_percentual: number;
  comissao_fixa_media: number;
  premio_bonus_medio: number;
}

interface SellerCostModalProps {
  open: boolean;
  onClose: () => void;
  sellerId: string;
  sellerName: string;
  sellerRevenue: number;
  workingDays: number;
  onSaved?: () => void;
}

const defaultCost: Omit<SellerCost, 'seller_id'> = {
  salario_base: 0,
  encargos_percentual: 35,
  provisao_ferias_13_percentual: 16.7,
  ajuda_custo: 0,
  vale_transporte: 0,
  vale_refeicao: 0,
  plano_saude: 0,
  internet_telefone: 0,
  aluguel_rateio: 0,
  outros_fixos: 0,
  comissao_percentual: 1.5,
  comissao_fixa_media: 0,
  premio_bonus_medio: 0,
};

function formatCurrency(value: number): string {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(value);
}

export function SellerCostModal({
  open,
  onClose,
  sellerId,
  sellerName,
  sellerRevenue,
  workingDays,
  onSaved,
}: SellerCostModalProps) {
  const [cost, setCost] = useState<SellerCost>({ ...defaultCost, seller_id: sellerId });
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (open && sellerId) {
      loadCost();
    }
  }, [open, sellerId]);

  const loadCost = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('seller_costs')
        .select('*')
        .eq('seller_id', sellerId)
        .maybeSingle();

      if (error) throw error;

      if (data) {
        setCost({
          id: data.id,
          seller_id: data.seller_id,
          salario_base: data.salario_base || 0,
          encargos_percentual: data.encargos_percentual || 35,
          provisao_ferias_13_percentual: data.provisao_ferias_13_percentual || 16.7,
          ajuda_custo: data.ajuda_custo || 0,
          vale_transporte: data.vale_transporte || 0,
          vale_refeicao: data.vale_refeicao || 0,
          plano_saude: data.plano_saude || 0,
          internet_telefone: data.internet_telefone || 0,
          aluguel_rateio: data.aluguel_rateio || 0,
          outros_fixos: data.outros_fixos || 0,
          comissao_percentual: data.comissao_percentual || 1.5,
          comissao_fixa_media: data.comissao_fixa_media || 0,
          premio_bonus_medio: data.premio_bonus_medio || 0,
        });
      } else {
        setCost({ ...defaultCost, seller_id: sellerId });
      }
    } catch (error) {
      console.error('Error loading seller cost:', error);
    } finally {
      setLoading(false);
    }
  };

  // Cálculos automáticos
  const calculations = useMemo(() => {
    const salarioComEncargos =
      cost.salario_base +
      cost.salario_base * (cost.encargos_percentual / 100) +
      cost.salario_base * (cost.provisao_ferias_13_percentual / 100);

    const custoFixos =
      cost.vale_transporte +
      cost.vale_refeicao +
      cost.plano_saude +
      cost.internet_telefone +
      cost.ajuda_custo +
      cost.outros_fixos +
      cost.aluguel_rateio;

    const comissaoEstimada = Math.max(
      cost.comissao_fixa_media,
      sellerRevenue * (cost.comissao_percentual / 100)
    ) + cost.premio_bonus_medio;

    const custoMensalTotal = salarioComEncargos + custoFixos + comissaoEstimada;
    const custoDiario = workingDays > 0 ? custoMensalTotal / workingDays : 0;

    return {
      salarioComEncargos,
      custoFixos,
      comissaoEstimada,
      custoMensalTotal,
      custoDiario,
    };
  }, [cost, sellerRevenue, workingDays]);

  const handleChange = (field: keyof SellerCost, value: number) => {
    setCost(prev => ({ ...prev, [field]: value }));
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const payload = {
        seller_id: sellerId,
        salario_base: cost.salario_base,
        encargos_percentual: cost.encargos_percentual,
        provisao_ferias_13_percentual: cost.provisao_ferias_13_percentual,
        ajuda_custo: cost.ajuda_custo,
        vale_transporte: cost.vale_transporte,
        vale_refeicao: cost.vale_refeicao,
        plano_saude: cost.plano_saude,
        internet_telefone: cost.internet_telefone,
        aluguel_rateio: cost.aluguel_rateio,
        outros_fixos: cost.outros_fixos,
        comissao_percentual: cost.comissao_percentual,
        comissao_fixa_media: cost.comissao_fixa_media,
        premio_bonus_medio: cost.premio_bonus_medio,
        custo_mensal_calculado: calculations.custoMensalTotal,
      };

      if (cost.id) {
        const { error } = await supabase
          .from('seller_costs')
          .update(payload)
          .eq('id', cost.id);
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('seller_costs')
          .insert(payload);
        if (error) throw error;
      }

      // Atualizar também o monthly_cost no sellers para retrocompatibilidade
      await supabase
        .from('sellers')
        .update({ monthly_cost: calculations.custoMensalTotal })
        .eq('id', sellerId);

      toast.success('Custos salvos com sucesso!');
      onSaved?.();
      onClose();
    } catch (error: any) {
      console.error('Error saving seller cost:', error);
      toast.error('Erro ao salvar custos: ' + error.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Calculator className="h-5 w-5 text-primary" />
            Calculadora de Custo — {sellerName}
          </DialogTitle>
        </DialogHeader>

        {loading ? (
          <div className="py-8 text-center text-muted-foreground">Carregando...</div>
        ) : (
          <div className="space-y-6">
            {/* Salário e Encargos */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm flex items-center gap-2">
                  <User className="h-4 w-4" />
                  Salário e Encargos
                </CardTitle>
              </CardHeader>
              <CardContent className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label>Salário Base (R$)</Label>
                  <Input
                    type="number"
                    value={cost.salario_base}
                    onChange={(e) => handleChange('salario_base', Number(e.target.value))}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Encargos (%)</Label>
                  <Input
                    type="number"
                    step="0.1"
                    value={cost.encargos_percentual}
                    onChange={(e) => handleChange('encargos_percentual', Number(e.target.value))}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Provisão Férias/13º (%)</Label>
                  <Input
                    type="number"
                    step="0.1"
                    value={cost.provisao_ferias_13_percentual}
                    onChange={(e) => handleChange('provisao_ferias_13_percentual', Number(e.target.value))}
                  />
                </div>
              </CardContent>
            </Card>

            {/* Benefícios Fixos */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Building2 className="h-4 w-4" />
                  Benefícios e Custos Fixos
                </CardTitle>
              </CardHeader>
              <CardContent className="grid grid-cols-4 gap-4">
                <div className="space-y-2">
                  <Label>Vale Transporte</Label>
                  <Input
                    type="number"
                    value={cost.vale_transporte}
                    onChange={(e) => handleChange('vale_transporte', Number(e.target.value))}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Vale Refeição</Label>
                  <Input
                    type="number"
                    value={cost.vale_refeicao}
                    onChange={(e) => handleChange('vale_refeicao', Number(e.target.value))}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Plano de Saúde</Label>
                  <Input
                    type="number"
                    value={cost.plano_saude}
                    onChange={(e) => handleChange('plano_saude', Number(e.target.value))}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Internet/Telefone</Label>
                  <Input
                    type="number"
                    value={cost.internet_telefone}
                    onChange={(e) => handleChange('internet_telefone', Number(e.target.value))}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Ajuda de Custo</Label>
                  <Input
                    type="number"
                    value={cost.ajuda_custo}
                    onChange={(e) => handleChange('ajuda_custo', Number(e.target.value))}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Rateio Aluguel</Label>
                  <Input
                    type="number"
                    value={cost.aluguel_rateio}
                    onChange={(e) => handleChange('aluguel_rateio', Number(e.target.value))}
                  />
                </div>
                <div className="space-y-2 col-span-2">
                  <Label>Outros Fixos</Label>
                  <Input
                    type="number"
                    value={cost.outros_fixos}
                    onChange={(e) => handleChange('outros_fixos', Number(e.target.value))}
                  />
                </div>
              </CardContent>
            </Card>

            {/* Comissão e Variáveis */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Award className="h-4 w-4" />
                  Comissão e Variáveis
                </CardTitle>
              </CardHeader>
              <CardContent className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label>Comissão (% da receita)</Label>
                  <Input
                    type="number"
                    step="0.1"
                    value={cost.comissao_percentual}
                    onChange={(e) => handleChange('comissao_percentual', Number(e.target.value))}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Comissão Fixa Mínima (R$)</Label>
                  <Input
                    type="number"
                    value={cost.comissao_fixa_media}
                    onChange={(e) => handleChange('comissao_fixa_media', Number(e.target.value))}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Prêmio/Bônus Médio (R$)</Label>
                  <Input
                    type="number"
                    value={cost.premio_bonus_medio}
                    onChange={(e) => handleChange('premio_bonus_medio', Number(e.target.value))}
                  />
                </div>
              </CardContent>
            </Card>

            <Separator />

            {/* Resumo Calculado */}
            <Card className="border-primary/30 bg-primary/5">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm flex items-center gap-2">
                  <DollarSign className="h-4 w-4 text-primary" />
                  Resumo do Custo
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                  <div className="text-center p-3 bg-background rounded-lg">
                    <p className="text-xs text-muted-foreground">Salário + Encargos</p>
                    <p className="text-lg font-bold">{formatCurrency(calculations.salarioComEncargos)}</p>
                  </div>
                  <div className="text-center p-3 bg-background rounded-lg">
                    <p className="text-xs text-muted-foreground">Benefícios Fixos</p>
                    <p className="text-lg font-bold">{formatCurrency(calculations.custoFixos)}</p>
                  </div>
                  <div className="text-center p-3 bg-background rounded-lg">
                    <p className="text-xs text-muted-foreground">Comissão Estimada</p>
                    <p className="text-lg font-bold text-amber-500">{formatCurrency(calculations.comissaoEstimada)}</p>
                  </div>
                  <div className="text-center p-3 bg-primary/20 rounded-lg">
                    <p className="text-xs text-muted-foreground">Custo Mensal Total</p>
                    <p className="text-xl font-bold text-primary">{formatCurrency(calculations.custoMensalTotal)}</p>
                  </div>
                  <div className="text-center p-3 bg-background rounded-lg">
                    <p className="text-xs text-muted-foreground">Custo/Dia ({workingDays} dias)</p>
                    <p className="text-lg font-bold">{formatCurrency(calculations.custoDiario)}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancelar
          </Button>
          <Button onClick={handleSave} disabled={saving}>
            {saving ? 'Salvando...' : 'Salvar Custos'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}