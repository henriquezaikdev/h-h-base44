import { Card, CardContent } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import { LucideIcon } from 'lucide-react';

interface KPIItem {
  label: string;
  value: string;
  icon: LucideIcon;
  color: string;
  bg: string;
  subValue?: string;
}

interface SellerKPIRowProps {
  kpis: KPIItem[];
}

export function SellerKPIRow({ kpis }: SellerKPIRowProps) {
  return (
    <div className="grid grid-cols-4 gap-4">
      {kpis.map((kpi, idx) => {
        const Icon = kpi.icon;
        return (
          <Card key={idx} className={cn('border-2', kpi.bg.replace('50', '200'))}>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className={cn('p-2 rounded-lg', kpi.bg)}>
                  <Icon className={cn('h-5 w-5', kpi.color)} />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">{kpi.label}</p>
                  <p className={cn('text-xl font-bold', kpi.color)}>{kpi.value}</p>
                  {kpi.subValue && (
                    <p className="text-xs text-muted-foreground">{kpi.subValue}</p>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
