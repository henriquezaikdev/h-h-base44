import { useState, useCallback } from 'react';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { 
  X, 
  ChevronLeft, 
  ChevronRight,
  User,
  Rocket,
  Settings,
  TrendingDown,
  AlertTriangle
} from 'lucide-react';
import { cn } from '@/lib/utils';
import type { SellerResult } from '@/hooks/useGestorData';
import type { Layer5Analysis } from './Layer5StrategicAnalysis';
import { SellerAnalysisChat } from './SellerAnalysisChat';
import { SellerAnalysisDashboard } from './SellerAnalysisDashboard';

interface SellerAnalysisModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  seller: SellerResult;
  layer5Analysis?: Layer5Analysis;
  allSellers: SellerResult[];
  onSellerChange: (id: string) => void;
}

function getDecisaoConfig(decisao: string) {
  switch (decisao) {
    case 'escalar':
      return { icon: Rocket, color: 'text-emerald-600', bg: 'bg-emerald-100', label: 'ESCALAR' };
    case 'ajustar_processo':
      return { icon: Settings, color: 'text-amber-600', bg: 'bg-amber-100', label: 'AJUSTAR PROCESSO' };
    case 'ajustar_margem':
      return { icon: TrendingDown, color: 'text-orange-600', bg: 'bg-orange-100', label: 'AJUSTAR MARGEM' };
    case 'risco':
      return { icon: AlertTriangle, color: 'text-red-600', bg: 'bg-red-100', label: 'RISCO' };
    default:
      return { icon: User, color: 'text-muted-foreground', bg: 'bg-muted', label: 'ANALISAR' };
  }
}

export function SellerAnalysisModal({
  open,
  onOpenChange,
  seller,
  layer5Analysis,
  allSellers,
  onSellerChange,
}: SellerAnalysisModalProps) {
  const currentIndex = allSellers.findIndex(s => s.id === seller.id);
  const decisaoConfig = getDecisaoConfig(layer5Analysis?.decisaoGerencial || '');
  const DecisaoIcon = decisaoConfig.icon;

  const handlePrev = useCallback(() => {
    if (currentIndex > 0) {
      onSellerChange(allSellers[currentIndex - 1].id);
    }
  }, [currentIndex, allSellers, onSellerChange]);

  const handleNext = useCallback(() => {
    if (currentIndex < allSellers.length - 1) {
      onSellerChange(allSellers[currentIndex + 1].id);
    }
  }, [currentIndex, allSellers, onSellerChange]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[100vw] w-[100vw] h-[100vh] max-h-[100vh] p-0 gap-0 rounded-none border-0">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b bg-gradient-to-r from-primary/5 to-transparent">
          <div className="flex items-center gap-4">
            {/* Navigation */}
            <div className="flex items-center gap-1">
              <Button
                variant="ghost"
                size="icon"
                onClick={handlePrev}
                disabled={currentIndex === 0}
                className="h-8 w-8"
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <span className="text-sm text-muted-foreground">
                {currentIndex + 1} / {allSellers.length}
              </span>
              <Button
                variant="ghost"
                size="icon"
                onClick={handleNext}
                disabled={currentIndex === allSellers.length - 1}
                className="h-8 w-8"
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>

            {/* Seller Info */}
            <div className="flex items-center gap-3">
              <div className={cn(
                'flex items-center justify-center w-10 h-10 rounded-full',
                decisaoConfig.bg
              )}>
                <DecisaoIcon className={cn('h-5 w-5', decisaoConfig.color)} />
              </div>
              <div>
                <h2 className="text-lg font-semibold">{seller.name}</h2>
                <div className="flex items-center gap-2">
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Badge variant="outline" className={cn('text-xs cursor-help', decisaoConfig.color)}>
                          {decisaoConfig.label}
                        </Badge>
                      </TooltipTrigger>
                      <TooltipContent className="max-w-xs">
                        <p className="text-xs">{layer5Analysis?.decisaoGerencialDescricao || 'Sem análise disponível'}</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                  {layer5Analysis && (
                    <span className="text-xs text-muted-foreground">
                      Eficiência: {layer5Analysis.eficienciaMeta.toFixed(0)}%
                    </span>
                  )}
                </div>
              </div>
            </div>
          </div>

          <Button
            variant="ghost"
            size="icon"
            onClick={() => onOpenChange(false)}
            className="h-8 w-8"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>

        {/* Content - Split Layout */}
        <div className="flex flex-1 overflow-hidden">
          {/* Left Panel - Chat (35%) */}
          <div className="w-[35%] border-r flex flex-col bg-muted/30">
            <SellerAnalysisChat
              seller={seller}
              layer5Analysis={layer5Analysis}
            />
          </div>

          {/* Right Panel - Dashboard (65%) */}
          <div className="w-[65%] flex flex-col overflow-hidden">
            <SellerAnalysisDashboard
              seller={seller}
              layer5Analysis={layer5Analysis}
            />
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
