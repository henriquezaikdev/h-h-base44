import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Calculator, 
  UserPlus, 
  Percent, 
  TrendingUp, 
  TrendingDown,
  Sparkles,
  RefreshCw,
  Info,
  DollarSign,
  Users,
  Clock,
  Target,
  Building2
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { cn } from '@/lib/utils';

interface WhatIfSimulatorProps {
  currentRevenue: number;
  currentMargin: number;
  currentProfit: number;
  currentCustoHumano: number;
  currentCEE: number;
  currentImpostos: number;
  currentLucroReal: number;
  currentSellersCount: number;
  avgRevenuePerSeller: number;
}

function formatCurrency(value: number): string {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value);
}

export function WhatIfSimulator({
  currentRevenue,
  currentMargin,
  currentProfit,
  currentCustoHumano,
  currentCEE,
  currentImpostos,
  currentLucroReal,
  currentSellersCount,
  avgRevenuePerSeller
}: WhatIfSimulatorProps) {
  // Simulation inputs
  const [newSellers, setNewSellers] = useState(0);
  const [marginAdjust, setMarginAdjust] = useState(0); // -5 to +10
  const [revenueGrowth, setRevenueGrowth] = useState(0); // 0 to 50%
  const [ceeReduction, setCeeReduction] = useState(0); // -30 to 0%

  // Constants for new seller costs (average)
  const avgNewSellerCost = currentSellersCount > 0 
    ? currentCustoHumano / currentSellersCount 
    : 5000;

  // Calculate projected values
  const projections = useMemo(() => {
    // Base values — usar valores reais da Visão Executiva (mesma fonte de dados)
    const currentMarginPercent = currentMargin;
    const actualProfit = currentProfit; // Lucro Bruto real (não recalculado)
    const actualLucroReal = currentLucroReal; // Resultado Real da Visão Executiva
    const actualImpostos = currentImpostos;

    // New seller impact
    const newSellerRevenue = newSellers * avgRevenuePerSeller * 0.7; // 70% productivity in first months
    const newSellerCosts = newSellers * avgNewSellerCost;

    // Margin adjustment impact
    const adjustedMarginPercent = currentMarginPercent + marginAdjust;

    // Revenue growth impact
    const growthMultiplier = 1 + (revenueGrowth / 100);
    
    // CEE reduction impact
    const ceeMultiplier = 1 + (ceeReduction / 100); // ceeReduction is negative
    
    // Projected values
    const projectedRevenue = (currentRevenue + newSellerRevenue) * growthMultiplier;
    const projectedMarginPercent = adjustedMarginPercent;
    const projectedProfit = projectedRevenue * (projectedMarginPercent / 100);
    const projectedCustoHumano = currentCustoHumano + newSellerCosts;
    const projectedCEE = currentCEE * ceeMultiplier;
    // Impostos projetados escalam proporcionalmente à receita
    const revenueRatio = currentRevenue > 0 ? projectedRevenue / currentRevenue : 1;
    const projectedImpostos = actualImpostos * revenueRatio;
    const projectedLucroReal = projectedProfit - projectedImpostos - projectedCustoHumano - projectedCEE;

    // Deltas
    const deltaRevenue = projectedRevenue - currentRevenue;
    const deltaLucroReal = projectedLucroReal - actualLucroReal;
    const deltaPercent = actualLucroReal !== 0 
      ? ((projectedLucroReal - actualLucroReal) / Math.abs(actualLucroReal)) * 100
      : 0;

    // Payback calculation for new sellers (in months)
    let paybackMonths: number | null = null;
    if (newSellers > 0) {
      const monthlyRevenueFromNewSellers = newSellerRevenue;
      const monthlyProfitFromNewSellers = monthlyRevenueFromNewSellers * (projectedMarginPercent / 100);
      const monthlyNetFromNewSellers = monthlyProfitFromNewSellers - newSellerCosts;
      
      if (monthlyNetFromNewSellers > 0) {
        // Already profitable from month 1
        paybackMonths = 1;
      } else {
        // Calculate how many months until cumulative profit covers initial investment
        // Assuming productivity grows to 100% over 6 months
        const productivityRamp = [0.7, 0.75, 0.8, 0.85, 0.9, 1.0];
        let cumulativeProfit = 0;
        for (let month = 0; month < 24; month++) {
          const productivity = productivityRamp[Math.min(month, 5)];
          const monthRevenue = newSellers * avgRevenuePerSeller * productivity;
          const monthProfit = monthRevenue * (projectedMarginPercent / 100) - newSellerCosts;
          cumulativeProfit += monthProfit;
          if (cumulativeProfit >= 0) {
            paybackMonths = month + 1;
            break;
          }
        }
      }
    }

    // 12-month ROI calculation
    let roi12Months: number | null = null;
    const monthlyDeltaLucro = deltaLucroReal;
    const totalInvestment = newSellerCosts * 6 + (currentCEE - projectedCEE) * -1; // 6 months of new seller costs
    if (totalInvestment > 0) {
      const annualReturn = monthlyDeltaLucro * 12;
      roi12Months = (annualReturn / totalInvestment) * 100;
    } else if (deltaLucroReal > 0) {
      // Pure gain with no investment
      roi12Months = Infinity;
    }

    return {
      current: {
        revenue: currentRevenue,
        margin: currentMarginPercent,
        profit: actualProfit,
        custoHumano: currentCustoHumano,
        cee: currentCEE,
        impostos: actualImpostos,
        lucroReal: actualLucroReal
      },
      projected: {
        revenue: projectedRevenue,
        margin: projectedMarginPercent,
        profit: projectedProfit,
        custoHumano: projectedCustoHumano,
        cee: projectedCEE,
        impostos: projectedImpostos,
        lucroReal: projectedLucroReal
      },
      delta: {
        revenue: deltaRevenue,
        lucroReal: deltaLucroReal,
        percent: deltaPercent
      },
      paybackMonths,
      roi12Months
    };
  }, [currentRevenue, currentMargin, currentProfit, currentCustoHumano, currentCEE, currentImpostos, currentLucroReal, newSellers, marginAdjust, revenueGrowth, ceeReduction, avgRevenuePerSeller, avgNewSellerCost]);

  const resetSimulation = () => {
    setNewSellers(0);
    setMarginAdjust(0);
    setRevenueGrowth(0);
    setCeeReduction(0);
  };

  const hasChanges = newSellers !== 0 || marginAdjust !== 0 || revenueGrowth !== 0 || ceeReduction !== 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.3 }}
    >
      <Card className="border-border/50 overflow-hidden">
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-gradient-to-br from-violet/20 to-violet/10 border border-violet/30">
                <Calculator className="h-5 w-5 text-violet" />
              </div>
              <div>
                <CardTitle className="text-lg flex items-center gap-2">
                  Simulador What-If
                  <Sparkles className="h-4 w-4 text-violet" />
                </CardTitle>
                <p className="text-sm text-muted-foreground">
                  Projete cenários de crescimento
                </p>
              </div>
            </div>
            {hasChanges && (
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={resetSimulation}
                className="text-muted-foreground hover:text-foreground"
              >
                <RefreshCw className="h-4 w-4 mr-1" />
                Resetar
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Input Sliders */}
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            {/* New Sellers */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label className="flex items-center gap-2 text-sm">
                  <UserPlus className="h-4 w-4 text-primary" />
                  Novos Vendedores
                </Label>
                <Badge variant="secondary" className="font-mono">
                  +{newSellers}
                </Badge>
              </div>
              <Slider
                value={[newSellers]}
                onValueChange={([value]) => setNewSellers(value)}
                max={5}
                min={0}
                step={1}
                className="cursor-pointer"
              />
              <p className="text-xs text-muted-foreground">
                Custo estimado: {formatCurrency(newSellers * avgNewSellerCost)}/mês
              </p>
            </div>

            {/* Margin Adjustment */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label className="flex items-center gap-2 text-sm">
                  <Percent className="h-4 w-4 text-amber" />
                  Ajuste de Margem
                </Label>
                <Badge 
                  variant="secondary" 
                  className={cn(
                    "font-mono",
                    marginAdjust > 0 && "text-emerald",
                    marginAdjust < 0 && "text-rose"
                  )}
                >
                  {marginAdjust > 0 ? '+' : ''}{marginAdjust}%
                </Badge>
              </div>
              <Slider
                value={[marginAdjust]}
                onValueChange={([value]) => setMarginAdjust(value)}
                max={10}
                min={-5}
                step={1}
                className="cursor-pointer"
              />
              <p className="text-xs text-muted-foreground">
                Margem projetada: {projections.projected.margin.toFixed(1)}%
              </p>
            </div>

            {/* Revenue Growth */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label className="flex items-center gap-2 text-sm">
                  <TrendingUp className="h-4 w-4 text-emerald" />
                  Crescimento Receita
                </Label>
                <Badge variant="secondary" className="font-mono text-emerald">
                  +{revenueGrowth}%
                </Badge>
              </div>
              <Slider
                value={[revenueGrowth]}
                onValueChange={([value]) => setRevenueGrowth(value)}
                max={50}
                min={0}
                step={5}
                className="cursor-pointer"
              />
              <p className="text-xs text-muted-foreground">
                Receita projetada: {formatCurrency(projections.projected.revenue)}
              </p>
            </div>

            {/* CEE Reduction */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label className="flex items-center gap-2 text-sm">
                  <Building2 className="h-4 w-4 text-violet" />
                  Redução de CEE
                </Label>
                <Badge 
                  variant="secondary" 
                  className={cn(
                    "font-mono",
                    ceeReduction < 0 && "text-emerald"
                  )}
                >
                  {ceeReduction}%
                </Badge>
              </div>
              <Slider
                value={[ceeReduction]}
                onValueChange={([value]) => setCeeReduction(value)}
                max={0}
                min={-30}
                step={5}
                className="cursor-pointer"
              />
              <p className="text-xs text-muted-foreground">
                CEE projetado: {formatCurrency(projections.projected.cee)}
                {ceeReduction < 0 && (
                  <span className="text-emerald ml-1">
                    (economia: {formatCurrency(currentCEE - projections.projected.cee)})
                  </span>
                )}
              </p>
            </div>
          </div>

          <Separator />

          {/* Results Comparison */}
          <AnimatePresence mode="wait">
            <motion.div
              key={`${newSellers}-${marginAdjust}-${revenueGrowth}-${ceeReduction}`}
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              transition={{ duration: 0.2 }}
              className="grid gap-4 md:grid-cols-2"
            >
              {/* Current */}
              <div className="p-4 rounded-xl bg-muted/30 border border-border/50">
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-2 h-2 rounded-full bg-muted-foreground" />
                  <span className="text-sm font-medium text-muted-foreground">Atual</span>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Receita</span>
                    <span className="font-medium">{formatCurrency(projections.current.revenue)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Lucro Bruto</span>
                    <span className="font-medium">{formatCurrency(projections.current.profit)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Despesas Totais</span>
                    <span className="font-medium text-rose">
                      -{formatCurrency(projections.current.impostos + projections.current.custoHumano + projections.current.cee)}
                    </span>
                  </div>
                  <Separator className="my-2" />
                  <div className="flex justify-between">
                    <span className="text-sm font-medium">Resultado Real</span>
                    <span className={cn(
                      "text-lg font-bold",
                      projections.current.lucroReal >= 0 ? "text-emerald" : "text-rose"
                    )}>
                      {formatCurrency(projections.current.lucroReal)}
                    </span>
                  </div>
                </div>
              </div>

              {/* Projected */}
              <div className={cn(
                "p-4 rounded-xl border-2 transition-all",
                hasChanges 
                  ? projections.delta.lucroReal >= 0
                    ? "bg-emerald/5 border-emerald/30"
                    : "bg-rose/5 border-rose/30"
                  : "bg-muted/30 border-border/50"
              )}>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <div className={cn(
                      "w-2 h-2 rounded-full",
                      hasChanges 
                        ? projections.delta.lucroReal >= 0 
                          ? "bg-emerald" 
                          : "bg-rose"
                        : "bg-muted-foreground"
                    )} />
                    <span className="text-sm font-medium">Projetado</span>
                  </div>
                  {hasChanges && (
                    <Badge className={cn(
                      "font-mono",
                      projections.delta.lucroReal >= 0 
                        ? "bg-emerald/10 text-emerald border-emerald/30"
                        : "bg-rose/10 text-rose border-rose/30"
                    )}>
                      {projections.delta.percent >= 0 ? '+' : ''}{projections.delta.percent.toFixed(1)}%
                    </Badge>
                  )}
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Receita</span>
                    <span className="font-medium">{formatCurrency(projections.projected.revenue)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Lucro Bruto</span>
                    <span className="font-medium">{formatCurrency(projections.projected.profit)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Despesas Totais</span>
                    <span className="font-medium text-rose">
                      -{formatCurrency(projections.projected.impostos + projections.projected.custoHumano + projections.projected.cee)}
                    </span>
                  </div>
                  <Separator className="my-2" />
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">Resultado Real</span>
                    <div className="flex items-center gap-2">
                      {hasChanges && (
                        <span className={cn(
                          "text-xs",
                          projections.delta.lucroReal >= 0 ? "text-emerald" : "text-rose"
                        )}>
                          {projections.delta.lucroReal >= 0 ? '+' : ''}{formatCurrency(projections.delta.lucroReal)}
                        </span>
                      )}
                      <span className={cn(
                        "text-lg font-bold",
                        projections.projected.lucroReal >= 0 ? "text-emerald" : "text-rose"
                      )}>
                        {formatCurrency(projections.projected.lucroReal)}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>

          {/* Payback & ROI Insights */}
          {hasChanges && (newSellers > 0 || ceeReduction < 0) && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="grid gap-4 md:grid-cols-2"
            >
              {/* Payback for New Sellers */}
              {newSellers > 0 && (
                <div className="p-4 rounded-xl bg-primary/5 border border-primary/20">
                  <div className="flex items-start gap-3">
                    <Clock className="h-5 w-5 text-primary mt-0.5" />
                    <div className="space-y-1">
                      <p className="text-sm font-medium text-primary">
                        Payback dos Novos Vendedores
                      </p>
                      <p className="text-2xl font-bold">
                        {projections.paybackMonths !== null 
                          ? projections.paybackMonths === 1 
                            ? "< 1 mês" 
                            : `${projections.paybackMonths} meses`
                          : "> 24 meses"
                        }
                      </p>
                      <p className="text-xs text-muted-foreground">
                        Tempo estimado para recuperar o investimento nos novos vendedores, 
                        considerando rampa de produtividade de 70% a 100% em 6 meses.
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* 12-Month ROI */}
              <div className={cn(
                "p-4 rounded-xl border",
                projections.roi12Months !== null && projections.roi12Months > 0
                  ? "bg-emerald/5 border-emerald/20"
                  : "bg-amber/5 border-amber/20"
              )}>
                <div className="flex items-start gap-3">
                  <Target className={cn(
                    "h-5 w-5 mt-0.5",
                    projections.roi12Months !== null && projections.roi12Months > 0
                      ? "text-emerald"
                      : "text-amber"
                  )} />
                  <div className="space-y-1">
                    <p className={cn(
                      "text-sm font-medium",
                      projections.roi12Months !== null && projections.roi12Months > 0
                        ? "text-emerald"
                        : "text-amber"
                    )}>
                      ROI Estimado em 12 Meses
                    </p>
                    <p className="text-2xl font-bold">
                      {projections.roi12Months === null 
                        ? "N/A"
                        : projections.roi12Months === Infinity
                          ? "∞ (ganho puro)"
                          : `${projections.roi12Months.toFixed(0)}%`
                      }
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {projections.delta.lucroReal > 0 
                        ? `Ganho anual projetado: ${formatCurrency(projections.delta.lucroReal * 12)}`
                        : `Perda anual projetada: ${formatCurrency(Math.abs(projections.delta.lucroReal * 12))}`
                      }
                    </p>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {/* Scenario Analysis Insight */}
          {hasChanges && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="p-4 rounded-xl bg-violet/5 border border-violet/20"
            >
              <div className="flex items-start gap-3">
                <Info className="h-5 w-5 text-violet mt-0.5" />
                <div className="space-y-1">
                  <p className="text-sm font-medium text-violet">
                    Análise do Cenário
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {projections.delta.lucroReal >= 0 ? (
                      <>
                        Este cenário projeta um <strong className="text-emerald">aumento de {formatCurrency(projections.delta.lucroReal)}</strong> no resultado real mensal
                        {projections.roi12Months !== null && projections.roi12Months !== Infinity && projections.roi12Months > 0 && (
                          <>, com ROI de <strong className="text-emerald">{projections.roi12Months.toFixed(0)}%</strong> em 12 meses</>
                        )}.
                        {newSellers > 0 && projections.paybackMonths !== null && (
                          <> O investimento em novos vendedores se paga em aproximadamente <strong>{projections.paybackMonths} meses</strong>.</>
                        )}
                        {ceeReduction < 0 && (
                          <> A redução de CEE contribui com <strong className="text-emerald">{formatCurrency(currentCEE - projections.projected.cee)}</strong>/mês.</>
                        )}
                      </>
                    ) : (
                      <>
                        Este cenário projeta uma <strong className="text-rose">redução de {formatCurrency(Math.abs(projections.delta.lucroReal))}</strong> no resultado real.
                        {newSellers > 0 && (
                          <> Considere aguardar até que os vendedores atuais atinjam maior produtividade ou buscar maior redução de CEE para compensar.</>
                        )}
                      </>
                    )}
                  </p>
                </div>
              </div>
            </motion.div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
}
