import { useState, useEffect, useMemo } from 'react';
import { 
  Building2, 
  HelpCircle, 
  Server, 
  Truck, 
  Landmark, 
  User, 
  FileText,
  ChevronDown, 
  ChevronUp, 
  Save,
  Lock,
  AlertTriangle
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

// =============================================================================
// FASE 2 - CEE LIMPO: CUSTO FIXO OPERACIONAL
// Custos fixos que existem mesmo com faturamento = 0
// CEE_LIMPO = R$ 24.026,49 (sem pró-labore, empréstimos ou impostos)
// =============================================================================

interface CompanyCost {
  id?: string;
  
  // 1) ESTRUTURA FÍSICA
  aluguel: number;
  condominio: number;
  iptu_mensalizado: number;
  energia: number;
  agua: number;
  internet_empresa: number;
  internet_secundaria: number;
  limpeza: number;
  manutencao_predial: number;
  seguranca_monitoramento: number;
  
  // 2) ADMINISTRATIVO & FINANCEIRO
  contabilidade: number;
  honorarios_contabeis_extras: number;
  tarifas_bancarias: number;
  manutencao_conta_pj: number;
  tarifas_pix_ted: number;
  juros_emprestimos: number;
  juros_limite_especial: number;
  antecipacao_recebiveis: number;
  multas_encargos_recorrentes: number;
  
  // 3) SISTEMAS, TECNOLOGIA E FERRAMENTAS
  crm: number;
  erp: number;
  automacoes: number;
  whatsapp_business: number;
  google_workspace: number;
  google_ads_estrutural: number;
  ferramentas_ia: number;
  licencas_software: number;
  dominios_hospedagem: number;
  backups_nuvem: number;
  
  // 4) LOGÍSTICA E OPERAÇÃO
  combustivel_geral: number;
  manutencao: number;
  frota: number;
  seguro_veiculos: number;
  ipva_mensalizado: number;
  embalagens: number;
  fretes_terceirizados: number;
  correios_transportadoras: number;
  equipamentos_operacionais: number;
  outros_logistica: number;
  
  // [REMOVIDO DO CEE] - Gestão agora é separada
  
  // 6) OUTROS FIXOS RECORRENTES
  assinaturas_diversas: number;
  servicos_terceirizados: number;
  custos_juridicos: number;
  ajustes_mensais: number;
  outros_fixos: number;
  
  // Controle
  mes_referencia?: number;
  ano_referencia?: number;
  congelado_em?: string;
}

interface Phase2CompanyCostsProps {
  activeSellersCount: number;
  onCostCalculated: (ceeTotal: number, ceePerSeller: number) => void;
}

const defaultCost: CompanyCost = {
  // 1) ESTRUTURA FÍSICA
  aluguel: 0,
  condominio: 0,
  iptu_mensalizado: 0,
  energia: 0,
  agua: 0,
  internet_empresa: 0,
  internet_secundaria: 0,
  limpeza: 0,
  manutencao_predial: 0,
  seguranca_monitoramento: 0,
  
  // 2) ADMINISTRATIVO & FINANCEIRO
  contabilidade: 0,
  honorarios_contabeis_extras: 0,
  tarifas_bancarias: 0,
  manutencao_conta_pj: 0,
  tarifas_pix_ted: 0,
  juros_emprestimos: 0,
  juros_limite_especial: 0,
  antecipacao_recebiveis: 0,
  multas_encargos_recorrentes: 0,
  
  // 3) SISTEMAS, TECNOLOGIA E FERRAMENTAS
  crm: 0,
  erp: 0,
  automacoes: 0,
  whatsapp_business: 0,
  google_workspace: 0,
  google_ads_estrutural: 0,
  ferramentas_ia: 0,
  licencas_software: 0,
  dominios_hospedagem: 0,
  backups_nuvem: 0,
  
  // 4) LOGÍSTICA E OPERAÇÃO
  combustivel_geral: 0,
  manutencao: 0,
  frota: 0,
  seguro_veiculos: 0,
  ipva_mensalizado: 0,
  embalagens: 0,
  fretes_terceirizados: 0,
  correios_transportadoras: 0,
  equipamentos_operacionais: 0,
  outros_logistica: 0,
  
  // [REMOVIDO DO CEE] - Gestão é separada
  
  // 6) OUTROS FIXOS
  assinaturas_diversas: 0,
  servicos_terceirizados: 0,
  custos_juridicos: 0,
  ajustes_mensais: 0,
  outros_fixos: 0,
};

function formatCurrency(value: number): string {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  }).format(value);
}

function HelpTooltip({ text }: { text: string }) {
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <HelpCircle className="h-4 w-4 text-muted-foreground cursor-help" />
        </TooltipTrigger>
        <TooltipContent className="max-w-xs">
          <p className="text-sm">{text}</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

interface CostInputProps {
  label: string;
  value: number;
  onChange: (value: number) => void;
  disabled?: boolean;
}

function CostInput({ label, value, onChange, disabled }: CostInputProps) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs">{label}</Label>
      <Input 
        type="number" 
        value={value || ''} 
        onChange={(e) => onChange(Number(e.target.value) || 0)}
        disabled={disabled}
        className="h-9"
        placeholder="0"
      />
    </div>
  );
}

export function Phase2CompanyCosts({ activeSellersCount, onCostCalculated }: Phase2CompanyCostsProps) {
  const [cost, setCost] = useState<CompanyCost>(defaultCost);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [expandedSections, setExpandedSections] = useState<string[]>(['estrutura']);
  const [costId, setCostId] = useState<string | null>(null);

  const isLocked = !!cost.congelado_em;

  useEffect(() => {
    loadCost();
  }, []);

  const loadCost = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('company_costs')
        .select('*')
        .limit(1)
        .maybeSingle();

      if (error) throw error;

      if (data) {
        setCostId(data.id);
        const d = data as any;
        setCost({
          // 1) ESTRUTURA FÍSICA
          aluguel: d.aluguel || 0,
          condominio: d.condominio || 0,
          iptu_mensalizado: d.iptu_mensalizado || 0,
          energia: d.energia || 0,
          agua: d.agua || 0,
          internet_empresa: d.internet_empresa || 0,
          internet_secundaria: d.internet_secundaria || 0,
          limpeza: d.limpeza || 0,
          manutencao_predial: d.manutencao_predial || 0,
          seguranca_monitoramento: d.seguranca_monitoramento || 0,
          
          // 2) ADMINISTRATIVO & FINANCEIRO
          contabilidade: d.contabilidade || 0,
          honorarios_contabeis_extras: d.honorarios_contabeis_extras || 0,
          tarifas_bancarias: d.tarifas_bancarias || 0,
          manutencao_conta_pj: d.manutencao_conta_pj || 0,
          tarifas_pix_ted: d.tarifas_pix_ted || 0,
          juros_emprestimos: d.juros_emprestimos || 0,
          juros_limite_especial: d.juros_limite_especial || 0,
          antecipacao_recebiveis: d.antecipacao_recebiveis || 0,
          multas_encargos_recorrentes: d.multas_encargos_recorrentes || 0,
          
          // 3) SISTEMAS
          crm: d.crm || 0,
          erp: d.erp || 0,
          automacoes: d.automacoes || 0,
          whatsapp_business: d.whatsapp_business || 0,
          google_workspace: d.google_workspace || 0,
          google_ads_estrutural: d.google_ads_estrutural || 0,
          ferramentas_ia: d.ferramentas_ia || 0,
          licencas_software: d.licencas_software || 0,
          dominios_hospedagem: d.dominios_hospedagem || 0,
          backups_nuvem: d.backups_nuvem || 0,
          
          // 4) LOGÍSTICA
          combustivel_geral: d.combustivel_geral || 0,
          manutencao: d.manutencao || 0,
          frota: d.frota || 0,
          seguro_veiculos: d.seguro_veiculos || 0,
          ipva_mensalizado: d.ipva_mensalizado || 0,
          embalagens: d.embalagens || 0,
          fretes_terceirizados: d.fretes_terceirizados || 0,
          correios_transportadoras: d.correios_transportadoras || 0,
          equipamentos_operacionais: d.equipamentos_operacionais || 0,
          outros_logistica: d.outros_logistica || 0,
          
          // [GESTÃO REMOVIDA DO CEE - agora é separado]
          
          // 6) OUTROS FIXOS
          assinaturas_diversas: d.assinaturas_diversas || 0,
          servicos_terceirizados: d.servicos_terceirizados || 0,
          custos_juridicos: d.custos_juridicos || 0,
          ajustes_mensais: d.ajustes_mensais || 0,
          outros_fixos: d.outros_fixos || 0,
          
          // Controle
          mes_referencia: d.mes_referencia,
          ano_referencia: d.ano_referencia,
          congelado_em: d.congelado_em,
        });
      }
    } catch (error) {
      console.error('Error loading company cost:', error);
    } finally {
      setLoading(false);
    }
  };

  // Cálculos do CEE por bloco
  const calculations = useMemo(() => {
    // 1) ESTRUTURA FÍSICA
    const estruturaFisica = 
      cost.aluguel + cost.condominio + cost.iptu_mensalizado + 
      cost.energia + cost.agua + cost.internet_empresa + 
      cost.internet_secundaria + cost.limpeza + cost.manutencao_predial + 
      cost.seguranca_monitoramento;
    
    // 2) ADMINISTRATIVO & FINANCEIRO
    const adminFinanceiro = 
      cost.contabilidade + cost.honorarios_contabeis_extras + 
      cost.tarifas_bancarias + cost.manutencao_conta_pj + 
      cost.tarifas_pix_ted + cost.juros_emprestimos + 
      cost.juros_limite_especial + cost.antecipacao_recebiveis + 
      cost.multas_encargos_recorrentes;
    
    // 3) SISTEMAS
    const sistemas = 
      cost.crm + cost.erp + cost.automacoes + cost.whatsapp_business + 
      cost.google_workspace + cost.google_ads_estrutural + 
      cost.ferramentas_ia + cost.licencas_software + 
      cost.dominios_hospedagem + cost.backups_nuvem;
    
    // 4) LOGÍSTICA
    const logistica = 
      cost.combustivel_geral + cost.manutencao + cost.frota + 
      cost.seguro_veiculos + cost.ipva_mensalizado + cost.embalagens + 
      cost.fretes_terceirizados + cost.correios_transportadoras + 
      cost.equipamentos_operacionais + cost.outros_logistica;
    
    // [5) GESTÃO REMOVIDA DO CEE LIMPO - vai em camada separada]
    
    // 6) OUTROS FIXOS
    const outrosFixos = 
      cost.assinaturas_diversas + cost.servicos_terceirizados + 
      cost.custos_juridicos + cost.ajustes_mensais + cost.outros_fixos;
    
    // CEE LIMPO Total (sem gestão, empréstimos ou impostos)
    const ceeTotal = estruturaFisica + adminFinanceiro + sistemas + logistica + outrosFixos;
    
    // CEE por vendedor
    const ceePerSeller = activeSellersCount > 0 ? ceeTotal / activeSellersCount : 0;
    
    return {
      estruturaFisica,
      adminFinanceiro,
      sistemas,
      logistica,
      outrosFixos,
      ceeTotal,
      ceePerSeller,
    };
  }, [cost, activeSellersCount]);

  useEffect(() => {
    onCostCalculated(calculations.ceeTotal, calculations.ceePerSeller);
  }, [calculations.ceeTotal, calculations.ceePerSeller, onCostCalculated]);

  const handleChange = (field: keyof CompanyCost, value: number) => {
    if (isLocked) return;
    setCost(prev => ({ ...prev, [field]: value }));
  };

  const toggleSection = (section: string) => {
    setExpandedSections(prev => 
      prev.includes(section) 
        ? prev.filter(s => s !== section)
        : [...prev, section]
    );
  };

  const handleSave = async () => {
    if (isLocked) {
      toast.error('CEE congelado. Não é possível editar.');
      return;
    }
    
    setSaving(true);
    try {
      const { id, mes_referencia, ano_referencia, congelado_em, ...payload } = cost;

      if (costId) {
        const { error } = await supabase
          .from('company_costs')
          .update(payload as any)
          .eq('id', costId);
        if (error) throw error;
      } else {
        const { data, error } = await supabase
          .from('company_costs')
          .insert(payload as any)
          .select()
          .single();
        if (error) throw error;
        setCostId(data.id);
      }

      // Sincronizar o total do CEE com gestor_config_mensal.despesas_fixas_base
      // para manter consistência entre o detalhamento (company_costs) e o resumo (gestor_config)
      const competenciaAtual = `${new Date().getFullYear()}-${String(new Date().getMonth() + 1).padStart(2, '0')}`;
      const { data: configData } = await supabase
        .from('gestor_config_mensal')
        .select('id')
        .eq('competencia', competenciaAtual)
        .maybeSingle();

      if (configData) {
        await supabase
          .from('gestor_config_mensal')
          .update({ despesas_fixas_base: calculations.ceeTotal })
          .eq('id', (configData as any).id);
      }

      toast.success('Custos estruturais salvos com sucesso!');
    } catch (error: any) {
      console.error('Error saving company cost:', error);
      toast.error('Erro ao salvar custos: ' + error.message);
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return <div className="py-8 text-center text-muted-foreground">Carregando...</div>;
  }

  const sections = [
    {
      key: 'estrutura',
      title: '1. Estrutura Física',
      icon: Building2,
      help: 'Custos que existem mesmo se a empresa não vender nada.',
      total: calculations.estruturaFisica,
      fields: [
        { key: 'aluguel', label: 'Aluguel' },
        { key: 'condominio', label: 'Condomínio' },
        { key: 'iptu_mensalizado', label: 'IPTU (mensalizado)' },
        { key: 'energia', label: 'Energia Elétrica' },
        { key: 'agua', label: 'Água' },
        { key: 'internet_empresa', label: 'Internet Principal' },
        { key: 'internet_secundaria', label: 'Internet Secundária' },
        { key: 'limpeza', label: 'Limpeza' },
        { key: 'manutencao_predial', label: 'Manutenção Predial' },
        { key: 'seguranca_monitoramento', label: 'Segurança/Monitoramento' },
      ],
    },
    {
      key: 'admin',
      title: '2. Administrativo & Financeiro',
      icon: Landmark,
      help: 'Juros e taxas NÃO são exceção. São custo estrutural.',
      total: calculations.adminFinanceiro,
      fields: [
        { key: 'contabilidade', label: 'Contabilidade' },
        { key: 'honorarios_contabeis_extras', label: 'Honorários Extras' },
        { key: 'tarifas_bancarias', label: 'Taxas Bancárias' },
        { key: 'manutencao_conta_pj', label: 'Manutenção Conta PJ' },
        { key: 'tarifas_pix_ted', label: 'Tarifas PIX/TED' },
        { key: 'juros_emprestimos', label: 'Juros de Empréstimos' },
        { key: 'juros_limite_especial', label: 'Juros Limite/Especial' },
        { key: 'antecipacao_recebiveis', label: 'Antecipação Recebíveis' },
        { key: 'multas_encargos_recorrentes', label: 'Multas/Encargos' },
      ],
    },
    {
      key: 'sistemas',
      title: '3. Sistemas e Tecnologia',
      icon: Server,
      help: 'Se cancelar e a operação travar, é estrutural.',
      total: calculations.sistemas,
      fields: [
        { key: 'crm', label: 'CRM' },
        { key: 'erp', label: 'ERP / Conta Azul' },
        { key: 'automacoes', label: 'Automações (Make, Zap)' },
        { key: 'whatsapp_business', label: 'WhatsApp Business/API' },
        { key: 'google_workspace', label: 'Google Workspace' },
        { key: 'google_ads_estrutural', label: 'Google Ads (estrutural)' },
        { key: 'ferramentas_ia', label: 'Ferramentas de IA' },
        { key: 'licencas_software', label: 'Licenças de Software' },
        { key: 'dominios_hospedagem', label: 'Domínios/Hospedagem' },
        { key: 'backups_nuvem', label: 'Backups/Nuvem' },
      ],
    },
    {
      key: 'logistica',
      title: '4. Logística e Operação',
      icon: Truck,
      help: 'Apenas custos fixos de logística. Itens já cobertos na margem real operacional (5% logística padrão) não entram novamente no rateio gerencial.',
      total: calculations.logistica,
      fields: [
        { key: 'combustivel_geral', label: 'Combustível Operacional' },
        { key: 'manutencao', label: 'Manutenção de Frota' },
        { key: 'frota', label: 'Frota' },
        { key: 'seguro_veiculos', label: 'Seguro de Veículos' },
        { key: 'ipva_mensalizado', label: 'IPVA (mensalizado)' },
        { key: 'embalagens', label: 'Embalagens' },
        { key: 'fretes_terceirizados', label: 'Fretes Terceirizados' },
        { key: 'correios_transportadoras', label: 'Correios/Transportadoras' },
        { key: 'equipamentos_operacionais', label: 'Equipamentos' },
        { key: 'outros_logistica', label: 'Outros Logística' },
      ],
    },
    // [BLOCO GESTÃO REMOVIDO DO CEE LIMPO - configurado em gestor_config_mensal.prolabore_total]
    {
      key: 'outros',
      title: '5. Outros Fixos Recorrentes',
      icon: FileText,
      help: 'Custos fixos identificados que não se encaixam nas categorias anteriores.',
      total: calculations.outrosFixos,
      fields: [
        { key: 'assinaturas_diversas', label: 'Assinaturas Diversas' },
        { key: 'servicos_terceirizados', label: 'Serviços Terceirizados' },
        { key: 'custos_juridicos', label: 'Custos Jurídicos' },
        { key: 'ajustes_mensais', label: 'Ajustes Mensais' },
        { key: 'outros_fixos', label: 'Outros Fixos' },
      ],
    },
  ];

  return (
    <div className="space-y-4">
      {/* Header com resumo */}
      <Card className="border-2 border-primary/30 bg-primary/5">
        <CardContent className="pt-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
                CEE Limpo (Custo Fixo Operacional)
              </p>
              <p className="text-3xl font-bold text-primary">
                {formatCurrency(calculations.ceeTotal)}
              </p>
              <p className="text-[10px] text-muted-foreground">
                Sem pró-labore, empréstimos ou impostos
              </p>
            </div>
            <div className="text-right">
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger className="cursor-help text-right">
                    <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
                      Rateio por Vendedor ({activeSellersCount})
                    </p>
                    <p className="text-2xl font-bold text-primary">
                      {formatCurrency(calculations.ceePerSeller)}
                    </p>
                  </TooltipTrigger>
                  <TooltipContent className="max-w-xs">
                    <p className="text-xs">O rateio da Fase 2 é proporcional à meta de cada vendedor, e não dividido por igual.</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Alerta sobre o CEE Limpo */}
      <Alert>
        <AlertTriangle className="h-4 w-4" />
        <AlertDescription className="text-xs">
          <strong>CEE Limpo:</strong> Somente custos fixos que existem mesmo com faturamento = 0. 
          É PROIBIDO incluir: impostos, empréstimos, comissões, CMV ou pró-labore.
          Estes itens são configurados separadamente na aba Gestor.
        </AlertDescription>
      </Alert>

      {isLocked && (
        <Alert variant="destructive">
          <Lock className="h-4 w-4" />
          <AlertDescription>
            CEE congelado em {new Date(cost.congelado_em!).toLocaleDateString('pt-BR')}. 
            Edição bloqueada.
          </AlertDescription>
        </Alert>
      )}

      {/* Seções de entrada */}
      <div className="space-y-2">
        {sections.map((section) => {
          const Icon = section.icon;
          const isOpen = expandedSections.includes(section.key);
          
          return (
            <Collapsible 
              key={section.key} 
              open={isOpen} 
              onOpenChange={() => toggleSection(section.key)}
            >
              <Card className={isOpen ? 'border-primary/30' : ''}>
                <CollapsibleTrigger className="w-full">
                  <CardHeader className="py-3 flex flex-row items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Icon className="h-4 w-4 text-primary" />
                      <CardTitle className="text-sm font-medium">{section.title}</CardTitle>
                      <HelpTooltip text={section.help} />
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold text-primary">
                        {formatCurrency(section.total)}
                      </span>
                      {isOpen ? (
                        <ChevronUp className="h-4 w-4" />
                      ) : (
                        <ChevronDown className="h-4 w-4" />
                      )}
                    </div>
                  </CardHeader>
                </CollapsibleTrigger>
                <CollapsibleContent>
                  <CardContent className="pt-0 grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
                    {section.fields.map((field) => (
                      <CostInput
                        key={field.key}
                        label={field.label}
                        value={(cost as any)[field.key] || 0}
                        onChange={(value) => handleChange(field.key as keyof CompanyCost, value)}
                        disabled={isLocked}
                      />
                    ))}
                  </CardContent>
                </CollapsibleContent>
              </Card>
            </Collapsible>
          );
        })}
      </div>

      {/* Botão Salvar */}
      <Button 
        onClick={handleSave} 
        disabled={saving || isLocked}
        className="w-full"
        size="lg"
      >
        <Save className="h-4 w-4 mr-2" />
        {saving ? 'Salvando...' : 'Salvar Custos Estruturais (CEE)'}
      </Button>
    </div>
  );
}
