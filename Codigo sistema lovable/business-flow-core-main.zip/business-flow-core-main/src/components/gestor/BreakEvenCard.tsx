import { useMemo, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { 
  Target, 
  TrendingUp, 
  TrendingDown, 
  AlertTriangle, 
  CheckCircle2,
  Info,
  Minus,
  Settings2
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { FinancialConfigModal } from './FinancialConfigModal';
import { format } from 'date-fns';

interface BreakEvenCardProps {
  receita: number;
  lucroBruto: number;
  ceeLimpo: number;        // CEE Limpo (só estrutural)
  prolaboreTotal: number;  // Pró-labore (separado)
  emprestimosTotal: number; // Empréstimos (separado)
  impostosVendas: number;
  custoHumanoTotal: number;
  cdvTotal: number;
  onConfigSaved?: () => void;
}

function formatCurrency(value: number): string {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value);
}

export function BreakEvenCard({
  receita,
  lucroBruto,
  ceeLimpo,
  prolaboreTotal,
  emprestimosTotal,
  impostosVendas,
  custoHumanoTotal,
  cdvTotal,
  onConfigSaved,
}: BreakEvenCardProps) {
  const [configModalOpen, setConfigModalOpen] = useState(false);
  const competencia = format(new Date(), 'yyyy-MM');
  const calculations = useMemo(() => {
    // Margem bruta %
    const margemBruta = receita > 0 ? lucroBruto / receita : 0;
    
    // Lucro bruto pós impostos
    const lucroBrutoPosImpostos = lucroBruto - impostosVendas;
    
    // Margem pós impostos
    const margemPosImpostos = receita > 0 ? lucroBrutoPosImpostos / receita : 0;
    
    // Imposto % efetivo
    const impostoPercentual = receita > 0 ? (impostosVendas / receita) * 100 : 0;
    
    // Custos totais para break-even (CEE Limpo + Pró-labore + Empréstimos)
    // FÓRMULA CORRETA: PE = (CEE + Prolabore + Empréstimos) / Margem Pós Impostos
    const custosFixosTotais = ceeLimpo + prolaboreTotal + emprestimosTotal;
    
    // Ponto de equilíbrio = Custos Fixos / Margem Pós Impostos
    const pontoEquilibrio = margemPosImpostos > 0 
      ? custosFixosTotais / margemPosImpostos 
      : Infinity;
    
    // Progresso até o break-even
    const progressoBreakEven = pontoEquilibrio > 0 && isFinite(pontoEquilibrio)
      ? Math.min(100, (receita / pontoEquilibrio) * 100)
      : 0;
    
    // Faltando/Excedente
    const diferencaBreakEven = receita - pontoEquilibrio;
    
    // Status
    let status: 'PREJUIZO' | 'EMPATE' | 'LUCRO';
    if (receita < pontoEquilibrio) {
      status = 'PREJUIZO';
    } else if (receita >= pontoEquilibrio * 1.15) {
      status = 'LUCRO';
    } else {
      status = 'EMPATE';
    }
    
    // Resultado real = Lucro Bruto - Impostos - CDV - Custo Humano - CEE Limpo - Prolabore - Emprestimos
    const resultadoReal = lucroBruto - impostosVendas - cdvTotal - custoHumanoTotal - ceeLimpo - prolaboreTotal - emprestimosTotal;
    
    return {
      margemBruta,
      margemPosImpostos,
      impostoPercentual,
      pontoEquilibrio,
      progressoBreakEven,
      diferencaBreakEven,
      status,
      resultadoReal,
      custosFixosTotais,
    };
  }, [receita, lucroBruto, ceeLimpo, prolaboreTotal, emprestimosTotal, impostosVendas, custoHumanoTotal, cdvTotal]);

  const isFinitePE = isFinite(calculations.pontoEquilibrio);

  return (
    <Card className={cn(
      'border-2',
      calculations.status === 'LUCRO' && 'border-emerald-300 dark:border-emerald-700 bg-emerald-50/50 dark:bg-emerald-950/20',
      calculations.status === 'EMPATE' && 'border-amber-300 dark:border-amber-700 bg-amber-50/50 dark:bg-amber-950/20',
      calculations.status === 'PREJUIZO' && 'border-rose-300 dark:border-rose-700 bg-rose-50/50 dark:bg-rose-950/20'
    )}>
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-base">
            <Target className="h-5 w-5 text-primary" />
            Ponto de Equilíbrio
          </div>
          <div className="flex items-center gap-2">
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setConfigModalOpen(true)}
                  className="h-7 px-2"
                >
                  <Settings2 className="h-4 w-4 mr-1" />
                  Configurar
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>Editar CEE, Pró-labore, Empréstimos e Impostos</p>
              </TooltipContent>
            </Tooltip>
            <Badge 
              variant={
                calculations.status === 'LUCRO' ? 'default' :
                calculations.status === 'EMPATE' ? 'secondary' : 'destructive'
              }
              className={cn(
                calculations.status === 'LUCRO' && 'bg-emerald-500',
                calculations.status === 'EMPATE' && 'bg-amber-500 text-white'
              )}
            >
              {calculations.status === 'LUCRO' && '✓ LUCRO OPERACIONAL'}
              {calculations.status === 'EMPATE' && '⚠ ZONA DE RISCO'}
              {calculations.status === 'PREJUIZO' && '✗ PREJUÍZO OPERACIONAL'}
            </Badge>
          </div>
        </CardTitle>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <TooltipProvider>
          {/* Grid de métricas */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {/* Receita */}
            <div className="text-center">
              <p className="text-xs text-muted-foreground uppercase tracking-wide">Receita</p>
              <p className="text-xl font-bold">{formatCurrency(receita)}</p>
            </div>
            
            {/* Margem Bruta */}
            <Tooltip>
              <TooltipTrigger asChild>
                <div className="text-center cursor-help">
                  <p className="text-xs text-muted-foreground uppercase tracking-wide flex items-center justify-center gap-1">
                    Margem Bruta
                    <Info className="h-3 w-3" />
                  </p>
                  <p className="text-xl font-bold">{(calculations.margemBruta * 100).toFixed(1)}%</p>
                </div>
              </TooltipTrigger>
              <TooltipContent>
                <p className="text-xs">Lucro Bruto / Receita (antes de impostos)</p>
              </TooltipContent>
            </Tooltip>
            
            {/* Impostos */}
            <Tooltip>
              <TooltipTrigger asChild>
                <div className="text-center cursor-help">
                  <p className="text-xs text-muted-foreground uppercase tracking-wide flex items-center justify-center gap-1">
                    Impostos
                    <Info className="h-3 w-3" />
                  </p>
                  <p className="text-xl font-bold text-rose-600 dark:text-rose-400">
                    {formatCurrency(impostosVendas)}
                  </p>
                  <p className="text-[10px] text-muted-foreground">
                    ({calculations.impostoPercentual.toFixed(2)}% efetivo)
                  </p>
                </div>
              </TooltipTrigger>
              <TooltipContent>
                <p className="text-xs">Impostos sobre vendas (ICMS, ST, DAS...)</p>
              </TooltipContent>
            </Tooltip>
            
            {/* CEE Limpo */}
            <Tooltip>
              <TooltipTrigger asChild>
                <div className="text-center cursor-help">
                  <p className="text-xs text-muted-foreground uppercase tracking-wide flex items-center justify-center gap-1">
                    CEE Limpo
                    <Info className="h-3 w-3" />
                  </p>
                  <p className="text-xl font-bold text-blue-600 dark:text-blue-400">
                    {formatCurrency(ceeLimpo)}
                  </p>
                </div>
              </TooltipTrigger>
              <TooltipContent>
                <p className="text-xs">Custo Fixo Operacional (sem pró-labore/empréstimos)</p>
              </TooltipContent>
            </Tooltip>
          </div>
          
          {/* Segunda linha de métricas */}
          <div className="grid grid-cols-3 gap-4 mt-3">
            {/* Pró-labore */}
            <Tooltip>
              <TooltipTrigger asChild>
                <div className="text-center cursor-help">
                  <p className="text-xs text-muted-foreground uppercase tracking-wide flex items-center justify-center gap-1">
                    Pró-labore
                    <Info className="h-3 w-3" />
                  </p>
                  <p className="text-lg font-bold text-violet-600 dark:text-violet-400">
                    {formatCurrency(prolaboreTotal)}
                  </p>
                </div>
              </TooltipTrigger>
              <TooltipContent>
                <p className="text-xs">Remuneração da Gestão (fora do CEE)</p>
              </TooltipContent>
            </Tooltip>
            
            {/* Empréstimos */}
            <Tooltip>
              <TooltipTrigger asChild>
                <div className="text-center cursor-help">
                  <p className="text-xs text-muted-foreground uppercase tracking-wide flex items-center justify-center gap-1">
                    Empréstimos
                    <Info className="h-3 w-3" />
                  </p>
                  <p className="text-lg font-bold text-amber-600 dark:text-amber-400">
                    {formatCurrency(emprestimosTotal)}
                  </p>
                </div>
              </TooltipTrigger>
              <TooltipContent>
                <p className="text-xs">Obrigações Financeiras (fora do CEE)</p>
              </TooltipContent>
            </Tooltip>
            
            {/* Total para PE */}
            <Tooltip>
              <TooltipTrigger asChild>
                <div className="text-center cursor-help">
                  <p className="text-xs text-muted-foreground uppercase tracking-wide flex items-center justify-center gap-1">
                    Total Fixo
                    <Info className="h-3 w-3" />
                  </p>
                  <p className="text-lg font-bold text-primary">
                    {formatCurrency(calculations.custosFixosTotais)}
                  </p>
                </div>
              </TooltipTrigger>
              <TooltipContent>
                <p className="text-xs">CEE + Pró-labore + Empréstimos (base do PE)</p>
              </TooltipContent>
            </Tooltip>
          </div>
          
          {/* Barra de progresso do Break-Even */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Progresso até Break-Even</span>
              <span className="font-medium">
                {isFinitePE ? `${calculations.progressoBreakEven.toFixed(0)}%` : 'N/A'}
              </span>
            </div>
            
            <div className="relative h-4 bg-secondary rounded-full overflow-hidden">
              {/* Zona de empate (85-115% do PE) */}
              {isFinitePE && (
                <div 
                  className="absolute h-full bg-amber-200 dark:bg-amber-900/50"
                  style={{ 
                    left: '85%', 
                    width: '30%',
                  }}
                />
              )}
              
              {/* Barra de progresso */}
              <div 
                className={cn(
                  'h-full rounded-full transition-all duration-500',
                  calculations.status === 'LUCRO' && 'bg-emerald-500',
                  calculations.status === 'EMPATE' && 'bg-amber-500',
                  calculations.status === 'PREJUIZO' && 'bg-rose-500'
                )}
                style={{ width: `${Math.min(130, calculations.progressoBreakEven)}%` }}
              />
              
              {/* Marcador do Break-Even */}
              {isFinitePE && (
                <div 
                  className="absolute top-0 h-full w-0.5 bg-foreground/50"
                  style={{ left: '100%' }}
                />
              )}
            </div>
            
            <div className="flex items-center justify-between text-xs text-muted-foreground">
              <span>R$ 0</span>
              <span className="font-medium">
                PE: {isFinitePE ? formatCurrency(calculations.pontoEquilibrio) : 'Impossível'}
              </span>
            </div>
          </div>
          
          {/* Resultado */}
          <div className="pt-3 border-t flex items-center justify-between">
            <div className="flex items-center gap-2">
              {calculations.status === 'LUCRO' ? (
                <CheckCircle2 className="h-5 w-5 text-emerald-500" />
              ) : calculations.status === 'EMPATE' ? (
                <Minus className="h-5 w-5 text-amber-500" />
              ) : (
                <AlertTriangle className="h-5 w-5 text-rose-500" />
              )}
              <div>
                <p className="text-sm font-medium">
                  {calculations.status === 'LUCRO' && 'Meta atingida!'}
                  {calculations.status === 'EMPATE' && 'Zona de risco'}
                  {calculations.status === 'PREJUIZO' && 'Abaixo do break-even'}
                </p>
                <p className="text-xs text-muted-foreground">
                  {isFinitePE && calculations.diferencaBreakEven >= 0 
                    ? `Excedente de ${formatCurrency(calculations.diferencaBreakEven)}`
                    : isFinitePE 
                      ? `Faltam ${formatCurrency(Math.abs(calculations.diferencaBreakEven))}`
                      : 'Margem insuficiente para break-even'
                  }
                </p>
              </div>
            </div>
            
            <div className="text-right">
              <p className="text-xs text-muted-foreground">Resultado Real</p>
              <p className={cn(
                'text-xl font-bold',
                calculations.resultadoReal >= 0 
                  ? 'text-emerald-600 dark:text-emerald-400' 
                  : 'text-rose-600 dark:text-rose-400'
              )}>
                {formatCurrency(calculations.resultadoReal)}
              </p>
            </div>
          </div>
        </TooltipProvider>
      </CardContent>
      
      {/* Modal de Configuração Financeira */}
      <FinancialConfigModal
        open={configModalOpen}
        onOpenChange={setConfigModalOpen}
        competencia={competencia}
        onSaved={onConfigSaved}
      />
    </Card>
  );
}
