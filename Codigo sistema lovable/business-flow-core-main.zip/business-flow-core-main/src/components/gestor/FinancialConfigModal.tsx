import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Loader2, Settings2, DollarSign, Percent, PieChart, AlertTriangle, CheckCircle2, Info } from 'lucide-react';
import { useGestorConfig, GestorConfigMensal } from '@/hooks/useGestorConfig';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

interface FinancialConfigModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  competencia: string;
  onSaved?: () => void;
}

function formatCurrency(value: number): string {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    minimumFractionDigits: 2,
  }).format(value);
}

export function FinancialConfigModal({
  open,
  onOpenChange,
  competencia,
  onSaved,
}: FinancialConfigModalProps) {
  const { config, loading, saveConfig, refetch } = useGestorConfig(competencia);
  const [saving, setSaving] = useState(false);
  
  // Form state
  const [despesasFixas, setDespesasFixas] = useState('');
  const [prolabore, setProlabore] = useState('');
  const [emprestimos, setEmprestimos] = useState('');
  const [impostosModo, setImpostosModo] = useState<'ALIQUOTA' | 'VALOR'>('ALIQUOTA');
  const [impostosAliquota, setImpostosAliquota] = useState('');
  const [impostosValor, setImpostosValor] = useState('');
  const [rateioBase, setRateioBase] = useState<'RECEITA' | 'LUCRO_BRUTO'>('RECEITA');
  const [margemFallback, setMargemFallback] = useState('');

  // Initialize form when config loads
  useEffect(() => {
    if (config) {
      setDespesasFixas(config.despesas_fixas_base.toFixed(2));
      setProlabore(config.prolabore_total.toFixed(2));
      setEmprestimos(config.emprestimos_total.toFixed(2));
      setImpostosModo(config.impostos_modo);
      setImpostosAliquota((config.impostos_aliquota_efetiva * 100).toFixed(2));
      setImpostosValor(config.impostos_valor_fechado.toFixed(2));
      setRateioBase(config.rateio_base);
      setMargemFallback((config.margem_bruta_fallback * 100).toFixed(2));
    }
  }, [config]);

  const parseNumber = (value: string): number => {
    const cleaned = value.replace(/\./g, '').replace(',', '.');
    return parseFloat(cleaned) || 0;
  };

  const ceeFixoTotal = parseNumber(despesasFixas) + parseNumber(prolabore) + parseNumber(emprestimos);

  const handleSave = async () => {
    setSaving(true);
    try {
      const success = await saveConfig({
        despesas_fixas_base: parseNumber(despesasFixas),
        prolabore_total: parseNumber(prolabore),
        emprestimos_total: parseNumber(emprestimos),
        impostos_modo: impostosModo,
        impostos_aliquota_efetiva: parseNumber(impostosAliquota) / 100,
        impostos_valor_fechado: parseNumber(impostosValor),
        rateio_base: rateioBase,
        margem_bruta_fallback: parseNumber(margemFallback) / 100,
      });

      if (success) {
        toast.success('Configuração financeira salva com sucesso!');
        onSaved?.();
        onOpenChange(false);
      } else {
        toast.error('Erro ao salvar configuração');
      }
    } catch (err) {
      toast.error('Erro ao salvar configuração');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-2xl">
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Settings2 className="h-5 w-5 text-primary" />
            Configuração Financeira do Mês
          </DialogTitle>
          <DialogDescription>
            Competência: <Badge variant="outline">{competencia}</Badge>
          </DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="cee" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="cee" className="gap-2">
              <DollarSign className="h-4 w-4" />
              CEE Fixo
            </TabsTrigger>
            <TabsTrigger value="impostos" className="gap-2">
              <Percent className="h-4 w-4" />
              Impostos
            </TabsTrigger>
            <TabsTrigger value="rateio" className="gap-2">
              <PieChart className="h-4 w-4" />
              Rateio
            </TabsTrigger>
          </TabsList>

          {/* TAB: CEE Fixo */}
          <TabsContent value="cee" className="space-y-4 mt-4">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">Custos Fixos Base (CEE)</CardTitle>
                <CardDescription>
                  Despesas que existem independente de vendas: estrutura, pró-labore e empréstimos
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="despesas">Despesas Fixas (R$)</Label>
                    <Input
                      id="despesas"
                      type="text"
                      inputMode="decimal"
                      value={despesasFixas}
                      onChange={(e) => setDespesasFixas(e.target.value)}
                      placeholder="0,00"
                    />
                    <p className="text-xs text-muted-foreground">
                      Aluguel, energia, internet, contador, sistemas...
                    </p>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="prolabore">Pró-labore (R$)</Label>
                    <Input
                      id="prolabore"
                      type="text"
                      inputMode="decimal"
                      value={prolabore}
                      onChange={(e) => setProlabore(e.target.value)}
                      placeholder="0,00"
                    />
                    <p className="text-xs text-muted-foreground">
                      Retirada mensal dos sócios
                    </p>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="emprestimos">Empréstimos (R$)</Label>
                    <Input
                      id="emprestimos"
                      type="text"
                      inputMode="decimal"
                      value={emprestimos}
                      onChange={(e) => setEmprestimos(e.target.value)}
                      placeholder="0,00"
                    />
                    <p className="text-xs text-muted-foreground">
                      Parcelas mensais (amortização + juros)
                    </p>
                  </div>
                </div>

                {/* CEE Total calculado */}
                <div className="pt-4 border-t">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="h-4 w-4 text-primary" />
                      <span className="font-medium">CEE Fixo Total</span>
                    </div>
                    <span className="text-xl font-bold text-primary">
                      {formatCurrency(ceeFixoTotal)}
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    Este é o custo mínimo mensal que a empresa precisa cobrir
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* TAB: Impostos */}
          <TabsContent value="impostos" className="space-y-4 mt-4">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">Impostos sobre Vendas</CardTitle>
                <CardDescription>
                  ICMS, ST, DAS/Simples, etc. Não confundir com CMV.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <RadioGroup
                  value={impostosModo}
                  onValueChange={(v) => setImpostosModo(v as 'ALIQUOTA' | 'VALOR')}
                  className="space-y-3"
                >
                  <div className={cn(
                    "flex items-start gap-3 p-4 rounded-lg border transition-colors",
                    impostosModo === 'ALIQUOTA' && "border-primary bg-primary/5"
                  )}>
                    <RadioGroupItem value="ALIQUOTA" id="aliquota" className="mt-0.5" />
                    <div className="flex-1 space-y-2">
                      <Label htmlFor="aliquota" className="font-medium cursor-pointer">
                        Alíquota Efetiva (%)
                      </Label>
                      <p className="text-xs text-muted-foreground">
                        Impostos = Receita × Alíquota
                      </p>
                      <Input
                        type="text"
                        inputMode="decimal"
                        value={impostosAliquota}
                        onChange={(e) => setImpostosAliquota(e.target.value)}
                        placeholder="5,50"
                        disabled={impostosModo !== 'ALIQUOTA'}
                        className="max-w-[150px]"
                      />
                    </div>
                  </div>

                  <div className={cn(
                    "flex items-start gap-3 p-4 rounded-lg border transition-colors",
                    impostosModo === 'VALOR' && "border-primary bg-primary/5"
                  )}>
                    <RadioGroupItem value="VALOR" id="valor" className="mt-0.5" />
                    <div className="flex-1 space-y-2">
                      <Label htmlFor="valor" className="font-medium cursor-pointer">
                        Valor Fechado (R$)
                      </Label>
                      <p className="text-xs text-muted-foreground">
                        Usar quando você tem o valor exato do fechamento fiscal
                      </p>
                      <Input
                        type="text"
                        inputMode="decimal"
                        value={impostosValor}
                        onChange={(e) => setImpostosValor(e.target.value)}
                        placeholder="0,00"
                        disabled={impostosModo !== 'VALOR'}
                        className="max-w-[200px]"
                      />
                    </div>
                  </div>
                </RadioGroup>

                <div className="flex items-start gap-2 p-3 rounded-lg bg-amber-500/10 border border-amber-500/30">
                  <AlertTriangle className="h-4 w-4 text-amber-500 shrink-0 mt-0.5" />
                  <p className="text-xs text-amber-700 dark:text-amber-400">
                    <strong>Dica:</strong> Use Alíquota se estiver no meio do mês. Use Valor Fechado após o fechamento fiscal.
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* TAB: Rateio */}
          <TabsContent value="rateio" className="space-y-4 mt-4">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">Critério de Rateio</CardTitle>
                <CardDescription>
                  Como distribuir o CEE Fixo entre vendedores
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <RadioGroup
                  value={rateioBase}
                  onValueChange={(v) => setRateioBase(v as 'RECEITA' | 'LUCRO_BRUTO')}
                  className="space-y-3"
                >
                  <div className={cn(
                    "flex items-start gap-3 p-4 rounded-lg border transition-colors",
                    rateioBase === 'RECEITA' && "border-primary bg-primary/5"
                  )}>
                    <RadioGroupItem value="RECEITA" id="receita" className="mt-0.5" />
                    <div className="flex-1">
                      <Label htmlFor="receita" className="font-medium cursor-pointer">
                        Proporcional à Receita
                      </Label>
                      <p className="text-xs text-muted-foreground mt-1">
                        Participação = Receita do vendedor / Receita total
                      </p>
                      <Badge variant="secondary" className="mt-2">Recomendado</Badge>
                    </div>
                  </div>

                  <div className={cn(
                    "flex items-start gap-3 p-4 rounded-lg border transition-colors",
                    rateioBase === 'LUCRO_BRUTO' && "border-primary bg-primary/5"
                  )}>
                    <RadioGroupItem value="LUCRO_BRUTO" id="lucro" className="mt-0.5" />
                    <div className="flex-1">
                      <Label htmlFor="lucro" className="font-medium cursor-pointer">
                        Proporcional ao Lucro Bruto
                      </Label>
                      <p className="text-xs text-muted-foreground mt-1">
                        Participação = Lucro bruto do vendedor / Lucro bruto total
                      </p>
                    </div>
                  </div>
                </RadioGroup>

                <div className="pt-4 border-t space-y-3">
                  <div className="space-y-2">
                    <Label htmlFor="margem-fallback">Margem Bruta Fallback (%)</Label>
                    <Input
                      id="margem-fallback"
                      type="text"
                      inputMode="decimal"
                      value={margemFallback}
                      onChange={(e) => setMargemFallback(e.target.value)}
                      placeholder="38,21"
                      className="max-w-[150px]"
                    />
                    <p className="text-xs text-muted-foreground">
                      Usada quando o mês está parcial e não há CMV fechado
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-2 p-3 rounded-lg bg-blue-500/10 border border-blue-500/30">
                  <Info className="h-4 w-4 text-blue-500 shrink-0 mt-0.5" />
                  <p className="text-xs text-blue-700 dark:text-blue-400">
                    O sistema escala automaticamente para qualquer número de vendedores. 
                    Vendedores sem vendas no mês não recebem rateio.
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancelar
          </Button>
          <Button onClick={handleSave} disabled={saving}>
            {saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
            Salvar Configuração
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
