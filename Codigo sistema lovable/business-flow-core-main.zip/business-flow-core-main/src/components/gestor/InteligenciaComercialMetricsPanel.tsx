import { useState } from 'react';
import { useInteligenciaComercialMetricas } from '@/hooks/useInteligenciaComercialMetricas';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import {
  Loader2, TrendingUp, Users, ShoppingCart, Target,
  MessageSquare, FileText, CheckCircle, RefreshCw, Activity,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { format, subDays, startOfMonth } from 'date-fns';

interface Props {
  sellerId?: string | null;
}

export function InteligenciaComercialMetricsPanel({ sellerId }: Props) {
  const [period, setPeriod] = useState<'7d' | '30d' | 'mes'>('30d');

  const now = new Date();
  const endDate = now.toISOString().split('T')[0];
  const startDate = period === '7d'
    ? subDays(now, 7).toISOString().split('T')[0]
    : period === 'mes'
      ? startOfMonth(now).toISOString().split('T')[0]
      : subDays(now, 30).toISOString().split('T')[0];

  const { data: metrics, isLoading } = useInteligenciaComercialMetricas(startDate, endDate, sellerId);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="h-5 w-5 animate-spin text-primary" />
      </div>
    );
  }

  if (!metrics) return null;

  const fmt = (v: number) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL', maximumFractionDigits: 0 }).format(v);

  return (
    <div className="space-y-6">
      {/* Period selector */}
      <div className="flex items-center justify-between">
        <h3 className="text-base font-semibold text-foreground flex items-center gap-2">
          <Activity className="h-4 w-4 text-primary" />
          Indicadores de Inteligência Comercial
        </h3>
        <div className="flex gap-1">
          {(['7d', '30d', 'mes'] as const).map(p => (
            <button
              key={p}
              onClick={() => setPeriod(p)}
              className={cn(
                "px-2.5 py-1 rounded-full text-[11px] font-medium transition-colors",
                period === p ? "bg-primary text-primary-foreground" : "bg-muted/60 text-muted-foreground hover:bg-muted"
              )}
            >
              {p === '7d' ? '7 dias' : p === '30d' ? '30 dias' : 'Mês'}
            </button>
          ))}
        </div>
      </div>

      {/* KPIs Row 1: Impact */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <MetricCard icon={TrendingUp} label="Clientes recuperados" value={metrics.clientes_recuperados} color="text-primary" />
        <MetricCard icon={ShoppingCart} label="Valor recuperado" value={fmt(metrics.valor_recuperado)} color="text-primary" />
        <MetricCard icon={Target} label="Oportunidades convertidas" value={metrics.oportunidades_convertidas} color="text-primary" />
        <MetricCard icon={Activity} label="Taxa execução fila" value={`${metrics.taxa_execucao_fila}%`} color={metrics.taxa_execucao_fila >= 60 ? "text-primary" : "text-destructive"} />
      </div>

      {/* KPIs Row 2: Usage */}
      <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
        <MiniMetric label="Análises IA" value={metrics.analises_realizadas} />
        <MiniMetric label="Tarefas criadas" value={metrics.tarefas_criadas_ia} />
        <MiniMetric label="Tarefas concluídas" value={metrics.tarefas_concluidas_ia} />
        <MiniMetric label="WhatsApp" value={metrics.whatsapp_gerados} />
        <MiniMetric label="Checklists" value={metrics.checklists_gerados} />
        <MiniMetric label="PDFs" value={metrics.pdfs_gerados} />
      </div>

      {/* Evolution Chart */}
      {metrics.evolucao_carteira.length > 1 && (
        <Card className="border-border/40">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold text-foreground">Evolução da Carteira</CardTitle>
          </CardHeader>
          <CardContent className="h-48">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={metrics.evolucao_carteira}>
                <XAxis dataKey="date" tick={{ fontSize: 10 }} tickFormatter={(d) => format(new Date(d + 'T12:00:00'), 'dd/MM')} />
                <YAxis tick={{ fontSize: 10 }} width={30} />
                <Tooltip
                  labelFormatter={(d) => format(new Date(d + 'T12:00:00'), 'dd/MM/yyyy')}
                  contentStyle={{ fontSize: 11, borderRadius: 8, border: '1px solid hsl(var(--border))' }}
                />
                <Area type="monotone" dataKey="ativos" stackId="1" stroke="hsl(142 71% 45%)" fill="hsl(142 71% 45% / 0.3)" name="Ativos" />
                <Area type="monotone" dataKey="recompra" stackId="1" stroke="hsl(45 93% 47%)" fill="hsl(45 93% 47% / 0.3)" name="Recompra" />
                <Area type="monotone" dataKey="atraso" stackId="1" stroke="hsl(25 95% 53%)" fill="hsl(25 95% 53% / 0.3)" name="Atraso" />
                <Area type="monotone" dataKey="risco" stackId="1" stroke="hsl(var(--destructive))" fill="hsl(var(--destructive) / 0.3)" name="Risco" />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      )}

      {/* Per Seller Table */}
      {metrics.por_vendedor.length > 1 && (
        <Card className="border-border/40">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold text-foreground">Desempenho por Vendedor</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-border/40">
                    <th className="text-left py-2 font-medium text-muted-foreground">Vendedor</th>
                    <th className="text-right py-2 font-medium text-muted-foreground">Recuperados</th>
                    <th className="text-right py-2 font-medium text-muted-foreground">Valor</th>
                    <th className="text-right py-2 font-medium text-muted-foreground">Análises</th>
                    <th className="text-right py-2 font-medium text-muted-foreground">Execução</th>
                    <th className="text-right py-2 font-medium text-muted-foreground">Em risco</th>
                  </tr>
                </thead>
                <tbody>
                  {metrics.por_vendedor.map(v => (
                    <tr key={v.seller_id} className="border-b border-border/20">
                      <td className="py-2 font-medium text-foreground">{v.seller_name}</td>
                      <td className="py-2 text-right tabular-nums text-foreground">{v.recuperados}</td>
                      <td className="py-2 text-right tabular-nums text-foreground">{fmt(v.valor_recuperado)}</td>
                      <td className="py-2 text-right tabular-nums text-muted-foreground">{v.analises}</td>
                      <td className={cn("py-2 text-right tabular-nums font-medium",
                        v.taxa_execucao >= 60 ? "text-primary" : v.taxa_execucao >= 30 ? "text-amber-600 dark:text-amber-400" : "text-destructive"
                      )}>
                        {v.taxa_execucao}%
                      </td>
                      <td className={cn("py-2 text-right tabular-nums",
                        v.clientes_risco > 3 ? "text-destructive font-medium" : "text-muted-foreground"
                      )}>
                        {v.clientes_risco}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

function MetricCard({ icon: Icon, label, value, color }: { icon: any; label: string; value: string | number; color: string }) {
  return (
    <Card className="border-border/40">
      <CardContent className="p-3 flex items-center gap-3">
        <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
          <Icon className={cn("h-4 w-4", color)} />
        </div>
        <div>
          <p className={cn("text-lg font-bold tabular-nums", color)}>{value}</p>
          <p className="text-[10px] text-muted-foreground leading-tight">{label}</p>
        </div>
      </CardContent>
    </Card>
  );
}

function MiniMetric({ label, value }: { label: string; value: number }) {
  return (
    <div className="p-2.5 rounded-xl border border-border/40 text-center">
      <p className="text-base font-bold tabular-nums text-foreground">{value}</p>
      <p className="text-[9px] text-muted-foreground">{label}</p>
    </div>
  );
}
