import { useEffect } from 'react';
import { AlertTriangle, ShieldAlert } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';
import type { HRAction } from '@/hooks/useHRActions';

interface AcknowledgementModalProps {
  pendingActions: HRAction[];
  onAcknowledge: (id: string) => Promise<void>;
}

export function AcknowledgementModal({ pendingActions, onAcknowledge }: AcknowledgementModalProps) {
  if (pendingActions.length === 0) return null;

  const action = pendingActions[0]; // Show one at a time

  return (
    <Dialog open={true} onOpenChange={() => {}}>
      <DialogContent className="max-w-md" onPointerDownOutside={e => e.preventDefault()} onEscapeKeyDown={e => e.preventDefault()}>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-destructive">
            <ShieldAlert className="h-5 w-5" />
            Advertência — Ciência Obrigatória
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="p-4 rounded-lg bg-destructive/10 border border-destructive/30">
            <div className="flex items-center gap-2 mb-2">
              <AlertTriangle className="h-4 w-4 text-destructive" />
              <span className="font-semibold text-sm">{action.title}</span>
              {action.severity && (
                <Badge variant="outline" className={cn(
                  action.severity === 'GRAVE' && 'border-destructive text-destructive',
                  action.severity === 'MEDIA' && 'border-amber-500 text-amber-600',
                  action.severity === 'LEVE' && 'border-blue-500 text-blue-600',
                )}>
                  {action.severity}
                </Badge>
              )}
            </div>
            {action.summary && <p className="text-sm text-muted-foreground mb-2">{action.summary}</p>}
            {action.details && <p className="text-sm">{action.details}</p>}
          </div>

          {action.corrective_action && (
            <div>
              <p className="text-xs font-semibold text-muted-foreground uppercase mb-1">Ação Corretiva Esperada</p>
              <p className="text-sm">{action.corrective_action}</p>
            </div>
          )}

          {action.correction_deadline && (
            <div>
              <p className="text-xs font-semibold text-muted-foreground uppercase mb-1">Prazo</p>
              <p className="text-sm font-medium">{format(new Date(action.correction_deadline), 'dd/MM/yyyy')}</p>
            </div>
          )}

          <p className="text-xs text-muted-foreground">
            Registrada em {format(new Date(action.created_at), 'dd/MM/yyyy HH:mm')}
          </p>
        </div>

        <DialogFooter>
          <Button
            className="w-full"
            onClick={() => onAcknowledge(action.id)}
          >
            Li e estou ciente
          </Button>
        </DialogFooter>

        {pendingActions.length > 1 && (
          <p className="text-xs text-center text-muted-foreground">
            +{pendingActions.length - 1} advertência(s) pendente(s)
          </p>
        )}
      </DialogContent>
    </Dialog>
  );
}
