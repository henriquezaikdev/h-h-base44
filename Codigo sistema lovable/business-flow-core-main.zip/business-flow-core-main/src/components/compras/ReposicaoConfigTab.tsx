import { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Settings2, Save } from 'lucide-react';
import { toast } from 'sonner';

interface ConfigRow {
  id: string;
  categoria_name: string;
  lead_time_days: number;
  safety_stock_days: number;
  reorder_multiplier: number;
}

export function ReposicaoConfigTab() {
  const queryClient = useQueryClient();
  const [edits, setEdits] = useState<Record<string, Partial<ConfigRow>>>({});
  const [saving, setSaving] = useState(false);

  const { data: configs = [], isLoading } = useQuery({
    queryKey: ['hh_replenishment_config'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('hh_replenishment_config')
        .select('*')
        .order('categoria_name');
      if (error) throw error;
      return data as ConfigRow[];
    },
  });

  const getValue = (row: ConfigRow, field: keyof ConfigRow) => {
    return edits[row.id]?.[field] ?? row[field];
  };

  const setEdit = (id: string, field: string, value: number) => {
    setEdits(prev => ({
      ...prev,
      [id]: { ...prev[id], [field]: value },
    }));
  };

  const hasChanges = Object.keys(edits).length > 0;

  const handleSave = async () => {
    setSaving(true);
    try {
      for (const [id, changes] of Object.entries(edits)) {
        const { error } = await supabase
          .from('hh_replenishment_config')
          .update({ ...changes, updated_at: new Date().toISOString() })
          .eq('id', id);
        if (error) throw error;
      }
      toast.success('Configurações salvas');
      setEdits({});
      queryClient.invalidateQueries({ queryKey: ['hh_replenishment_config'] });
    } catch (err: any) {
      toast.error('Erro ao salvar: ' + err.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2">
            <Settings2 className="h-4 w-4" /> Configuração de Lead Time por Categoria
          </CardTitle>
          {hasChanges && (
            <Button size="sm" onClick={handleSave} disabled={saving} className="gap-2">
              <Save className="h-4 w-4" /> Salvar
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent className="p-0">
        {isLoading ? (
          <div className="flex justify-center py-8">
            <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary" />
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Categoria</TableHead>
                <TableHead className="text-center">Lead Time (dias)</TableHead>
                <TableHead className="text-center">Estoque Segurança (dias)</TableHead>
                <TableHead className="text-center">Multiplicador Reposição (dias)</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {configs.map(row => (
                <TableRow key={row.id}>
                  <TableCell className="font-medium">{row.categoria_name}</TableCell>
                  <TableCell className="text-center">
                    <Input
                      type="number"
                      min={1}
                      className="w-20 mx-auto text-center h-8"
                      value={getValue(row, 'lead_time_days')}
                      onChange={e => setEdit(row.id, 'lead_time_days', parseInt(e.target.value) || 0)}
                    />
                  </TableCell>
                  <TableCell className="text-center">
                    <Input
                      type="number"
                      min={0}
                      className="w-20 mx-auto text-center h-8"
                      value={getValue(row, 'safety_stock_days')}
                      onChange={e => setEdit(row.id, 'safety_stock_days', parseInt(e.target.value) || 0)}
                    />
                  </TableCell>
                  <TableCell className="text-center">
                    <Input
                      type="number"
                      min={1}
                      className="w-20 mx-auto text-center h-8"
                      value={getValue(row, 'reorder_multiplier')}
                      onChange={e => setEdit(row.id, 'reorder_multiplier', parseInt(e.target.value) || 0)}
                    />
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  );
}
