import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Plus, Search, Pencil, Building2, Trash2 } from 'lucide-react';
import { useFornecedores, useSaveFornecedor, useDeleteFornecedor } from '@/hooks/useComprasData';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';

export function FornecedoresPanel() {
  const { data: fornecedores = [], isLoading } = useFornecedores();
  const save = useSaveFornecedor();
  const deleteFornecedor = useDeleteFornecedor();
  const [search, setSearch] = useState('');
  const [editing, setEditing] = useState<any>(null);
  const [showModal, setShowModal] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<any>(null);

  const filtered = fornecedores.filter((f: any) =>
    f.razao_social?.toLowerCase().includes(search.toLowerCase()) ||
    f.cnpj?.includes(search) ||
    f.nome_fantasia?.toLowerCase().includes(search.toLowerCase())
  );

  const openNew = () => {
    setEditing({ razao_social: '', cnpj: '', nome_fantasia: '', telefone: '', whatsapp: '', email: '', cidade: '', observacoes: '', ativo: true });
    setShowModal(true);
  };

  const openEdit = (f: any) => {
    setEditing({ ...f });
    setShowModal(true);
  };

  const handleSave = async () => {
    if (!editing?.razao_social?.trim()) return;
    await save.mutateAsync(editing);
    setShowModal(false);
    setEditing(null);
  };

  const handleDelete = async () => {
    if (!deleteTarget?.id) return;
    await deleteFornecedor.mutateAsync(deleteTarget.id);
    setDeleteTarget(null);
  };

  return (
    <div className="space-y-4">
      <div className="flex gap-3 items-center">
        <div className="relative flex-1 max-w-xs">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Buscar fornecedores..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9" />
        </div>
        <Button size="sm" onClick={openNew}>
          <Plus className="h-4 w-4 mr-1" /> Novo Fornecedor
        </Button>
      </div>

      {isLoading ? (
        <div className="flex justify-center py-12"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" /></div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-12">
          <Building2 className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
          <p className="text-sm text-muted-foreground">Nenhum fornecedor cadastrado.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {filtered.map((f: any) => (
            <Card key={f.id} className="hover:border-primary/40 transition-colors">
              <CardContent className="p-4">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0 flex-1">
                    <p className="font-medium text-sm truncate">{f.razao_social}</p>
                    {f.nome_fantasia && <p className="text-xs text-muted-foreground truncate">{f.nome_fantasia}</p>}
                    {f.cnpj && <p className="text-xs text-muted-foreground mt-1">CNPJ: {f.cnpj}</p>}
                    {f.cidade && <p className="text-xs text-muted-foreground">{f.cidade}</p>}
                  </div>
                  <div className="flex flex-col items-end gap-1.5 shrink-0">
                    <Badge variant={f.ativo ? 'default' : 'secondary'} className="text-[10px]">
                      {f.ativo ? 'Ativo' : 'Inativo'}
                    </Badge>
                    <div className="flex gap-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-7 w-7 text-muted-foreground hover:text-primary hover:bg-primary/10"
                        onClick={() => openEdit(f)}
                        title="Editar fornecedor"
                      >
                        <Pencil className="h-3.5 w-3.5" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-7 w-7 text-muted-foreground hover:text-destructive hover:bg-destructive/10"
                        onClick={() => setDeleteTarget(f)}
                        title="Excluir fornecedor"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Edit/Create Modal */}
      <Dialog open={showModal} onOpenChange={setShowModal}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>{editing?.id ? 'Editar Fornecedor' : 'Novo Fornecedor'}</DialogTitle>
          </DialogHeader>
          {editing && (
            <div className="space-y-3">
              <div>
                <Label>Razão Social *</Label>
                <Input value={editing.razao_social} onChange={(e) => setEditing({ ...editing, razao_social: e.target.value })} />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label>CNPJ</Label><Input value={editing.cnpj || ''} onChange={(e) => setEditing({ ...editing, cnpj: e.target.value })} /></div>
                <div><Label>Nome Fantasia</Label><Input value={editing.nome_fantasia || ''} onChange={(e) => setEditing({ ...editing, nome_fantasia: e.target.value })} /></div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label>Telefone</Label><Input value={editing.telefone || ''} onChange={(e) => setEditing({ ...editing, telefone: e.target.value })} /></div>
                <div><Label>WhatsApp</Label><Input value={editing.whatsapp || ''} onChange={(e) => setEditing({ ...editing, whatsapp: e.target.value })} /></div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label>Email</Label><Input value={editing.email || ''} onChange={(e) => setEditing({ ...editing, email: e.target.value })} /></div>
                <div><Label>Cidade</Label><Input value={editing.cidade || ''} onChange={(e) => setEditing({ ...editing, cidade: e.target.value })} /></div>
              </div>
              <div>
                <Label>Observações</Label>
                <Textarea value={editing.observacoes || ''} onChange={(e) => setEditing({ ...editing, observacoes: e.target.value })} rows={2} />
              </div>
              {editing?.id && (
                <div className="flex items-center gap-2">
                  <Label className="text-sm">Status:</Label>
                  <Button
                    variant={editing.ativo ? 'default' : 'secondary'}
                    size="sm"
                    className="text-xs h-7"
                    onClick={() => setEditing({ ...editing, ativo: !editing.ativo })}
                  >
                    {editing.ativo ? 'Ativo' : 'Inativo'}
                  </Button>
                </div>
              )}
              <div className="flex justify-end gap-2 pt-2">
                <Button variant="outline" onClick={() => setShowModal(false)}>Cancelar</Button>
                <Button onClick={handleSave} disabled={!editing.razao_social?.trim() || save.isPending}>
                  {save.isPending ? 'Salvando...' : 'Salvar'}
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={!!deleteTarget} onOpenChange={(open) => !open && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Excluir fornecedor?</AlertDialogTitle>
            <AlertDialogDescription>
              O fornecedor <strong>{deleteTarget?.razao_social}</strong> será excluído permanentemente. Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Excluir
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
