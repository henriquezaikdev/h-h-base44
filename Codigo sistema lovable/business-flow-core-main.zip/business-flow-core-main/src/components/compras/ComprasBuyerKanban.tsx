import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle
} from '@/components/ui/alert-dialog';
import {
  Clock, Search, AlertTriangle, Package, Truck, CheckCircle2, Eye, RefreshCw, Timer, User,
  Play, AlertCircle, Trash2, ShoppingCart, Plus, Undo2, ThumbsDown
} from 'lucide-react';
import { useSolicitacoes, useChangeStatus, useDeleteSolicitacao, STATUS_LABELS } from '@/hooks/useComprasData';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { formatDistanceToNow, isPast, differenceInHours } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { toast } from 'sonner';
import { ComprasDetailSheet } from './ComprasDetailSheet';
import { PerdaComercialModal } from './PerdaComercialModal';
import { NovaSolicitacaoModal } from './NovaSolicitacaoModal';

// Status tabs for buyer view
const BUYER_TABS = [
  { key: 'AGUARDANDO', label: 'Aguardando', icon: Clock, statuses: ['NOVA_SOLICITACAO', 'AGUARDANDO_COMPRADOR'] },
  { key: 'EM_COTACAO', label: 'Em Cotação', icon: Search, statuses: ['EM_COTACAO'] },
  { key: 'AGUARD_APROVACAO', label: 'Aguard. Aprovação', icon: AlertCircle, statuses: ['AGUARDANDO_APROVACAO_SOLICITANTE'] },
  { key: 'APROVADOS', label: 'Aprovados', icon: CheckCircle2, statuses: ['APROVADA_PARA_COMPRAR', 'RECEBIDO'] },
  { key: 'AGUARDANDO_ENTREGA', label: 'Aguardando Entrega', icon: Truck, statuses: ['EM_COMPRA_FORNECEDOR', 'AGUARDANDO_ENTREGA_FORNECEDOR'] },
  { key: 'FINALIZADOS', label: 'Finalizados', icon: CheckCircle2, statuses: ['ENTREGUE', 'CANCELADO'] },
];

// Action labels per status
const STATUS_DISPLAY: Record<string, { label: string; className: string }> = {
  NOVA_SOLICITACAO: { label: 'Novo', className: 'text-primary border-primary/30' },
  AGUARDANDO_COMPRADOR: { label: 'Novo', className: 'text-primary border-primary/30' },
  EM_COTACAO: { label: 'Em Cotação', className: 'text-primary border-primary/30' },
  AGUARDANDO_APROVACAO_SOLICITANTE: { label: 'Aguard. Aprovação', className: 'text-amber-600 border-amber-300' },
  APROVADA_PARA_COMPRAR: { label: 'Aprovada', className: 'text-emerald-600 border-emerald-300' },
  EM_COMPRA_FORNECEDOR: { label: 'Em Compra', className: 'text-primary border-primary/30' },
  AGUARDANDO_ENTREGA_FORNECEDOR: { label: 'A Caminho', className: 'text-primary border-primary/30' },
  RECEBIDO: { label: 'Recebido', className: 'text-emerald-600 border-emerald-300' },
  ENTREGUE: { label: 'Entregue', className: 'text-muted-foreground border-muted' },
  CANCELADO: { label: 'Perdido', className: 'text-destructive border-destructive/30' },
};

interface ComprasBuyerKanbanProps {
  onOpenCotacaoSession?: (sessionId: string) => void;
}

export function ComprasBuyerKanban({ onOpenCotacaoSession }: ComprasBuyerKanbanProps) {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');
  const [activeTab, setActiveTab] = useState('AGUARDANDO');
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [selectedTab, setSelectedTab] = useState<string>('cotacao');
  const [confirmAction, setConfirmAction] = useState<{ id: string; action: string; nextStatus: string } | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<string | null>(null);
  const [showNewModal, setShowNewModal] = useState(false);
  const [revertTarget, setRevertTarget] = useState<string | null>(null);
  const [perdaTarget, setPerdaTarget] = useState<any>(null);

  const { data: solicitacoes = [], isLoading, refetch } = useSolicitacoes();
  const changeStatus = useChangeStatus();
  const deleteSolicitacao = useDeleteSolicitacao();
  const { seller } = useAuth();

  const searched = solicitacoes.filter((s: any) =>
    !searchTerm ||
    s.titulo?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    s.client_name_snapshot?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    s.solicitante?.name?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const currentTab = BUYER_TABS.find(t => t.key === activeTab)!;
  const filtered = searched.filter((s: any) => currentTab.statuses.includes(s.status));

  const getTabCount = (tab: typeof BUYER_TABS[0]) =>
    searched.filter((s: any) => tab.statuses.includes(s.status)).length;

  const handleConfirmAction = async () => {
    if (!confirmAction) return;
    const extra: Record<string, any> = {};

    // If starting cotação, assign buyer
    if (confirmAction.nextStatus === 'EM_COTACAO') {
      extra.comprador_responsavel_id = seller?.id;
    }

    // Auto-approval check for EM_COTACAO → APROVAÇÃO
    let finalStatus = confirmAction.nextStatus;
    if (confirmAction.nextStatus === 'AGUARDANDO_APROVACAO_SOLICITANTE') {
      const sol = solicitacoes.find((s: any) => s.id === confirmAction.id);
      const autoApprove = sol && seller?.id === sol.solicitante?.id;
      if (autoApprove) {
        finalStatus = 'APROVADA_PARA_COMPRAR';
      }
    }

    await changeStatus.mutateAsync({
      id: confirmAction.id,
      status: finalStatus,
      extra,
      message: finalStatus === 'APROVADA_PARA_COMPRAR' && confirmAction.nextStatus === 'AGUARDANDO_APROVACAO_SOLICITANTE'
        ? 'Cotação auto-aprovada (comprador = solicitante)'
        : `${confirmAction.action}`,
    });

    // Notify requester if sent for approval (not auto-approved)
    if (finalStatus === 'AGUARDANDO_APROVACAO_SOLICITANTE') {
      const sol = solicitacoes.find((s: any) => s.id === confirmAction.id);
      if (sol?.solicitante?.id) {
        await supabase.from('seller_notifications').insert({
          seller_id: sol.solicitante.id,
          type: 'compras',
          title: 'Cotação aguardando sua aprovação',
          message: `A solicitação "${sol.titulo}" está pronta para sua aprovação.`,
          data: { solicitacao_id: confirmAction.id },
        });
      }
    }

    // BLOCO 1: After changing to EM_COTACAO, find or create cotacao session and redirect
    if (confirmAction.nextStatus === 'EM_COTACAO') {
      await handleIniciarCotacaoRedirect(confirmAction.id);
    }

    setConfirmAction(null);
  };

  const handleRevert = async () => {
    if (!revertTarget) return;
    await changeStatus.mutateAsync({
      id: revertTarget,
      status: 'AGUARDANDO_COMPRADOR',
      extra: { comprador_responsavel_id: null },
      message: 'Solicitação devolvida para fila de aguardando',
    });
    setRevertTarget(null);
  };

  const handleIniciarCotacaoRedirect = async (solicitacaoId: string) => {
    try {
      // Find solicitação title
      const { data: sol } = await supabase
        .from('solicitacoes_compra')
        .select('titulo')
        .eq('id', solicitacaoId)
        .single();

      // Check if a session already exists for this solicitação
      const { data: existing } = await supabase
        .from('cotacao_sessoes')
        .select('id')
        .eq('solicitacao_compra_id', solicitacaoId)
        .limit(1);

      let sessionId: string;

      if (existing && existing.length > 0) {
        sessionId = existing[0].id;
      } else {
        // Create new session
        const { data: newSession, error } = await supabase
          .from('cotacao_sessoes')
          .insert({
            titulo: sol?.titulo || 'Cotação',
            status: 'aberta',
            origem: 'painel_comprador',
            solicitacao_compra_id: solicitacaoId,
            created_by: seller?.id || null,
          })
          .select('id')
          .single();

        if (error) throw error;
        sessionId = (newSession as any).id;
      }

      // Redirect to Central de Cotação opening this session
      if (onOpenCotacaoSession) {
        onOpenCotacaoSession(sessionId);
      }
    } catch (err: any) {
      console.error('Error creating cotação session:', err);
      toast.error('Erro ao criar sessão de cotação');
    }
  };

  // Action config per status
  const getCardAction = (s: any): { label: string; icon: any; nextStatus: string; confirmTitle: string; confirmDesc: string } | null => {
    switch (s.status) {
      case 'NOVA_SOLICITACAO':
      case 'AGUARDANDO_COMPRADOR':
        return {
          label: 'Iniciar Cotação',
          icon: Play,
          nextStatus: 'EM_COTACAO',
          confirmTitle: 'Iniciar Cotação',
          confirmDesc: 'Ao iniciar a cotação, você assume a responsabilidade por esta solicitação.',
        };
      case 'EM_COTACAO':
        return {
          label: 'Enviar p/ Aprovação',
          icon: AlertCircle,
          nextStatus: 'AGUARDANDO_APROVACAO_SOLICITANTE',
          confirmTitle: 'Enviar para Aprovação',
          confirmDesc: 'A cotação será enviada para o solicitante aprovar. Deseja continuar?',
        };
      case 'APROVADA_PARA_COMPRAR':
        return {
          label: 'Iniciar Compra',
          icon: ShoppingCart,
          nextStatus: 'EM_COMPRA_FORNECEDOR',
          confirmTitle: 'Iniciar Compra',
          confirmDesc: 'Confirme que a compra será iniciada junto ao fornecedor.',
        };
      case 'EM_COMPRA_FORNECEDOR':
        return {
          label: 'Enviado p/ Entrega',
          icon: Truck,
          nextStatus: 'AGUARDANDO_ENTREGA_FORNECEDOR',
          confirmTitle: 'Confirmar Envio',
          confirmDesc: 'Confirme que o pedido foi enviado pelo fornecedor e está a caminho.',
        };
      case 'AGUARDANDO_ENTREGA_FORNECEDOR':
        return {
          label: 'Recebido',
          icon: Package,
          nextStatus: 'RECEBIDO',
          confirmTitle: 'Confirmar Recebimento',
          confirmDesc: 'Confirme que o pedido foi recebido no estoque.',
        };
      case 'RECEBIDO':
        return {
          label: 'Entregue ao Cliente',
          icon: CheckCircle2,
          nextStatus: 'ENTREGUE',
          confirmTitle: 'Marcar como Entregue',
          confirmDesc: 'Confirme que o produto foi entregue ao cliente.',
        };
      default:
        return null;
    }
  };

  return (
    <div className="space-y-4">
      {/* Search bar */}
      <div className="flex gap-2 items-center">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Buscar..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="pl-9" />
        </div>
        <Button variant="outline" size="icon" onClick={() => refetch()} className="h-9 w-9">
          <RefreshCw className="h-4 w-4" />
        </Button>
        <Button size="sm" onClick={() => setShowNewModal(true)}>
          <Plus className="h-4 w-4 mr-1" /> Nova Solicitação
        </Button>
      </div>

      <NovaSolicitacaoModal open={showNewModal} onOpenChange={setShowNewModal} />

      {/* Status tabs - horizontal scroll */}
      <div className="flex gap-6 border-b overflow-x-auto pb-0">
        {BUYER_TABS.map(tab => {
          const count = getTabCount(tab);
          const Icon = tab.icon;
          const isActive = activeTab === tab.key;
          return (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={`flex items-center gap-2 pb-3 px-1 text-sm font-medium whitespace-nowrap border-b-2 transition-colors ${
                isActive
                  ? 'border-primary text-primary'
                  : 'border-transparent text-muted-foreground hover:text-foreground'
              }`}
            >
              <Icon className="h-4 w-4" />
              {tab.label}
              <Badge variant={isActive ? 'default' : 'secondary'} className="text-[10px] px-1.5 py-0 min-w-[20px] justify-center">
                {count}
              </Badge>
            </button>
          );
        })}
      </div>

      {/* List */}
      {isLoading ? (
        <div className="flex justify-center py-16">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground text-sm">Nenhuma solicitação nesta etapa.</div>
      ) : (
        <div className="space-y-3">
          {filtered.map((s: any) => {
            const action = getCardAction(s);
            const display = STATUS_DISPLAY[s.status] || { label: s.status, className: 'text-muted-foreground' };
            const hasOverdueResponse = s.requested_response_due_at && isPast(new Date(s.requested_response_due_at));
            const itemCount = s.solicitacao_itens?.length || 0;

            return (
              <Card key={s.id} className="border hover:border-primary/30 transition-colors cursor-pointer" onClick={() => { setSelectedId(s.id); setSelectedTab(s.process_type === 'ORDEM_DIRETA' ? 'detalhes' : 'cotacao'); }}>
                <CardContent className="p-0">
                  {/* Top section */}
                  <div className="p-4 pb-2">
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0 flex-1">
                         <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-bold text-sm">{s.titulo}</span>
                          <Badge variant="outline" className="text-[10px] gap-1 font-medium border-primary/30 text-primary">
                            ↑ {s.prioridade}
                          </Badge>
                          {s.process_type === 'ORDEM_DIRETA' && (
                            <Badge className="text-[10px] gap-1 bg-emerald-600 text-white">
                              <ShoppingCart className="h-3 w-3" /> Ordem Direta
                            </Badge>
                          )}
                          {s.status === 'CANCELADO' && s.lost_reason && (
                            <Badge variant="destructive" className="text-[10px] gap-1">
                              <ThumbsDown className="h-3 w-3" /> Perdido
                            </Badge>
                          )}
                        </div>
                        <div className="flex items-center gap-3 mt-1.5 text-xs text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <User className="h-3 w-3" />
                            {s.solicitante?.name || 'N/A'}
                          </span>
                          <span>• {itemCount} itens</span>
                          {s.client_name_snapshot && <span>• {s.client_name_snapshot}</span>}
                        </div>
                        {hasOverdueResponse && (
                          <Badge variant="destructive" className="mt-1.5 text-[10px] gap-1">
                            <AlertCircle className="h-3 w-3" />
                            Resposta: Vencido
                          </Badge>
                        )}
                      </div>
                      <div className="flex flex-col items-end gap-1 shrink-0">
                        <Badge variant="outline" className={`text-[10px] font-medium ${display.className}`}>
                          {display.label}
                        </Badge>
                        <span className="text-[10px] text-muted-foreground">
                          {s.comprador?.name || 'Não atribuído'}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Live Timer (if applicable) */}
                  {s.supplier_eta_at && (
                    <div className="px-4 pb-2">
                      <LiveTimer eta={s.supplier_eta_at} />
                    </div>
                  )}

                  {/* Bottom bar with timestamp + actions */}
                  <div className="flex items-center justify-between px-4 py-2.5 border-t bg-muted/30">
                    <span className="text-[11px] text-muted-foreground">
                      Atualizado {formatDistanceToNow(new Date(s.updated_at || s.created_at), { addSuffix: true, locale: ptBR })}
                    </span>
                    <div className="flex items-center gap-2">
                      {s.status === 'EM_COTACAO' && (
                        <Button
                          variant="outline"
                          size="sm"
                          className="h-7 text-xs gap-1.5"
                          onClick={(e) => {
                            e.stopPropagation();
                            setRevertTarget(s.id);
                          }}
                        >
                          <Undo2 className="h-3.5 w-3.5" />
                          Devolver
                        </Button>
                      )}
                      {s.status === 'AGUARDANDO_APROVACAO_SOLICITANTE' && (
                        <Button
                          variant="destructive"
                          size="sm"
                          className="h-7 text-xs gap-1.5"
                          onClick={(e) => {
                            e.stopPropagation();
                            setPerdaTarget(s);
                          }}
                        >
                          <ThumbsDown className="h-3.5 w-3.5" />
                          Perdi
                        </Button>
                      )}
                      {action && (
                        <Button
                          size="sm"
                          className="h-7 text-xs gap-1.5"
                          onClick={(e) => {
                            e.stopPropagation();
                            setConfirmAction({ id: s.id, action: action.label, nextStatus: action.nextStatus });
                          }}
                        >
                          <action.icon className="h-3.5 w-3.5" />
                          {action.label}
                        </Button>
                      )}
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-7 text-xs gap-1.5 text-muted-foreground"
                        onClick={(e) => { e.stopPropagation(); setSelectedId(s.id); setSelectedTab('detalhes'); }}
                      >
                        <Eye className="h-3.5 w-3.5" />
                        Detalhes
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Confirmation dialog */}
      <AlertDialog open={!!confirmAction} onOpenChange={(v) => !v && setConfirmAction(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              {confirmAction?.nextStatus === 'EM_COTACAO' && <CheckCircle2 className="h-5 w-5 text-primary" />}
              {confirmAction?.nextStatus === 'RECEBIDO' && <Package className="h-5 w-5 text-primary" />}
              {confirmAction?.nextStatus === 'ENTREGUE' && <CheckCircle2 className="h-5 w-5 text-primary" />}
              {confirmAction?.action}
            </AlertDialogTitle>
            <AlertDialogDescription>
              {confirmAction && getCardAction({ status: confirmAction.nextStatus === 'EM_COTACAO' ? 'NOVA_SOLICITACAO' : confirmAction.nextStatus === 'RECEBIDO' ? 'AGUARDANDO_ENTREGA_FORNECEDOR' : confirmAction.nextStatus === 'ENTREGUE' ? 'RECEBIDO' : '' } as any)?.confirmDesc}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleConfirmAction} disabled={changeStatus.isPending}>
              {confirmAction?.action}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Revert confirmation dialog */}
      <AlertDialog open={!!revertTarget} onOpenChange={(v) => !v && setRevertTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <Undo2 className="h-5 w-5 text-muted-foreground" />
              Devolver Solicitação
            </AlertDialogTitle>
            <AlertDialogDescription>
              A solicitação voltará para a fila de "Aguardando" e poderá ser retomada depois. A sessão de cotação vinculada será mantida.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleRevert} disabled={changeStatus.isPending}>
              Devolver
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Detail sheet (side panel) */}
      {selectedId && (
        <ComprasDetailSheet
          open={!!selectedId}
          onOpenChange={(v) => !v && setSelectedId(null)}
          solicitacaoId={selectedId}
          initialTab={selectedTab}
        />
      )}

      {/* Perda Comercial Modal */}
      {perdaTarget && (
        <PerdaComercialModal
          open={!!perdaTarget}
          onOpenChange={(v) => !v && setPerdaTarget(null)}
          solicitacao={perdaTarget}
          itens={perdaTarget?.solicitacao_itens || []}
        />
      )}
    </div>
  );
}

function LiveTimer({ eta }: { eta: string }) {
  const [now, setNow] = useState(Date.now());

  useEffect(() => {
    const interval = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(interval);
  }, []);

  const target = new Date(eta).getTime();
  const diff = target - now;
  const isLate = diff < 0;
  const absDiff = Math.abs(diff);

  const days = Math.floor(absDiff / (1000 * 60 * 60 * 24));
  const hours = Math.floor((absDiff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  const minutes = Math.floor((absDiff % (1000 * 60 * 60)) / (1000 * 60));
  const seconds = Math.floor((absDiff % (1000 * 60)) / 1000);

  const timeStr = days > 0
    ? `${days}d ${hours}h ${minutes}m`
    : `${hours}h ${minutes}m ${seconds}s`;

  return (
    <div className={`flex items-center gap-1.5 text-xs font-mono px-2 py-1 rounded ${
      isLate
        ? 'bg-destructive/10 text-destructive'
        : 'bg-primary/10 text-primary'
    }`}>
      <Timer className="h-3.5 w-3.5" />
      {isLate ? (
        <span>ATRASADO +{timeStr}</span>
      ) : (
        <span>ETA: {timeStr}</span>
      )}
    </div>
  );
}
