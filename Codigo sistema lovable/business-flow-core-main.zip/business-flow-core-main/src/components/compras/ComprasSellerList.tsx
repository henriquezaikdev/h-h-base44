import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Plus, Search, AlertTriangle, Trash2, CheckCircle2, ClipboardCheck, ShoppingCart
} from 'lucide-react';
import { useSolicitacoes, useChangeStatus, useDeleteSolicitacao, STATUS_LABELS } from '@/hooks/useComprasData';
import { useAuth } from '@/hooks/useAuth';
import { formatDistanceToNow } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { NovaSolicitacaoModal } from './NovaSolicitacaoModal';
import { ComprasDetailSheet } from './ComprasDetailSheet';

const SELLER_STATUSES = [
  { key: 'ALL', label: 'Todas', statuses: [] as string[] },
  { key: 'NOVA_SOLICITACAO', label: 'Novas', statuses: ['NOVA_SOLICITACAO'] },
  { key: 'AGUARDANDO_APROVACAO_SOLICITANTE', label: 'Para Aprovar', statuses: ['AGUARDANDO_APROVACAO_SOLICITANTE'] },
  { key: 'EM_COTACAO', label: 'Em Cotação', statuses: ['EM_COTACAO'] },
  { key: 'APROVADOS', label: 'Aprovados', statuses: ['APROVADA_PARA_COMPRAR', 'EM_COMPRA_FORNECEDOR', 'AGUARDANDO_ENTREGA_FORNECEDOR', 'RECEBIDO'] },
  { key: 'ENTREGUE', label: 'Entregues', statuses: ['ENTREGUE'] },
];

interface ComprasSellerListProps {
  /** When true, restricts to vendedor-only view: only own solicitações, no edit/delete */
  isVendedorView?: boolean;
}

export function ComprasSellerList({ isVendedorView = false }: ComprasSellerListProps) {
  const [activeFilter, setActiveFilter] = useState('ALL');
  const [searchTerm, setSearchTerm] = useState('');
  const [showNewModal, setShowNewModal] = useState(false);
  const [selected, setSelected] = useState<any>(null);
  const [deleteTarget, setDeleteTarget] = useState<string | null>(null);
  const [confirmFinish, setConfirmFinish] = useState<string | null>(null);
  const { seller } = useAuth();
  const changeStatus = useChangeStatus();
  const deleteSolicitacao = useDeleteSolicitacao();

  // For vendedor view: filter only by solicitante_id (own requests only)
  const { data: solicitacoes = [], isLoading } = useSolicitacoes(
    isVendedorView
      ? { onlySolicitanteId: seller?.id }
      : { mySellerId: seller?.id }
  );

  const searched = solicitacoes.filter((s: any) =>
    !searchTerm ||
    s.titulo?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    s.client_name_snapshot?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const currentFilter = SELLER_STATUSES.find(st => st.key === activeFilter)!;
  const filtered = activeFilter === 'ALL'
    ? searched
    : searched.filter((s: any) => currentFilter.statuses.includes(s.status));

  const pendingApproval = solicitacoes.filter((s: any) => s.status === 'AGUARDANDO_APROVACAO_SOLICITANTE').length;

  return (
    <div className="space-y-4">
      {/* Alert */}
      {pendingApproval > 0 && (
        <div className="flex items-center gap-2 rounded-lg border border-orange-300 bg-orange-50 dark:bg-orange-950/20 px-4 py-2.5 text-sm">
          <AlertTriangle className="h-4 w-4 text-orange-600 flex-shrink-0" />
          <span className="text-orange-700 dark:text-orange-400 font-medium">
            {pendingApproval} cotação(ões) aguardando sua aprovação
          </span>
        </div>
      )}

      {/* Search + New */}
      <div className="flex gap-2 items-center">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Buscar solicitações..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="pl-9" />
        </div>
        <Button size="sm" onClick={() => setShowNewModal(true)}>
          <Plus className="h-4 w-4 mr-1" /> Nova Solicitação
        </Button>
      </div>

      {/* Filter chips */}
      <div className="flex gap-1.5 flex-wrap">
        {SELLER_STATUSES.map(st => {
          const count = st.key === 'ALL'
            ? searched.length
            : searched.filter((s: any) => st.statuses.includes(s.status)).length;
          return (
            <button
              key={st.key}
              onClick={() => setActiveFilter(st.key)}
              className={`px-3 py-1.5 rounded-full text-xs font-medium transition-colors ${
                activeFilter === st.key
                  ? 'bg-foreground text-background'
                  : 'bg-muted text-muted-foreground hover:bg-muted/80'
              }`}
            >
              {st.label} ({count})
            </button>
          );
        })}
      </div>

      {/* List */}
      {isLoading ? (
        <div className="flex justify-center py-16">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground text-sm">Nenhuma solicitação encontrada.</div>
      ) : (
        <div className="space-y-2">
          {filtered.map((s: any) => (
            <Card key={s.id} className="cursor-pointer hover:border-primary/40 transition-colors" onClick={() => setSelected(s)}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between gap-3">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      {s.prioridade === 'URGENTE' && <AlertTriangle className="h-4 w-4 text-destructive shrink-0" />}
                      <span className="font-semibold text-sm truncate">{s.titulo}</span>
                    </div>
                    <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
                      {s.client_name_snapshot && <span>{s.client_name_snapshot}</span>}
                      <span>{s.solicitacao_itens?.length || 0} itens</span>
                      <span>{formatDistanceToNow(new Date(s.updated_at || s.created_at), { addSuffix: true, locale: ptBR })}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    {s.process_type === 'ORDEM_DIRETA' && (
                      <Badge className="text-[10px] gap-1 bg-emerald-600 text-white">
                        <ShoppingCart className="h-3 w-3" /> Direta
                      </Badge>
                    )}
                    <Badge variant="outline" className="text-[10px]">{STATUS_LABELS[s.status] || s.status}</Badge>

                    {/* Actions: hidden for vendedor view */}
                    {!isVendedorView && (
                      <>
                        {s.status === 'AGUARDANDO_APROVACAO_SOLICITANTE' && (
                          <Button
                            size="sm"
                            variant="outline"
                            className="h-7 text-xs gap-1 border-orange-400 text-orange-700 dark:text-orange-400 hover:bg-orange-50 dark:hover:bg-orange-950/30"
                            onClick={(e) => { e.stopPropagation(); setSelected(s); }}
                          >
                            <ClipboardCheck className="h-3.5 w-3.5" />
                            Analisar
                          </Button>
                        )}
                        {s.status === 'RECEBIDO' && (
                          <Button
                            size="sm"
                            className="h-7 text-xs gap-1"
                            onClick={(e) => { e.stopPropagation(); setConfirmFinish(s.id); }}
                          >
                            <CheckCircle2 className="h-3.5 w-3.5" />
                            Entregue ao Cliente
                          </Button>
                        )}
                        {!['ENTREGUE', 'CANCELADO'].includes(s.status) && (
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-7 w-7 text-muted-foreground hover:text-destructive"
                            onClick={(e) => { e.stopPropagation(); setDeleteTarget(s.id); }}
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </Button>
                        )}
                      </>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <NovaSolicitacaoModal open={showNewModal} onOpenChange={setShowNewModal} />
      {selected && (
        <ComprasDetailSheet
          open={!!selected}
          onOpenChange={(v) => !v && setSelected(null)}
          solicitacaoId={selected.id}
        />
      )}

      {/* Finish confirmation dialog */}
      {!isVendedorView && (
        <AlertDialog open={!!confirmFinish} onOpenChange={(v) => !v && setConfirmFinish(null)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Marcar como entregue?</AlertDialogTitle>
              <AlertDialogDescription>
                Confirme que o produto foi entregue ao cliente.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancelar</AlertDialogCancel>
              <AlertDialogAction
                onClick={async () => {
                  if (confirmFinish) {
                    await changeStatus.mutateAsync({ id: confirmFinish, status: 'ENTREGUE', message: 'Produto entregue ao cliente' });
                    setConfirmFinish(null);
                  }
                }}
              >
                Confirmar Entrega
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      )}

      {/* Delete confirmation dialog */}
      {!isVendedorView && (
        <AlertDialog open={!!deleteTarget} onOpenChange={(v) => !v && setDeleteTarget(null)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Excluir solicitação?</AlertDialogTitle>
              <AlertDialogDescription>
                Esta ação é irreversível. Todos os itens, cotações e eventos desta solicitação serão removidos.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancelar</AlertDialogCancel>
              <AlertDialogAction
                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                onClick={async () => {
                  if (deleteTarget) {
                    await deleteSolicitacao.mutateAsync(deleteTarget);
                    setDeleteTarget(null);
                  }
                }}
              >
                Excluir
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      )}
    </div>
  );
}
