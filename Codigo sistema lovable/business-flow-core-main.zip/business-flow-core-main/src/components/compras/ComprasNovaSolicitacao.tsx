import { useState, useEffect, useRef } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Trash2, Search, Keyboard, Paperclip, X, FileText } from 'lucide-react';
import { toast } from 'sonner';
import { useCreateSolicitacao, useAddSolicitacaoItem } from '@/hooks/useComprasData';
import { supabase } from '@/integrations/supabase/client';
import { useQuery } from '@tanstack/react-query';

function useDebouncedValue(value: string, delay = 300) {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const t = setTimeout(() => setDebounced(value), delay);
    return () => clearTimeout(t);
  }, [value, delay]);
  return debounced;
}

interface SolicitacaoItem {
  descricao: string;
  produto_id: string | null;
  quantidade: string;
  unidade: string;
  observacoes: string;
  anexos: string[];
  produtoSearch: string;
  showProdutoResults: boolean;
}

const emptyItem = (): SolicitacaoItem => ({
  descricao: '', produto_id: null, quantidade: '1', unidade: 'Unidade', observacoes: '',
  anexos: [], produtoSearch: '', showProdutoResults: false,
});

function AttachmentTextarea({ value, onChange, anexos, onAnexosChange, placeholder }: {
  value: string;
  onChange: (v: string) => void;
  anexos: string[];
  onAnexosChange: (urls: string[]) => void;
  placeholder?: string;
}) {
  const fileRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);

  const uploadFile = async (file: File) => {
    setUploading(true);
    try {
      const ext = file.name.split('.').pop() || 'bin';
      const path = `${Date.now()}_${Math.random().toString(36).slice(2)}.${ext}`;
      const { data, error } = await supabase.storage.from('cotacao-images').upload(path, file);
      if (error) throw error;
      const { data: { publicUrl } } = supabase.storage.from('cotacao-images').getPublicUrl(data.path);
      onAnexosChange([...anexos, publicUrl]);
    } catch (err: any) {
      toast.error('Erro ao enviar arquivo: ' + (err.message || 'erro desconhecido'));
    } finally {
      setUploading(false);
    }
  };

  const handlePaste = async (e: React.ClipboardEvent) => {
    const items = e.clipboardData?.items;
    if (!items) return;
    for (const item of Array.from(items)) {
      if (item.type.startsWith('image/') || item.type === 'application/pdf') {
        e.preventDefault();
        const file = item.getAsFile();
        if (file) await uploadFile(file);
        return;
      }
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files) {
      Array.from(files).forEach(f => uploadFile(f));
    }
    e.target.value = '';
  };

  const removeAnexo = (idx: number) => {
    onAnexosChange(anexos.filter((_, i) => i !== idx));
  };

  return (
    <div className="space-y-1.5">
      <div onPaste={handlePaste} className="relative">
        <textarea
          value={value}
          onChange={(e) => onChange(e.target.value)}
          rows={1}
          className="flex w-full rounded-md border border-input bg-background px-3 py-2 pr-9 text-xs ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 resize-none"
          placeholder={placeholder}
        />
        <button
          type="button"
          onClick={() => fileRef.current?.click()}
          disabled={uploading}
          className="absolute right-2 top-2 text-muted-foreground hover:text-foreground transition-colors"
          title="Anexar imagem ou PDF"
        >
          <Paperclip className="h-4 w-4" />
        </button>
        <input
          ref={fileRef}
          type="file"
          accept="image/*,.pdf"
          multiple
          className="hidden"
          onChange={handleFileSelect}
        />
      </div>
      {uploading && <p className="text-xs text-muted-foreground animate-pulse">Enviando arquivo...</p>}
      {anexos.length > 0 && (
        <div className="flex flex-wrap gap-2">
          {anexos.map((url, i) => {
            const isPdf = url.toLowerCase().endsWith('.pdf');
            return (
              <div key={i} className="relative group flex items-center gap-1.5 p-1.5 border rounded-md bg-muted/30">
                {isPdf ? (
                  <a href={url} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1 text-xs text-primary hover:underline">
                    <FileText className="h-4 w-4" /> PDF
                  </a>
                ) : (
                  <a href={url} target="_blank" rel="noopener noreferrer">
                    <img src={url} alt="Anexo" className="h-12 w-12 object-cover rounded" />
                  </a>
                )}
                <button type="button" onClick={() => removeAnexo(i)} className="text-muted-foreground hover:text-destructive">
                  <X className="h-3 w-3" />
                </button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
}

export function ComprasNovaSolicitacao({ open, onOpenChange }: Props) {
  const [titulo, setTitulo] = useState('');
  const [prioridade, setPrioridade] = useState('NORMAL');
  // REGRA: cliente inicia no modo BASE (CRM) por padrão
  const [clienteMode, setClienteMode] = useState<'base' | 'manual'>('base');
  const [clienteManual, setClienteManual] = useState('');
  const [selectedClientId, setSelectedClientId] = useState<string | null>(null);
  const [clientSearch, setClientSearch] = useState('');
  const [showClientResults, setShowClientResults] = useState(false);
  const [prazoResposta, setPrazoResposta] = useState('');
  const [itens, setItens] = useState<SolicitacaoItem[]>([emptyItem()]);

  const create = useCreateSolicitacao();
  const addItemMutation = useAddSolicitacaoItem();

  // Client search — queries the main CRM clients table
  const debouncedClientSearch = useDebouncedValue(clientSearch, 300);
  const { data: clientResults = [] } = useQuery({
    queryKey: ['compras_client_search', debouncedClientSearch],
    enabled: clienteMode === 'base' && debouncedClientSearch.length >= 2,
    queryFn: async () => {
      const { data, error } = await supabase
        .from('clients')
        .select('id, company_name')
        .eq('is_deleted', false)
        .ilike('company_name', `%${debouncedClientSearch}%`)
        .order('company_name')
        .limit(15);
      if (error) throw error;
      return data;
    },
  });

  // Product search for items
  const [activeProductSearch, setActiveProductSearch] = useState('');
  const debouncedProductSearch = useDebouncedValue(activeProductSearch, 300);
  const { data: productResults = [] } = useQuery({
    queryKey: ['compras_product_search', debouncedProductSearch],
    enabled: debouncedProductSearch.length >= 2,
    queryFn: async () => {
      const { data, error } = await supabase
        .from('products')
        .select('id, name, sku')
        .eq('active', true)
        .or(`name.ilike.%${debouncedProductSearch}%,sku.ilike.%${debouncedProductSearch}%`)
        .order('name')
        .limit(10);
      if (error) throw error;
      return data;
    },
  });

  const addItem = () => setItens([...itens, emptyItem()]);
  const removeItem = (idx: number) => setItens(itens.filter((_, i) => i !== idx));

  const selectProduct = (idx: number, product: { id: string; name: string; sku: string | null }) => {
    const copy = [...itens];
    copy[idx] = {
      ...copy[idx],
      descricao: product.name,
      produto_id: product.id,
      produtoSearch: product.name,
      showProdutoResults: false,
    };
    setItens(copy);
    setActiveProductSearch('');
  };

  const handleSubmit = async () => {
    const nomes = itens.filter(i => i.descricao.trim()).map(i => i.descricao.trim());
    const tituloFinal = titulo.trim() || nomes.join(', ');
    if (!tituloFinal) return;

    const solicitacao = await create.mutateAsync({
      titulo: tituloFinal,
      prioridade,
      // CRM client ID (base mode)
      cliente_id: clienteMode === 'base' ? selectedClientId || undefined : undefined,
      // Manual client name
      client_name_manual: clienteMode === 'manual' ? clienteManual.trim() || undefined : undefined,
      // Snapshot for display
      client_name_snapshot: clienteMode === 'base' && selectedClientId
        ? clientSearch
        : clienteMode === 'manual' ? clienteManual.trim() || undefined : undefined,
      requested_response_due_at: prazoResposta ? new Date(prazoResposta).toISOString() : undefined,
    });

    const validItens = itens.filter(i => i.descricao.trim());
    for (const item of validItens) {
      await addItemMutation.mutateAsync({
        solicitacao_id: solicitacao.id,
        descricao_livre: item.descricao.trim(),
        produto_id: item.produto_id || null,
        quantidade: Number(item.quantidade) || 1,
        unidade: item.unidade,
        observacoes_item: item.observacoes.trim() || null,
        imagem_url: item.anexos.length > 0 ? item.anexos[0] : null,
      });
    }

    // Reset form
    setTitulo('');
    setPrioridade('NORMAL');
    setClienteMode('base');
    setClienteManual('');
    setSelectedClientId(null);
    setClientSearch('');
    setPrazoResposta('');
    setItens([emptyItem()]);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[640px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-lg font-bold">Nova Solicitação de Compra</DialogTitle>
        </DialogHeader>

        <div className="space-y-4 pt-1">
          {/* Título */}
          <div className="space-y-1">
            <Label className="text-sm font-medium">Título <span className="text-muted-foreground font-normal">(opcional se tiver item)</span></Label>
            <Input value={titulo} onChange={(e) => setTitulo(e.target.value)} placeholder="Ex: Toner Brother TN-2370 p/ Cliente X" />
          </div>

          {/* Prioridade */}
          <div className="space-y-1">
            <Label className="text-sm font-medium">Prioridade</Label>
            <Select value={prioridade} onValueChange={setPrioridade}>
              <SelectTrigger className="w-full sm:w-48"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="NORMAL">Normal</SelectItem>
                <SelectItem value="URGENTE">Urgente</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Cliente — BASE POR PADRÃO */}
          <div className="space-y-1">
            <div className="flex items-center justify-between">
              <Label className="text-sm font-medium">Cliente</Label>
              {clienteMode === 'base' ? (
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-6 text-[11px] text-muted-foreground gap-1 px-2"
                  onClick={() => {
                    setClienteMode('manual');
                    setSelectedClientId(null);
                    setClientSearch('');
                  }}
                >
                  <Keyboard className="h-3 w-3" />
                  Digitar manualmente
                </Button>
              ) : (
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-6 text-[11px] text-primary gap-1 px-2"
                  onClick={() => {
                    setClienteMode('base');
                    setClienteManual('');
                  }}
                >
                  <Search className="h-3 w-3" />
                  Selecionar da base
                </Button>
              )}
            </div>

            {clienteMode === 'base' ? (
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  value={clientSearch}
                  onChange={(e) => { setClientSearch(e.target.value); setSelectedClientId(null); setShowClientResults(true); }}
                  onFocus={() => setShowClientResults(true)}
                  placeholder="Buscar cliente na base..."
                  className="pl-9"
                  autoFocus
                />
                {showClientResults && clientResults.length > 0 && !selectedClientId && (
                  <div className="absolute z-50 w-full mt-1 bg-popover border rounded-md shadow-md max-h-48 overflow-y-auto">
                    {clientResults.map((c: any) => (
                      <button
                        key={c.id}
                        className="w-full text-left px-3 py-2 text-sm hover:bg-accent transition-colors"
                        onClick={() => { setSelectedClientId(c.id); setClientSearch(c.company_name); setShowClientResults(false); }}
                      >
                        {c.company_name}
                      </button>
                    ))}
                  </div>
                )}
                {selectedClientId && <p className="text-xs text-primary mt-1">✓ Cliente selecionado da base</p>}
              </div>
            ) : (
              <Input value={clienteManual} onChange={(e) => setClienteManual(e.target.value)} placeholder="Ex: SIQUEIRA / CONSTRUTORA XYZ" />
            )}
          </div>

          {/* Prazo para Resposta */}
          <div className="space-y-1">
            <Label className="text-sm font-medium">Prazo para Resposta do Comprador</Label>
            <Input type="datetime-local" value={prazoResposta} onChange={(e) => setPrazoResposta(e.target.value)} />
            <p className="text-xs text-muted-foreground">Quando espera retorno do comprador (SLA)</p>
          </div>

          {/* Itens */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label className="text-sm font-bold">Itens Solicitados</Label>
              <Button variant="outline" size="sm" className="gap-1.5 text-xs" onClick={addItem}>
                <Plus className="h-3.5 w-3.5" /> Adicionar Item
              </Button>
            </div>

            {itens.map((item, idx) => (
              <div key={idx} className="rounded-lg border p-3 space-y-2 relative">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-muted-foreground">Item {idx + 1}</span>
                  {itens.length > 1 && (
                    <Button variant="ghost" size="icon" className="h-6 w-6 text-muted-foreground hover:text-destructive" onClick={() => removeItem(idx)}>
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  )}
                </div>

                {/* Product search — atomic update */}
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    value={item.produto_id ? item.descricao : item.produtoSearch}
                    onChange={(e) => {
                      const val = e.target.value;
                      const copy = [...itens];
                      copy[idx] = {
                        ...copy[idx],
                        produtoSearch: val,
                        descricao: val,
                        produto_id: null,
                        showProdutoResults: true,
                      };
                      setItens(copy);
                      setActiveProductSearch(val);
                    }}
                    onFocus={() => {
                      const copy = [...itens];
                      copy[idx] = { ...copy[idx], showProdutoResults: true };
                      setItens(copy);
                      setActiveProductSearch(item.produtoSearch || item.descricao);
                    }}
                    placeholder="Buscar produto ou digitar descrição livre..."
                    className="pl-9"
                  />
                  {item.showProdutoResults && productResults.length > 0 && !item.produto_id && (
                    <div className="absolute z-50 w-full mt-1 bg-popover border rounded-md shadow-md max-h-40 overflow-y-auto">
                      {productResults.map((p: any) => (
                        <button
                          key={p.id}
                          className="w-full text-left px-3 py-2 text-sm hover:bg-accent transition-colors"
                          onClick={() => selectProduct(idx, p)}
                        >
                          <span>{p.name}</span>
                          {p.sku && <span className="text-xs text-muted-foreground ml-2">({p.sku})</span>}
                        </button>
                      ))}
                    </div>
                  )}
                  {item.produto_id && <p className="text-xs text-primary mt-0.5">✓ Produto vinculado</p>}
                </div>

                <div className="flex gap-2">
                  <div className="w-20">
                    <Input
                      type="number"
                      value={item.quantidade}
                      onChange={(e) => {
                        const copy = [...itens];
                        copy[idx] = { ...copy[idx], quantidade: e.target.value };
                        setItens(copy);
                      }}
                      placeholder="Qtd"
                      min="1"
                    />
                  </div>
                  <div className="w-28">
                    <Select
                      value={item.unidade}
                      onValueChange={(v) => {
                        const copy = [...itens];
                        copy[idx] = { ...copy[idx], unidade: v };
                        setItens(copy);
                      }}
                    >
                      <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Unidade">Unidade</SelectItem>
                        <SelectItem value="Caixa">Caixa</SelectItem>
                        <SelectItem value="Pacote">Pacote</SelectItem>
                        <SelectItem value="Kg">Kg</SelectItem>
                        <SelectItem value="Metro">Metro</SelectItem>
                        <SelectItem value="Litro">Litro</SelectItem>
                        <SelectItem value="Resma">Resma</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <AttachmentTextarea
                  value={item.observacoes}
                  onChange={(v) => {
                    const copy = [...itens];
                    copy[idx] = { ...copy[idx], observacoes: v };
                    setItens(copy);
                  }}
                  anexos={item.anexos}
                  onAnexosChange={(urls) => {
                    const copy = [...itens];
                    copy[idx] = { ...copy[idx], anexos: urls };
                    setItens(copy);
                  }}
                  placeholder="Marca, modelo, observações..."
                />
              </div>
            ))}
          </div>

          {/* Actions */}
          <div className="flex justify-end gap-2 pt-2 border-t">
            <Button variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
            <Button onClick={handleSubmit} disabled={create.isPending}>
              {create.isPending ? 'Criando...' : 'Criar Solicitação'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
