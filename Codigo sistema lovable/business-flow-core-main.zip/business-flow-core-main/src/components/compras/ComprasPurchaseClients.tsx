import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Search, Users, Pencil } from 'lucide-react';
import { useAllPurchaseClients, useSavePurchaseClient } from '@/hooks/useComprasData';

export function ComprasPurchaseClients() {
  const { data: clients = [], isLoading } = useAllPurchaseClients();
  const save = useSavePurchaseClient();
  const [search, setSearch] = useState('');
  const [editing, setEditing] = useState<any>(null);
  const [showModal, setShowModal] = useState(false);

  const filtered = clients.filter((c: any) =>
    c.name?.toLowerCase().includes(search.toLowerCase()) ||
    c.document_number?.includes(search)
  );

  const openNew = () => {
    setEditing({ name: '', document_type: '', document_number: '', notes: '', is_active: true });
    setShowModal(true);
  };

  const openEdit = (c: any) => {
    setEditing({ ...c });
    setShowModal(true);
  };

  const handleSave = async () => {
    if (!editing?.name?.trim()) return;
    await save.mutateAsync(editing);
    setShowModal(false);
    setEditing(null);
  };

  return (
    <div className="space-y-4">
      <div className="flex gap-3 items-center">
        <div className="relative flex-1 max-w-xs">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Buscar clientes..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9" />
        </div>
        <Button size="sm" onClick={openNew}>
          <Plus className="h-4 w-4 mr-1" /> Novo Cliente
        </Button>
      </div>

      {isLoading ? (
        <div className="flex justify-center py-12">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-12">
          <Users className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
          <p className="text-sm text-muted-foreground">Nenhum cliente cadastrado na base de compras.</p>
          <p className="text-xs text-muted-foreground mt-1">Cadastre clientes exclusivos do módulo de compras aqui.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {filtered.map((c: any) => (
            <Card key={c.id} className="cursor-pointer hover:border-primary/40 transition-colors" onClick={() => openEdit(c)}>
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <div className="min-w-0">
                    <p className="font-medium text-sm truncate">{c.name}</p>
                    {c.document_number && (
                      <p className="text-xs text-muted-foreground mt-0.5">
                        {c.document_type || 'Doc'}: {c.document_number}
                      </p>
                    )}
                    <p className="text-xs text-muted-foreground mt-0.5">{c.purchase_count} compras</p>
                  </div>
                  <Badge variant={c.is_active ? 'default' : 'secondary'} className="text-[10px] ml-2">
                    {c.is_active ? 'Ativo' : 'Inativo'}
                  </Badge>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={showModal} onOpenChange={setShowModal}>
        <DialogContent className="sm:max-w-[450px]">
          <DialogHeader>
            <DialogTitle>{editing?.id ? 'Editar Cliente' : 'Novo Cliente (Compras)'}</DialogTitle>
          </DialogHeader>
          {editing && (
            <div className="space-y-3">
              <div>
                <Label>Nome *</Label>
                <Input value={editing.name} onChange={(e) => setEditing({ ...editing, name: e.target.value })} placeholder="Nome ou razão social" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label>Tipo Documento</Label>
                  <Select value={editing.document_type || ''} onValueChange={(v) => setEditing({ ...editing, document_type: v })}>
                    <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="CPF">CPF</SelectItem>
                      <SelectItem value="CNPJ">CNPJ</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Número</Label>
                  <Input value={editing.document_number || ''} onChange={(e) => setEditing({ ...editing, document_number: e.target.value })} placeholder="CPF ou CNPJ" />
                </div>
              </div>
              <div>
                <Label>Observações</Label>
                <Textarea value={editing.notes || ''} onChange={(e) => setEditing({ ...editing, notes: e.target.value })} rows={2} />
              </div>
              <div className="flex items-center gap-2">
                <Label>Ativo</Label>
                <input type="checkbox" checked={editing.is_active} onChange={(e) => setEditing({ ...editing, is_active: e.target.checked })} />
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <Button variant="outline" onClick={() => setShowModal(false)}>Cancelar</Button>
                <Button onClick={handleSave} disabled={!editing.name?.trim() || save.isPending}>
                  {save.isPending ? 'Salvando...' : 'Salvar'}
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
