import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ClipboardList, Search, Truck, CheckCircle2, Clock, BarChart3, Package } from 'lucide-react';
import { useComprasRelatorios, useEntregueReport, STATUS_LABELS } from '@/hooks/useComprasData';
import { formatCurrency } from '@/lib/utils';
import { format } from 'date-fns';

export function ComprasRelatoriosTab() {
  const [dias, setDias] = useState(30);
  const { data, isLoading } = useComprasRelatorios(dias);
  const { data: entregues = [], isLoading: loadingEntregues } = useEntregueReport(dias);

  const solicitacoes = data?.solicitacoes || [];
  const compras = data?.compras || [];

  const pendentes = solicitacoes.filter((s: any) => !['ENTREGUE', 'CANCELADO'].includes(s.status));
  const finalizados = solicitacoes.filter((s: any) => s.status === 'ENTREGUE');

  const statusCounts: Record<string, number> = {};
  solicitacoes.forEach((s: any) => {
    statusCounts[s.status] = (statusCounts[s.status] || 0) + 1;
  });

  const fornecedorMap: Record<string, { name: string; total: number; count: number }> = {};
  compras.forEach((c: any) => {
    const name = (c.fornecedor as any)?.razao_social || 'Desconhecido';
    if (!fornecedorMap[c.fornecedor_id]) fornecedorMap[c.fornecedor_id] = { name, total: 0, count: 0 };
    fornecedorMap[c.fornecedor_id].total += Number(c.valor_total) || 0;
    fornecedorMap[c.fornecedor_id].count += 1;
  });
  const topFornecedores = Object.values(fornecedorMap).sort((a, b) => b.total - a.total).slice(0, 10);

  const tempos = solicitacoes
    .filter((s: any) => s.data_finalizacao && s.data_solicitacao)
    .map((s: any) => (new Date(s.data_finalizacao).getTime() - new Date(s.data_solicitacao).getTime()) / (1000 * 60 * 60 * 24));
  const tempoMedio = tempos.length > 0 ? (tempos.reduce((a: number, b: number) => a + b, 0) / tempos.length).toFixed(1) : '-';

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">Relatórios de Compras</h3>
        <Select value={String(dias)} onValueChange={(v) => setDias(Number(v))}>
          <SelectTrigger className="w-[150px]"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="30">Últimos 30 dias</SelectItem>
            <SelectItem value="90">Últimos 90 dias</SelectItem>
            <SelectItem value="180">Últimos 180 dias</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {isLoading ? (
        <div className="flex justify-center py-12">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
        </div>
      ) : (
        <>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <Card>
              <CardContent className="p-4 text-center">
                <ClipboardList className="h-8 w-8 text-orange-500 mx-auto mb-1" />
                <p className="text-2xl font-bold">{pendentes.length}</p>
                <p className="text-xs text-muted-foreground">Pendentes</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 text-center">
                <CheckCircle2 className="h-8 w-8 text-primary mx-auto mb-1" />
                <p className="text-2xl font-bold">{finalizados.length}</p>
                <p className="text-xs text-muted-foreground">Finalizados</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 text-center">
                <Clock className="h-8 w-8 text-muted-foreground mx-auto mb-1" />
                <p className="text-2xl font-bold">{tempoMedio}d</p>
                <p className="text-xs text-muted-foreground">Tempo Médio</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 text-center">
                <BarChart3 className="h-8 w-8 text-primary mx-auto mb-1" />
                <p className="text-2xl font-bold">{solicitacoes.length}</p>
                <p className="text-xs text-muted-foreground">Total Período</p>
              </CardContent>
            </Card>
          </div>

          {Object.keys(statusCounts).length > 0 && (
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">Distribuição por Status</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {Object.entries(statusCounts).map(([status, count]) => (
                    <Badge key={status} variant="outline" className="text-xs gap-1">
                      {STATUS_LABELS[status] || status}: <span className="font-bold">{count}</span>
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {topFornecedores.length > 0 && (
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">Top Fornecedores por Valor</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {topFornecedores.map((f, i) => (
                    <div key={i} className="flex items-center justify-between text-sm">
                      <span>{f.name}</span>
                      <div className="flex items-center gap-3">
                        <span className="text-muted-foreground">{f.count} compras</span>
                        <span className="font-medium">{formatCurrency(f.total)}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Detailed ENTREGUE report */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2">
                <Package className="h-4 w-4" />
                Pedidos Entregues no Período
              </CardTitle>
            </CardHeader>
            <CardContent>
              {loadingEntregues ? (
                <div className="flex justify-center py-6">
                  <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary" />
                </div>
              ) : entregues.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-4">Nenhum pedido entregue no período.</p>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b text-left text-muted-foreground">
                        <th className="pb-2 pr-3 font-medium">Data Entrega</th>
                        <th className="pb-2 pr-3 font-medium">Título</th>
                        <th className="pb-2 pr-3 font-medium">Cliente</th>
                        <th className="pb-2 pr-3 font-medium">Solicitante</th>
                        <th className="pb-2 pr-3 font-medium">Itens</th>
                        <th className="pb-2 pr-3 font-medium text-right">Valor Total</th>
                      </tr>
                    </thead>
                    <tbody>
                      {entregues.map((s: any) => {
                        const itens = s.solicitacao_itens || [];
                        const valorTotal = itens.reduce((sum: number, i: any) => sum + ((Number(i.preco_cotado) || 0) * (Number(i.quantidade) || 1)), 0);
                        return (
                          <tr key={s.id} className="border-b last:border-0">
                            <td className="py-2 pr-3 whitespace-nowrap">
                              {s.data_entrega_cliente ? format(new Date(s.data_entrega_cliente), 'dd/MM/yyyy') : '-'}
                            </td>
                            <td className="py-2 pr-3 font-medium">{s.titulo}</td>
                            <td className="py-2 pr-3">{s.client_name_snapshot || '-'}</td>
                            <td className="py-2 pr-3">{s.solicitante?.name || '-'}</td>
                            <td className="py-2 pr-3">{itens.length}</td>
                            <td className="py-2 pr-3 text-right font-medium">{valorTotal > 0 ? formatCurrency(valorTotal) : '-'}</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}
