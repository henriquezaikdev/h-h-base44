import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle
} from '@/components/ui/alert-dialog';
import {
  AlertTriangle, Package, Trash2, Plus, Send, CheckCircle2, Pencil, Save, Search, X,
  Clock, Timer, FileCheck, ShoppingCart, MessageSquare
} from 'lucide-react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import {
  useSolicitacaoItens, useAddSolicitacaoItem, useDeleteSolicitacaoItem,
  useCotacoes, useCreateCotacao,
  usePurchaseEvents, useAddEvent,
  useChangeStatus, useFornecedores, useDeleteSolicitacao,
  STATUS_LABELS,
} from '@/hooks/useComprasData';
import { formatCurrency } from '@/lib/utils';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { toast } from 'sonner';

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  solicitacaoId: string;
}

// Valid transitions per status
const VALID_ACTIONS: Record<string, { label: string; nextStatus: string; icon: any; variant?: any }[]> = {
  NOVA_SOLICITACAO: [
    { label: 'Enviar p/ Comprador', nextStatus: 'AGUARDANDO_COMPRADOR', icon: Send },
  ],
  AGUARDANDO_COMPRADOR: [
    { label: 'Iniciar Cotação', nextStatus: 'EM_COTACAO', icon: Search },
  ],
  EM_COTACAO: [
    { label: 'Enviar p/ Aprovação', nextStatus: 'AGUARDANDO_APROVACAO_SOLICITANTE', icon: FileCheck },
  ],
  AGUARDANDO_APROVACAO_SOLICITANTE: [
    { label: 'Aprovar', nextStatus: 'APROVADA_PARA_COMPRAR', icon: CheckCircle2 },
    { label: 'Pedir Ajuste', nextStatus: 'EM_COTACAO', icon: X, variant: 'outline' },
  ],
  APROVADA_PARA_COMPRAR: [
    { label: 'Iniciar Compra', nextStatus: 'EM_COMPRA_FORNECEDOR', icon: ShoppingCart },
  ],
  EM_COMPRA_FORNECEDOR: [
    { label: 'Aguardando Entrega', nextStatus: 'AGUARDANDO_ENTREGA_FORNECEDOR', icon: Package },
  ],
  AGUARDANDO_ENTREGA_FORNECEDOR: [
    { label: 'Marcar Recebido', nextStatus: 'RECEBIDO', icon: CheckCircle2 },
  ],
  RECEBIDO: [
    { label: 'Entregue ao Cliente', nextStatus: 'ENTREGUE', icon: CheckCircle2 },
  ],
};

export function ComprasDetailModal({ open, onOpenChange, solicitacaoId }: Props) {
  const { seller } = useAuth();
  const qc = useQueryClient();
  const [activeTab, setActiveTab] = useState('itens');
  const [comment, setComment] = useState('');
  const [showCancelForm, setShowCancelForm] = useState(false);
  const [motivoCancelamento, setMotivoCancelamento] = useState('');
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  // Edit mode
  const [isEditing, setIsEditing] = useState(false);
  const [editTitulo, setEditTitulo] = useState('');
  const [editPrioridade, setEditPrioridade] = useState('');
  const [editClienteMode, setEditClienteMode] = useState<'manual' | 'base'>('manual');
  const [editClienteManual, setEditClienteManual] = useState('');
  const [editClientSearch, setEditClientSearch] = useState('');
  const [editSelectedClientId, setEditSelectedClientId] = useState<string | null>(null);
  const [editShowClientResults, setEditShowClientResults] = useState(false);
  const [editPrazoResposta, setEditPrazoResposta] = useState('');

  // Item form with product search
  const [itemDesc, setItemDesc] = useState('');
  const [itemQtd, setItemQtd] = useState('1');
  const [itemProductId, setItemProductId] = useState<string | null>(null);
  const [itemProductSearch, setItemProductSearch] = useState('');
  const [showItemProductResults, setShowItemProductResults] = useState(false);

  // ETA form
  const [etaDate, setEtaDate] = useState('');

  // Customer due date form
  const [customerDue, setCustomerDue] = useState('');

  const [cotFornecedorId, setCotFornecedorId] = useState('');

  // Debounced searches
  const [debouncedClientSearch, setDebouncedClientSearch] = useState('');
  const [debouncedProductSearch, setDebouncedProductSearch] = useState('');

  useEffect(() => {
    const t = setTimeout(() => setDebouncedClientSearch(editClientSearch), 300);
    return () => clearTimeout(t);
  }, [editClientSearch]);

  useEffect(() => {
    const t = setTimeout(() => setDebouncedProductSearch(itemProductSearch), 300);
    return () => clearTimeout(t);
  }, [itemProductSearch]);

  // Client search for edit mode
  const { data: editClientResults = [] } = useQuery({
    queryKey: ['compras_detail_client_search', debouncedClientSearch],
    enabled: editClienteMode === 'base' && debouncedClientSearch.length >= 2,
    queryFn: async () => {
      const { data, error } = await supabase
        .from('clients')
        .select('id, company_name')
        .eq('is_deleted', false)
        .ilike('company_name', `%${debouncedClientSearch}%`)
        .order('company_name')
        .limit(15);
      if (error) throw error;
      return data;
    },
  });

  // Product search for adding items
  const { data: productResults = [] } = useQuery({
    queryKey: ['compras_detail_product_search', debouncedProductSearch],
    enabled: debouncedProductSearch.length >= 2,
    queryFn: async () => {
      const { data, error } = await supabase
        .from('products')
        .select('id, name, sku')
        .eq('active', true)
        .or(`name.ilike.%${debouncedProductSearch}%,sku.ilike.%${debouncedProductSearch}%`)
        .order('name')
        .limit(10);
      if (error) throw error;
      return data;
    },
  });
  const { data: sol, refetch: refetchSol } = useQuery({
    queryKey: ['solicitacao_detail', solicitacaoId],
    enabled: !!solicitacaoId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from('solicitacoes_compra')
        .select('*, solicitante:sellers!solicitacoes_compra_solicitante_id_fkey(id, name), comprador:sellers!solicitacoes_compra_comprador_responsavel_id_fkey(id, name)')
        .eq('id', solicitacaoId)
        .single();
      if (error) throw error;
      return data;
    },
  });

  const { data: itens = [] } = useSolicitacaoItens(solicitacaoId);
  const { data: cotacoes = [] } = useCotacoes(solicitacaoId);
  const { data: events = [] } = usePurchaseEvents(solicitacaoId);
  const { data: fornecedores = [] } = useFornecedores();

  const addItem = useAddSolicitacaoItem();
  const deleteItem = useDeleteSolicitacaoItem();
  const createCotacao = useCreateCotacao();
  const changeStatus = useChangeStatus();
  const addEvent = useAddEvent();
  const deleteSolicitacao = useDeleteSolicitacao();

  if (!sol) return null;

  const isEditable = !['ENTREGUE', 'CANCELADO'].includes(sol.status);
  const actions = VALID_ACTIONS[sol.status] || [];

  const invalidateAll = () => {
    qc.invalidateQueries({ queryKey: ['solicitacao_detail', solicitacaoId] });
    qc.invalidateQueries({ queryKey: ['solicitacoes_compra'] });
    qc.invalidateQueries({ queryKey: ['purchase_events', solicitacaoId] });
  };

  const handleStatusChange = async (nextStatus: string) => {
    const extra: Record<string, any> = {};

    // Approval requires customer_due_at
    if (nextStatus === 'APROVADA_PARA_COMPRAR' && customerDue) {
      extra.customer_due_at = new Date(customerDue).toISOString();
    }

    // Setting ETA
    if (nextStatus === 'AGUARDANDO_ENTREGA_FORNECEDOR' && etaDate) {
      extra.supplier_eta_at = new Date(etaDate).toISOString();
    }

    await changeStatus.mutateAsync({ id: solicitacaoId, status: nextStatus, extra });
    invalidateAll();
  };

  const handleSaveEdit = async () => {
    if (!editTitulo.trim()) return;
    const updates: Record<string, any> = {
      titulo: editTitulo.trim(),
      prioridade: editPrioridade,
    };
    // Client update
    if (editClienteMode === 'base' && editSelectedClientId) {
      updates.client_name_snapshot = editClientSearch;
      updates.client_name_manual = null;
    } else if (editClienteMode === 'manual' && editClienteManual.trim()) {
      updates.client_name_snapshot = editClienteManual.trim();
      updates.client_name_manual = editClienteManual.trim();
    }
    // Deadline update
    if (editPrazoResposta) {
      updates.requested_response_due_at = new Date(editPrazoResposta).toISOString();
    }
    const { error } = await supabase
      .from('solicitacoes_compra')
      .update(updates)
      .eq('id', solicitacaoId);
    if (error) { toast.error(error.message); return; }
    toast.success('Atualizado!');
    setIsEditing(false);
    refetchSol();
    qc.invalidateQueries({ queryKey: ['solicitacoes_compra'] });
  };

  const handleAddItem = async () => {
    if (!itemDesc.trim() && !itemProductSearch.trim()) return;
    await addItem.mutateAsync({
      solicitacao_id: solicitacaoId,
      descricao_livre: itemDesc.trim() || itemProductSearch.trim(),
      produto_id: itemProductId || null,
      quantidade: Number(itemQtd) || 1,
    });
    setItemDesc('');
    setItemQtd('1');
    setItemProductId(null);
    setItemProductSearch('');
    setShowItemProductResults(false);
  };

  const handleDelete = async () => {
    await deleteSolicitacao.mutateAsync(solicitacaoId);
    onOpenChange(false);
  };

  const handleCancel = async () => {
    if (!motivoCancelamento.trim()) return;
    await changeStatus.mutateAsync({
      id: solicitacaoId,
      status: 'CANCELADO',
      extra: { cancelado_por: seller?.id, motivo_cancelamento: motivoCancelamento.trim() },
      message: `Cancelado: ${motivoCancelamento.trim()}`,
    });
    onOpenChange(false);
  };

  const handleSendComment = async () => {
    if (!comment.trim()) return;
    await addEvent.mutateAsync({
      request_id: solicitacaoId,
      event_type: 'COMENTARIO',
      message: comment.trim(),
    });
    setComment('');
  };

  const handleSetETA = async () => {
    if (!etaDate) return;
    const { error } = await supabase
      .from('solicitacoes_compra')
      .update({ supplier_eta_at: new Date(etaDate).toISOString() })
      .eq('id', solicitacaoId);
    if (error) { toast.error(error.message); return; }
    await addEvent.mutateAsync({
      request_id: solicitacaoId,
      event_type: 'ETA_DEFINIDO',
      message: `ETA definido: ${format(new Date(etaDate), "dd/MM/yyyy HH:mm", { locale: ptBR })}`,
    });
    toast.success('ETA definido!');
    refetchSol();
    setEtaDate('');
  };

  const handleCreateCotacao = async () => {
    if (!cotFornecedorId) return;
    await createCotacao.mutateAsync({ solicitacao_id: solicitacaoId, fornecedor_id: cotFornecedorId });
    setCotFornecedorId('');
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[800px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center gap-3">
            {sol.prioridade === 'URGENTE' && <AlertTriangle className="h-5 w-5 text-destructive" />}
            <div className="flex-1 min-w-0">
              {isEditing ? (
                <div className="space-y-3">
                  <Input value={editTitulo} onChange={(e) => setEditTitulo(e.target.value)} className="text-lg font-semibold" placeholder="Título" />
                  <div className="flex items-center gap-2">
                    <Select value={editPrioridade} onValueChange={setEditPrioridade}>
                      <SelectTrigger className="w-32 h-8 text-xs"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="NORMAL">Normal</SelectItem>
                        <SelectItem value="URGENTE">Urgente</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  {/* Client edit */}
                  <div className="space-y-1">
                    <div className="flex items-center justify-between">
                      <Label className="text-xs font-medium">Cliente</Label>
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        <span className={editClienteMode === 'manual' ? 'font-semibold text-foreground' : ''}>✏️ Manual</span>
                        <Switch checked={editClienteMode === 'base'} onCheckedChange={(v) => {
                          setEditClienteMode(v ? 'base' : 'manual');
                          setEditSelectedClientId(null);
                          setEditClientSearch('');
                          setEditClienteManual('');
                        }} className="scale-75" />
                        <span className={editClienteMode === 'base' ? 'font-semibold text-foreground' : ''}>👥 Base</span>
                      </div>
                    </div>
                    {editClienteMode === 'manual' ? (
                      <Input value={editClienteManual} onChange={(e) => setEditClienteManual(e.target.value)} placeholder="Nome do cliente" className="h-8 text-xs" />
                    ) : (
                      <div className="relative">
                        <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
                        <Input
                          value={editClientSearch}
                          onChange={(e) => { setEditClientSearch(e.target.value); setEditSelectedClientId(null); setEditShowClientResults(true); }}
                          onFocus={() => setEditShowClientResults(true)}
                          placeholder="Buscar cliente..."
                          className="pl-8 h-8 text-xs"
                        />
                        {editShowClientResults && editClientResults.length > 0 && !editSelectedClientId && (
                          <div className="absolute z-50 w-full mt-1 bg-popover border rounded-md shadow-md max-h-40 overflow-y-auto">
                            {editClientResults.map((c: any) => (
                              <button key={c.id} className="w-full text-left px-3 py-1.5 text-xs hover:bg-accent" onClick={() => {
                                setEditSelectedClientId(c.id);
                                setEditClientSearch(c.company_name);
                                setEditShowClientResults(false);
                              }}>{c.company_name}</button>
                            ))}
                          </div>
                        )}
                        {editSelectedClientId && <p className="text-[10px] text-primary mt-0.5">✓ Selecionado</p>}
                      </div>
                    )}
                  </div>
                  {/* Prazo resposta edit */}
                  <div className="space-y-1">
                    <Label className="text-xs font-medium">Prazo para Resposta</Label>
                    <Input type="datetime-local" value={editPrazoResposta} onChange={(e) => setEditPrazoResposta(e.target.value)} className="h-8 text-xs" />
                  </div>
                  <div className="flex items-center gap-2">
                    <Button size="sm" onClick={handleSaveEdit} className="h-8 gap-1">
                      <Save className="h-3.5 w-3.5" /> Salvar
                    </Button>
                    <Button size="sm" variant="ghost" onClick={() => setIsEditing(false)} className="h-8">
                      <X className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </div>
              ) : (
                <>
                  <div className="flex items-center gap-2">
                    <DialogTitle className="text-lg">{sol.titulo}</DialogTitle>
                    {isEditable && (
                      <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => {
                        setEditTitulo(sol.titulo);
                        setEditPrioridade(sol.prioridade);
                        setEditClienteManual(sol.client_name_manual || sol.client_name_snapshot || '');
                        setEditClienteMode(sol.client_name_manual ? 'manual' : 'manual');
                        setEditPrazoResposta(sol.requested_response_due_at ? new Date(sol.requested_response_due_at).toISOString().slice(0, 16) : '');
                        setIsEditing(true);
                      }}>
                        <Pencil className="h-3.5 w-3.5" />
                      </Button>
                    )}
                    {isEditable && (
                      <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive" onClick={() => setShowDeleteConfirm(true)}>
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    )}
                  </div>
                  <div className="flex items-center gap-2 mt-1 text-xs text-muted-foreground flex-wrap">
                    <span>Solicitante: {sol.solicitante?.name}</span>
                    {sol.client_name_snapshot && <><span>•</span><span>Cliente: {sol.client_name_snapshot}</span></>}
                    <span>•</span>
                    <Badge variant="outline" className="text-[10px]">{STATUS_LABELS[sol.status] || sol.status}</Badge>
                  </div>
                </>
              )}
            </div>
          </div>
        </DialogHeader>

        {/* Live Timer */}
        {sol.supplier_eta_at && (
          <LiveTimerBanner eta={sol.supplier_eta_at} />
        )}

        {/* Status Actions */}
        {actions.length > 0 && (
          <div className="flex flex-wrap gap-2 border-b pb-3">
            {actions.map(action => {
              const Icon = action.icon;
              // Special: approval requires customer_due_at
              if (action.nextStatus === 'APROVADA_PARA_COMPRAR') {
                return (
                  <div key={action.nextStatus} className="flex items-center gap-2">
                    <div>
                      <Label className="text-[10px]">Prazo do Cliente</Label>
                      <Input type="datetime-local" value={customerDue} onChange={(e) => setCustomerDue(e.target.value)} className="h-8 text-xs w-48" />
                    </div>
                    <Button size="sm" onClick={() => handleStatusChange(action.nextStatus)} disabled={changeStatus.isPending} className="mt-4">
                      <Icon className="h-4 w-4 mr-1" /> {action.label}
                    </Button>
                  </div>
                );
              }
              // ETA required for AGUARDANDO_ENTREGA
              if (action.nextStatus === 'AGUARDANDO_ENTREGA_FORNECEDOR') {
                return (
                  <div key={action.nextStatus} className="flex items-center gap-2">
                    <div>
                      <Label className="text-[10px]">ETA Fornecedor</Label>
                      <Input type="datetime-local" value={etaDate} onChange={(e) => setEtaDate(e.target.value)} className="h-8 text-xs w-48" />
                    </div>
                    <Button size="sm" onClick={() => handleStatusChange(action.nextStatus)} disabled={changeStatus.isPending || !etaDate} className="mt-4">
                      <Icon className="h-4 w-4 mr-1" /> {action.label}
                    </Button>
                  </div>
                );
              }
              return (
                <Button key={action.nextStatus} size="sm" variant={(action as any).variant || 'default'}
                  onClick={() => handleStatusChange(action.nextStatus)} disabled={changeStatus.isPending}>
                  <Icon className="h-4 w-4 mr-1" /> {action.label}
                </Button>
              );
            })}

            {isEditable && (
              <Button size="sm" variant="destructive" className="ml-auto" onClick={() => setShowCancelForm(!showCancelForm)}>
                Cancelar
              </Button>
            )}
          </div>
        )}

        {/* Cancel form */}
        {showCancelForm && (
          <div className="flex gap-2 items-end border-b pb-3">
            <div className="flex-1">
              <Label className="text-xs">Motivo do cancelamento *</Label>
              <Input value={motivoCancelamento} onChange={(e) => setMotivoCancelamento(e.target.value)} placeholder="Informe o motivo..." />
            </div>
            <Button size="sm" variant="destructive" onClick={handleCancel} disabled={!motivoCancelamento.trim()}>Confirmar</Button>
          </div>
        )}

        {/* ETA setter (if in EM_COMPRA_FORNECEDOR and no ETA yet) */}
        {sol.status === 'EM_COMPRA_FORNECEDOR' && !sol.supplier_eta_at && (
          <div className="flex gap-2 items-end border-b pb-3">
            <div>
              <Label className="text-xs">Definir ETA de Entrega</Label>
              <Input type="datetime-local" value={etaDate} onChange={(e) => setEtaDate(e.target.value)} className="h-8 text-xs" />
            </div>
            <Button size="sm" onClick={handleSetETA} disabled={!etaDate}>
              <Timer className="h-4 w-4 mr-1" /> Definir ETA
            </Button>
          </div>
        )}

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="itens">Itens</TabsTrigger>
            <TabsTrigger value="cotacoes">Cotações</TabsTrigger>
            <TabsTrigger value="timeline">Timeline</TabsTrigger>
            <TabsTrigger value="info">Info</TabsTrigger>
          </TabsList>

          {/* ITENS TAB */}
          <TabsContent value="itens" className="space-y-3">
            {isEditable && (
              <div className="space-y-2">
                <div className="relative flex-1">
                  <Label className="text-xs">Buscar produto ou digitar descrição</Label>
                  <div className="relative">
                    <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
                    <Input
                      value={itemProductId ? itemDesc : itemProductSearch}
                      onChange={(e) => {
                        const val = e.target.value;
                        setItemProductSearch(val);
                        setItemDesc(val);
                        setItemProductId(null);
                        setShowItemProductResults(true);
                      }}
                      onFocus={() => setShowItemProductResults(true)}
                      placeholder="Buscar produto ou digitar descrição livre..."
                      className="pl-8"
                    />
                    {showItemProductResults && productResults.length > 0 && !itemProductId && (
                      <div className="absolute z-50 w-full mt-1 bg-popover border rounded-md shadow-md max-h-40 overflow-y-auto">
                        {productResults.map((p: any) => (
                          <button key={p.id} className="w-full text-left px-3 py-1.5 text-xs hover:bg-accent" onClick={() => {
                            setItemProductId(p.id);
                            setItemDesc(p.name);
                            setItemProductSearch(p.name);
                            setShowItemProductResults(false);
                          }}>
                            <span>{p.name}</span>
                            {p.sku && <span className="text-muted-foreground ml-2">({p.sku})</span>}
                          </button>
                        ))}
                      </div>
                    )}
                    {itemProductId && <p className="text-[10px] text-primary mt-0.5">✓ Produto vinculado</p>}
                  </div>
                </div>
                <div className="flex gap-2 items-end">
                  <div className="w-20">
                    <Label className="text-xs">Qtd</Label>
                    <Input type="number" value={itemQtd} onChange={(e) => setItemQtd(e.target.value)} min="1" />
                  </div>
                  <Button size="sm" onClick={handleAddItem} disabled={addItem.isPending || (!itemDesc.trim() && !itemProductSearch.trim())}>
                    <Plus className="h-4 w-4 mr-1" /> Adicionar
                  </Button>
                </div>
              </div>
            )}
            {itens.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-6">Nenhum item adicionado.</p>
            ) : (
              <div className="space-y-1">
                {itens.map((it: any) => (
                  <div key={it.id} className="flex items-center justify-between p-2 rounded-md bg-muted/50 text-sm">
                    <div className="min-w-0">
                      <span className="font-medium">{it.produto?.name || it.descricao_livre || 'Sem descrição'}</span>
                      {it.unidade && it.unidade !== 'Unidade' && <span className="text-xs text-muted-foreground ml-2">• {it.unidade}</span>}
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="text-muted-foreground text-xs">Qtd: {it.quantidade}</span>
                      {isEditable && (
                        <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => deleteItem.mutate({ id: it.id, solicitacao_id: solicitacaoId })}>
                          <Trash2 className="h-3.5 w-3.5 text-destructive" />
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </TabsContent>

          {/* COTAÇÕES TAB */}
          <TabsContent value="cotacoes" className="space-y-3">
            {isEditable && (
              <div className="flex gap-2 items-end">
                <div className="flex-1">
                  <Label className="text-xs">Fornecedor</Label>
                  <Select value={cotFornecedorId} onValueChange={setCotFornecedorId}>
                    <SelectTrigger><SelectValue placeholder="Selecione..." /></SelectTrigger>
                    <SelectContent>
                      {fornecedores.filter((f: any) => f.ativo).map((f: any) => (
                        <SelectItem key={f.id} value={f.id}>{f.razao_social}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <Button size="sm" onClick={handleCreateCotacao} disabled={!cotFornecedorId || createCotacao.isPending}>
                  <Plus className="h-4 w-4 mr-1" /> Nova Cotação
                </Button>
              </div>
            )}
            {cotacoes.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-6">Nenhuma cotação criada.</p>
            ) : (
              <div className="space-y-2">
                {cotacoes.map((c: any) => (
                  <div key={c.id} className="p-3 rounded-lg border bg-card">
                    <div className="flex items-center justify-between">
                      <span className="font-medium text-sm">{c.fornecedor?.razao_social || c.fornecedor?.nome_fantasia}</span>
                      <Badge variant="outline" className="text-xs">{c.status_cotacao}</Badge>
                    </div>
                    {c.valor_total && <p className="text-sm mt-1">Total: {formatCurrency(c.valor_total)}</p>}
                    {c.prazo_entrega_dias && <p className="text-xs text-muted-foreground">Prazo: {c.prazo_entrega_dias} dias</p>}
                  </div>
                ))}
              </div>
            )}
          </TabsContent>

          {/* TIMELINE TAB */}
          <TabsContent value="timeline" className="space-y-3">
            <div className="flex gap-2">
              <Input value={comment} onChange={(e) => setComment(e.target.value)} placeholder="Adicionar comentário..." onKeyDown={(e) => e.key === 'Enter' && handleSendComment()} />
              <Button size="icon" onClick={handleSendComment} disabled={!comment.trim()}>
                <Send className="h-4 w-4" />
              </Button>
            </div>
            <div className="space-y-2 max-h-[300px] overflow-y-auto">
              {events.map((ev: any) => (
                <div key={ev.id} className="flex gap-2 text-sm p-2 rounded-lg bg-muted/30">
                  <MessageSquare className="h-4 w-4 text-muted-foreground flex-shrink-0 mt-0.5" />
                  <div className="min-w-0">
                    <p>{ev.message}</p>
                    <p className="text-[10px] text-muted-foreground mt-0.5">
                      {ev.usuario?.name || 'Sistema'} • {format(new Date(ev.created_at), "dd/MM HH:mm", { locale: ptBR })} • {ev.event_type}
                    </p>
                  </div>
                </div>
              ))}
              {events.length === 0 && <p className="text-xs text-muted-foreground text-center py-4">Nenhum evento registrado.</p>}
            </div>
          </TabsContent>

          {/* INFO TAB */}
          <TabsContent value="info" className="space-y-3">
            <div className="grid grid-cols-2 gap-3 text-sm">
              <div><span className="text-muted-foreground">Status:</span> <Badge variant="outline">{STATUS_LABELS[sol.status]}</Badge></div>
              <div><span className="text-muted-foreground">Prioridade:</span> {sol.prioridade}</div>
              <div><span className="text-muted-foreground">Solicitante:</span> {sol.solicitante?.name}</div>
              <div><span className="text-muted-foreground">Comprador:</span> {sol.comprador?.name || 'Não atribuído'}</div>
              {sol.client_name_snapshot && <div><span className="text-muted-foreground">Cliente:</span> {sol.client_name_snapshot}</div>}
              {sol.requested_response_due_at && (
                <div><span className="text-muted-foreground">SLA Resposta:</span> {format(new Date(sol.requested_response_due_at), 'dd/MM/yyyy HH:mm', { locale: ptBR })}</div>
              )}
              {sol.customer_due_at && (
                <div><span className="text-muted-foreground">Prazo Cliente:</span> {format(new Date(sol.customer_due_at), 'dd/MM/yyyy HH:mm', { locale: ptBR })}</div>
              )}
              {sol.supplier_eta_at && (
                <div><span className="text-muted-foreground">ETA Fornecedor:</span> {format(new Date(sol.supplier_eta_at), 'dd/MM/yyyy HH:mm', { locale: ptBR })}</div>
              )}
              <div><span className="text-muted-foreground">Criado em:</span> {format(new Date(sol.created_at), 'dd/MM/yyyy HH:mm', { locale: ptBR })}</div>
            </div>
          </TabsContent>
        </Tabs>

        {/* Delete confirmation */}
        <AlertDialog open={showDeleteConfirm} onOpenChange={setShowDeleteConfirm}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Excluir solicitação?</AlertDialogTitle>
              <AlertDialogDescription>
                Esta ação é irreversível. Todos os itens, cotações e eventos serão removidos.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancelar</AlertDialogCancel>
              <AlertDialogAction className="bg-destructive text-destructive-foreground hover:bg-destructive/90" onClick={handleDelete}>
                Excluir
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </DialogContent>
    </Dialog>
  );
}

function LiveTimerBanner({ eta }: { eta: string }) {
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const interval = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(interval);
  }, []);

  const target = new Date(eta).getTime();
  const diff = target - now;
  const isLate = diff < 0;
  const absDiff = Math.abs(diff);
  const days = Math.floor(absDiff / (1000 * 60 * 60 * 24));
  const hours = Math.floor((absDiff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  const minutes = Math.floor((absDiff % (1000 * 60 * 60)) / (1000 * 60));
  const seconds = Math.floor((absDiff % (1000 * 60)) / 1000);

  const timeStr = days > 0
    ? `${days}d ${hours}h ${minutes}m`
    : `${hours}h ${minutes}m ${seconds}s`;

  return (
    <div className={`flex items-center gap-2 text-sm font-mono px-3 py-2 rounded-lg ${
      isLate
        ? 'bg-destructive/10 text-destructive border border-destructive/20'
        : 'bg-primary/10 text-primary border border-primary/20'
    }`}>
      <Timer className="h-4 w-4" />
      {isLate ? (
        <span>⚠️ ATRASADO — +{timeStr} além do prazo</span>
      ) : (
        <span>⏳ ETA: {timeStr} restantes</span>
      )}
    </div>
  );
}
