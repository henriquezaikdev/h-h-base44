import { useState, useMemo } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { RefreshCw, Send, AlertTriangle, Clock, Package, ChevronDown, CheckCircle2 } from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { useAuth } from '@/hooks/useAuth';
import { cn } from '@/lib/utils';
import { EnviarComprasModal } from './EnviarComprasModal';

const PRIORITY_ORDER: Record<string, number> = { URGENTE: 0, ATENCAO: 1, OK: 2 };

function priorityIcon(p: string) {
  if (p === 'URGENTE') return <AlertTriangle className="h-3.5 w-3.5 text-destructive" />;
  if (p === 'ATENCAO') return <Clock className="h-3.5 w-3.5 text-amber-500" />;
  return <CheckCircle2 className="h-3.5 w-3.5 text-emerald-500" />;
}

function priorityVariant(p: string): 'destructive' | 'secondary' | 'default' {
  if (p === 'URGENTE') return 'destructive';
  if (p === 'ATENCAO') return 'secondary';
  return 'default';
}

export function ReposicaoTab() {
  const { seller } = useAuth();
  const queryClient = useQueryClient();
  const [loading, setLoading] = useState(false);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [collapsedCategories, setCollapsedCategories] = useState<Set<string>>(new Set());
  const [showModal, setShowModal] = useState(false);

  const { data: suggestions = [], isLoading } = useQuery({
    queryKey: ['hh_sugestao_reposicao'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('hh_sugestao_reposicao')
        .select('*');
      if (error) throw error;
      return data || [];
    },
  });

  // Filter out already-sent items for selection purposes
  const selectableSuggestions = useMemo(
    () => suggestions.filter((s: any) => !(s as any).enviado_para_compras),
    [suggestions]
  );

  const groupedByCategory = useMemo(() => {
    const map = new Map<string, any[]>();
    for (const s of suggestions) {
      const cat = s.categoria || 'Sem Categoria';
      if (!map.has(cat)) map.set(cat, []);
      map.get(cat)!.push(s);
    }
    for (const [, items] of map) {
      items.sort((a: any, b: any) => {
        const pa = PRIORITY_ORDER[a.priority] ?? 9;
        const pb = PRIORITY_ORDER[b.priority] ?? 9;
        if (pa !== pb) return pa - pb;
        return (Number(b.daily_avg) || 0) - (Number(a.daily_avg) || 0);
      });
    }
    return Array.from(map.entries()).sort(([a], [b]) => a.localeCompare(b, 'pt-BR'));
  }, [suggestions]);

  const lastGenerated = suggestions.length > 0 ? suggestions[0].generated_at : null;
  const urgentCount = suggestions.filter((s: any) => s.priority === 'URGENTE').length;
  const atencaoCount = suggestions.filter((s: any) => s.priority === 'ATENCAO').length;

  const selectedItems = useMemo(
    () => suggestions.filter((s: any) => selected.has(s.id)),
    [suggestions, selected]
  );

  const handleRefresh = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('hh-gerar-sugestao-reposicao');
      if (error) throw error;
      toast.success(`Sugestões atualizadas: ${data.urgente} urgentes, ${data.atencao} atenção, ${data.ok || 0} OK`);
      queryClient.invalidateQueries({ queryKey: ['hh_sugestao_reposicao'] });
    } catch (err: any) {
      toast.error('Erro ao gerar sugestões: ' + (err.message || 'Erro desconhecido'));
    } finally {
      setLoading(false);
    }
  };

  const toggleSelect = (id: string) => {
    setSelected(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const isItemSelectable = (item: any) =>
    item.priority !== 'OK' && !(item as any).enviado_para_compras;

  const toggleAllCategory = (items: any[]) => {
    const selectableIds = items.filter(isItemSelectable).map((i: any) => i.id);
    const allSelected = selectableIds.length > 0 && selectableIds.every(id => selected.has(id));
    setSelected(prev => {
      const next = new Set(prev);
      selectableIds.forEach(id => allSelected ? next.delete(id) : next.add(id));
      return next;
    });
  };

  const toggleCollapseCategory = (cat: string) => {
    setCollapsedCategories(prev => {
      const next = new Set(prev);
      if (next.has(cat)) next.delete(cat); else next.add(cat);
      return next;
    });
  };

  return (
    <div className="space-y-4 pb-20">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-3">
          <Package className="h-5 w-5 text-primary" />
          <div>
            <h2 className="text-lg font-semibold">Sugestão de Reposição</h2>
            <p className="text-sm text-muted-foreground">
              Análise inteligente de cobertura de estoque
              {lastGenerated && (
                <span className="ml-2 text-xs">
                  • Atualizado em {format(new Date(lastGenerated), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}
                </span>
              )}
              {suggestions.length > 0 && (
                <span className="ml-2 text-xs">
                  • {urgentCount} urgentes, {atencaoCount} atenção
                </span>
              )}
            </p>
          </div>
        </div>
        <Button variant="outline" onClick={handleRefresh} disabled={loading} className="gap-2">
          <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
          {loading ? 'Calculando...' : '🔄 Atualizar Sugestões'}
        </Button>
      </div>

      {/* Content */}
      {isLoading ? (
        <div className="flex justify-center py-16">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
        </div>
      ) : suggestions.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center text-muted-foreground">
            <Package className="h-10 w-10 mx-auto mb-3 opacity-40" />
            <p>Nenhuma sugestão de reposição.</p>
            <p className="text-sm mt-1">Clique em "Atualizar Sugestões" para gerar a análise.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {groupedByCategory.map(([category, items]) => {
            const collapsed = collapsedCategories.has(category);
            const catUrgent = items.filter((i: any) => i.priority === 'URGENTE').length;
            const catAtencao = items.filter((i: any) => i.priority === 'ATENCAO').length;
            const selectableItems = items.filter(isItemSelectable);
            const allSelected = selectableItems.length > 0 && selectableItems.every((i: any) => selected.has(i.id));

            return (
              <Card key={category} className="overflow-hidden">
                <CardHeader className="pb-0 pt-3 px-4">
                  <div className="flex items-center justify-between">
                    <button
                      onClick={() => toggleCollapseCategory(category)}
                      className="flex items-center gap-2 text-left hover:opacity-80 transition-opacity"
                    >
                      <ChevronDown className={cn('h-4 w-4 text-muted-foreground transition-transform', !collapsed && 'rotate-180')} />
                      <CardTitle className="text-sm font-semibold">{category}</CardTitle>
                      <Badge variant="outline" className="text-[10px]">{items.length}</Badge>
                      {catUrgent > 0 && <Badge variant="destructive" className="text-[10px]">{catUrgent} urgente</Badge>}
                      {catAtencao > 0 && <Badge variant="secondary" className="text-[10px]">{catAtencao} atenção</Badge>}
                    </button>
                    {!collapsed && selectableItems.length > 0 && (
                      <Button variant="ghost" size="sm" className="text-xs h-7" onClick={() => toggleAllCategory(items)}>
                        {allSelected ? 'Desmarcar' : 'Selecionar todos'}
                      </Button>
                    )}
                  </div>
                </CardHeader>

                {!collapsed && (
                  <CardContent className="p-0 pt-2">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="w-10"></TableHead>
                          <TableHead>SKU</TableHead>
                          <TableHead>Produto</TableHead>
                          <TableHead className="text-right">Estoque</TableHead>
                          <TableHead className="text-right">Saída/Mês</TableHead>
                          <TableHead className="text-right">Cobertura</TableHead>
                          <TableHead className="text-right">Prazo Forn.</TableHead>
                          <TableHead className="text-right">Qtd Sugerida</TableHead>
                          <TableHead>Status</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {items.map((item: any) => {
                          const monthlyAvg = (Number(item.daily_avg) || 0) * 30;
                          const isOk = item.priority === 'OK';
                          const jáEnviado = !!(item as any).enviado_para_compras;
                          const canSelect = !isOk && !jáEnviado;
                          return (
                            <TableRow key={item.id} className={cn((isOk || jáEnviado) && 'opacity-60')}>
                              <TableCell>
                                {canSelect ? (
                                  <Checkbox
                                    checked={selected.has(item.id)}
                                    onCheckedChange={() => toggleSelect(item.id)}
                                  />
                                ) : (
                                  <span className="block w-4" />
                                )}
                              </TableCell>
                              <TableCell className="font-mono text-xs">{item.sku || '—'}</TableCell>
                              <TableCell className="max-w-[200px] truncate text-sm">{item.product_name}</TableCell>
                              <TableCell className="text-right font-medium">{Number(item.current_stock).toFixed(0)}</TableCell>
                              <TableCell className="text-right">{monthlyAvg.toFixed(0)}</TableCell>
                              <TableCell className="text-right">
                                <span className={cn(
                                  item.priority === 'URGENTE' && 'text-destructive font-bold',
                                  item.priority === 'ATENCAO' && 'text-amber-600 font-medium',
                                  item.priority === 'OK' && 'text-emerald-600',
                                )}>
                                  {Number(item.coverage_days).toFixed(0)}d
                                </span>
                              </TableCell>
                              <TableCell className="text-right">{item.lead_time_days}d</TableCell>
                              <TableCell className="text-right font-bold">{item.suggested_qty || '—'}</TableCell>
                              <TableCell>
                                {jáEnviado ? (
                                  <Badge variant="outline" className="text-[10px] gap-1 text-primary border-primary/30">
                                    <CheckCircle2 className="h-3 w-3" />
                                    Enviado
                                  </Badge>
                                ) : (
                                  <Badge variant={priorityVariant(item.priority)} className="text-[10px] gap-1">
                                    {priorityIcon(item.priority)}
                                    {item.priority}
                                  </Badge>
                                )}
                              </TableCell>
                            </TableRow>
                          );
                        })}
                      </TableBody>
                    </Table>
                  </CardContent>
                )}
              </Card>
            );
          })}
        </div>
      )}

      {/* Fixed footer bar */}
      {selected.size > 0 && (
        <div className="fixed bottom-0 left-0 right-0 z-50 border-t bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/80 px-6 py-3">
          <div className="max-w-7xl mx-auto flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Badge variant="secondary" className="text-sm">
                {selected.size} {selected.size === 1 ? 'item selecionado' : 'itens selecionados'}
              </Badge>
              <Button variant="ghost" size="sm" className="text-xs" onClick={() => setSelected(new Set())}>
                Limpar seleção
              </Button>
            </div>
            <Button onClick={() => setShowModal(true)} className="gap-2">
              <Send className="h-4 w-4" />
              Enviar para Compras ({selected.size})
            </Button>
          </div>
        </div>
      )}

      {/* Confirmation modal */}
      <EnviarComprasModal
        open={showModal}
        onOpenChange={setShowModal}
        selectedItems={selectedItems}
        onSuccess={() => setSelected(new Set())}
      />
    </div>
  );
}
