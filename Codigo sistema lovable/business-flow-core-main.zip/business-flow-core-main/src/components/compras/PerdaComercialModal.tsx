import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { AlertTriangle } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { formatCurrency } from '@/lib/utils';

const LOSS_REASONS = [
  'Achou caro',
  'Foi para concorrente',
  'Desistiu da compra',
  'Prazo longo',
  'Outro',
];

interface PerdaComercialModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  solicitacao: any;
  itens: any[];
}

export function PerdaComercialModal({ open, onOpenChange, solicitacao, itens }: PerdaComercialModalProps) {
  const [lostReason, setLostReason] = useState('');
  const [lostValue, setLostValue] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { seller } = useAuth();
  const qc = useQueryClient();

  const handleSubmit = async () => {
    setIsSubmitting(true);
    try {
      const now = new Date().toISOString();

      // Update solicitação status to CANCELADO with loss data
      await supabase.from('solicitacoes_compra').update({
        status: 'CANCELADO',
        cancelado_em: now,
        cancelado_por: seller?.id,
        lost_reason: lostReason || null,
        lost_value: lostValue ? Number(lostValue) : null,
      } as any).eq('id', solicitacao.id);

      // Log purchase event
      await supabase.from('purchase_events').insert({
        request_id: solicitacao.id,
        event_type: 'PERDA_COMERCIAL',
        message: `Perda comercial registrada${lostReason ? `: ${lostReason}` : ''}`,
        created_by: seller?.id,
        meta: {
          motivo: lostReason || null,
          valor_aceito_cliente: lostValue ? Number(lostValue) : null,
          itens_count: itens.length,
        },
      });

      qc.invalidateQueries({ queryKey: ['solicitacoes_compra'] });
      qc.invalidateQueries({ queryKey: ['solicitacao_detail'] });
      toast.success('Perda comercial registrada');
      onOpenChange(false);
      setLostReason('');
      setLostValue('');
    } catch (err: any) {
      toast.error('Erro ao registrar perda: ' + err.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-destructive" />
            Registrar Perda Comercial
          </DialogTitle>
          <DialogDescription>
            Registre a perda para a solicitação "{solicitacao?.titulo}"
          </DialogDescription>
        </DialogHeader>

        {/* Items list */}
        {itens.length > 0 && (
          <div className="space-y-1 max-h-32 overflow-y-auto">
            <Label className="text-xs text-muted-foreground">Itens da solicitação:</Label>
            {itens.map((item: any, i: number) => (
              <div key={i} className="flex justify-between text-xs px-2 py-1 bg-muted rounded">
                <span className="truncate flex-1">{item.descricao || item.produto_nome || `Item ${i + 1}`}</span>
                {item.preco_cotado && (
                  <span className="ml-2 font-medium">{formatCurrency(item.preco_cotado)}</span>
                )}
              </div>
            ))}
          </div>
        )}

        <div className="space-y-3">
          <div>
            <Label className="text-sm">Motivo da perda</Label>
            <Select value={lostReason} onValueChange={setLostReason}>
              <SelectTrigger><SelectValue placeholder="Selecione..." /></SelectTrigger>
              <SelectContent>
                {LOSS_REASONS.map(r => (
                  <SelectItem key={r} value={r}>{r}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label className="text-sm">Valor que o cliente aceitou pagar (opcional)</Label>
            <Input
              type="number"
              placeholder="0,00"
              value={lostValue}
              onChange={(e) => setLostValue(e.target.value)}
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
          <Button
            variant="destructive"
            onClick={handleSubmit}
            disabled={isSubmitting}
          >
            {isSubmitting ? 'Registrando...' : 'Registrar Perda'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
