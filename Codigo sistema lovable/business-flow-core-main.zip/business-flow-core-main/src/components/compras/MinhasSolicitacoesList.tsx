import { useState, useMemo } from 'react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Plus, Search, AlertTriangle, CheckCircle2, Package, Clock, Archive,
  ShoppingCart, ClipboardCheck, Calendar, Hash, DollarSign, Trash2
} from 'lucide-react';
import { useSolicitacoes, useChangeStatus, useDeleteSolicitacao, STATUS_LABELS } from '@/hooks/useComprasData';
import { useAuth } from '@/hooks/useAuth';
import { formatDistanceToNow, differenceInDays, format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { formatCurrency } from '@/lib/utils';
import { NovaSolicitacaoModal } from './NovaSolicitacaoModal';
import { ComprasDetailSheet } from './ComprasDetailSheet';

// ── Status visual config ─────────────────────────────────────────────
const STATUS_CONFIG: Record<string, { color: string; border: string; icon: typeof Package; ownerLabel: string }> = {
  NOVA_SOLICITACAO: {
    color: 'bg-blue-50 text-blue-700 dark:bg-blue-950/40 dark:text-blue-400',
    border: 'border-l-blue-500',
    icon: ClipboardCheck,
    ownerLabel: 'Com Compras',
  },
  AGUARDANDO_COMPRADOR: {
    color: 'bg-slate-50 text-slate-600 dark:bg-slate-900/40 dark:text-slate-400',
    border: 'border-l-slate-400',
    icon: Clock,
    ownerLabel: 'Com Compras',
  },
  EM_COTACAO: {
    color: 'bg-amber-50 text-amber-700 dark:bg-amber-950/40 dark:text-amber-400',
    border: 'border-l-amber-500',
    icon: Search,
    ownerLabel: 'Com Compras',
  },
  AGUARDANDO_APROVACAO_SOLICITANTE: {
    color: 'bg-orange-50 text-orange-700 dark:bg-orange-950/40 dark:text-orange-400',
    border: 'border-l-orange-500',
    icon: AlertTriangle,
    ownerLabel: 'Com Você',
  },
  APROVADA_PARA_COMPRAR: {
    color: 'bg-green-50 text-green-700 dark:bg-green-950/40 dark:text-green-400',
    border: 'border-l-green-500',
    icon: CheckCircle2,
    ownerLabel: 'Com Compras',
  },
  EM_COMPRA_FORNECEDOR: {
    color: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400',
    border: 'border-l-emerald-500',
    icon: ShoppingCart,
    ownerLabel: 'Com Fornecedor',
  },
  AGUARDANDO_ENTREGA_FORNECEDOR: {
    color: 'bg-cyan-50 text-cyan-700 dark:bg-cyan-950/40 dark:text-cyan-400',
    border: 'border-l-cyan-500',
    icon: Package,
    ownerLabel: 'Em Trânsito',
  },
  RECEBIDO: {
    color: 'bg-teal-50 text-teal-700 dark:bg-teal-950/40 dark:text-teal-400',
    border: 'border-l-teal-500',
    icon: Package,
    ownerLabel: 'Recebido',
  },
  ENTREGUE: {
    color: 'bg-green-50 text-green-600 dark:bg-green-950/30 dark:text-green-400',
    border: 'border-l-green-400',
    icon: CheckCircle2,
    ownerLabel: 'Entregue',
  },
};

const defaultConfig = {
  color: 'bg-muted text-muted-foreground',
  border: 'border-l-muted-foreground',
  icon: Package,
  ownerLabel: '',
};

// ── Filter tabs ──────────────────────────────────────────────────────
const TABS = [
  { key: 'TUDO', label: 'Tudo', statuses: [] as string[] },
  { key: 'NOVAS', label: 'Novas', statuses: ['NOVA_SOLICITACAO', 'AGUARDANDO_COMPRADOR'] },
  { key: 'EM_COTACAO', label: 'Em Cotação', statuses: ['EM_COTACAO'] },
  { key: 'PARA_APROVAR', label: 'Para Aprovar', statuses: ['AGUARDANDO_APROVACAO_SOLICITANTE'] },
  { key: 'APROVADOS', label: 'Aprovados', statuses: ['APROVADA_PARA_COMPRAR', 'EM_COMPRA_FORNECEDOR', 'AGUARDANDO_ENTREGA_FORNECEDOR', 'RECEBIDO'] },
  { key: 'ENTREGUES', label: 'Entregues', statuses: ['ENTREGUE'] },
  { key: 'ARQUIVO', label: 'Arquivo', statuses: ['__ARCHIVE__'] },
];

export function MinhasSolicitacoesList() {
  const [activeTab, setActiveTab] = useState('TUDO');
  const [searchTerm, setSearchTerm] = useState('');
  const [showNewModal, setShowNewModal] = useState(false);
  const [selected, setSelected] = useState<any>(null);
  const [confirmFinish, setConfirmFinish] = useState<string | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<string | null>(null);
  const { seller, isOwner } = useAuth();
  const changeStatus = useChangeStatus();
  const deleteSolicitacao = useDeleteSolicitacao();

  const { data: allSolicitacoes = [], isLoading } = useSolicitacoes({
    onlySolicitanteId: seller?.id,
  });

  // ── Split active vs archived (7-day rule) ────────────────────────
  const { active, archived } = useMemo(() => {
    const now = new Date();
    const act: any[] = [];
    const arch: any[] = [];

    allSolicitacoes.forEach((s: any) => {
      if (s.status === 'ENTREGUE') {
        const deliveredAt = new Date(s.updated_at || s.created_at);
        const daysSince = differenceInDays(now, deliveredAt);
        if (daysSince > 7) {
          arch.push(s);
          return;
        }
      }
      act.push(s);
    });

    return { active: act, archived: arch };
  }, [allSolicitacoes]);

  // ── Search ───────────────────────────────────────────────────────
  const searched = useMemo(() => {
    const pool = activeTab === 'ARQUIVO' ? archived : active;
    if (!searchTerm) return pool;
    const term = searchTerm.toLowerCase();
    return pool.filter((s: any) =>
      s.titulo?.toLowerCase().includes(term) ||
      s.client_name_snapshot?.toLowerCase().includes(term)
    );
  }, [active, archived, activeTab, searchTerm]);

  // ── Filter by tab ────────────────────────────────────────────────
  const filtered = useMemo(() => {
    if (activeTab === 'TUDO') return searched;
    if (activeTab === 'ARQUIVO') return searched;
    const tab = TABS.find(t => t.key === activeTab);
    if (!tab) return searched;
    return searched.filter((s: any) => tab.statuses.includes(s.status));
  }, [searched, activeTab]);

  // ── Counts for tabs ──────────────────────────────────────────────
  const tabCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    TABS.forEach(tab => {
      if (tab.key === 'TUDO') counts[tab.key] = active.length;
      else if (tab.key === 'ARQUIVO') counts[tab.key] = archived.length;
      else counts[tab.key] = active.filter((s: any) => tab.statuses.includes(s.status)).length;
    });
    return counts;
  }, [active, archived]);

  const pendingApproval = tabCounts['PARA_APROVAR'] || 0;

  return (
    <div className="space-y-4">
      {/* ── Alert: pending approval ─────────────────────────────── */}
      {pendingApproval > 0 && (
        <div className="flex items-center gap-3 rounded-xl border border-orange-200 bg-orange-50 dark:border-orange-800 dark:bg-orange-950/20 px-4 py-3">
          <div className="flex items-center justify-center h-8 w-8 rounded-full bg-orange-100 dark:bg-orange-900/40">
            <AlertTriangle className="h-4 w-4 text-orange-600" />
          </div>
          <div>
            <p className="text-sm font-semibold text-orange-700 dark:text-orange-400">
              {pendingApproval} cotação(ões) aguardando sua aprovação
            </p>
            <p className="text-xs text-orange-600/70 dark:text-orange-400/60">
              Clique na aba "Para Aprovar" para analisar
            </p>
          </div>
        </div>
      )}

      {/* ── Search + Nova ───────────────────────────────────────── */}
      <div className="flex gap-2 items-center">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Buscar por título ou cliente..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-9 h-9"
          />
        </div>
        <Button size="sm" onClick={() => setShowNewModal(true)} className="gap-1.5">
          <Plus className="h-4 w-4" /> Nova Solicitação
        </Button>
      </div>

      {/* ── Filter tabs ─────────────────────────────────────────── */}
      <div className="flex gap-1 flex-wrap border-b pb-2">
        {TABS.map(tab => {
          const count = tabCounts[tab.key] || 0;
          const isActive = activeTab === tab.key;
          const isArchive = tab.key === 'ARQUIVO';
          const hasItems = count > 0;

          return (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                isActive
                  ? 'bg-primary text-primary-foreground shadow-sm'
                  : 'text-muted-foreground hover:bg-muted hover:text-foreground'
              } ${isArchive ? 'ml-auto' : ''}`}
            >
              {isArchive && <Archive className="h-3 w-3" />}
              {tab.key === 'PARA_APROVAR' && hasItems && !isActive && (
                <span className="flex h-2 w-2 rounded-full bg-orange-500 animate-pulse" />
              )}
              {tab.label}
              <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-bold ${
                isActive ? 'bg-primary-foreground/20 text-primary-foreground' : 'bg-muted text-muted-foreground'
              }`}>
                {count}
              </span>
            </button>
          );
        })}
      </div>

      {/* ── Cards list ──────────────────────────────────────────── */}
      {isLoading ? (
        <div className="flex justify-center py-16">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16">
          <Package className="h-10 w-10 text-muted-foreground/30 mx-auto mb-3" />
          <p className="text-sm text-muted-foreground">
            {activeTab === 'ARQUIVO' ? 'Nenhuma solicitação arquivada.' : 'Nenhuma solicitação encontrada.'}
          </p>
        </div>
      ) : (
        <div className="space-y-2">
          {filtered.map((s: any) => (
            <SolicitacaoCard
              key={s.id}
              solicitacao={s}
              onClick={() => setSelected(s)}
              onFinish={() => setConfirmFinish(s.id)}
              onDelete={isOwner ? () => setDeleteTarget(s.id) : undefined}
              isArchived={activeTab === 'ARQUIVO'}
            />
          ))}
        </div>
      )}

      {/* ── Modals ──────────────────────────────────────────────── */}
      <NovaSolicitacaoModal open={showNewModal} onOpenChange={setShowNewModal} />
      {selected && (
        <ComprasDetailSheet
          open={!!selected}
          onOpenChange={(v) => !v && setSelected(null)}
          solicitacaoId={selected.id}
        />
      )}

      <AlertDialog open={!!confirmFinish} onOpenChange={(v) => !v && setConfirmFinish(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Marcar como entregue?</AlertDialogTitle>
            <AlertDialogDescription>
              Confirme que o produto foi entregue ao cliente.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={async () => {
                if (confirmFinish) {
                  await changeStatus.mutateAsync({ id: confirmFinish, status: 'ENTREGUE', message: 'Produto entregue ao cliente' });
                  setConfirmFinish(null);
                }
              }}
            >
              Confirmar Entrega
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Owner-only delete confirmation */}
      <AlertDialog open={!!deleteTarget} onOpenChange={(v) => !v && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Excluir solicitação?</AlertDialogTitle>
            <AlertDialogDescription>
              Esta ação é irreversível. Todos os itens, cotações e eventos desta solicitação serão removidos.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={async () => {
                if (deleteTarget) {
                  await deleteSolicitacao.mutateAsync(deleteTarget);
                  setDeleteTarget(null);
                }
              }}
            >
              Excluir
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// ── Card component ─────────────────────────────────────────────────
function SolicitacaoCard({ solicitacao: s, onClick, onFinish, onDelete, isArchived }: {
  solicitacao: any;
  onClick: () => void;
  onFinish: () => void;
  onDelete?: () => void;
  isArchived: boolean;
}) {
  const cfg = STATUS_CONFIG[s.status] || defaultConfig;
  const StatusIcon = cfg.icon;
  const itemCount = s.solicitacao_itens?.length || 0;

  return (
    <div
      onClick={onClick}
      className={`group relative flex border rounded-xl bg-card cursor-pointer transition-all hover:shadow-md hover:border-primary/30 border-l-[3px] ${cfg.border} ${isArchived ? 'opacity-70' : ''}`}
    >
      <div className="flex-1 p-3.5 min-w-0">
        {/* Top row: client + status */}
        <div className="flex items-start justify-between gap-2 mb-1.5">
          <h3 className="font-semibold text-[13px] text-foreground truncate leading-tight">
            {s.client_name_snapshot || 'Sem cliente'}
          </h3>
          <div className="flex items-center gap-1.5 shrink-0">
            {s.prioridade === 'URGENTE' && (
              <Badge className="text-[9px] px-1.5 py-0 bg-destructive/10 text-destructive border-destructive/20 font-bold uppercase tracking-wider">
                Urgente
              </Badge>
            )}
            {s.process_type === 'ORDEM_DIRETA' && (
              <Badge className="text-[9px] px-1.5 py-0 bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/30 dark:text-emerald-400 dark:border-emerald-800 gap-0.5">
                <ShoppingCart className="h-2.5 w-2.5" /> Direta
              </Badge>
            )}
          </div>
        </div>

        {/* Title */}
        <p className="text-xs text-muted-foreground truncate mb-2.5">{s.titulo}</p>

        {/* Meta row */}
        <div className="flex items-center gap-3 text-[11px] text-muted-foreground">
          <span className="flex items-center gap-1">
            <Calendar className="h-3 w-3" />
            {format(new Date(s.created_at), 'dd/MM/yy')}
          </span>
          <span className="flex items-center gap-1">
            <Hash className="h-3 w-3" />
            {itemCount} {itemCount === 1 ? 'item' : 'itens'}
          </span>
          <span className="text-muted-foreground/50">
            {formatDistanceToNow(new Date(s.updated_at || s.created_at), { addSuffix: true, locale: ptBR })}
          </span>
        </div>
      </div>

      {/* Right side: status + action */}
      <div className="flex flex-col items-end justify-between p-3.5 pl-0 shrink-0">
        <Badge className={`text-[10px] font-semibold px-2 py-0.5 gap-1 border-0 ${cfg.color}`}>
          <StatusIcon className="h-3 w-3" />
          {STATUS_LABELS[s.status] || s.status}
        </Badge>

        {/* Owner indicator */}
        <span className={`text-[10px] font-medium mt-auto ${
          cfg.ownerLabel === 'Com Você'
            ? 'text-orange-600 dark:text-orange-400'
            : 'text-muted-foreground/60'
        }`}>
          {cfg.ownerLabel}
        </span>

        {/* Quick actions */}
        {s.status === 'AGUARDANDO_APROVACAO_SOLICITANTE' && (
          <Button
            size="sm"
            variant="outline"
            className="h-6 text-[10px] gap-1 border-orange-300 text-orange-700 dark:text-orange-400 hover:bg-orange-50 dark:hover:bg-orange-950/30 mt-1"
            onClick={(e) => { e.stopPropagation(); onClick(); }}
          >
            <ClipboardCheck className="h-3 w-3" />
            Analisar
          </Button>
        )}
        {s.status === 'RECEBIDO' && !isArchived && (
          <Button
            size="sm"
            className="h-6 text-[10px] gap-1 mt-1"
            onClick={(e) => { e.stopPropagation(); onFinish(); }}
          >
            <CheckCircle2 className="h-3 w-3" />
            Entregue
          </Button>
        )}
        {/* Owner-only delete */}
        {onDelete && !['ENTREGUE', 'CANCELADO'].includes(s.status) && (
          <Button
            variant="ghost"
            size="sm"
            className="h-6 w-6 p-0 text-muted-foreground hover:text-destructive mt-1"
            onClick={(e) => { e.stopPropagation(); onDelete(); }}
            title="Excluir solicitação"
          >
            <Trash2 className="h-3.5 w-3.5" />
          </Button>
        )}
      </div>
    </div>
  );
}
