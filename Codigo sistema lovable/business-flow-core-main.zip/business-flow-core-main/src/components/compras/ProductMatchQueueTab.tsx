import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Check, Search, Plus, ArrowRight, Loader2, Package, X } from 'lucide-react';
import { toast } from 'sonner';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';

interface QueueItem {
  id: string;
  conta_azul_name: string;
  conta_azul_sku: string | null;
  conta_azul_id: string | null;
  suggested_product_id: string | null;
  suggested_product_name: string | null;
  similarity_score: number;
  status: string;
  reasoning: string | null;
  created_at: string;
}

interface ProductSearchResult {
  id: string;
  name: string;
  sku: string | null;
}

export function ProductMatchQueueTab() {
  const queryClient = useQueryClient();
  const [searchingItemId, setSearchingItemId] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [searchResults, setSearchResults] = useState<ProductSearchResult[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [createDialogItem, setCreateDialogItem] = useState<QueueItem | null>(null);
  const [newProductName, setNewProductName] = useState('');

  const { data: queueItems = [], isLoading } = useQuery({
    queryKey: ['product_match_queue'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('product_match_queue')
        .select('*')
        .eq('status', 'pending')
        .order('created_at', { ascending: false });
      if (error) throw error;
      return (data || []) as QueueItem[];
    },
  });

  const confirmMutation = useMutation({
    mutationFn: async ({ queueId, productId, contaAzulId }: { queueId: string; productId: string; contaAzulId: string | null }) => {
      // Update queue status
      const { error: qErr } = await supabase
        .from('product_match_queue')
        .update({ status: 'confirmed', confirmed_at: new Date().toISOString() })
        .eq('id', queueId);
      if (qErr) throw qErr;

      // Save to learned
      if (contaAzulId) {
        await supabase.from('product_match_learned').upsert(
          { conta_azul_id: contaAzulId, product_id: productId },
          { onConflict: 'conta_azul_id' }
        );
      }
    },
    onSuccess: () => {
      toast.success('Match confirmado e salvo!');
      queryClient.invalidateQueries({ queryKey: ['product_match_queue'] });
      setSearchingItemId(null);
    },
    onError: (err: any) => toast.error(`Erro: ${err.message}`),
  });

  const createNewMutation = useMutation({
    mutationFn: async ({ queueId, name, contaAzulId, contaAzulSku }: { queueId: string; name: string; contaAzulId: string | null; contaAzulSku: string | null }) => {
      // Create product
      const normalizedName = name.toLowerCase().replace(/[^a-z0-9]/g, '');
      const { data: newProduct, error: pErr } = await supabase
        .from('products')
        .insert({ name, normalized_name: normalizedName, sku: contaAzulSku, conta_azul_id: contaAzulId, active: true })
        .select('id')
        .single();
      if (pErr) throw pErr;

      // Update queue
      await supabase
        .from('product_match_queue')
        .update({ status: 'created_new', confirmed_at: new Date().toISOString() })
        .eq('id', queueId);

      // Save to learned
      if (contaAzulId) {
        await supabase.from('product_match_learned').upsert(
          { conta_azul_id: contaAzulId, product_id: newProduct.id },
          { onConflict: 'conta_azul_id' }
        );
      }
    },
    onSuccess: () => {
      toast.success('Produto criado e vinculado!');
      queryClient.invalidateQueries({ queryKey: ['product_match_queue'] });
      setCreateDialogItem(null);
      setNewProductName('');
    },
    onError: (err: any) => toast.error(`Erro: ${err.message}`),
  });

  const handleSearch = async () => {
    if (!searchTerm.trim()) return;
    setIsSearching(true);
    try {
      const { data } = await supabase
        .from('products')
        .select('id, name, sku')
        .eq('active', true)
        .or(`name.ilike.%${searchTerm}%,sku.ilike.%${searchTerm}%`)
        .limit(10);
      setSearchResults(data || []);
    } finally {
      setIsSearching(false);
    }
  };

  const getConfidenceBadge = (score: number) => {
    if (score >= 85) return <Badge className="bg-primary/15 text-primary border-primary/20">{score}%</Badge>;
    if (score >= 60) return <Badge className="bg-accent/50 text-accent-foreground border-accent/30">{score}%</Badge>;
    return <Badge variant="destructive">{score}%</Badge>;
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (queueItems.length === 0) {
    return (
      <div className="text-center py-12 text-muted-foreground">
        <Package className="h-12 w-12 mx-auto mb-3 opacity-40" />
        <p className="font-medium">Nenhum match pendente</p>
        <p className="text-sm mt-1">Todos os produtos estão vinculados corretamente.</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold">Match de Produtos</h2>
          <p className="text-sm text-muted-foreground">
            {queueItems.length} produto(s) aguardando vinculação manual
          </p>
        </div>
      </div>

      <div className="space-y-3">
        {queueItems.map((item) => (
          <Card key={item.id} className="border-border/60">
            <CardContent className="p-4">
              <div className="flex items-start gap-4">
                {/* Left: Conta Azul product */}
                <div className="flex-1 min-w-0">
                  <p className="text-xs text-muted-foreground font-medium uppercase tracking-wide mb-1">Conta Azul</p>
                  <p className="font-semibold text-foreground truncate">{item.conta_azul_name}</p>
                  {item.conta_azul_sku && (
                    <p className="text-sm text-muted-foreground">SKU: {item.conta_azul_sku}</p>
                  )}
                </div>

                <ArrowRight className="h-5 w-5 text-muted-foreground/50 mt-4 shrink-0" />

                {/* Right: Suggestion */}
                <div className="flex-1 min-w-0">
                  <p className="text-xs text-muted-foreground font-medium uppercase tracking-wide mb-1">Sugestão IA</p>
                  {item.suggested_product_name && item.similarity_score >= 60 ? (
                    <div>
                      <p className="font-semibold text-foreground truncate">{item.suggested_product_name}</p>
                      <div className="flex items-center gap-2 mt-1">
                        {getConfidenceBadge(item.similarity_score)}
                        {item.reasoning && (
                          <span className="text-xs text-muted-foreground truncate">{item.reasoning}</span>
                        )}
                      </div>
                    </div>
                  ) : (
                    <p className="text-sm text-muted-foreground italic">Nenhuma sugestão confiável</p>
                  )}
                </div>

                {/* Actions */}
                <div className="flex items-center gap-2 shrink-0 mt-2">
                  {item.suggested_product_id && item.similarity_score >= 60 && (
                    <Button
                      size="sm"
                      variant="default"
                      onClick={() => confirmMutation.mutate({
                        queueId: item.id,
                        productId: item.suggested_product_id!,
                        contaAzulId: item.conta_azul_id,
                      })}
                      disabled={confirmMutation.isPending}
                      className="gap-1"
                    >
                      <Check className="h-3.5 w-3.5" /> Confirmar
                    </Button>
                  )}
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => {
                      setSearchingItemId(item.id);
                      setSearchTerm('');
                      setSearchResults([]);
                    }}
                    className="gap-1"
                  >
                    <Search className="h-3.5 w-3.5" /> Buscar outro
                  </Button>
                  <Button
                    size="sm"
                    variant="secondary"
                    onClick={() => {
                      setCreateDialogItem(item);
                      setNewProductName(item.conta_azul_name);
                    }}
                    className="gap-1"
                  >
                    <Plus className="h-3.5 w-3.5" /> Criar novo
                  </Button>
                </div>
              </div>

              {/* Search panel */}
              {searchingItemId === item.id && (
                <div className="mt-4 pt-4 border-t border-border/50 space-y-3">
                  <div className="flex gap-2">
                    <Input
                      placeholder="Buscar por nome ou SKU..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                      className="flex-1"
                    />
                    <Button size="sm" onClick={handleSearch} disabled={isSearching}>
                      {isSearching ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
                    </Button>
                    <Button size="sm" variant="ghost" onClick={() => setSearchingItemId(null)}>
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                  {searchResults.length > 0 && (
                    <div className="space-y-1 max-h-48 overflow-y-auto">
                      {searchResults.map((product) => (
                        <div
                          key={product.id}
                          className="flex items-center justify-between p-2 rounded-md hover:bg-muted/50 cursor-pointer"
                          onClick={() => confirmMutation.mutate({
                            queueId: item.id,
                            productId: product.id,
                            contaAzulId: item.conta_azul_id,
                          })}
                        >
                          <div>
                            <p className="text-sm font-medium">{product.name}</p>
                            {product.sku && <p className="text-xs text-muted-foreground">SKU: {product.sku}</p>}
                          </div>
                          <Check className="h-4 w-4 text-muted-foreground" />
                        </div>
                      ))}
                    </div>
                  )}
                  {searchResults.length === 0 && searchTerm && !isSearching && (
                    <p className="text-sm text-muted-foreground text-center py-2">Nenhum produto encontrado</p>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Create new product dialog */}
      <Dialog open={!!createDialogItem} onOpenChange={(open) => !open && setCreateDialogItem(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Criar novo produto</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Nome do produto</Label>
              <Input
                value={newProductName}
                onChange={(e) => setNewProductName(e.target.value)}
                placeholder="Nome do produto"
              />
            </div>
            {createDialogItem?.conta_azul_sku && (
              <div>
                <Label>SKU (Conta Azul)</Label>
                <Input value={createDialogItem.conta_azul_sku} disabled />
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCreateDialogItem(null)}>Cancelar</Button>
            <Button
              onClick={() => {
                if (!createDialogItem || !newProductName.trim()) return;
                createNewMutation.mutate({
                  queueId: createDialogItem.id,
                  name: newProductName.trim(),
                  contaAzulId: createDialogItem.conta_azul_id,
                  contaAzulSku: createDialogItem.conta_azul_sku,
                });
              }}
              disabled={createNewMutation.isPending || !newProductName.trim()}
            >
              {createNewMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Plus className="h-4 w-4 mr-2" />}
              Criar produto
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
