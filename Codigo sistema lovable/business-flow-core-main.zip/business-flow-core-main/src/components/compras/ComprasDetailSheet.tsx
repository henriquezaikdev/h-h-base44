import { useState, useEffect } from 'react';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle
} from '@/components/ui/alert-dialog';
import {
  Package, Trash2, Plus, Send, CheckCircle2, Pencil, Search,
  Clock, Timer, FileCheck, MessageSquare, User, Calendar, Settings,
  ChevronDown, ChevronRight, Copy, X, ImagePlus, XCircle, ThumbsUp, ThumbsDown,
  Play, ShoppingCart, Truck, PackageCheck, Undo2, type LucideIcon
} from 'lucide-react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import {
  useSolicitacaoItens, useAddSolicitacaoItem, useDeleteSolicitacaoItem,
  useCotacoes, useCreateCotacao, useUpsertCotacaoItem, useDeleteCotacaoItem,
  usePurchaseEvents, useAddEvent,
  useChangeStatus, useFornecedores, useDeleteSolicitacao, useUpdateSolicitacao,
  useApproveCotacaoItem, useRejectAllCotacoes,
  useRevertItemApproval, useRevertAllApprovals,
  STATUS_LABELS,
} from '@/hooks/useComprasData';
import { formatCurrency } from '@/lib/utils';
import { format, formatDistanceToNow } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { toast } from 'sonner';

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  solicitacaoId: string;
  initialTab?: string;
  onOpenCotacaoSession?: (sessionId: string) => void;
}

const STATUS_DISPLAY: Record<string, { label: string; className: string }> = {
  NOVA_SOLICITACAO: { label: 'Novo', className: 'bg-primary text-primary-foreground' },
  AGUARDANDO_COMPRADOR: { label: 'Aguardando', className: 'bg-muted text-muted-foreground' },
  EM_COTACAO: { label: 'Em Cotação', className: 'bg-primary text-primary-foreground' },
  AGUARDANDO_APROVACAO_SOLICITANTE: { label: 'Aguard. Aprovação', className: 'bg-amber-500 text-white' },
  APROVADA_PARA_COMPRAR: { label: 'Aprovada', className: 'bg-emerald-600 text-white' },
  EM_COMPRA_FORNECEDOR: { label: 'Em Compra', className: 'bg-primary text-primary-foreground' },
  AGUARDANDO_ENTREGA_FORNECEDOR: { label: 'A Caminho', className: 'bg-primary text-primary-foreground' },
  RECEBIDO: { label: 'Recebido', className: 'bg-emerald-600 text-white' },
  ENTREGUE: { label: 'Entregue', className: 'bg-muted text-muted-foreground' },
  CANCELADO: { label: 'Cancelado', className: 'bg-destructive text-destructive-foreground' },
};

interface HeaderAction {
  label: string;
  icon: LucideIcon;
  nextStatus: string;
  confirmTitle: string;
  confirmDesc: string;
  message: string;
}

function getHeaderAction(status: string, isSolicitante: boolean, isComprador: boolean): HeaderAction | null {
  if (status === 'NOVA_SOLICITACAO' && isComprador) {
    return { label: 'Iniciar Cotação', icon: Play, nextStatus: 'EM_COTACAO', confirmTitle: 'Iniciar Cotação?', confirmDesc: 'A solicitação passará para o status "Em Cotação" e você será atribuído como comprador responsável.', message: 'Cotação iniciada pelo comprador' };
  }
  if (status === 'AGUARDANDO_COMPRADOR' && isComprador) {
    return { label: 'Iniciar Cotação', icon: Play, nextStatus: 'EM_COTACAO', confirmTitle: 'Iniciar Cotação?', confirmDesc: 'A solicitação passará para o status "Em Cotação" e você será atribuído como comprador responsável.', message: 'Cotação iniciada pelo comprador' };
  }
  if (status === 'APROVADA_PARA_COMPRAR' && isComprador) {
    return { label: 'Iniciar Compra', icon: ShoppingCart, nextStatus: 'EM_COMPRA_FORNECEDOR', confirmTitle: 'Iniciar Compra?', confirmDesc: 'A solicitação passará para "Em Compra com Fornecedor". Confirma o início da compra?', message: 'Compra iniciada pelo comprador' };
  }
  if (status === 'EM_COMPRA_FORNECEDOR' && isComprador) {
    return { label: 'Enviado p/ Entrega', icon: Truck, nextStatus: 'AGUARDANDO_ENTREGA_FORNECEDOR', confirmTitle: 'Marcar como enviado?', confirmDesc: 'O pedido será marcado como "Aguardando Entrega do Fornecedor".', message: 'Pedido enviado para entrega' };
  }
  if (status === 'AGUARDANDO_ENTREGA_FORNECEDOR' && isComprador) {
    return { label: 'Marcar Recebido', icon: PackageCheck, nextStatus: 'RECEBIDO', confirmTitle: 'Confirmar recebimento?', confirmDesc: 'O pedido será marcado como "Recebido". O solicitante poderá então concluir a solicitação.', message: 'Pedido recebido pelo comprador' };
  }
  if (status === 'RECEBIDO' && (isSolicitante || isComprador)) {
    return { label: 'Entregue ao Cliente', icon: CheckCircle2, nextStatus: 'ENTREGUE', confirmTitle: 'Marcar como entregue?', confirmDesc: 'Confirme que o produto foi entregue ao cliente. Esta ação não pode ser desfeita.', message: 'Produto entregue ao cliente' };
  }
  return null;
}

const OPTION_LABELS = ['Opção A', 'Opção B', 'Opção C', 'Opção D', 'Opção E', 'Opção F', 'Opção G', 'Opção H'];

const QUICK_PAYMENT_CHIPS = [
  { label: 'À vista (PIX)', tipo: 'PIX', prazo: 0 },
  { label: 'À vista (Boleto)', tipo: 'BOLETO', prazo: 0 },
  { label: '30 dias', tipo: 'BOLETO', prazo: 30 },
  { label: '30/60 dias', tipo: 'BOLETO', prazo: 60 },
];

export function ComprasDetailSheet({ open, onOpenChange, solicitacaoId, initialTab, onOpenCotacaoSession }: Props) {
  const { seller, isAdminOrOwner } = useAuth();
  const qc = useQueryClient();
  const [activeTab, setActiveTab] = useState(initialTab || 'cotacao');
  const [comment, setComment] = useState('');
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [showRejectAllDialog, setShowRejectAllDialog] = useState(false);
  const [rejectAllMotivo, setRejectAllMotivo] = useState('');
  const [showActionConfirm, setShowActionConfirm] = useState(false);
  const [showRevertConfirm, setShowRevertConfirm] = useState(false);

  // Cotação general fields
  const [obsGerais, setObsGerais] = useState('');
  const [validaAte, setValidaAte] = useState('');

  // Item form with product search
  const [itemProductSearch, setItemProductSearch] = useState('');
  const [itemDesc, setItemDesc] = useState('');
  const [itemProductId, setItemProductId] = useState<string | null>(null);
  const [itemQtd, setItemQtd] = useState('1');
  const [showItemProductResults, setShowItemProductResults] = useState(false);

  const [debouncedProductSearch, setDebouncedProductSearch] = useState('');
  useEffect(() => {
    const t = setTimeout(() => setDebouncedProductSearch(itemProductSearch), 300);
    return () => clearTimeout(t);
  }, [itemProductSearch]);

  const { data: productResults = [] } = useQuery({
    queryKey: ['compras_sheet_product_search', debouncedProductSearch],
    enabled: debouncedProductSearch.length >= 2,
    queryFn: async () => {
      const { data, error } = await supabase
        .from('products')
        .select('id, name, sku')
        .eq('active', true)
        .or(`name.ilike.%${debouncedProductSearch}%,sku.ilike.%${debouncedProductSearch}%`)
        .order('name')
        .limit(10);
      if (error) throw error;
      return data;
    },
  });

  const { data: sol, refetch: refetchSol } = useQuery({
    queryKey: ['solicitacao_detail', solicitacaoId],
    enabled: !!solicitacaoId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from('solicitacoes_compra')
        .select('*, solicitante:sellers!solicitacoes_compra_solicitante_id_fkey(id, name), comprador:sellers!solicitacoes_compra_comprador_responsavel_id_fkey(id, name), fornecedor_ordem:fornecedores!solicitacoes_compra_ordem_direta_fornecedor_id_fkey(id, razao_social)')
        .eq('id', solicitacaoId)
        .single();
      if (error) throw error;
      return data;
    },
  });

  const { data: crmClient } = useQuery({
    queryKey: ['crm_client_for_sol', sol?.cliente_id],
    enabled: !!sol?.cliente_id,
    queryFn: async () => {
      const { data, error } = await supabase
        .from('clients')
        .select('id, company_name')
        .eq('id', sol!.cliente_id!)
        .single();
      if (error) throw error;
      return data;
    },
  });

  const { data: itens = [] } = useSolicitacaoItens(solicitacaoId);
  const { data: cotacoes = [] } = useCotacoes(solicitacaoId);
  const { data: events = [] } = usePurchaseEvents(solicitacaoId);
  const { data: fornecedores = [] } = useFornecedores();

  // Fetch supplier_quote_lines from Central de Cotação linked to this solicitação
  const { data: supplierQuoteOptions = [] } = useQuery({
    queryKey: ['supplier_quote_options_for_sol', solicitacaoId],
    enabled: !!solicitacaoId,
    queryFn: async () => {
      // 1. Find cotacao_sessoes linked to this solicitação
      const { data: sessions } = await supabase
        .from('cotacao_sessoes')
        .select('id')
        .eq('solicitacao_compra_id', solicitacaoId);
      if (!sessions || sessions.length === 0) return [];

      const sessionIds = sessions.map(s => s.id);

      // 2. Find supplier_quotes for those sessions
      const { data: quotes } = await supabase
        .from('supplier_quotes')
        .select('id, supplier_id, notes, created_at')
        .in('session_id', sessionIds);
      if (!quotes || quotes.length === 0) return [];

      const quoteIds = quotes.map(q => q.id);
      const supplierIds = [...new Set(quotes.map(q => q.supplier_id).filter(Boolean))] as string[];

      // 3. Fetch supplier names
      let supplierMap: Record<string, string> = {};
      if (supplierIds.length > 0) {
        const { data: suppliers } = await supabase
          .from('fornecedores')
          .select('id, razao_social')
          .in('id', supplierIds);
        if (suppliers) {
          for (const s of suppliers) {
            supplierMap[s.id] = s.razao_social;
          }
        }
      }

      // 4. Fetch all lines
      const { data: lines } = await supabase
        .from('supplier_quote_lines')
        .select('*')
        .in('supplier_quote_id', quoteIds);
      if (!lines) return [];

      // 5. Map lines with supplier info
      return lines.map(line => {
        const quote = quotes.find(q => q.id === line.supplier_quote_id);
        return {
          ...line,
          _supplier_name: quote?.supplier_id ? supplierMap[quote.supplier_id] || null : null,
          _supplier_id: quote?.supplier_id || null,
          _quote_notes: quote?.notes || null,
        };
      });
    },
  });

  const addItem = useAddSolicitacaoItem();
  const deleteItem = useDeleteSolicitacaoItem();
  const createCotacao = useCreateCotacao();
  const upsertCotacaoItem = useUpsertCotacaoItem();
  const deleteCotacaoItem = useDeleteCotacaoItem();
  const changeStatus = useChangeStatus();
  const addEvent = useAddEvent();
  const deleteSolicitacao = useDeleteSolicitacao();
  const approveCotacaoItem = useApproveCotacaoItem();
  const rejectAllCotacoes = useRejectAllCotacoes();
  const revertItemApproval = useRevertItemApproval();
  const revertAllApprovals = useRevertAllApprovals();

  if (!sol) return null;

  const isEditable = !['ENTREGUE', 'CANCELADO'].includes(sol.status);
  const clientDisplayName = crmClient?.company_name || sol.client_name_snapshot || sol.client_name_manual || '—';

  const isSolicitante = seller?.id === sol.solicitante?.id;
  const isComprador = seller?.id === sol.comprador?.id || isAdminOrOwner;
  const headerAction = getHeaderAction(sol.status, isSolicitante, isComprador);

  const invalidateAll = () => {
    qc.invalidateQueries({ queryKey: ['solicitacao_detail', solicitacaoId] });
    qc.invalidateQueries({ queryKey: ['solicitacoes_compra'] });
    qc.invalidateQueries({ queryKey: ['purchase_events', solicitacaoId] });
  };

  const handleStatusChange = async (newStatus: string) => {
    const extra: Record<string, any> = {};
    if (newStatus === 'EM_COTACAO' && !sol.comprador_responsavel_id) {
      extra.comprador_responsavel_id = seller?.id;
    }
    await changeStatus.mutateAsync({ id: solicitacaoId, status: newStatus, extra });
    invalidateAll();

    // BLOCO 1: Redirect to Central de Cotação after starting cotação
    if (newStatus === 'EM_COTACAO' && onOpenCotacaoSession) {
      try {
        // Check if session already exists
        const { data: existing } = await supabase
          .from('cotacao_sessoes')
          .select('id')
          .eq('solicitacao_compra_id', solicitacaoId)
          .limit(1);

        let sessionId: string;
        if (existing && existing.length > 0) {
          sessionId = existing[0].id;
        } else {
          const { data: newSession, error } = await supabase
            .from('cotacao_sessoes')
            .insert({
              titulo: sol.titulo || 'Cotação',
              status: 'aberta',
              origem: 'painel_comprador',
              solicitacao_compra_id: solicitacaoId,
              created_by: seller?.id || null,
            })
            .select('id')
            .single();
          if (error) throw error;
          sessionId = (newSession as any).id;
        }
        onOpenChange(false);
        onOpenCotacaoSession(sessionId);
      } catch (err) {
        console.error('Error creating cotação session:', err);
      }
    }
  };

  const handleAddItem = async () => {
    if (!itemDesc.trim() && !itemProductSearch.trim()) return;
    await addItem.mutateAsync({
      solicitacao_id: solicitacaoId,
      descricao_livre: itemDesc.trim() || itemProductSearch.trim(),
      produto_id: itemProductId || null,
      quantidade: Number(itemQtd) || 1,
    });
    setItemDesc('');
    setItemQtd('1');
    setItemProductId(null);
    setItemProductSearch('');
    setShowItemProductResults(false);
  };

  const handleDelete = async () => {
    await deleteSolicitacao.mutateAsync(solicitacaoId);
    onOpenChange(false);
  };

  const handleSendComment = async () => {
    if (!comment.trim()) return;
    await addEvent.mutateAsync({
      request_id: solicitacaoId,
      event_type: 'COMENTARIO',
      message: comment.trim(),
    });
    setComment('');
  };

  const handleAssignBuyer = async () => {
    const { error } = await supabase
      .from('solicitacoes_compra')
      .update({ comprador_responsavel_id: seller?.id })
      .eq('id', solicitacaoId);
    if (error) { toast.error(error.message); return; }
    toast.success('Atribuído!');
    refetchSol();
    invalidateAll();
  };

  // Build per-item cotacao map
  const itemCotacaoMap: Record<string, any[]> = {};
  for (const cot of cotacoes) {
    for (const ci of (cot as any).cotacao_itens || []) {
      if (!itemCotacaoMap[ci.solicitacao_item_id]) {
        itemCotacaoMap[ci.solicitacao_item_id] = [];
      }
      itemCotacaoMap[ci.solicitacao_item_id].push({
        ...ci,
        cotacao_id: cot.id,
        fornecedor: (cot as any).fornecedor,
        status_cotacao: (cot as any).status_cotacao,
      });
    }
  }

  // Merge supplier_quote_lines from Central de Cotação into itemCotacaoMap
  if (supplierQuoteOptions.length > 0 && itens.length > 0) {
    for (const line of supplierQuoteOptions) {
      // Match to a solicitacao_item by product_id or by description similarity
      let matchedItemId: string | null = null;

      // Try product_id match first
      if (line.product_id) {
        const match = itens.find((it: any) => it.produto_id === line.product_id);
        if (match) matchedItemId = match.id;
      }

      // Fallback: match by description
      if (!matchedItemId && line.raw_description) {
        const descLower = line.raw_description.toLowerCase();
        const match = itens.find((it: any) => {
          const itemDesc = (it.produto?.name || it.descricao_livre || '').toLowerCase();
          return itemDesc && (itemDesc.includes(descLower) || descLower.includes(itemDesc));
        });
        if (match) matchedItemId = match.id;
      }

      // If no match found, assign to first item as fallback
      if (!matchedItemId && itens.length > 0) {
        matchedItemId = itens[0].id;
      }

      if (matchedItemId) {
        if (!itemCotacaoMap[matchedItemId]) {
          itemCotacaoMap[matchedItemId] = [];
        }

        // Avoid duplicates (check by id)
        const alreadyExists = itemCotacaoMap[matchedItemId].some((o: any) => o.id === line.id);
        if (!alreadyExists) {
          const optionIndex = itemCotacaoMap[matchedItemId].length;
          itemCotacaoMap[matchedItemId].push({
            id: line.id,
            solicitacao_item_id: matchedItemId,
            cotacao_id: null,
            opcao_label: OPTION_LABELS[optionIndex] || `Opção ${optionIndex + 1}`,
            fornecedor_nome: (line as any)._supplier_name || null,
            fornecedor: (line as any)._supplier_id ? { id: (line as any)._supplier_id, razao_social: (line as any)._supplier_name } : null,
            preco_unitario: line.unit_price,
            quantidade: line.qty,
            marca: null,
            modelo_referencia: null,
            contato_fornecedor: null,
            prazo_dias: line.delivery_days,
            previsao_chegada: null,
            frete_incluso: false,
            especificacoes: line.raw_description,
            valor_frete: null,
            observacoes_opcao: line.observations || (line as any)._quote_notes || null,
            imagem_referencia_url: null,
            status_aprovacao: line.is_winner ? 'APROVADA' : null,
            _from_supplier_quotes: true, // flag to identify source
          });
        }
      }
    }
  }

  return (
    <>
      <Sheet open={open} onOpenChange={onOpenChange}>
        <SheetContent className="sm:max-w-[600px] p-0 flex flex-col h-full overflow-hidden">
          {/* Header */}
          <div className="p-5 pb-4 border-b space-y-3">
            <div className="flex items-start justify-between gap-3">
              <SheetTitle className="text-lg font-bold leading-tight">{sol.titulo}</SheetTitle>
              {isEditable && (
                <Button variant="destructive" size="sm" className="shrink-0 gap-1.5 text-xs h-8" onClick={() => setShowDeleteConfirm(true)}>
                  <Trash2 className="h-3.5 w-3.5" />
                  Excluir
                </Button>
              )}
            </div>
             <div className="flex items-center gap-2 flex-wrap">
              <span className={`inline-flex items-center rounded-full px-3 py-1.5 text-xs font-medium ${STATUS_DISPLAY[sol.status]?.className || 'bg-muted text-muted-foreground'}`}>
                {STATUS_DISPLAY[sol.status]?.label || sol.status}
              </span>
              {(sol as any).process_type === 'ORDEM_DIRETA' && (
                <Badge className="text-[10px] gap-1 bg-emerald-600 text-white">
                  <ShoppingCart className="h-3 w-3" /> Ordem Direta
                </Badge>
              )}
              {sol.status === 'EM_COTACAO' && isComprador && (
                <Button variant="outline" size="sm" className="h-7 text-xs gap-1 rounded-full" onClick={() => setShowRevertConfirm(true)}>
                  <Undo2 className="h-3.5 w-3.5" /> Devolver
                </Button>
              )}
              {headerAction && (
                <Button size="sm" className="h-7 text-xs gap-1 rounded-full" onClick={() => setShowActionConfirm(true)}>
                  <headerAction.icon className="h-3.5 w-3.5" /> {headerAction.label}
                </Button>
              )}
              <Badge variant="outline" className="text-[10px] gap-1 border-primary/30 text-primary font-medium">↑ {sol.prioridade}</Badge>
            </div>
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="flex items-center gap-1.5 text-muted-foreground">
                <User className="h-3 w-3 shrink-0" />
                <span>Vendedor:</span>
                <span className="font-medium text-foreground">{sol.solicitante?.name || '—'}</span>
              </div>
              <div className="flex items-center gap-1.5 text-muted-foreground">
                <User className="h-3 w-3 shrink-0" />
                <span>Comprador:</span>
                <span className="font-medium text-foreground">{sol.comprador?.name || 'Não atribuído'}</span>
                {!sol.comprador?.name && isEditable && (
                  <Button variant="link" size="sm" className="h-auto p-0 text-xs text-primary" onClick={handleAssignBuyer}>
                    <Pencil className="h-3 w-3 mr-0.5" /> Atribuir
                  </Button>
                )}
              </div>
            </div>
            <div className="text-xs text-muted-foreground flex items-center gap-1">
              <Package className="h-3 w-3" />Cliente: <span className="font-medium text-foreground">{clientDisplayName}</span>
              {sol.cliente_id && <Badge variant="outline" className="text-[9px] ml-1 px-1 py-0">Base CRM</Badge>}
            </div>
            <div className="text-[11px] text-muted-foreground flex items-center gap-1">
              <Calendar className="h-3 w-3" />Criado: {format(new Date(sol.created_at), 'dd/MM/yyyy', { locale: ptBR })}
            </div>
            {sol.supplier_eta_at && <LiveTimerBanner eta={sol.supplier_eta_at} />}
          </div>

          {/* Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col min-h-0">
            <TabsList className={`grid w-full ${(sol as any).process_type === 'ORDEM_DIRETA' ? 'grid-cols-2' : 'grid-cols-3'} mx-0 rounded-none border-b bg-transparent h-auto p-0`}>
              {(sol as any).process_type !== 'ORDEM_DIRETA' && (
                <TabsTrigger value="cotacao" className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent py-2.5 text-xs font-medium flex items-center gap-1.5">
                  <FileCheck className="h-3.5 w-3.5" />Cotação
                </TabsTrigger>
              )}
              <TabsTrigger value="detalhes" className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent py-2.5 text-xs font-medium flex items-center gap-1.5">
                <Settings className="h-3.5 w-3.5" />Detalhes
              </TabsTrigger>
              <TabsTrigger value="historico" className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent py-2.5 text-xs font-medium flex items-center gap-1.5">
                <Clock className="h-3.5 w-3.5" />Histórico
                {events.length > 0 && <Badge className="bg-primary text-primary-foreground text-[9px] px-1.5 py-0 min-w-[18px] justify-center">{events.length}</Badge>}
              </TabsTrigger>
            </TabsList>

            <div className="flex-1 overflow-y-auto">
              {/* DETALHES TAB */}
              <TabsContent value="detalhes" className="p-4 space-y-5 mt-0">
                {/* Ordem Direta Info */}
                {(sol as any).process_type === 'ORDEM_DIRETA' && (
                  <div className="rounded-lg border-2 border-emerald-200 bg-emerald-50/30 p-4 space-y-3">
                    <div className="flex items-center gap-2 text-sm font-bold text-emerald-700">
                      <ShoppingCart className="h-4 w-4" />
                      Dados da Ordem Direta
                    </div>
                    <div className="grid grid-cols-2 gap-3 text-xs">
                      <div>
                        <span className="text-muted-foreground">Fornecedor:</span>
                        <p className="font-medium">{(sol as any).fornecedor_ordem?.razao_social || 'N/A'}</p>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Preço Unitário:</span>
                        <p className="font-medium">{formatCurrency((sol as any).ordem_direta_preco_unitario || 0)}</p>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Quantidade:</span>
                        <p className="font-medium">{(sol as any).ordem_direta_quantidade || 0}</p>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Total:</span>
                        <p className="font-medium text-emerald-700">{formatCurrency(((sol as any).ordem_direta_preco_unitario || 0) * ((sol as any).ordem_direta_quantidade || 0))}</p>
                      </div>
                      {(sol as any).ordem_direta_ultimo_preco && (
                        <div>
                          <span className="text-muted-foreground">Último Preço Ref.:</span>
                          <p className="font-medium">{formatCurrency((sol as any).ordem_direta_ultimo_preco)}</p>
                        </div>
                      )}
                      {(sol as any).ordem_direta_ultima_data && (
                        <div>
                          <span className="text-muted-foreground">Última Compra:</span>
                          <p className="font-medium">{(sol as any).ordem_direta_ultima_data}</p>
                        </div>
                      )}
                    </div>
                    {(sol as any).ordem_direta_observacoes && (
                      <div className="text-xs">
                        <span className="text-muted-foreground">Observações:</span>
                        <p className="mt-0.5">{(sol as any).ordem_direta_observacoes}</p>
                      </div>
                    )}
                  </div>
                )}
                <div className="rounded-lg border p-4 space-y-3">
                  <div className="flex items-center gap-2">
                    <Package className="h-4 w-4 text-muted-foreground" />
                    <span className="font-semibold text-sm">Itens Solicitados</span>
                    <Badge variant="secondary" className="text-[10px] px-1.5 py-0">{itens.length}</Badge>
                  </div>
                  {itens.length === 0 ? (
                    <p className="text-xs text-muted-foreground">Nenhum item adicionado.</p>
                  ) : (
                    <div className="space-y-2">
                      {itens.map((it: any) => (
                        <div key={it.id} className="flex items-start justify-between gap-2 p-2 rounded-md bg-muted/40">
                          <div className="min-w-0">
                            <p className="text-sm font-medium">{it.produto?.name || it.descricao_livre || 'Sem descrição'}</p>
                            <div className="flex items-center gap-2 text-xs text-muted-foreground mt-0.5">
                              {it.produto?.sku && <span className="font-mono">{it.produto.sku}</span>}
                              <span>Qtd: {it.quantidade} {it.unidade || 'un'}</span>
                            </div>
                            {it.observacoes_item && <p className="text-[11px] text-muted-foreground mt-0.5 italic">{it.observacoes_item}</p>}
                            {it.imagem_url && <img src={it.imagem_url} alt="Referência" className="h-16 mt-1 rounded border object-cover" />}
                          </div>
                          {isEditable && (
                            <Button variant="ghost" size="icon" className="h-7 w-7 shrink-0" onClick={() => deleteItem.mutate({ id: it.id, solicitacao_id: solicitacaoId })}>
                              <Trash2 className="h-3.5 w-3.5 text-destructive" />
                            </Button>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                  {isEditable && (
                    <div className="space-y-2 pt-2 border-t">
                      <div className="relative">
                        <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
                        <Input
                          value={itemProductId ? itemDesc : itemProductSearch}
                          onChange={(e) => {
                            const val = e.target.value;
                            setItemProductSearch(val);
                            setItemDesc(val);
                            setItemProductId(null);
                            setShowItemProductResults(true);
                          }}
                          onFocus={() => setShowItemProductResults(true)}
                          placeholder="Buscar produto ou digitar descrição..."
                          className="pl-8 h-8 text-xs"
                        />
                        {showItemProductResults && productResults.length > 0 && !itemProductId && (
                          <div className="absolute z-50 w-full mt-1 bg-popover border rounded-md shadow-md max-h-36 overflow-y-auto">
                            {productResults.map((p: any) => (
                              <button key={p.id} className="w-full text-left px-3 py-1.5 text-xs hover:bg-accent" onClick={() => {
                                setItemProductId(p.id);
                                setItemDesc(p.name);
                                setItemProductSearch(p.name);
                                setShowItemProductResults(false);
                              }}>
                                <span>{p.name}</span>
                                {p.sku && <span className="text-muted-foreground ml-2">({p.sku})</span>}
                              </button>
                            ))}
                          </div>
                        )}
                        {itemProductId && <p className="text-[10px] text-primary mt-0.5">✓ Produto vinculado</p>}
                      </div>
                      <div className="flex gap-2">
                        <Input type="number" value={itemQtd} onChange={(e) => setItemQtd(e.target.value)} min="1" className="w-16 h-8 text-xs" placeholder="Qtd" />
                        <Button size="sm" className="h-8 text-xs gap-1" onClick={handleAddItem} disabled={addItem.isPending || (!itemDesc.trim() && !itemProductSearch.trim())}>
                          <Plus className="h-3.5 w-3.5" /> Adicionar
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
                {/* Comments */}
                <div className="rounded-lg border p-4 space-y-3">
                  <div className="flex items-center gap-2">
                    <MessageSquare className="h-4 w-4 text-muted-foreground" />
                    <span className="font-semibold text-sm">Comentários</span>
                  </div>
                  {events.filter((ev: any) => ev.event_type === 'COMENTARIO').length === 0 ? (
                    <p className="text-xs text-muted-foreground">Nenhum comentário.</p>
                  ) : (
                    <div className="space-y-2">
                      {events.filter((ev: any) => ev.event_type === 'COMENTARIO').map((ev: any) => (
                        <div key={ev.id} className="text-sm">
                          <div className="flex items-center gap-2">
                            <span className="font-medium text-xs">{ev.usuario?.name || 'Sistema'}</span>
                            <span className="text-[10px] text-muted-foreground">{format(new Date(ev.created_at), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}</span>
                          </div>
                          <p className="text-xs text-muted-foreground mt-0.5 italic">{ev.message}</p>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </TabsContent>

              {/* COTAÇÃO TAB — FULL REBUILD */}
              <TabsContent value="cotacao" className="p-4 space-y-5 mt-0">
                {/* Section 1: General Info */}
                <div className="rounded-lg border p-4 space-y-3">
                  <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Informações Gerais</p>
                  <div className="flex items-center gap-2 p-2 rounded-md bg-muted/30">
                    <User className="h-4 w-4 text-muted-foreground shrink-0" />
                    <div>
                      <p className="text-[11px] text-muted-foreground">Cliente (herdado)</p>
                      <p className="text-sm font-semibold">{clientDisplayName}</p>
                    </div>
                    {sol.cliente_id && <Badge variant="outline" className="text-[9px] px-1 py-0 ml-auto">Base CRM</Badge>}
                  </div>
                  {/* Fornecedor field */}
                  <CotacaoFornecedorField
                    solicitacaoId={solicitacaoId}
                    fornecedores={fornecedores}
                    cotacoes={cotacoes}
                    isEditable={isEditable && sol.status !== 'AGUARDANDO_APROVACAO_SOLICITANTE'}
                    createCotacao={createCotacao}
                  />
                  <div>
                    <Label className="text-xs">Observações Gerais da Cotação</Label>
                    <Textarea value={obsGerais} onChange={(e) => setObsGerais(e.target.value)} placeholder="Observações gerais..." className="mt-1 text-xs min-h-[60px]" />
                  </div>
                  <div>
                    <Label className="text-xs">Cotação Válida Até</Label>
                    <Input type="date" value={validaAte} onChange={(e) => setValidaAte(e.target.value)} className="mt-1 h-8 text-xs w-48" />
                  </div>
                </div>

                {/* Section 2: Itens Solicitados (per-item options) */}
                {itens.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground text-sm">Adicione itens na aba Detalhes primeiro.</div>
                ) : (
                  <div className="space-y-4">
                    <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Itens Solicitados</p>
                    {itens.map((item: any) => (
                      <CotacaoItemBlock
                        key={item.id}
                        item={item}
                        solicitacaoId={solicitacaoId}
                        cotacoes={cotacoes}
                        existingOptions={itemCotacaoMap[item.id] || []}
                        isEditable={isEditable}
                        upsertCotacaoItem={upsertCotacaoItem}
                        deleteCotacaoItem={deleteCotacaoItem}
                        createCotacao={createCotacao}
                        solStatus={sol.status}
                        isSolicitante={seller?.id === sol.solicitante_id}
                        allOptionIds={(itemCotacaoMap[item.id] || []).map((o: any) => o.id)}
                        approveCotacaoItem={approveCotacaoItem}
                        revertItemApproval={revertItemApproval}
                      />
                    ))}
                  </div>
                )}

                {/* Section 3: Itens Sugeridos */}
                {isEditable && (
                  <SuggestedItemsSection solicitacaoId={solicitacaoId} addItem={addItem} />
                )}

                {/* Approval buttons for solicitante */}
                {(sol.status === 'AGUARDANDO_APROVACAO_SOLICITANTE' || sol.status === 'APROVADA_PARA_COMPRAR') && seller?.id === sol.solicitante_id && (
                  <div className="flex items-center justify-end gap-2 pt-2 border-t">
                    {/* Desfazer todas as aprovações */}
                    {Object.values(itemCotacaoMap).flat().some((o: any) => o.status_aprovacao) && (
                      <Button
                        variant="outline"
                        size="sm"
                        className="text-xs gap-1.5"
                        onClick={async () => {
                          await revertAllApprovals.mutateAsync(solicitacaoId);
                          invalidateAll();
                        }}
                        disabled={revertAllApprovals.isPending}
                      >
                        <Undo2 className="h-3.5 w-3.5" /> Desfazer Todas Aprovações
                      </Button>
                    )}
                    {sol.status === 'AGUARDANDO_APROVACAO_SOLICITANTE' && (
                      <Button
                        variant="destructive"
                        size="sm"
                        className="text-xs gap-1.5"
                        onClick={() => setShowRejectAllDialog(true)}
                      >
                        <ThumbsDown className="h-3.5 w-3.5" /> Rejeitar Todas
                      </Button>
                    )}
                  </div>
                )}

                {/* Devolver para Cotação — comprador */}
                {isEditable && sol.status === 'AGUARDANDO_APROVACAO_SOLICITANTE' && (
                  <div className="flex items-center justify-end gap-2 pt-2 border-t">
                    <Button
                      variant="outline"
                      size="sm"
                      className="text-xs gap-1.5"
                      onClick={async () => {
                        if (!confirm('Deseja devolver esta solicitação para cotação?')) return;
                        await changeStatus.mutateAsync({
                          id: solicitacaoId,
                          status: 'EM_COTACAO',
                          message: 'Devolvido para cotação pelo comprador',
                        });
                        invalidateAll();
                        toast.success('Solicitação devolvida para cotação');
                      }}
                      disabled={changeStatus.isPending}
                    >
                      <Undo2 className="h-3.5 w-3.5" /> Devolver para Cotação
                    </Button>
                  </div>
                )}

                {isEditable && sol.status === 'EM_COTACAO' && isComprador && (
                  <div className="flex items-center justify-end gap-2 pt-2 border-t">
                    <Button variant="outline" size="sm" className="text-xs" onClick={() => onOpenChange(false)}>Cancelar</Button>
                    <Button size="sm" className="text-xs gap-1.5" onClick={async () => {
                      try {
                        // Save cotação general fields
                        for (const cot of cotacoes) {
                          await supabase.from('cotacoes_fornecedor').update({
                            observacoes_gerais: obsGerais || null,
                            valida_ate: validaAte || null,
                          } as any).eq('id', cot.id);
                        }

                        // Determine next status: auto-approve if buyer is the requester
                        const autoApprove = seller?.id === sol.solicitante?.id;
                        const nextStatus = autoApprove ? 'APROVADA_PARA_COMPRAR' : 'AGUARDANDO_APROVACAO_SOLICITANTE';

                        await changeStatus.mutateAsync({
                          id: solicitacaoId,
                          status: nextStatus,
                          message: autoApprove
                            ? 'Cotação auto-aprovada (comprador = solicitante)'
                            : 'Cotação enviada para aprovação do solicitante',
                        });

                        // Create notification for the requester if not auto-approved
                        if (!autoApprove && sol.solicitante?.id) {
                          await supabase.from('seller_notifications').insert({
                            seller_id: sol.solicitante.id,
                            type: 'compras',
                            title: 'Cotação aguardando sua aprovação',
                            message: `A solicitação "${sol.titulo}" está pronta para sua aprovação.`,
                            data: { solicitacao_id: solicitacaoId },
                          });
                        }

                        invalidateAll();
                        toast.success(autoApprove ? 'Cotação aprovada automaticamente!' : 'Cotação enviada para aprovação!');
                      } catch (err: any) {
                        console.error('Error sending for approval:', err);
                        toast.error('Erro ao enviar para aprovação');
                      }
                    }} disabled={changeStatus.isPending}>
                      <FileCheck className="h-3.5 w-3.5" /> Enviar p/ Aprovação
                    </Button>
                  </div>
                )}
              </TabsContent>

              {/* HISTÓRICO TAB */}
              <TabsContent value="historico" className="p-4 space-y-4 mt-0">
                <div className="rounded-lg border p-4 space-y-3">
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <span className="font-semibold text-sm">Histórico de Eventos</span>
                  </div>
                  {events.length === 0 ? (
                    <p className="text-xs text-muted-foreground text-center py-4">Nenhum evento registrado.</p>
                  ) : (
                    <div className="relative space-y-4 pl-4 border-l-2 border-muted">
                      {events.map((ev: any) => (
                        <div key={ev.id} className="relative">
                          <div className="absolute -left-[calc(1rem+5px)] top-1 w-2.5 h-2.5 rounded-full bg-primary/40 border-2 border-background" />
                          <div className="flex items-start justify-between gap-2">
                            <div>
                              <p className="text-sm font-medium">{getEventTitle(ev.event_type)}</p>
                              <p className="text-xs text-muted-foreground">{ev.message}</p>
                            </div>
                            <span className="text-[10px] text-muted-foreground whitespace-nowrap">
                              {formatDistanceToNow(new Date(ev.created_at), { addSuffix: true, locale: ptBR })}
                            </span>
                          </div>
                          <div className="flex items-center gap-2 mt-1">
                            <div className="h-5 w-5 rounded-full bg-muted flex items-center justify-center">
                              <User className="h-3 w-3 text-muted-foreground" />
                            </div>
                            <span className="text-[11px] text-muted-foreground">{ev.usuario?.name || 'Sistema'}</span>
                            <span className="text-[10px] text-muted-foreground">{format(new Date(ev.created_at), "dd/MM 'às' HH:mm", { locale: ptBR })}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </TabsContent>
            </div>
          </Tabs>

          {/* Bottom comment input */}
          <div className="border-t p-3 flex gap-2 shrink-0">
            <Input value={comment} onChange={(e) => setComment(e.target.value)} placeholder="Escreva um comentário..." className="text-sm" onKeyDown={(e) => e.key === 'Enter' && handleSendComment()} />
            <Button size="icon" onClick={handleSendComment} disabled={!comment.trim() || addEvent.isPending} className="shrink-0">
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </SheetContent>
      </Sheet>

      <AlertDialog open={showDeleteConfirm} onOpenChange={setShowDeleteConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Excluir solicitação?</AlertDialogTitle>
            <AlertDialogDescription>Esta ação é irreversível. Todos os itens, cotações e eventos serão removidos.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction className="bg-destructive text-destructive-foreground hover:bg-destructive/90" onClick={handleDelete}>Excluir</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Action Confirm Dialog */}
      <AlertDialog open={showActionConfirm} onOpenChange={setShowActionConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{headerAction?.confirmTitle}</AlertDialogTitle>
            <AlertDialogDescription>{headerAction?.confirmDesc}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={async () => {
              if (headerAction) {
                await handleStatusChange(headerAction.nextStatus);
                setShowActionConfirm(false);
              }
            }}>
              Confirmar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Revert Confirm Dialog */}
      <AlertDialog open={showRevertConfirm} onOpenChange={setShowRevertConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <Undo2 className="h-5 w-5 text-muted-foreground" />
              Devolver Solicitação
            </AlertDialogTitle>
            <AlertDialogDescription>
              A solicitação voltará para a fila de "Aguardando" e poderá ser retomada depois. A sessão de cotação vinculada será mantida.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={async () => {
              await changeStatus.mutateAsync({
                id: solicitacaoId,
                status: 'AGUARDANDO_COMPRADOR',
                extra: { comprador_responsavel_id: null },
                message: 'Solicitação devolvida para fila de aguardando',
              });
              setShowRevertConfirm(false);
            }}>
              Devolver
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={showRejectAllDialog} onOpenChange={(v) => { setShowRejectAllDialog(v); if (!v) setRejectAllMotivo(''); }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Rejeitar todas as propostas?</AlertDialogTitle>
            <AlertDialogDescription>
              Todas as opções de cotação serão marcadas como rejeitadas e a solicitação voltará ao comprador para nova cotação. Os dados serão preservados para relatórios.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="py-2">
            <Label className="text-sm font-medium">Motivo da rejeição *</Label>
            <Textarea
              value={rejectAllMotivo}
              onChange={(e) => setRejectAllMotivo(e.target.value)}
              placeholder="Descreva o motivo da rejeição..."
              className="mt-1.5 min-h-[80px]"
            />
          </div>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              disabled={!rejectAllMotivo.trim()}
              onClick={async () => {
                const allIds = Object.values(itemCotacaoMap).flat().map((o: any) => o.id);
                await rejectAllCotacoes.mutateAsync({
                  solicitacaoId,
                  allOptionIds: allIds,
                  motivo: rejectAllMotivo.trim(),
                });
                setRejectAllMotivo('');
                invalidateAll();
              }}
            >
              <ThumbsDown className="h-4 w-4 mr-1" /> Rejeitar Todas
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}

// =====================================================
// Per-Item Cotação Block — expandable options A, B, C...
// =====================================================
function CotacaoItemBlock({ item, solicitacaoId, cotacoes, existingOptions, isEditable, upsertCotacaoItem, deleteCotacaoItem, createCotacao, solStatus, isSolicitante, allOptionIds, approveCotacaoItem, revertItemApproval }: {
  item: any;
  solicitacaoId: string;
  cotacoes: any[];
  existingOptions: any[];
  isEditable: boolean;
  upsertCotacaoItem: any;
  deleteCotacaoItem: any;
  createCotacao: any;
  solStatus?: string;
  isSolicitante?: boolean;
  allOptionIds?: string[];
  approveCotacaoItem?: any;
  revertItemApproval?: any;
}) {
  const [expandedOption, setExpandedOption] = useState<string | null>(null);
  const [adding, setAdding] = useState(false);

  const handleAddOption = async () => {
    setAdding(true);
    try {
      let cotacaoId = cotacoes[0]?.id;
      if (!cotacaoId) {
        // Auto-create a cotação with placeholder fornecedor
        const PLACEHOLDER_FORNECEDOR_ID = 'dc8b5849-7102-443f-88a0-830cfe8ace12';
        const result = await createCotacao.mutateAsync({
          solicitacao_id: solicitacaoId,
          fornecedor_id: PLACEHOLDER_FORNECEDOR_ID,
        });
        cotacaoId = result?.id;
        if (!cotacaoId) { toast.error('Erro ao criar cotação'); return; }
      }

      const nextLabel = OPTION_LABELS[existingOptions.length] || `Opção ${existingOptions.length + 1}`;
      const result = await upsertCotacaoItem.mutateAsync({
        cotacao_id: cotacaoId,
        solicitacao_item_id: item.id,
        opcao_label: nextLabel,
      });

      if (result?.id) {
        setExpandedOption(result.id);
      }
    } finally {
      setAdding(false);
    }
  };

  return (
    <div className="rounded-lg border overflow-hidden">
      {/* Item header */}
      <div className="p-3 bg-muted/40 border-b flex items-start justify-between gap-3">
        <div className="flex gap-3 min-w-0">
          {item.imagem_url && <img src={item.imagem_url} alt="Ref" className="h-12 w-12 rounded border object-cover shrink-0" />}
          <div>
            <p className="text-sm font-semibold">{item.produto?.name || item.descricao_livre || 'Item'}</p>
            <div className="flex items-center gap-2 text-xs text-muted-foreground mt-0.5">
              {item.produto?.sku && <span className="font-mono">{item.produto.sku}</span>}
              <span>Qtd: {item.quantidade} {item.unidade || 'un'}</span>
            </div>
            {item.observacoes_item && <p className="text-[11px] text-muted-foreground mt-0.5 italic">{item.observacoes_item}</p>}
          </div>
        </div>
        {isEditable && (
          <Button variant="outline" size="sm" className="text-xs gap-1 h-7" onClick={handleAddOption} disabled={adding}>
            <Plus className="h-3 w-3" /> Opção
          </Button>
        )}
      </div>

      {/* Options */}
      <div className="divide-y">
        {existingOptions.length === 0 ? (
          <p className="p-3 text-xs text-muted-foreground italic">Nenhuma opção de cotação. Clique em "+ Opção" para adicionar.</p>
        ) : (
          existingOptions.map((opt: any, idx: number) => (
            <CotacaoOptionRow
              key={opt.id}
              option={opt}
              index={idx}
              item={item}
              isEditable={isEditable}
              isExpanded={expandedOption === opt.id}
              onToggle={() => setExpandedOption(expandedOption === opt.id ? null : opt.id)}
              upsertCotacaoItem={upsertCotacaoItem}
              deleteCotacaoItem={deleteCotacaoItem}
              showApproval={(solStatus === 'AGUARDANDO_APROVACAO_SOLICITANTE' || solStatus === 'APROVADA_PARA_COMPRAR') && isSolicitante && !existingOptions.some((o: any) => o.status_aprovacao === 'APROVADA')}
              showRevert={isSolicitante && !!opt.status_aprovacao && (solStatus === 'AGUARDANDO_APROVACAO_SOLICITANTE' || solStatus === 'APROVADA_PARA_COMPRAR')}
              onRevert={async () => {
                if (!revertItemApproval || !allOptionIds) return;
                await revertItemApproval.mutateAsync({
                  solicitacaoId,
                  optionIds: allOptionIds,
                });
              }}
              reverting={revertItemApproval?.isPending}
              onApprove={async () => {
                if (!approveCotacaoItem || !allOptionIds) return;
                await approveCotacaoItem.mutateAsync({
                  cotacaoItemId: opt.id,
                  solicitacaoId,
                  allOptionIds,
                });
              }}
              approving={approveCotacaoItem?.isPending}
            />
          ))
        )}
      </div>
    </div>
  );
}

// =====================================================
// Single Option Row — collapsible with full fields
// =====================================================
function CotacaoOptionRow({ option, index, item, isEditable, isExpanded, onToggle, upsertCotacaoItem, deleteCotacaoItem, showApproval, showRevert, onApprove, onRevert, approving, reverting }: {
  option: any;
  index: number;
  item: any;
  isEditable: boolean;
  isExpanded: boolean;
  onToggle: () => void;
  upsertCotacaoItem: any;
  deleteCotacaoItem: any;
  showApproval?: boolean;
  showRevert?: boolean;
  onApprove?: () => void;
  onRevert?: () => void;
  approving?: boolean;
  reverting?: boolean;
}) {
  const [marca, setMarca] = useState(option.marca || '');
  const [modelo, setModelo] = useState(option.modelo_referencia || '');
  const [fornecedorNome, setFornecedorNome] = useState(option.fornecedor_nome || option.fornecedor?.razao_social || '');
  const [contato, setContato] = useState(option.contato_fornecedor || '');
  const [quantidade, setQuantidade] = useState(String(item.quantidade || 1));
  const [prazoDias, setPrazoDias] = useState(String(option.prazo_dias || ''));
  const [previsaoChegada, setPrevisaoChegada] = useState(option.previsao_chegada || '');
  const [freteIncluso, setFreteIncluso] = useState(option.frete_incluso || false);
  const [especificacoes, setEspecificacoes] = useState(option.especificacoes || '');
  const [precoUnitario, setPrecoUnitario] = useState(option.preco_unitario != null ? String(option.preco_unitario) : '');
  const [valorFrete, setValorFrete] = useState(option.valor_frete != null ? String(option.valor_frete) : '');
  const [obsOpcao, setObsOpcao] = useState(option.observacoes_opcao || '');
  const [imagemUrl, setImagemUrl] = useState(option.imagem_referencia_url || '');
  const [uploading, setUploading] = useState(false);

  const label = option.opcao_label || OPTION_LABELS[index] || `Opção ${index + 1}`;

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) { toast.error('Apenas imagens são permitidas'); return; }
    if (file.size > 5 * 1024 * 1024) { toast.error('Imagem muito grande (máx 5MB)'); return; }

    setUploading(true);
    try {
      const ext = file.name.split('.').pop();
      const path = `${option.id}-${Date.now()}.${ext}`;
      const { error: uploadError } = await supabase.storage.from('cotacao-images').upload(path, file, { upsert: true });
      if (uploadError) throw uploadError;
      const { data: urlData } = supabase.storage.from('cotacao-images').getPublicUrl(path);
      setImagemUrl(urlData.publicUrl);
      // Save immediately
      await supabase.from('cotacao_itens').update({ imagem_referencia_url: urlData.publicUrl } as any).eq('id', option.id);
      toast.success('Imagem enviada!');
    } catch (err: any) {
      toast.error(err.message || 'Erro ao enviar imagem');
    } finally {
      setUploading(false);
    }
  };

  const handleRemoveImage = async () => {
    setImagemUrl('');
    await supabase.from('cotacao_itens').update({ imagem_referencia_url: null } as any).eq('id', option.id);
    toast.success('Imagem removida');
  };

  const handleSave = async () => {
    await upsertCotacaoItem.mutateAsync({
      id: option.id,
      cotacao_id: option.cotacao_id,
      solicitacao_item_id: item.id,
      marca: marca || null,
      modelo_referencia: modelo || null,
      fornecedor_nome: fornecedorNome || null,
      contato_fornecedor: contato || null,
      prazo_dias: prazoDias ? parseInt(prazoDias) : null,
      previsao_chegada: previsaoChegada || null,
      frete_incluso: freteIncluso,
      especificacoes: especificacoes || null,
      preco_unitario: precoUnitario ? parseFloat(precoUnitario.replace(',', '.')) : null,
      valor_frete: valorFrete ? parseFloat(valorFrete.replace(',', '.')) : null,
      observacoes_opcao: obsOpcao || null,
      opcao_label: label,
    });
    toast.success(`${label} salva!`);
  };

  const handleDelete = async () => {
    await deleteCotacaoItem.mutateAsync(option.id);
    toast.success(`${label} removida`);
  };

  return (
    <Collapsible open={isExpanded} onOpenChange={onToggle}>
      <CollapsibleTrigger className="w-full">
        <div className="flex items-center justify-between p-3 hover:bg-muted/20 transition-colors cursor-pointer">
          <div className="flex items-center gap-2">
            {isExpanded ? <ChevronDown className="h-3.5 w-3.5 text-muted-foreground" /> : <ChevronRight className="h-3.5 w-3.5 text-muted-foreground" />}
            <Badge variant="outline" className="text-[10px] font-semibold">{label}</Badge>
            {option.status_aprovacao === 'APROVADA' && (
              <Badge className="bg-green-600 text-white text-[9px] px-1.5 py-0 gap-1">
                ✓ Aprovada
                {option.aprovado_em && <span className="opacity-80">{format(new Date(option.aprovado_em), "dd/MM 'às' HH:mm", { locale: ptBR })}</span>}
              </Badge>
            )}
            {option.status_aprovacao === 'REJEITADA' && (
              <Badge variant="destructive" className="text-[9px] px-1.5 py-0 gap-1">
                ✗ Rejeitada
                {option.aprovado_em && <span className="opacity-80">{format(new Date(option.aprovado_em), "dd/MM 'às' HH:mm", { locale: ptBR })}</span>}
              </Badge>
            )}
            {fornecedorNome && <span className="text-xs text-muted-foreground">{fornecedorNome}</span>}
            {precoUnitario && <span className="text-xs font-medium text-primary">R$ {precoUnitario}/un</span>}
          </div>
          <div className="flex items-center gap-1">
            {showRevert && option.status_aprovacao && (
              <Button
                variant="ghost"
                size="sm"
                className="h-7 text-[10px] gap-1 text-muted-foreground hover:text-foreground"
                onClick={(e) => { e.stopPropagation(); onRevert?.(); }}
                disabled={reverting}
              >
                <Undo2 className="h-3 w-3" /> Desfazer
              </Button>
            )}
            {showApproval && !option.status_aprovacao && (
              <Button
                variant="outline"
                size="sm"
                className="h-7 text-[10px] gap-1 border-green-500 text-green-600 hover:bg-green-50 hover:text-green-700"
                onClick={(e) => { e.stopPropagation(); onApprove?.(); }}
                disabled={approving}
              >
                <ThumbsUp className="h-3 w-3" /> Aprovar
              </Button>
            )}
            {isEditable && !option.status_aprovacao && (
              <Button variant="ghost" size="icon" className="h-6 w-6" onClick={(e) => { e.stopPropagation(); handleDelete(); }}>
                <X className="h-3 w-3 text-destructive" />
              </Button>
            )}
          </div>
        </div>
      </CollapsibleTrigger>
      <CollapsibleContent>
        <div className="px-4 pb-4 space-y-3 border-t bg-muted/10">
          {/* Row: Marca + Modelo */}
          <div className="grid grid-cols-2 gap-2 pt-3">
            <div>
              <Label className="text-[11px]">Marca</Label>
              <Input value={marca} onChange={(e) => setMarca(e.target.value)} className="h-8 text-xs mt-1" placeholder="Marca" disabled={!isEditable} />
            </div>
            <div>
              <Label className="text-[11px]">Modelo / Referência</Label>
              <Input value={modelo} onChange={(e) => setModelo(e.target.value)} className="h-8 text-xs mt-1" placeholder="Modelo" disabled={!isEditable} />
            </div>
          </div>

          {/* Imagem de Referência */}
          <div>
            <Label className="text-[11px]">Imagem de Referência</Label>
            {imagemUrl ? (
              <div className="mt-1 relative inline-block">
                <img src={imagemUrl} alt="Referência" className="rounded-md border max-h-32 max-w-full object-contain" />
                {isEditable && (
                  <Button variant="destructive" size="icon" className="absolute -top-2 -right-2 h-5 w-5 rounded-full" onClick={handleRemoveImage}>
                    <X className="h-3 w-3" />
                  </Button>
                )}
              </div>
            ) : isEditable ? (
              <label className="mt-1 flex items-center gap-2 p-3 rounded-md border border-dashed cursor-pointer hover:bg-muted/30 transition-colors">
                <ImagePlus className="h-4 w-4 text-muted-foreground" />
                <span className="text-xs text-muted-foreground">{uploading ? 'Enviando...' : 'Clique para enviar imagem'}</span>
                <input type="file" accept="image/*" className="hidden" onChange={handleImageUpload} disabled={uploading} />
              </label>
            ) : (
              <p className="text-xs text-muted-foreground mt-1 italic">Sem imagem</p>
            )}
          </div>

          {/* Row: Fornecedor + Contato */}
          <div className="grid grid-cols-2 gap-2">
            <div>
              <Label className="text-[11px]">Fornecedor</Label>
              <Input value={fornecedorNome} onChange={(e) => setFornecedorNome(e.target.value)} className="h-8 text-xs mt-1" placeholder="Nome do fornecedor" disabled={!isEditable} />
            </div>
            <div>
              <Label className="text-[11px]">Contato</Label>
              <Input value={contato} onChange={(e) => setContato(e.target.value)} className="h-8 text-xs mt-1" placeholder="Telefone / Email" disabled={!isEditable} />
            </div>
          </div>

          {/* Row: Preço + Frete + Prazo */}
          <div className="grid grid-cols-3 gap-2">
            <div>
              <Label className="text-[11px]">Preço Unitário</Label>
              <Input value={precoUnitario} onChange={(e) => setPrecoUnitario(e.target.value)} className="h-8 text-xs mt-1" placeholder="0,00" disabled={!isEditable} />
            </div>
            <div>
              <Label className="text-[11px]">Valor Frete</Label>
              <Input value={valorFrete} onChange={(e) => setValorFrete(e.target.value)} className="h-8 text-xs mt-1" placeholder="0,00" disabled={!isEditable} />
            </div>
            <div>
              <Label className="text-[11px]">Prazo (dias)</Label>
              <Input type="number" value={prazoDias} onChange={(e) => setPrazoDias(e.target.value)} className="h-8 text-xs mt-1" placeholder="0" disabled={!isEditable} />
            </div>
          </div>

          {/* Row: Previsão + Frete incluso */}
          <div className="flex items-end gap-4">
            <div className="flex-1">
              <Label className="text-[11px]">Previsão Chegada</Label>
              <Input type="date" value={previsaoChegada} onChange={(e) => setPrevisaoChegada(e.target.value)} className="h-8 text-xs mt-1" disabled={!isEditable} />
            </div>
            <div className="flex items-center gap-2 pb-1">
              <Checkbox checked={freteIncluso} onCheckedChange={(v) => setFreteIncluso(!!v)} disabled={!isEditable} id={`frete-${option.id}`} />
              <label htmlFor={`frete-${option.id}`} className="text-xs text-muted-foreground cursor-pointer">Frete incluso</label>
            </div>
          </div>

          {/* Especificações */}
          <div>
            <Label className="text-[11px]">Especificações</Label>
            <Textarea value={especificacoes} onChange={(e) => setEspecificacoes(e.target.value)} className="mt-1 text-xs min-h-[50px]" placeholder="Detalhes técnicos..." disabled={!isEditable} />
          </div>

          {/* Payment Conditions */}
          <div className="space-y-2">
            <Label className="text-[11px] font-semibold">Condições de Pagamento</Label>
            <div className="flex flex-wrap gap-1.5">
              {QUICK_PAYMENT_CHIPS.map(chip => (
                <Badge
                  key={chip.label}
                  variant="outline"
                  className="text-[10px] cursor-pointer hover:bg-primary hover:text-primary-foreground transition-colors"
                  onClick={() => {
                    if (!isEditable) return;
                    // Quick-fill payment info into observações
                    setObsOpcao(prev => prev ? `${prev}\n${chip.label}` : chip.label);
                  }}
                >
                  {chip.label}
                </Badge>
              ))}
            </div>
            <PaymentConditionsSection cotacaoItemId={option.id} isEditable={isEditable} />
          </div>

          {/* Observações da Opção */}
          <div>
            <Label className="text-[11px]">Observações da Opção</Label>
            <Textarea value={obsOpcao} onChange={(e) => setObsOpcao(e.target.value)} className="mt-1 text-xs min-h-[40px]" placeholder="Observações..." disabled={!isEditable} />
          </div>

          {/* Save button */}
          {isEditable && (
            <Button size="sm" className="w-full text-xs gap-1.5" onClick={handleSave} disabled={upsertCotacaoItem.isPending}>
              <CheckCircle2 className="h-3.5 w-3.5" /> Salvar {label}
            </Button>
          )}
        </div>
      </CollapsibleContent>
    </Collapsible>
  );
}

// =====================================================
// Payment Conditions Section (per cotacao_item)
// =====================================================
function PaymentConditionsSection({ cotacaoItemId, isEditable }: { cotacaoItemId: string; isEditable: boolean }) {
  const [showAdd, setShowAdd] = useState(false);
  const [desc, setDesc] = useState('');
  const [prazo, setPrazo] = useState('0');
  const [tipo, setTipo] = useState('PIX');
  const [precoUnit, setPrecoUnit] = useState('');
  const [frete, setFrete] = useState('0');

  const { data: pagamentos = [] } = useQuery({
    queryKey: ['cotacao_item_pagamentos', cotacaoItemId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('cotacao_item_pagamentos')
        .select('*')
        .eq('cotacao_item_id', cotacaoItemId)
        .order('created_at');
      if (error) throw error;
      return data;
    },
  });

  const qc = useQueryClient();

  const handleAdd = async () => {
    if (!desc.trim() || !precoUnit) return;
    const pu = parseFloat(precoUnit.replace(',', '.'));
    const fr = parseFloat(frete.replace(',', '.')) || 0;
    const total = pu + fr;

    const { error } = await supabase.from('cotacao_item_pagamentos').insert({
      cotacao_item_id: cotacaoItemId,
      descricao: desc,
      prazo_dias: parseInt(prazo) || 0,
      tipo,
      preco_unitario: pu,
      valor_frete: fr,
      total,
    } as any);
    if (error) { toast.error(error.message); return; }
    qc.invalidateQueries({ queryKey: ['cotacao_item_pagamentos', cotacaoItemId] });
    setDesc(''); setPrecoUnit(''); setFrete('0'); setPrazo('0');
    setShowAdd(false);
    toast.success('Condição adicionada!');
  };

  const handleDelete = async (id: string) => {
    const { error } = await supabase.from('cotacao_item_pagamentos').delete().eq('id', id);
    if (error) { toast.error(error.message); return; }
    qc.invalidateQueries({ queryKey: ['cotacao_item_pagamentos', cotacaoItemId] });
  };

  return (
    <div className="space-y-1.5">
      {pagamentos.map((p: any) => (
        <div key={p.id} className="flex items-center justify-between p-1.5 rounded bg-muted/30 text-xs">
          <div>
            <span className="font-medium">{p.descricao}</span>
            <span className="text-muted-foreground ml-2">R$ {Number(p.preco_unitario).toFixed(2)}/un</span>
            {p.valor_frete > 0 && <span className="text-muted-foreground ml-1">+ Frete R$ {Number(p.valor_frete).toFixed(2)}</span>}
            <span className="text-primary ml-2 font-medium">= R$ {Number(p.total).toFixed(2)}</span>
          </div>
          {isEditable && (
            <Button variant="ghost" size="icon" className="h-5 w-5" onClick={() => handleDelete(p.id)}>
              <X className="h-3 w-3 text-destructive" />
            </Button>
          )}
        </div>
      ))}
      {isEditable && !showAdd && (
        <Button variant="ghost" size="sm" className="text-xs gap-1 h-6 text-muted-foreground" onClick={() => setShowAdd(true)}>
          <Plus className="h-3 w-3" /> Condição
        </Button>
      )}
      {showAdd && (
        <div className="space-y-1.5 p-2 rounded border bg-card">
          <Input value={desc} onChange={(e) => setDesc(e.target.value)} placeholder="Descrição (ex: À vista PIX)" className="h-7 text-xs" />
          <div className="grid grid-cols-3 gap-1.5">
            <Input value={precoUnit} onChange={(e) => setPrecoUnit(e.target.value)} placeholder="Preço unit." className="h-7 text-xs" />
            <Input value={frete} onChange={(e) => setFrete(e.target.value)} placeholder="Frete" className="h-7 text-xs" />
            <Input value={prazo} onChange={(e) => setPrazo(e.target.value)} placeholder="Prazo dias" className="h-7 text-xs" type="number" />
          </div>
          <div className="flex gap-1.5">
            <Button size="sm" className="h-6 text-[10px] flex-1" onClick={handleAdd}>Adicionar</Button>
            <Button variant="ghost" size="sm" className="h-6 text-[10px]" onClick={() => setShowAdd(false)}>Cancelar</Button>
          </div>
        </div>
      )}
    </div>
  );
}

// =====================================================
// Helpers
// =====================================================
function LiveTimerBanner({ eta }: { eta: string }) {
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const interval = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(interval);
  }, []);

  const target = new Date(eta).getTime();
  const diff = target - now;
  const isLate = diff < 0;
  const absDiff = Math.abs(diff);
  const days = Math.floor(absDiff / (1000 * 60 * 60 * 24));
  const hours = Math.floor((absDiff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  const minutes = Math.floor((absDiff % (1000 * 60 * 60)) / (1000 * 60));
  const seconds = Math.floor((absDiff % (1000 * 60)) / 1000);

  const timeStr = days > 0 ? `${days}d ${hours}h ${minutes}m` : `${hours}h ${minutes}m ${seconds}s`;

  return (
    <div className={`flex items-center gap-2 text-xs font-mono px-3 py-1.5 rounded-lg ${
      isLate ? 'bg-destructive/10 text-destructive border border-destructive/20' : 'bg-primary/10 text-primary border border-primary/20'
    }`}>
      <Timer className="h-3.5 w-3.5" />
      {isLate ? <span>⚠️ ATRASADO — +{timeStr}</span> : <span>⏳ ETA: {timeStr} restantes</span>}
    </div>
  );
}

function getEventTitle(eventType: string): string {
  switch (eventType) {
    case 'CRIACAO': return 'Solicitação criada';
    case 'MUDANCA_STATUS': return 'Status alterado';
    case 'COTACAO_CRIADA': return 'Cotação iniciada';
    case 'ETA_DEFINIDO': return 'ETA definido';
    case 'COMENTARIO': return 'Comentário';
    case 'ATUALIZACAO': return 'Atualização';
    case 'EXCLUSAO': return 'Exclusão';
    default: return eventType;
  }
}

// =====================================================
// Suggested Items — inline add directly in Cotação tab
// =====================================================
function SuggestedItemsSection({ solicitacaoId, addItem }: { solicitacaoId: string; addItem: any }) {
  const [desc, setDesc] = useState('');
  const [qtd, setQtd] = useState('1');
  const [showForm, setShowForm] = useState(false);

  const handleAdd = async () => {
    if (!desc.trim()) return;
    await addItem.mutateAsync({
      solicitacao_id: solicitacaoId,
      descricao_livre: desc.trim(),
      quantidade: Number(qtd) || 1,
      observacoes_item: 'Sugerido pelo comprador',
    });
    setDesc('');
    setQtd('1');
    setShowForm(false);
    toast.success('Item sugerido adicionado!');
  };

  return (
    <div className="rounded-lg border border-dashed p-4 space-y-3">
      <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Itens Sugeridos pelo Comprador</p>
      <p className="text-[11px] text-muted-foreground">Adicione itens alternativos não solicitados pelo vendedor.</p>
      {showForm ? (
        <div className="space-y-2">
          <Input value={desc} onChange={(e) => setDesc(e.target.value)} placeholder="Descrição do item sugerido..." className="h-8 text-xs" />
          <div className="flex gap-2">
            <Input type="number" value={qtd} onChange={(e) => setQtd(e.target.value)} min="1" className="w-16 h-8 text-xs" placeholder="Qtd" />
            <Button size="sm" className="h-8 text-xs gap-1" onClick={handleAdd} disabled={addItem.isPending || !desc.trim()}>
              <Plus className="h-3.5 w-3.5" /> Adicionar
            </Button>
            <Button variant="ghost" size="sm" className="h-8 text-xs" onClick={() => setShowForm(false)}>Cancelar</Button>
          </div>
        </div>
      ) : (
        <Button variant="outline" size="sm" className="text-xs gap-1.5" onClick={() => setShowForm(true)}>
          <Plus className="h-3.5 w-3.5" /> Item Sugerido
        </Button>
      )}
    </div>
  );
}

// =====================================================
// Fornecedor Field for Cotação Tab
// =====================================================
function CotacaoFornecedorField({ solicitacaoId, fornecedores, cotacoes, isEditable, createCotacao }: {
  solicitacaoId: string;
  fornecedores: any[];
  cotacoes: any[];
  isEditable: boolean;
  createCotacao: any;
}) {
  const currentFornecedor = cotacoes[0]?.fornecedor;
  const [selectedId, setSelectedId] = useState(currentFornecedor?.id || '');
  const qc = useQueryClient();

  const handleChange = async (value: string) => {
    setSelectedId(value);
    if (cotacoes.length > 0) {
      // Update existing cotação
      await supabase
        .from('cotacoes_fornecedor')
        .update({ fornecedor_id: value } as any)
        .eq('id', cotacoes[0].id);
      qc.invalidateQueries({ queryKey: ['cotacoes', solicitacaoId] });
    } else {
      // Create new cotação with this fornecedor
      await createCotacao.mutateAsync({
        solicitacao_id: solicitacaoId,
        fornecedor_id: value,
      });
    }
    toast.success('Fornecedor atualizado');
  };

  return (
    <div>
      <Label className="text-xs">Fornecedor</Label>
      <Select value={selectedId} onValueChange={handleChange} disabled={!isEditable}>
        <SelectTrigger className="mt-1 h-8 text-xs">
          <SelectValue placeholder="Selecione o fornecedor..." />
        </SelectTrigger>
        <SelectContent>
          {fornecedores.map((f: any) => (
            <SelectItem key={f.id} value={f.id} className="text-xs">
              {f.razao_social}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}
