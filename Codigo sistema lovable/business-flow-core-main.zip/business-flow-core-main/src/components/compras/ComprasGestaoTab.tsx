import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { FornecedoresPanel } from './FornecedoresPanel';
import { ComprasPurchaseClients } from './ComprasPurchaseClients';
import { Building2, Users } from 'lucide-react';

export function ComprasGestaoTab() {
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <Building2 className="h-5 w-5 text-primary" />
        <div>
          <h2 className="text-lg font-semibold">Gestão de Cadastros</h2>
          <p className="text-sm text-muted-foreground">Fornecedores e clientes do módulo de compras</p>
        </div>
      </div>

      <Tabs defaultValue="fornecedores">
        <TabsList>
          <TabsTrigger value="fornecedores" className="gap-2">
            <Building2 className="h-4 w-4" /> Fornecedores
          </TabsTrigger>
          <TabsTrigger value="clientes" className="gap-2">
            <Users className="h-4 w-4" /> Clientes (Compras)
          </TabsTrigger>
        </TabsList>

        <TabsContent value="fornecedores">
          <FornecedoresPanel />
        </TabsContent>

        <TabsContent value="clientes">
          <ComprasPurchaseClients />
        </TabsContent>
      </Tabs>
    </div>
  );
}
