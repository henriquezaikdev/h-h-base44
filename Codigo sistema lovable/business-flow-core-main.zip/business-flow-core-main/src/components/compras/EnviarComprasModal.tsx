import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { AlertTriangle, Clock, CheckCircle2, Send, Loader2 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { useAuth } from '@/hooks/useAuth';
import { useQueryClient } from '@tanstack/react-query';

const ANNA_DEPARTMENT = 'financeiro_gestora';

function mapPrioridade(items: any[]): string {
  if (items.some(i => i.priority === 'URGENTE')) return 'URGENTE';
  if (items.some(i => i.priority === 'ATENCAO')) return 'NORMAL';
  return 'NORMAL';
}

function priorityIcon(p: string) {
  if (p === 'URGENTE') return <AlertTriangle className="h-3 w-3 text-destructive" />;
  if (p === 'ATENCAO') return <Clock className="h-3 w-3 text-amber-500" />;
  return <CheckCircle2 className="h-3 w-3 text-emerald-500" />;
}

interface EnviarComprasModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  selectedItems: any[];
  onSuccess: () => void;
}

export function EnviarComprasModal({ open, onOpenChange, selectedItems, onSuccess }: EnviarComprasModalProps) {
  const { seller } = useAuth();
  const queryClient = useQueryClient();
  const [observacao, setObservacao] = useState('');
  const [sending, setSending] = useState(false);

  const prioridade = mapPrioridade(selectedItems);
  const hoje = format(new Date(), "dd/MM/yyyy", { locale: ptBR });

  const handleConfirmar = async () => {
    if (selectedItems.length === 0) return;
    setSending(true);

    try {
      // Find Anna's seller ID
      const { data: annaData } = await supabase
        .from('sellers')
        .select('id')
        .eq('department', ANNA_DEPARTMENT)
        .limit(1);
      const compradorId = annaData?.[0]?.id || null;

      // Create solicitação
      const { data: solicitacao, error: solErr } = await supabase
        .from('solicitacoes_compra')
        .insert({
          titulo: `Reposição de Estoque — ${hoje}`,
          tipo_solicitacao: 'reposicao',
          prioridade,
          solicitante_id: seller?.id || null,
          comprador_responsavel_id: compradorId,
          motivo: observacao || 'Reposição automática baseada em análise de cobertura de estoque',
          status: 'nova',
          process_type: 'cotacao',
        })
        .select('id')
        .single();
      if (solErr) throw solErr;

      // Create items
      const items = selectedItems.map((s: any) => ({
        solicitacao_id: solicitacao.id,
        produto_id: s.product_id,
        descricao_livre: s.product_name,
        quantidade: s.suggested_qty,
        unidade: 'UN',
        observacoes_item: `${s.priority} — Cobertura: ${Number(s.coverage_days).toFixed(0)} dias`,
      }));
      const { error: itemsErr } = await supabase.from('solicitacao_itens').insert(items);
      if (itemsErr) throw itemsErr;

      // Mark suggestions as sent
      const ids = selectedItems.map((s: any) => s.id);
      await supabase
        .from('hh_sugestao_reposicao')
        .update({
          enviado_para_compras: true,
          data_envio: new Date().toISOString(),
          solicitacao_compra_id: solicitacao.id,
        } as any)
        .in('id', ids);

      // Create task for Anna in Meu Dia
      if (compradorId) {
        const uniqueKey = `reposicao_compra_${solicitacao.id}`;
        await supabase.from('tasks').insert({
          notes: `Nova solicitação de reposição aguardando cotação — ${selectedItems.length} itens`,
          task_date: new Date().toISOString().split('T')[0],
          status: 'pendente',
          priority: prioridade === 'URGENTE' ? 'alta' : 'media',
          contact_type: 'interno',
          contact_reason: 'Reposição de Estoque',
          module_type: 'COMPRAS',
          task_category: 'COMPRAS',
          created_by_seller_id: seller?.id || null,
          assigned_to_seller_id: compradorId,
          related_id: solicitacao.id,
          related_type: 'solicitacao_compra',
          unique_key: uniqueKey,
          source_module: 'reposicao',
        });
      }

      toast.success(`Solicitação criada com sucesso — ${selectedItems.length} itens`);
      queryClient.invalidateQueries({ queryKey: ['hh_sugestao_reposicao'] });
      setObservacao('');
      onSuccess();
      onOpenChange(false);
    } catch (err: any) {
      toast.error('Erro ao criar solicitação: ' + (err.message || 'Erro desconhecido'));
    } finally {
      setSending(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Send className="h-5 w-5 text-primary" />
            Enviar para Compras
          </DialogTitle>
          <DialogDescription>
            Confirme os {selectedItems.length} itens que serão enviados como solicitação de compra para a Anna Cristina.
          </DialogDescription>
        </DialogHeader>

        {/* Priority badge */}
        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground">Prioridade:</span>
          <Badge variant={prioridade === 'URGENTE' ? 'destructive' : 'secondary'}>
            {prioridade}
          </Badge>
        </div>

        {/* Items table */}
        <div className="border rounded-md overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>SKU</TableHead>
                <TableHead>Produto</TableHead>
                <TableHead className="text-right">Qtd Sugerida</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {selectedItems.map((item: any) => (
                <TableRow key={item.id}>
                  <TableCell className="font-mono text-xs">{item.sku || '—'}</TableCell>
                  <TableCell className="text-sm max-w-[200px] truncate">{item.product_name}</TableCell>
                  <TableCell className="text-right font-bold">{item.suggested_qty}</TableCell>
                  <TableCell>
                    <span className="inline-flex items-center gap-1 text-xs">
                      {priorityIcon(item.priority)}
                      {item.priority}
                    </span>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>

        {/* Observation */}
        <div className="space-y-1.5">
          <label className="text-sm font-medium">Observação (opcional)</label>
          <Textarea
            value={observacao}
            onChange={e => setObservacao(e.target.value)}
            placeholder="Adicione um comentário sobre esta solicitação..."
            rows={2}
          />
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={sending}>
            Cancelar
          </Button>
          <Button onClick={handleConfirmar} disabled={sending} className="gap-2">
            {sending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
            {sending ? 'Enviando...' : 'Confirmar e Enviar'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
