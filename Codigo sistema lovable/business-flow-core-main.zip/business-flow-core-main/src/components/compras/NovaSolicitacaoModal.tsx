import { useState, useEffect, useRef } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { FileText, Plus, Trash2, Search, ImagePlus, X, ShoppingCart, ClipboardList, AlertCircle, CheckCircle2, Sparkles } from 'lucide-react';
import { useCreateSolicitacao, useAddSolicitacaoItem, useFornecedores } from '@/hooks/useComprasData';
import { supabase } from '@/integrations/supabase/client';
import { useQuery } from '@tanstack/react-query';
import { toast } from 'sonner';
import { useAuth } from '@/hooks/useAuth';
import { formatCurrency } from '@/lib/utils';

function useDebouncedValue(value: string, delay = 300) {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const t = setTimeout(() => setDebounced(value), delay);
    return () => clearTimeout(t);
  }, [value, delay]);
  return debounced;
}

interface SolicitacaoItem {
  nome: string;
  quantidade: string;
  unidade: string;
  especificacoes: string;
  imagemUrl: string;
  produtoId: string | null;
}

const emptyItem = (): SolicitacaoItem => ({
  nome: '', quantidade: '1', unidade: 'Unidade', especificacoes: '', imagemUrl: '', produtoId: null,
});

interface IASugestaoItem {
  produto_nome: string;
  produto_id: string | null;
  quantidade_sugerida: number;
  observacao: string;
}

interface IASugestao {
  id: string;
  cliente_id: string;
  cliente_nome: string;
  motivo: string;
  observacao_comercial: string;
  payload: IASugestaoItem[];
  status: string;
}

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  iaSugestao?: IASugestao | null;
}

export function NovaSolicitacaoModal({ open, onOpenChange, iaSugestao }: Props) {
  const [processType, setProcessType] = useState<'COTACAO' | 'ORDEM_DIRETA'>('COTACAO');
  const [titulo, setTitulo] = useState('');
  const [prioridade, setPrioridade] = useState('NORMAL');
  const [clienteMode, setClienteMode] = useState<'manual' | 'base'>('manual');
  const [clienteManual, setClienteManual] = useState('');
  const [clienteId, setClienteId] = useState<string | null>(null);
  const [clienteSearch, setClienteSearch] = useState('');
  const [showClienteResults, setShowClienteResults] = useState(false);
  const [prazoResposta, setPrazoResposta] = useState('');
  const [itens, setItens] = useState<SolicitacaoItem[]>([emptyItem()]);
  const [origemIA, setOrigemIA] = useState(false);

  // Ordem Direta fields
  const [ordemDiretaFornecedorId, setOrdemDiretaFornecedorId] = useState<string | null>(null);
  const [ordemDiretaPreco, setOrdemDiretaPreco] = useState('');
  const [ordemDiretaQuantidade, setOrdemDiretaQuantidade] = useState('1');
  const [ordemDiretaObs, setOrdemDiretaObs] = useState('');
  const [ordemDiretaProdutoSearch, setOrdemDiretaProdutoSearch] = useState('');
  const [ordemDiretaProdutoId, setOrdemDiretaProdutoId] = useState<string | null>(null);
  const [showOrdemProdutoResults, setShowOrdemProdutoResults] = useState(false);

  const create = useCreateSolicitacao();
  const addItemMutation = useAddSolicitacaoItem();
  const { seller, isAdminOrOwner } = useAuth();
  const { data: fornecedores = [] } = useFornecedores();

  const debouncedClienteSearch = useDebouncedValue(clienteSearch, 300);
  const debouncedOrdemProdutoSearch = useDebouncedValue(ordemDiretaProdutoSearch, 300);

  // Check if user can use ORDEM_DIRETA (admin/comprador only)
  const isComprador = seller?.role === 'admin' || seller?.role === 'owner' || seller?.role === 'comprador' || isAdminOrOwner;

  const { data: clientesResults = [] } = useQuery({
    queryKey: ['clients_search_compras', debouncedClienteSearch],
    enabled: clienteMode === 'base' && debouncedClienteSearch.length >= 2,
    queryFn: async () => {
      const { data, error } = await supabase
        .from('clients')
        .select('id, company_name')
        .eq('is_deleted', false)
        .ilike('company_name', `%${debouncedClienteSearch}%`)
        .order('company_name')
        .limit(10);
      if (error) throw error;
      return data;
    },
  });

  // Product search for Ordem Direta
  const { data: ordemProdutoResults = [] } = useQuery({
    queryKey: ['ordem_direta_product_search', debouncedOrdemProdutoSearch],
    enabled: processType === 'ORDEM_DIRETA' && debouncedOrdemProdutoSearch.length >= 2,
    queryFn: async () => {
      const { data, error } = await supabase
        .from('products')
        .select('id, name, sku, is_homologated, cost_price')
        .eq('active', true)
        .or(`name.ilike.%${debouncedOrdemProdutoSearch}%,sku.ilike.%${debouncedOrdemProdutoSearch}%`)
        .order('name')
        .limit(10);
      if (error) throw error;
      return data;
    },
  });

  // Check if selected product is eligible for ORDEM_DIRETA
  const { data: productEligibility } = useQuery({
    queryKey: ['product_ordem_direta_eligibility', ordemDiretaProdutoId],
    enabled: !!ordemDiretaProdutoId && processType === 'ORDEM_DIRETA',
    queryFn: async () => {
      // Check if product is homologated
      const { data: product } = await supabase
        .from('products')
        .select('id, name, is_homologated, cost_price')
        .eq('id', ordemDiretaProdutoId!)
        .single();

      // Check if product has confirmed purchase history
      const { data: history } = await supabase
        .from('supplier_product_prices' as any)
        .select('id, supplier_id, last_price, last_date')
        .eq('product_id', ordemDiretaProdutoId!)
        .order('last_date', { ascending: false })
        .limit(1);

      const hasHistory = history && history.length > 0;
      const isHomologated = product?.is_homologated || false;
      const eligible = true;

      return {
        eligible,
        isHomologated,
        hasHistory,
        lastSupplier: hasHistory ? (history as any[])[0] : null,
        product,
      };
    },
  });

  // Auto-fill supplier and price when product is eligible
  useEffect(() => {
    if (productEligibility?.lastSupplier && processType === 'ORDEM_DIRETA') {
      const ls = productEligibility.lastSupplier;
      if (ls.supplier_id && !ordemDiretaFornecedorId) {
        setOrdemDiretaFornecedorId(ls.supplier_id);
      }
      if (ls.last_price && !ordemDiretaPreco) {
        setOrdemDiretaPreco(String(ls.last_price));
      }
    }
  }, [productEligibility]);

  // Pre-fill from AI suggestion
  useEffect(() => {
    if (iaSugestao && open) {
      setOrigemIA(true);
      // Set client
      if (iaSugestao.cliente_id) {
        setClienteMode('base');
        setClienteId(iaSugestao.cliente_id);
        setClienteSearch(iaSugestao.cliente_nome || '');
      } else if (iaSugestao.cliente_nome) {
        setClienteMode('manual');
        setClienteManual(iaSugestao.cliente_nome);
      }
      // Set title from motivo
      const motivoLabels: Record<string, string> = {
        recompra_atrasada: 'Recompra Atrasada',
        oportunidade: 'Oportunidade Comercial',
        upsell: 'Upsell',
        pedido_sugerido: 'Pedido Sugerido',
      };
      setTitulo(`[IA] ${motivoLabels[iaSugestao.motivo] || iaSugestao.motivo} — ${iaSugestao.cliente_nome}`);
      // Set items
      const iaItens: SolicitacaoItem[] = (iaSugestao.payload || []).map((item: any) => ({
        nome: item.produto_nome || '',
        quantidade: String(item.quantidade_sugerida || 1),
        unidade: 'Unidade',
        especificacoes: item.observacao || '',
        imagemUrl: '',
        produtoId: item.produto_id || null,
      }));
      if (iaItens.length > 0) setItens(iaItens);
    }
  }, [iaSugestao, open]);

  const addItem = () => setItens([...itens, emptyItem()]);
  const removeItem = (idx: number) => setItens(itens.filter((_, i) => i !== idx));
  const updateItem = (idx: number, field: keyof SolicitacaoItem, val: string) => {
    const copy = [...itens];
    copy[idx] = { ...copy[idx], [field]: val };
    setItens(copy);
  };

  const handleSubmit = async () => {
    if (processType === 'ORDEM_DIRETA') {
      // Validate direct order
      if (!ordemDiretaProdutoId) { toast.error('Selecione um produto'); return; }
      if (isComprador && !ordemDiretaFornecedorId) { toast.error('Selecione um fornecedor'); return; }
      if (!ordemDiretaPreco || Number(ordemDiretaPreco) <= 0) { toast.error('Preço deve ser maior que zero'); return; }
      if (!ordemDiretaQuantidade || Number(ordemDiretaQuantidade) <= 0) { toast.error('Quantidade deve ser maior que zero'); return; }
      

      const tituloFinal = titulo.trim() || `Ordem Direta - ${ordemDiretaProdutoSearch}`;

      const solicitacao = await create.mutateAsync({
        titulo: tituloFinal,
        prioridade,
        cliente_id: clienteMode === 'base' ? clienteId || undefined : undefined,
        client_name_manual: clienteMode === 'manual' ? clienteManual.trim() || undefined : undefined,
        client_name_snapshot: clienteMode === 'base' && clienteId ? clienteSearch : clienteManual.trim() || undefined,
        process_type: 'ORDEM_DIRETA',
        ordem_direta_fornecedor_id: ordemDiretaFornecedorId || null,
        ordem_direta_preco_unitario: Number(ordemDiretaPreco),
        ordem_direta_quantidade: Number(ordemDiretaQuantidade),
        ordem_direta_ultimo_preco: productEligibility?.lastSupplier?.last_price || null,
        ordem_direta_ultima_data: productEligibility?.lastSupplier?.last_date || null,
        ordem_direta_observacoes: ordemDiretaObs.trim() || null,
        initial_status: 'AGUARDANDO_ENTREGA_FORNECEDOR',
      });

      // Add item
      await addItemMutation.mutateAsync({
        solicitacao_id: solicitacao.id,
        descricao_livre: ordemDiretaProdutoSearch,
        produto_id: ordemDiretaProdutoId,
        quantidade: Number(ordemDiretaQuantidade) || 1,
      });

      resetForm();
      onOpenChange(false);
      return;
    }

    // Original COTACAO flow
    const nomes = itens.filter(i => i.nome.trim()).map(i => i.nome.trim());
    const tituloFinal = titulo.trim() || nomes.join(', ');
    if (!tituloFinal) return;

    const solicitacao = await create.mutateAsync({
      titulo: tituloFinal,
      prioridade,
      cliente_id: clienteMode === 'base' ? clienteId || undefined : undefined,
      client_name_manual: clienteMode === 'manual' ? clienteManual.trim() || undefined : undefined,
      client_name_snapshot: clienteMode === 'base' && clienteId ? clienteSearch : clienteManual.trim() || undefined,
      requested_response_due_at: prazoResposta ? new Date(prazoResposta).toISOString() : undefined,
      process_type: 'COTACAO',
    });

    const validItens = itens.filter(i => i.nome.trim());
    for (const item of validItens) {
      await addItemMutation.mutateAsync({
        solicitacao_id: solicitacao.id,
        descricao_livre: item.nome.trim(),
        quantidade: Number(item.quantidade) || 1,
        unidade: item.unidade,
        observacoes_item: item.especificacoes.trim() || null,
        imagem_url: item.imagemUrl || null,
      });
    }

    resetForm();
    onOpenChange(false);
  };

  const resetForm = () => {
    setProcessType('COTACAO');
    setTitulo('');
    setPrioridade('NORMAL');
    setClienteManual('');
    setClienteId(null);
    setClienteSearch('');
    setPrazoResposta('');
    setItens([emptyItem()]);
    setOrdemDiretaFornecedorId(null);
    setOrdemDiretaPreco('');
    setOrdemDiretaQuantidade('1');
    setOrdemDiretaObs('');
    setOrdemDiretaProdutoSearch('');
    setOrdemDiretaProdutoId(null);
    setOrigemIA(false);
  };

  const selectCliente = (client: { id: string; company_name: string }) => {
    setClienteId(client.id);
    setClienteSearch(client.company_name);
    setShowClienteResults(false);
  };

  const selectOrdemProduto = (product: any) => {
    setOrdemDiretaProdutoId(product.id);
    setOrdemDiretaProdutoSearch(product.name);
    setShowOrdemProdutoResults(false);
    // Reset supplier/price to let auto-fill work
    setOrdemDiretaFornecedorId(null);
    setOrdemDiretaPreco('');
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
        <DialogHeader className="flex-row items-center justify-between pr-8">
          <DialogTitle className="text-xl font-bold">Nova Solicitação de Compra</DialogTitle>
        </DialogHeader>

        <div className="space-y-5 pt-2">
          {origemIA && iaSugestao && (
            <div className="rounded-lg border border-emerald-500/30 bg-emerald-500/[0.04] p-3 space-y-1.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Sparkles className="h-3.5 w-3.5 text-emerald-600" />
                  <span className="text-xs font-semibold text-foreground">Sugestão gerada pela IA</span>
                </div>
                <button type="button" onClick={() => { setOrigemIA(false); resetForm(); }} className="text-[10px] text-muted-foreground hover:text-foreground px-2 py-0.5 rounded hover:bg-muted">Remover sugestão</button>
              </div>
              <div className="text-[11px] text-muted-foreground space-y-0.5 pl-6">
                <p><span className="font-medium text-foreground">Cliente:</span> {iaSugestao.cliente_nome}</p>
                <p><span className="font-medium text-foreground">Motivo:</span> {(iaSugestao.motivo || '').replace(/_/g, ' ')}</p>
                {iaSugestao.observacao_comercial && <p><span className="font-medium text-foreground">Ação:</span> {iaSugestao.observacao_comercial}</p>}
                <p><span className="font-medium text-foreground">Itens:</span> {(iaSugestao.payload || []).length} produto(s) · Origem: Ficha do Cliente</p>
              </div>
            </div>
          )}
          {/* Tipo de Processo */}
          <div className="space-y-2">
            <Label className="text-sm font-bold">Tipo de Processo *</Label>
            <RadioGroup
              value={processType}
              onValueChange={(v) => setProcessType(v as 'COTACAO' | 'ORDEM_DIRETA')}
              className="flex gap-3"
            >
              <label className={`flex items-center gap-3 flex-1 p-3 rounded-lg border-2 cursor-pointer transition-colors ${
                processType === 'COTACAO' ? 'border-primary bg-primary/5' : 'border-muted hover:border-muted-foreground/30'
              }`}>
                <RadioGroupItem value="COTACAO" />
                <div className="flex items-center gap-2">
                  <ClipboardList className="h-4 w-4 text-primary" />
                  <div>
                    <p className="text-sm font-medium">Cotação</p>
                    <p className="text-[11px] text-muted-foreground">Fluxo completo com comparativo</p>
                  </div>
                </div>
              </label>
              <label className={`flex items-center gap-3 flex-1 p-3 rounded-lg border-2 cursor-pointer transition-colors ${
                processType === 'ORDEM_DIRETA' ? 'border-primary bg-primary/5' : 'border-muted hover:border-muted-foreground/30'
              } ${!isComprador ? 'opacity-50 pointer-events-none' : ''}`}>
                <RadioGroupItem value="ORDEM_DIRETA" disabled={!isComprador} />
                <div className="flex items-center gap-2">
                  <ShoppingCart className="h-4 w-4 text-emerald-600" />
                  <div>
                    <p className="text-sm font-medium">Ordem Direta</p>
                    <p className="text-[11px] text-muted-foreground">Compra rápida sem cotação</p>
                  </div>
                </div>
              </label>
            </RadioGroup>
            {!isComprador && processType === 'COTACAO' && (
              <p className="text-[11px] text-muted-foreground">Ordem Direta disponível apenas para Admin/Comprador.</p>
            )}
          </div>

          {/* Título */}
          <div className="space-y-1.5">
            <Label className="text-sm font-medium">Título (opcional se tiver item)</Label>
            <Input value={titulo} onChange={(e) => setTitulo(e.target.value)} placeholder="Ex: Toner Brother TN-2370 p/ Cliente X" />
          </div>

          {/* Prioridade */}
          <div className="space-y-1.5">
            <Label className="text-sm font-medium">Prioridade</Label>
            <Select value={prioridade} onValueChange={setPrioridade}>
              <SelectTrigger className="w-full sm:w-1/2"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="NORMAL">Normal</SelectItem>
                <SelectItem value="URGENTE">Urgente</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Cliente */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <Label className="text-sm font-medium">Cliente</Label>
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <span className={clienteMode === 'manual' ? 'font-semibold text-foreground' : ''}>✏️ Manual</span>
                <Switch checked={clienteMode === 'base'} onCheckedChange={(v) => { setClienteMode(v ? 'base' : 'manual'); setClienteId(null); setClienteSearch(''); setClienteManual(''); }} className="scale-90" />
                <span className={clienteMode === 'base' ? 'font-semibold text-foreground' : ''}>👥 Base</span>
              </div>
            </div>
            {clienteMode === 'manual' ? (
              <Input value={clienteManual} onChange={(e) => setClienteManual(e.target.value)} placeholder="Ex: SIQUEIRA / CONSTRUTORA XYZ" />
            ) : (
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  value={clienteSearch}
                  onChange={(e) => { setClienteSearch(e.target.value); setClienteId(null); setShowClienteResults(true); }}
                  onFocus={() => setShowClienteResults(true)}
                  placeholder="Buscar cliente da base..."
                  className="pl-9"
                />
                {showClienteResults && clientesResults.length > 0 && !clienteId && (
                  <div className="absolute z-50 w-full mt-1 bg-popover border rounded-md shadow-md max-h-48 overflow-y-auto">
                    {clientesResults.map((c: any) => (
                      <button
                        key={c.id}
                        className="w-full text-left px-3 py-2 text-sm hover:bg-accent transition-colors"
                        onClick={() => selectCliente(c)}
                      >
                        {c.company_name}
                      </button>
                    ))}
                  </div>
                )}
                {clienteId && (
                  <p className="text-xs text-green-600 mt-1">✓ Cliente selecionado</p>
                )}
              </div>
            )}
          </div>

          {/* ============== ORDEM DIRETA FIELDS ============== */}
          {processType === 'ORDEM_DIRETA' && (
            <div className="space-y-4 p-4 rounded-lg border-2 border-emerald-200 bg-emerald-50/30">
              <div className="flex items-center gap-2 text-sm font-bold text-emerald-700">
                <ShoppingCart className="h-4 w-4" />
                Dados da Ordem Direta
              </div>

              {/* Produto */}
              <div className="space-y-1.5">
                <Label className="text-sm font-medium">Produto *</Label>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    value={ordemDiretaProdutoSearch}
                    onChange={(e) => { setOrdemDiretaProdutoSearch(e.target.value); setOrdemDiretaProdutoId(null); setShowOrdemProdutoResults(true); }}
                    onFocus={() => setShowOrdemProdutoResults(true)}
                    placeholder="Buscar produto..."
                    className="pl-9"
                  />
                  {showOrdemProdutoResults && ordemProdutoResults.length > 0 && !ordemDiretaProdutoId && (
                    <div className="absolute z-50 w-full mt-1 bg-popover border rounded-md shadow-md max-h-48 overflow-y-auto">
                      {ordemProdutoResults.map((p: any) => (
                        <button
                          key={p.id}
                          className="w-full text-left px-3 py-2 text-sm hover:bg-accent transition-colors"
                          onClick={() => selectOrdemProduto(p)}
                        >
                          <span className="font-medium">{p.name}</span>
                          {p.sku && <span className="text-muted-foreground ml-2 font-mono text-xs">{p.sku}</span>}
                          {p.is_homologated && <span className="ml-2 text-emerald-600 text-[10px]">✓ Homologado</span>}
                        </button>
                      ))}
                    </div>
                  )}
                  {ordemDiretaProdutoId && (
                    <div className="flex items-center gap-1 mt-1">
                      <CheckCircle2 className="h-3 w-3 text-green-600" />
                      <span className="text-xs text-green-600">Produto selecionado</span>
                      <button onClick={() => { setOrdemDiretaProdutoId(null); setOrdemDiretaProdutoSearch(''); }} className="ml-1">
                        <X className="h-3 w-3 text-muted-foreground" />
                      </button>
                    </div>
                  )}
                </div>

                {/* Eligibility check */}
                {ordemDiretaProdutoId && productEligibility?.eligible && (
                  <div className="flex items-start gap-2 p-2 rounded-md bg-emerald-50 text-emerald-700 text-xs">
                    <CheckCircle2 className="h-4 w-4 shrink-0 mt-0.5" />
                    <span>
                      {productEligibility.isHomologated && 'Produto homologado. '}
                      {productEligibility.hasHistory && `Último preço: ${formatCurrency(productEligibility.lastSupplier?.last_price || 0)} (${productEligibility.lastSupplier?.last_date || 'N/A'})`}
                    </span>
                  </div>
                )}
              </div>

              {/* Fornecedor */}
              <div className="space-y-1.5">
                <Label className="text-sm font-medium">Fornecedor {isComprador ? '*' : '(opcional)'}</Label>
                <Select value={ordemDiretaFornecedorId || ''} onValueChange={setOrdemDiretaFornecedorId}>
                  <SelectTrigger><SelectValue placeholder="Selecione o fornecedor" /></SelectTrigger>
                  <SelectContent>
                    {fornecedores.map((f: any) => (
                      <SelectItem key={f.id} value={f.id}>{f.razao_social}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Quantidade e Preço */}
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label className="text-sm font-medium">Quantidade *</Label>
                  <Input type="number" value={ordemDiretaQuantidade} onChange={(e) => setOrdemDiretaQuantidade(e.target.value)} min="1" />
                </div>
                <div className="space-y-1">
                  <Label className="text-sm font-medium">Preço Unitário (R$) *</Label>
                  <Input type="number" step="0.01" value={ordemDiretaPreco} onChange={(e) => setOrdemDiretaPreco(e.target.value)} min="0.01" />
                </div>
              </div>

              {/* Total */}
              {Number(ordemDiretaPreco) > 0 && Number(ordemDiretaQuantidade) > 0 && (
                <div className="text-sm font-medium text-right">
                  Total: <span className="text-emerald-700">{formatCurrency(Number(ordemDiretaPreco) * Number(ordemDiretaQuantidade))}</span>
                </div>
              )}

              {/* Observações */}
              <div className="space-y-1">
                <Label className="text-sm font-medium">Observações</Label>
                <Textarea value={ordemDiretaObs} onChange={(e) => setOrdemDiretaObs(e.target.value)} rows={2} className="resize-none" placeholder="Observações sobre a compra..." />
              </div>
            </div>
          )}

          {/* ============== COTAÇÃO FIELDS (existing) ============== */}
          {processType === 'COTACAO' && (
            <>
              {/* Prazo para Resposta */}
              <div className="space-y-1.5">
                <Label className="text-sm font-medium">Prazo para Resposta</Label>
                <Textarea value={prazoResposta} onChange={(e) => setPrazoResposta(e.target.value)} rows={2} className="resize-none" />
                <p className="text-xs text-muted-foreground">Quando espera retorno do comprador</p>
              </div>

              {/* Itens Solicitados */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label className="text-base font-bold">Itens Solicitados</Label>
                  <Button variant="outline" size="sm" className="gap-1.5 text-xs" onClick={addItem}>
                    <Plus className="h-3.5 w-3.5" />
                    Adicionar Item
                  </Button>
                </div>

                {itens.map((item, idx) => (
                  <div key={idx} className="rounded-lg border p-4 space-y-3 relative">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-semibold text-muted-foreground">Item {idx + 1}</span>
                      {itens.length > 1 && (
                        <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-destructive" onClick={() => removeItem(idx)}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      )}
                    </div>

                    <div className="space-y-1">
                      <Label className="text-sm font-medium">Descrição do Item *</Label>
                      <Input value={item.nome} onChange={(e) => updateItem(idx, 'nome', e.target.value)} placeholder="Nome do produto ou descrição livre" />
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <Label className="text-sm font-medium">Quantidade</Label>
                        <Input type="number" value={item.quantidade} onChange={(e) => updateItem(idx, 'quantidade', e.target.value)} placeholder="1" min="1" />
                      </div>
                      <div className="space-y-1">
                        <Label className="text-sm font-medium">Unidade</Label>
                        <Select value={item.unidade} onValueChange={(v) => updateItem(idx, 'unidade', v)}>
                          <SelectTrigger><SelectValue /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Unidade">Unidade</SelectItem>
                            <SelectItem value="Caixa">Caixa</SelectItem>
                            <SelectItem value="Pacote">Pacote</SelectItem>
                            <SelectItem value="Kg">Kg</SelectItem>
                            <SelectItem value="Metro">Metro</SelectItem>
                            <SelectItem value="Litro">Litro</SelectItem>
                            <SelectItem value="Resma">Resma</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="space-y-1">
                      <Label className="text-sm font-medium">Observações / Especificações</Label>
                      <PasteImageTextarea
                        value={item.especificacoes}
                        onChange={(val) => updateItem(idx, 'especificacoes', val)}
                        imagemUrl={item.imagemUrl}
                        onImageChange={(url) => updateItem(idx, 'imagemUrl', url)}
                        placeholder="Marca, modelo, observações... (cole uma imagem aqui)"
                      />
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}

          {/* Actions */}
          <div className="flex justify-end gap-2 pt-3 border-t">
            <Button variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
            <Button
              onClick={handleSubmit}
              disabled={create.isPending || (processType === 'ORDEM_DIRETA' && (!productEligibility?.eligible || !ordemDiretaProdutoId))}
              className={processType === 'ORDEM_DIRETA' ? 'bg-emerald-600 hover:bg-emerald-700' : ''}
            >
              {create.isPending ? 'Criando...' : processType === 'ORDEM_DIRETA' ? 'Criar Ordem Direta' : 'Criar Solicitação'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// =====================================================
// Textarea with paste-image support
// =====================================================
function PasteImageTextarea({ value, onChange, imagemUrl, onImageChange, placeholder }: {
  value: string;
  onChange: (v: string) => void;
  imagemUrl: string;
  onImageChange: (url: string) => void;
  placeholder?: string;
}) {
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const uploadImage = async (file: File) => {
    if (!file.type.startsWith('image/')) { toast.error('Apenas imagens'); return; }
    if (file.size > 5 * 1024 * 1024) { toast.error('Máx 5MB'); return; }
    setUploading(true);
    try {
      const ext = file.name?.split('.').pop() || 'png';
      const path = `solicitacao-${Date.now()}.${ext}`;
      const { error } = await supabase.storage.from('cotacao-images').upload(path, file, { upsert: true });
      if (error) throw error;
      const { data: urlData } = supabase.storage.from('cotacao-images').getPublicUrl(path);
      onImageChange(urlData.publicUrl);
      toast.success('Imagem anexada!');
    } catch (err: any) {
      toast.error(err.message || 'Erro ao enviar imagem');
    } finally {
      setUploading(false);
    }
  };

  const handlePaste = async (e: React.ClipboardEvent) => {
    const items = e.clipboardData?.items;
    if (!items) return;
    for (const item of Array.from(items)) {
      if (item.type.startsWith('image/')) {
        e.preventDefault();
        const file = item.getAsFile();
        if (file) await uploadImage(file);
        return;
      }
    }
  };

  return (
    <div className="space-y-2">
      <div
        className="relative border rounded-md bg-background focus-within:ring-2 focus-within:ring-ring focus-within:ring-offset-2"
        onPaste={handlePaste}
      >
        <textarea
          value={value}
          onChange={(e) => onChange(e.target.value)}
          rows={2}
          className="w-full resize-none px-3 py-2 text-sm bg-transparent outline-none placeholder:text-muted-foreground"
          placeholder={placeholder}
        />
        <div className="flex items-center gap-2 px-3 pb-2 border-t pt-1.5">
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-primary transition-colors"
          >
            <ImagePlus className="h-4 w-4" />
            <span>Anexar imagem</span>
          </button>
          {uploading && <span className="text-xs text-muted-foreground">Enviando...</span>}
        </div>
        <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) uploadImage(file);
          e.target.value = '';
        }} />
      </div>
      {imagemUrl && (
        <div className="relative inline-block">
          <img src={imagemUrl} alt="Referência" className="h-24 rounded-md border object-cover" />
          <button type="button" onClick={() => onImageChange('')} className="absolute -top-1.5 -right-1.5 bg-destructive text-destructive-foreground rounded-full p-0.5">
            <X className="h-3 w-3" />
          </button>
        </div>
      )}
    </div>
  );
}
