import { Card, CardContent } from '@/components/ui/card';
import { Phone, MessageCircle, Users, DollarSign, TrendingUp, AlertCircle } from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { motion } from 'framer-motion';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

interface SellerMetrics {
  // Realizados do dia
  actualCallsToday: number;
  actualWhatsappToday: number;
  actualContactsToday: number;
  actualSalesToday: number;
  
  // Metas do dia (padrão por nível)
  metaCallsToday: number;
  metaWhatsappToday: number;
  metaContactsToday: number;
  
  // Faltante do mês
  remainingCallsMonth: number;
  remainingWhatsappMonth: number;
  remainingContactsMonth: number;
  remainingSalesMonth: number;
  
  // Meta dinâmica "necessária por dia restante"
  neededCallsPerDayFromNow: number;
  neededWhatsappPerDayFromNow: number;
  neededContactsPerDayFromNow: number;
  neededSalesPerDayFromNow: number;
  
  // Dias úteis
  workingDays?: number;
  elapsedWorkdays?: number;
  remainingWorkdays?: number;
}

interface DailyScoreboardV2Props {
  metrics: SellerMetrics;
  isConfigured: boolean;
  onCallsCardClick?: () => void;
  onWhatsappCardClick?: () => void;
}

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1
    }
  }
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { 
    opacity: 1, 
    y: 0,
    transition: { duration: 0.3 }
  }
};

const formatCurrency = (value: number) => {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(value);
};

export function DailyScoreboardV2({ metrics, isConfigured, onCallsCardClick, onWhatsappCardClick }: DailyScoreboardV2Props) {
  if (!isConfigured) {
    return (
      <Card className="bg-yellow-500/10 border-yellow-500/30">
        <CardContent className="p-4 flex items-center gap-3">
          <AlertCircle className="h-5 w-5 text-yellow-500" />
          <div>
            <p className="text-sm font-medium">Dias úteis não configurados</p>
            <p className="text-xs text-muted-foreground">
              Configure os dias úteis do mês para exibir as metas corretamente.
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  const {
    actualCallsToday,
    actualWhatsappToday,
    actualContactsToday,
    actualSalesToday,
    metaCallsToday,
    metaWhatsappToday,
    metaContactsToday,
    remainingCallsMonth,
    remainingWhatsappMonth,
    neededCallsPerDayFromNow,
    neededWhatsappPerDayFromNow,
    neededSalesPerDayFromNow,
    remainingSalesMonth,
    remainingWorkdays = 1,
  } = metrics;

  const callsPercent = metaCallsToday > 0 ? Math.min(100, (actualCallsToday / metaCallsToday) * 100) : 0;
  const whatsappPercent = metaWhatsappToday > 0 ? Math.min(100, (actualWhatsappToday / metaWhatsappToday) * 100) : 0;
  const contactsPercent = metaContactsToday > 0 ? Math.min(100, (actualContactsToday / metaContactsToday) * 100) : 0;

  const callsComplete = actualCallsToday >= metaCallsToday;
  const whatsappComplete = actualWhatsappToday >= metaWhatsappToday;
  const contactsComplete = actualContactsToday >= metaContactsToday;

  return (
    <TooltipProvider>
      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="grid grid-cols-2 md:grid-cols-4 gap-3"
      >
        {/* Contatos (Total) */}
        <motion.div variants={itemVariants}>
          <Card className={`transition-all ${contactsComplete ? 'bg-green-500/10 border-green-500/30' : 'bg-card border-border'}`}>
            <CardContent className="p-3">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <div className={`p-1.5 rounded-md ${contactsComplete ? 'bg-green-500/20' : 'bg-primary/10'}`}>
                    <Users className={`h-4 w-4 ${contactsComplete ? 'text-green-500' : 'text-primary'}`} />
                  </div>
                  <span className="text-xs font-medium text-muted-foreground">Contatos</span>
                </div>
              </div>
              
              <div className="space-y-1.5">
                <div className="flex items-baseline justify-between">
                  <span className={`text-xl font-bold ${contactsComplete ? 'text-green-500' : 'text-foreground'}`}>
                    {actualContactsToday}
                  </span>
                  <span className="text-sm text-muted-foreground">/ {metaContactsToday}</span>
                </div>
                <Progress value={contactsPercent} className="h-2" />
                {contactsComplete ? (
                  <p className="text-xs text-green-600 font-medium">🎉 Meta do dia atingida!</p>
                ) : (
                  <p className="text-xs text-muted-foreground">
                    Faltam {metaContactsToday - actualContactsToday} hoje
                  </p>
                )}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Ligações */}
        <motion.div variants={itemVariants}>
          <Tooltip>
            <TooltipTrigger asChild>
              <Card 
                className={`transition-all cursor-pointer hover:shadow-md ${callsComplete ? 'bg-blue-500/10 border-blue-500/30' : 'bg-card border-border hover:border-blue-500/40'}`}
                onClick={onCallsCardClick}
              >
                <CardContent className="p-3">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div className={`p-1.5 rounded-md ${callsComplete ? 'bg-blue-500/20' : 'bg-blue-500/10'}`}>
                        <Phone className={`h-4 w-4 ${callsComplete ? 'text-blue-500' : 'text-blue-600'}`} />
                      </div>
                      <span className="text-xs font-medium text-muted-foreground">Ligações</span>
                    </div>
                  </div>
                  
                  <div className="space-y-1.5">
                    <div className="flex items-baseline justify-between">
                      <span className={`text-xl font-bold ${callsComplete ? 'text-blue-500' : 'text-foreground'}`}>
                        {actualCallsToday}
                      </span>
                      <span className="text-sm text-muted-foreground">/ {metaCallsToday}</span>
                    </div>
                    <Progress value={callsPercent} className="h-2" />
                    <p className="text-xs text-muted-foreground">
                      Faltam {remainingCallsMonth} no mês
                    </p>
                  </div>
                </CardContent>
              </Card>
            </TooltipTrigger>
            <TooltipContent>
              <div className="space-y-1">
                <p className="font-medium">Meta por nível: {metaCallsToday}/dia</p>
                <p>Necessário p/ bater mês: {neededCallsPerDayFromNow}/dia</p>
                <p className="text-xs text-muted-foreground">{remainingWorkdays} dias úteis restantes</p>
                <p className="text-xs text-blue-600 mt-1">Clique para ver detalhes</p>
              </div>
            </TooltipContent>
          </Tooltip>
        </motion.div>

        {/* WhatsApp */}
        <motion.div variants={itemVariants}>
          <Tooltip>
            <TooltipTrigger asChild>
              <Card 
                className={`transition-all cursor-pointer hover:shadow-md ${whatsappComplete ? 'bg-green-500/10 border-green-500/30' : 'bg-card border-border hover:border-green-500/40'}`}
                onClick={onWhatsappCardClick}
                role="button"
                tabIndex={0}
              >
                <CardContent className="p-3">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div className={`p-1.5 rounded-md ${whatsappComplete ? 'bg-green-500/20' : 'bg-green-500/10'}`}>
                        <MessageCircle className={`h-4 w-4 ${whatsappComplete ? 'text-green-500' : 'text-green-600'}`} />
                      </div>
                      <span className="text-xs font-medium text-muted-foreground">WhatsApp</span>
                    </div>
                  </div>
                  
                  <div className="space-y-1.5">
                    <div className="flex items-baseline justify-between">
                      <span className={`text-xl font-bold ${whatsappComplete ? 'text-green-500' : 'text-foreground'}`}>
                        {actualWhatsappToday}
                      </span>
                      <span className="text-sm text-muted-foreground">/ {metaWhatsappToday}</span>
                    </div>
                    <Progress value={whatsappPercent} className="h-2" />
                    <p className="text-xs text-muted-foreground">
                      Faltam {remainingWhatsappMonth} no mês
                    </p>
                  </div>
                </CardContent>
              </Card>
            </TooltipTrigger>
            <TooltipContent>
              <div className="space-y-1">
                <p className="font-medium">Meta por nível: {metaWhatsappToday}/dia</p>
                <p>Necessário p/ bater mês: {neededWhatsappPerDayFromNow}/dia</p>
                <p className="text-xs text-muted-foreground">{remainingWorkdays} dias úteis restantes</p>
                <p className="text-xs text-green-600 mt-1">Clique para ver detalhes</p>
              </div>
            </TooltipContent>
          </Tooltip>
        </motion.div>

        {/* Vendas */}
        <motion.div variants={itemVariants}>
          <Tooltip>
            <TooltipTrigger asChild>
              <Card className="transition-all cursor-help bg-card border-border hover:border-primary/30">
                <CardContent className="p-3">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div className="p-1.5 rounded-md bg-emerald-500/10">
                        <DollarSign className="h-4 w-4 text-emerald-600" />
                      </div>
                      <span className="text-xs font-medium text-muted-foreground">Vendas Hoje</span>
                    </div>
                  </div>
                  
                  <div className="space-y-1.5">
                    <div className="flex items-baseline">
                      <span className="text-xl font-bold text-foreground">
                        {formatCurrency(actualSalesToday)}
                      </span>
                    </div>
                    <div className="flex items-center gap-1 text-xs text-muted-foreground">
                      <TrendingUp className="h-3 w-3" />
                      <span>Necessário: {formatCurrency(neededSalesPerDayFromNow)}/dia</span>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Faltam {formatCurrency(remainingSalesMonth)} no mês
                    </p>
                  </div>
                </CardContent>
              </Card>
            </TooltipTrigger>
            <TooltipContent>
              <div className="space-y-1">
                <p className="font-medium">Meta diária necessária: {formatCurrency(neededSalesPerDayFromNow)}</p>
                <p>Faltam {formatCurrency(remainingSalesMonth)} para bater a meta</p>
                <p className="text-xs text-muted-foreground">{remainingWorkdays} dias úteis restantes</p>
              </div>
            </TooltipContent>
          </Tooltip>
        </motion.div>
      </motion.div>
    </TooltipProvider>
  );
}
