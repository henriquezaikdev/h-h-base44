import { useState, useEffect } from 'react';
import { Phone, MessageCircle, Check, Clock, AlertCircle, Pencil, Ban, MoreVertical, GripVertical } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { TodayTask, ContactReason } from '@/hooks/useActionCenterData';
import { useAuth } from '@/hooks/useAuth';
import { useSellersData } from '@/hooks/useSellersData';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

import { TaskUnifiedModal } from '@/components/tasks/TaskUnifiedModal';
import { CancelTaskModal } from '@/components/tasks/CancelTaskModal';
import { CONTACT_REASON_OPTIONS, TaskData } from '@/hooks/useTasksData';
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  useSortable,
  verticalListSortingStrategy,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

interface TodayTasksProps {
  todayTasks: TodayTask[];
  overdueTasks: TodayTask[];
  onTaskCompleted: () => void;
}

interface SortableTaskItemProps {
  task: TodayTask;
  isOverdue: boolean;
  onComplete: (task: TodayTask) => void;
  onEdit: (task: TodayTask) => void;
  onCancel: (task: TodayTask) => void;
}

const priorityConfig = {
  alta: { label: 'A', dot: 'bg-rose-500' },
  media: { label: 'M', dot: 'bg-amber-500' },
  baixa: { label: 'B', dot: 'bg-emerald-500' },
};

const getReasonConfig = (reason: ContactReason) => {
  return CONTACT_REASON_OPTIONS.find(r => r.value === reason) || CONTACT_REASON_OPTIONS[0];
};

function SortableTaskItem({ task, isOverdue, onComplete, onEdit, onCancel }: SortableTaskItemProps) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: task.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  const priority = priorityConfig[task.priority] || priorityConfig.media;
  const reasonConfig = getReasonConfig(task.contactReason);

  return (
    <div
      ref={setNodeRef}
      style={style}
      className={`group flex items-center gap-3 p-3 rounded-xl border transition-all duration-200 ${
        isOverdue 
          ? 'bg-rose-500/5 border-rose-500/20 hover:border-rose-500/30' 
          : 'bg-muted/20 border-transparent hover:bg-muted/40 hover:border-border/50'
      } ${isDragging ? 'opacity-50 shadow-xl z-10 scale-105' : ''}`}
    >
      {/* Drag handle */}
      <button
        {...attributes}
        {...listeners}
        className="cursor-grab active:cursor-grabbing p-1 text-muted-foreground/30 hover:text-muted-foreground touch-none transition-colors"
      >
        <GripVertical size={14} />
      </button>

      {/* Priority dot */}
      <div className={`w-1.5 h-8 rounded-full ${priority.dot}`} />

      {/* Contact type icon */}
      <div className={`p-2 rounded-lg ${
        task.contactType === 'whatsapp' 
          ? 'bg-emerald-500/10' 
          : 'bg-blue-500/10'
      }`}>
        {task.contactType === 'whatsapp' ? (
          <MessageCircle size={14} className="text-emerald-600" />
        ) : (
          <Phone size={14} className="text-blue-600" />
        )}
      </div>

      {/* Content - clickable to edit task */}
      <div 
        className="flex-1 min-w-0 cursor-pointer"
        onClick={() => onEdit(task)}
      >
        {/* Contact reason badge + client name */}
        <div className="flex items-center gap-2 flex-wrap">
          <Badge variant="outline" className={`text-[10px] px-1.5 py-0 ${reasonConfig.color}`}>
            {reasonConfig.label}
          </Badge>
          <span className="font-semibold text-sm text-foreground hover:text-primary truncate transition-colors">
            {task.clientName || (task.notes ? task.notes.split('\n')[0].slice(0, 60) : 'Tarefa Operacional')}
          </span>
        </div>
        <div className="flex items-center gap-2 text-xs text-muted-foreground mt-0.5">
          {task.taskTime && <span>{task.taskTime.slice(0, 5)}</span>}
          {task.notes && <span className="truncate max-w-[250px]">{task.notes}</span>}
        </div>
      </div>
      
      {/* Actions */}
      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
        <Button
          size="sm"
          variant="ghost"
          className="h-7 px-2 text-xs text-emerald-600 hover:bg-emerald-500/10"
          onClick={() => onComplete(task)}
        >
          <Check size={14} className="mr-1" />
          OK
        </Button>
        
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="h-7 w-7 p-0">
              <MoreVertical size={14} />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={() => onEdit(task)}>
              <Pencil size={12} className="mr-2" />
              Editar
            </DropdownMenuItem>
            <DropdownMenuItem
              className="text-amber-600"
              onClick={() => onCancel(task)}
            >
              <Ban size={12} className="mr-2" />
              Cancelar
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  );
}

// Helper to convert TodayTask to TaskData for TaskExecutionModal
function toTaskData(task: TodayTask): TaskData {
  return {
    id: task.id,
    clientId: task.clientId,
    clientName: task.clientName,
    clientRankingTier: 'geral',
    clientSellerId: null,
    contactType: task.contactType as 'ligacao' | 'whatsapp',
    contactReason: task.contactReason,
    taskDate: task.taskDate,
    taskTime: task.taskTime,
    notes: task.notes,
    status: task.status as 'pendente' | 'concluida',
    createdAt: task.taskDate || new Date().toISOString(), // fallback to prevent parseISO crash
    completedAt: null,
    createdBySellerId: null,
    priority: task.priority,
    temOrcamentoAberto: false,
    orcamentoCaCodigo: null,
    orcamentoValor: null,
    orcamentoAbertoEm: null,
  };
}

export function TodayTasks({ todayTasks: initialTodayTasks, overdueTasks: initialOverdueTasks, onTaskCompleted }: TodayTasksProps) {
  const { seller } = useAuth();
  const { sellers } = useSellersData();
  const [selectedTask, setSelectedTask] = useState<TaskData | null>(null);
  const [cancelingTask, setCancelingTask] = useState<TodayTask | null>(null);
  const [todayTasks, setTodayTasks] = useState<TodayTask[]>(initialTodayTasks);
  const [overdueTasks, setOverdueTasks] = useState<TodayTask[]>(initialOverdueTasks);

  // Sync with props when they change
  useEffect(() => {
    setTodayTasks(initialTodayTasks);
    setOverdueTasks(initialOverdueTasks);
  }, [initialTodayTasks, initialOverdueTasks]);

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8,
      },
    }),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  const handleDragEnd = (event: DragEndEvent, isOverdueList: boolean) => {
    const { active, over } = event;

    if (over && active.id !== over.id) {
      const taskList = isOverdueList ? overdueTasks : todayTasks;
      const setTaskList = isOverdueList ? setOverdueTasks : setTodayTasks;

      const oldIndex = taskList.findIndex((task) => task.id === active.id);
      const newIndex = taskList.findIndex((task) => task.id === over.id);

      setTaskList(arrayMove(taskList, oldIndex, newIndex));
    toast.success('Tarefas reordenadas');
    }
  };

  // Open task in execution modal (no longer navigates to client)
  const handleTaskClick = (task: TodayTask) => {
    setSelectedTask(toTaskData(task));
  };

  // Complete button also opens the execution modal
  const handleCompleteClick = (task: TodayTask) => {
    setSelectedTask(toTaskData(task));
  };

  const handleCancelTask = (task: TodayTask) => {
    setCancelingTask(task);
  };

  return (
    <>
      <div className="space-y-4">
        {/* Overdue Tasks */}
        {overdueTasks.length > 0 && (
          <div>
            <div className="flex items-center gap-2 mb-2">
              <div className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-pulse" />
              <h4 className="text-xs font-medium text-rose-600 uppercase tracking-wide">
                Atrasadas ({overdueTasks.length})
              </h4>
            </div>
            <DndContext
              sensors={sensors}
              collisionDetection={closestCenter}
              onDragEnd={(e) => handleDragEnd(e, true)}
            >
              <SortableContext items={overdueTasks.map(t => t.id)} strategy={verticalListSortingStrategy}>
                <div className="space-y-1.5">
                  {overdueTasks.map((task) => (
                    <SortableTaskItem
                      key={task.id}
                      task={task}
                      isOverdue={true}
                      onComplete={handleCompleteClick}
                      onEdit={handleTaskClick}
                      onCancel={handleCancelTask}
                    />
                  ))}
                </div>
              </SortableContext>
            </DndContext>
          </div>
        )}

        {/* Today's Tasks */}
        <div>
          <div className="flex items-center gap-2 mb-2">
            <div className="w-1.5 h-1.5 rounded-full bg-primary" />
            <h4 className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
              Hoje ({todayTasks.length})
            </h4>
          </div>
          {todayTasks.length > 0 ? (
            <DndContext
              sensors={sensors}
              collisionDetection={closestCenter}
              onDragEnd={(e) => handleDragEnd(e, false)}
            >
              <SortableContext items={todayTasks.map(t => t.id)} strategy={verticalListSortingStrategy}>
                <div className="space-y-1.5">
                  {todayTasks.map((task) => (
                    <SortableTaskItem
                      key={task.id}
                      task={task}
                      isOverdue={false}
                      onComplete={handleCompleteClick}
                      onEdit={handleTaskClick}
                      onCancel={handleCancelTask}
                    />
                  ))}
                </div>
              </SortableContext>
            </DndContext>
          ) : (
            <div className="flex flex-col items-center justify-center py-8 text-muted-foreground">
              <div className="w-10 h-10 rounded-full bg-muted/50 flex items-center justify-center mb-2">
                <Clock size={16} className="opacity-50" />
              </div>
              <p className="text-xs">Nenhuma tarefa para hoje</p>
            </div>
          )}
        </div>
      </div>

      {/* Task Execution Modal - unified planning + execution */}
      {selectedTask && (
        <TaskUnifiedModal
          open={!!selectedTask}
          onOpenChange={(open) => !open && setSelectedTask(null)}
          mode="edit"
          task={selectedTask}
          sellers={sellers}
          onCompleted={onTaskCompleted}
        />
      )}

      {/* Cancel Task Modal */}
      {cancelingTask && (
        <CancelTaskModal
          open={!!cancelingTask}
          onOpenChange={(open) => !open && setCancelingTask(null)}
          taskId={cancelingTask.id}
          clientName={cancelingTask.clientName}
          onCanceled={onTaskCompleted}
        />
      )}
    </>
  );
}
