import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { SellerRow } from '@/hooks/useSellersData';

interface SellerFilterProps {
  sellers: SellerRow[];
  selectedSellerId: string;
  onSellerChange: (sellerId: string) => void;
  loading?: boolean;
  includeAllOption?: boolean;
}

export function SellerFilter({
  sellers,
  selectedSellerId,
  onSellerChange,
  loading,
  includeAllOption = false,
}: SellerFilterProps) {
  return (
    <div className="flex items-center gap-2">
      <span className="text-sm text-muted-foreground">Colaborador:</span>
      <Select
        value={selectedSellerId}
        onValueChange={onSellerChange}
        disabled={loading}
      >
        <SelectTrigger className="w-[200px]">
          <SelectValue placeholder="Selecionar vendedor" />
        </SelectTrigger>
        <SelectContent>
          {includeAllOption && <SelectItem value="all">Todos os vendedores</SelectItem>}
          {sellers.map((seller) => (
            <SelectItem key={seller.id} value={seller.id}>
              {seller.name}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}
