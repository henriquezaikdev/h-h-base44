import { useState } from 'react';
import { Loader2, Save, AlertTriangle, CheckCircle, Target, Users, TrendingUp, ClipboardList } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { ScrollArea } from '@/components/ui/scroll-area';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { format, startOfMonth, endOfMonth, subMonths } from 'date-fns';

interface AIAnalysisModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  sellerId: string | undefined;
}

type Period = 'day' | 'month_current' | 'month_previous';

export const AIAnalysisModal = ({ open, onOpenChange, sellerId }: AIAnalysisModalProps) => {
  const [period, setPeriod] = useState<Period>('day');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);

  const gatherCRMData = async (selectedPeriod: Period) => {
    const today = format(new Date(), 'yyyy-MM-dd');
    const now = new Date();
    
    let startDate: string;
    let endDate: string;

    if (selectedPeriod === 'day') {
      startDate = today;
      endDate = today;
    } else if (selectedPeriod === 'month_current') {
      startDate = format(startOfMonth(now), 'yyyy-MM-dd');
      endDate = format(endOfMonth(now), 'yyyy-MM-dd');
    } else {
      const lastMonth = subMonths(now, 1);
      startDate = format(startOfMonth(lastMonth), 'yyyy-MM-dd');
      endDate = format(endOfMonth(lastMonth), 'yyyy-MM-dd');
    }

    // Fetch tasks
    const { data: tasks } = await supabase
      .from('tasks')
      .select('*')
      .gte('task_date', startDate)
      .lte('task_date', endDate);

    // Fetch clients with alerts
    const { data: clients } = await supabase
      .from('clients')
      .select('id, company_name, ranking_tier, days_since_last_order, last_contact_at, total_revenue, status');

    // Fetch orders for period
    const { data: orders } = await supabase
      .from('orders')
      .select('id, total, order_date, client_id')
      .gte('order_date', startDate)
      .lte('order_date', endDate);

    // Fetch lost quotes for period
    const { data: quotes } = await supabase
      .from('quotes')
      .select('id, total, quote_date, client_id')
      .gte('quote_date', startDate)
      .lte('quote_date', endDate);

    // Calculate metrics
    const tasksToday = tasks?.filter(t => t.task_date === today) || [];
    const tasksPendentes = tasksToday.filter(t => t.status === 'pendente');
    const tasksConcluidas = tasksToday.filter(t => t.status === 'concluida');
    
    const ligacoesConcluidas = tasksConcluidas.filter(t => t.contact_type === 'ligacao').length;
    const whatsappConcluidos = tasksConcluidas.filter(t => t.contact_type === 'whatsapp').length;

    // Clients needing attention
    const clientesSemContato15d = clients?.filter(c => {
      if (!c.last_contact_at) return true;
      const daysSinceContact = Math.floor((Date.now() - new Date(c.last_contact_at).getTime()) / (1000 * 60 * 60 * 24));
      return daysSinceContact >= 15;
    }) || [];

    const clientesInativos90d = clients?.filter(c => 
      c.days_since_last_order && c.days_since_last_order >= 90
    ) || [];

    const recorrentes45d = clients?.filter(c => 
      c.days_since_last_order && c.days_since_last_order >= 45 && c.days_since_last_order < 90
    ) || [];

    const topClients = clients?.filter(c => 
      c.ranking_tier === 'top20' || c.ranking_tier === 'top100' || c.ranking_tier === 'top200'
    ) || [];

    return {
      periodo: selectedPeriod === 'day' ? 'Hoje' : selectedPeriod === 'month_current' ? 'Mês Atual' : 'Mês Anterior',
      dataInicio: startDate,
      dataFim: endDate,
      tarefas: {
        total: tasks?.length || 0,
        pendentes: tasksPendentes.length,
        concluidas: tasksConcluidas.length,
        ligacoesConcluidas,
        whatsappConcluidos,
      },
      pedidos: {
        total: orders?.length || 0,
        valorTotal: orders?.reduce((sum, o) => sum + Number(o.total), 0) || 0,
      },
      orcamentosPerdidos: {
        total: quotes?.length || 0,
        valorTotal: quotes?.reduce((sum, q) => sum + Number(q.total), 0) || 0,
      },
      alertas: {
        clientesSemContato15dias: clientesSemContato15d.length,
        listaClientesSemContato: clientesSemContato15d.slice(0, 10).map(c => ({
          nome: c.company_name,
          ranking: c.ranking_tier,
        })),
        clientesInativos90dias: clientesInativos90d.length,
        listaInativos: clientesInativos90d.slice(0, 10).map(c => ({
          nome: c.company_name,
          diasSemPedido: c.days_since_last_order,
          ranking: c.ranking_tier,
        })),
        recorrentesSemPedido45dias: recorrentes45d.length,
        listaRecorrentes: recorrentes45d.slice(0, 10).map(c => ({
          nome: c.company_name,
          diasSemPedido: c.days_since_last_order,
          ranking: c.ranking_tier,
        })),
      },
      topClientes: {
        total: topClients.length,
        top20: topClients.filter(c => c.ranking_tier === 'top20').length,
        top100: topClients.filter(c => c.ranking_tier === 'top100').length,
        top200: topClients.filter(c => c.ranking_tier === 'top200').length,
      },
      totalClientes: clients?.length || 0,
    };
  };

  const handleAnalyze = async () => {
    if (!sellerId) {
      toast.error('Vendedor não identificado');
      return;
    }

    setLoading(true);
    setResult(null);

    try {
      const dataJson = await gatherCRMData(period);

      const { data, error } = await supabase.functions.invoke('perplexity-assistant', {
        body: {
          mode: 'analysis',
          period,
          sellerId,
          dataJson,
        },
      });

      if (error) throw error;

      setResult(data.answer);
      toast.success('Análise gerada com sucesso!');
    } catch (error) {
      console.error('Error calling AI:', error);
      toast.error('Erro ao gerar análise. Tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  const handleSave = () => {
    toast.success('Análise salva no histórico!');
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Target className="h-5 w-5 text-primary" />
            Análise do Desempenho
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Period Selection */}
          <div className="space-y-3">
            <Label className="text-sm font-medium">Período da análise:</Label>
            <RadioGroup 
              value={period} 
              onValueChange={(v) => setPeriod(v as Period)}
              className="flex flex-col gap-2"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="day" id="day" />
                <Label htmlFor="day" className="cursor-pointer">Análise do dia</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="month_current" id="month_current" />
                <Label htmlFor="month_current" className="cursor-pointer">Análise do mês atual</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="month_previous" id="month_previous" />
                <Label htmlFor="month_previous" className="cursor-pointer">Análise do mês anterior</Label>
              </div>
            </RadioGroup>
          </div>

          {/* Generate Button */}
          <Button 
            onClick={handleAnalyze} 
            disabled={loading}
            className="w-full gap-2"
          >
            {loading ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                Analisando dados do CRM...
              </>
            ) : (
              'Gerar análise'
            )}
          </Button>

          {/* Results */}
          {result && (
            <div className="space-y-4">
              <ScrollArea className="h-[400px] rounded-lg border bg-muted/30 p-4">
                <div className="prose prose-sm dark:prose-invert max-w-none">
                  {result.split('\n').map((line, i) => {
                    if (line.startsWith('**') && line.endsWith('**')) {
                      return (
                        <h4 key={i} className="font-semibold text-primary mt-4 mb-2 flex items-center gap-2">
                          {line.includes('DIAGNÓSTICO') && <CheckCircle className="h-4 w-4" />}
                          {line.includes('RISCOS') && <AlertTriangle className="h-4 w-4 text-amber-500" />}
                          {line.includes('AÇÕES') && <ClipboardList className="h-4 w-4" />}
                          {line.includes('CLIENTES') && <Users className="h-4 w-4" />}
                          {line.includes('FOCO') && <TrendingUp className="h-4 w-4" />}
                          {line.replace(/\*\*/g, '')}
                        </h4>
                      );
                    }
                    if (line.trim()) {
                      return <p key={i} className="text-sm text-foreground mb-2">{line}</p>;
                    }
                    return null;
                  })}
                </div>
              </ScrollArea>

              <Button 
                variant="outline" 
                onClick={handleSave}
                className="w-full gap-2"
              >
                <Save className="h-4 w-4" />
                Salvar no histórico
              </Button>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};
