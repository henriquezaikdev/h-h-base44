import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { Loader2, RefreshCw, Crown, TrendingDown, Clock, Package, ExternalLink, Phone, MessageCircle, AlertTriangle } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { format, differenceInDays } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { cn, calculateDaysSinceDate } from '@/lib/utils';

type AlertType = 'recurrent_no_order' | 'top_no_contact' | 'revenue_drop' | 'overdue_tasks' | 'replenishment_overdue' | 'entering_60days';

interface AlertDetailsModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  alertType: AlertType | null;
  sellerId?: string | null;
}

interface ClientAlert {
  id: string;
  companyName: string;
  details: string;
  secondaryInfo?: string;
  rankingTier?: string;
}

const alertConfig: Record<AlertType, { title: string; icon: React.ElementType; iconBg: string; iconColor: string }> = {
  entering_60days: { 
    title: 'Clientes Entrando em 60 dias (46-60 dias)', 
    icon: AlertTriangle,
    iconBg: 'bg-amber-500/20',
    iconColor: 'text-amber-600',
  },
  recurrent_no_order: { 
    title: 'Clientes sem Pedido (60+ dias)', 
    icon: RefreshCw,
    iconBg: 'bg-orange-500/10',
    iconColor: 'text-orange-600',
  },
  top_no_contact: { 
    title: 'Clientes Top sem Contato (15+ dias)', 
    icon: Crown,
    iconBg: 'bg-violet-500/10',
    iconColor: 'text-violet-600',
  },
  revenue_drop: { 
    title: 'Clientes com Queda de Faturamento (<70% média)', 
    icon: TrendingDown,
    iconBg: 'bg-rose-500/10',
    iconColor: 'text-rose-600',
  },
  overdue_tasks: { 
    title: 'Tarefas Atrasadas', 
    icon: Clock,
    iconBg: 'bg-orange-500/10',
    iconColor: 'text-orange-600',
  },
  replenishment_overdue: { 
    title: 'Clientes com Reposição em Atraso (5+ itens)', 
    icon: Package,
    iconBg: 'bg-red-500/10',
    iconColor: 'text-red-600',
  },
};

export function AlertDetailsModal({ open, onOpenChange, alertType, sellerId }: AlertDetailsModalProps) {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [clients, setClients] = useState<ClientAlert[]>([]);

  useEffect(() => {
    if (open && alertType) {
      fetchAlertDetails();
    }
  }, [open, alertType, sellerId]);

  const fetchAlertDetails = async () => {
    if (!alertType) return;
    
    setLoading(true);
    try {
      switch (alertType) {
        case 'entering_60days':
          await fetchEntering60Days();
          break;
        case 'recurrent_no_order':
          await fetchRecurrentNoOrder();
          break;
        case 'top_no_contact':
          await fetchTopNoContact();
          break;
        case 'revenue_drop':
          await fetchRevenueDropClients();
          break;
        case 'overdue_tasks':
          await fetchOverdueTasks();
          break;
        case 'replenishment_overdue':
          await fetchReplenishmentOverdue();
          break;
      }
    } finally {
      setLoading(false);
    }
  };

  const fetchEntering60Days = async () => {
    // Fetch clients with last_order_date and filter dynamically
    let query = supabase
      .from('clients')
      .select('id, company_name, last_order_date, ranking_tier')
      .eq('is_deleted', false)
      .not('last_order_date', 'is', null);

    if (sellerId) {
      query = query.eq('seller_id', sellerId);
    }

    const { data, error } = await query;
    if (error) throw error;

    // Filter dynamically for 46-60 days
    const filteredClients = (data || [])
      .map(c => ({
        ...c,
        dynamicDays: calculateDaysSinceDate(c.last_order_date)
      }))
      .filter(c => c.dynamicDays !== null && c.dynamicDays >= 46 && c.dynamicDays <= 60)
      .sort((a, b) => (b.dynamicDays || 0) - (a.dynamicDays || 0));

    setClients(filteredClients.map(c => ({
      id: c.id,
      companyName: c.company_name,
      details: `⚠️ ${c.dynamicDays || 0} dias sem pedido - AÇÃO URGENTE`,
      secondaryInfo: c.last_order_date 
        ? `Último pedido: ${format(new Date(c.last_order_date), 'dd/MM/yyyy', { locale: ptBR })}`
        : 'Sem pedidos registrados',
      rankingTier: c.ranking_tier,
    })));
  };

  const fetchRecurrentNoOrder = async () => {
    // Fetch clients with last_order_date and filter dynamically
    let query = supabase
      .from('clients')
      .select('id, company_name, last_order_date, classification, ranking_tier')
      .eq('is_deleted', false)
      .not('last_order_date', 'is', null);

    if (sellerId) {
      query = query.eq('seller_id', sellerId);
    }

    const { data, error } = await query;
    if (error) throw error;

    // Filter dynamically for > 60 days
    const filteredClients = (data || [])
      .map(c => ({
        ...c,
        dynamicDays: calculateDaysSinceDate(c.last_order_date)
      }))
      .filter(c => c.dynamicDays !== null && c.dynamicDays > 60)
      .sort((a, b) => (b.dynamicDays || 0) - (a.dynamicDays || 0));

    setClients(filteredClients.map(c => ({
      id: c.id,
      companyName: c.company_name,
      details: `${c.dynamicDays || 0} dias sem pedido`,
      secondaryInfo: c.last_order_date 
        ? `Último: ${format(new Date(c.last_order_date), 'dd/MM/yyyy', { locale: ptBR })}`
        : 'Sem pedidos',
      rankingTier: c.ranking_tier,
    })));
  };

  const fetchTopNoContact = async () => {
    const fifteenDaysAgo = new Date();
    fifteenDaysAgo.setDate(fifteenDaysAgo.getDate() - 15);

    let query = supabase
      .from('clients')
      .select('id, company_name, last_contact_at, ranking_tier')
      .eq('is_deleted', false)
      .in('ranking_tier', ['top20', 'top100'])
      .or(`last_contact_at.is.null,last_contact_at.lt.${fifteenDaysAgo.toISOString()}`)
      .order('last_contact_at', { ascending: true, nullsFirst: true });

    if (sellerId) {
      query = query.eq('seller_id', sellerId);
    }

    const { data, error } = await query;
    if (error) throw error;

    setClients((data || []).map(c => {
      const daysSince = c.last_contact_at 
        ? differenceInDays(new Date(), new Date(c.last_contact_at))
        : null;
      
      return {
        id: c.id,
        companyName: c.company_name,
        details: daysSince !== null ? `${daysSince} dias sem contato` : 'Nunca contatado',
        secondaryInfo: c.last_contact_at 
          ? `Último: ${format(new Date(c.last_contact_at), 'dd/MM/yyyy', { locale: ptBR })}`
          : undefined,
        rankingTier: c.ranking_tier,
      };
    }));
  };

  const fetchRevenueDropClients = async () => {
    // Fetch clients and calculate revenue drop
    const now = new Date();
    const currentMonth = now.getMonth() + 1;
    const currentYear = now.getFullYear();
    const lastMonth = currentMonth === 1 ? 12 : currentMonth - 1;
    const lastMonthYear = currentMonth === 1 ? currentYear - 1 : currentYear;
    
    let clientsQuery = supabase
      .from('clients')
      .select('id, company_name, ranking_tier')
      .eq('is_deleted', false);

    if (sellerId) {
      clientsQuery = clientsQuery.eq('seller_id', sellerId);
    }

    const { data: clientsData } = await clientsQuery;
    if (!clientsData) return;

    // Get orders for current and last month
    const startCurrentMonth = new Date(currentYear, currentMonth - 1, 1);
    const startLastMonth = new Date(lastMonthYear, lastMonth - 1, 1);
    const endLastMonth = new Date(currentYear, currentMonth - 1, 0);

    const clientIds = clientsData.map(c => c.id);
    
    const { data: ordersData } = await supabase
      .from('orders')
      .select('client_id, total, order_date')
      .in('client_id', clientIds)
      .gte('order_date', startLastMonth.toISOString().split('T')[0]);

    if (!ordersData) return;

    // Calculate monthly totals per client
    const clientTotals: Record<string, { current: number; last: number }> = {};
    
    ordersData.forEach(order => {
      const orderDate = new Date(order.order_date);
      const clientId = order.client_id;
      
      if (!clientTotals[clientId]) {
        clientTotals[clientId] = { current: 0, last: 0 };
      }

      if (orderDate >= startCurrentMonth) {
        clientTotals[clientId].current += order.total || 0;
      } else if (orderDate >= startLastMonth && orderDate <= endLastMonth) {
        clientTotals[clientId].last += order.total || 0;
      }
    });

    // Filter clients with 50%+ drop
    const droppedClients: ClientAlert[] = [];
    
    clientsData.forEach(client => {
      const totals = clientTotals[client.id];
      if (totals && totals.last > 0) {
        const dropPercent = ((totals.last - totals.current) / totals.last) * 100;
        if (dropPercent >= 50) {
          droppedClients.push({
            id: client.id,
            companyName: client.company_name,
            details: `Queda de ${dropPercent.toFixed(0)}%`,
            secondaryInfo: `R$ ${totals.last.toLocaleString('pt-BR')} → R$ ${totals.current.toLocaleString('pt-BR')}`,
            rankingTier: client.ranking_tier,
          });
        }
      }
    });

    setClients(droppedClients.sort((a, b) => {
      const aPercent = parseInt(a.details.match(/\d+/)?.[0] || '0');
      const bPercent = parseInt(b.details.match(/\d+/)?.[0] || '0');
      return bPercent - aPercent;
    }));
  };

  const fetchOverdueTasks = async () => {
    // Use São Paulo timezone for today's date
    const today = new Intl.DateTimeFormat('sv-SE', {
      timeZone: 'America/Sao_Paulo',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    }).format(new Date());
    
    let query = supabase
      .from('tasks')
      .select(`
        id,
        task_date,
        contact_type,
        clients!inner(id, company_name, ranking_tier)
      `)
      .eq('status', 'pendente')
      .lt('task_date', today)
      .order('task_date', { ascending: true });

    if (sellerId) {
      query = query.eq('created_by_seller_id', sellerId);
    }

    const { data, error } = await query;
    if (error) throw error;

    setClients((data || []).map(t => {
      const daysOverdue = differenceInDays(new Date(), new Date(t.task_date));
      const client = t.clients as any;
      
      return {
        id: client.id,
        companyName: client.company_name,
        details: `${daysOverdue} dia${daysOverdue > 1 ? 's' : ''} de atraso`,
        secondaryInfo: t.contact_type === 'ligacao' ? 'Ligação' : 'WhatsApp',
        rankingTier: client.ranking_tier,
      };
    }));
  };

  const fetchReplenishmentOverdue = async () => {
    // Similar logic to useReplenishmentAlerts but return client list
    let clientsQuery = supabase
      .from('clients')
      .select('id, company_name, ranking_tier')
      .eq('is_deleted', false);

    if (sellerId) {
      clientsQuery = clientsQuery.eq('seller_id', sellerId);
    }

    const { data: clientsData } = await clientsQuery;
    if (!clientsData) return;

    const clientIds = clientsData.map(c => c.id);

    // Fetch orders with items for these clients
    const { data: ordersData } = await supabase
      .from('orders')
      .select(`
        client_id,
        order_date,
        order_items!inner(product_name)
      `)
      .in('client_id', clientIds)
      .order('order_date', { ascending: false });

    if (!ordersData) return;

    // Group purchases by client and product
    const clientProducts: Record<string, Record<string, Date[]>> = {};
    
    ordersData.forEach(order => {
      const clientId = order.client_id;
      if (!clientProducts[clientId]) {
        clientProducts[clientId] = {};
      }
      
      const items = order.order_items as any[];
      items.forEach(item => {
        const productName = item.product_name;
        if (!clientProducts[clientId][productName]) {
          clientProducts[clientId][productName] = [];
        }
        clientProducts[clientId][productName].push(new Date(order.order_date));
      });
    });

    // Calculate overdue items per client
    const clientAlerts: ClientAlert[] = [];
    const today = new Date();

    clientsData.forEach(client => {
      const products = clientProducts[client.id] || {};
      let overdueCount = 0;

      Object.entries(products).forEach(([_, dates]) => {
        if (dates.length < 2) return;
        
        // Calculate average interval
        const sortedDates = dates.sort((a, b) => a.getTime() - b.getTime());
        let totalInterval = 0;
        for (let i = 1; i < sortedDates.length; i++) {
          totalInterval += differenceInDays(sortedDates[i], sortedDates[i - 1]);
        }
        const avgInterval = totalInterval / (sortedDates.length - 1);
        
        // Check if overdue
        const lastPurchase = sortedDates[sortedDates.length - 1];
        const daysSince = differenceInDays(today, lastPurchase);
        
        if (daysSince > avgInterval) {
          overdueCount++;
        }
      });

      if (overdueCount >= 5) {
        clientAlerts.push({
          id: client.id,
          companyName: client.company_name,
          details: `${overdueCount} itens em atraso`,
          secondaryInfo: 'Reposição necessária',
          rankingTier: client.ranking_tier,
        });
      }
    });

    setClients(clientAlerts.sort((a, b) => {
      const aCount = parseInt(a.details.match(/\d+/)?.[0] || '0');
      const bCount = parseInt(b.details.match(/\d+/)?.[0] || '0');
      return bCount - aCount;
    }));
  };

  const handleClientClick = (clientId: string) => {
    onOpenChange(false);
    navigate(`/clients/${clientId}`);
  };

  const getRankingBadge = (tier?: string) => {
    switch (tier) {
      case 'top20':
        return <Badge variant="outline" className="bg-amber-500/10 text-amber-600 border-amber-500/30">🏆 Top 20</Badge>;
      case 'top100':
        return <Badge variant="outline" className="bg-slate-500/10 text-slate-600 border-slate-500/30">🥈 Top 100</Badge>;
      case 'top200':
        return <Badge variant="outline" className="bg-orange-500/10 text-orange-600 border-orange-500/30">🥉 Top 200</Badge>;
      case 'top300':
        return <Badge variant="outline" className="bg-purple-500/10 text-purple-600 border-purple-500/30">📊 Top 300</Badge>;
      default:
        return null;
    }
  };

  if (!alertType) return null;

  const config = alertConfig[alertType];
  const Icon = config.icon;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[80vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-3">
            <div className={cn("p-2 rounded-lg", config.iconBg)}>
              <Icon className={cn("h-5 w-5", config.iconColor)} />
            </div>
            {config.title}
          </DialogTitle>
        </DialogHeader>

        {loading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="animate-spin h-8 w-8 text-primary" />
          </div>
        ) : clients.length === 0 ? (
          <div className="text-center py-12">
            <Icon className={cn("h-12 w-12 mx-auto mb-4 opacity-30", config.iconColor)} />
            <p className="text-muted-foreground">Nenhum cliente encontrado para este alerta</p>
          </div>
        ) : (
          <ScrollArea className="max-h-[60vh] pr-4">
            <div className="space-y-2">
              {clients.map((client) => (
                <div
                  key={client.id}
                  onClick={() => handleClientClick(client.id)}
                  className="group p-4 rounded-lg border bg-card hover:bg-muted/50 cursor-pointer transition-all hover:shadow-sm"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <p className="font-medium text-foreground truncate">
                          {client.companyName}
                        </p>
                        {getRankingBadge(client.rankingTier)}
                      </div>
                      <div className="flex items-center gap-2 mt-1 text-sm">
                        <span className={cn(
                          "font-medium",
                          alertType === 'revenue_drop' && "text-rose-600",
                          alertType === 'replenishment_overdue' && "text-red-600",
                          alertType === 'overdue_tasks' && "text-orange-600",
                          alertType === 'top_no_contact' && "text-violet-600",
                          alertType === 'recurrent_no_order' && "text-amber-600",
                        )}>
                          {client.details}
                        </span>
                        {client.secondaryInfo && (
                          <>
                            <span className="text-muted-foreground">•</span>
                            <span className="text-muted-foreground">{client.secondaryInfo}</span>
                          </>
                        )}
                      </div>
                    </div>
                    <ExternalLink className="h-4 w-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>
        )}

        <div className="flex items-center justify-between pt-4 border-t">
          <p className="text-sm text-muted-foreground">
            {clients.length} cliente{clients.length !== 1 ? 's' : ''} encontrado{clients.length !== 1 ? 's' : ''}
          </p>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Fechar
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
