import { useState } from 'react';
import { Bot, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { AIUnifiedModal } from './AIUnifiedModal';

interface AIAssistantCardProps {
  sellerId: string | undefined;
}

export const AIAssistantCard = ({ sellerId }: AIAssistantCardProps) => {
  const [modalOpen, setModalOpen] = useState(false);

  return (
    <>
      <div className="group relative overflow-hidden rounded-2xl border border-border/50 bg-gradient-to-r from-primary/5 via-transparent to-transparent p-4 transition-all duration-300 hover:border-primary/30 hover:shadow-lg hover:shadow-primary/5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-primary/10 rounded-xl transition-transform duration-300 group-hover:scale-110">
              <Bot className="h-5 w-5 text-primary" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-medium text-foreground">Assistente IA</h3>
                <span className="flex items-center gap-1 text-[10px] text-emerald-600 bg-emerald-500/10 px-1.5 py-0.5 rounded-md">
                  <span className="w-1 h-1 rounded-full bg-emerald-500 animate-pulse" />
                  Online
                </span>
              </div>
              <p className="text-xs text-muted-foreground mt-0.5">Análises e orientações H&H</p>
            </div>
          </div>
          
          <Button 
            onClick={() => setModalOpen(true)}
            className="gap-2 bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg shadow-primary/20"
          >
            <Sparkles className="h-4 w-4" />
            Abrir IA
          </Button>
        </div>
        
        {/* Subtle animated gradient */}
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-primary/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-700 -translate-x-full group-hover:translate-x-full pointer-events-none" />
      </div>

      <AIUnifiedModal 
        open={modalOpen} 
        onOpenChange={setModalOpen}
        sellerId={sellerId}
      />
    </>
  );
};
