import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuotesData } from '@/hooks/useQuotesData';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { FileX2, Loader2, Calendar, User, DollarSign, Building2, Eye } from 'lucide-react';
import { format, parseISO, startOfMonth, endOfMonth, startOfDay, endOfDay } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { QuoteDetailsModal } from './QuoteDetailsModal';

interface LostQuotesTabProps {
  sellerId?: string | null;
  isAdmin?: boolean;
  sellers?: { id: string; name: string }[];
  onSellerChange?: (sellerId: string | null) => void;
}

const RANKING_CONFIG: Record<string, { label: string; className: string }> = {
  top20: { label: 'Top 20', className: 'bg-amber-500/10 text-amber-600 border-amber-500/20' },
  top100: { label: 'Top 100', className: 'bg-blue-500/10 text-blue-600 border-blue-500/20' },
  top200: { label: 'Top 200', className: 'bg-purple-500/10 text-purple-600 border-purple-500/20' },
  eventual: { label: 'Eventual', className: 'bg-gray-500/10 text-gray-600 border-gray-500/20' },
  geral: { label: 'Sem ranking', className: 'bg-gray-500/10 text-gray-500 border-gray-500/20' },
};

export function LostQuotesTab({ sellerId, isAdmin, sellers, onSellerChange }: LostQuotesTabProps) {
  const navigate = useNavigate();
  const { quotes, loading } = useQuotesData(sellerId);
  const [periodFilter, setPeriodFilter] = useState<string>('mes');
  const [selectedQuoteId, setSelectedQuoteId] = useState<string | null>(null);

  const filteredQuotes = useMemo(() => {
    const now = new Date();
    
    return quotes.filter(q => {
      const quoteDate = parseISO(q.quoteDate);
      
      if (periodFilter === 'hoje') {
        return quoteDate >= startOfDay(now) && quoteDate <= endOfDay(now);
      } else if (periodFilter === 'mes') {
        return quoteDate >= startOfMonth(now) && quoteDate <= endOfMonth(now);
      }
      return true;
    });
  }, [quotes, periodFilter]);

  const totalValue = useMemo(() => {
    return filteredQuotes.reduce((sum, q) => sum + q.total, 0);
  }, [filteredQuotes]);

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
  };

  if (loading) {
    return (
      <div className="flex justify-center py-12">
        <Loader2 className="animate-spin h-8 w-8 text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Filters */}
      <div className="flex flex-wrap items-center gap-4">
        <div className="flex items-center gap-2">
          <Calendar size={16} className="text-muted-foreground" />
          <Select value={periodFilter} onValueChange={setPeriodFilter}>
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="hoje">Hoje</SelectItem>
              <SelectItem value="mes">Mês Atual</SelectItem>
              <SelectItem value="todos">Todos</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {isAdmin && sellers && onSellerChange && (
          <div className="flex items-center gap-2">
            <User size={16} className="text-muted-foreground" />
            <Select 
              value={sellerId || 'all'} 
              onValueChange={(v) => onSellerChange(v === 'all' ? null : v)}
            >
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Todos vendedores" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos vendedores</SelectItem>
                {sellers.map(s => (
                  <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}

        {/* Summary */}
        <div className="ml-auto flex items-center gap-4 bg-red-50 dark:bg-red-950/30 px-4 py-2 rounded-lg border border-red-200 dark:border-red-800">
          <div className="text-center">
            <p className="text-2xl font-bold text-red-600">{filteredQuotes.length}</p>
            <p className="text-xs text-red-500">Orçamentos</p>
          </div>
          <div className="w-px h-8 bg-red-200 dark:bg-red-800" />
          <div className="text-center">
            <p className="text-2xl font-bold text-red-600">{formatCurrency(totalValue)}</p>
            <p className="text-xs text-red-500">Valor Total Perdido</p>
          </div>
        </div>
      </div>

      {/* Quotes List */}
      {filteredQuotes.length === 0 ? (
        <div className="card-section text-center py-12">
          <FileX2 className="h-12 w-12 text-muted-foreground/50 mx-auto mb-4" />
          <p className="text-lg font-medium text-foreground">Nenhum orçamento perdido</p>
          <p className="text-muted-foreground mt-1">
            Não há orçamentos perdidos {periodFilter === 'hoje' ? 'hoje' : periodFilter === 'mes' ? 'neste mês' : ''}.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredQuotes.map((quote) => {
            const rankingConfig = RANKING_CONFIG[quote.clientRankingTier] || RANKING_CONFIG.geral;
            
            return (
              <div
                key={quote.id}
                className="rounded-lg border border-red-200 dark:border-red-800 bg-red-50/50 dark:bg-red-950/20 transition-all hover:shadow-md hover:border-red-300"
              >
                <div className="flex items-center justify-between p-4">
                  <div 
                    className="flex items-center gap-4 flex-1 cursor-pointer"
                    onClick={() => navigate(`/clients/${quote.clientId}`)}
                  >
                    <div className="w-11 h-11 rounded-lg bg-red-100 dark:bg-red-900/50 flex items-center justify-center">
                      <FileX2 className="h-5 w-5 text-red-600" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="font-semibold text-foreground">{quote.clientName}</p>
                        <Badge variant="outline" className={`text-[10px] px-1.5 py-0 h-5 ${rankingConfig.className}`}>
                          {rankingConfig.label}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-3 text-sm text-muted-foreground mt-0.5">
                        <span className="flex items-center gap-1">
                          <Calendar className="h-3.5 w-3.5" />
                          {format(parseISO(quote.quoteDate), "dd/MM/yyyy", { locale: ptBR })}
                        </span>
                        {quote.sellerName && (
                          <span className="flex items-center gap-1">
                            <User className="h-3.5 w-3.5" />
                            {quote.sellerName}
                          </span>
                        )}
                        <span>Orçamento #{quote.quoteNumber}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <p className="text-lg font-bold text-red-600">{formatCurrency(quote.total)}</p>
                      <Badge variant="destructive" className="text-xs">PERDIDO</Badge>
                    </div>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedQuoteId(quote.id);
                      }}
                    >
                      <Eye className="h-4 w-4 mr-1" />
                      Ver Detalhes
                    </Button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Quote Details Modal */}
      <QuoteDetailsModal 
        open={!!selectedQuoteId}
        onOpenChange={(open) => !open && setSelectedQuoteId(null)}
        quoteId={selectedQuoteId}
      />
    </div>
  );
}
