import { RefreshCw, Crown, TrendingDown, Clock, Package, AlertTriangle } from 'lucide-react';
import { CriticalAlert } from '@/hooks/useActionCenterData';
import { motion } from 'framer-motion';

interface CriticalAlertsProps {
  alerts: CriticalAlert[];
  onAlertClick: (type: string) => void;
}

const alertConfig: Record<string, { icon: any }> = {
  entering_60days: { icon: AlertTriangle },
  recurrent_no_order: { icon: RefreshCw },
  top_no_contact: { icon: Crown },
  revenue_drop: { icon: TrendingDown },
  overdue_tasks: { icon: Clock },
  replenishment_overdue: { icon: Package },
};

export function CriticalAlerts({ alerts, onAlertClick }: CriticalAlertsProps) {
  const sortedAlerts = [...alerts].sort((a, b) => {
    if (a.type === 'entering_60days' && a.count > 0) return -1;
    if (b.type === 'entering_60days' && b.count > 0) return 1;
    return 0;
  });

  return (
    <motion.div 
      className="grid grid-cols-2 lg:grid-cols-5 gap-4"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
    >
      {sortedAlerts.map((alert) => {
        const config = alertConfig[alert.type] || alertConfig.overdue_tasks;
        const Icon = config.icon;
        const isUrgent = alert.type === 'entering_60days' && alert.count > 0;
        
        return (
          <button
            key={alert.id}
            onClick={() => onAlertClick(alert.type)}
            className="relative flex items-center gap-3 p-4 rounded-xl transition-all text-left bg-card border border-border shadow-hh-sm hover:shadow-hh-md hover:border-border/80"
          >
            {isUrgent && (
              <div className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full animate-pulse bg-destructive" />
            )}
            <Icon size={16} className="shrink-0 text-muted-foreground" />
            <div className="flex-1 min-w-0">
              <p className={`text-[22px] font-semibold leading-none ${
                alert.count > 0 ? (isUrgent ? 'text-destructive' : 'text-primary') : 'text-foreground'
              }`}>
                {alert.count}
              </p>
              <p className="text-[11px] truncate mt-1 text-muted-foreground">{alert.label}</p>
            </div>
          </button>
        );
      })}
    </motion.div>
  );
}
