import { useState, useEffect } from 'react';
import { Loader2, Copy, CheckCircle, Trash2, History, Clock, ChevronRight, RotateCcw, Maximize2, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { format, startOfMonth, endOfMonth, subMonths, startOfWeek, endOfWeek } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { useAuth } from '@/hooks/useAuth';

interface AIHHTabProps {
  sellerId: string | undefined;
}

type Mode = 'analysis' | 'consultation' | 'manager_panel';
type AnalysisPeriod = 'day' | 'month_current' | 'month_previous';
type ManagerPeriod = 'today' | 'week' | 'month_current' | 'month_previous';
type ViewTab = 'new' | 'history';

interface StructuredResult {
  mapaRapido: string;
  diagnostico: string;
  acoes: string;
  alertas: string;
  proximosPassos: string;
}

interface ParsedResult {
  diagnostico: string;
  acoes: string[];
  atencao: string[];
  proximoPasso: string;
}

interface AILogEntry {
  id: string;
  mode: string;
  period: string | null;
  output_text: string;
  created_at: string;
}

// Perplexity Logo SVG Component
const PerplexityLogo = () => (
  <svg width="28" height="28" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M12 2L2 7L12 12L22 7L12 2Z" fill="#20808D"/>
    <path d="M2 17L12 22L22 17" stroke="#20808D" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M2 12L12 17L22 12" stroke="#20808D" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

export const AIHHTab = ({ sellerId }: AIHHTabProps) => {
  const { isAdminOrOwner } = useAuth();
  const [viewTab, setViewTab] = useState<ViewTab>('new');
  const [mode, setMode] = useState<Mode>('analysis');
  const [analysisPeriod, setAnalysisPeriod] = useState<AnalysisPeriod | null>(null);
  const [managerPeriod, setManagerPeriod] = useState<ManagerPeriod>('month_current');
  const [contextText, setContextText] = useState('');
  const [managerQuery, setManagerQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [structuredResult, setStructuredResult] = useState<StructuredResult | null>(null);
  const [copied, setCopied] = useState(false);
  const [history, setHistory] = useState<AILogEntry[]>([]);
  const [historyLoading, setHistoryLoading] = useState(false);
  const [selectedHistoryItem, setSelectedHistoryItem] = useState<AILogEntry | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [fullscreenOpen, setFullscreenOpen] = useState(false);

  useEffect(() => {
    if (viewTab === 'history') {
      fetchHistory();
    }
  }, [viewTab, sellerId]);

  const fetchHistory = async () => {
    if (!sellerId) return;
    
    setHistoryLoading(true);
    try {
      const { data, error } = await supabase
        .from('ai_logs')
        .select('id, mode, period, output_text, created_at')
        .order('created_at', { ascending: false })
        .limit(50);

      if (error) throw error;
      setHistory(data || []);
    } catch (error) {
      console.error('Error fetching AI history:', error);
      toast.error('Erro ao carregar histórico');
    } finally {
      setHistoryLoading(false);
    }
  };

  const gatherCRMData = async (period: string) => {
    const now = new Date();
    let startDate: string;
    let endDate: string;

    switch (period) {
      case 'day':
      case 'today':
        startDate = format(now, 'yyyy-MM-dd');
        endDate = format(now, 'yyyy-MM-dd');
        break;
      case 'week':
        startDate = format(startOfWeek(now, { weekStartsOn: 1 }), 'yyyy-MM-dd');
        endDate = format(endOfWeek(now, { weekStartsOn: 1 }), 'yyyy-MM-dd');
        break;
      case 'month_current':
        startDate = format(startOfMonth(now), 'yyyy-MM-dd');
        endDate = format(endOfMonth(now), 'yyyy-MM-dd');
        break;
      case 'month_previous':
        const lastMonth = subMonths(now, 1);
        startDate = format(startOfMonth(lastMonth), 'yyyy-MM-dd');
        endDate = format(endOfMonth(lastMonth), 'yyyy-MM-dd');
        break;
      default:
        startDate = format(startOfMonth(now), 'yyyy-MM-dd');
        endDate = format(endOfMonth(now), 'yyyy-MM-dd');
    }

    const today = format(now, 'yyyy-MM-dd');

    // Fetch all data in parallel
    const [
      { data: tasks },
      { data: clients },
      { data: orders },
      { data: quotes },
      { data: sellers },
      { data: interactions },
    ] = await Promise.all([
      supabase.from('tasks').select('*').gte('task_date', startDate).lte('task_date', endDate),
      supabase.from('clients').select('id, company_name, ranking_tier, days_since_last_order, last_contact_at, total_revenue, status, seller_id').eq('is_deleted', false),
      supabase.from('orders').select('id, total, order_date, client_id, seller_id').gte('order_date', startDate).lte('order_date', endDate),
      supabase.from('quotes').select('id, total, quote_date, client_id, status').gte('quote_date', startDate).lte('quote_date', endDate),
      supabase.from('sellers').select('id, name, role').or('status.eq.ATIVO,status.is.null'),
      supabase.from('interactions').select('id, interaction_type, responsible_seller_id, client_id').gte('interaction_date', startDate).lte('interaction_date', endDate),
    ]);

    // Calculate metrics
    const tasksToday = tasks?.filter(t => t.task_date === today) || [];
    const tasksPendentes = tasksToday.filter(t => t.status === 'pendente');
    const tasksConcluidas = tasksToday.filter(t => t.status === 'concluida');
    
    const ligacoesConcluidas = tasksConcluidas.filter(t => t.contact_type === 'ligacao').length;
    const whatsappConcluidos = tasksConcluidas.filter(t => t.contact_type === 'whatsapp').length;

    // Client alerts
    const clientesSemContato15d = clients?.filter(c => {
      if (!c.last_contact_at) return true;
      const daysSinceContact = Math.floor((Date.now() - new Date(c.last_contact_at).getTime()) / (1000 * 60 * 60 * 24));
      return daysSinceContact >= 15;
    }) || [];

    const clientesInativos90d = clients?.filter(c => 
      c.days_since_last_order && c.days_since_last_order >= 90
    ) || [];

    const recorrentes45d = clients?.filter(c => 
      c.days_since_last_order && c.days_since_last_order >= 45 && c.days_since_last_order < 90
    ) || [];

    // Client ranking
    const sortedClients = [...(clients || [])].sort((a, b) => (b.total_revenue || 0) - (a.total_revenue || 0));
    const top20Clients = sortedClients.slice(0, 20);
    const top100Clients = sortedClients.slice(0, 100);
    const top200Clients = sortedClients.slice(0, 200);

    const totalRevenue = sortedClients.reduce((sum, c) => sum + (c.total_revenue || 0), 0);
    const top20Revenue = top20Clients.reduce((sum, c) => sum + (c.total_revenue || 0), 0);
    const top100Revenue = top100Clients.reduce((sum, c) => sum + (c.total_revenue || 0), 0);
    const top20Concentration = totalRevenue > 0 ? (top20Revenue / totalRevenue) * 100 : 0;
    const top100Concentration = totalRevenue > 0 ? (top100Revenue / totalRevenue) * 100 : 0;

    // Seller metrics
    const sellerMetrics = sellers?.map(seller => {
      const sellerInteractions = interactions?.filter(i => i.responsible_seller_id === seller.id) || [];
      const sellerOrders = orders?.filter(o => o.seller_id === seller.id) || [];
      const sellerTasks = tasks?.filter(t => t.created_by_seller_id === seller.id) || [];
      const sellerClients = clients?.filter(c => c.seller_id === seller.id) || [];

      const ligacoes = sellerInteractions.filter(i => 
        i.interaction_type?.toLowerCase().includes('ligaç') || 
        i.interaction_type?.toLowerCase().includes('ligac') ||
        i.interaction_type?.toLowerCase() === 'call'
      ).length;
      
      const whatsapp = sellerInteractions.filter(i => 
        i.interaction_type?.toLowerCase().includes('whatsapp') ||
        i.interaction_type?.toLowerCase().includes('whats')
      ).length;
      
      const emails = sellerInteractions.filter(i => 
        i.interaction_type?.toLowerCase().includes('email') ||
        i.interaction_type?.toLowerCase().includes('e-mail')
      ).length;

      const total_contatos = sellerInteractions.length;
      const total_pedidos = sellerOrders.length;
      const faturamento = sellerOrders.reduce((sum, o) => sum + Number(o.total || 0), 0);
      const ticket_medio = total_pedidos > 0 ? faturamento / total_pedidos : 0;

      const tarefas_concluidas = sellerTasks.filter(t => t.status === 'concluida').length;
      const tarefas_pendentes = sellerTasks.filter(t => t.status === 'pendente').length;
      const total_tarefas = sellerTasks.length;
      const perc_execucao = total_tarefas > 0 ? (tarefas_concluidas / total_tarefas) * 100 : 0;

      return {
        nome: seller.name,
        cargo: seller.role,
        contatos: { ligacoes, whatsapp, emails, total: total_contatos },
        vendas: { pedidos: total_pedidos, faturamento, ticket_medio },
        tarefas: { concluidas: tarefas_concluidas, pendentes: tarefas_pendentes, taxa_execucao: perc_execucao },
        carteira: { total_clientes: sellerClients.length },
      };
    }) || [];

    const periodLabels: Record<string, string> = {
      day: 'Hoje',
      today: 'Hoje',
      week: 'Esta Semana',
      month_current: 'Mês Atual',
      month_previous: 'Mês Anterior',
    };

    return {
      periodo: periodLabels[period] || 'Período',
      dataInicio: startDate,
      dataFim: endDate,
      
      resumo: {
        totalClientes: clients?.length || 0,
        totalVendedores: sellers?.length || 0,
        pedidosNoPeriodo: orders?.length || 0,
        faturamentoNoPeriodo: orders?.reduce((sum, o) => sum + Number(o.total), 0) || 0,
        contatosNoPeriodo: interactions?.length || 0,
      },

      tarefas: {
        total: tasks?.length || 0,
        pendentes: tasksPendentes.length,
        concluidas: tasksConcluidas.length,
        ligacoesConcluidas,
        whatsappConcluidos,
      },

      orcamentosPerdidos: {
        total: quotes?.filter(q => q.status === 'perdido').length || 0,
        valorTotal: quotes?.filter(q => q.status === 'perdido').reduce((sum, q) => sum + Number(q.total), 0) || 0,
        lista: quotes?.filter(q => q.status === 'perdido').slice(0, 5).map(q => ({
          valor: q.total,
          data: q.quote_date,
        })) || [],
      },

      alertas: {
        clientesSemContato15dias: {
          quantidade: clientesSemContato15d.length,
          lista: clientesSemContato15d.slice(0, 10).map(c => ({
            nome: c.company_name,
            ranking: c.ranking_tier,
            faturamento: c.total_revenue,
          })),
        },
        clientesInativos90dias: {
          quantidade: clientesInativos90d.length,
          lista: clientesInativos90d.slice(0, 10).map(c => ({
            nome: c.company_name,
            diasSemPedido: c.days_since_last_order,
            ranking: c.ranking_tier,
            faturamento: c.total_revenue,
          })),
        },
        recorrentesSemPedido45dias: {
          quantidade: recorrentes45d.length,
          lista: recorrentes45d.slice(0, 10).map(c => ({
            nome: c.company_name,
            diasSemPedido: c.days_since_last_order,
            ranking: c.ranking_tier,
            faturamento: c.total_revenue,
          })),
        },
      },

      relatorioClientes: {
        top20: {
          quantidade: top20Clients.length,
          faturamentoTotal: top20Revenue,
          concentracao: top20Concentration,
          lista: top20Clients.slice(0, 10).map((c, i) => ({
            posicao: i + 1,
            nome: c.company_name,
            faturamento: c.total_revenue,
            status: c.status,
          })),
        },
        top100: {
          quantidade: top100Clients.length,
          faturamentoTotal: top100Revenue,
          concentracao: top100Concentration,
        },
        top200: { quantidade: top200Clients.length },
        total: { quantidade: sortedClients.length, faturamentoTotal: totalRevenue },
      },

      relatorioVendedores: sellerMetrics,
    };
  };

  const handleAnalysis = async (period: AnalysisPeriod) => {
    if (!sellerId) {
      toast.error('Vendedor não identificado');
      return;
    }

    setAnalysisPeriod(period);
    setLoading(true);
    setResult(null);
    setStructuredResult(null);
    setSelectedHistoryItem(null);

    try {
      const dataJson = await gatherCRMData(period);

      const { data, error } = await supabase.functions.invoke('perplexity-assistant', {
        body: { mode: 'analysis', period, sellerId, dataJson },
      });

      if (error) throw error;
      
      // Parse structured response
      const parsed = parseStructuredResponse(data.answer);
      setStructuredResult(parsed);
      setResult(data.answer);
      toast.success('Análise gerada com sucesso!');
    } catch (error) {
      console.error('Error calling AI:', error);
      toast.error('Erro ao gerar análise. Tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  const handleConsultation = async () => {
    if (!sellerId) {
      toast.error('Vendedor não identificado');
      return;
    }

    if (!contextText.trim()) {
      toast.error('Cole a conversa do cliente');
      return;
    }

    setLoading(true);
    setResult(null);
    setStructuredResult(null);
    setSelectedHistoryItem(null);

    try {
      const { data, error } = await supabase.functions.invoke('perplexity-assistant', {
        body: {
          mode: 'ask',
          sellerId,
          contextText,
          userQuestion: 'Com base na conversa acima, sugira a melhor resposta seguindo o padrão H&H.',
          copyForWhatsApp: true,
        },
      });

      if (error) throw error;
      
      const parsed = parseStructuredResponse(data.answer);
      setStructuredResult(parsed);
      setResult(data.answer);
      toast.success('Sugestão gerada!');
    } catch (error) {
      console.error('Error calling AI:', error);
      toast.error('Erro ao gerar sugestão. Tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  const handleManagerPanel = async () => {
    if (!sellerId) {
      toast.error('Vendedor não identificado');
      return;
    }

    if (!managerQuery.trim()) {
      toast.error('Digite sua pergunta');
      return;
    }

    setLoading(true);
    setResult(null);
    setStructuredResult(null);
    setSelectedHistoryItem(null);

    try {
      const dataJson = await gatherCRMData(managerPeriod);

      const { data, error } = await supabase.functions.invoke('perplexity-assistant', {
        body: {
          mode: 'manager_panel',
          period: managerPeriod,
          sellerId,
          dataJson,
          userQuestion: managerQuery,
        },
      });

      if (error) throw error;
      
      const parsed = parseStructuredResponse(data.answer);
      setStructuredResult(parsed);
      setResult(data.answer);
      toast.success('Análise gerada!');
    } catch (error) {
      console.error('Error calling AI:', error);
      toast.error('Erro ao gerar análise. Tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  const handleClear = () => {
    setContextText('');
    setManagerQuery('');
    setResult(null);
    setStructuredResult(null);
    setAnalysisPeriod(null);
    setSelectedHistoryItem(null);
  };

  // Parse structured response from AI (with fallback)
  const parseStructuredResponse = (text: string): StructuredResult => {
    // Try to extract sections from markdown-like response
    const result: StructuredResult = {
      mapaRapido: '',
      diagnostico: '',
      acoes: '',
      alertas: '',
      proximosPassos: ''
    };

    const lines = text.split('\n');
    let currentSection = '';

    lines.forEach(line => {
      const cleanLine = line.trim();
      const lowerLine = cleanLine.toLowerCase();
      
      // Check for section headers
      if (lowerLine.includes('mapa rápido') || lowerLine.includes('mapa rapido') || lowerLine.includes('status rápido')) {
        currentSection = 'mapaRapido';
        return;
      }
      if (lowerLine.includes('diagnóstico') || lowerLine.includes('diagnostico')) {
        currentSection = 'diagnostico';
        return;
      }
      if (lowerLine.includes('ações recomendadas') || lowerLine.includes('acoes recomendadas') || lowerLine.includes('ações') || lowerLine.includes('## ações')) {
        currentSection = 'acoes';
        return;
      }
      if (lowerLine.includes('pontos de atenção') || lowerLine.includes('alertas') || lowerLine.includes('atenção')) {
        currentSection = 'alertas';
        return;
      }
      if (lowerLine.includes('próximo passo') || lowerLine.includes('proximo passo') || lowerLine.includes('próximos passos')) {
        currentSection = 'proximosPassos';
        return;
      }

      if (!cleanLine || cleanLine.startsWith('##') || cleanLine.startsWith('#')) return;

      const contentLine = cleanLine
        .replace(/^\*\*.*?\*\*:?\s*/, '')
        .replace(/^[-•]\s*\[\s*\]\s*/, '')
        .trim();

      if (!contentLine) return;

      switch (currentSection) {
        case 'mapaRapido':
          result.mapaRapido += (result.mapaRapido ? '\n' : '') + contentLine;
          break;
        case 'diagnostico':
          result.diagnostico += (result.diagnostico ? '\n' : '') + contentLine;
          break;
        case 'acoes':
          result.acoes += (result.acoes ? '\n' : '') + contentLine;
          break;
        case 'alertas':
          result.alertas += (result.alertas ? '\n' : '') + contentLine;
          break;
        case 'proximosPassos':
          result.proximosPassos += (result.proximosPassos ? '\n' : '') + contentLine;
          break;
      }
    });

    // If no sections found, put everything in diagnostico
    if (!result.diagnostico && !result.acoes && !result.alertas && !result.proximosPassos) {
      result.diagnostico = text;
    }

    // Generate a quick map if none exists
    if (!result.mapaRapido && result.diagnostico) {
      const firstLine = result.diagnostico.split('\n')[0];
      result.mapaRapido = firstLine.length > 100 ? firstLine.substring(0, 100) + '...' : firstLine;
    }

    console.log('✅ Resposta estruturada parseada', result);
    return result;
  };

  const handleCopy = async () => {
    const textToCopy = selectedHistoryItem ? selectedHistoryItem.output_text : result;
    if (!textToCopy) return;
    await navigator.clipboard.writeText(textToCopy);
    setCopied(true);
    toast.success('Copiado!');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleViewHistoryItem = (item: AILogEntry) => {
    setSelectedHistoryItem(item);
    setResult(null);
  };

  const handleDeleteHistoryItem = async (itemId: string) => {
    setDeletingId(itemId);
    try {
      const { error } = await supabase.from('ai_logs').delete().eq('id', itemId);
      if (error) throw error;
      setHistory(prev => prev.filter(item => item.id !== itemId));
      if (selectedHistoryItem?.id === itemId) setSelectedHistoryItem(null);
      toast.success('Análise excluída!');
    } catch (error) {
      console.error('Error deleting:', error);
      toast.error('Erro ao excluir');
    } finally {
      setDeletingId(null);
    }
  };

  const parseResult = (text: string): ParsedResult => {
    const sections: ParsedResult = { diagnostico: '', acoes: [], atencao: [], proximoPasso: '' };
    const lines = text.split('\n');
    let currentSection = '';

    lines.forEach(line => {
      const cleanLine = line.trim();
      
      if (cleanLine.toLowerCase().includes('## diagnóstico') || cleanLine.toLowerCase().includes('## diagnostico')) {
        currentSection = 'diagnostico';
        return;
      }
      if (cleanLine.toLowerCase().includes('## ações recomendadas') || cleanLine.toLowerCase().includes('## acoes recomendadas')) {
        currentSection = 'acoes';
        return;
      }
      if (cleanLine.toLowerCase().includes('## pontos de atenção') || cleanLine.toLowerCase().includes('## pontos de atencao')) {
        currentSection = 'atencao';
        return;
      }
      if (cleanLine.toLowerCase().includes('## próximo passo') || cleanLine.toLowerCase().includes('## proximo passo')) {
        currentSection = 'proximoPasso';
        return;
      }

      if (!cleanLine || cleanLine.startsWith('##')) return;

      const contentLine = cleanLine
        .replace(/^\*\*.*?\*\*:?\s*/, '')
        .replace(/^[-•]\s*\[\s*\]\s*/, '')
        .replace(/^[-•]\s*/, '')
        .replace(/^\d+\.\s*/, '')
        .trim();

      if (!contentLine) return;

      if (currentSection === 'diagnostico') {
        sections.diagnostico += (sections.diagnostico ? '\n' : '') + contentLine;
      }
      if (currentSection === 'acoes' && contentLine) {
        sections.acoes.push(contentLine);
      }
      if (currentSection === 'atencao' && contentLine) {
        sections.atencao.push(contentLine);
      }
      if (currentSection === 'proximoPasso') {
        sections.proximoPasso += (sections.proximoPasso ? ' ' : '') + contentLine;
      }
    });

    if (!sections.diagnostico && !sections.acoes.length && !sections.atencao.length && !sections.proximoPasso) {
      sections.diagnostico = text;
    }

    return sections;
  };

  const getModeLabel = (m: string) => {
    if (m === 'analysis') return 'Análise';
    if (m === 'ask') return 'Consulta';
    if (m === 'manager_panel') return 'Painel Gestor';
    return m;
  };

  const getPeriodLabel = (p: string | null) => {
    if (!p) return '';
    const labels: Record<string, string> = {
      day: 'do Dia',
      today: 'de Hoje',
      week: 'da Semana',
      month_current: 'do Mês Atual',
      month_previous: 'do Mês Anterior',
    };
    return labels[p] || '';
  };

  const activeResult = selectedHistoryItem ? selectedHistoryItem.output_text : result;
  const parsed = activeResult ? parseResult(activeResult) : null;

  // Use structuredResult if available, otherwise fall back to parsed
  const displayResult = structuredResult || (activeResult ? {
    mapaRapido: '',
    diagnostico: parsed?.diagnostico || '',
    acoes: parsed?.acoes?.join('\n') || '',
    alertas: parsed?.atencao?.join('\n') || '',
    proximosPassos: parsed?.proximoPasso || ''
  } : null);

  const renderResultCards = () => (
    <div className="flex flex-col gap-4 min-h-full">
      {displayResult?.mapaRapido && (
        <div className="ai-block ai-block-mapa">
          <h3>🎯 MAPA RÁPIDO</h3>
          <div className="ai-content">{displayResult.mapaRapido}</div>
        </div>
      )}

      {displayResult?.diagnostico && (
        <div className="ai-block ai-block-diagnostico">
          <h3>📊 DIAGNÓSTICO</h3>
          <div className="ai-content whitespace-pre-wrap">{displayResult.diagnostico}</div>
        </div>
      )}

      {displayResult?.acoes && (
        <div className="ai-block ai-block-acoes">
          <h3>✅ AÇÕES RECOMENDADAS</h3>
          <div className="ai-content whitespace-pre-wrap">{displayResult.acoes}</div>
        </div>
      )}

      {displayResult?.alertas && (
        <div className="ai-block ai-block-alertas">
          <h3>⚠️ ALERTAS</h3>
          <div className="ai-content whitespace-pre-wrap">{displayResult.alertas}</div>
        </div>
      )}

      {displayResult?.proximosPassos && (
        <div className="ai-block ai-block-proximos">
          <h3>📅 PRÓXIMOS PASSOS</h3>
          <div className="ai-content whitespace-pre-wrap">{displayResult.proximosPassos}</div>
        </div>
      )}
    </div>
  );

  return (
    <div className="flex flex-col h-full border rounded-xl bg-background overflow-hidden">
      {/* Header with Perplexity branding */}
      <div className="flex items-center justify-between px-6 py-4 border-b bg-gradient-to-r from-[#20808D]/10 to-transparent">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-[#20808D]/10 rounded-lg">
            <PerplexityLogo />
          </div>
          <div>
            <h2 className="text-lg font-semibold text-foreground">IA H&H</h2>
            <p className="text-sm text-muted-foreground">Powered by Perplexity</p>
          </div>
        </div>
      </div>

      {/* Main Tabs */}
      <Tabs value={viewTab} onValueChange={(v) => { setViewTab(v as ViewTab); setSelectedHistoryItem(null); }} className="flex flex-col flex-1 overflow-hidden">
        <div className="px-6 pt-4 border-b">
          <TabsList className="w-full max-w-[400px]">
            <TabsTrigger value="new" className="flex-1 gap-2">
              <PerplexityLogo />
              Nova Análise
            </TabsTrigger>
            <TabsTrigger value="history" className="flex-1 gap-2">
              <History size={16} />
              Histórico
            </TabsTrigger>
          </TabsList>
        </div>

        {/* New Analysis Tab */}
        <TabsContent value="new" className="flex-1 flex flex-col md:flex-row m-0 overflow-hidden">
          {/* Left Section - Controls (30%) */}
          <div className="w-full md:w-[30%] min-w-[280px] border-r bg-muted/30 p-6 flex flex-col overflow-y-auto">
            <div className="space-y-6 flex-1">
              {/* Mode Selection */}
              <div className="space-y-3">
                <Label className="text-sm font-semibold text-foreground">Selecione o modo:</Label>
                <RadioGroup 
                  value={mode} 
                  onValueChange={(v) => {
                    setMode(v as Mode);
                    setResult(null);
                    setAnalysisPeriod(null);
                  }}
                  className="flex flex-col gap-3"
                >
                  <div className="flex items-center space-x-3 p-3 rounded-lg border bg-background hover:bg-accent/50 transition-colors cursor-pointer">
                    <RadioGroupItem value="analysis" id="analysis" />
                    <Label htmlFor="analysis" className="cursor-pointer font-medium">Análise</Label>
                  </div>
                  <div className="flex items-center space-x-3 p-3 rounded-lg border bg-background hover:bg-accent/50 transition-colors cursor-pointer">
                    <RadioGroupItem value="consultation" id="consultation" />
                    <Label htmlFor="consultation" className="cursor-pointer font-medium">Consulta</Label>
                  </div>
                  <div className="flex items-center space-x-3 p-3 rounded-lg border bg-background hover:bg-accent/50 transition-colors cursor-pointer">
                    <RadioGroupItem value="manager_panel" id="manager_panel" />
                    <Label htmlFor="manager_panel" className="cursor-pointer font-medium">Painel do Gestor</Label>
                  </div>
                </RadioGroup>
              </div>

              {/* Analysis Mode Controls */}
              {mode === 'analysis' && (
                <div className="space-y-3">
                  <Label className="text-sm font-semibold text-foreground">Qual período deseja analisar?</Label>
                  <div className="flex flex-col gap-2">
                    <Button
                      variant={analysisPeriod === 'day' ? 'default' : 'outline'}
                      className="w-full justify-start gap-2 text-white border-0"
                      style={{ backgroundColor: '#2B8CB5' }}
                      onClick={() => handleAnalysis('day')}
                      disabled={loading}
                    >
                      {loading && analysisPeriod === 'day' && <Loader2 className="h-4 w-4 animate-spin" />}
                      📊 Análise do Dia
                    </Button>
                    <Button
                      variant={analysisPeriod === 'month_current' ? 'default' : 'outline'}
                      className="w-full justify-start gap-2 text-white border-0"
                      style={{ backgroundColor: '#27AE60' }}
                      onClick={() => handleAnalysis('month_current')}
                      disabled={loading}
                    >
                      {loading && analysisPeriod === 'month_current' && <Loader2 className="h-4 w-4 animate-spin" />}
                      📈 Análise do Mês Atual
                    </Button>
                    <Button
                      variant={analysisPeriod === 'month_previous' ? 'default' : 'outline'}
                      className="w-full justify-start gap-2 text-white border-0"
                      style={{ backgroundColor: '#8E44AD' }}
                      onClick={() => handleAnalysis('month_previous')}
                      disabled={loading}
                    >
                      {loading && analysisPeriod === 'month_previous' && <Loader2 className="h-4 w-4 animate-spin" />}
                      📉 Análise do Mês Anterior
                    </Button>
                  </div>
                </div>
              )}

              {/* Consultation Mode Controls */}
              {mode === 'consultation' && (
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label className="text-sm font-semibold text-foreground">Cole a conversa do cliente:</Label>
                    <Textarea
                      value={contextText}
                      onChange={(e) => setContextText(e.target.value)}
                      placeholder="Cole aqui a conversa do WhatsApp ou e-mail com o cliente..."
                      className="min-h-[200px] font-mono text-sm bg-muted/50 resize-none"
                    />
                  </div>
                  <Button
                    className="w-full text-white font-semibold border-0"
                    style={{ backgroundColor: '#27AE60' }}
                    onClick={handleConsultation}
                    disabled={loading || !contextText.trim()}
                  >
                    {loading ? (
                      <>
                        <Loader2 className="h-4 w-4 animate-spin mr-2" />
                        Gerando sugestão...
                      </>
                    ) : (
                      '💬 Gerar Sugestão'
                    )}
                  </Button>
                </div>
              )}

              {/* Manager Panel Controls */}
              {mode === 'manager_panel' && (
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label className="text-sm font-semibold text-foreground">Pergunte sobre a operação:</Label>
                    <Textarea
                      value={managerQuery}
                      onChange={(e) => setManagerQuery(e.target.value)}
                      placeholder={`Exemplos:\n• Me dê um panorama geral da empresa neste mês.\n• Quais são os 5 vendedores com mais contatos no período?\n• Quais clientes grandes estão com risco de queda?`}
                      className="min-h-[160px] text-sm bg-muted/50 resize-none"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-sm font-medium">Período:</Label>
                    <Select value={managerPeriod} onValueChange={(v) => setManagerPeriod(v as ManagerPeriod)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="today">Hoje</SelectItem>
                        <SelectItem value="week">Esta Semana</SelectItem>
                        <SelectItem value="month_current">Este Mês</SelectItem>
                        <SelectItem value="month_previous">Mês Anterior</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <Button
                    className="w-full text-white font-semibold border-0"
                    style={{ backgroundColor: '#2B8CB5' }}
                    onClick={handleManagerPanel}
                    disabled={loading || !managerQuery.trim()}
                  >
                    {loading ? (
                      <>
                        <Loader2 className="h-4 w-4 animate-spin mr-2" />
                        Analisando...
                      </>
                    ) : (
                      '🔍 Analisar Panorama'
                    )}
                  </Button>
                </div>
              )}
            </div>

            {/* Clear Button */}
            <Button variant="outline" className="w-full mt-4 gap-2" onClick={handleClear}>
              <Trash2 className="h-4 w-4" />
              Limpar
            </Button>
          </div>

          {/* Right Section - Results (70%) */}
          <div className="flex-1 flex flex-col bg-background overflow-hidden">
            {!result && !loading ? (
              <div className="flex-1 flex items-center justify-center text-muted-foreground">
                <div className="text-center">
                  <div className="opacity-20 mx-auto mb-4">
                    <PerplexityLogo />
                  </div>
                  <p className="text-lg">A análise aparecerá aqui</p>
                  <p className="text-sm">Selecione um modo e período ou digite sua pergunta</p>
                </div>
              </div>
            ) : loading ? (
              <div className="flex-1 flex items-center justify-center">
                <div className="text-center">
                  <div className="ai-loading">
                    <div className="spinner"></div>
                    <p className="text-lg font-medium">Analisando seus dados...</p>
                  </div>
                </div>
              </div>
            ) : (
              <div className="flex-1 overflow-y-auto p-6 bg-gradient-to-b from-muted/20 to-background">
                {renderResultCards()}
              </div>
            )}

            {/* Footer Actions */}
            {result && (
              <div className="border-t p-4 flex gap-3">
                <Button variant="outline" className="flex-1 gap-2" onClick={handleCopy}>
                  {copied ? <CheckCircle className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                  {copied ? 'Copiado!' : 'Copiar'}
                </Button>
                <Button variant="outline" className="gap-2" onClick={() => setFullscreenOpen(true)}>
                  <Maximize2 className="h-4 w-4" />
                  Expandir
                </Button>
              </div>
            )}
          </div>
        </TabsContent>

        {/* History Tab */}
        <TabsContent value="history" className="flex-1 flex flex-col md:flex-row m-0 overflow-hidden">
          {/* Left Section - History List */}
          <div className="w-full md:w-[30%] min-w-[280px] border-r bg-muted/30 flex flex-col overflow-hidden">
            <div className="p-4 border-b">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-foreground">Análises Anteriores</h3>
                <Button variant="ghost" size="sm" onClick={fetchHistory} disabled={historyLoading}>
                  <RotateCcw className={`h-4 w-4 ${historyLoading ? 'animate-spin' : ''}`} />
                </Button>
              </div>
            </div>

            <ScrollArea className="flex-1">
              {historyLoading ? (
                <div className="flex items-center justify-center py-12">
                  <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
                </div>
              ) : history.length === 0 ? (
                <div className="text-center py-12 text-muted-foreground">
                  <History className="h-12 w-12 mx-auto mb-3 opacity-30" />
                  <p>Nenhuma análise salva</p>
                </div>
              ) : (
                <div className="p-2 space-y-2">
                  {history.map((item) => (
                    <div
                      key={item.id}
                      className={`relative w-full text-left p-3 rounded-lg border transition-all hover:border-primary/30 ${
                        selectedHistoryItem?.id === item.id ? 'border-primary bg-primary/5' : 'bg-background'
                      }`}
                    >
                      <button onClick={() => handleViewHistoryItem(item)} className="w-full text-left">
                        <div className="flex items-center justify-between mb-1">
                          <Badge variant="outline" className="text-xs">
                            {getModeLabel(item.mode)} {getPeriodLabel(item.period)}
                          </Badge>
                          <ChevronRight size={14} className="text-muted-foreground" />
                        </div>
                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                          <Clock size={12} />
                          {format(new Date(item.created_at), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}
                        </div>
                        <p className="text-xs text-muted-foreground mt-2 line-clamp-2">
                          {item.output_text.slice(0, 100)}...
                        </p>
                      </button>
                      
                      {isAdminOrOwner && (
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="absolute top-2 right-2 h-7 w-7 text-muted-foreground hover:text-destructive hover:bg-destructive/10"
                              onClick={(e) => e.stopPropagation()}
                            >
                              <Trash2 size={14} />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Excluir Análise</AlertDialogTitle>
                              <AlertDialogDescription>
                                Tem certeza que deseja excluir esta análise? Esta ação não pode ser desfeita.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancelar</AlertDialogCancel>
                              <AlertDialogAction
                                onClick={() => handleDeleteHistoryItem(item.id)}
                                className="bg-destructive hover:bg-destructive/90"
                                disabled={deletingId === item.id}
                              >
                                {deletingId === item.id ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Excluir'}
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </ScrollArea>
          </div>

          {/* Right Section - Selected History Item */}
          <div className="flex-1 flex flex-col bg-background overflow-hidden">
            {!selectedHistoryItem ? (
              <div className="flex-1 flex items-center justify-center text-muted-foreground">
                <div className="text-center">
                  <History className="h-16 w-16 mx-auto mb-4 opacity-20" />
                  <p className="text-lg">Selecione uma análise para visualizar</p>
                  <p className="text-sm">Clique em uma das análises à esquerda</p>
                </div>
              </div>
            ) : (
              <>
                <div className="p-4 border-b flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <Badge variant="outline">
                        {getModeLabel(selectedHistoryItem.mode)} {getPeriodLabel(selectedHistoryItem.period)}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground flex items-center gap-1">
                      <Clock size={12} />
                      {format(new Date(selectedHistoryItem.created_at), "dd 'de' MMMM 'de' yyyy 'às' HH:mm", { locale: ptBR })}
                    </p>
                  </div>
                </div>
                <ScrollArea className="flex-1 p-6">
                  {renderResultCards()}
                </ScrollArea>
                <div className="border-t p-4">
                  <Button variant="outline" className="w-full gap-2" onClick={handleCopy}>
                    {copied ? <CheckCircle className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                    {copied ? 'Copiado!' : 'Copiar'}
                  </Button>
                </div>
              </>
            )}
          </div>
        </TabsContent>
      </Tabs>

      {/* Fullscreen Modal */}
      <Dialog open={fullscreenOpen} onOpenChange={setFullscreenOpen}>
        <DialogContent className="max-w-[95vw] w-full h-[95vh] flex flex-col p-0 gap-0">
          <DialogHeader className="px-6 py-4 border-b bg-gradient-to-r from-[#20808D]/10 to-transparent flex-shrink-0">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#20808D]/10 rounded-lg">
                  <PerplexityLogo />
                </div>
                <div>
                  <DialogTitle className="text-lg font-semibold">Análise Completa</DialogTitle>
                  <p className="text-sm text-muted-foreground">Powered by Perplexity</p>
                </div>
              </div>
            </div>
          </DialogHeader>
          <ScrollArea className="flex-1 p-6">
            <div className="max-w-5xl mx-auto">
              {renderResultCards()}
            </div>
          </ScrollArea>
          <div className="border-t p-4 flex gap-3 flex-shrink-0">
            <Button variant="outline" className="flex-1 gap-2" onClick={handleCopy}>
              {copied ? <CheckCircle className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
              {copied ? 'Copiado!' : 'Copiar'}
            </Button>
            <Button variant="outline" className="gap-2" onClick={() => setFullscreenOpen(false)}>
              <X className="h-4 w-4" />
              Fechar
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};
