import { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Loader2, Users, AlertTriangle, RefreshCw, Zap, Target, CalendarDays } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { upsertTasks } from '@/lib/taskUtils';

// Helper to get date in São Paulo timezone (YYYY-MM-DD)
function saoPauloDayKey(date: Date): string {
  return new Intl.DateTimeFormat('sv-SE', {
    timeZone: 'America/Sao_Paulo',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(date);
}

interface PlanningModeModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  sellerId: string | null;
  onPlanCreated: () => void;
}

interface ClientForPlanning {
  id: string;
  company_name: string;
  ranking_tier: string;
  days_since_last_order: number | null;
  last_contact_at: string | null;
  total_revenue: number;
  status: string;
  hasOverdueTask: boolean;
  hasTodayTask: boolean;
}

type PlanningTab = 'inativos' | 'recorrentes';

export function PlanningModeModal({ open, onOpenChange, sellerId, onPlanCreated }: PlanningModeModalProps) {
  const [mode, setMode] = useState<'select' | 'manual' | 'auto'>('select');
  const [loading, setLoading] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [clients, setClients] = useState<ClientForPlanning[]>([]);
  const [selectedClients, setSelectedClients] = useState<Set<string>>(new Set());
  const [manualTab, setManualTab] = useState<PlanningTab>('inativos');

  useEffect(() => {
    if (open && sellerId) {
      fetchClients();
    }
  }, [open, sellerId]);

  const fetchClients = async () => {
    if (!sellerId) return;
    
    setLoading(true);
    try {
      const today = saoPauloDayKey(new Date());
      
      // Fetch clients
      const { data: clientsData } = await supabase
        .from('clients')
        .select('id, company_name, ranking_tier, days_since_last_order, last_contact_at, total_revenue, status')
        .eq('is_deleted', false)
        .eq('seller_id', sellerId);

      // Fetch tasks for today and overdue
      const { data: tasksData } = await supabase
        .from('tasks')
        .select('client_id, task_date, status')
        .eq('status', 'pendente')
        .lte('task_date', today);

      const overdueTaskClients = new Set(tasksData?.filter(t => t.task_date < today).map(t => t.client_id) || []);
      const todayTaskClients = new Set(tasksData?.filter(t => t.task_date === today).map(t => t.client_id) || []);

      const enrichedClients = (clientsData || []).map(c => ({
        ...c,
        hasOverdueTask: overdueTaskClients.has(c.id),
        hasTodayTask: todayTaskClients.has(c.id),
      }));

      setClients(enrichedClients);
    } catch (error) {
      console.error('Error fetching clients:', error);
    } finally {
      setLoading(false);
    }
  };

  // Categorize clients
  const categorizedClients = useMemo(() => {
    const inativos = clients.filter(c => c.days_since_last_order && c.days_since_last_order >= 90);
    const recorrentes = clients.filter(c => c.days_since_last_order && c.days_since_last_order <= 45);
    
    return { inativos, recorrentes };
  }, [clients]);

  const getCurrentTabClients = () => {
    switch (manualTab) {
      case 'inativos': return categorizedClients.inativos;
      case 'recorrentes': return categorizedClients.recorrentes;
      default: return [];
    }
  };

  const toggleClient = (clientId: string) => {
    setSelectedClients(prev => {
      const next = new Set(prev);
      if (next.has(clientId)) {
        next.delete(clientId);
      } else {
        next.add(clientId);
      }
      return next;
    });
  };

  // Ref to prevent double submit
  const isSubmittingRef = useRef(false);

  const handleAutoGenerate = async () => {
    if (!sellerId || generating || isSubmittingRef.current) return;
    
    isSubmittingRef.current = true;
    setGenerating(true);
    try {
      const today = saoPauloDayKey(new Date());
      const planningList: ClientForPlanning[] = [];

      // 1. INATIVOS com tarefa hoje ou mais tempo parados
      const inativosOrdered = categorizedClients.inativos
        .sort((a, b) => {
          if (a.hasTodayTask && !b.hasTodayTask) return -1;
          if (!a.hasTodayTask && b.hasTodayTask) return 1;
          return (b.days_since_last_order || 0) - (a.days_since_last_order || 0);
        });
      planningList.push(...inativosOrdered.filter(c => !planningList.find(p => p.id === c.id)).slice(0, 5));

      // 2. RECORRENTES ordenados por faturamento e ranking
      const rankingOrder = { top20: 0, top100: 1, top200: 2, eventual: 3, geral: 4 };
      const recorrentesOrdered = categorizedClients.recorrentes
        .sort((a, b) => {
          const rankDiff = (rankingOrder[a.ranking_tier as keyof typeof rankingOrder] || 4) - 
                          (rankingOrder[b.ranking_tier as keyof typeof rankingOrder] || 4);
          if (rankDiff !== 0) return rankDiff;
          return (b.total_revenue || 0) - (a.total_revenue || 0);
        });
      planningList.push(...recorrentesOrdered.filter(c => !planningList.find(p => p.id === c.id)).slice(0, 10));

      // Create tasks for selected clients with upsert to prevent duplicates
      const tasksToCreate = planningList.map(client => ({
        client_id: client.id,
        task_date: today,
        contact_type: 'ligacao',
        status: 'pendente' as const,
        priority: (client.ranking_tier === 'top20' ? 'alta' : client.ranking_tier === 'top100' ? 'media' : 'baixa') as 'alta' | 'media' | 'baixa',
        notes: `Planejamento automático - ${client.status === 'prospect' ? 'Prospect' : client.days_since_last_order && client.days_since_last_order >= 90 ? 'Cliente Inativo' : 'Cliente Recorrente'}`,
        created_by_seller_id: sellerId,
        source: 'planning-auto',
      }));

      await upsertTasks(supabase, tasksToCreate);

      toast.success(`${planningList.length} tarefas criadas no planejamento automático!`);
      onOpenChange(false);
      onPlanCreated();
    } catch (error) {
      console.error('Error creating auto plan:', error);
      toast.error('Erro ao gerar planejamento');
    } finally {
      setGenerating(false);
      isSubmittingRef.current = false;
    }
  };

  const handleManualConfirm = async () => {
    if (!sellerId || selectedClients.size === 0) {
      toast.error('Selecione ao menos um cliente');
      return;
    }

    if (generating || isSubmittingRef.current) return;

    isSubmittingRef.current = true;
    setGenerating(true);
    try {
      const today = saoPauloDayKey(new Date());
      
      const tasksToCreate = Array.from(selectedClients).map(clientId => {
        const client = clients.find(c => c.id === clientId);
        return {
          client_id: clientId,
          task_date: today,
          contact_type: 'ligacao',
          status: 'pendente' as const,
          priority: (client?.ranking_tier === 'top20' ? 'alta' : client?.ranking_tier === 'top100' ? 'media' : 'baixa') as 'alta' | 'media' | 'baixa',
          notes: 'Planejamento manual',
          created_by_seller_id: sellerId,
          source: 'planning-manual',
        };
      });

      await upsertTasks(supabase, tasksToCreate);

      toast.success(`${selectedClients.size} tarefas criadas!`);
      onOpenChange(false);
      onPlanCreated();
    } catch (error) {
      console.error('Error creating manual plan:', error);
      toast.error('Erro ao criar planejamento');
    } finally {
      setGenerating(false);
      isSubmittingRef.current = false;
    }
  };

  const getRankingBadge = (tier: string) => {
    const config: Record<string, { label: string; className: string }> = {
      top20: { label: 'Top 20', className: 'bg-amber-500/10 text-amber-600 border-amber-500/20' },
      top100: { label: 'Top 100', className: 'bg-blue-500/10 text-blue-600 border-blue-500/20' },
      top200: { label: 'Top 200', className: 'bg-purple-500/10 text-purple-600 border-purple-500/20' },
      eventual: { label: 'Eventual', className: 'bg-gray-500/10 text-gray-600 border-gray-500/20' },
    };
    const c = config[tier] || config.eventual;
    return <Badge variant="outline" className={`text-[10px] ${c.className}`}>{c.label}</Badge>;
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[700px] max-h-[85vh] flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <CalendarDays className="h-5 w-5 text-primary" />
            Montar Planejamento do Dia
          </DialogTitle>
        </DialogHeader>

        {mode === 'select' && (
          <div className="flex-1 py-6">
            <div className="grid grid-cols-2 gap-4">
              <button
                onClick={() => setMode('manual')}
                className="p-6 border-2 border-dashed border-border rounded-xl hover:border-primary/50 hover:bg-primary/5 transition-all text-left"
              >
                <Users className="h-8 w-8 text-primary mb-3" />
                <h3 className="font-semibold text-lg">Modo Manual</h3>
                <p className="text-sm text-muted-foreground mt-1">
                  Selecione os clientes manualmente entre Prospects, Inativos e Recorrentes
                </p>
              </button>

              <button
                onClick={() => {
                  setMode('auto');
                  handleAutoGenerate();
                }}
                className="p-6 border-2 border-dashed border-border rounded-xl hover:border-primary/50 hover:bg-primary/5 transition-all text-left"
              >
                <Zap className="h-8 w-8 text-amber-500 mb-3" />
                <h3 className="font-semibold text-lg">Modo Automático</h3>
                <p className="text-sm text-muted-foreground mt-1">
                  Sistema gera lista otimizada baseada em prioridades e histórico
                </p>
              </button>
            </div>
          </div>
        )}

        {mode === 'manual' && (
          <>
            <Tabs value={manualTab} onValueChange={(v) => setManualTab(v as PlanningTab)} className="flex-1">
              <TabsList className="w-full">
                <TabsTrigger value="inativos" className="flex-1 gap-1">
                  <AlertTriangle className="h-4 w-4" />
                  Inativos ({categorizedClients.inativos.length})
                </TabsTrigger>
                <TabsTrigger value="recorrentes" className="flex-1 gap-1">
                  <RefreshCw className="h-4 w-4" />
                  Recorrentes ({categorizedClients.recorrentes.length})
                </TabsTrigger>
              </TabsList>

              <TabsContent value={manualTab} className="mt-4 flex-1">
                {loading ? (
                  <div className="flex justify-center py-12">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  </div>
                ) : (
                  <ScrollArea className="h-[350px]">
                    <div className="space-y-2 pr-4">
                      {getCurrentTabClients().map(client => (
                        <div
                          key={client.id}
                          onClick={() => toggleClient(client.id)}
                          className={`flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-all ${
                            selectedClients.has(client.id) 
                              ? 'border-primary bg-primary/5' 
                              : 'border-border hover:border-primary/30'
                          }`}
                        >
                          <Checkbox checked={selectedClients.has(client.id)} />
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2">
                              <span className="font-medium truncate">{client.company_name}</span>
                              {getRankingBadge(client.ranking_tier)}
                              {client.hasOverdueTask && (
                                <Badge variant="destructive" className="text-[10px]">Atrasada</Badge>
                              )}
                              {client.hasTodayTask && (
                                <Badge variant="outline" className="text-[10px] bg-amber-50 text-amber-600">Hoje</Badge>
                              )}
                            </div>
                            <p className="text-xs text-muted-foreground">
                              {client.days_since_last_order 
                                ? `${client.days_since_last_order} dias sem pedido` 
                                : 'Sem pedidos'}
                            </p>
                          </div>
                        </div>
                      ))}
                      {getCurrentTabClients().length === 0 && (
                        <p className="text-center py-8 text-muted-foreground">
                          Nenhum cliente nesta categoria
                        </p>
                      )}
                    </div>
                  </ScrollArea>
                )}
              </TabsContent>
            </Tabs>

            <DialogFooter className="mt-4">
              <Button variant="outline" onClick={() => setMode('select')}>
                Voltar
              </Button>
              <Button onClick={handleManualConfirm} disabled={generating || selectedClients.size === 0}>
                {generating && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                Criar {selectedClients.size} Tarefas
              </Button>
            </DialogFooter>
          </>
        )}

        {mode === 'auto' && generating && (
          <div className="flex-1 flex flex-col items-center justify-center py-12">
            <Loader2 className="h-12 w-12 animate-spin text-primary mb-4" />
            <p className="text-lg font-medium">Gerando planejamento otimizado...</p>
            <p className="text-sm text-muted-foreground mt-1">
              Analisando sua carteira de clientes
            </p>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
