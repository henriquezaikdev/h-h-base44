import { useState, useEffect } from 'react';
import { Loader2, Save, Copy, CheckCircle, X, Bot, Trash2, History, Clock, ChevronRight, RotateCcw } from 'lucide-react';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { Button } from '@/components/ui/button';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { format, startOfMonth, endOfMonth, subMonths } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { useAuth } from '@/hooks/useAuth';

interface AIUnifiedModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  sellerId: string | undefined;
}

type Mode = 'analysis' | 'consultation';
type Period = 'day' | 'month_current' | 'month_previous';
type ViewTab = 'new' | 'history';

interface ParsedResult {
  diagnostico: string;
  acoes: string[];
  atencao: string[];
  proximoPasso: string;
}

interface AILogEntry {
  id: string;
  mode: string;
  period: string | null;
  output_text: string;
  created_at: string;
}

export const AIUnifiedModal = ({ open, onOpenChange, sellerId }: AIUnifiedModalProps) => {
  const { isAdminOrOwner } = useAuth();
  const [viewTab, setViewTab] = useState<ViewTab>('new');
  const [mode, setMode] = useState<Mode>('analysis');
  const [period, setPeriod] = useState<Period | null>(null);
  const [contextText, setContextText] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [history, setHistory] = useState<AILogEntry[]>([]);
  const [historyLoading, setHistoryLoading] = useState(false);
  const [selectedHistoryItem, setSelectedHistoryItem] = useState<AILogEntry | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  // Fetch history when modal opens or tab changes to history
  useEffect(() => {
    if (open && viewTab === 'history') {
      fetchHistory();
    }
  }, [open, viewTab, sellerId]);

  const fetchHistory = async () => {
    if (!sellerId) return;
    
    setHistoryLoading(true);
    try {
      const { data, error } = await supabase
        .from('ai_logs')
        .select('id, mode, period, output_text, created_at')
        .order('created_at', { ascending: false })
        .limit(50);

      if (error) throw error;
      setHistory(data || []);
    } catch (error) {
      console.error('Error fetching AI history:', error);
      toast.error('Erro ao carregar histórico');
    } finally {
      setHistoryLoading(false);
    }
  };

  const gatherCRMData = async (selectedPeriod: Period) => {
    const today = format(new Date(), 'yyyy-MM-dd');
    const now = new Date();
    
    let startDate: string;
    let endDate: string;

    if (selectedPeriod === 'day') {
      startDate = today;
      endDate = today;
    } else if (selectedPeriod === 'month_current') {
      startDate = format(startOfMonth(now), 'yyyy-MM-dd');
      endDate = format(endOfMonth(now), 'yyyy-MM-dd');
    } else {
      const lastMonth = subMonths(now, 1);
      startDate = format(startOfMonth(lastMonth), 'yyyy-MM-dd');
      endDate = format(endOfMonth(lastMonth), 'yyyy-MM-dd');
    }

    // Fetch tasks
    const { data: tasks } = await supabase
      .from('tasks')
      .select('*')
      .gte('task_date', startDate)
      .lte('task_date', endDate);

    // Fetch all clients
    const { data: clients } = await supabase
      .from('clients')
      .select('id, company_name, ranking_tier, days_since_last_order, last_contact_at, total_revenue, status, seller_id')
      .eq('is_deleted', false);

    // Fetch orders for the period
    const { data: orders } = await supabase
      .from('orders')
      .select('id, total, order_date, client_id, seller_id')
      .gte('order_date', startDate)
      .lte('order_date', endDate);

    // Fetch quotes for the period
    const { data: quotes } = await supabase
      .from('quotes')
      .select('id, total, quote_date, client_id, status')
      .gte('quote_date', startDate)
      .lte('quote_date', endDate);

    // Fetch sellers (apenas ativos)
    const { data: sellers } = await supabase
      .from('sellers')
      .select('id, name, role')
      .or('status.eq.ATIVO,status.is.null');

    // Fetch interactions for the period
    const { data: interactions } = await supabase
      .from('interactions')
      .select('id, interaction_type, responsible_seller_id, client_id')
      .gte('interaction_date', startDate)
      .lte('interaction_date', endDate);

    // Calculate task metrics
    const tasksToday = tasks?.filter(t => t.task_date === today) || [];
    const tasksPendentes = tasksToday.filter(t => t.status === 'pendente');
    const tasksConcluidas = tasksToday.filter(t => t.status === 'concluida');
    
    const ligacoesConcluidas = tasksConcluidas.filter(t => t.contact_type === 'ligacao').length;
    const whatsappConcluidos = tasksConcluidas.filter(t => t.contact_type === 'whatsapp').length;

    // Calculate client alerts
    const clientesSemContato15d = clients?.filter(c => {
      if (!c.last_contact_at) return true;
      const daysSinceContact = Math.floor((Date.now() - new Date(c.last_contact_at).getTime()) / (1000 * 60 * 60 * 24));
      return daysSinceContact >= 15;
    }) || [];

    const clientesInativos90d = clients?.filter(c => 
      c.days_since_last_order && c.days_since_last_order >= 90
    ) || [];

    const recorrentes45d = clients?.filter(c => 
      c.days_since_last_order && c.days_since_last_order >= 45 && c.days_since_last_order < 90
    ) || [];

    // Calculate client ranking reports
    const sortedClients = [...(clients || [])].sort((a, b) => (b.total_revenue || 0) - (a.total_revenue || 0));
    const top20Clients = sortedClients.slice(0, 20);
    const top100Clients = sortedClients.slice(0, 100);
    const top200Clients = sortedClients.slice(0, 200);

    const totalRevenue = sortedClients.reduce((sum, c) => sum + (c.total_revenue || 0), 0);
    const top20Revenue = top20Clients.reduce((sum, c) => sum + (c.total_revenue || 0), 0);
    const top100Revenue = top100Clients.reduce((sum, c) => sum + (c.total_revenue || 0), 0);
    const top20Concentration = totalRevenue > 0 ? (top20Revenue / totalRevenue) * 100 : 0;
    const top100Concentration = totalRevenue > 0 ? (top100Revenue / totalRevenue) * 100 : 0;

    // Calculate seller metrics
    const sellerMetrics = sellers?.map(seller => {
      const sellerInteractions = interactions?.filter(i => i.responsible_seller_id === seller.id) || [];
      const sellerOrders = orders?.filter(o => o.seller_id === seller.id) || [];
      const sellerTasks = tasks?.filter(t => t.created_by_seller_id === seller.id) || [];
      const sellerClients = clients?.filter(c => c.seller_id === seller.id) || [];

      const ligacoes = sellerInteractions.filter(i => 
        i.interaction_type?.toLowerCase().includes('ligaç') || 
        i.interaction_type?.toLowerCase().includes('ligac') ||
        i.interaction_type?.toLowerCase() === 'call'
      ).length;
      
      const whatsapp = sellerInteractions.filter(i => 
        i.interaction_type?.toLowerCase().includes('whatsapp') ||
        i.interaction_type?.toLowerCase().includes('whats')
      ).length;
      
      const emails = sellerInteractions.filter(i => 
        i.interaction_type?.toLowerCase().includes('email') ||
        i.interaction_type?.toLowerCase().includes('e-mail')
      ).length;

      const total_contatos = sellerInteractions.length;
      const total_pedidos = sellerOrders.length;
      const faturamento = sellerOrders.reduce((sum, o) => sum + Number(o.total || 0), 0);
      const ticket_medio = total_pedidos > 0 ? faturamento / total_pedidos : 0;

      const tarefas_concluidas = sellerTasks.filter(t => t.status === 'concluida').length;
      const tarefas_pendentes = sellerTasks.filter(t => t.status === 'pendente').length;
      const total_tarefas = sellerTasks.length;
      const perc_execucao = total_tarefas > 0 ? (tarefas_concluidas / total_tarefas) * 100 : 0;

      return {
        nome: seller.name,
        cargo: seller.role,
        contatos: {
          ligacoes,
          whatsapp,
          emails,
          total: total_contatos,
        },
        vendas: {
          pedidos: total_pedidos,
          faturamento,
          ticket_medio,
        },
        tarefas: {
          concluidas: tarefas_concluidas,
          pendentes: tarefas_pendentes,
          taxa_execucao: perc_execucao,
        },
        carteira: {
          total_clientes: sellerClients.length,
        },
      };
    }) || [];

    return {
      periodo: selectedPeriod === 'day' ? 'Hoje' : selectedPeriod === 'month_current' ? 'Mês Atual' : 'Mês Anterior',
      dataInicio: startDate,
      dataFim: endDate,
      
      resumo: {
        totalClientes: clients?.length || 0,
        totalVendedores: sellers?.length || 0,
        pedidosNoPeriodo: orders?.length || 0,
        faturamentoNoPeriodo: orders?.reduce((sum, o) => sum + Number(o.total), 0) || 0,
        contatosNoPeriodo: interactions?.length || 0,
      },

      tarefas: {
        total: tasks?.length || 0,
        pendentes: tasksPendentes.length,
        concluidas: tasksConcluidas.length,
        ligacoesConcluidas,
        whatsappConcluidos,
      },

      orcamentosPerdidos: {
        total: quotes?.filter(q => q.status === 'perdido').length || 0,
        valorTotal: quotes?.filter(q => q.status === 'perdido').reduce((sum, q) => sum + Number(q.total), 0) || 0,
        lista: quotes?.filter(q => q.status === 'perdido').slice(0, 5).map(q => ({
          valor: q.total,
          data: q.quote_date,
        })) || [],
      },

      alertas: {
        clientesSemContato15dias: {
          quantidade: clientesSemContato15d.length,
          lista: clientesSemContato15d.slice(0, 10).map(c => ({
            nome: c.company_name,
            ranking: c.ranking_tier,
            faturamento: c.total_revenue,
          })),
        },
        clientesInativos90dias: {
          quantidade: clientesInativos90d.length,
          lista: clientesInativos90d.slice(0, 10).map(c => ({
            nome: c.company_name,
            diasSemPedido: c.days_since_last_order,
            ranking: c.ranking_tier,
            faturamento: c.total_revenue,
          })),
        },
        recorrentesSemPedido45dias: {
          quantidade: recorrentes45d.length,
          lista: recorrentes45d.slice(0, 10).map(c => ({
            nome: c.company_name,
            diasSemPedido: c.days_since_last_order,
            ranking: c.ranking_tier,
            faturamento: c.total_revenue,
          })),
        },
      },

      relatorioClientes: {
        top20: {
          quantidade: top20Clients.length,
          faturamentoTotal: top20Revenue,
          concentracao: top20Concentration,
          lista: top20Clients.slice(0, 10).map((c, i) => ({
            posicao: i + 1,
            nome: c.company_name,
            faturamento: c.total_revenue,
            status: c.status,
          })),
        },
        top100: {
          quantidade: top100Clients.length,
          faturamentoTotal: top100Revenue,
          concentracao: top100Concentration,
        },
        top200: {
          quantidade: top200Clients.length,
        },
        total: {
          quantidade: sortedClients.length,
          faturamentoTotal: totalRevenue,
        },
      },

      relatorioVendedores: sellerMetrics,
    };
  };

  const handleAnalyze = async (selectedPeriod: Period) => {
    if (!sellerId) {
      toast.error('Vendedor não identificado');
      return;
    }

    setPeriod(selectedPeriod);
    setLoading(true);
    setResult(null);
    setSelectedHistoryItem(null);

    try {
      const dataJson = await gatherCRMData(selectedPeriod);

      const { data, error } = await supabase.functions.invoke('perplexity-assistant', {
        body: {
          mode: 'analysis',
          period: selectedPeriod,
          sellerId,
          dataJson,
        },
      });

      if (error) throw error;

      setResult(data.answer);
      toast.success('Análise gerada com sucesso!');
    } catch (error) {
      console.error('Error calling AI:', error);
      toast.error('Erro ao gerar análise. Tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  const handleConsultation = async () => {
    if (!sellerId) {
      toast.error('Vendedor não identificado');
      return;
    }

    if (!contextText.trim()) {
      toast.error('Cole a conversa do cliente');
      return;
    }

    setLoading(true);
    setResult(null);
    setSelectedHistoryItem(null);

    try {
      const { data, error } = await supabase.functions.invoke('perplexity-assistant', {
        body: {
          mode: 'ask',
          sellerId,
          contextText,
          userQuestion: 'Com base na conversa acima, sugira a melhor resposta seguindo o padrão H&H.',
          copyForWhatsApp: true,
        },
      });

      if (error) throw error;

      setResult(data.answer);
      toast.success('Sugestão gerada!');
    } catch (error) {
      console.error('Error calling AI:', error);
      toast.error('Erro ao gerar sugestão. Tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  const handleClear = () => {
    setContextText('');
    setResult(null);
    setPeriod(null);
    setSelectedHistoryItem(null);
  };

  const handleCopy = async () => {
    const textToCopy = selectedHistoryItem ? selectedHistoryItem.output_text : result;
    if (!textToCopy) return;
    await navigator.clipboard.writeText(textToCopy);
    setCopied(true);
    toast.success('Copiado para a área de transferência!');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSave = () => {
    toast.success('Análise salva no histórico!');
  };

  const handleViewHistoryItem = (item: AILogEntry) => {
    setSelectedHistoryItem(item);
    setResult(null);
  };

  const handleBackToList = () => {
    setSelectedHistoryItem(null);
  };

  const handleDeleteHistoryItem = async (itemId: string) => {
    setDeletingId(itemId);
    try {
      const { error } = await supabase
        .from('ai_logs')
        .delete()
        .eq('id', itemId);

      if (error) throw error;

      // Remove from local state
      setHistory(prev => prev.filter(item => item.id !== itemId));
      
      // If deleted item was selected, clear selection
      if (selectedHistoryItem?.id === itemId) {
        setSelectedHistoryItem(null);
      }

      toast.success('Análise excluída com sucesso!');
    } catch (error) {
      console.error('Error deleting AI log:', error);
      toast.error('Erro ao excluir análise');
    } finally {
      setDeletingId(null);
    }
  };

  const parseResult = (text: string): ParsedResult => {
    const sections = {
      diagnostico: '',
      acoes: [] as string[],
      atencao: [] as string[],
      proximoPasso: '',
    };

    const lines = text.split('\n');
    let currentSection = '';

    lines.forEach(line => {
      const cleanLine = line.trim();
      
      if (cleanLine.toLowerCase().includes('## diagnóstico') || cleanLine.toLowerCase().includes('## diagnostico')) {
        currentSection = 'diagnostico';
        return;
      }
      if (cleanLine.toLowerCase().includes('## ações recomendadas') || cleanLine.toLowerCase().includes('## acoes recomendadas')) {
        currentSection = 'acoes';
        return;
      }
      if (cleanLine.toLowerCase().includes('## pontos de atenção') || cleanLine.toLowerCase().includes('## pontos de atencao')) {
        currentSection = 'atencao';
        return;
      }
      if (cleanLine.toLowerCase().includes('## próximo passo') || cleanLine.toLowerCase().includes('## proximo passo')) {
        currentSection = 'proximoPasso';
        return;
      }

      if (!cleanLine || cleanLine.startsWith('##')) return;

      const contentLine = cleanLine
        .replace(/^\*\*.*?\*\*:?\s*/, '')
        .replace(/^[-•]\s*\[\s*\]\s*/, '')
        .replace(/^[-•]\s*/, '')
        .replace(/^\d+\.\s*/, '')
        .trim();

      if (!contentLine) return;

      if (currentSection === 'diagnostico') {
        sections.diagnostico += (sections.diagnostico ? '\n' : '') + contentLine;
      }
      if (currentSection === 'acoes' && contentLine) {
        sections.acoes.push(contentLine);
      }
      if (currentSection === 'atencao' && contentLine) {
        sections.atencao.push(contentLine);
      }
      if (currentSection === 'proximoPasso') {
        sections.proximoPasso += (sections.proximoPasso ? ' ' : '') + contentLine;
      }
    });

    if (!sections.diagnostico && !sections.acoes.length && !sections.atencao.length && !sections.proximoPasso) {
      sections.diagnostico = text;
    }

    return sections;
  };

  const getModeLabel = (modeValue: string) => {
    return modeValue === 'analysis' ? 'Análise' : 'Consulta';
  };

  const getPeriodLabel = (periodValue: string | null) => {
    if (!periodValue) return '';
    switch (periodValue) {
      case 'day': return 'do Dia';
      case 'month_current': return 'do Mês Atual';
      case 'month_previous': return 'do Mês Anterior';
      default: return '';
    }
  };

  const activeResult = selectedHistoryItem ? selectedHistoryItem.output_text : result;
  const parsed = activeResult ? parseResult(activeResult) : null;

  const renderResultCards = () => (
    <div className="space-y-4">
      {parsed?.diagnostico && (
        <div className="rounded-lg border-l-4 border-l-[#21868D] bg-card p-4 shadow-sm">
          <h3 className="font-bold text-base mb-3 text-[#21868D]">DIAGNÓSTICO</h3>
          <div className="text-sm text-foreground whitespace-pre-line">
            {parsed.diagnostico}
          </div>
        </div>
      )}

      {parsed?.acoes && parsed.acoes.length > 0 && (
        <div className="rounded-lg border-l-4 border-l-[#22C55E] bg-card p-4 shadow-sm">
          <h3 className="font-bold text-base mb-3 text-[#22C55E]">AÇÕES RECOMENDADAS</h3>
          <div className="space-y-2">
            {parsed.acoes.slice(0, 5).map((acao, idx) => (
              <div key={idx} className="flex items-start gap-3 text-sm">
                <div className="w-4 h-4 border-2 border-muted-foreground/40 rounded flex-shrink-0 mt-0.5" />
                <span className="text-foreground">{acao}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {parsed?.atencao && parsed.atencao.length > 0 && (
        <div className="rounded-lg border-l-4 border-l-[#F59E0B] bg-card p-4 shadow-sm">
          <h3 className="font-bold text-base mb-3 text-[#F59E0B]">PONTOS DE ATENÇÃO</h3>
          <ul className="space-y-1.5">
            {parsed.atencao.map((item, idx) => (
              <li key={idx} className="text-sm text-foreground flex items-start gap-2">
                <span className="text-[#F59E0B]">•</span>
                {item}
              </li>
            ))}
          </ul>
        </div>
      )}

      {parsed?.proximoPasso && (
        <div className="rounded-lg border-l-4 border-l-[#A855F7] bg-card p-4 shadow-sm">
          <h3 className="font-bold text-base mb-3 text-[#A855F7]">PRÓXIMO PASSO EM 1 MINUTO</h3>
          <p className="text-sm font-medium text-foreground">
            {parsed.proximoPasso}
          </p>
        </div>
      )}
    </div>
  );

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[90vw] w-[1100px] h-[80vh] max-h-[850px] p-0 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b bg-gradient-to-r from-orange-500/10 to-transparent">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-orange-500/10 rounded-lg">
              <Bot className="h-6 w-6 text-orange-500" />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-foreground">Análise IA da H&H</h2>
              <p className="text-sm text-muted-foreground">Powered by Perplexity</p>
            </div>
          </div>
          <Button variant="ghost" size="icon" onClick={() => onOpenChange(false)}>
            <X className="h-5 w-5" />
          </Button>
        </div>

        {/* Main Tabs */}
        <Tabs value={viewTab} onValueChange={(v) => { setViewTab(v as ViewTab); setSelectedHistoryItem(null); }} className="flex flex-col h-[calc(100%-65px)]">
          <div className="px-6 pt-4 border-b">
            <TabsList className="w-full max-w-[400px]">
              <TabsTrigger value="new" className="flex-1 gap-2">
                <Bot size={16} />
                Nova Análise
              </TabsTrigger>
              <TabsTrigger value="history" className="flex-1 gap-2">
                <History size={16} />
                Histórico
              </TabsTrigger>
            </TabsList>
          </div>

          {/* New Analysis Tab */}
          <TabsContent value="new" className="flex-1 flex flex-col md:flex-row m-0 overflow-hidden">
            {/* Left Section - Controls */}
            <div className="w-full md:w-[350px] border-r bg-muted/30 p-6 flex flex-col overflow-y-auto">
              <div className="space-y-6 flex-1">
                {/* Mode Selection */}
                <div className="space-y-3">
                  <Label className="text-sm font-semibold text-foreground">Selecione o modo:</Label>
                  <RadioGroup 
                    value={mode} 
                    onValueChange={(v) => {
                      setMode(v as Mode);
                      setResult(null);
                      setPeriod(null);
                    }}
                    className="flex flex-col gap-3"
                  >
                    <div className="flex items-center space-x-3 p-3 rounded-lg border bg-background hover:bg-accent/50 transition-colors cursor-pointer">
                      <RadioGroupItem value="analysis" id="analysis" />
                      <Label htmlFor="analysis" className="cursor-pointer font-medium">⊙ Análise</Label>
                    </div>
                    <div className="flex items-center space-x-3 p-3 rounded-lg border bg-background hover:bg-accent/50 transition-colors cursor-pointer">
                      <RadioGroupItem value="consultation" id="consultation" />
                      <Label htmlFor="consultation" className="cursor-pointer font-medium">⊙ Consulta</Label>
                    </div>
                  </RadioGroup>
                </div>

                {/* Analysis Mode Controls */}
                {mode === 'analysis' && (
                  <div className="space-y-3">
                    <Label className="text-sm font-semibold text-foreground">Qual período deseja analisar?</Label>
                    <div className="flex flex-col gap-2">
                      <Button
                        variant={period === 'day' ? 'default' : 'outline'}
                        className="w-full justify-start gap-2 bg-orange-500 hover:bg-orange-600 text-white"
                        onClick={() => handleAnalyze('day')}
                        disabled={loading}
                      >
                        {loading && period === 'day' ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
                        Análise do Dia
                      </Button>
                      <Button
                        variant={period === 'month_current' ? 'default' : 'outline'}
                        className="w-full justify-start gap-2 bg-orange-500 hover:bg-orange-600 text-white"
                        onClick={() => handleAnalyze('month_current')}
                        disabled={loading}
                      >
                        {loading && period === 'month_current' ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
                        Análise do Mês Atual
                      </Button>
                      <Button
                        variant={period === 'month_previous' ? 'default' : 'outline'}
                        className="w-full justify-start gap-2 bg-orange-500 hover:bg-orange-600 text-white"
                        onClick={() => handleAnalyze('month_previous')}
                        disabled={loading}
                      >
                        {loading && period === 'month_previous' ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
                        Análise do Mês Anterior
                      </Button>
                    </div>
                  </div>
                )}

                {/* Consultation Mode Controls */}
                {mode === 'consultation' && (
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label className="text-sm font-semibold text-foreground">Cole a conversa do cliente:</Label>
                      <Textarea
                        value={contextText}
                        onChange={(e) => setContextText(e.target.value)}
                        placeholder="Cole aqui a conversa do WhatsApp ou resumo da negociação..."
                        className="min-h-[200px] font-mono text-sm bg-muted/50 resize-none"
                      />
                    </div>
                    <Button
                      className="w-full bg-orange-500 hover:bg-orange-600 text-white font-semibold"
                      onClick={handleConsultation}
                      disabled={loading || !contextText.trim()}
                    >
                      {loading ? (
                        <>
                          <Loader2 className="h-4 w-4 animate-spin mr-2" />
                          Gerando sugestão...
                        </>
                      ) : (
                        'Gerar Sugestão'
                      )}
                    </Button>
                  </div>
                )}
              </div>

              {/* Clear Button */}
              <Button 
                variant="outline" 
                className="w-full mt-4 gap-2"
                onClick={handleClear}
              >
                <Trash2 className="h-4 w-4" />
                Limpar
              </Button>
            </div>

            {/* Right Section - Results */}
            <div className="flex-1 flex flex-col bg-background overflow-hidden">
              {!result && !loading ? (
                <div className="flex-1 flex items-center justify-center text-muted-foreground">
                  <div className="text-center">
                    <Bot className="h-16 w-16 mx-auto mb-4 opacity-20" />
                    <p className="text-lg">Selecione um período ou cole uma conversa</p>
                    <p className="text-sm">O resultado aparecerá aqui</p>
                  </div>
                </div>
              ) : loading ? (
                <div className="flex-1 flex items-center justify-center">
                  <div className="text-center">
                    <Loader2 className="h-12 w-12 animate-spin text-orange-500 mx-auto mb-4" />
                    <p className="text-lg font-medium">Analisando dados com IA...</p>
                    <p className="text-sm text-muted-foreground">Isso pode levar alguns segundos</p>
                  </div>
                </div>
              ) : (
                <ScrollArea className="flex-1 p-6">
                  {renderResultCards()}
                </ScrollArea>
              )}

              {/* Footer Actions */}
              {result && (
                <div className="border-t p-4 flex gap-3">
                  <Button 
                    variant="outline" 
                    className="flex-1 gap-2"
                    onClick={handleCopy}
                  >
                    {copied ? <CheckCircle className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                    {copied ? 'Copiado!' : 'Copiar'}
                  </Button>
                  <Button 
                    className="flex-1 gap-2 bg-orange-500 hover:bg-orange-600 text-white"
                    onClick={handleSave}
                  >
                    <Save className="h-4 w-4" />
                    Salvar no Histórico
                  </Button>
                </div>
              )}
            </div>
          </TabsContent>

          {/* History Tab */}
          <TabsContent value="history" className="flex-1 flex flex-col md:flex-row m-0 overflow-hidden">
            {/* Left Section - History List */}
            <div className="w-full md:w-[350px] border-r bg-muted/30 flex flex-col overflow-hidden">
              <div className="p-4 border-b">
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold text-foreground">Análises Anteriores</h3>
                  <Button variant="ghost" size="sm" onClick={fetchHistory} disabled={historyLoading}>
                    <RotateCcw className={`h-4 w-4 ${historyLoading ? 'animate-spin' : ''}`} />
                  </Button>
                </div>
              </div>

              <ScrollArea className="flex-1">
                {historyLoading ? (
                  <div className="flex items-center justify-center py-12">
                    <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
                  </div>
                ) : history.length === 0 ? (
                  <div className="text-center py-12 text-muted-foreground">
                    <History className="h-12 w-12 mx-auto mb-3 opacity-30" />
                    <p>Nenhuma análise salva</p>
                  </div>
                ) : (
                  <div className="p-2 space-y-2">
                    {history.map((item) => (
                      <div
                        key={item.id}
                        className={`relative w-full text-left p-3 rounded-lg border transition-all hover:border-primary/30 ${
                          selectedHistoryItem?.id === item.id 
                            ? 'border-primary bg-primary/5' 
                            : 'bg-background'
                        }`}
                      >
                        <button
                          onClick={() => handleViewHistoryItem(item)}
                          className="w-full text-left"
                        >
                          <div className="flex items-center justify-between mb-1">
                            <Badge variant="outline" className="text-xs">
                              {getModeLabel(item.mode)} {getPeriodLabel(item.period)}
                            </Badge>
                            <ChevronRight size={14} className="text-muted-foreground" />
                          </div>
                          <div className="flex items-center gap-2 text-xs text-muted-foreground">
                            <Clock size={12} />
                            {format(new Date(item.created_at), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}
                          </div>
                          <p className="text-xs text-muted-foreground mt-2 line-clamp-2">
                            {item.output_text.slice(0, 100)}...
                          </p>
                        </button>
                        
                        {/* Delete button for admins */}
                        {isAdminOrOwner && (
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="absolute top-2 right-2 h-7 w-7 text-muted-foreground hover:text-destructive hover:bg-destructive/10"
                                onClick={(e) => e.stopPropagation()}
                              >
                                <Trash2 size={14} />
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Excluir Análise</AlertDialogTitle>
                                <AlertDialogDescription>
                                  Tem certeza que deseja excluir esta análise? Esta ação não pode ser desfeita.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Cancelar</AlertDialogCancel>
                                <AlertDialogAction
                                  onClick={() => handleDeleteHistoryItem(item.id)}
                                  className="bg-destructive hover:bg-destructive/90"
                                  disabled={deletingId === item.id}
                                >
                                  {deletingId === item.id ? (
                                    <Loader2 className="h-4 w-4 animate-spin" />
                                  ) : (
                                    'Excluir'
                                  )}
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </ScrollArea>
            </div>

            {/* Right Section - Selected History Item */}
            <div className="flex-1 flex flex-col bg-background overflow-hidden">
              {!selectedHistoryItem ? (
                <div className="flex-1 flex items-center justify-center text-muted-foreground">
                  <div className="text-center">
                    <History className="h-16 w-16 mx-auto mb-4 opacity-20" />
                    <p className="text-lg">Selecione uma análise para visualizar</p>
                    <p className="text-sm">Clique em uma das análises à esquerda</p>
                  </div>
                </div>
              ) : (
                <>
                  <div className="p-4 border-b flex items-center justify-between">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <Badge variant="outline">
                          {getModeLabel(selectedHistoryItem.mode)} {getPeriodLabel(selectedHistoryItem.period)}
                        </Badge>
                      </div>
                      <p className="text-xs text-muted-foreground flex items-center gap-1">
                        <Clock size={12} />
                        {format(new Date(selectedHistoryItem.created_at), "dd 'de' MMMM 'de' yyyy 'às' HH:mm", { locale: ptBR })}
                      </p>
                    </div>
                    <Button variant="ghost" size="sm" onClick={handleBackToList} className="md:hidden">
                      Voltar
                    </Button>
                  </div>
                  <ScrollArea className="flex-1 p-6">
                    {renderResultCards()}
                  </ScrollArea>
                  <div className="border-t p-4">
                    <Button 
                      variant="outline" 
                      className="w-full gap-2"
                      onClick={handleCopy}
                    >
                      {copied ? <CheckCircle className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                      {copied ? 'Copiado!' : 'Copiar'}
                    </Button>
                  </div>
                </>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
};
