import { useState, useMemo, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useActionCenterData, CriticalAlert } from '@/hooks/useActionCenterData';
import { useReplenishmentAlerts } from '@/hooks/useReplenishmentAlerts';
import { useTasksData, TaskData } from '@/hooks/useTasksData';
import { useWorkingDaysTargets } from '@/hooks/useWorkingDaysTargets';
import { useDailyFocus } from '@/hooks/useDailyFocus';
import { useCriticalBlocker } from '@/hooks/useCriticalBlocker';
import { useTaskLimits } from '@/hooks/useTaskLimits';
import { CriticalAlerts } from '@/components/action-center/CriticalAlerts';
import { TaskPrioritySection } from '@/components/meu-dia/TaskPrioritySection';
import { BulkActionsBar } from '@/components/meu-dia/BulkActionsBar';
import { ClickableScoreboard } from '@/components/meu-dia/ClickableScoreboard';
import { EmptyStateCard } from '@/components/meu-dia/EmptyStateCard';
import { MeuDiaDebugPanel } from '@/components/meu-dia/MeuDiaDebugPanel';
import { QuickShortcutsCard } from '@/components/meu-dia/QuickShortcutsCard';
import { BirthdaysCard } from '@/components/meu-dia/BirthdaysCard';
import { OpenQuotesCard } from '@/components/meu-dia/OpenQuotesCard';
import { PriorityQueueSection } from '@/components/meu-dia/PriorityQueueSection';
import { CarteiraRadar } from '@/components/radar/CarteiraRadar';
import { DailyFocusBlock } from '@/components/meu-dia/DailyFocusBlock';
import { CriticalBlockerModal } from '@/components/meu-dia/CriticalBlockerModal';
import { DeleteTaskModal } from '@/components/tasks/DeleteTaskModal';
import { AlertTriangle, Clock, CalendarCheck, Settings2, Users, Calculator } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { isToday, isPast, parseISO, isFuture } from 'date-fns';
import { PriceCalculatorModal } from '@/components/price-calculator/PriceCalculatorModal';

interface Props {
  effectiveSellerId: string | null;
  sellerId: string;
  isAdminOrOwner: boolean;
  isOwner?: boolean;
  debugEnabled: boolean;
  contactFilter: string | null;
  searchTerm: string;
  onSetTaskModalOpen: (v: boolean) => void;
  onSetPlanningModalOpen: (v: boolean) => void;
  onSetConfigModalOpen: (v: boolean) => void;
  onSetSelectedTask: (t: TaskData | null) => void;
  onSetAlertDetailsType: (t: CriticalAlert['type'] | null) => void;
  onSetCallsReportModalOpen: (v: boolean) => void;
  onSetWhatsappReportModalOpen: (v: boolean) => void;
  onSetContactFilter: (v: string | null) => void;
}

export function ActionCenterVendedor({
  effectiveSellerId, sellerId, isAdminOrOwner, isOwner = false, debugEnabled,
  contactFilter, searchTerm,
  onSetTaskModalOpen, onSetPlanningModalOpen, onSetConfigModalOpen,
  onSetSelectedTask, onSetAlertDetailsType,
  onSetCallsReportModalOpen, onSetWhatsappReportModalOpen, onSetContactFilter,
}: Props) {
  const navigate = useNavigate();
  const overdueRef = useRef<HTMLDivElement>(null);
  const todayRef = useRef<HTMLDivElement>(null);
  const upcomingRef = useRef<HTMLDivElement>(null);
  const [selectedTasks, setSelectedTasks] = useState<Set<string>>(new Set());
  const [deletingTask, setDeletingTask] = useState<TaskData | null>(null);
  const [priceCalcOpen, setPriceCalcOpen] = useState(false);

  const { alerts: baseAlerts, loading, refetch } = useActionCenterData(effectiveSellerId);
  const { totalClientsWithAlerts: replenishmentClientsCount, refetch: refetchReplenishment } = useReplenishmentAlerts(effectiveSellerId, 5);

  const alerts = useMemo(() => {
    const combined = [...baseAlerts];
    combined.push({
      id: 'replenishment',
      label: 'Clientes com reposição em atraso (5+)',
      count: replenishmentClientsCount,
      type: 'replenishment_overdue' as const,
    });
    return combined;
  }, [baseAlerts, replenishmentClientsCount]);

  const { workMonthConfig, isConfigured, sellerMetrics, refetch: refetchTargets } = useWorkingDaysTargets(effectiveSellerId);
  const { tasks, loading: tasksLoading, refetch: refetchTasks } = useTasksData(undefined, effectiveSellerId);
  const { hasCriticalBlock, criticalTasks, snooze } = useCriticalBlocker();
  const { focusItems, focusTaskIds, addFocus, removeFocus, suggestFocus, refetch: refetchFocus } = useDailyFocus();
  const taskLimits = useTaskLimits(tasks, effectiveSellerId);

  const handleRefresh = () => {
    refetch();
    refetchTasks();
    refetchTargets();
    refetchReplenishment();
    refetchFocus();
    setSelectedTasks(new Set());
  };

  const pendingForSeller = useMemo(() =>
    tasks.filter(t => {
      if (t.status !== 'pendente') return false;
      // Hide system/automated tasks from sellers (only show commercial tasks)
      if (t.createdByTrigger || t.sourceModule) return false;
      if (!t.clientId && !t.clientName) return false; // No client = system task
      if (effectiveSellerId) {
        return t.clientSellerId === effectiveSellerId || t.assignedToSellerId === effectiveSellerId || t.createdBySellerId === effectiveSellerId;
      }
      return true;
    }),
    [tasks, effectiveSellerId]
  );
  const focusSuggestions = useMemo(() => suggestFocus(pendingForSeller), [pendingForSeller, focusItems]);

  const { aggregated } = useWorkingDaysTargets(effectiveSellerId);

  const currentMetrics = useMemo(() => {
    // If a specific seller is selected, use their individual metrics
    if (effectiveSellerId && sellerMetrics.has(effectiveSellerId)) {
      return sellerMetrics.get(effectiveSellerId)!;
    }
    // If no seller selected (Master "all" view), use aggregated data from ALL sellers
    if (!effectiveSellerId) {
      return {
        actualCallsToday: aggregated.actualCallsTodayAll,
        actualWhatsappToday: aggregated.actualWhatsappTodayAll,
        actualContactsToday: aggregated.actualContactsTodayAll,
        actualSalesToday: aggregated.actualSalesTodayAll,
        metaCallsToday: aggregated.metaCallsTodayAll,
        metaWhatsappToday: aggregated.metaWhatsappTodayAll,
        metaContactsToday: aggregated.metaContactsTodayAll,
        remainingCallsMonth: aggregated.remainingCallsMonthAll,
        remainingWhatsappMonth: aggregated.remainingWhatsappMonthAll,
        remainingContactsMonth: aggregated.remainingContactsMonthAll,
        remainingSalesMonth: aggregated.remainingSalesMonthAll,
        neededCallsPerDayFromNow: 0,
        neededWhatsappPerDayFromNow: 0,
        neededContactsPerDayFromNow: 0,
        neededSalesPerDayFromNow: 0,
        workingDays: workMonthConfig?.workingDays || 22,
        elapsedWorkdays: 0,
        remainingWorkdays: 1,
      };
    }
    return {
      actualCallsToday: 0, actualWhatsappToday: 0, actualContactsToday: 0, actualSalesToday: 0,
      metaCallsToday: 36, metaWhatsappToday: 18, metaContactsToday: 36,
      remainingCallsMonth: 0, remainingWhatsappMonth: 0, remainingContactsMonth: 0, remainingSalesMonth: 0,
      neededCallsPerDayFromNow: 0, neededWhatsappPerDayFromNow: 0, neededContactsPerDayFromNow: 0, neededSalesPerDayFromNow: 0,
      workingDays: workMonthConfig?.workingDays || 22, elapsedWorkdays: 0, remainingWorkdays: 1,
    };
  }, [effectiveSellerId, sellerMetrics, workMonthConfig, aggregated]);

  const { overdueTasks, todayTasks, upcomingTasks, delegatedTasks } = useMemo(() => {
    const searchLower = searchTerm.toLowerCase().trim();
    const pending = tasks
      .filter(t => t.status === 'pendente')
      .filter(t => !t.createdByTrigger && !t.sourceModule) // Exclude system/automated tasks
      .filter(t => t.clientId || t.clientName) // Exclude tasks without client association
      .filter(t => (effectiveSellerId ? (t.createdBySellerId === effectiveSellerId || t.assignedToSellerId === effectiveSellerId) : true))
      .filter(t => { if (!contactFilter) return true; return t.contactType === contactFilter; })
      .filter(t => { if (!searchLower) return true; return t.clientName.toLowerCase().includes(searchLower); });

    const isDelegatedToMe = (t: TaskData) =>
      effectiveSellerId && t.assignedToSellerId === effectiveSellerId && t.createdBySellerId !== effectiveSellerId;

    const delegated: TaskData[] = [];
    const overdue: TaskData[] = [];
    const today: TaskData[] = [];
    const upcoming: TaskData[] = [];

    pending.forEach(task => {
      if (isDelegatedToMe(task)) { delegated.push(task); return; }
      const taskDate = parseISO(task.taskDate);
      if (isPast(taskDate) && !isToday(taskDate)) overdue.push(task);
      else if (isToday(taskDate)) today.push(task);
      else if (isFuture(taskDate)) upcoming.push(task);
    });

    // Also include completed delegated tasks awaiting manager confirmation
    const completedDelegated = tasks
      .filter(t => t.status === 'concluida' && !t.managerConfirmedAt && isDelegatedToMe(t))
      .filter(t => { if (!searchLower) return true; return t.clientName.toLowerCase().includes(searchLower); });
    delegated.push(...completedDelegated);

    const sortTasks = (a: TaskData, b: TaskData) => {
      const priorityOrder = { alta: 0, media: 1, baixa: 2 };
      const aPrio = priorityOrder[a.priority] ?? 1;
      const bPrio = priorityOrder[b.priority] ?? 1;
      if (aPrio !== bPrio) return aPrio - bPrio;
      return parseISO(a.taskDate).getTime() - parseISO(b.taskDate).getTime();
    };

    return {
      overdueTasks: overdue.sort(sortTasks),
      todayTasks: today.sort(sortTasks),
      upcomingTasks: upcoming.sort(sortTasks),
      delegatedTasks: delegated.sort(sortTasks),
    };
  }, [tasks, effectiveSellerId, contactFilter, searchTerm]);

  const totalPending = overdueTasks.length + todayTasks.length + upcomingTasks.length + delegatedTasks.length;

  const toggleTask = (taskId: string) => {
    setSelectedTasks(prev => {
      const next = new Set(prev);
      if (next.has(taskId)) next.delete(taskId); else next.add(taskId);
      return next;
    });
  };

  const handleTaskClick = (task: TaskData) => onSetSelectedTask(task);
  const handleDeleteTask = (task: TaskData) => setDeletingTask(task);

  return (
    <>
      {/* Simular Preço button — top right, discrete */}
      <div className="flex justify-end mb-2">
        <Button variant="outline" size="sm" onClick={() => setPriceCalcOpen(true)}
          className="text-[12px] h-8 gap-1.5 font-medium">
          <Calculator className="h-3.5 w-3.5" />
          Simular Preço
        </Button>
      </div>

      <DailyFocusBlock
        focusItems={focusItems}
        allTasks={pendingForSeller}
        suggestions={focusSuggestions}
        focusTaskIds={focusTaskIds}
        onAddFocus={addFocus}
        onRemoveFocus={removeFocus}
        onTaskClick={handleTaskClick}
      />

      {taskLimits.showWarning && (
        <p className="text-[12px] text-muted-foreground">
          ⚠ Limite atingido ({taskLimits.pendingCount} abertas, máx. {taskLimits.warnLimit}).
          {taskLimits.isBlocked ? ' Criação bloqueada.' : ' Finalize antes de criar novas.'}
        </p>
      )}

      <OpenQuotesCard sellerId={effectiveSellerId} onCreateTask={() => onSetTaskModalOpen(true)} />
      <BirthdaysCard sellerId={effectiveSellerId} />

      <QuickShortcutsCard
        overdueCount={overdueTasks.length}
        todayCount={todayTasks.length}
        upcomingCount={upcomingTasks.length}
        onScrollToOverdue={() => overdueRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' })}
        onScrollToToday={() => todayRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' })}
        onScrollToUpcoming={() => upcomingRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' })}
      />

      <PriorityQueueSection />

      <CarteiraRadar />

      <CriticalAlerts alerts={alerts} onAlertClick={(type) => onSetAlertDetailsType(type as CriticalAlert['type'])} />

      {isAdminOrOwner && (
        <div className="flex justify-end mb-2">
          <Button variant="ghost" size="sm" onClick={() => onSetConfigModalOpen(true)}
            className="text-[11px] font-medium text-muted-foreground">
            <Settings2 className="h-3 w-3 mr-1" />
            Configurar dias úteis
          </Button>
        </div>
      )}
      <ClickableScoreboard
        metrics={currentMetrics}
        isConfigured={isConfigured}
        activeFilter={contactFilter}
        onFilterChange={onSetContactFilter}
        onCallsCardClick={() => onSetCallsReportModalOpen(true)}
        onWhatsappCardClick={() => onSetWhatsappReportModalOpen(true)}
      />

      {debugEnabled && effectiveSellerId && <MeuDiaDebugPanel effectiveSellerId={effectiveSellerId} />}

      <div ref={overdueRef}>
        <TaskPrioritySection title="Atrasadas" subtitle={overdueTasks.length > 0 ? `${overdueTasks.length} tarefas precisam de atenção` : undefined} icon={<AlertTriangle className="h-5 w-5 text-destructive" />} tasks={overdueTasks} variant="overdue" selectedTasks={selectedTasks} onToggleTask={toggleTask} onComplete={handleTaskClick} onTaskClick={handleTaskClick} onDeleteTask={isOwner ? handleDeleteTask : undefined} onRequestReschedule={(task) => console.log('Request reschedule:', task.id)} isAdmin={isAdminOrOwner} isOwner={isOwner} emptyState={<EmptyStateCard variant="overdue" onCreateTask={() => onSetTaskModalOpen(true)} onSearchClients={() => navigate('/clients?filter=no-contact-20')} />} />
      </div>

      <div ref={todayRef}>
        <TaskPrioritySection title="Tarefas de Hoje" subtitle={todayTasks.length > 0 ? `${todayTasks.length} tarefas para hoje` : undefined} icon={<Clock className="h-5 w-5 text-status-warning" />} tasks={todayTasks} variant="today" selectedTasks={selectedTasks} onToggleTask={toggleTask} onComplete={handleTaskClick} onTaskClick={handleTaskClick} onDeleteTask={isOwner ? handleDeleteTask : undefined} onCreateFollowup={(task) => console.log('Create followup:', task.id)} isAdmin={isAdminOrOwner} isOwner={isOwner} emptyState={<EmptyStateCard variant="today" onCreateTask={() => onSetTaskModalOpen(true)} onSearchClients={() => navigate('/clients?filter=no-contact-20')} onPlanWeek={() => onSetPlanningModalOpen(true)} />} />
      </div>

      <div ref={upcomingRef}>
        <TaskPrioritySection title="Próximos Dias" subtitle={upcomingTasks.length > 0 ? `${upcomingTasks.length} tarefas agendadas` : undefined} icon={<CalendarCheck className="h-5 w-5 text-primary" />} tasks={upcomingTasks} variant="upcoming" selectedTasks={selectedTasks} onToggleTask={toggleTask} onComplete={handleTaskClick} onTaskClick={handleTaskClick} onDeleteTask={isOwner ? handleDeleteTask : undefined} isAdmin={isAdminOrOwner} isOwner={isOwner} emptyState={<EmptyStateCard variant="upcoming" onCreateTask={() => onSetTaskModalOpen(true)} onSearchClients={() => navigate('/clients?filter=no-contact-20')} onPlanWeek={() => onSetPlanningModalOpen(true)} />} />
      </div>

      {delegatedTasks.length > 0 && (
        <div>
          <TaskPrioritySection title="Delegadas para mim" subtitle={`${delegatedTasks.length} tarefa${delegatedTasks.length !== 1 ? 's' : ''} delegada${delegatedTasks.length !== 1 ? 's' : ''}`} icon={<Users className="h-5 w-5 text-primary" />} tasks={delegatedTasks} variant="upcoming" selectedTasks={selectedTasks} onToggleTask={toggleTask} onComplete={handleTaskClick} onTaskClick={handleTaskClick} onDeleteTask={isOwner ? handleDeleteTask : undefined} isAdmin={isAdminOrOwner} isOwner={isOwner} emptyState={null} />
        </div>
      )}

      {totalPending === 0 && (
        <EmptyStateCard variant="all" onCreateTask={() => onSetTaskModalOpen(true)} onSearchClients={() => navigate('/clients?filter=no-contact-20')} onPlanWeek={() => onSetPlanningModalOpen(true)} />
      )}

      <BulkActionsBar selectedCount={selectedTasks.size} selectedTaskIds={selectedTasks} onClearSelection={() => setSelectedTasks(new Set())} onActionComplete={handleRefresh} sellerId={sellerId} />

      <CriticalBlockerModal
        open={hasCriticalBlock}
        tasks={criticalTasks}
        onOpenTask={(taskId) => {
          const task = tasks.find(t => t.id === taskId);
          if (task) onSetSelectedTask(task);
        }}
        onSnooze={snooze}
      />

      {/* Owner-only delete modal */}
      {deletingTask && (
        <DeleteTaskModal
          open={!!deletingTask}
          onOpenChange={(open) => !open && setDeletingTask(null)}
          taskId={deletingTask.id}
          isCompleted={deletingTask.status === 'concluida'}
          onDeleted={handleRefresh}
          taskInfo={{
            clientId: deletingTask.clientId,
            clientName: deletingTask.clientName,
            taskDate: deletingTask.taskDate,
            notes: deletingTask.notes || undefined,
            contactType: deletingTask.contactType,
            contactReason: deletingTask.contactReason,
            responsibleSellerId: deletingTask.createdBySellerId || undefined,
          }}
        />
      )}

      <PriceCalculatorModal
        open={priceCalcOpen}
        onOpenChange={setPriceCalcOpen}
        sellerId={effectiveSellerId}
        isAdmin={isAdminOrOwner}
      />
    </>
  );
}
