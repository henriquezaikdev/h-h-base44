import { useState } from 'react';
import { Loader2, Copy, CheckCircle, MessageSquare, ArrowRight } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { ScrollArea } from '@/components/ui/scroll-area';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface AIAskModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  sellerId: string | undefined;
}

export const AIAskModal = ({ open, onOpenChange, sellerId }: AIAskModalProps) => {
  const [contextText, setContextText] = useState('');
  const [userQuestion, setUserQuestion] = useState('');
  const [copyForWhatsApp, setCopyForWhatsApp] = useState(true);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const handleAsk = async () => {
    if (!sellerId) {
      toast.error('Vendedor não identificado');
      return;
    }

    if (!contextText.trim()) {
      toast.error('Cole o contexto da conversa');
      return;
    }

    if (!userQuestion.trim()) {
      toast.error('Digite sua pergunta');
      return;
    }

    setLoading(true);
    setResult(null);

    try {
      const { data, error } = await supabase.functions.invoke('perplexity-assistant', {
        body: {
          mode: 'ask',
          sellerId,
          contextText,
          userQuestion,
          copyForWhatsApp,
        },
      });

      if (error) throw error;

      setResult(data.answer);
      toast.success('Resposta gerada!');
    } catch (error) {
      console.error('Error calling AI:', error);
      toast.error('Erro ao gerar resposta. Tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = async () => {
    if (!result) return;
    
    // Extract just the suggested response part for WhatsApp
    const match = result.match(/\*\*RESPOSTA SUGERIDA\*\*[^*]*:\s*([\s\S]*?)(?=\*\*OBSERVAÇÕES|$)/i);
    const textToCopy = match ? match[1].trim() : result;
    
    await navigator.clipboard.writeText(textToCopy);
    setCopied(true);
    toast.success('Copiado para a área de transferência!');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleReset = () => {
    setContextText('');
    setUserQuestion('');
    setResult(null);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <MessageSquare className="h-5 w-5 text-primary" />
            Assistente de Atendimento / Fechamento
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {!result ? (
            <>
              {/* Context Input */}
              <div className="space-y-2">
                <Label htmlFor="context">Cole aqui o contexto (conversa do WhatsApp / resumo do caso)</Label>
                <Textarea
                  id="context"
                  value={contextText}
                  onChange={(e) => setContextText(e.target.value)}
                  placeholder="Cole aqui a conversa do WhatsApp, resumo da negociação, ou contexto do atendimento..."
                  className="min-h-[150px] resize-none"
                />
              </div>

              {/* Question Input */}
              <div className="space-y-2">
                <Label htmlFor="question">Qual sua pergunta?</Label>
                <Input
                  id="question"
                  value={userQuestion}
                  onChange={(e) => setUserQuestion(e.target.value)}
                  placeholder="Ex: Como responder essa objeção de preço?"
                />
              </div>

              {/* WhatsApp Checkbox */}
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="whatsapp"
                  checked={copyForWhatsApp}
                  onCheckedChange={(checked) => setCopyForWhatsApp(checked as boolean)}
                />
                <Label htmlFor="whatsapp" className="cursor-pointer text-sm">
                  Resposta pronta para copiar/colar no WhatsApp
                </Label>
              </div>

              {/* Submit Button */}
              <Button 
                onClick={handleAsk} 
                disabled={loading}
                className="w-full gap-2"
              >
                {loading ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Pensando com padrão H&H...
                  </>
                ) : (
                  <>
                    Responder com padrão H&H
                    <ArrowRight className="h-4 w-4" />
                  </>
                )}
              </Button>
            </>
          ) : (
            <>
              {/* Results */}
              <ScrollArea className="h-[350px] rounded-lg border bg-muted/30 p-4">
                <div className="prose prose-sm dark:prose-invert max-w-none">
                  {result.split('\n').map((line, i) => {
                    if (line.startsWith('**') && line.includes('**')) {
                      const cleanLine = line.replace(/\*\*/g, '');
                      return (
                        <h4 key={i} className="font-semibold text-primary mt-4 mb-2">
                          {cleanLine}
                        </h4>
                      );
                    }
                    if (line.trim()) {
                      return <p key={i} className="text-sm text-foreground mb-2">{line}</p>;
                    }
                    return null;
                  })}
                </div>
              </ScrollArea>

              {/* Action Buttons */}
              <div className="flex gap-2">
                <Button 
                  variant="outline" 
                  onClick={handleReset}
                  className="flex-1"
                >
                  Nova pergunta
                </Button>
                <Button 
                  onClick={handleCopy}
                  className="flex-1 gap-2"
                >
                  {copied ? (
                    <>
                      <CheckCircle className="h-4 w-4" />
                      Copiado!
                    </>
                  ) : (
                    <>
                      <Copy className="h-4 w-4" />
                      Copiar resposta
                    </>
                  )}
                </Button>
              </div>
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};
