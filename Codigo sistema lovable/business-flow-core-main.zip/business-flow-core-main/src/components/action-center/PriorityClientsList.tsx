import { Phone, MessageCircle, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { PriorityClient } from '@/hooks/useActionCenterData';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { toast } from 'sonner';
import { format } from 'date-fns';

interface PriorityClientsListProps {
  clients: PriorityClient[];
  filterType?: string | null;
  onContactMade: () => void;
}

const tierConfig: Record<string, { label: string; dot: string }> = {
  top20: { label: 'Top 20', dot: 'bg-amber-500' },
  top100: { label: 'Top 100', dot: 'bg-violet-500' },
  top200: { label: 'Top 200', dot: 'bg-blue-500' },
  geral: { label: 'Geral', dot: 'bg-muted-foreground/50' },
  eventual: { label: 'Eventual', dot: 'bg-muted-foreground/30' },
};

export function PriorityClientsList({ clients, filterType, onContactMade }: PriorityClientsListProps) {
  const navigate = useNavigate();
  const { seller } = useAuth();

  const filteredClients = filterType 
    ? clients.filter(c => c.reasonType === filterType)
    : clients;

  const handleWhatsApp = async (client: PriorityClient, e: React.MouseEvent) => {
    e.stopPropagation();
    const phone = client.buyerWhatsapp || client.phone;
    if (!phone) {
      toast.error('Nenhum telefone cadastrado');
      return;
    }

    const cleanPhone = phone.replace(/\D/g, '');
    const message = encodeURIComponent(`Olá! Tudo bem? Aqui é da H&H Suprimentos.`);
    const now = new Date();
    
    await Promise.all([
      supabase.from('interactions').insert({
        client_id: client.id,
        interaction_type: 'whatsapp',
        interaction_date: format(now, 'yyyy-MM-dd'),
        interaction_time: format(now, 'HH:mm:ss'),
        interaction_notes: 'Contato via WhatsApp - Central de Ação',
        responsible_seller_id: seller?.id,
      }),
      supabase.from('clients').update({ last_contact_at: now.toISOString() }).eq('id', client.id),
    ]);

    window.open(`https://wa.me/55${cleanPhone}?text=${message}`, '_blank');
    toast.success('Contato registrado');
    onContactMade();
  };

  const handleCall = async (client: PriorityClient, e: React.MouseEvent) => {
    e.stopPropagation();
    const phone = client.phone || client.buyerWhatsapp;
    if (!phone) {
      toast.error('Nenhum telefone cadastrado');
      return;
    }

    const now = new Date();
    
    await Promise.all([
      supabase.from('interactions').insert({
        client_id: client.id,
        interaction_type: 'ligacao',
        interaction_date: format(now, 'yyyy-MM-dd'),
        interaction_time: format(now, 'HH:mm:ss'),
        interaction_notes: 'Tentativa de ligação - Central de Ação',
        responsible_seller_id: seller?.id,
      }),
      supabase.from('clients').update({ last_contact_at: now.toISOString() }).eq('id', client.id),
    ]);

    toast.success('Ligação registrada');
    onContactMade();
    navigate(`/clients/${client.id}?from=%2Faction-center`);
  };

  if (filteredClients.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
        <div className="w-12 h-12 rounded-full bg-muted/50 flex items-center justify-center mb-3">
          <MessageCircle size={20} className="opacity-50" />
        </div>
        <p className="text-sm">Nenhum cliente prioritário</p>
      </div>
    );
  }

  return (
    <div className="space-y-1.5 max-h-[400px] overflow-y-auto pr-1">
      {filteredClients.map((client) => {
        const tier = tierConfig[client.tier] || tierConfig.geral;
        
        return (
          <div
            key={client.id}
            onClick={() => navigate(`/clients/${client.id}?from=%2Faction-center`)}
            className="group flex items-center gap-3 p-3 rounded-xl border border-transparent bg-muted/20 hover:bg-muted/40 hover:border-border/50 cursor-pointer transition-all duration-200"
          >
            {/* Tier indicator */}
            <div className={`w-1.5 h-8 rounded-full ${tier.dot}`} />
            
            {/* Content */}
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <span className="font-medium text-foreground text-sm truncate">
                  {client.companyName}
                </span>
                <span className="text-[10px] text-muted-foreground px-1.5 py-0.5 rounded-md bg-foreground/5">
                  {tier.label}
                </span>
              </div>
              <div className="flex items-center gap-2 mt-0.5">
                {client.daysSinceOrder !== null && (
                  <span className="text-xs text-muted-foreground">
                    {client.daysSinceOrder}d sem compra
                  </span>
                )}
                <span className="text-xs text-primary/80">{client.reason}</span>
              </div>
            </div>
            
            {/* Actions */}
            <div className="flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
              <Button
                size="sm"
                variant="ghost"
                className="h-8 w-8 p-0 text-emerald-600 hover:bg-emerald-500/10"
                onClick={(e) => handleWhatsApp(client, e)}
              >
                <MessageCircle size={15} />
              </Button>
              <Button
                size="sm"
                variant="ghost"
                className="h-8 w-8 p-0 text-blue-600 hover:bg-blue-500/10"
                onClick={(e) => handleCall(client, e)}
              >
                <Phone size={15} />
              </Button>
            </div>
            
            <ChevronRight size={14} className="text-muted-foreground/50 group-hover:text-muted-foreground transition-colors" />
          </div>
        );
      })}
    </div>
  );
}
