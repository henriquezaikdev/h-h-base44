import { useState, useEffect, useMemo } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { Loader2, Phone, Search, Calendar, ChevronDown, ChevronUp, ExternalLink } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { format, startOfDay, endOfDay, subDays, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { useNavigate } from 'react-router-dom';
import { cn } from '@/lib/utils';

interface CallItem {
  id: string;
  source: 'task' | 'interaction';
  datetime: string;
  clientId: string;
  clientName: string;
  sellerId: string;
  sellerName: string;
  notes: string | null;
  status?: string;
}

interface CallsReportModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  sellerId: string;
  sellerName?: string;
  isAdmin?: boolean;
  sellers?: Array<{ id: string; name: string }>;
}

function saoPauloDayKey(date: Date): string {
  return new Intl.DateTimeFormat('sv-SE', {
    timeZone: 'America/Sao_Paulo',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(date);
}

function saoPauloDayRange(date: Date) {
  const dayKey = saoPauloDayKey(date);
  const startIso = `${dayKey}T00:00:00-03:00`;
  const endIso = `${dayKey}T23:59:59.999-03:00`;
  return { dayKey, startIso, endIso };
}

const PAGE_SIZE = 20;

export function CallsReportModal({
  open,
  onOpenChange,
  sellerId,
  sellerName = 'Vendedor',
  isAdmin = false,
  sellers = [],
}: CallsReportModalProps) {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [allItems, setAllItems] = useState<CallItem[]>([]);
  const [expandedRows, setExpandedRows] = useState<Set<string>>(new Set());
  const [displayCount, setDisplayCount] = useState(PAGE_SIZE);

  // Filters
  const [dateFilter, setDateFilter] = useState<'today' | 'yesterday' | 'custom'>('today');
  const [customStartDate, setCustomStartDate] = useState('');
  const [customEndDate, setCustomEndDate] = useState('');
  const [selectedSellerId, setSelectedSellerId] = useState(sellerId);
  const [sourceFilter, setSourceFilter] = useState<'all' | 'tasks' | 'interactions'>('all');
  const [clientSearch, setClientSearch] = useState('');

  // Reset selected seller when modal opens
  useEffect(() => {
    if (open) {
      setSelectedSellerId(sellerId);
      setDateFilter('today');
      setSourceFilter('all');
      setClientSearch('');
      setExpandedRows(new Set());
      setDisplayCount(PAGE_SIZE);
    }
  }, [open, sellerId]);

  // Compute date range based on filter
  const dateRange = useMemo(() => {
    const now = new Date();
    if (dateFilter === 'today') {
      return saoPauloDayRange(now);
    } else if (dateFilter === 'yesterday') {
      return saoPauloDayRange(subDays(now, 1));
    } else if (customStartDate && customEndDate) {
      return {
        dayKey: customStartDate,
        startIso: `${customStartDate}T00:00:00-03:00`,
        endIso: `${customEndDate}T23:59:59.999-03:00`,
      };
    }
    return saoPauloDayRange(now);
  }, [dateFilter, customStartDate, customEndDate]);

  // Fetch data
  useEffect(() => {
    if (!open || !selectedSellerId) return;

    const fetchCallItems = async () => {
      setLoading(true);
      const items: CallItem[] = [];

      try {
        // 1. Fetch interactions (type = Ligação)
        if (sourceFilter === 'all' || sourceFilter === 'interactions') {
          const { data: interactions } = await supabase
            .from('interactions')
            .select(`
              id,
              interaction_date,
              interaction_time,
              interaction_notes,
              interaction_type,
              client:clients!interactions_client_id_fkey(id, company_name),
              seller:sellers!interactions_responsible_seller_id_fkey(id, name)
            `)
            .eq('responsible_seller_id', selectedSellerId)
            .gte('interaction_date', dateRange.dayKey.split('T')[0])
            .lte('interaction_date', dateFilter === 'custom' && customEndDate ? customEndDate : dateRange.dayKey)
            .or('interaction_type.ilike.%ligaç%,interaction_type.ilike.%ligac%,interaction_type.eq.ligacao,interaction_type.eq.call')
            .order('interaction_date', { ascending: false })
            .order('interaction_time', { ascending: false });

          (interactions || []).forEach((i: any) => {
            items.push({
              id: i.id,
              source: 'interaction',
              datetime: `${i.interaction_date}T${i.interaction_time || '00:00:00'}`,
              clientId: i.client?.id || '',
              clientName: i.client?.company_name || 'Cliente desconhecido',
              sellerId: i.seller?.id || selectedSellerId,
              sellerName: i.seller?.name || sellerName,
              notes: i.interaction_notes,
            });
          });
        }

        // 2. Fetch completed tasks (type = Ligação)
        if (sourceFilter === 'all' || sourceFilter === 'tasks') {
          const { data: tasks } = await supabase
            .from('tasks')
            .select(`
              id,
              completed_at,
              completion_notes,
              notes,
              contact_type,
              status,
              client:clients!tasks_client_id_fkey(id, company_name, seller_id),
              created_by:sellers!tasks_created_by_seller_id_fkey(id, name)
            `)
            .eq('status', 'concluida')
            .gte('completed_at', dateRange.startIso)
            .lte('completed_at', dateRange.endIso)
            .or('contact_type.ilike.%ligaç%,contact_type.ilike.%ligac%,contact_type.eq.ligacao')
            .order('completed_at', { ascending: false });

          // Filter by seller (via client.seller_id)
          (tasks || [])
            .filter((t: any) => t.client?.seller_id === selectedSellerId)
            .forEach((t: any) => {
              items.push({
                id: t.id,
                source: 'task',
                datetime: t.completed_at,
                clientId: t.client?.id || '',
                clientName: t.client?.company_name || 'Cliente desconhecido',
                sellerId: t.client?.seller_id || selectedSellerId,
                sellerName: t.created_by?.name || sellerName,
                notes: t.completion_notes || t.notes,
                status: t.status,
              });
            });
        }

        // Sort by datetime descending
        items.sort((a, b) => new Date(b.datetime).getTime() - new Date(a.datetime).getTime());
        setAllItems(items);
        setDisplayCount(PAGE_SIZE);
      } catch (error) {
        console.error('Error fetching call items:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchCallItems();
  }, [open, selectedSellerId, dateRange, sourceFilter, dateFilter, customEndDate, sellerName]);

  // Filter by client search
  const filteredItems = useMemo(() => {
    if (!clientSearch.trim()) return allItems;
    const search = clientSearch.toLowerCase();
    return allItems.filter(item => item.clientName.toLowerCase().includes(search));
  }, [allItems, clientSearch]);

  // Paginated items
  const displayedItems = useMemo(() => {
    return filteredItems.slice(0, displayCount);
  }, [filteredItems, displayCount]);

  const hasMore = displayCount < filteredItems.length;

  const toggleRowExpand = (id: string) => {
    setExpandedRows(prev => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const handleLoadMore = () => {
    setDisplayCount(prev => prev + PAGE_SIZE);
  };

  const handleClientClick = (clientId: string) => {
    onOpenChange(false);
    navigate(`/clients/${clientId}`);
  };

  const getDateLabel = () => {
    if (dateFilter === 'today') return 'Hoje';
    if (dateFilter === 'yesterday') return 'Ontem';
    if (customStartDate && customEndDate) {
      if (customStartDate === customEndDate) {
        return format(parseISO(customStartDate), "dd 'de' MMM", { locale: ptBR });
      }
      return `${format(parseISO(customStartDate), 'dd/MM')} - ${format(parseISO(customEndDate), 'dd/MM')}`;
    }
    return 'Hoje';
  };

  const selectedSellerName = sellers.find(s => s.id === selectedSellerId)?.name || sellerName;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl h-[90vh] flex flex-col overflow-hidden">
        <DialogHeader className="flex-shrink-0">
          <DialogTitle className="flex items-center gap-2">
            <Phone className="h-5 w-5 text-blue-600" />
            Relatório de Ligações
          </DialogTitle>
          <p className="text-sm text-muted-foreground">
            {getDateLabel()} • {selectedSellerName}
          </p>
        </DialogHeader>

        {/* Filters */}
        <div className="flex flex-wrap gap-3 py-3 border-b flex-shrink-0">
          <Select value={dateFilter} onValueChange={(v) => setDateFilter(v as any)}>
            <SelectTrigger className="w-[140px]">
              <Calendar className="h-4 w-4 mr-2" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="today">Hoje</SelectItem>
              <SelectItem value="yesterday">Ontem</SelectItem>
              <SelectItem value="custom">Intervalo</SelectItem>
            </SelectContent>
          </Select>

          {dateFilter === 'custom' && (
            <>
              <Input
                type="date"
                value={customStartDate}
                onChange={(e) => setCustomStartDate(e.target.value)}
                className="w-[150px]"
              />
              <Input
                type="date"
                value={customEndDate}
                onChange={(e) => setCustomEndDate(e.target.value)}
                className="w-[150px]"
              />
            </>
          )}

          {isAdmin && sellers.length > 0 && (
            <Select value={selectedSellerId} onValueChange={setSelectedSellerId}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Vendedor" />
              </SelectTrigger>
              <SelectContent>
                {sellers.map((s) => (
                  <SelectItem key={s.id} value={s.id}>
                    {s.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}

          <Select value={sourceFilter} onValueChange={(v) => setSourceFilter(v as any)}>
            <SelectTrigger className="w-[150px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos</SelectItem>
              <SelectItem value="tasks">Tarefas</SelectItem>
              <SelectItem value="interactions">Interações</SelectItem>
            </SelectContent>
          </Select>

          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Buscar cliente..."
              value={clientSearch}
              onChange={(e) => setClientSearch(e.target.value)}
              className="pl-9"
            />
          </div>
        </div>

        {/* Summary */}
        <div className="flex items-center gap-4 py-2 text-sm flex-shrink-0">
          <span className="font-medium">
            Mostrando {displayedItems.length} de {filteredItems.length} ligações
          </span>
          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
            Interações: {filteredItems.filter(i => i.source === 'interaction').length}
          </Badge>
          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
            Tarefas: {filteredItems.filter(i => i.source === 'task').length}
          </Badge>
        </div>

        {/* Table with scroll */}
        <div className="flex-1 overflow-y-auto min-h-0">
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : filteredItems.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
              <Phone className="h-12 w-12 mb-4 opacity-50" />
              <p>Nenhuma ligação encontrada no período</p>
            </div>
          ) : (
            <>
              <Table>
                <TableHeader className="sticky top-0 bg-background z-10">
                  <TableRow>
                    <TableHead className="w-[140px]">Data/Hora</TableHead>
                    <TableHead>Cliente</TableHead>
                    <TableHead className="w-[120px]">Vendedor</TableHead>
                    <TableHead className="w-[100px]">Origem</TableHead>
                    <TableHead>Observações</TableHead>
                    <TableHead className="w-[50px]"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {displayedItems.map((item) => {
                    const isExpanded = expandedRows.has(item.id);
                    const hasNotes = item.notes && item.notes.trim().length > 0;
                    const notesLength = item.notes?.length || 0;

                    return (
                      <TableRow key={item.id} className="group">
                        <TableCell className="font-mono text-xs">
                          {format(parseISO(item.datetime), "dd/MM HH:mm", { locale: ptBR })}
                        </TableCell>
                        <TableCell>
                          <button
                            onClick={() => handleClientClick(item.clientId)}
                            className="flex items-center gap-1 text-left hover:text-primary hover:underline transition-colors"
                          >
                            {item.clientName}
                            <ExternalLink className="h-3 w-3 opacity-0 group-hover:opacity-100 transition-opacity" />
                          </button>
                        </TableCell>
                        <TableCell className="text-sm text-muted-foreground">
                          {item.sellerName}
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant="outline"
                            className={cn(
                              item.source === 'interaction'
                                ? 'bg-blue-50 text-blue-700 border-blue-200'
                                : 'bg-green-50 text-green-700 border-green-200'
                            )}
                          >
                            {item.source === 'interaction' ? 'Interação' : 'Tarefa'}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-sm text-muted-foreground max-w-[300px]">
                          {hasNotes ? (
                            <div className={cn(!isExpanded && 'line-clamp-2')}>
                              {item.notes}
                            </div>
                          ) : (
                            <span className="text-muted-foreground/50">—</span>
                          )}
                        </TableCell>
                        <TableCell>
                          {hasNotes && notesLength > 80 && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => toggleRowExpand(item.id)}
                              className="h-6 w-6 p-0"
                            >
                              {isExpanded ? (
                                <ChevronUp className="h-4 w-4" />
                              ) : (
                                <ChevronDown className="h-4 w-4" />
                              )}
                            </Button>
                          )}
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>

              {/* Load More Button */}
              {hasMore && (
                <div className="flex justify-center py-4">
                  <Button variant="outline" onClick={handleLoadMore}>
                    Carregar mais ({filteredItems.length - displayCount} restantes)
                  </Button>
                </div>
              )}
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
