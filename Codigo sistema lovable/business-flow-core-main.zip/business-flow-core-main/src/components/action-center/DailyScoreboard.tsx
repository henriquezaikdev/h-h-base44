import { useState, useEffect } from 'react';
import { MessageCircle, Phone, ShoppingCart, Users, Activity, Check } from 'lucide-react';
import { DailyScore } from '@/hooks/useActionCenterData';
import { cn } from '@/lib/utils';
import { motion } from 'framer-motion';

interface DailyScoreboardProps {
  score: DailyScore;
  dailyTarget?: number;
}

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.06,
      delayChildren: 0.1,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 15, scale: 0.95 },
  visible: {
    opacity: 1,
    y: 0,
    scale: 1,
    transition: {
      type: 'spring' as const,
      stiffness: 400,
      damping: 25,
    },
  },
};

export function DailyScoreboard({ score, dailyTarget = 20 }: DailyScoreboardProps) {
  const [animatingCard, setAnimatingCard] = useState<string | null>(null);
  const [previousScore, setPreviousScore] = useState<DailyScore>(score);

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };

  useEffect(() => {
    if (score.contactsToday >= dailyTarget && previousScore.contactsToday < dailyTarget) {
      setAnimatingCard('contacts');
      setTimeout(() => setAnimatingCard(null), 1000);
    }
    setPreviousScore(score);
  }, [score, dailyTarget, previousScore.contactsToday]);

  const targetReached = score.contactsToday >= dailyTarget;
  const progress = Math.min((score.contactsToday / dailyTarget) * 100, 100);

  const metrics = [
    {
      id: 'contacts',
      label: 'Contatos',
      value: score.contactsToday,
      target: dailyTarget,
      icon: targetReached ? Check : Activity,
      showProgress: true,
      reached: targetReached,
    },
    {
      id: 'calls',
      label: 'Ligações',
      value: score.callsToday,
      icon: Phone,
    },
    {
      id: 'whatsapp',
      label: 'WhatsApps',
      value: score.whatsappsToday,
      icon: MessageCircle,
    },
    {
      id: 'orders',
      label: 'Pedidos',
      value: score.ordersToday,
      subtitle: formatCurrency(score.orderValueToday),
      icon: ShoppingCart,
    },
    {
      id: 'inactive',
      label: 'Sem contato 15d',
      value: score.clientsNoContact15Days,
      icon: Users,
      isWarning: score.clientsNoContact15Days > 0,
      isHighWarning: score.clientsNoContact15Days > 10,
    },
  ];

  return (
    <motion.div 
      className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3"
      variants={containerVariants}
      initial="hidden"
      animate="visible"
    >
      {metrics.map((metric) => {
        const Icon = metric.icon;
        
        return (
          <motion.div
            key={metric.id}
            variants={itemVariants}
            whileHover={{ scale: 1.02, y: -2 }}
            className={cn(
              "group relative overflow-hidden p-4 rounded-xl border bg-card transition-all duration-300 hover:shadow-md",
              metric.reached && "border-emerald-500/50 bg-emerald-50/50 dark:bg-emerald-950/20",
              metric.isWarning && !metric.isHighWarning && "border-amber-500/50 bg-amber-50/50 dark:bg-amber-950/20",
              metric.isHighWarning && "border-amber-600/60 bg-amber-50 dark:bg-amber-950/30",
              !metric.reached && !metric.isWarning && "border-border",
              animatingCard === metric.id && "animate-pulse scale-105"
            )}
          >
            <div className="flex items-start justify-between mb-3">
              <div className={cn(
                "p-2 rounded-lg border transition-all duration-300 group-hover:scale-110",
                metric.reached && "bg-emerald-500/10 border-emerald-500/20",
                metric.isWarning && "bg-amber-500/10 border-amber-500/20",
                !metric.reached && !metric.isWarning && "bg-muted/50 border-border"
              )}>
                <Icon 
                  size={16} 
                  className={cn(
                    "text-muted-foreground",
                    metric.reached && "text-emerald-600",
                    metric.isWarning && "text-amber-600"
                  )} 
                />
              </div>
              {metric.target && (
                <span className="text-xs text-muted-foreground tabular-nums">
                  {metric.value}/{metric.target}
                </span>
              )}
            </div>
            
            <div>
              <p className={cn(
                "text-2xl font-semibold tracking-tight",
                metric.reached ? "text-emerald-600 dark:text-emerald-400" : "text-foreground",
                metric.isWarning && "text-amber-600 dark:text-amber-400"
              )}>
                {metric.value}
              </p>
              {metric.subtitle && (
                <p className="text-xs text-muted-foreground mt-0.5">{metric.subtitle}</p>
              )}
              <p className="text-xs text-muted-foreground mt-1">{metric.label}</p>
            </div>

            {metric.showProgress && (
              <div className="mt-3 h-1.5 bg-muted rounded-full overflow-hidden">
                <div 
                  className={cn(
                    "h-full rounded-full transition-all duration-500",
                    metric.reached 
                      ? "bg-emerald-500" 
                      : "bg-primary"
                  )}
                  style={{ width: `${progress}%` }}
                />
              </div>
            )}
          </motion.div>
        );
      })}
    </motion.div>
  );
}