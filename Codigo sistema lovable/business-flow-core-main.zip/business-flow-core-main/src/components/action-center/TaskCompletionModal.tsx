import { useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Loader2, Phone, MessageCircle, PhoneOff, MessageSquareOff, CheckCircle } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { SELLER_METRICS_QUERY_KEY } from '@/hooks/useSellerMetrics';

interface TaskCompletionModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  task: {
    id: string;
    clientId: string;
    clientName: string;
    contactType: string;
    notes: string | null;
  } | null;
  sellerId: string | null;
  onCompleted: () => void;
}

const ATTEMPT_TYPES = [
  { value: 'whatsapp_sem_resposta', label: 'WhatsApp — sem resposta', icon: MessageSquareOff },
  { value: 'ligacao_sem_resposta', label: 'Ligação — sem resposta', icon: PhoneOff },
];

export function TaskCompletionModal({ open, onOpenChange, task, sellerId, onCompleted }: TaskCompletionModalProps) {
  const queryClient = useQueryClient();
  const [loading, setLoading] = useState(false);
  const [notes, setNotes] = useState('');
  const [attemptType, setAttemptType] = useState<string>('');

  // Handle successful contact (WhatsApp or Call)
  const handleSuccessfulContact = async (contactType: 'whatsapp' | 'ligacao') => {
    if (!task || !sellerId) return;

    // Validate required notes
    if (!notes.trim()) {
      toast.error('A observação é obrigatória');
      return;
    }

    setLoading(true);
    try {
      const now = new Date();
      
      // Get today's date in São Paulo timezone for interaction_date
      const todaySP = new Intl.DateTimeFormat('sv-SE', {
        timeZone: 'America/Sao_Paulo',
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
      }).format(now);
      
      // Get current time in São Paulo timezone for interaction_time
      const timeSP = new Intl.DateTimeFormat('en-GB', {
        timeZone: 'America/Sao_Paulo',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false,
      }).format(now);
      
      const interactionTypeLabel = contactType === 'whatsapp' ? 'WhatsApp' : 'Ligação';

      // Update task as completed (successful contact)
      // NOTE: We no longer create a separate interaction record - the task IS the contact record
      const { error: taskError } = await supabase
        .from('tasks')
        .update({
          status: 'concluida',
          completed_at: now.toISOString(),
          completion_notes: notes,
          contact_successful: true,
          is_attempt: false,
          contact_type: contactType,
        })
        .eq('id', task.id);

      if (taskError) throw taskError;

      // Update client last_contact_at (successful contact)
      await supabase
        .from('clients')
        .update({ last_contact_at: now.toISOString() })
        .eq('id', task.clientId);

      toast.success(`Contato via ${interactionTypeLabel} registrado com sucesso!`);
      
      // INVALIDAR CACHE DE MÉTRICAS PARA ATUALIZAÇÃO IMEDIATA
      queryClient.invalidateQueries({ queryKey: [SELLER_METRICS_QUERY_KEY] });
      queryClient.invalidateQueries({ queryKey: ['tasks'] });
      queryClient.invalidateQueries({ queryKey: ['actionCenter'] });
      
      // Reset form
      setNotes('');
      setAttemptType('');
      onOpenChange(false);
      onCompleted();
    } catch (error) {
      console.error('Error completing task:', error);
      toast.error('Erro ao registrar contato');
    } finally {
      setLoading(false);
    }
  };

  // Handle attempt without response
  const handleAttempt = async () => {
    if (!task || !sellerId) return;

    // Validate required fields
    if (!notes.trim()) {
      toast.error('A observação é obrigatória para tentativas');
      return;
    }

    if (!attemptType) {
      toast.error('Selecione o resultado da tentativa');
      return;
    }

    setLoading(true);
    try {
      const now = new Date();
      
      // Get today's date in São Paulo timezone for interaction_date
      const todaySP = new Intl.DateTimeFormat('sv-SE', {
        timeZone: 'America/Sao_Paulo',
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
      }).format(now);
      
      // Get current time in São Paulo timezone for interaction_time
      const timeSP = new Intl.DateTimeFormat('en-GB', {
        timeZone: 'America/Sao_Paulo',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false,
      }).format(now);
      
      // Map attempt type to interaction type
      const interactionTypeLabel = attemptType === 'whatsapp_sem_resposta' 
        ? 'WhatsApp (Tentativa)' 
        : 'Ligação (Tentativa)';

      const contactType = attemptType === 'whatsapp_sem_resposta' ? 'whatsapp' : 'ligacao';

      // Update task as completed (but marked as attempt)
      // NOTE: We no longer create a separate interaction record - the task IS the contact record
      const { error: taskError } = await supabase
        .from('tasks')
        .update({
          status: 'concluida',
          completed_at: now.toISOString(),
          completion_notes: notes,
          contact_successful: false,
          is_attempt: true,
          contact_type: contactType,
        })
        .eq('id', task.id);

      if (taskError) throw taskError;

      // Note: Do NOT update last_contact_at since this was an unsuccessful attempt

      toast.success('Tentativa registrada no histórico do cliente');
      
      // INVALIDAR CACHE DE MÉTRICAS PARA ATUALIZAÇÃO IMEDIATA
      queryClient.invalidateQueries({ queryKey: [SELLER_METRICS_QUERY_KEY] });
      queryClient.invalidateQueries({ queryKey: ['tasks'] });
      queryClient.invalidateQueries({ queryKey: ['actionCenter'] });
      
      // Reset form
      setNotes('');
      setAttemptType('');
      onOpenChange(false);
      onCompleted();
    } catch (error) {
      console.error('Error completing task:', error);
      toast.error('Erro ao registrar tentativa');
    } finally {
      setLoading(false);
    }
  };

  const handleClose = () => {
    setNotes('');
    setAttemptType('');
    onOpenChange(false);
  };

  if (!task) return null;

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="text-lg">
            Concluir Tarefa
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-5 py-4">
          {/* Client Info */}
          <div className="p-3 bg-muted/50 rounded-lg">
            <p className="font-medium">{task.clientName}</p>
          </div>

          {/* Notes - Always required first */}
          <div className="space-y-2">
            <Label htmlFor="notes" className="text-base">Observação do vendedor *</Label>
            <Textarea
              id="notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Descreva o resultado do contato..."
              rows={3}
              className="resize-none"
            />
            <p className="text-xs text-muted-foreground">
              Obrigatório. Esta anotação será salva no histórico do cliente.
            </p>
          </div>

          {/* Successful Contact Buttons */}
          <div className="space-y-3">
            <Label className="text-base flex items-center gap-2">
              <CheckCircle className="h-4 w-4 text-green-500" />
              Conseguiu falar com o cliente?
            </Label>
            <div className="grid grid-cols-2 gap-3">
              <Button
                variant="outline"
                className="h-auto py-4 flex flex-col gap-2 border-green-500/30 hover:bg-green-500/10 hover:border-green-500/50 disabled:opacity-50"
                onClick={() => handleSuccessfulContact('whatsapp')}
                disabled={loading || !notes.trim()}
              >
                <MessageCircle className="h-6 w-6 text-green-500" />
                <span className="font-medium">WhatsApp</span>
                <span className="text-xs text-muted-foreground">Contato efetivo</span>
              </Button>
              <Button
                variant="outline"
                className="h-auto py-4 flex flex-col gap-2 border-blue-500/30 hover:bg-blue-500/10 hover:border-blue-500/50 disabled:opacity-50"
                onClick={() => handleSuccessfulContact('ligacao')}
                disabled={loading || !notes.trim()}
              >
                <Phone className="h-6 w-6 text-blue-500" />
                <span className="font-medium">Ligação</span>
                <span className="text-xs text-muted-foreground">Contato efetivo</span>
              </Button>
            </div>
          </div>

          {/* Divider */}
          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <span className="w-full border-t" />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-background px-2 text-muted-foreground">
                ou não conseguiu contato
              </span>
            </div>
          </div>

          {/* Attempt Type Selection */}
          <div className="space-y-3">
            <Label className="text-base">Registrar tentativa sem resposta</Label>
            <RadioGroup value={attemptType} onValueChange={setAttemptType} className="space-y-2">
              {ATTEMPT_TYPES.map((type) => (
                <div
                  key={type.value}
                  className={`flex items-center space-x-3 p-3 rounded-lg border cursor-pointer transition-colors ${
                    attemptType === type.value
                      ? 'border-amber-500 bg-amber-500/5'
                      : 'border-border hover:bg-muted/50'
                  }`}
                  onClick={() => setAttemptType(type.value)}
                >
                  <RadioGroupItem value={type.value} id={type.value} />
                  <type.icon className={`h-5 w-5 ${
                    attemptType === type.value ? 'text-amber-500' : 'text-muted-foreground'
                  }`} />
                  <Label htmlFor={type.value} className="flex-1 cursor-pointer font-medium">
                    {type.label}
                  </Label>
                </div>
              ))}
            </RadioGroup>
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={handleClose} disabled={loading}>
            Cancelar
          </Button>
          {attemptType && (
            <Button 
              onClick={handleAttempt} 
              disabled={loading || !notes.trim()}
              variant="secondary"
              className="bg-amber-500/10 hover:bg-amber-500/20 text-amber-600 border border-amber-500/20"
            >
              {loading && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Salvar Tentativa
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
