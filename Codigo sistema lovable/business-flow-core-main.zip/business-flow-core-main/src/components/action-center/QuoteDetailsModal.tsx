import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Loader2, FileX2, Calendar, User, Package, ExternalLink } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { format, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { useNavigate } from 'react-router-dom';

interface QuoteItem {
  id: string;
  product_name: string;
  quantity: number;
  unit_price: number;
  subtotal: number;
}

interface QuoteDetailsModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  quoteId: string | null;
}

export function QuoteDetailsModal({ open, onOpenChange, quoteId }: QuoteDetailsModalProps) {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [quote, setQuote] = useState<any>(null);
  const [items, setItems] = useState<QuoteItem[]>([]);

  useEffect(() => {
    if (open && quoteId) {
      fetchQuoteDetails();
    }
  }, [open, quoteId]);

  const fetchQuoteDetails = async () => {
    if (!quoteId) return;
    
    setLoading(true);
    try {
      // Fetch quote with client and seller info
      const { data: quoteData, error: quoteError } = await supabase
        .from('quotes')
        .select(`
          *,
          clients(company_name, ranking_tier),
          seller:sellers!quotes_seller_id_fkey(name)
        `)
        .eq('id', quoteId)
        .single();

      if (quoteError) throw quoteError;
      setQuote(quoteData);

      // Fetch quote items
      const { data: itemsData, error: itemsError } = await supabase
        .from('quote_items')
        .select('*')
        .eq('quote_id', quoteId)
        .order('product_name');

      if (itemsError) throw itemsError;
      setItems(itemsData || []);
    } catch (error) {
      console.error('Error fetching quote details:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
  };

  if (!quoteId) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileX2 className="h-5 w-5 text-red-500" />
            Detalhes do Orçamento Perdido
          </DialogTitle>
        </DialogHeader>

        {loading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : quote ? (
          <div className="space-y-6">
            {/* Quote Header */}
            <div className="p-4 bg-red-50 dark:bg-red-950/30 rounded-lg border border-red-200 dark:border-red-800">
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="font-semibold text-lg">Orçamento #{quote.quote_number}</h3>
                  <div className="flex items-center gap-3 text-sm text-muted-foreground mt-1">
                    <span className="flex items-center gap-1">
                      <Calendar className="h-3.5 w-3.5" />
                      {format(parseISO(quote.quote_date), "dd 'de' MMMM 'de' yyyy", { locale: ptBR })}
                    </span>
                    {quote.seller?.name && (
                      <span className="flex items-center gap-1">
                        <User className="h-3.5 w-3.5" />
                        {quote.seller.name}
                      </span>
                    )}
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-2xl font-bold text-red-600">{formatCurrency(quote.total)}</p>
                  <Badge variant="destructive">PERDIDO</Badge>
                </div>
              </div>
            </div>

            {/* Client Info */}
            <div className="p-4 bg-muted/50 rounded-lg">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Cliente</p>
                  <p className="font-medium text-lg">{quote.clients?.company_name}</p>
                </div>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => {
                    onOpenChange(false);
                    navigate(`/clients/${quote.client_id}`);
                  }}
                >
                  <ExternalLink className="h-4 w-4 mr-2" />
                  Ver Cliente
                </Button>
              </div>
            </div>

            {/* Quote Items */}
            <div>
              <h4 className="font-medium mb-3 flex items-center gap-2">
                <Package className="h-4 w-4" />
                Itens do Orçamento ({items.length})
              </h4>
              
              {items.length > 0 ? (
                <div className="border rounded-lg overflow-hidden">
                  <table className="w-full text-sm">
                    <thead className="bg-muted/50">
                      <tr>
                        <th className="text-left p-3 font-medium">Produto</th>
                        <th className="text-center p-3 font-medium w-20">Qtd</th>
                        <th className="text-right p-3 font-medium w-28">Unitário</th>
                        <th className="text-right p-3 font-medium w-28">Subtotal</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {items.map((item) => (
                        <tr key={item.id} className="hover:bg-muted/30">
                          <td className="p-3">{item.product_name}</td>
                          <td className="p-3 text-center">{item.quantity}</td>
                          <td className="p-3 text-right">{formatCurrency(item.unit_price)}</td>
                          <td className="p-3 text-right font-medium">{formatCurrency(item.subtotal)}</td>
                        </tr>
                      ))}
                    </tbody>
                    <tfoot className="bg-muted/50">
                      <tr>
                        <td colSpan={3} className="p-3 text-right font-semibold">Total:</td>
                        <td className="p-3 text-right font-bold text-red-600">{formatCurrency(quote.total)}</td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
              ) : (
                <p className="text-muted-foreground text-center py-6 bg-muted/30 rounded-lg">
                  Nenhum item registrado neste orçamento
                </p>
              )}
            </div>

            {/* PDF Link */}
            {quote.pdf_url && (
              <div className="flex justify-end">
                <Button variant="outline" asChild>
                  <a href={quote.pdf_url} target="_blank" rel="noopener noreferrer">
                    <ExternalLink className="h-4 w-4 mr-2" />
                    Ver PDF Original
                  </a>
                </Button>
              </div>
            )}
          </div>
        ) : (
          <p className="text-center py-8 text-muted-foreground">
            Orçamento não encontrado
          </p>
        )}
      </DialogContent>
    </Dialog>
  );
}
