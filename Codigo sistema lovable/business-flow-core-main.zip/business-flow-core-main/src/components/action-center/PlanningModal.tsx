import { useState, useEffect, useRef } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { upsertTasks } from '@/lib/taskUtils';
import { Loader2, Calendar, Check, UserMinus, RefreshCcw } from 'lucide-react';
import { differenceInDays } from 'date-fns';

// Helper to get date in São Paulo timezone (YYYY-MM-DD)
function saoPauloDayKey(date: Date): string {
  return new Intl.DateTimeFormat('sv-SE', {
    timeZone: 'America/Sao_Paulo',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(date);
}

interface PlanningModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  sellerId: string;
  onPlanGenerated: () => void;
}

interface PlanningClient {
  id: string;
  company_name: string;
  ranking_tier: string | null;
  days_since_last_order: number | null;
  days_since_contact: number | null;
  total_revenue: number | null;
  type: 'inativo' | 'recorrente';
}

const TIER_ORDER: Record<string, number> = { top20: 1, top100: 2, top200: 3, eventual: 4, geral: 5 };
const TIER_LABELS: Record<string, string> = {
  top20: '🏆 TOP 20',
  top100: '🥈 TOP 100',
  top200: '🥉 TOP 200',
  eventual: 'Eventual',
  geral: 'Geral',
};

export function PlanningModal({ open, onOpenChange, sellerId, onPlanGenerated }: PlanningModalProps) {
  const [loading, setLoading] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [prospects] = useState<PlanningClient[]>([]);
  const [inativos, setInativos] = useState<PlanningClient[]>([]);
  const [recorrentes, setRecorrentes] = useState<PlanningClient[]>([]);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [activeTab, setActiveTab] = useState('inativos');

  useEffect(() => {
    if (open) {
      fetchData();
      setSelectedIds(new Set());
    }
  }, [open, sellerId]);

  const fetchData = async () => {
    setLoading(true);
    try {
      const now = new Date();

      // Fetch clients with last_contact_at
      const { data: clientsData } = await supabase
        .from('clients')
        .select('id, company_name, ranking_tier, days_since_last_order, total_revenue, last_contact_at, classification')
        .eq('seller_id', sellerId)
        .eq('is_deleted', false);

      // Filter and format inactive clients (90+ days without order)
      const inativosFormatted: PlanningClient[] = (clientsData || [])
        .filter(c => c.days_since_last_order && c.days_since_last_order >= 90)
        .map(c => ({
          id: c.id,
          company_name: c.company_name,
          ranking_tier: c.ranking_tier,
          days_since_last_order: c.days_since_last_order,
          days_since_contact: c.last_contact_at ? differenceInDays(now, new Date(c.last_contact_at)) : null,
          total_revenue: c.total_revenue,
          type: 'inativo' as const,
        }))
        .sort((a, b) => {
          const tierDiff = (TIER_ORDER[a.ranking_tier || 'geral'] || 5) - (TIER_ORDER[b.ranking_tier || 'geral'] || 5);
          if (tierDiff !== 0) return tierDiff;
          return (b.days_since_last_order || 0) - (a.days_since_last_order || 0);
        });
      setInativos(inativosFormatted);

      // Filter and format recurrent clients (45+ days without order)
      const recorrentesFormatted: PlanningClient[] = (clientsData || [])
        .filter(c => c.classification === 'recorrente' && c.days_since_last_order && c.days_since_last_order >= 45 && c.days_since_last_order < 90)
        .map(c => ({
          id: c.id,
          company_name: c.company_name,
          ranking_tier: c.ranking_tier,
          days_since_last_order: c.days_since_last_order,
          days_since_contact: c.last_contact_at ? differenceInDays(now, new Date(c.last_contact_at)) : null,
          total_revenue: c.total_revenue,
          type: 'recorrente' as const,
        }))
        .sort((a, b) => {
          const tierDiff = (TIER_ORDER[a.ranking_tier || 'geral'] || 5) - (TIER_ORDER[b.ranking_tier || 'geral'] || 5);
          if (tierDiff !== 0) return tierDiff;
          return (b.days_since_last_order || 0) - (a.days_since_last_order || 0);
        });
      setRecorrentes(recorrentesFormatted);

    } catch (error) {
      console.error('Error fetching planning data:', error);
      toast.error('Erro ao carregar dados');
    } finally {
      setLoading(false);
    }
  };

  const toggleSelection = (id: string) => {
    setSelectedIds(prev => {
      const newSet = new Set(prev);
      if (newSet.has(id)) {
        newSet.delete(id);
      } else {
        newSet.add(id);
      }
      return newSet;
    });
  };

  const selectAll = (items: PlanningClient[]) => {
    setSelectedIds(prev => {
      const newSet = new Set(prev);
      items.forEach(item => newSet.add(item.id));
      return newSet;
    });
  };

  const clearSelection = (items: PlanningClient[]) => {
    setSelectedIds(prev => {
      const newSet = new Set(prev);
      items.forEach(item => newSet.delete(item.id));
      return newSet;
    });
  };

  // Ref to prevent double submit
  const isSubmittingRef = useRef(false);

  const handleGenerate = async () => {
    if (selectedIds.size === 0) {
      toast.error('Selecione pelo menos um cliente/prospect');
      return;
    }

    if (generating || isSubmittingRef.current) return;

    isSubmittingRef.current = true;
    setGenerating(true);
    const today = saoPauloDayKey(new Date());

    try {
      const tasksToCreate: any[] = [];

      selectedIds.forEach(id => {

        // Determine the reason based on type
        let reason = 'Planejamento do Dia';
        const client = [...inativos, ...recorrentes].find(c => c.id === id);
        if (client) {
          if (client.type === 'inativo') {
            reason = `Planejamento do Dia — Inativo ${client.days_since_last_order}d`;
          } else if (client.type === 'recorrente') {
            reason = `Planejamento do Dia — Recorrente ${client.days_since_last_order}d`;
          }
        }

        tasksToCreate.push({
          client_id: id,
          contact_type: 'whatsapp',
          task_date: today,
          status: 'pendente' as const,
          priority: 'alta' as const,
          notes: reason,
          created_by_seller_id: sellerId,
          source: 'planning-execution',
        });
      });




      if (tasksToCreate.length > 0) {
        await upsertTasks(supabase, tasksToCreate);
        toast.success(`${tasksToCreate.length} tarefa(s) criada(s) para hoje!`);
      }

      onPlanGenerated();
      onOpenChange(false);
    } catch (error) {
      console.error('Error generating planning:', error);
      toast.error('Erro ao gerar planejamento');
    } finally {
      setGenerating(false);
      isSubmittingRef.current = false;
    }
  };

  const renderClientItem = (client: PlanningClient) => {
    const isSelected = selectedIds.has(client.id);
    
    return (
      <label
        key={client.id}
        className={`flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-all ${
          isSelected ? 'border-primary bg-primary/5' : 'border-border hover:border-primary/50'
        }`}
      >
        <Checkbox
          checked={isSelected}
          onCheckedChange={() => toggleSelection(client.id)}
        />
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <span className="font-medium text-foreground truncate">{client.company_name}</span>
            {client.ranking_tier && TIER_LABELS[client.ranking_tier] && (
              <Badge variant="outline" className="text-xs shrink-0">
                {TIER_LABELS[client.ranking_tier]}
              </Badge>
            )}
          </div>
          <div className="flex items-center gap-3 text-xs text-muted-foreground mt-0.5">
            {client.days_since_last_order !== null && (
              <span>{client.days_since_last_order}d sem compra</span>
            )}
            {client.days_since_contact !== null && (
              <span>{client.days_since_contact}d sem contato</span>
            )}
            {client.total_revenue !== null && client.total_revenue > 0 && (
              <span>R$ {client.total_revenue.toLocaleString('pt-BR')}</span>
            )}
          </div>
        </div>
      </label>
    );
  };

  const getListForTab = (tab: string): PlanningClient[] => {
    switch (tab) {
      case 'inativos': return inativos;
      case 'recorrentes': return recorrentes;
      default: return [];
    }
  };

  const currentList = getListForTab(activeTab);
  const selectedInCurrentTab = currentList.filter(c => selectedIds.has(c.id)).length;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Calendar size={20} className="text-primary" />
            Planejamento de Hoje — Execução
          </DialogTitle>
          <p className="text-sm text-muted-foreground mt-1">
            Selecione os clientes que você vai trabalhar hoje. O sistema organiza. Você executa.
          </p>
        </DialogHeader>

        {loading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="animate-spin h-8 w-8 text-primary" />
          </div>
        ) : (
          <>
            <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col min-h-0">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="inativos" className="gap-1">
                  <UserMinus size={14} />
                  Inativos
                  <Badge variant="secondary" className="ml-1">{inativos.length}</Badge>
                </TabsTrigger>
                <TabsTrigger value="recorrentes" className="gap-1">
                  <RefreshCcw size={14} />
                  Recorrentes
                  <Badge variant="secondary" className="ml-1">{recorrentes.length}</Badge>
                </TabsTrigger>
              </TabsList>

              <div className="mt-4 flex-1 min-h-0">
                <TabsContent value="inativos" className="h-full m-0">
                  <div className="space-y-3">
                    <div className="p-3 bg-muted/50 rounded-lg">
                      <p className="text-sm font-medium text-foreground">Clientes sem compra há 90 dias ou mais</p>
                      <p className="text-xs text-muted-foreground">Objetivo: reativação.</p>
                    </div>
                    {inativos.length > 0 ? (
                      <>
                        <div className="flex items-center gap-2">
                          <Button variant="outline" size="sm" onClick={() => selectAll(inativos)}>Selecionar todos</Button>
                          <Button variant="ghost" size="sm" onClick={() => clearSelection(inativos)}>Limpar</Button>
                          <span className="text-sm text-muted-foreground ml-auto">{selectedInCurrentTab} selecionado(s)</span>
                        </div>
                        <ScrollArea className="h-[280px]">
                          <div className="space-y-2 pr-4">
                            {inativos.map(renderClientItem)}
                          </div>
                        </ScrollArea>
                      </>
                    ) : (
                      <p className="text-sm text-muted-foreground text-center py-8">Nenhum cliente inativo encontrado</p>
                    )}
                  </div>
                </TabsContent>

                <TabsContent value="recorrentes" className="h-full m-0">
                  <div className="space-y-3">
                    <div className="p-3 bg-muted/50 rounded-lg">
                      <p className="text-sm font-medium text-foreground">Clientes ativos que quebraram a recorrência (45+ dias)</p>
                      <p className="text-xs text-muted-foreground">Objetivo: recuperar o ciclo.</p>
                    </div>
                    {recorrentes.length > 0 ? (
                      <>
                        <div className="flex items-center gap-2">
                          <Button variant="outline" size="sm" onClick={() => selectAll(recorrentes)}>Selecionar todos</Button>
                          <Button variant="ghost" size="sm" onClick={() => clearSelection(recorrentes)}>Limpar</Button>
                          <span className="text-sm text-muted-foreground ml-auto">{selectedInCurrentTab} selecionado(s)</span>
                        </div>
                        <ScrollArea className="h-[280px]">
                          <div className="space-y-2 pr-4">
                            {recorrentes.map(renderClientItem)}
                          </div>
                        </ScrollArea>
                      </>
                    ) : (
                      <p className="text-sm text-muted-foreground text-center py-8">Nenhum cliente recorrente com quebra de ciclo</p>
                    )}
                  </div>
                </TabsContent>
              </div>
            </Tabs>

            <div className="flex items-center justify-between pt-4 border-t">
              <div className="text-sm text-muted-foreground">
                <span className="font-medium text-foreground">{selectedIds.size}</span> cliente(s) selecionado(s) no total
              </div>
              <div className="flex gap-3">
                <Button variant="outline" onClick={() => onOpenChange(false)}>
                  Cancelar
                </Button>
                <Button onClick={handleGenerate} disabled={generating || selectedIds.size === 0} className="gap-2">
                  {generating ? (
                    <>
                      <Loader2 size={16} className="animate-spin" /> Gerando...
                    </>
                  ) : (
                    <>
                      <Check size={16} /> Gerar Tarefas do Dia
                    </>
                  )}
                </Button>
              </div>
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
