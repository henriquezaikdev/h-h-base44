import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { MapPin, ExternalLink, Truck, Package } from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

const STATUS_COLOR: Record<string, string> = {
  ENTREGUE: 'bg-emerald-100 text-emerald-700 border-emerald-200',
  SAIU_ENTREGA: 'bg-blue-100 text-blue-700 border-blue-200',
  'EM ROTA': 'bg-blue-100 text-blue-700 border-blue-200',
  PENDENTE: 'bg-amber-100 text-amber-700 border-amber-200',
  COLETADO: 'bg-violet-100 text-violet-700 border-violet-200',
};

const STATUS_LABEL: Record<string, string> = {
  ENTREGUE: 'Entregue',
  SAIU_ENTREGA: 'Em rota',
  'EM ROTA': 'Em rota',
  PENDENTE: 'Pendente',
  COLETADO: 'Coletado',
};

interface Entrega {
  id: string;
  destinatario: string | null;
  endereco: string | null;
  status: string | null;
  data_baixa: string | null;
  hora_baixa: string | null;
  link: string | null;
  controle_pedido: string | null;
}

interface MonthGroup {
  label: string;
  entregas: Entrega[];
  entregueCount: number;
  xp: number;
}

function groupByMonth(entregas: Entrega[]): MonthGroup[] {
  const groups: Record<string, Entrega[]> = {};

  entregas.forEach(e => {
    if (!e.data_baixa) return;
    const date = new Date(e.data_baixa);
    const key = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
    if (!groups[key]) groups[key] = [];
    groups[key].push(e);
  });

  return Object.entries(groups)
    .sort(([a], [b]) => b.localeCompare(a))
    .map(([key, items]) => {
      const [year, month] = key.split('-');
      const date = new Date(Number(year), Number(month) - 1, 1);
      const entregueCount = items.filter(e => e.status === 'ENTREGUE').length;
      return {
        label: format(date, "MMMM yyyy", { locale: ptBR }).replace(/^\w/, c => c.toUpperCase()),
        entregas: items,
        entregueCount,
        xp: entregueCount * 5,
      };
    });
}

export function EntregadorEntregasHistorico({ entregas }: { entregas: Entrega[] }) {
  const months = groupByMonth(entregas);

  if (months.length === 0) {
    return (
      <Card className="border-border/50">
        <CardContent className="py-8 text-center">
          <Truck className="h-10 w-10 mx-auto mb-2 text-muted-foreground/40" />
          <p className="text-sm text-muted-foreground">Nenhuma entrega encontrada</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Monthly summary */}
      <div>
        <h3 className="text-sm font-bold text-foreground mb-3 flex items-center gap-2">
          <Package size={16} className="text-primary" />
          Relatório Mensal
        </h3>
        <div className="space-y-2">
          {months.map(m => (
            <div key={m.label} className="flex items-center justify-between bg-card border border-border rounded-xl px-4 py-3">
              <span className="text-sm font-semibold text-foreground">{m.label}</span>
              <div className="flex items-center gap-4">
                <span className="text-xs text-muted-foreground">
                  <strong className="text-foreground">{m.entregueCount}</strong> entregas
                </span>
                <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200 text-xs">
                  +{m.xp} XP
                </Badge>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Detailed history */}
      <div>
        <h3 className="text-sm font-bold text-foreground mb-3">Histórico de Entregas</h3>
        {months.map(m => (
          <div key={m.label} className="mb-5">
            <p className="text-xs font-semibold text-primary uppercase tracking-wide mb-2">
              {m.label} — {m.entregas.length} registros ({m.entregueCount} entregues)
            </p>
            <div className="space-y-2">
              {m.entregas.map(e => (
                <EntregaCard key={e.id} entrega={e} />
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function EntregaCard({ entrega }: { entrega: Entrega }) {
  const statusClass = STATUS_COLOR[entrega.status || ''] || 'bg-muted text-muted-foreground';
  const statusLabel = STATUS_LABEL[entrega.status || ''] || entrega.status || 'N/A';

  return (
    <Card className="border-border/50 bg-card shadow-sm">
      <CardContent className="p-3 space-y-1.5">
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold text-foreground truncate">
              {entrega.destinatario || 'Sem destinatário'}
            </p>
            {entrega.endereco && (
              <p className="text-xs text-muted-foreground flex items-start gap-1 mt-0.5">
                <MapPin className="h-3 w-3 mt-0.5 shrink-0" />
                <span className="line-clamp-2">{entrega.endereco}</span>
              </p>
            )}
          </div>
          <Badge variant="outline" className={`shrink-0 text-[10px] ${statusClass}`}>
            {statusLabel}
          </Badge>
        </div>
        <div className="flex items-center justify-between">
          <p className="text-[11px] text-muted-foreground">
            {entrega.data_baixa
              ? format(new Date(entrega.data_baixa), "dd MMM yyyy", { locale: ptBR })
              : '—'}
            {entrega.hora_baixa && ` • ${entrega.hora_baixa}`}
            {entrega.controle_pedido && ` • #${entrega.controle_pedido}`}
          </p>
          {entrega.link && (
            <Button
              variant="outline"
              size="sm"
              className="h-7 text-xs gap-1"
              onClick={() => window.open(entrega.link!, '_blank')}
            >
              <ExternalLink className="h-3 w-3" />
              Rastrear
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
