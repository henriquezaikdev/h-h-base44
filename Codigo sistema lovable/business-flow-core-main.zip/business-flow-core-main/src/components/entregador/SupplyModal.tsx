import { useState, useRef } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Camera, Loader2, Fuel, Check } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";

interface SupplyModalProps {
  open: boolean;
  onClose: () => void;
  sellerId: string;
}

export function SupplyModal({ open, onClose, sellerId }: SupplyModalProps) {
  const queryClient = useQueryClient();
  const [step, setStep] = useState<"photos" | "review" | "saving">("photos");
  const [receiptFile, setReceiptFile] = useState<File | null>(null);
  const [odometerFile, setOdometerFile] = useState<File | null>(null);
  const [receiptPreview, setReceiptPreview] = useState<string | null>(null);
  const [odometerPreview, setOdometerPreview] = useState<string | null>(null);
  const [analyzing, setAnalyzing] = useState(false);

  const [receiptDate, setReceiptDate] = useState("");
  const [totalValue, setTotalValue] = useState("");
  const [liters, setLiters] = useState("");
  const [pricePerLiter, setPricePerLiter] = useState("");
  const [odometerKm, setOdometerKm] = useState("");
  const [cardUsed, setCardUsed] = useState("");

  const receiptRef = useRef<HTMLInputElement>(null);
  const odometerRef = useRef<HTMLInputElement>(null);

  const reset = () => {
    setStep("photos");
    setReceiptFile(null);
    setOdometerFile(null);
    setReceiptPreview(null);
    setOdometerPreview(null);
    setReceiptDate("");
    setTotalValue("");
    setLiters("");
    setPricePerLiter("");
    setOdometerKm("");
    setCardUsed("");
    setAnalyzing(false);
  };

  const handleClose = () => {
    reset();
    onClose();
  };

  const handleFileSelect = (type: "receipt" | "odometer", file: File) => {
    const url = URL.createObjectURL(file);
    if (type === "receipt") {
      setReceiptFile(file);
      setReceiptPreview(url);
    } else {
      setOdometerFile(file);
      setOdometerPreview(url);
    }
  };

  const compressAndBase64 = (file: File, maxWidth = 1200, quality = 0.7): Promise<string> =>
    new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement("canvas");
        let w = img.width;
        let h = img.height;
        if (w > maxWidth) {
          h = Math.round((h * maxWidth) / w);
          w = maxWidth;
        }
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext("2d");
        if (!ctx) return reject(new Error("Canvas not supported"));
        ctx.drawImage(img, 0, 0, w, h);
        const dataUrl = canvas.toDataURL("image/jpeg", quality);
        resolve(dataUrl.split(",")[1]);
        URL.revokeObjectURL(img.src);
      };
      img.onerror = reject;
      img.src = URL.createObjectURL(file);
    });

  const analyzePhotos = async () => {
    if (!receiptFile || !odometerFile) {
      toast.error("Envie ambas as fotos");
      return;
    }

    setAnalyzing(true);
    try {
      const [receiptBase64, odometerBase64] = await Promise.all([
        compressAndBase64(receiptFile),
        compressAndBase64(odometerFile),
      ]);

      const { data, error } = await supabase.functions.invoke("hh-ocr-abastecimento", {
        body: { receiptBase64, odometerBase64 },
      });

      if (error) throw error;

      const extracted = data?.data;
      if (extracted) {
        if (extracted.receipt_date) setReceiptDate(extracted.receipt_date.slice(0, 16));
        if (extracted.total_value) setTotalValue(String(extracted.total_value));
        if (extracted.liters) setLiters(String(extracted.liters));
        if (extracted.price_per_liter) setPricePerLiter(String(extracted.price_per_liter));
        if (extracted.odometer_km) setOdometerKm(String(extracted.odometer_km));
      }

      setStep("review");
      toast.success("Dados extraídos com sucesso!");
    } catch (err) {
      console.error("OCR error:", err);
      toast.error("Erro ao analisar fotos. Preencha manualmente.");
      setStep("review");
    } finally {
      setAnalyzing(false);
    }
  };

  const uploadPhoto = async (file: File, prefix: string): Promise<string> => {
    const ext = file.name.split(".").pop() || "jpg";
    const path = `${sellerId}/${prefix}-${Date.now()}.${ext}`;
    const { error } = await supabase.storage.from("delivery-photos").upload(path, file);
    if (error) throw error;
    const { data: { publicUrl } } = supabase.storage.from("delivery-photos").getPublicUrl(path);
    return publicUrl;
  };

  const handleSave = async () => {
    setStep("saving");
    try {
      const [receiptUrl, odometerUrl] = await Promise.all([
        receiptFile ? uploadPhoto(receiptFile, "receipt") : Promise.resolve(null),
        odometerFile ? uploadPhoto(odometerFile, "odometer") : Promise.resolve(null),
      ]);

      const { error } = await supabase.from("vehicle_supplies").insert({
        seller_id: sellerId,
        receipt_image_url: receiptUrl,
        odometer_image_url: odometerUrl,
        receipt_date: receiptDate || null,
        total_value: totalValue ? parseFloat(totalValue) : null,
        liters: liters ? parseFloat(liters) : null,
        price_per_liter: pricePerLiter ? parseFloat(pricePerLiter) : null,
        odometer_km: odometerKm ? parseFloat(odometerKm) : null,
        card_used: cardUsed || null,
        ai_extracted_data: { receiptDate, totalValue, liters, pricePerLiter, odometerKm },
      });

      if (error) throw error;

      toast.success("Abastecimento registrado! +20 XP");
      queryClient.invalidateQueries({ queryKey: ["vehicle-supplies"] });
      queryClient.invalidateQueries({ queryKey: ["carteira-entregador"] });
      handleClose();
    } catch (err) {
      console.error("Save error:", err);
      toast.error("Erro ao salvar abastecimento");
      setStep("review");
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-md mx-auto max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Fuel size={20} className="text-emerald-500" />
            Registrar Abastecimento
          </DialogTitle>
        </DialogHeader>

        {step === "photos" && (
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">Tire ou selecione as fotos abaixo. A IA vai extrair os dados automaticamente.</p>

            {/* Receipt Photo */}
            <div>
              <Label className="text-sm font-medium">1. Cupom Fiscal</Label>
              <input
                ref={receiptRef}
                type="file"
                accept="image/*"
                capture="environment"
                className="hidden"
                onChange={e => e.target.files?.[0] && handleFileSelect("receipt", e.target.files[0])}
              />
              <button
                onClick={() => receiptRef.current?.click()}
                className="mt-1 w-full h-32 border-2 border-dashed border-border rounded-xl flex flex-col items-center justify-center gap-2 hover:bg-muted/50 transition-colors overflow-hidden"
              >
                {receiptPreview ? (
                  <img src={receiptPreview} alt="Cupom" className="w-full h-full object-cover rounded-lg" />
                ) : (
                  <>
                    <Camera size={24} className="text-muted-foreground" />
                    <span className="text-xs text-muted-foreground">Toque para fotografar</span>
                  </>
                )}
              </button>
            </div>

            {/* Odometer Photo */}
            <div>
              <Label className="text-sm font-medium">2. Painel do Veículo (Odômetro)</Label>
              <input
                ref={odometerRef}
                type="file"
                accept="image/*"
                capture="environment"
                className="hidden"
                onChange={e => e.target.files?.[0] && handleFileSelect("odometer", e.target.files[0])}
              />
              <button
                onClick={() => odometerRef.current?.click()}
                className="mt-1 w-full h-32 border-2 border-dashed border-border rounded-xl flex flex-col items-center justify-center gap-2 hover:bg-muted/50 transition-colors overflow-hidden"
              >
                {odometerPreview ? (
                  <img src={odometerPreview} alt="Odômetro" className="w-full h-full object-cover rounded-lg" />
                ) : (
                  <>
                    <Camera size={24} className="text-muted-foreground" />
                    <span className="text-xs text-muted-foreground">Toque para fotografar</span>
                  </>
                )}
              </button>
            </div>

            <Button
              onClick={analyzePhotos}
              disabled={!receiptFile || !odometerFile || analyzing}
              className="w-full h-12 rounded-xl"
            >
              {analyzing ? (
                <>
                  <Loader2 size={18} className="animate-spin mr-2" />
                  Analisando com IA...
                </>
              ) : (
                "Analisar Fotos com IA"
              )}
            </Button>

            <Button
              variant="ghost"
              onClick={() => setStep("review")}
              className="w-full text-sm text-muted-foreground"
            >
              Preencher manualmente (sem fotos)
            </Button>
          </div>
        )}

        {(step === "review" || step === "saving") && (
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">Confira os dados e ajuste se necessário.</p>

            <div className="space-y-3">
              <div>
                <Label className="text-xs">Data e Hora</Label>
                <Input type="datetime-local" value={receiptDate} onChange={e => setReceiptDate(e.target.value)} className="h-11" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-xs">Valor Total (R$)</Label>
                  <Input type="number" step="0.01" value={totalValue} onChange={e => setTotalValue(e.target.value)} placeholder="0.00" className="h-11" />
                </div>
                <div>
                  <Label className="text-xs">Litros</Label>
                  <Input type="number" step="0.001" value={liters} onChange={e => setLiters(e.target.value)} placeholder="0.000" className="h-11" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-xs">Preço/Litro (R$)</Label>
                  <Input type="number" step="0.001" value={pricePerLiter} onChange={e => setPricePerLiter(e.target.value)} placeholder="0.000" className="h-11" />
                </div>
                <div>
                  <Label className="text-xs">Km Odômetro</Label>
                  <Input type="number" step="0.1" value={odometerKm} onChange={e => setOdometerKm(e.target.value)} placeholder="0.0" className="h-11" />
                </div>
              </div>
              <div>
                <Label className="text-xs">Cartão Utilizado</Label>
                <Select value={cardUsed} onValueChange={setCardUsed}>
                  <SelectTrigger className="h-11">
                    <SelectValue placeholder="Selecione o cartão" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="corporativo">Cartão Corporativo</SelectItem>
                    <SelectItem value="pessoal">Cartão Pessoal</SelectItem>
                    <SelectItem value="dinheiro">Dinheiro</SelectItem>
                    <SelectItem value="pix">PIX</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <Button
              onClick={handleSave}
              disabled={step === "saving"}
              className="w-full h-12 rounded-xl bg-emerald-600 hover:bg-emerald-700"
            >
              {step === "saving" ? (
                <>
                  <Loader2 size={18} className="animate-spin mr-2" />
                  Salvando...
                </>
              ) : (
                <>
                  <Check size={18} className="mr-2" />
                  Confirmar Abastecimento
                </>
              )}
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
