import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogTitle } from '@/components/ui/dialog';
import { HelpCircle, Zap, Camera, Fuel } from 'lucide-react';

const LEVEL_THRESHOLDS = [
  { level: 1, name: 'Iniciante', xpMin: 0 },
  { level: 2, name: 'Explorador', xpMin: 200 },
  { level: 3, name: 'Corredor', xpMin: 400 },
  { level: 4, name: 'Águia', xpMin: 600 },
  { level: 5, name: 'Lendário', xpMin: 800 },
];

const XP_RULES = [
  { action: 'Foto de entrega postada', xp: '+5 XP', icon: Camera },
  { action: 'Registro de abastecimento', xp: '+20 XP', icon: Fuel },
];

interface Props {
  level: number;
  xpTotal: number;
  xpInLevel: number;
  levelTitle: string;
}

export function EntregadorLevelBlock({ level, xpTotal, xpInLevel, levelTitle }: Props) {
  const [showHelp, setShowHelp] = useState(false);
  const xpPerLevel = 200;
  const xpRemaining = xpPerLevel - xpInLevel;

  return (
    <>
      <Card className="border-border/50 bg-card">
        <CardContent className="p-4 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Zap className="h-4 w-4 text-amber-500" />
              <span className="text-sm font-semibold text-foreground">Como funciona seu nível</span>
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="h-7 w-7 rounded-full text-muted-foreground"
              onClick={() => setShowHelp(true)}
            >
              <HelpCircle className="h-4 w-4" />
            </Button>
          </div>

          <div className="grid grid-cols-3 gap-2">
            <div className="rounded-xl bg-muted/30 border border-border/40 p-2.5 text-center">
              <p className="text-lg font-bold text-foreground">{level}</p>
              <p className="text-[10px] text-muted-foreground font-medium uppercase tracking-wide">Nível</p>
            </div>
            <div className="rounded-xl bg-muted/30 border border-border/40 p-2.5 text-center">
              <p className="text-lg font-bold text-foreground">{xpTotal}</p>
              <p className="text-[10px] text-muted-foreground font-medium uppercase tracking-wide">XP total</p>
            </div>
            <div className="rounded-xl bg-muted/30 border border-border/40 p-2.5 text-center">
              <p className="text-lg font-bold text-primary">{xpRemaining}</p>
              <p className="text-[10px] text-muted-foreground font-medium uppercase tracking-wide">XP restante</p>
            </div>
          </div>

          <p className="text-xs text-muted-foreground leading-relaxed">
            Você sobe de nível a cada <strong>200 XP</strong> acumulados. Poste fotos de entregas e registre abastecimentos para ganhar XP.
          </p>
        </CardContent>
      </Card>

      <Dialog open={showHelp} onOpenChange={setShowHelp}>
        <DialogContent className="max-w-sm rounded-2xl max-h-[80vh] overflow-y-auto">
          <DialogTitle className="text-base font-semibold flex items-center gap-2">
            <Zap className="h-4 w-4 text-amber-500" /> Entender Níveis & XP
          </DialogTitle>

          <div className="space-y-5 mt-2">
            <div>
              <h4 className="text-sm font-semibold mb-1.5">O que é XP?</h4>
              <p className="text-xs text-muted-foreground leading-relaxed">
                XP (Pontos de Experiência) são ganhos ao registrar suas atividades no sistema.
                Quanto mais XP, maior seu nível.
              </p>
            </div>

            <div>
              <h4 className="text-sm font-semibold mb-1.5">Como subir de nível?</h4>
              <p className="text-xs text-muted-foreground leading-relaxed">
                A cada 200 XP acumulados, você avança de nível automaticamente. Seu progresso é mostrado na barra.
              </p>
            </div>

            <div>
              <h4 className="text-sm font-semibold mb-2">Faixas de Nível</h4>
              <div className="space-y-1">
                {LEVEL_THRESHOLDS.map(lt => (
                  <div key={lt.level} className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs ${lt.level === level ? 'bg-primary/10 font-semibold' : ''}`}>
                    <span className="flex-1">Nível {lt.level} — {lt.name}</span>
                    <span className="font-mono text-muted-foreground">{lt.xpMin}+ XP</span>
                    {lt.level === level && <span className="text-primary text-[10px] font-bold">← Você</span>}
                  </div>
                ))}
              </div>
            </div>

            <div>
              <h4 className="text-sm font-semibold mb-2">Como ganhar XP</h4>
              <div className="space-y-1">
                {XP_RULES.map((rule, i) => {
                  const Icon = rule.icon;
                  return (
                    <div key={i} className="flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs">
                      <Icon className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
                      <span className="flex-1">{rule.action}</span>
                      <span className="font-semibold text-emerald-600">{rule.xp}</span>
                    </div>
                  );
                })}
              </div>
            </div>

            <p className="text-[10px] text-muted-foreground text-center pt-2">
              Continue registrando suas atividades para evoluir!
            </p>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
