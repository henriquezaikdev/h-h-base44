import { Card, CardContent } from '@/components/ui/card';
import { Wrench } from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface MaintenanceLog {
  id: string;
  date: string;
  category: string;
  description: string;
  odometer_km: number | null;
  total_value: number;
  notes: string | null;
  supplier: string | null;
}

export function EntregadorManutencao({ logs }: { logs: MaintenanceLog[] }) {
  if (logs.length === 0) {
    return (
      <Card className="border-border/50">
        <CardContent className="py-8 text-center">
          <Wrench className="h-10 w-10 mx-auto mb-2 text-muted-foreground/40" />
          <p className="text-sm text-muted-foreground">Nenhuma manutenção registrada</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-2">
      {logs.map(log => (
        <Card key={log.id} className="border-border/50 bg-card shadow-sm">
          <CardContent className="p-3 space-y-1">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-orange-500/10 text-orange-500 flex items-center justify-center">
                  <Wrench size={14} />
                </div>
                <div>
                  <p className="text-sm font-semibold text-foreground">{log.description}</p>
                  <p className="text-[10px] text-muted-foreground">
                    {log.category} • {format(new Date(log.date), "dd MMM yyyy", { locale: ptBR })}
                  </p>
                </div>
              </div>
              <p className="text-sm font-bold text-foreground">
                R$ {Number(log.total_value).toFixed(2)}
              </p>
            </div>
            <div className="flex gap-3 text-[11px] text-muted-foreground pl-10">
              {log.odometer_km && <span>KM: {log.odometer_km.toLocaleString()}</span>}
              {log.supplier && <span>Fornecedor: {log.supplier}</span>}
            </div>
            {log.notes && (
              <p className="text-[11px] text-muted-foreground pl-10 italic">{log.notes}</p>
            )}
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
