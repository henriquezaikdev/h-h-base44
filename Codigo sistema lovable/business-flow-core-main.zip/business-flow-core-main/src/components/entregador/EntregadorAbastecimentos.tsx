import { Card, CardContent } from '@/components/ui/card';
import { Fuel, Image } from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Dialog, DialogContent, DialogTitle } from '@/components/ui/dialog';
import { useState } from 'react';

interface Supply {
  id: string;
  created_at: string;
  receipt_date: string | null;
  total_value: number | null;
  liters: number | null;
  price_per_liter: number | null;
  odometer_km: number | null;
  receipt_image_url: string | null;
  odometer_image_url: string | null;
  xp_awarded: number;
  hcoins_awarded: number;
}

export function EntregadorAbastecimentos({ supplies }: { supplies: Supply[] }) {
  const [previewImg, setPreviewImg] = useState<string | null>(null);

  if (supplies.length === 0) {
    return (
      <Card className="border-border/50">
        <CardContent className="py-8 text-center">
          <Fuel className="h-10 w-10 mx-auto mb-2 text-muted-foreground/40" />
          <p className="text-sm text-muted-foreground">Nenhum abastecimento registrado</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <div className="space-y-2">
        {supplies.map(s => (
          <Card key={s.id} className="border-border/50 bg-card shadow-sm">
            <CardContent className="p-3 space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-emerald-500/10 text-emerald-500 flex items-center justify-center">
                    <Fuel size={14} />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-foreground">
                      R$ {Number(s.total_value || 0).toFixed(2)}
                    </p>
                    <p className="text-[10px] text-muted-foreground">
                      {s.receipt_date
                        ? format(new Date(s.receipt_date), "dd MMM yyyy", { locale: ptBR })
                        : format(new Date(s.created_at), "dd MMM yyyy", { locale: ptBR })}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-xs font-bold text-amber-500">+{s.xp_awarded} XP</p>
                  <p className="text-[10px] text-emerald-500">+{s.hcoins_awarded} Hões</p>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2 text-center text-[11px]">
                <div className="bg-muted/30 rounded-lg p-1.5">
                  <p className="font-semibold text-foreground">{s.odometer_km ? `${s.odometer_km.toLocaleString()} km` : '—'}</p>
                  <p className="text-muted-foreground">KM</p>
                </div>
                <div className="bg-muted/30 rounded-lg p-1.5">
                  <p className="font-semibold text-foreground">{s.liters ? `${s.liters.toFixed(1)}L` : '—'}</p>
                  <p className="text-muted-foreground">Litros</p>
                </div>
                <div className="bg-muted/30 rounded-lg p-1.5">
                  <p className="font-semibold text-foreground">{s.price_per_liter ? `R$${s.price_per_liter.toFixed(2)}` : '—'}</p>
                  <p className="text-muted-foreground">R$/L</p>
                </div>
              </div>

              {(s.receipt_image_url || s.odometer_image_url) && (
                <div className="flex gap-2">
                  {s.receipt_image_url && (
                    <button
                      onClick={() => setPreviewImg(s.receipt_image_url)}
                      className="flex items-center gap-1 text-[10px] text-primary hover:underline"
                    >
                      <Image size={12} /> Cupom
                    </button>
                  )}
                  {s.odometer_image_url && (
                    <button
                      onClick={() => setPreviewImg(s.odometer_image_url)}
                      className="flex items-center gap-1 text-[10px] text-primary hover:underline"
                    >
                      <Image size={12} /> Painel
                    </button>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      <Dialog open={!!previewImg} onOpenChange={() => setPreviewImg(null)}>
        <DialogContent className="max-w-sm p-2 rounded-2xl">
          <DialogTitle className="sr-only">Imagem</DialogTitle>
          {previewImg && (
            <img src={previewImg} alt="Foto" className="w-full rounded-xl object-contain max-h-[70vh]" />
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
