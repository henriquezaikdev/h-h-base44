import { useState } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ClipboardList, CheckCircle2, Clock, Loader2, Plus } from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { TaskUnifiedModal } from '@/components/tasks/TaskUnifiedModal';
import { useSellersData } from '@/hooks/useSellersData';

const STATUS_MAP: Record<string, { label: string; color: string; icon: typeof Clock }> = {
  pendente: { label: 'Pendente', color: 'bg-amber-100 text-amber-700 border-amber-200', icon: Clock },
  concluida: { label: 'Concluída', color: 'bg-emerald-100 text-emerald-700 border-emerald-200', icon: CheckCircle2 },
};

export function EntregadorTarefasView() {
  const { seller } = useAuth();
  const queryClient = useQueryClient();
  const { sellers } = useSellersData();
  const [showCreateModal, setShowCreateModal] = useState(false);

  const { data: tasks = [], isLoading } = useQuery({
    queryKey: ['entregador-tarefas', seller?.id],
    queryFn: async () => {
      const thirtyDaysAgo = new Date(Date.now() - 30 * 86400000).toISOString().split('T')[0];

      const { data } = await supabase
        .from('tasks')
        .select('id, task_date, notes, status, priority, contact_type, created_at, assigned_to_seller_id, created_by_seller_id, clients!tasks_client_id_fkey(company_name)')
        .or(`created_by_seller_id.eq.${seller!.id},assigned_to_seller_id.eq.${seller!.id}`)
        .gte('task_date', thirtyDaysAgo)
        .order('task_date', { ascending: false })
        .limit(50);

      return data || [];
    },
    enabled: !!seller?.id,
    staleTime: 1000 * 60 * 2,
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-16">
        <Loader2 className="animate-spin h-8 w-8 text-primary" />
      </div>
    );
  }

  const today = new Date().toISOString().split('T')[0];
  const pending = tasks.filter(t => t.status === 'pendente');
  const todayTasks = pending.filter(t => t.task_date === today);
  const otherPending = pending.filter(t => t.task_date !== today);
  const completed = tasks.filter(t => t.status === 'concluida').slice(0, 10);

  return (
    <div className="space-y-5 pb-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-base font-bold text-foreground mb-1">Minhas Tarefas</h2>
          <p className="text-xs text-muted-foreground">{pending.length} pendentes • {completed.length} concluídas (últimos 30 dias)</p>
        </div>
        <Button
          size="sm"
          onClick={() => setShowCreateModal(true)}
          className="gap-1.5 rounded-xl"
        >
          <Plus size={16} />
          Nova Tarefa
        </Button>
      </div>

      {/* Today */}
      {todayTasks.length > 0 && (
        <div className="space-y-2">
          <p className="text-xs font-semibold text-primary uppercase tracking-wide">Hoje — {todayTasks.length} tarefas</p>
          {todayTasks.map(t => <TaskCard key={t.id} task={t} />)}
        </div>
      )}

      {todayTasks.length === 0 && pending.length === 0 && (
        <Card className="border-border/50">
          <CardContent className="py-8 text-center">
            <ClipboardList className="h-10 w-10 mx-auto mb-2 text-muted-foreground/40" />
            <p className="text-sm text-muted-foreground">Nenhuma tarefa pendente</p>
          </CardContent>
        </Card>
      )}

      {/* Other pending */}
      {otherPending.length > 0 && (
        <div className="space-y-2">
          <p className="text-xs font-semibold text-amber-600 uppercase tracking-wide">Pendentes — {otherPending.length}</p>
          {otherPending.map(t => <TaskCard key={t.id} task={t} />)}
        </div>
      )}

      {/* Completed */}
      {completed.length > 0 && (
        <div className="space-y-2">
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Concluídas recentes</p>
          {completed.map(t => <TaskCard key={t.id} task={t} />)}
        </div>
      )}

      {/* Create task modal */}
      <TaskUnifiedModal
        open={showCreateModal}
        onOpenChange={setShowCreateModal}
        mode="create"
        sellers={sellers}
        onCompleted={() => {
          queryClient.invalidateQueries({ queryKey: ['entregador-tarefas'] });
        }}
      />
    </div>
  );
}

function TaskCard({ task }: { task: any }) {
  const info = STATUS_MAP[task.status] || STATUS_MAP.pendente;
  const clientName = task.clients?.company_name;

  return (
    <Card className="border-border/50 bg-card shadow-sm">
      <CardContent className="p-4 space-y-1.5">
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1 min-w-0">
            {clientName && (
              <p className="text-sm font-semibold text-foreground truncate">{clientName}</p>
            )}
            {task.notes && (
              <p className="text-xs text-muted-foreground line-clamp-2 mt-0.5">{task.notes}</p>
            )}
          </div>
          <Badge variant="outline" className={`shrink-0 text-[10px] ${info.color}`}>
            {info.label}
          </Badge>
        </div>
        <p className="text-[11px] text-muted-foreground">
          {task.task_date
            ? format(new Date(task.task_date + 'T12:00:00'), "dd MMM yyyy", { locale: ptBR })
            : '—'}
          {task.contact_type && ` • ${task.contact_type}`}
          {task.priority && ` • ${task.priority}`}
        </p>
      </CardContent>
    </Card>
  );
}
