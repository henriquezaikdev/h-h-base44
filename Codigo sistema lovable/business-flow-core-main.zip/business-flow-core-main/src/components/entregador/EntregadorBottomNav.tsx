import { Truck, User, ClipboardList } from 'lucide-react';
import { cn } from '@/lib/utils';

interface Props {
  activeTab: 'entregas' | 'tarefas' | 'perfil';
  onTabChange: (tab: 'entregas' | 'tarefas' | 'perfil') => void;
}

const TABS = [
  { key: 'entregas' as const, label: 'Entregas', icon: Truck },
  { key: 'tarefas' as const, label: 'Tarefas', icon: ClipboardList },
  { key: 'perfil' as const, label: 'Perfil', icon: User },
] as const;

export function EntregadorBottomNav({ activeTab, onTabChange }: Props) {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-card border-t border-border safe-area-bottom">
      <div className="flex items-center justify-around h-16 max-w-md mx-auto">
        {TABS.map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.key;
          return (
            <button
              key={tab.key}
              onClick={() => onTabChange(tab.key)}
              className={cn(
                'flex flex-col items-center justify-center gap-0.5 flex-1 h-full transition-colors',
                isActive ? 'text-primary' : 'text-muted-foreground'
              )}
            >
              <Icon size={22} strokeWidth={isActive ? 2.5 : 1.8} />
              <span className={cn('text-[10px]', isActive ? 'font-bold' : 'font-medium')}>
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
