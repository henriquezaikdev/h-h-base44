import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { supabase } from '@/integrations/supabase/client';
import { useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { Loader2, Plus } from 'lucide-react';

interface ManualDeliveryModalProps {
  open: boolean;
  onClose: () => void;
  driverName: string;
}

export function ManualDeliveryModal({ open, onClose, driverName }: ManualDeliveryModalProps) {
  const queryClient = useQueryClient();
  const [saving, setSaving] = useState(false);

  const todayStr = new Date().toISOString().split('T')[0];

  const [destinatario, setDestinatario] = useState('');
  const [endereco, setEndereco] = useState('');
  const [dataEntrega, setDataEntrega] = useState(todayStr);
  const [hora, setHora] = useState('');
  const [status, setStatus] = useState('ENTREGUE');
  const [pedido, setPedido] = useState('');
  const [observacao, setObservacao] = useState('');

  const resetForm = () => {
    setDestinatario('');
    setEndereco('');
    setDataEntrega(todayStr);
    setHora('');
    setStatus('ENTREGUE');
    setPedido('');
    setObservacao('');
  };

  const handleSubmit = async () => {
    if (!destinatario.trim()) {
      toast.error('Informe o destinatário');
      return;
    }

    setSaving(true);
    try {
      const dataBaixa = hora
        ? `${dataEntrega}T${hora}:00`
        : `${dataEntrega}T12:00:00`;

      const obsFinal = observacao.trim()
        ? `[REGISTRO MANUAL] ${observacao.trim()}`
        : '[REGISTRO MANUAL]';

      const { error } = await supabase.from('entregas_eo').insert({
        destinatario: destinatario.trim(),
        endereco: endereco.trim() || null,
        data_baixa: dataBaixa,
        hora_baixa: hora || null,
        status,
        controle_pedido: pedido.trim() || null,
        observacao: obsFinal,
        entregador: driverName,
      });

      if (error) throw error;

      toast.success('Entrega registrada com sucesso!');
      queryClient.invalidateQueries({ queryKey: ['entregador-all-entregas'] });
      resetForm();
      onClose();
    } catch (err: any) {
      toast.error('Erro ao registrar entrega');
      console.error(err);
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="max-w-[95vw] sm:max-w-md rounded-xl">
        <DialogHeader>
          <DialogTitle className="text-base">Registrar Entrega Manual</DialogTitle>
        </DialogHeader>

        <div className="space-y-4 mt-2">
          <div className="space-y-1.5">
            <Label className="text-xs">Destinatário *</Label>
            <Input
              placeholder="Nome do cliente / loja"
              value={destinatario}
              onChange={(e) => setDestinatario(e.target.value)}
            />
          </div>

          <div className="space-y-1.5">
            <Label className="text-xs">Endereço</Label>
            <Input
              placeholder="Endereço de entrega"
              value={endereco}
              onChange={(e) => setEndereco(e.target.value)}
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label className="text-xs">Data</Label>
              <Input
                type="date"
                value={dataEntrega}
                onChange={(e) => setDataEntrega(e.target.value)}
              />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">Hora</Label>
              <Input
                type="time"
                value={hora}
                onChange={(e) => setHora(e.target.value)}
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label className="text-xs">Status</Label>
              <Select value={status} onValueChange={setStatus}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ENTREGUE">Entregue</SelectItem>
                  <SelectItem value="SAIU_ENTREGA">Em rota</SelectItem>
                  <SelectItem value="PENDENTE">Pendente</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">Nº Pedido</Label>
              <Input
                placeholder="Ex: 12345"
                value={pedido}
                onChange={(e) => setPedido(e.target.value)}
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <Label className="text-xs">Observação</Label>
            <Textarea
              placeholder="Observações adicionais..."
              value={observacao}
              onChange={(e) => setObservacao(e.target.value)}
              rows={2}
            />
          </div>

          <Button
            onClick={handleSubmit}
            disabled={saving}
            className="w-full h-11 gap-2"
          >
            {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
            {saving ? 'Salvando...' : 'Registrar Entrega'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
