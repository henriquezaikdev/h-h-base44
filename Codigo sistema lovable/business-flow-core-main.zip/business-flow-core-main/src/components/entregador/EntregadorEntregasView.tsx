import { useAuth } from '@/hooks/useAuth';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Truck, MapPin, ExternalLink, Loader2 } from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

const STATUS_COLOR: Record<string, string> = {
  ENTREGUE: 'bg-emerald-100 text-emerald-700 border-emerald-200',
  SAIU_ENTREGA: 'bg-blue-100 text-blue-700 border-blue-200',
  PENDENTE: 'bg-amber-100 text-amber-700 border-amber-200',
};

const STATUS_LABEL: Record<string, string> = {
  ENTREGUE: 'Entregue',
  SAIU_ENTREGA: 'Em rota',
  PENDENTE: 'Pendente',
};

export function EntregadorEntregasView() {
  const { seller } = useAuth();
  const driverName = seller?.name?.toUpperCase() || '';

  const { data: entregas = [], isLoading } = useQuery({
    queryKey: ['entregador-entregas', seller?.id],
    queryFn: async () => {
      const today = new Date().toISOString().split('T')[0];
      const thirtyDaysAgo = new Date(Date.now() - 30 * 86400000).toISOString().split('T')[0];
      
      const { data } = await supabase
        .from('entregas_eo')
        .select('id, destinatario, endereco, status, data_baixa, link, controle_pedido, entregador')
        .ilike('entregador', `%${driverName.split(' ')[0]}%`)
        .gte('data_baixa', thirtyDaysAgo)
        .order('data_baixa', { ascending: false })
        .limit(50);

      return data || [];
    },
    enabled: !!seller?.id && driverName.length > 0,
    staleTime: 1000 * 60 * 2,
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-16">
        <Loader2 className="animate-spin h-8 w-8 text-primary" />
      </div>
    );
  }

  const today = new Date().toISOString().split('T')[0];
  const todayEntregas = entregas.filter(e => e.data_baixa?.startsWith(today));
  const pastEntregas = entregas.filter(e => !e.data_baixa?.startsWith(today));

  return (
    <div className="space-y-5 pb-4">
      <div>
        <h2 className="text-base font-bold text-foreground mb-1">Minhas Entregas</h2>
        <p className="text-xs text-muted-foreground">Últimos 30 dias • {entregas.length} registros</p>
      </div>

      {/* Today */}
      {todayEntregas.length > 0 && (
        <div className="space-y-2">
          <p className="text-xs font-semibold text-primary uppercase tracking-wide">Hoje — {todayEntregas.length} entregas</p>
          {todayEntregas.map(e => (
            <EntregaCard key={e.id} entrega={e} />
          ))}
        </div>
      )}

      {todayEntregas.length === 0 && (
        <Card className="border-border/50">
          <CardContent className="py-8 text-center">
            <Truck className="h-10 w-10 mx-auto mb-2 text-muted-foreground/40" />
            <p className="text-sm text-muted-foreground">Nenhuma entrega hoje</p>
          </CardContent>
        </Card>
      )}

      {/* Past */}
      {pastEntregas.length > 0 && (
        <div className="space-y-2">
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Anteriores</p>
          {pastEntregas.slice(0, 20).map(e => (
            <EntregaCard key={e.id} entrega={e} />
          ))}
        </div>
      )}
    </div>
  );
}

function EntregaCard({ entrega }: { entrega: any }) {
  const statusClass = STATUS_COLOR[entrega.status] || 'bg-muted text-muted-foreground';
  const statusLabel = STATUS_LABEL[entrega.status] || entrega.status || 'N/A';

  return (
    <Card className="border-border/50 bg-card shadow-sm">
      <CardContent className="p-4 space-y-2">
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold text-foreground truncate">
              {entrega.destinatario || 'Sem destinatário'}
            </p>
            {entrega.endereco && (
              <p className="text-xs text-muted-foreground flex items-start gap-1 mt-0.5">
                <MapPin className="h-3 w-3 mt-0.5 shrink-0" />
                <span className="line-clamp-2">{entrega.endereco}</span>
              </p>
            )}
          </div>
          <Badge variant="outline" className={`shrink-0 text-[10px] ${statusClass}`}>
            {statusLabel}
          </Badge>
        </div>

        <div className="flex items-center justify-between">
          <p className="text-[11px] text-muted-foreground">
            {entrega.data_baixa
              ? format(new Date(entrega.data_baixa), "dd MMM, HH:mm", { locale: ptBR })
              : '—'}
            {entrega.controle_pedido && ` • #${entrega.controle_pedido}`}
          </p>
          {entrega.link && (
            <Button
              variant="outline"
              size="sm"
              className="h-8 text-xs gap-1.5"
              onClick={() => window.open(entrega.link, '_blank')}
            >
              <ExternalLink className="h-3 w-3" />
              Rastrear
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
