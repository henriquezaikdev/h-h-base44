import { useState, useRef } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Camera, Loader2, Send } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";

interface NewPostModalProps {
  open: boolean;
  onClose: () => void;
  sellerId: string;
}

export function NewPostModal({ open, onClose, sellerId }: NewPostModalProps) {
  const queryClient = useQueryClient();
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [caption, setCaption] = useState("");
  const [saving, setSaving] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const reset = () => {
    setFile(null);
    setPreview(null);
    setCaption("");
    setSaving(false);
  };

  const handleClose = () => {
    reset();
    onClose();
  };

  const handleFileSelect = (f: File) => {
    setFile(f);
    setPreview(URL.createObjectURL(f));
  };

  const handleSubmit = async () => {
    if (!file) {
      toast.error("Selecione uma foto");
      return;
    }

    setSaving(true);
    try {
      const ext = file.name.split(".").pop() || "jpg";
      const path = `${sellerId}/post-${Date.now()}.${ext}`;
      const { error: uploadErr } = await supabase.storage.from("delivery-photos").upload(path, file);
      if (uploadErr) throw uploadErr;

      const { data: { publicUrl } } = supabase.storage.from("delivery-photos").getPublicUrl(path);

      const { error } = await supabase.from("delivery_posts").insert({
        seller_id: sellerId,
        image_url: publicUrl,
        caption: caption || null,
      });
      if (error) throw error;

      toast.success("Foto postada! +5 XP +5 Hões 🎉");
      queryClient.invalidateQueries({ queryKey: ["delivery-posts"] });
      queryClient.invalidateQueries({ queryKey: ["carteira-entregador"] });
      handleClose();
    } catch (err) {
      console.error("Post error:", err);
      toast.error("Erro ao postar foto");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-md mx-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Camera size={20} className="text-blue-500" />
            Nova Postagem
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <input
            ref={inputRef}
            type="file"
            accept="image/*"
            capture="environment"
            className="hidden"
            onChange={e => e.target.files?.[0] && handleFileSelect(e.target.files[0])}
          />

          <button
            onClick={() => inputRef.current?.click()}
            className="w-full aspect-square max-h-64 border-2 border-dashed border-border rounded-2xl flex flex-col items-center justify-center gap-3 hover:bg-muted/50 transition-colors overflow-hidden"
          >
            {preview ? (
              <img src={preview} alt="Preview" className="w-full h-full object-cover rounded-xl" />
            ) : (
              <>
                <Camera size={32} className="text-muted-foreground" />
                <span className="text-sm text-muted-foreground">Toque para tirar foto ou selecionar</span>
              </>
            )}
          </button>

          <div>
            <Label className="text-xs">Legenda (opcional)</Label>
            <Input
              value={caption}
              onChange={e => setCaption(e.target.value)}
              placeholder="Entrega concluída! 🚚"
              className="h-11"
            />
          </div>

          <div className="bg-muted/50 rounded-xl p-3 text-center">
            <p className="text-sm text-muted-foreground">
              Ao postar, você ganha <span className="font-bold text-amber-500">+10 XP</span> e <span className="font-bold text-emerald-500">+5 Hões</span>
            </p>
          </div>

          <Button
            onClick={handleSubmit}
            disabled={!file || saving}
            className="w-full h-12 rounded-xl"
          >
            {saving ? (
              <><Loader2 size={18} className="animate-spin mr-2" />Postando...</>
            ) : (
              <><Send size={18} className="mr-2" />Publicar</>
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
