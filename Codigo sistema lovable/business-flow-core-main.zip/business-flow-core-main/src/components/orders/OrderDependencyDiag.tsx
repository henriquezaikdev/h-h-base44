import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Loader2, Search, ShieldAlert, CheckCircle2 } from 'lucide-react';

interface DepResult {
  order_id: string;
  order_number: string | null;
  status: string | null;
  source_system: string | null;
  is_deleted: boolean | null;
  dependencias: {
    order_items: number;
    fin_contas_receber: number;
    order_edit_requests: number;
    client_reactivations: number;
    import_logs: number;
    import_staging_items: number;
    entregas_eo: number;
  };
  bloqueio_fk: boolean;
  motivo_bloqueio: string;
}

export function OrderDependencyDiag() {
  const [searchId, setSearchId] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<DepResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const runDiag = async () => {
    const id = searchId.trim();
    if (!id) return;
    setLoading(true);
    setError(null);
    setResult(null);

    try {
      // Fetch order
      const { data: order, error: orderErr } = await supabase
        .from('orders')
        .select('id, order_number, source_system, is_deleted')
        .eq('id', id)
        .maybeSingle();

      if (orderErr) throw orderErr;
      if (!order) {
        setError(`Pedido com ID "${id}" não encontrado no banco.`);
        return;
      }

      // Count all FK dependencies in parallel
      const [
        { count: itemsCount },
        { count: contasReceberCount },
        { count: editReqCount },
        { count: reactivationsCount },
        { count: importLogsCount },
        { count: stagingCount },
        { count: entregasCount },
      ] = await Promise.all([
        supabase.from('order_items').select('id', { count: 'exact', head: true }).eq('order_id', id),
        supabase.from('fin_contas_receber').select('id', { count: 'exact', head: true }).eq('order_id', id),
        supabase.from('order_edit_requests').select('id', { count: 'exact', head: true }).eq('order_id', id),
        supabase.from('client_reactivations').select('id', { count: 'exact', head: true }).eq('order_id', id),
        supabase.from('import_logs').select('id', { count: 'exact', head: true }).eq('order_id', id),
        supabase.from('import_staging_items').select('id', { count: 'exact', head: true }).eq('order_id', id),
        supabase.from('entregas_eo').select('id', { count: 'exact', head: true }).eq('pedido_id', id),
      ]);

      const deps = {
        order_items: itemsCount ?? 0,
        fin_contas_receber: contasReceberCount ?? 0,
        order_edit_requests: editReqCount ?? 0,
        client_reactivations: reactivationsCount ?? 0,
        import_logs: importLogsCount ?? 0,
        import_staging_items: stagingCount ?? 0,
        entregas_eo: entregasCount ?? 0,
      };

      const blocking = Object.entries(deps).filter(([, v]) => v > 0);
      const bloqueio = blocking.length > 0;
      const motivo = bloqueio
        ? `FK ativa em: ${blocking.map(([k, v]) => `${k} (${v})`).join(', ')}`
        : 'Nenhuma dependência encontrada — pode ser excluído.';

      setResult({
        order_id: order.id,
        order_number: order.order_number,
        status: null,
        source_system: order.source_system,
        is_deleted: order.is_deleted,
        dependencias: deps,
        bloqueio_fk: bloqueio,
        motivo_bloqueio: motivo,
      });
    } catch (err: any) {
      setError(err.message || 'Erro ao consultar dependências.');
    } finally {
      setLoading(false);
    }
  };

  const depRows = result
    ? Object.entries(result.dependencias).map(([table, count]) => ({ table, count }))
    : [];

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-sm font-medium flex items-center gap-2">
          <ShieldAlert className="h-4 w-4" />
          Diagnóstico de Bloqueio de Exclusão
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex gap-2">
          <Input
            placeholder="Cole o UUID do pedido aqui..."
            value={searchId}
            onChange={(e) => setSearchId(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && runDiag()}
            className="font-mono text-xs"
          />
          <Button onClick={runDiag} disabled={loading || !searchId.trim()} size="sm">
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
          </Button>
        </div>

        {error && (
          <div className="rounded-lg bg-destructive/10 border border-destructive/20 p-3 text-sm text-destructive">
            {error}
          </div>
        )}

        {result && (
          <div className="space-y-3">
            {/* Order info */}
            <div className="flex flex-wrap gap-2 items-center text-sm">
              <Badge variant="outline" className="font-mono text-xs">#{result.order_number || '—'}</Badge>
              <Badge variant="secondary" className="text-xs">{result.source_system || 'sem source'}</Badge>
              {result.is_deleted && <Badge variant="destructive" className="text-xs">soft-deleted</Badge>}
            </div>

            {/* Verdict */}
            <div className={`rounded-lg p-3 border ${result.bloqueio_fk ? 'bg-destructive/10 border-destructive/20' : 'bg-emerald-500/10 border-emerald-500/20'}`}>
              <div className="flex items-center gap-2 text-sm font-medium">
                {result.bloqueio_fk ? (
                  <ShieldAlert className="h-4 w-4 text-destructive" />
                ) : (
                  <CheckCircle2 className="h-4 w-4 text-emerald-600" />
                )}
                <span className={result.bloqueio_fk ? 'text-destructive' : 'text-emerald-700'}>
                  {result.bloqueio_fk ? 'BLOQUEADO — Existem dependências FK' : 'LIVRE — Pode ser excluído'}
                </span>
              </div>
              <p className="text-xs text-muted-foreground mt-1">{result.motivo_bloqueio}</p>
            </div>

            {/* Dependency table */}
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b bg-muted/40">
                    <th className="text-left p-2 font-medium">Tabela (FK)</th>
                    <th className="text-right p-2 font-medium">Registros</th>
                    <th className="text-center p-2 font-medium">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {depRows.map(({ table, count }) => (
                    <tr key={table} className="border-b last:border-0">
                      <td className="p-2 font-mono text-xs">{table}</td>
                      <td className="p-2 text-right font-bold">{count}</td>
                      <td className="p-2 text-center">
                        {count > 0 ? (
                          <Badge variant="destructive" className="text-xs">Bloqueia</Badge>
                        ) : (
                          <span className="text-muted-foreground text-xs">OK</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Raw JSON */}
            <details className="text-xs">
              <summary className="cursor-pointer text-muted-foreground hover:text-foreground">Ver JSON bruto</summary>
              <pre className="mt-2 bg-muted/40 rounded-lg p-3 overflow-x-auto text-[10px]">
                {JSON.stringify(result, null, 2)}
              </pre>
            </details>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
