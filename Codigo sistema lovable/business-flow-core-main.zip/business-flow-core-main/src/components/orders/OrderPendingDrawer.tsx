import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from '@/components/ui/sheet';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { AlertTriangle, Tag, DollarSign, PackageX, Loader2, Check, X, UserX } from 'lucide-react';
import { toast } from 'sonner';
import { useActiveSellers } from '@/hooks/useSellersData';

interface PendingItem {
  id: string;
  product_name: string;
  product_id: string | null;
  missing_product: boolean | null;
  missing_cost: boolean | null;
  cost_price: number | null;
  pending_reason: string | null;
  hh_categoria_id: string | null;
}

interface Category {
  id: string;
  name: string;
}

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  orderId: string;
  orderNumber: string | null;
  onResolved?: () => void;
}

type EditingCost = { itemId: string; productId: string; value: string };

export function OrderPendingDrawer({ open, onOpenChange, orderId, orderNumber, onResolved }: Props) {
  const [items, setItems] = useState<PendingItem[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingCost, setEditingCost] = useState<EditingCost | null>(null);
  const [savingId, setSavingId] = useState<string | null>(null);
  const [orderSellerId, setOrderSellerId] = useState<string | null>(null);
  const [savingSeller, setSavingSeller] = useState(false);
  const { sellers: activeSellers } = useActiveSellers();

  useEffect(() => {
    if (!open) return;
    loadData();
  }, [open, orderId]);

  const loadData = async () => {
    setLoading(true);
    const [itemsRes, catsRes, orderRes] = await Promise.all([
      supabase
        .from('order_items')
        .select('id, product_name, product_id, missing_product, missing_cost, cost_price, pending_reason')
        .eq('order_id', orderId)
        .or('is_deleted.is.null,is_deleted.eq.false'),
      supabase
        .from('hh_categorias')
        .select('id, name')
        .eq('is_active', true)
        .order('name'),
      supabase
        .from('orders')
        .select('seller_id')
        .eq('id', orderId)
        .single(),
    ]);

    setOrderSellerId(orderRes.data?.seller_id ?? null);

    const rawItems = (itemsRes.data || []) as any[];

    // For items with product_id, fetch hh_categoria_id
    const productIds = rawItems.filter(i => i.product_id).map(i => i.product_id);
    let productCatMap: Record<string, string | null> = {};
    if (productIds.length > 0) {
      const { data: products } = await supabase
        .from('products')
        .select('id, hh_categoria_id')
        .in('id', productIds);
      (products || []).forEach((p: any) => {
        productCatMap[p.id] = p.hh_categoria_id;
      });
    }

    const enriched: PendingItem[] = rawItems.map(i => ({
      ...i,
      hh_categoria_id: i.product_id ? (productCatMap[i.product_id] ?? null) : null,
    }));

    // Only show items that have a pendency
    const pending = enriched.filter(i =>
      i.missing_product || i.missing_cost || !i.hh_categoria_id
    );

    setItems(pending);
    setCategories((catsRes.data || []) as Category[]);
    setLoading(false);
  };

  const getPendencyType = (item: PendingItem): { label: string; icon: React.ReactNode; color: string } => {
    if (item.missing_product) return { label: 'Produto não mapeado', icon: <PackageX className="h-4 w-4" />, color: 'text-red-600' };
    if (!item.hh_categoria_id) return { label: 'Sem categoria', icon: <Tag className="h-4 w-4" />, color: 'text-amber-600' };
    if (item.missing_cost || !item.cost_price || item.cost_price <= 0) return { label: 'Sem custo', icon: <DollarSign className="h-4 w-4" />, color: 'text-orange-600' };
    return { label: '', icon: null, color: '' };
  };

  const handleCategoryChange = async (item: PendingItem, categoryId: string) => {
    if (!item.product_id) return;
    setSavingId(item.id);
    const { error } = await supabase
      .from('products')
      .update({ hh_categoria_id: categoryId })
      .eq('id', item.product_id);
    if (error) {
      toast.error('Erro ao categorizar produto');
    } else {
      toast.success(`Categoria atribuída para ${item.product_name}`);
      setItems(prev => prev.map(i => i.id === item.id ? { ...i, hh_categoria_id: categoryId } : i));
    }
    setSavingId(null);
  };

  const handleSaveCost = async () => {
    if (!editingCost) return;
    const cost = parseFloat(editingCost.value.replace(',', '.'));
    if (isNaN(cost) || cost <= 0) {
      toast.error('Informe um valor de custo válido');
      return;
    }
    setSavingId(editingCost.itemId);

    // Update product cost
    const { error: prodErr } = await supabase
      .from('products')
      .update({ cost_price: cost })
      .eq('id', editingCost.productId);

    if (prodErr) {
      toast.error('Erro ao salvar custo');
      setSavingId(null);
      return;
    }

    toast.success('Custo atualizado');
    setItems(prev => prev.map(i =>
      i.id === editingCost.itemId ? { ...i, cost_price: cost, missing_cost: false } : i
    ));
    setEditingCost(null);
    setSavingId(null);
  };

  const handleSellerChange = async (sellerId: string) => {
    setSavingSeller(true);
    const { error } = await supabase
      .from('orders')
      .update({ seller_id: sellerId })
      .eq('id', orderId);
    if (error) {
      toast.error('Erro ao atribuir vendedor');
    } else {
      const sellerName = activeSellers.find(s => s.id === sellerId)?.name || '';
      toast.success(`Vendedor ${sellerName} atribuído ao pedido`);
      setOrderSellerId(sellerId);
    }
    setSavingSeller(false);
  };

  const itemPendingCount = items.filter(i => {
    const p = getPendencyType(i);
    return p.label !== '';
  }).length;

  const hasSellerPendency = !orderSellerId;
  const pendingCount = itemPendingCount + (hasSellerPendency ? 1 : 0);

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="w-full sm:max-w-lg overflow-y-auto">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-amber-500" />
            Pendências do Pedido {orderNumber || ''}
          </SheetTitle>
          <SheetDescription>
            {pendingCount > 0
              ? `${pendingCount} pendência(s) impedem a contabilização deste pedido.`
              : 'Todas as pendências foram resolvidas! Reprocesse o pedido para contabilizar.'}
          </SheetDescription>
        </SheetHeader>

        <div className="mt-6 space-y-3">
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
          ) : (
            <>
              {/* Seller pendency */}
              {hasSellerPendency && (
                <div className="border rounded-lg p-3 space-y-2">
                  <div className="flex items-start justify-between gap-2">
                    <p className="text-sm font-medium text-foreground leading-tight flex-1">
                      Pedido sem vendedor atribuído
                    </p>
                    <Badge variant="outline" className="shrink-0 text-[10px] gap-1 text-purple-600">
                      <UserX className="h-4 w-4" />
                      Sem vendedor
                    </Badge>
                  </div>
                  <div className="flex items-center gap-2">
                    <Select onValueChange={handleSellerChange} disabled={savingSeller}>
                      <SelectTrigger className="h-8 text-xs flex-1">
                        <SelectValue placeholder="Selecionar vendedor..." />
                      </SelectTrigger>
                      <SelectContent>
                        {activeSellers.map(s => (
                          <SelectItem key={s.id} value={s.id} className="text-xs">
                            {s.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {savingSeller && <Loader2 className="h-4 w-4 animate-spin" />}
                  </div>
                </div>
              )}

              {/* Item pendencies */}
              {items.length === 0 && !hasSellerPendency ? (
                <div className="text-center py-12 text-muted-foreground text-sm">
                  Nenhuma pendência encontrada.
                </div>
              ) : (
                items.map(item => {
                  const pendency = getPendencyType(item);
                  if (!pendency.label) return null;

                  return (
                    <div key={item.id} className="border rounded-lg p-3 space-y-2">
                      <div className="flex items-start justify-between gap-2">
                        <p className="text-sm font-medium text-foreground leading-tight flex-1">
                          {item.product_name}
                        </p>
                        <Badge variant="outline" className={`shrink-0 text-[10px] gap-1 ${pendency.color}`}>
                          {pendency.icon}
                          {pendency.label}
                        </Badge>
                      </div>

                      {/* Action: Sem categoria */}
                      {!item.hh_categoria_id && !item.missing_product && item.product_id && (
                        <div className="flex items-center gap-2">
                          <Select
                            onValueChange={(val) => handleCategoryChange(item, val)}
                            disabled={savingId === item.id}
                          >
                            <SelectTrigger className="h-8 text-xs flex-1">
                              <SelectValue placeholder="Selecionar categoria..." />
                            </SelectTrigger>
                            <SelectContent>
                              {categories.map(cat => (
                                <SelectItem key={cat.id} value={cat.id} className="text-xs">
                                  {cat.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          {savingId === item.id && <Loader2 className="h-4 w-4 animate-spin" />}
                        </div>
                      )}

                      {/* Action: Sem custo */}
                      {item.hh_categoria_id && !item.missing_product && item.product_id && (item.missing_cost || !item.cost_price || item.cost_price <= 0) && (
                        <div className="flex items-center gap-2">
                          {editingCost?.itemId === item.id ? (
                            <>
                              <Input
                                type="text"
                                placeholder="Ex: 12.50"
                                value={editingCost.value}
                                onChange={e => setEditingCost({ ...editingCost, value: e.target.value })}
                                className="h-8 text-xs flex-1"
                                autoFocus
                              />
                              <Button size="icon" variant="ghost" className="h-8 w-8 text-emerald-600" onClick={handleSaveCost} disabled={savingId === item.id}>
                                {savingId === item.id ? <Loader2 className="h-4 w-4 animate-spin" /> : <Check className="h-4 w-4" />}
                              </Button>
                              <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => setEditingCost(null)}>
                                <X className="h-4 w-4" />
                              </Button>
                            </>
                          ) : (
                            <Button
                              variant="outline"
                              size="sm"
                              className="text-xs h-8 gap-1"
                              onClick={() => setEditingCost({ itemId: item.id, productId: item.product_id!, value: '' })}
                            >
                              <DollarSign className="h-3 w-3" />
                              Informar custo
                            </Button>
                          )}
                        </div>
                      )}

                      {/* Missing product — no inline action possible */}
                      {item.missing_product && (
                        <p className="text-[11px] text-muted-foreground">
                          Este produto precisa ser vinculado na importação de pedidos.
                        </p>
                      )}
                    </div>
                  );
                })
              )}
            </>
          )}
        </div>

        {!loading && pendingCount === 0 && (
          <div className="mt-4">
            <Button
              className="w-full"
              onClick={() => {
                onResolved?.();
                onOpenChange(false);
              }}
            >
              Reprocessar pedido
            </Button>
          </div>
        )}
      </SheetContent>
    </Sheet>
  );
}