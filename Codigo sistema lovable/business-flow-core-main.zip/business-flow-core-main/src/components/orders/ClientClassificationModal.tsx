import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { Loader2, Search, Check, UserPlus, Megaphone, Globe, Store, RotateCcw, Building2, Clock } from 'lucide-react';
import { cn } from '@/lib/utils';

type ClientCategory = 'conquistado' | 'indicacao' | 'google' | 'porta_da_loja' | 'reativacao' | 'filial' | 'janela_longa';

interface ClientClassificationModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  clientId: string;
  clientName: string;
  clientCnpj: string | null;
  sellerId: string;
  onClassified: () => void;
}

interface MatrizOption {
  id: string;
  company_name: string;
  cnpj: string | null;
}

const CATEGORIES: { key: ClientCategory; label: string; description: string; icon: React.ReactNode }[] = [
  { key: 'conquistado', label: 'Conquistado', description: 'Eu prospectei e fechei', icon: <UserPlus className="h-5 w-5" /> },
  { key: 'indicacao', label: 'Indicação', description: 'Veio por indicação', icon: <Megaphone className="h-5 w-5" /> },
  { key: 'google', label: 'Google', description: 'Veio pela internet / Google', icon: <Globe className="h-5 w-5" /> },
  { key: 'porta_da_loja', label: 'Porta da Loja', description: 'Apareceu aqui na loja', icon: <Store className="h-5 w-5" /> },
  { key: 'reativacao', label: 'Reativação', description: 'Cliente antigo que voltou', icon: <RotateCcw className="h-5 w-5" /> },
  { key: 'filial', label: 'Filial / Outro CNPJ', description: 'É outro CNPJ de um cliente já meu', icon: <Building2 className="h-5 w-5" /> },
  { key: 'janela_longa', label: 'Janela Longa', description: 'Tem ciclo de compra longo, não é inativo', icon: <Clock className="h-5 w-5" /> },
];

export function ClientClassificationModal({
  open,
  onOpenChange,
  clientId,
  clientName,
  clientCnpj,
  sellerId,
  onClassified,
}: ClientClassificationModalProps) {
  const [selected, setSelected] = useState<ClientCategory | null>(null);
  const [indicadoPor, setIndicadoPor] = useState('');
  const [matrizSearch, setMatrizSearch] = useState('');
  const [matrizOptions, setMatrizOptions] = useState<MatrizOption[]>([]);
  const [selectedMatriz, setSelectedMatriz] = useState<MatrizOption | null>(null);
  const [searchingMatriz, setSearchingMatriz] = useState(false);
  const [saving, setSaving] = useState(false);

  // Reset state when modal opens
  useEffect(() => {
    if (open) {
      setSelected(null);
      setIndicadoPor('');
      setMatrizSearch('');
      setMatrizOptions([]);
      setSelectedMatriz(null);
    }
  }, [open]);

  // Search matriz clients
  useEffect(() => {
    if (!matrizSearch.trim() || matrizSearch.length < 2) {
      setMatrizOptions([]);
      return;
    }
    const timer = setTimeout(async () => {
      setSearchingMatriz(true);
      const { data } = await supabase
        .from('clients')
        .select('id, company_name, cnpj')
        .neq('id', clientId)
        .eq('is_deleted', false)
        .or(`company_name.ilike.%${matrizSearch}%,cnpj.ilike.%${matrizSearch}%`)
        .limit(10);
      setMatrizOptions((data as MatrizOption[]) || []);
      setSearchingMatriz(false);
    }, 400);
    return () => clearTimeout(timer);
  }, [matrizSearch, clientId]);

  const canSubmit = () => {
    if (!selected) return false;
    if (selected === 'indicacao' && !indicadoPor.trim()) return false;
    if (selected === 'filial' && !selectedMatriz) return false;
    return true;
  };

  const handleSubmit = async () => {
    if (!canSubmit()) return;
    setSaving(true);
    try {
      const updateData: Record<string, any> = {
        classification_status: 'CLASSIFICADO',
        classified_by: sellerId,
        classified_at: new Date().toISOString(),
        client_category_sub: null,
        indicado_por: null,
        matriz_client_id: null,
      };

      if (selected === 'porta_da_loja') {
        updateData.client_category = 'google';
        updateData.client_category_sub = 'porta_da_loja';
      } else {
        updateData.client_category = selected;
      }

      if (selected === 'indicacao') {
        updateData.indicado_por = indicadoPor.trim();
      }
      if (selected === 'filial' && selectedMatriz) {
        updateData.matriz_client_id = selectedMatriz.id;
      }

      const { error } = await supabase
        .from('clients')
        .update(updateData)
        .eq('id', clientId);

      if (error) throw error;
      toast.success('Cliente classificado com sucesso!');
      onClassified();
      onOpenChange(false);
    } catch (err: any) {
      console.error('Error classifying client:', err);
      toast.error('Erro ao classificar cliente');
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="text-lg">Classificar Cliente</DialogTitle>
        </DialogHeader>

        {/* Client info */}
        <div className="rounded-lg border border-border bg-muted/30 p-3 space-y-1">
          <p className="font-medium text-sm text-foreground">{clientName}</p>
          {clientCnpj && (
            <p className="text-xs text-muted-foreground">CNPJ: {clientCnpj}</p>
          )}
        </div>

        <p className="text-sm font-medium text-foreground">Como este cliente chegou até nós?</p>

        {/* Category buttons */}
        <div className="grid grid-cols-1 gap-2 max-h-[300px] overflow-y-auto pr-1">
          {CATEGORIES.map((cat) => (
            <button
              key={cat.key}
              type="button"
              onClick={() => {
                setSelected(cat.key);
                if (cat.key !== 'indicacao') setIndicadoPor('');
                if (cat.key !== 'filial') { setMatrizSearch(''); setSelectedMatriz(null); }
              }}
              className={cn(
                "flex items-center gap-3 p-3 rounded-lg border text-left transition-all",
                selected === cat.key
                  ? "border-primary bg-primary/5 ring-1 ring-primary/30"
                  : "border-border hover:border-primary/40 hover:bg-muted/50"
              )}
            >
              <div className={cn(
                "flex-shrink-0 w-9 h-9 rounded-lg flex items-center justify-center",
                selected === cat.key ? "bg-primary/10 text-primary" : "bg-muted text-muted-foreground"
              )}>
                {cat.icon}
              </div>
              <div className="min-w-0">
                <p className="text-sm font-medium text-foreground">{cat.label}</p>
                <p className="text-xs text-muted-foreground">{cat.description}</p>
              </div>
              {selected === cat.key && (
                <Check className="h-4 w-4 text-primary ml-auto flex-shrink-0" />
              )}
            </button>
          ))}
        </div>

        {/* Conditional fields */}
        {selected === 'indicacao' && (
          <div className="space-y-1.5">
            <label className="text-xs font-medium text-foreground">Quem indicou?</label>
            <Input
              value={indicadoPor}
              onChange={(e) => setIndicadoPor(e.target.value)}
              placeholder="Nome de quem indicou"
              className="h-9 text-sm"
            />
          </div>
        )}

        {selected === 'filial' && (
          <div className="space-y-2">
            <label className="text-xs font-medium text-foreground">Buscar cliente matriz</label>
            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
              <Input
                value={matrizSearch}
                onChange={(e) => { setMatrizSearch(e.target.value); setSelectedMatriz(null); }}
                placeholder="Digite nome ou CNPJ..."
                className="pl-8 h-9 text-sm"
              />
              {searchingMatriz && <Loader2 className="absolute right-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 animate-spin text-muted-foreground" />}
            </div>
            {matrizOptions.length > 0 && !selectedMatriz && (
              <div className="border border-border rounded-lg max-h-[150px] overflow-y-auto divide-y divide-border">
                {matrizOptions.map((opt) => (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() => { setSelectedMatriz(opt); setMatrizSearch(opt.company_name); }}
                    className="w-full text-left px-3 py-2 hover:bg-muted/50 transition-colors"
                  >
                    <p className="text-sm font-medium text-foreground truncate">{opt.company_name}</p>
                    {opt.cnpj && <p className="text-xs text-muted-foreground">{opt.cnpj}</p>}
                  </button>
                ))}
              </div>
            )}
            {selectedMatriz && (
              <Badge variant="default" className="gap-1">
                <Check className="h-3 w-3" />
                {selectedMatriz.company_name}
              </Badge>
            )}
          </div>
        )}

        {/* Submit */}
        <Button onClick={handleSubmit} disabled={!canSubmit() || saving} className="w-full mt-2">
          {saving ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
          Confirmar Classificação
        </Button>
      </DialogContent>
    </Dialog>
  );
}
