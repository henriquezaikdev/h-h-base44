import { motion } from 'framer-motion';
import { PackageOpen, TrendingUp, DollarSign, ShoppingCart } from 'lucide-react';

interface OrdersPageHeaderProps {
  totalOrders: number;
  totalValue?: number;
}

export function OrdersPageHeader({ totalOrders, totalValue }: OrdersPageHeaderProps) {
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
      notation: 'compact',
      maximumFractionDigits: 1,
    }).format(value);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, ease: 'easeOut' }}
      className="relative rounded-2xl overflow-hidden bg-gradient-to-br from-emerald-500/10 via-teal-500/5 to-transparent border border-emerald-500/20 p-6"
    >
      {/* Decorative blurred spheres */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute -top-12 -right-12 w-40 h-40 bg-emerald-500/20 rounded-full blur-3xl" />
        <div className="absolute -bottom-8 -left-8 w-32 h-32 bg-teal-500/20 rounded-full blur-3xl" />
      </div>

      <div className="relative flex items-center justify-between flex-wrap gap-4">
        <div className="flex items-center gap-4">
          <motion.div
            initial={{ scale: 0.8, rotate: -10 }}
            animate={{ scale: 1, rotate: 0 }}
            transition={{ delay: 0.2, type: 'spring', stiffness: 200 }}
            className="w-14 h-14 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center shadow-lg shadow-emerald-500/25"
          >
            <PackageOpen className="w-7 h-7 text-white" />
          </motion.div>
          
          <div>
            <motion.h1 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1 }}
              className="text-xl font-semibold text-foreground"
            >
              Pedidos
            </motion.h1>
            <motion.p 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.3 }}
              className="text-muted-foreground flex items-center gap-2"
            >
              <TrendingUp className="w-4 h-4 text-emerald-500" />
              <span>Histórico completo de vendas</span>
            </motion.p>
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.3 }}
          className="flex items-center gap-4"
        >
          <div className="flex items-center gap-6 bg-muted/50 backdrop-blur-sm rounded-xl px-5 py-3 border border-border/50">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-emerald-500/20 flex items-center justify-center">
                <ShoppingCart className="w-4 h-4 text-emerald-600" />
              </div>
              <div>
                <p className="text-base font-semibold text-foreground">{totalOrders.toLocaleString('pt-BR')}</p>
                <p className="text-xs text-muted-foreground">pedidos</p>
              </div>
            </div>
            {totalValue !== undefined && totalValue > 0 && (
              <>
                <div className="w-px h-8 bg-border" />
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-teal-500/20 flex items-center justify-center">
                    <DollarSign className="w-4 h-4 text-teal-600" />
                  </div>
                  <div>
                    <p className="text-base font-semibold text-foreground">{formatCurrency(totalValue)}</p>
                    <p className="text-xs text-muted-foreground">total</p>
                  </div>
                </div>
              </>
            )}
          </div>
        </motion.div>
      </div>
    </motion.div>
  );
}
