import { Badge } from '@/components/ui/badge';
import { Tag } from 'lucide-react';

interface ClassificationBadgeProps {
  onClick: () => void;
}

export function ClassificationBadge({ onClick }: ClassificationBadgeProps) {
  return (
    <Badge
      className="cursor-pointer gap-1 text-[10px] px-1.5 py-0.5 bg-amber-500/15 text-amber-600 dark:text-amber-400 border-amber-500/30 hover:bg-amber-500/25 transition-colors"
      variant="outline"
      onClick={(e) => {
        e.preventDefault();
        e.stopPropagation();
        onClick();
      }}
    >
      <Tag className="h-2.5 w-2.5" />
      Classificar
    </Badge>
  );
}
