import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Loader2 } from "lucide-react";

interface DeleteOrderModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  orderNumber: string | null;
  onConfirm: () => void;
  isDeleting: boolean;
}

export function DeleteOrderModal({
  open,
  onOpenChange,
  orderNumber,
  onConfirm,
  isDeleting,
}: DeleteOrderModalProps) {
  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Excluir pedido</AlertDialogTitle>
          <AlertDialogDescription>
            Tem certeza que deseja excluir o pedido <strong>#{orderNumber}</strong>?
            <br />
            Esta ação não pode ser desfeita. Todos os itens do pedido também serão removidos.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel disabled={isDeleting}>Cancelar</AlertDialogCancel>
          <AlertDialogAction
            onClick={onConfirm}
            disabled={isDeleting}
            className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
          >
            {isDeleting ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Excluindo...
              </>
            ) : (
              "Excluir"
            )}
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}
