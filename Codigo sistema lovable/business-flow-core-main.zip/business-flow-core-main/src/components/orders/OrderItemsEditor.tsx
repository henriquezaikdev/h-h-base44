import { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { Plus, Trash2, Save, X, Search, Loader2, RotateCcw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { ScrollArea } from '@/components/ui/scroll-area';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { useEditStore } from '@/store/useEditStore';
import { registerActiveEdit } from '@/lib/realtimeUtils';
import { toast } from 'sonner';

export interface EditableOrderItem {
  id?: string;
  product_id?: string | null;
  product_name: string;
  quantity: number;
  unit_price: number;
  subtotal: number;
  cost_price: number | null;
  cost_subtotal: number | null;
}

interface Product {
  id: string;
  name: string;
  sku: string | null;
  cost_price: number | null;
  sale_price: number | null;
  is_cost_blocked?: boolean;
}

interface OrderItemsEditorProps {
  items: EditableOrderItem[];
  orderId?: string;
  onSave: (items: EditableOrderItem[]) => void;
  onCancel: () => void;
  isSaving: boolean;
  saveLabel?: string;
}


export function OrderItemsEditor({
  items,
  orderId,
  onSave,
  onCancel,
  isSaving,
  saveLabel = 'Salvar',
}: OrderItemsEditorProps) {
  const { user } = useAuth();

  // GLOBAL STORE: State survives remounts

  const { 
    getOrderItems, 
    setOrderItems: saveToStore, 
    clearOrderItems 
  } = useEditStore();
  
  const storeKey = orderId || 'new';
  
  // Initialize from store (survives remount) or props
  const [editedItems, setEditedItems] = useState<EditableOrderItem[]>(() => {
    const stored = getOrderItems(storeKey);
    if (stored?.items && Array.isArray(stored.items) && stored.items.length > 0) {
      return stored.items;
    }
    return items;
  });
  
  const [showDraftRecovery, setShowDraftRecovery] = useState(() => {
    const stored = getOrderItems(storeKey);
    return !!(stored?.items && Array.isArray(stored.items) && stored.items.length > 0);
  });
  
  // Track if form is dirty (has unsaved changes) - prevents server data from overwriting
  const isDirtyRef = useRef(false);
  const initializedRef = useRef(false);
  
  // Mark as initialized after first render
  useEffect(() => {
    initializedRef.current = true;
  }, []);
  
  // PROTECTION: Only update from props if not dirty and not from store
  useEffect(() => {
    if (showDraftRecovery || isDirtyRef.current) return;
    if (!initializedRef.current) return;
    
    // Only sync if items prop actually changed and we have no local changes
    setEditedItems(items);
  }, [items, showDraftRecovery]);
  
  const [searchIndex, setSearchIndex] = useState<number | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<Product[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  
  // Register active editing to pause aggressive realtime
  useEffect(() => {
    const unregister = registerActiveEdit();
    return unregister;
  }, []);
  
  // Auto-save to GLOBAL STORE on changes (debounced)
  const latestItemsRef = useRef(editedItems);
  latestItemsRef.current = editedItems;
  
  useEffect(() => {
    const timeout = setTimeout(() => {
      saveToStore(storeKey, latestItemsRef.current);
    }, 500);

    return () => clearTimeout(timeout);
  }, [editedItems, storeKey, saveToStore]);
  
  // Clear store on successful save or explicit cancel
  const handleClearDraft = useCallback(() => {
    clearOrderItems(storeKey);
  }, [storeKey, clearOrderItems]);
  
  const handleDiscardDraft = () => {
    isDirtyRef.current = false;
    setEditedItems(items);
    setShowDraftRecovery(false);
    handleClearDraft();
    toast.info('Rascunho descartado');
  };
  
  const handleKeepDraft = () => {
    isDirtyRef.current = true;
    setShowDraftRecovery(false);
    toast.success('Rascunho restaurado');
  };

  const formatCurrency = (val: number) =>
    new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(val);

  // Debounced product search
  useEffect(() => {
    if (!searchQuery || searchQuery.length < 2) {
      setSearchResults([]);
      return;
    }

    const timeout = setTimeout(async () => {
      setIsSearching(true);
      try {
        const { data } = await supabase
          .from('products')
          .select('id, name, sku, cost_price, sale_price, is_cost_blocked')
          .eq('active', true)
          .or(`name.ilike.%${searchQuery}%,sku.ilike.%${searchQuery}%,codigo_conta_azul.ilike.%${searchQuery}%,external_code_contaazul.ilike.%${searchQuery}%`)
          .limit(15);

        setSearchResults(data || []);
      } catch (error) {
        console.error('Erro ao buscar produtos:', error);
      } finally {
        setIsSearching(false);
      }
    }, 300);

    return () => clearTimeout(timeout);
  }, [searchQuery]);

  const selectProduct = (index: number, product: Product) => {
    // BLOQUEIO: Verificar se o produto está bloqueado para venda
    if (product.is_cost_blocked) {
      toast.error(
        'Este produto está bloqueado para venda. Motivo: custo não atualizado ou código ausente. Atualize o produto antes de prosseguir.',
        { duration: 5000 }
      );
      return;
    }

    isDirtyRef.current = true; // Mark as dirty
    const updated = [...editedItems];
    const item = { ...updated[index] };
    
    item.product_id = product.id;
    item.product_name = product.name;
    item.cost_price = product.cost_price;
    if (product.sale_price && item.unit_price === 0) {
      item.unit_price = product.sale_price;
    }
    item.subtotal = item.quantity * item.unit_price;
    item.cost_subtotal = item.cost_price !== null ? item.quantity * item.cost_price : null;
    
    updated[index] = item;
    setEditedItems(updated);
    setSearchIndex(null);
    setSearchQuery('');
    setSearchResults([]);
  };

  const updateItem = (index: number, field: keyof EditableOrderItem, value: string | number) => {
    isDirtyRef.current = true; // Mark as dirty on any change
    const updated = [...editedItems];
    const item = { ...updated[index] };
    
    if (field === 'quantity' || field === 'unit_price') {
      const numValue = typeof value === 'string' ? parseFloat(value) || 0 : value;
      (item as any)[field] = numValue;
      item.subtotal = item.quantity * item.unit_price;
      if (item.cost_price !== null) {
        item.cost_subtotal = item.quantity * item.cost_price;
      }
    } else if (field === 'cost_price') {
      const numValue = typeof value === 'string' ? (value === '' ? null : parseFloat(value) || 0) : value;
      item.cost_price = numValue as number | null;
      item.cost_subtotal = numValue !== null ? item.quantity * numValue : null;
    } else {
      (item as any)[field] = value;
    }
    
    updated[index] = item;
    setEditedItems(updated);
  };

  const removeItem = (index: number) => {
    isDirtyRef.current = true; // Mark as dirty
    setEditedItems(editedItems.filter((_, i) => i !== index));
  };

  const addItem = () => {
    isDirtyRef.current = true; // Mark as dirty
    setEditedItems([...editedItems, {
      product_name: '',
      quantity: 1,
      unit_price: 0,
      subtotal: 0,
      cost_price: null,
      cost_subtotal: null
    }]);
  };

  const totalValue = editedItems.reduce((sum, item) => sum + item.subtotal, 0);
  const totalCost = editedItems.reduce((sum, item) => sum + (item.cost_subtotal || 0), 0);
  const totalProfit = totalValue - totalCost;

  const handleSaveWithClearDraft = (itemsToSave: EditableOrderItem[]) => {
    handleClearDraft();
    onSave(itemsToSave);
  };
  
  const handleCancelWithPrompt = () => {
    handleClearDraft();
    onCancel();
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div className="flex items-center gap-3">
          <CardTitle>Editar Itens</CardTitle>
          {showDraftRecovery && (
            <div className="flex items-center gap-2 text-sm">
              <span className="text-amber-600 dark:text-amber-400">Rascunho recuperado</span>
              <Button variant="ghost" size="sm" onClick={handleKeepDraft} className="h-7 text-xs">
                Manter
              </Button>
              <Button variant="ghost" size="sm" onClick={handleDiscardDraft} className="h-7 text-xs text-muted-foreground">
                <RotateCcw className="h-3 w-3 mr-1" />
                Descartar
              </Button>
            </div>
          )}
        </div>
        <Button variant="outline" size="sm" onClick={addItem}>
          <Plus className="h-4 w-4 mr-1" /> Adicionar Item
        </Button>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted">
              <tr>
                <th className="text-left px-2 py-2 font-medium text-muted-foreground">Produto</th>
                <th className="text-right px-2 py-2 font-medium text-muted-foreground w-20">Qtd</th>
                <th className="text-right px-2 py-2 font-medium text-muted-foreground w-28">Unitário</th>
                <th className="text-right px-2 py-2 font-medium text-muted-foreground w-28">Custo Unit.</th>
                <th className="text-right px-2 py-2 font-medium text-muted-foreground w-28">Subtotal</th>
                <th className="px-2 py-2 w-10"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {editedItems.map((item, index) => (
                <tr key={index}>
                  <td className="px-2 py-2">
                    <Popover 
                      open={searchIndex === index} 
                      onOpenChange={(open) => {
                        if (open) {
                          setSearchIndex(index);
                          setSearchQuery(item.product_name);
                        } else {
                          setSearchIndex(null);
                          setSearchQuery('');
                          setSearchResults([]);
                        }
                      }}
                    >
                      <PopoverTrigger asChild>
                        <div className="relative">
                          <Input
                            value={searchIndex === index ? searchQuery : item.product_name}
                            onChange={(e) => {
                              const value = e.target.value;
                              setSearchQuery(value);
                              updateItem(index, 'product_name', value);
                              if (searchIndex !== index) {
                                setSearchIndex(index);
                              }
                            }}
                            onFocus={() => {
                              setSearchIndex(index);
                              setSearchQuery(item.product_name);
                            }}
                            placeholder="Buscar produto..."
                            className="h-8 pr-8"
                          />
                          <Search className="absolute right-2 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        </div>
                      </PopoverTrigger>
                      <PopoverContent 
                        className="w-[400px] p-0" 
                        align="start"
                        onOpenAutoFocus={(e) => e.preventDefault()}
                      >
                        <div className="p-2 border-b">
                          <p className="text-xs text-muted-foreground">
                            {isSearching ? 'Buscando...' : searchResults.length > 0 ? `${searchResults.length} produtos encontrados` : searchQuery.length >= 2 ? 'Nenhum produto encontrado' : 'Digite para buscar'}
                          </p>
                        </div>
                        <ScrollArea className="max-h-[250px]">
                          {isSearching && (
                            <div className="flex items-center justify-center py-4">
                              <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
                            </div>
                          )}
                          {!isSearching && searchResults.map((product) => (
                            <div
                              key={product.id}
                              onClick={() => selectProduct(index, product)}
                              className={`px-3 py-2 hover:bg-muted cursor-pointer border-b last:border-b-0 ${product.is_cost_blocked ? 'opacity-60 bg-destructive/5' : ''}`}
                            >
                              <div className="flex items-center gap-2">
                                <span className="font-medium text-sm">{product.name}</span>
                                {product.is_cost_blocked && (
                                  <span className="inline-flex px-1.5 py-0.5 bg-destructive/10 text-destructive rounded text-xs">
                                    Bloqueado
                                  </span>
                                )}
                              </div>
                              <div className="flex gap-3 text-xs text-muted-foreground mt-0.5">
                                {product.sku && <span>SKU: {product.sku}</span>}
                                {product.cost_price && (
                                  <span>Custo: {formatCurrency(product.cost_price)}</span>
                                )}
                                {product.sale_price && (
                                  <span>Venda: {formatCurrency(product.sale_price)}</span>
                                )}
                              </div>
                            </div>
                          ))}
                        </ScrollArea>
                      </PopoverContent>
                    </Popover>
                  </td>
                  <td className="px-2 py-2">
                    <Input
                      type="number"
                      value={item.quantity}
                      onChange={(e) => updateItem(index, 'quantity', e.target.value)}
                      min={0}
                      step={1}
                      className="h-8 text-right"
                    />
                  </td>
                  <td className="px-2 py-2">
                    <Input
                      type="number"
                      value={item.unit_price}
                      onChange={(e) => updateItem(index, 'unit_price', e.target.value)}
                      min={0}
                      step={0.01}
                      className="h-8 text-right"
                    />
                  </td>
                  <td className="px-2 py-2">
                    <Input
                      type="number"
                      value={item.cost_price ?? ''}
                      onChange={(e) => updateItem(index, 'cost_price', e.target.value)}
                      min={0}
                      step={0.01}
                      placeholder="—"
                      className="h-8 text-right"
                    />
                  </td>
                  <td className="px-2 py-2 text-right font-medium">
                    {formatCurrency(item.subtotal)}
                  </td>
                  <td className="px-2 py-2">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 text-destructive hover:text-destructive"
                      onClick={() => removeItem(index)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Totais */}
        <div className="flex justify-end gap-6 pt-4 border-t text-sm">
          <div>
            <span className="text-muted-foreground">Total:</span>{' '}
            <span className="font-bold text-primary">{formatCurrency(totalValue)}</span>
          </div>
          <div>
            <span className="text-muted-foreground">Custo:</span>{' '}
            <span className="font-medium">{formatCurrency(totalCost)}</span>
          </div>
          <div>
            <span className="text-muted-foreground">Lucro:</span>{' '}
            <span className={`font-medium ${totalProfit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              {formatCurrency(totalProfit)}
            </span>
          </div>
        </div>

        {/* Ações */}
        <div className="flex justify-end gap-2 pt-4">
          <Button variant="outline" onClick={handleCancelWithPrompt} disabled={isSaving}>
            <X className="h-4 w-4 mr-1" /> Cancelar
          </Button>
          <Button onClick={() => handleSaveWithClearDraft(editedItems)} disabled={isSaving || editedItems.length === 0}>
            <Save className="h-4 w-4 mr-1" /> {isSaving ? 'Salvando...' : saveLabel}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
