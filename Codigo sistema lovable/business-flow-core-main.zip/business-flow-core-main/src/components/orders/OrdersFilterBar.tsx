import { motion } from 'framer-motion';
import { Search, X, Filter } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { PeriodFilter } from '@/components/ui/PeriodFilter';
import { UsePeriodFilterReturn } from '@/hooks/usePeriodFilter';

interface Seller {
  id: string;
  name: string;
}

interface OrdersFilterBarProps {
  searchQuery: string;
  onSearchChange: (value: string) => void;
  sellerFilter: string;
  onSellerChange: (value: string) => void;
  originFilter: string;
  onOriginChange: (value: string) => void;
  margemFilter: string;
  onMargemChange: (value: string) => void;
  sellers: Seller[];
  uniqueOrigins: string[];
  periodFilter: UsePeriodFilterReturn;
  hasActiveFilters: boolean;
  onResetFilters: () => void;
  totalCount: number;
}

export function OrdersFilterBar({
  searchQuery,
  onSearchChange,
  sellerFilter,
  onSellerChange,
  originFilter,
  onOriginChange,
  margemFilter,
  onMargemChange,
  sellers,
  uniqueOrigins,
  periodFilter,
  hasActiveFilters,
  onResetFilters,
  totalCount,
}: OrdersFilterBarProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.2 }}
      className="sticky top-0 z-40 -mx-6 px-6 py-4 bg-background/80 backdrop-blur-xl border-b border-border/50 space-y-3"
    >
      {/* First row */}
      <div className="flex flex-wrap items-center gap-3">
        {/* Search Input */}
        <div className="relative flex-1 min-w-[200px] max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" size={18} />
          <input
            type="text"
            placeholder="Buscar por número ou cliente..."
            className="w-full h-10 pl-10 pr-10 rounded-xl bg-muted/50 border border-border/50 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary/50 transition-all"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
          />
          {searchQuery && (
            <button
              onClick={() => onSearchChange('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
            >
              <X size={16} />
            </button>
          )}
        </div>

        {/* Seller Filter */}
        <Select value={sellerFilter} onValueChange={onSellerChange}>
          <SelectTrigger className="w-[170px] h-10 rounded-xl bg-muted/30 border-border/50 text-sm">
            <SelectValue placeholder="Vendedor" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos Vendedores</SelectItem>
            {sellers.map((s) => (
              <SelectItem key={s.id} value={s.id}>
                {s.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        {/* Origin Filter */}
        <Select value={originFilter} onValueChange={onOriginChange}>
          <SelectTrigger className="w-[150px] h-10 rounded-xl bg-muted/30 border-border/50 text-sm">
            <SelectValue placeholder="Origem" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todas Origens</SelectItem>
            <SelectItem value="__synced__">🔄 Sincronizados</SelectItem>
            {uniqueOrigins.map((o) => (
              <SelectItem key={o} value={o}>
                {o}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        {/* Margin Filter */}
        <Select value={margemFilter} onValueChange={onMargemChange}>
          <SelectTrigger className="w-[140px] h-10 rounded-xl bg-muted/30 border-border/50 text-sm">
            <SelectValue placeholder="Margem" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todas Margens</SelectItem>
            <SelectItem value="com">✓ Com margem</SelectItem>
            <SelectItem value="sem">○ Sem margem</SelectItem>
          </SelectContent>
        </Select>

        {/* Reset Filters */}
        {hasActiveFilters && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
          >
            <Button
              variant="ghost"
              size="sm"
              onClick={onResetFilters}
              className="h-10 px-3 text-muted-foreground hover:text-foreground rounded-xl"
            >
              <Filter size={14} className="mr-1" />
              Limpar
            </Button>
          </motion.div>
        )}

        {/* Results Count Badge */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.3 }}
          className="ml-auto"
        >
          <Badge 
            variant="secondary" 
            className="h-8 px-3 bg-primary/10 text-foreground font-medium rounded-lg"
          >
            {totalCount.toLocaleString('pt-BR')} pedidos
          </Badge>
        </motion.div>
      </div>

      {/* Second row: Period filter */}
      <div className="flex items-center gap-3">
        <PeriodFilter filter={periodFilter} />
      </div>
    </motion.div>
  );
}
