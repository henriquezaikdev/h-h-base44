import { useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { BarChart3, Loader2, Truck, XCircle, CheckCircle, RotateCcw, CalendarIcon } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { format, startOfDay, endOfDay, startOfWeek, endOfWeek, startOfMonth, endOfMonth, subMonths } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { cn } from '@/lib/utils';
import { useQuery } from '@tanstack/react-query';

type Shortcut = 'hoje' | 'semana' | 'mes' | 'mes_passado' | 'personalizado';

function getRange(shortcut: Shortcut): { start: Date; end: Date } {
  const now = new Date();
  switch (shortcut) {
    case 'hoje':
      return { start: startOfDay(now), end: endOfDay(now) };
    case 'semana':
      return { start: startOfWeek(now, { weekStartsOn: 1 }), end: endOfWeek(now, { weekStartsOn: 1 }) };
    case 'mes':
      return { start: startOfMonth(now), end: endOfMonth(now) };
    case 'mes_passado': {
      const prev = subMonths(now, 1);
      return { start: startOfMonth(prev), end: endOfMonth(prev) };
    }
    default:
      return { start: startOfMonth(now), end: endOfMonth(now) };
  }
}

interface Stats {
  total: number;
  entregue: number;
  coletado: number;
  cancelada: number;
  nao_entregue: number;
  reentrega: number;
  pendente: number;
  byDriver: Record<string, number>;
  byDriverDelivered: Record<string, number>;
  byDriverEntregue: Record<string, number>;
}

const SHORTCUT_LABELS: Record<Shortcut, string> = {
  hoje: 'Hoje',
  semana: 'Esta semana',
  mes: 'Este mês',
  mes_passado: 'Mês passado',
  personalizado: 'Personalizado',
};

function mapStatus(raw: string | null): string {
  if (!raw) return 'pendente';
  const upper = raw.trim().toUpperCase();
  if (upper === 'ENTREGUE') return 'entregue';
  if (upper === 'COLETADO') return 'coletado';
  if (upper === 'CANCELADA' || upper === 'CANCELADO') return 'cancelada';
  if (upper.includes('NÃO ENTREGUE') || upper.includes('NAO ENTREGUE')) return 'nao_entregue';
  if (upper.includes('REENTREGA')) return 'reentrega';
  return 'pendente';
}

export function DeliveryReportsTab() {
  const [shortcut, setShortcut] = useState<Shortcut>('mes');
  const [customStart, setCustomStart] = useState<Date | undefined>();
  const [customEnd, setCustomEnd] = useState<Date | undefined>();

  const { periodStart, periodEnd } = useMemo(() => {
    if (shortcut === 'personalizado' && customStart && customEnd) {
      return { periodStart: customStart, periodEnd: customEnd };
    }
    const r = getRange(shortcut);
    return { periodStart: r.start, periodEnd: r.end };
  }, [shortcut, customStart, customEnd]);

  const startStr = format(periodStart, 'yyyy-MM-dd');
  const endStr = format(periodEnd, 'yyyy-MM-dd');

  const { data: stats, isLoading: loading } = useQuery({
    queryKey: ['delivery-reports-eo', startStr, endStr],
    queryFn: async () => {
      const { data } = await supabase
        .from('entregas_eo')
        .select('status, entregador')
        .gte('data_baixa', startStr)
        .lte('data_baixa', endStr);

      if (!data) return null;

      const s: Stats = {
        total: data.length,
        entregue: 0, coletado: 0, cancelada: 0, nao_entregue: 0, reentrega: 0, pendente: 0,
        byDriver: {}, byDriverDelivered: {}, byDriverEntregue: {},
      };

      for (const d of data) {
        const st = mapStatus(d.status);
        (s as any)[st]++;
        if (d.entregador) {
          s.byDriver[d.entregador] = (s.byDriver[d.entregador] || 0) + 1;
          if (st === 'entregue' || st === 'coletado') {
            s.byDriverDelivered[d.entregador] = (s.byDriverDelivered[d.entregador] || 0) + 1;
          }
          if (st === 'entregue') {
            const driverKey = d.entregador.trim().toUpperCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
            s.byDriverEntregue[driverKey] = (s.byDriverEntregue[driverKey] || 0) + 1;
          }
        }
      }

      return s;
    },
  });

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5" /> Relatórios de Entregas
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Period shortcuts */}
          <div className="flex flex-wrap gap-2">
            {(Object.keys(SHORTCUT_LABELS) as Shortcut[]).map((key) => (
              <Button
                key={key}
                size="sm"
                variant={shortcut === key ? 'default' : 'outline'}
                onClick={() => setShortcut(key)}
              >
                {SHORTCUT_LABELS[key]}
              </Button>
            ))}
          </div>

          {/* Custom date pickers */}
          {shortcut === 'personalizado' && (
            <div className="flex flex-wrap items-center gap-3">
              <DatePicker label="De" date={customStart} onSelect={setCustomStart} />
              <DatePicker label="Até" date={customEnd} onSelect={setCustomEnd} />
            </div>
          )}

          {/* Period display */}
          <p className="text-sm text-muted-foreground">
            Período: <span className="font-medium text-foreground">{format(periodStart, 'dd/MM/yyyy', { locale: ptBR })}</span>
            {' — '}
            <span className="font-medium text-foreground">{format(periodEnd, 'dd/MM/yyyy', { locale: ptBR })}</span>
          </p>

          {/* Stats */}
          {loading ? (
            <div className="flex items-center gap-2 py-8 justify-center text-muted-foreground">
              <Loader2 className="h-5 w-5 animate-spin" />
            </div>
          ) : stats ? (
            <div className="space-y-6">
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
                <KpiCard icon={<Truck className="h-4 w-4" />} label="Total" value={stats.total} />
                <KpiCard icon={<CheckCircle className="h-4 w-4 text-green-500" />} label="Entregues" value={stats.entregue} />
                <KpiCard icon={<CheckCircle className="h-4 w-4 text-blue-500" />} label="Coletados" value={stats.coletado} />
                <KpiCard icon={<XCircle className="h-4 w-4 text-red-500" />} label="Canceladas" value={stats.cancelada} />
                <KpiCard icon={<RotateCcw className="h-4 w-4 text-yellow-500" />} label="Não Entregues" value={stats.nao_entregue} />
                <KpiCard icon={<RotateCcw className="h-4 w-4" />} label="Reentregas" value={stats.reentrega} />
              </div>

              {Object.keys(stats.byDriver).length > 0 && (
                <div>
                  <h4 className="font-medium mb-2 text-sm">Por Entregador</h4>
                  <div className="flex flex-wrap gap-2">
                    {Object.entries(stats.byDriver)
                      .sort((a, b) => b[1] - a[1])
                      .map(([driver, count]) => (
                        <Badge key={driver} variant="secondary">
                          {driver}: {count}
                        </Badge>
                      ))}
                  </div>
                </div>
              )}

              {(stats.byDriverEntregue?.['CLAUDIO'] ?? 0) > 0 && (
                <div>
                  <h4 className="font-medium mb-2 text-sm">Comissão de Entrega — Claudio (R$ 1,50/entrega)</h4>
                  <div className="border rounded-lg p-3 space-y-1 max-w-sm">
                    <p className="text-sm font-medium">Claudio</p>
                    <div className="flex justify-between text-xs text-muted-foreground">
                      <span>{stats.byDriverEntregue['CLAUDIO']} entregas realizadas</span>
                      <span className="font-bold text-foreground">R$ {(stats.byDriverEntregue['CLAUDIO'] * 1.5).toFixed(2)}</span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <p className="text-muted-foreground text-center py-8">Selecione um período para ver os relatórios.</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function KpiCard({ icon, label, value }: { icon: React.ReactNode; label: string; value: string | number }) {
  return (
    <div className="border rounded-lg p-3 text-center space-y-1">
      <div className="flex items-center justify-center gap-1 text-muted-foreground text-xs">{icon} {label}</div>
      <p className="text-lg font-bold">{value}</p>
    </div>
  );
}

function DatePicker({ label, date, onSelect }: { label: string; date: Date | undefined; onSelect: (d: Date | undefined) => void }) {
  return (
    <div className="flex items-center gap-2">
      <span className="text-sm text-muted-foreground">{label}:</span>
      <Popover>
        <PopoverTrigger asChild>
          <Button
            variant="outline"
            className={cn('w-[160px] justify-start text-left font-normal', !date && 'text-muted-foreground')}
          >
            <CalendarIcon className="h-4 w-4 mr-2" />
            {date ? format(date, 'dd/MM/yyyy', { locale: ptBR }) : 'Selecionar'}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-0" align="start">
          <Calendar
            mode="single"
            selected={date}
            onSelect={onSelect}
            initialFocus
            className={cn('p-3 pointer-events-auto')}
          />
        </PopoverContent>
      </Popover>
    </div>
  );
}
