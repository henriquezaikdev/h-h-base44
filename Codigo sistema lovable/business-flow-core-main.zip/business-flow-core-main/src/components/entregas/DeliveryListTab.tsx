import { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { List, ExternalLink } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { usePeriodFilter } from '@/hooks/usePeriodFilter';
import { PeriodFilter } from '@/components/ui/PeriodFilter';
import { format } from 'date-fns';
import { CollapsibleDataSection, DataSkeleton } from '@/components/ui/CollapsibleDataSection';

const BATCH_SIZE = 10;

const STATUS_OPTIONS = [
  { value: 'all', label: 'Todos Status' },
  { value: 'ENTREGUE', label: 'Entregue' },
  { value: 'COLETADO', label: 'Coletado' },
  { value: 'CANCELADA', label: 'Cancelada' },
];

const STATUS_BADGE_STYLES: Record<string, string> = {
  ENTREGUE: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/30',
  COLETADO: 'bg-accent/20 text-accent-foreground border-accent/30',
  CANCELADA: 'bg-destructive/10 text-destructive border-destructive/30',
};

interface EntregaEO {
  id: string;
  data_baixa: string | null;
  created_at: string;
  destinatario: string | null;
  endereco: string | null;
  controle_pedido: string | null;
  entregador: string | null;
  status: string | null;
  link: string | null;
}

export function DeliveryListTab() {
  const periodFilter = usePeriodFilter('month', 'entregas');
  const [statusFilter, setStatusFilter] = useState('all');
  const [search, setSearch] = useState('');

  const [expanded, setExpanded] = useState(false);
  const [count, setCount] = useState<number | null>(null);
  const [loadingCount, setLoadingCount] = useState(true);
  const [deliveries, setDeliveries] = useState<EntregaEO[]>([]);
  const [loadingData, setLoadingData] = useState(false);
  const [hasMore, setHasMore] = useState(false);

  const applyFilters = useCallback((q: any) => {
    const startStr = periodFilter.startDate;
    const endStr = periodFilter.endDate;
    q = q.or(
      `and(data_baixa.gte.${startStr},data_baixa.lte.${endStr}),and(data_baixa.is.null,created_at.gte.${startStr}T00:00:00,created_at.lte.${endStr}T23:59:59)`
    );
    if (statusFilter !== 'all') q = q.eq('status', statusFilter);
    if (search.trim()) q = q.or(`destinatario.ilike.%${search.trim()}%,controle_pedido.ilike.%${search.trim()}%`);
    return q;
  }, [periodFilter.startDate, periodFilter.endDate, statusFilter, search]);

  useEffect(() => {
    fetchCount();
    setDeliveries([]);
    setExpanded(false);
  }, [periodFilter.startDate, periodFilter.endDate, statusFilter, search]);

  useEffect(() => {
    if (expanded && deliveries.length === 0) loadData(0);
  }, [expanded]);

  async function fetchCount() {
    setLoadingCount(true);
    const q = applyFilters(supabase.from('entregas_eo').select('*', { count: 'exact', head: true }));
    const { count: c } = await q;
    setCount(c || 0);
    setLoadingCount(false);
  }

  async function loadData(offset: number) {
    setLoadingData(true);
    const q = applyFilters(
      supabase.from('entregas_eo')
        .select('id, data_baixa, created_at, destinatario, endereco, controle_pedido, entregador, status, link')
    ).order('data_baixa', { ascending: false, nullsFirst: false }).range(offset, offset + BATCH_SIZE - 1);
    const { data } = await q;
    setDeliveries(prev => offset === 0 ? ((data as EntregaEO[]) || []) : [...prev, ...((data as EntregaEO[]) || [])]);
    setHasMore((data || []).length === BATCH_SIZE);
    setLoadingData(false);
  }

  const getBadgeStyle = (status: string | null) => {
    if (!status) return '';
    return STATUS_BADGE_STYLES[status] || 'bg-muted text-muted-foreground border-border';
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <List className="h-5 w-5" /> Lançamentos de Entregas
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col sm:flex-row sm:flex-wrap items-stretch sm:items-center gap-2 sm:gap-3 mb-4">
          <PeriodFilter filter={periodFilter} />
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-full sm:w-[160px]"><SelectValue /></SelectTrigger>
            <SelectContent>
              {STATUS_OPTIONS.map(o => (
                <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Input
            placeholder="Buscar destinatário ou pedido..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="w-full sm:max-w-[260px]"
          />
        </div>

        <CollapsibleDataSection
          title="Entregas"
          count={count}
          loadingCount={loadingCount}
          expanded={expanded}
          onToggle={() => setExpanded(v => !v)}
          hasMore={hasMore}
          onLoadMore={() => loadData(deliveries.length)}
          loadingMore={loadingData && deliveries.length > 0}
        >
          {loadingData && deliveries.length === 0 ? (
            <DataSkeleton />
          ) : deliveries.length === 0 && !loadingData ? (
            <div className="text-center py-10 text-muted-foreground">
              Nenhuma entrega sincronizada para este período.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full text-sm">
                <thead className="bg-muted">
                  <tr>
                    <th className="px-3 py-2 text-left">Data Baixa</th>
                    <th className="px-3 py-2 text-left">Status</th>
                    <th className="px-3 py-2 text-left">Destinatário</th>
                    <th className="px-3 py-2 text-left">Controle/Pedido</th>
                    <th className="px-3 py-2 text-left">Entregador</th>
                    <th className="px-3 py-2 text-left">Endereço</th>
                    <th className="px-3 py-2 text-left w-10"></th>
                  </tr>
                </thead>
                <tbody>
                  {deliveries.map(d => (
                    <tr key={d.id} className="border-t hover:bg-muted/50">
                      <td className="px-3 py-2 whitespace-nowrap">{d.data_baixa || d.created_at?.split('T')[0] || '-'}</td>
                      <td className="px-3 py-2">
                        <Badge className={getBadgeStyle(d.status)} variant="outline">{d.status || '-'}</Badge>
                      </td>
                      <td className="px-3 py-2 max-w-[200px] truncate">{d.destinatario || '-'}</td>
                      <td className="px-3 py-2">{d.controle_pedido || '-'}</td>
                      <td className="px-3 py-2">{d.entregador || '-'}</td>
                      <td className="px-3 py-2 max-w-[220px] truncate">{d.endereco || '-'}</td>
                      <td className="px-3 py-2">
                        {d.link && (
                          <a href={d.link} target="_blank" rel="noopener noreferrer">
                            <ExternalLink className="h-3.5 w-3.5 text-muted-foreground hover:text-foreground" />
                          </a>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CollapsibleDataSection>
      </CardContent>
    </Card>
  );
}
