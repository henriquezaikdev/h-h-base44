import { useState, useEffect, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { Link2, Search, CheckCircle, Loader2, XCircle } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { fuzzyScore, normalizeForMatch, STATUS_LABELS, STATUS_COLORS } from '@/lib/deliveryUtils';
import { toast } from 'sonner';

interface Delivery {
  id: string;
  external_delivery_id: string;
  recipient_raw: string | null;
  address_raw: string | null;
  status_internal: string;
  delivery_date: string | null;
  driver_raw: string | null;
  batch_id: string;
  client_alias_source_name: string | null;
}

interface ClientOption {
  id: string;
  company_name: string;
  cnpj: string | null;
  seller_id: string | null;
  score: number;
}

export function DeliveryPendingMatchTab() {
  const [batches, setBatches] = useState<{ id: string; file_name: string | null; period_start: string; period_end: string }[]>([]);
  const [selectedBatch, setSelectedBatch] = useState<string>('');
  const [deliveries, setDeliveries] = useState<Delivery[]>([]);
  const [loading, setLoading] = useState(false);

  const [selectedDelivery, setSelectedDelivery] = useState<Delivery | null>(null);
  const [clients, setClients] = useState<ClientOption[]>([]);
  const [clientSearch, setClientSearch] = useState('');
  const [matchLoading, setMatchLoading] = useState(false);

  useEffect(() => {
    supabase
      .from('delivery_import_batches')
      .select('id, file_name, period_start, period_end')
      .in('status', ['draft', 'mapped'])
      .order('created_at', { ascending: false })
      .then(({ data }) => {
        setBatches(data || []);
        if (data && data.length > 0 && !selectedBatch) {
          setSelectedBatch(data[0].id);
        }
      });
  }, []);

  useEffect(() => {
    if (!selectedBatch) return;
    setLoading(true);
    supabase
      .from('deliveries')
      .select('id, external_delivery_id, recipient_raw, address_raw, status_internal, delivery_date, driver_raw, batch_id, client_alias_source_name')
      .eq('batch_id', selectedBatch)
      .eq('client_match_status', 'pending')
      .order('delivery_date', { ascending: true })
      .limit(500)
      .then(({ data }) => {
        setDeliveries(data || []);
        setLoading(false);
      });
  }, [selectedBatch]);

  const openMatchPanel = async (delivery: Delivery) => {
    setSelectedDelivery(delivery);
    setClientSearch('');
    setMatchLoading(true);

    const normalized = normalizeForMatch(delivery.recipient_raw || '');

    // Check learned rules
    const { data: rules } = await supabase
      .from('delivery_client_match_rules')
      .select('client_id, confidence')
      .eq('source_name_normalized', normalized)
      .eq('active', true)
      .limit(1);

    if (rules && rules.length > 0) {
      const { data: client } = await supabase
        .from('clients')
        .select('id, company_name, cnpj, seller_id')
        .eq('id', rules[0].client_id)
        .single();

      if (client) {
        setClients([{ ...client, score: rules[0].confidence }]);
        setMatchLoading(false);
        return;
      }
    }

    // Fuzzy search
    const { data: allClients } = await supabase
      .from('clients')
      .select('id, company_name, cnpj, seller_id')
      .eq('is_deleted', false)
      .limit(3000);

    if (allClients) {
      const scored = allClients
        .map(c => ({
          ...c,
          score: fuzzyScore(delivery.recipient_raw || '', c.company_name),
        }))
        .filter(c => c.score > 0.15)
        .sort((a, b) => b.score - a.score)
        .slice(0, 15);

      setClients(scored);
    }
    setMatchLoading(false);
  };

  const filteredClients = useMemo(() => {
    if (!clientSearch) return clients;
    const q = clientSearch.toLowerCase();
    return clients.filter(c =>
      c.company_name.toLowerCase().includes(q) ||
      (c.cnpj && c.cnpj.includes(q))
    );
  }, [clients, clientSearch]);

  const linkClient = async (clientId: string, clientName: string, sellerId: string | null, score: number) => {
    if (!selectedDelivery) return;

    const { error } = await supabase
      .from('deliveries')
      .update({
        client_id: clientId,
        client_match_status: 'matched',
        client_match_score: score,
        client_owner_user_id: sellerId,
      })
      .eq('id', selectedDelivery.id);

    if (error) {
      toast.error('Erro ao vincular: ' + error.message);
      return;
    }

    // Save match rule
    const normalized = normalizeForMatch(selectedDelivery.recipient_raw || '');
    if (normalized) {
      await supabase.from('delivery_client_match_rules').upsert(
        {
          source_name_normalized: normalized,
          client_id: clientId,
          confidence: 1.0,
          active: true,
        },
        { onConflict: 'source_name_normalized' }
      );
    }

    toast.success(`Vinculado a "${clientName}"`);
    setSelectedDelivery(null);
    setDeliveries(prev => prev.filter(d => d.id !== selectedDelivery.id));
  };

  const rejectDelivery = async (deliveryId: string) => {
    await supabase
      .from('deliveries')
      .update({ client_match_status: 'rejected' })
      .eq('id', deliveryId);

    setDeliveries(prev => prev.filter(d => d.id !== deliveryId));
    toast.info('Entrega marcada como rejeitada');
  };

  const searchMoreClients = async () => {
    if (!clientSearch || clientSearch.length < 2) return;
    setMatchLoading(true);
    const { data } = await supabase
      .from('clients')
      .select('id, company_name, cnpj, seller_id')
      .eq('is_deleted', false)
      .ilike('company_name', `%${clientSearch}%`)
      .limit(20);

    if (data) {
      setClients(data.map(c => ({ ...c, score: 0 })));
    }
    setMatchLoading(false);
  };

  const pendingCount = deliveries.length;

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Link2 className="h-5 w-5" /> Pendentes de Vínculo
            {pendingCount > 0 && <Badge variant="destructive">{pendingCount}</Badge>}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-3 mb-4">
            <span className="shrink-0 text-sm font-medium">Lote:</span>
            <Select value={selectedBatch} onValueChange={setSelectedBatch}>
              <SelectTrigger className="max-w-[400px]">
                <SelectValue placeholder="Selecione um lote" />
              </SelectTrigger>
              <SelectContent>
                {batches.map(b => (
                  <SelectItem key={b.id} value={b.id}>
                    {b.file_name || 'Sem nome'} ({b.period_start} a {b.period_end})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {loading ? (
            <div className="flex items-center gap-2 py-8 justify-center text-muted-foreground">
              <Loader2 className="h-5 w-5 animate-spin" /> Carregando...
            </div>
          ) : deliveries.length === 0 ? (
            <div className="text-center py-8">
              <CheckCircle className="h-10 w-10 text-green-500 mx-auto mb-2" />
              <p className="text-muted-foreground">Nenhuma entrega pendente de vínculo neste lote.</p>
            </div>
          ) : (
            <div className="overflow-x-auto border rounded">
              <table className="min-w-full text-sm">
                <thead className="bg-muted">
                  <tr>
                    <th className="px-3 py-2 text-left">Data</th>
                    <th className="px-3 py-2 text-left">Código</th>
                    <th className="px-3 py-2 text-left">Destinatário (alias)</th>
                    <th className="px-3 py-2 text-left">Endereço</th>
                    <th className="px-3 py-2 text-left">Status</th>
                    <th className="px-3 py-2 text-left">Entregador</th>
                    <th className="px-3 py-2 text-left">Ações</th>
                  </tr>
                </thead>
                <tbody>
                  {deliveries.map(d => (
                    <tr key={d.id} className="border-t hover:bg-muted/50">
                      <td className="px-3 py-2 whitespace-nowrap">{d.delivery_date || '-'}</td>
                      <td className="px-3 py-2 font-mono text-xs">{d.external_delivery_id}</td>
                      <td className="px-3 py-2 max-w-[200px] truncate">{d.client_alias_source_name || d.recipient_raw || '-'}</td>
                      <td className="px-3 py-2 max-w-[200px] truncate">{d.address_raw || '-'}</td>
                      <td className="px-3 py-2">
                        <Badge className={STATUS_COLORS[d.status_internal] || ''} variant="secondary">
                          {STATUS_LABELS[d.status_internal] || d.status_internal}
                        </Badge>
                      </td>
                      <td className="px-3 py-2">{d.driver_raw || '-'}</td>
                      <td className="px-3 py-2">
                        <div className="flex gap-1">
                          <Button size="sm" variant="outline" onClick={() => openMatchPanel(d)}>
                            Vincular
                          </Button>
                          <Button size="sm" variant="ghost" onClick={() => rejectDelivery(d.id)} title="Rejeitar">
                            <XCircle className="h-3.5 w-3.5 text-destructive" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Match Side Panel */}
      <Sheet open={!!selectedDelivery} onOpenChange={(open) => !open && setSelectedDelivery(null)}>
        <SheetContent className="w-full sm:max-w-lg overflow-y-auto">
          <SheetHeader>
            <SheetTitle>Vincular Entrega ao Cliente</SheetTitle>
          </SheetHeader>

          {selectedDelivery && (
            <div className="mt-4 space-y-4">
              <div className="bg-muted rounded p-3 text-sm space-y-1">
                <p><strong>Destinatário:</strong> {selectedDelivery.recipient_raw}</p>
                <p><strong>Endereço:</strong> {selectedDelivery.address_raw}</p>
                <p><strong>Código:</strong> {selectedDelivery.external_delivery_id}</p>
              </div>

              <div className="flex items-center gap-2">
                <Input
                  placeholder="Buscar cliente por nome ou CNPJ..."
                  value={clientSearch}
                  onChange={e => setClientSearch(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && searchMoreClients()}
                />
                <Button size="sm" variant="outline" onClick={searchMoreClients}>
                  <Search className="h-4 w-4" />
                </Button>
              </div>

              {matchLoading ? (
                <div className="flex items-center gap-2 py-4 justify-center text-muted-foreground">
                  <Loader2 className="h-4 w-4 animate-spin" /> Buscando sugestões...
                </div>
              ) : (
                <div className="space-y-2">
                  {filteredClients.length === 0 && (
                    <p className="text-sm text-muted-foreground text-center py-4">
                      Nenhum cliente encontrado. Use a busca acima.
                    </p>
                  )}
                  {filteredClients.map(c => (
                    <div
                      key={c.id}
                      className="flex items-center justify-between border rounded p-3 hover:bg-muted/50 cursor-pointer transition-colors"
                      onClick={() => linkClient(c.id, c.company_name, c.seller_id, c.score)}
                    >
                      <div className="min-w-0">
                        <p className="font-medium text-sm truncate">{c.company_name}</p>
                        {c.cnpj && <p className="text-xs text-muted-foreground">{c.cnpj}</p>}
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        {c.score > 0 && (
                          <Badge
                            variant="outline"
                            className={`text-xs ${c.score >= 0.85 ? 'border-green-500 text-green-700' : c.score >= 0.5 ? 'border-yellow-500 text-yellow-700' : ''}`}
                          >
                            {Math.round(c.score * 100)}%
                          </Badge>
                        )}
                        <CheckCircle className="h-4 w-4 text-green-500" />
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </SheetContent>
      </Sheet>
    </div>
  );
}
