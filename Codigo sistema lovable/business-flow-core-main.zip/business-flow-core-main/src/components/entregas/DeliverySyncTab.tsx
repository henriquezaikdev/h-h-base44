import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Loader2, RefreshCw, Wifi, Clock, CheckCircle, AlertTriangle } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { DeliveryImportTab } from './DeliveryImportTab';
import { FinSyncHistory } from '@/components/shared/FinSyncHistory';

interface Props {
  onImportComplete: () => void;
}

export function DeliverySyncTab({ onImportComplete }: Props) {
  const [syncing, setSyncing] = useState(false);
  const [lastSync, setLastSync] = useState<string | null>(null);
  const [lastResult, setLastResult] = useState<{
    total: number;
    new_records: number;
    updated_records: number;
    already_registered: number;
  } | null>(null);
  const [manualOpen, setManualOpen] = useState(false);
  const [syncRefreshKey, setSyncRefreshKey] = useState(0);

  useEffect(() => {
    fetchLastSync();
  }, []);

  async function fetchLastSync() {
    const { data } = await supabase
      .from('app_config')
      .select('value')
      .eq('key', 'entregador_online_last_sync')
      .maybeSingle();
    if (data?.value) {
      const val = typeof data.value === 'string' ? data.value : JSON.stringify(data.value);
      setLastSync(val.replace(/"/g, ''));
    }
  }

  async function handleSync() {
    setSyncing(true);
    setLastResult(null);
    try {
      const { data, error } = await supabase.functions.invoke('entregador-online-sync');
      if (error) throw error;
      if (data?.error) throw new Error(data.error);

      setLastResult({
        total: data.total,
        new_records: data.new_records,
        updated_records: data.updated_records ?? 0,
        already_registered: data.already_registered,
      });
      setLastSync(data.synced_at);

      if (data.new_records > 0 || data.updated_records > 0) {
        const parts = [];
        if (data.new_records > 0) parts.push(`${data.new_records} novas`);
        if (data.updated_records > 0) parts.push(`${data.updated_records} atualizadas`);
        toast.success(`${parts.join(', ')} entregas sincronizadas`);
        setSyncRefreshKey(k => k + 1);
      }
      if (data.already_registered > 0) {
        toast.warning(`${data.already_registered} entregas já estavam registradas`);
      }
      if (data.new_records === 0 && data.already_registered === 0) {
        toast.info('Nenhuma entrega encontrada no período.');
      }

      onImportComplete();
    } catch (err: any) {
      toast.error(`Erro na sincronização: ${err.message}`);
    } finally {
      setSyncing(false);
    }
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <Wifi className="h-5 w-5 text-primary" />
            Sincronizar com Entregador Online
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-muted-foreground">
            Importa automaticamente as entregas dos últimos 31 dias da API do Entregador Online e vincula aos pedidos pelo código de barras.
          </p>

          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 sm:gap-4">
            <Button onClick={handleSync} disabled={syncing} size="lg" className="w-full sm:w-auto">
              {syncing ? (
                <Loader2 className="animate-spin h-4 w-4 mr-2" />
              ) : (
                <RefreshCw className="h-4 w-4 mr-2" />
              )}
              {syncing ? 'Sincronizando...' : 'Sincronizar Agora'}
            </Button>

            {lastSync && (
              <div className="flex items-center gap-1.5 text-xs sm:text-sm text-muted-foreground">
                <Clock className="h-4 w-4 shrink-0" />
                <span>Última sync: {format(new Date(lastSync), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}</span>
              </div>
            )}
          </div>

          {lastResult && (
            <div className="space-y-2">
              {lastResult.new_records > 0 && (
                <div className="flex items-center gap-3 p-3 rounded-lg bg-green-500/10 border border-green-500/20">
                  <CheckCircle className="h-5 w-5 text-green-600" />
                  <span className="text-sm font-medium text-green-700">
                    {lastResult.new_records} novas entregas sincronizadas
                  </span>
                </div>
              )}
              {lastResult.updated_records > 0 && (
                <div className="flex items-center gap-3 p-3 rounded-lg bg-blue-500/10 border border-blue-500/20">
                  <RefreshCw className="h-5 w-5 text-blue-600" />
                  <span className="text-sm font-medium text-blue-700">
                    {lastResult.updated_records} entregas atualizadas (status)
                  </span>
                </div>
              )}
              {lastResult.already_registered > 0 && (
                <div className="flex items-center gap-3 p-3 rounded-lg bg-yellow-500/10 border border-yellow-500/20">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <span className="text-sm font-medium text-yellow-700">
                    {lastResult.already_registered} entregas já estavam registradas
                  </span>
                </div>
              )}
              {lastResult.new_records === 0 && lastResult.already_registered === 0 && (
                <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50 border border-border/50">
                  <span className="text-sm text-muted-foreground">
                    Nenhuma entrega encontrada no período.
                  </span>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Sync history */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <Clock className="h-5 w-5 text-muted-foreground" />
            Histórico de Sincronizações
          </CardTitle>
        </CardHeader>
        <CardContent>
          <FinSyncHistory modeFilter="entregador_online" refreshKey={syncRefreshKey} />
        </CardContent>
      </Card>

      <Collapsible open={manualOpen} onOpenChange={setManualOpen}>
        <CollapsibleTrigger asChild>
          <Button variant="ghost" size="sm" className="text-muted-foreground gap-2">
            <AlertTriangle className="h-4 w-4" />
            Importação manual (alternativa CSV/XLSX)
          </Button>
        </CollapsibleTrigger>
        <CollapsibleContent className="mt-3">
          <DeliveryImportTab onImportComplete={onImportComplete} />
        </CollapsibleContent>
      </Collapsible>
    </div>
  );
}
