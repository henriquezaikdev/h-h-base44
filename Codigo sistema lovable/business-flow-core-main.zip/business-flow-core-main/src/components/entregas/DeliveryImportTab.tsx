import { useState, useRef, useCallback, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import {
  Upload, FileText, CheckCircle, AlertTriangle, Loader2,
  FileSpreadsheet, File as FileIcon, ChevronDown, XCircle, Clock,
  RefreshCw, Wifi,
} from 'lucide-react';
import { toast } from 'sonner';
import { parseDeliveryFile, ParsedFile } from '@/lib/deliveryFileParser';
import { checkRequiredColumns, validateRows, isImportBlockable, RowValidation } from '@/lib/deliveryValidation';
import {
  mapStatusToInternal, parseBoolFromCsv, parseDateFromCsv, parseTimeFromCsv, buildDeliveredAt,
  PERIOD_TYPE_LABELS, PeriodType, fuzzyScore, normalizeForMatch,
} from '@/lib/deliveryUtils';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';

interface Props {
  onImportComplete: () => void;
}

type Step = 'upload' | 'preview' | 'config' | 'importing' | 'done';

export function DeliveryImportTab({ onImportComplete }: Props) {
  const { user } = useAuth();
  const fileRef = useRef<HTMLInputElement>(null);

  const [step, setStep] = useState<Step>('upload');
  const [parsedFile, setParsedFile] = useState<ParsedFile | null>(null);
  const [fileName, setFileName] = useState('');
  const [colErrors, setColErrors] = useState<string[]>([]);
  const [validRows, setValidRows] = useState<Record<string, string>[]>([]);
  const [invalidRows, setInvalidRows] = useState<RowValidation[]>([]);
  const [blocked, setBlocked] = useState(false);

  // Period config
  const [periodType, setPeriodType] = useState<PeriodType>('monthly');
  const [periodStart, setPeriodStart] = useState('');
  const [periodEnd, setPeriodEnd] = useState('');
  const [kmStart, setKmStart] = useState('');
  const [kmEnd, setKmEnd] = useState('');

  // Progress
  const [progress, setProgress] = useState(0);
  const [processedRows, setProcessedRows] = useState(0);
  const [totalRows, setTotalRows] = useState(0);
  const [elapsedMs, setElapsedMs] = useState(0);
  const [progressMsg, setProgressMsg] = useState('');
  const startTimeRef = useRef(0);
  const timerRef = useRef<ReturnType<typeof setInterval>>();

  const [importResult, setImportResult] = useState<{ batchId: string; count: number; matched: number } | null>(null);

  // ──── Entregador Online Sync ────
  const [syncing, setSyncing] = useState(false);
  const [lastSyncAt, setLastSyncAt] = useState<string | null>(null);
  const [syncResult, setSyncResult] = useState<{ total: number; processed: number; matched: number } | null>(null);

  useEffect(() => {
    supabase
      .from('app_config')
      .select('value')
      .eq('key', 'entregador_online_last_sync')
      .maybeSingle()
      .then(({ data }) => {
        if (data?.value) {
          const val = typeof data.value === 'string' ? data.value : JSON.stringify(data.value);
          setLastSyncAt(val.replace(/"/g, ''));
        }
      });
  }, []);

  const handleSync = useCallback(async () => {
    setSyncing(true);
    setSyncResult(null);
    try {
      const projectId = import.meta.env.VITE_SUPABASE_PROJECT_ID;
      const res = await fetch(
        `https://${projectId}.supabase.co/functions/v1/entregador-online-sync`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
        }
      );
      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || 'Erro na sincronização');
      }
      setSyncResult({ total: data.total, processed: data.processed, matched: data.matched });
      setLastSyncAt(data.synced_at);
      toast.success(`Sincronização concluída: ${data.processed} entregas processadas, ${data.matched} vinculadas a pedidos.`);
      onImportComplete();
    } catch (err: any) {
      toast.error(err.message || 'Erro ao sincronizar com Entregador Online');
    } finally {
      setSyncing(false);
    }
  }, [onImportComplete]);

  // ──── File handling ────
  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setFileName(file.name);
    setColErrors([]);
    setInvalidRows([]);
    setBlocked(false);

    try {
      const parsed = await parseDeliveryFile(file);
      setParsedFile(parsed);

      // Validate columns
      const { valid, missing } = checkRequiredColumns(parsed.columns);
      if (!valid) {
        setColErrors(missing);
        setBlocked(true);
        setStep('preview');
        return;
      }

      // Validate rows
      const seenCodes = new Set<string>();
      const { validRows: vr, invalidRows: ir } = validateRows(parsed.rows, seenCodes);
      setValidRows(vr);
      setInvalidRows(ir);

      if (isImportBlockable(parsed.rows.length, ir.length)) {
        setBlocked(true);
        toast.error(`Importação bloqueada: ${ir.length} de ${parsed.rows.length} linhas inválidas (≥10%)`);
      }

      setStep('preview');
    } catch (err: any) {
      toast.error(err.message || 'Erro ao ler arquivo');
    }
  };

  // ──── XLSX sheet change ────
  const handleSheetChange = async (sheet: string) => {
    if (!fileRef.current?.files?.[0]) return;
    try {
      const parsed = await parseDeliveryFile(fileRef.current.files[0], { xlsxSheet: sheet });
      setParsedFile(parsed);
      const { valid, missing } = checkRequiredColumns(parsed.columns);
      setColErrors(valid ? [] : missing);
      setBlocked(!valid);
      const seenCodes = new Set<string>();
      const { validRows: vr, invalidRows: ir } = validateRows(parsed.rows, seenCodes);
      setValidRows(vr);
      setInvalidRows(ir);
      if (isImportBlockable(parsed.rows.length, ir.length)) setBlocked(true);
    } catch (err: any) {
      toast.error(err.message);
    }
  };

  // ──── Import ────
  const handleImport = useCallback(async () => {
    if (!parsedFile || !periodStart || !periodEnd) {
      toast.error('Preencha o período');
      return;
    }
    if (blocked) {
      toast.error('Importação bloqueada por erros de validação');
      return;
    }

    const rows = validRows;
    setTotalRows(rows.length);
    setProcessedRows(0);
    setProgress(0);
    setProgressMsg('Criando lote...');
    setStep('importing');

    startTimeRef.current = Date.now();
    timerRef.current = setInterval(() => setElapsedMs(Date.now() - startTimeRef.current), 500);

    try {
      // 1. Create batch
      const { data: batch, error: batchErr } = await supabase
        .from('delivery_import_batches')
        .insert({
          imported_by: user?.id || null,
          file_name: fileName,
          file_type: parsedFile.fileType,
          period_type: periodType,
          period_start: periodStart,
          period_end: periodEnd,
          km_start: kmStart ? parseInt(kmStart) : null,
          km_end: kmEnd ? parseInt(kmEnd) : null,
          status: 'draft',
          rows_total: rows.length,
          rows_processed: 0,
          progress_pct: 0,
          started_at: new Date().toISOString(),
        })
        .select('id')
        .single();

      if (batchErr || !batch) throw new Error(batchErr?.message || 'Erro ao criar lote');

      // 2. Load match rules for auto-matching
      const { data: matchRules } = await supabase
        .from('delivery_client_match_rules')
        .select('source_name_normalized, client_id, confidence')
        .eq('active', true);

      const rulesMap = new Map<string, { client_id: string; confidence: number }>();
      for (const r of matchRules || []) {
        rulesMap.set(r.source_name_normalized, { client_id: r.client_id, confidence: r.confidence });
      }

      // 3. Load clients for fuzzy matching
      const { data: allClients } = await supabase
        .from('clients')
        .select('id, company_name, seller_id')
        .eq('is_deleted', false)
        .limit(3000);

      const clientsList = allClients || [];

      // 4. Process in chunks of 200
      const CHUNK = 200;
      let inserted = 0;
      let autoMatched = 0;

      for (let i = 0; i < rows.length; i += CHUNK) {
        const chunk = rows.slice(i, i + CHUNK);
        setProgressMsg(`Processando linhas ${i + 1}-${Math.min(i + CHUNK, rows.length)}...`);

        const deliveries = chunk.map(row => {
          const g = (k: string) => (row[k] || '').trim();
          const dateStr = parseDateFromCsv(g('DataBaixa'));
          const timeStr = parseTimeFromCsv(g('HoraBaixa'));
          const recipientRaw = g('Destinatário') || g('Destinatario') || '';

          // Auto-matching
          let clientId: string | null = null;
          let matchStatus: 'matched' | 'pending' = 'pending';
          let matchScore: number | null = null;
          let ownerUserId: string | null = null;
          let matchRuleId: string | null = null;

          const normalized = normalizeForMatch(recipientRaw);

          // 1st: check learned rules
          const rule = rulesMap.get(normalized);
          if (rule) {
            clientId = rule.client_id;
            matchStatus = 'matched';
            matchScore = rule.confidence;
            const c = clientsList.find(cl => cl.id === clientId);
            ownerUserId = c?.seller_id || null;
          } else if (recipientRaw && clientsList.length > 0) {
            // 2nd: fuzzy match
            let bestScore = 0;
            let bestClient: typeof clientsList[0] | null = null;
            for (const c of clientsList) {
              const s = fuzzyScore(recipientRaw, c.company_name);
              if (s > bestScore) { bestScore = s; bestClient = c; }
            }
            if (bestScore >= 0.85 && bestClient) {
              clientId = bestClient.id;
              matchStatus = 'matched';
              matchScore = bestScore;
              ownerUserId = bestClient.seller_id;
              autoMatched++;
            }
          }

          return {
            batch_id: batch.id,
            external_delivery_id: g('CodEntrega') || `AUTO-${Math.random().toString(36).slice(2, 10)}`,
            service_name: g('Servico') || null,
            delivery_date: dateStr,
            delivery_time: timeStr,
            delivered_at: buildDeliveredAt(dateStr, timeStr),
            status_raw: g('Status') || null,
            status_internal: mapStatusToInternal(g('Status')),
            recipient_raw: recipientRaw || null,
            address_raw: g('Endereco') || g('Endereço') || null,
            order_or_note: g('ControlePedidoNota') || null,
            campo_livre_1: g('CampoLivre1') || null,
            campo_livre_2: g('CampoLivre2') || null,
            observation: g('Observação') || g('Observacao') || null,
            baixa_observation: g('ObservaDeBaixa') || null,
            driver_raw: g('Entregador') || null,
            has_photo: parseBoolFromCsv(g('Foto')),
            has_digital_protocol: parseBoolFromCsv(g('ProtocoloDigital')),
            has_audio: parseBoolFromCsv(g('Audio')),
            km_flag: parseBoolFromCsv(g('KM')),
            raw_payload: row as any,
            client_id: clientId,
            client_match_status: matchStatus,
            client_match_score: matchScore,
            client_alias_source_name: recipientRaw || null,
            client_owner_user_id: ownerUserId,
          };
        });

        const { error } = await supabase.from('deliveries').insert(deliveries);
        if (!error) inserted += deliveries.length;
        else console.error('Chunk error:', error);

        const processed = Math.min(i + CHUNK, rows.length);
        const pct = Math.round((processed / rows.length) * 100);
        setProcessedRows(processed);
        setProgress(pct);

        // Update batch progress
        await supabase.from('delivery_import_batches').update({
          rows_processed: processed,
          progress_pct: pct,
          last_message: `Processando: ${processed}/${rows.length}`,
        }).eq('id', batch.id);
      }

      // Finalize batch
      await supabase.from('delivery_import_batches').update({
        rows_processed: rows.length,
        progress_pct: 100,
        finished_at: new Date().toISOString(),
        last_message: `Concluído: ${inserted} inseridas, ${autoMatched} auto-vinculadas`,
        status: autoMatched > 0 ? 'mapped' : 'draft',
      }).eq('id', batch.id);

      clearInterval(timerRef.current);
      setElapsedMs(Date.now() - startTimeRef.current);
      setImportResult({ batchId: batch.id, count: inserted, matched: autoMatched });
      setStep('done');
      toast.success(`${inserted} entregas importadas! ${autoMatched} vinculadas automaticamente.`);
      onImportComplete();
    } catch (err: any) {
      clearInterval(timerRef.current);
      toast.error(err.message || 'Erro na importação');
      setStep('config');
    }
  }, [parsedFile, validRows, periodStart, periodEnd, blocked, user, fileName, periodType, kmStart, kmEnd, onImportComplete]);

  const resetForm = () => {
    setStep('upload');
    setParsedFile(null);
    setFileName('');
    setColErrors([]);
    setValidRows([]);
    setInvalidRows([]);
    setBlocked(false);
    setPeriodType('monthly');
    setPeriodStart('');
    setPeriodEnd('');
    setKmStart('');
    setKmEnd('');
    setImportResult(null);
    setProgress(0);
    setProcessedRows(0);
    setTotalRows(0);
    setElapsedMs(0);
    setProgressMsg('');
    if (fileRef.current) fileRef.current.value = '';
  };

  const formatTime = (ms: number) => {
    const s = Math.floor(ms / 1000);
    const m = Math.floor(s / 60);
    return m > 0 ? `${m}m ${s % 60}s` : `${s}s`;
  };

  const fileTypeIcon = parsedFile?.fileType === 'xlsx'
    ? <FileSpreadsheet className="h-5 w-5" />
    : parsedFile?.fileType === 'pdf'
    ? <FileIcon className="h-5 w-5" />
    : <FileText className="h-5 w-5" />;

  return (
    <div className="space-y-4">
      {/* Step 1: Upload */}
      {step === 'upload' && (
        <>
          {/* Primary: Entregador Online Sync */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Wifi className="h-5 w-5" /> Sincronizar com Entregador Online
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-muted-foreground">
                Busca automática das entregas dos últimos 31 dias direto da API do Entregador Online. Registros existentes são atualizados.
              </p>

              <div className="flex items-center gap-3">
                <Button onClick={handleSync} disabled={syncing} className="gap-2">
                  {syncing ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
                  {syncing ? 'Sincronizando...' : 'Sincronizar Agora'}
                </Button>
                {lastSyncAt && (
                  <span className="text-xs text-muted-foreground">
                    Última sincronização: {new Date(lastSyncAt).toLocaleString('pt-BR')}
                  </span>
                )}
              </div>

              {syncResult && (
                <div className="flex items-start gap-2 p-3 bg-green-50 dark:bg-green-950/20 rounded border border-green-200 dark:border-green-800">
                  <CheckCircle className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                  <div className="text-sm">
                    <p><strong>{syncResult.total}</strong> entregas encontradas na API</p>
                    <p><strong>{syncResult.processed}</strong> processadas com sucesso</p>
                    <p><strong>{syncResult.matched}</strong> vinculadas automaticamente a pedidos</p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Secondary: Manual CSV/XLSX Import */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <Upload className="h-4 w-4" /> Importação manual (alternativa)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                Selecione CSV, XLSX ou PDF do Entregador Online. Encoding Latin1/UTF-8 e separador (;/,) são detectados automaticamente.
              </p>
              <Input
                ref={fileRef}
                type="file"
                accept=".csv,.txt,.xlsx,.xls,.pdf"
                onChange={handleFileChange}
              />
              <div className="flex gap-2 mt-3">
                <Badge variant="outline">CSV</Badge>
                <Badge variant="outline">XLSX</Badge>
                <Badge variant="outline">PDF (modo assistido)</Badge>
              </div>
            </CardContent>
          </Card>
        </>
      )}

      {/* Step 2: Preview */}
      {(step === 'preview' || step === 'config') && parsedFile && (
        <>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                {fileTypeIcon} Pré-visualização: {fileName}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* File info badges */}
              <div className="flex flex-wrap items-center gap-2">
                <Badge variant="secondary">{parsedFile.rows.length} linhas</Badge>
                <Badge variant="secondary">{parsedFile.columns.length} colunas</Badge>
                <Badge variant="outline">{parsedFile.encoding}</Badge>
                <Badge variant="outline">{parsedFile.fileType.toUpperCase()}</Badge>
                {validRows.length > 0 && (
                  <Badge className="bg-green-100 text-green-800">{validRows.length} válidas</Badge>
                )}
                {invalidRows.length > 0 && (
                  <Badge className="bg-red-100 text-red-800">{invalidRows.length} inválidas</Badge>
                )}
              </div>

              {/* XLSX sheet selector */}
              {parsedFile.sheetNames && parsedFile.sheetNames.length > 1 && (
                <div className="flex items-center gap-2">
                  <Label className="text-sm font-medium shrink-0">Aba:</Label>
                  <Select value={parsedFile.selectedSheet} onValueChange={handleSheetChange}>
                    <SelectTrigger className="max-w-[250px]"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {parsedFile.sheetNames.map(s => (
                        <SelectItem key={s} value={s}>{s}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              {/* Column errors */}
              {colErrors.length > 0 && (
                <div className="flex items-start gap-2 p-3 bg-destructive/10 rounded border border-destructive/20">
                  <XCircle className="h-4 w-4 text-destructive mt-0.5 shrink-0" />
                  <div>
                    <p className="text-sm font-medium text-destructive">Colunas obrigatórias faltando:</p>
                    <p className="text-sm text-destructive/80">{colErrors.join(', ')}</p>
                  </div>
                </div>
              )}

              {/* Invalid rows detail */}
              {invalidRows.length > 0 && (
                <Collapsible>
                  <CollapsibleTrigger asChild>
                    <Button variant="ghost" size="sm" className="gap-1 text-destructive">
                      <AlertTriangle className="h-4 w-4" />
                      {invalidRows.length} linhas com erros
                      <ChevronDown className="h-3 w-3" />
                    </Button>
                  </CollapsibleTrigger>
                  <CollapsibleContent>
                    <div className="max-h-[200px] overflow-y-auto border rounded p-2 mt-1 text-xs space-y-1">
                      {invalidRows.slice(0, 50).map(r => (
                        <div key={r.index} className="flex gap-2">
                          <span className="font-mono text-muted-foreground">L{r.index}:</span>
                          <span className="text-destructive">{r.errors.join(' | ')}</span>
                        </div>
                      ))}
                      {invalidRows.length > 50 && (
                        <p className="text-muted-foreground">...e mais {invalidRows.length - 50} erros</p>
                      )}
                    </div>
                  </CollapsibleContent>
                </Collapsible>
              )}

              {/* Blocked warning */}
              {blocked && (
                <div className="flex items-center gap-2 p-3 bg-destructive/10 rounded border border-destructive/20">
                  <XCircle className="h-4 w-4 text-destructive" />
                  <span className="text-sm text-destructive font-medium">
                    Importação bloqueada. Corrija os erros no arquivo e tente novamente.
                  </span>
                </div>
              )}

              {/* Preview table */}
              <div className="overflow-x-auto max-h-[300px] border rounded">
                <table className="min-w-full text-xs">
                  <thead className="bg-muted sticky top-0">
                    <tr>
                      {parsedFile.columns.slice(0, 10).map(col => (
                        <th key={col} className="px-2 py-1 text-left font-medium">{col}</th>
                      ))}
                      {parsedFile.columns.length > 10 && <th className="px-2 py-1">...</th>}
                    </tr>
                  </thead>
                  <tbody>
                    {parsedFile.rows.slice(0, 20).map((row, i) => (
                      <tr key={i} className="border-t">
                        {parsedFile.columns.slice(0, 10).map(col => (
                          <td key={col} className="px-2 py-1 max-w-[200px] truncate">{row[col]}</td>
                        ))}
                        {parsedFile.columns.length > 10 && <td className="px-2 py-1">...</td>}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {!blocked && step === 'preview' && (
                <Button onClick={() => setStep('config')}>Próximo: Definir Período</Button>
              )}
              {blocked && (
                <Button variant="outline" onClick={resetForm}>Tentar outro arquivo</Button>
              )}
            </CardContent>
          </Card>

          {/* Step 3: Config */}
          {step === 'config' && (
            <Card>
              <CardHeader>
                <CardTitle>Configuração do Período e KM</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <Label className="text-sm font-medium">Tipo de Período</Label>
                    <Select value={periodType} onValueChange={(v) => setPeriodType(v as PeriodType)}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {Object.entries(PERIOD_TYPE_LABELS).map(([k, v]) => (
                          <SelectItem key={k} value={k}>{v}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div />
                  <div>
                    <Label className="text-sm font-medium">Data Início *</Label>
                    <Input type="date" value={periodStart} onChange={e => setPeriodStart(e.target.value)} />
                  </div>
                  <div>
                    <Label className="text-sm font-medium">Data Fim *</Label>
                    <Input type="date" value={periodEnd} onChange={e => setPeriodEnd(e.target.value)} />
                  </div>
                  <div>
                    <Label className="text-sm font-medium">KM Início (opcional)</Label>
                    <Input type="number" value={kmStart} onChange={e => setKmStart(e.target.value)} placeholder="Ex: 45000" />
                  </div>
                  <div>
                    <Label className="text-sm font-medium">KM Fim (opcional)</Label>
                    <Input type="number" value={kmEnd} onChange={e => setKmEnd(e.target.value)} placeholder="Ex: 46200" />
                  </div>
                </div>

                <div className="flex gap-2">
                  <Button variant="outline" onClick={() => setStep('preview')}>Voltar</Button>
                  <Button onClick={handleImport} disabled={!periodStart || !periodEnd || blocked}>
                    Importar e Criar Lote ({validRows.length} linhas)
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </>
      )}

      {/* Step 4: Importing with progress */}
      {step === 'importing' && (
        <Card>
          <CardContent className="py-8 space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold flex items-center gap-2">
                <Loader2 className="h-5 w-5 animate-spin text-primary" />
                Importando...
              </h3>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Clock className="h-4 w-4" />
                {formatTime(elapsedMs)}
              </div>
            </div>

            <Progress value={progress} className="h-3" />

            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">{progressMsg}</span>
              <span className="font-mono font-medium">{processedRows}/{totalRows} ({progress}%)</span>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Step 5: Done */}
      {step === 'done' && importResult && (
        <Card>
          <CardContent className="py-12 flex flex-col items-center gap-4">
            <CheckCircle className="h-12 w-12 text-green-500" />
            <h3 className="text-lg font-semibold">Importação Concluída!</h3>
            <div className="text-sm text-muted-foreground text-center space-y-1">
              <p><strong>{importResult.count}</strong> entregas importadas</p>
              <p><strong>{importResult.matched}</strong> vinculadas automaticamente (≥85% similaridade)</p>
              <p>Tempo total: {formatTime(elapsedMs)}</p>
            </div>
            {importResult.count - importResult.matched > 0 && (
              <p className="text-sm text-muted-foreground">
                Vá em "Pendentes de Vínculo" para vincular as {importResult.count - importResult.matched} entregas restantes.
              </p>
            )}
            <Button onClick={resetForm}>Nova Importação</Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
