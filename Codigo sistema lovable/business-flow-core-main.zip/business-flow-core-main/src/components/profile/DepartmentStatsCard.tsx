import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { format, startOfMonth } from 'date-fns';
import { ClipboardCheck, ShoppingCart, Truck, Package, CheckCircle2, Clock, AlertTriangle } from 'lucide-react';

interface Props {
  sellerId: string;
  department: string | null;
}

export function DepartmentStatsCard({ sellerId, department }: Props) {
  const monthStart = format(startOfMonth(new Date()), 'yyyy-MM-dd');

  const { data: stats } = useQuery({
    queryKey: ['department_stats', sellerId, department, monthStart],
    queryFn: async () => {
      // Tasks stats
      const [completedRes, pendingRes, overdueRes, delegatedRes] = await Promise.all([
        supabase
          .from('tasks')
          .select('id', { count: 'exact', head: true })
          .or(`created_by_seller_id.eq.${sellerId},assigned_to_seller_id.eq.${sellerId}`)
          .eq('status', 'concluida')
          .eq('is_deleted', false)
          .gte('completed_at', monthStart),
        supabase
          .from('tasks')
          .select('id', { count: 'exact', head: true })
          .or(`created_by_seller_id.eq.${sellerId},assigned_to_seller_id.eq.${sellerId}`)
          .eq('status', 'pendente')
          .eq('is_deleted', false),
        supabase
          .from('tasks')
          .select('id', { count: 'exact', head: true })
          .or(`created_by_seller_id.eq.${sellerId},assigned_to_seller_id.eq.${sellerId}`)
          .eq('status', 'pendente')
          .eq('is_deleted', false)
          .lt('task_date', format(new Date(), 'yyyy-MM-dd')),
        supabase
          .from('tasks')
          .select('id', { count: 'exact', head: true })
          .eq('assigned_to_seller_id', sellerId)
          .neq('created_by_seller_id', sellerId)
          .eq('status', 'pendente')
          .eq('is_deleted', false),
      ]);

      let cotacoesCount = 0;
      let comprasCount = 0;

      if (department === 'financeiro_gestora') {
        const [cotRes, compRes] = await Promise.all([
          supabase
            .from('cotacao_itens')
            .select('id', { count: 'exact', head: true })
            .gte('created_at', monthStart),
          supabase
            .from('compras')
            .select('id', { count: 'exact', head: true })
            .gte('created_at', monthStart),
        ]);
        cotacoesCount = cotRes.count || 0;
        comprasCount = compRes.count || 0;
      }

      return {
        completed: completedRes.count || 0,
        pending: pendingRes.count || 0,
        overdue: overdueRes.count || 0,
        delegated: delegatedRes.count || 0,
        cotacoes: cotacoesCount,
        compras: comprasCount,
      };
    },
  });

  if (!stats) return null;

  const isFinanceiro = department === 'financeiro_gestora';
  const isLogistica = department === 'logistica';

  const items = [
    { icon: <CheckCircle2 className="h-5 w-5 text-emerald-500" />, value: stats.completed, label: 'Concluídas (mês)' },
    { icon: <Clock className="h-5 w-5 text-blue-500" />, value: stats.pending, label: 'Pendentes' },
    { icon: <AlertTriangle className="h-5 w-5 text-red-500" />, value: stats.overdue, label: 'Atrasadas' },
    { icon: <ClipboardCheck className="h-5 w-5 text-purple-500" />, value: stats.delegated, label: 'Delegadas p/ mim' },
  ];

  if (isFinanceiro) {
    items.push(
      { icon: <ShoppingCart className="h-5 w-5 text-amber-500" />, value: stats.cotacoes, label: 'Cotações (mês)' },
      { icon: <Package className="h-5 w-5 text-cyan-500" />, value: stats.compras, label: 'Compras (mês)' },
    );
  }

  const deptLabel = isFinanceiro ? 'Financeiro / Gestão' : isLogistica ? 'Logística' : 'Operacional';
  const DeptIcon = isFinanceiro ? ShoppingCart : isLogistica ? Truck : ClipboardCheck;

  return (
    <div className="relative bg-white rounded-2xl border border-gray-200 shadow-sm p-6">
      <p className="text-sm text-gray-500 font-medium mb-4 uppercase tracking-wider flex items-center gap-2">
        <DeptIcon className="h-4 w-4" /> Performance — {deptLabel}
      </p>
      <div className={`grid grid-cols-2 ${items.length > 4 ? 'sm:grid-cols-3' : 'sm:grid-cols-4'} gap-4`}>
        {items.map((item, i) => (
          <div key={i} className="flex flex-col items-center p-3 rounded-xl bg-gray-50">
            <div className="mb-1">{item.icon}</div>
            <p className="text-2xl font-bold text-gray-900">{item.value}</p>
            <p className="text-[10px] text-gray-400 uppercase tracking-widest mt-1 font-medium text-center">{item.label}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
