import React from 'react';

// ===== CURTIDA ICON (Blue-Indigo thumbs up) =====
export function CurtidaIcon({ size = 24, className = '' }: { size?: number; className?: string }) {
  const id = React.useId();
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" fill="none" className={className}>
      <defs>
        <linearGradient id={`curtidaGrad-${id}`} x1="4" y1="4" x2="28" y2="28">
          <stop offset="0%" stopColor="#818CF8" />
          <stop offset="50%" stopColor="#6366F1" />
          <stop offset="100%" stopColor="#4F46E5" />
        </linearGradient>
      </defs>
      <circle cx="16" cy="16" r="14" fill={`url(#curtidaGrad-${id})`} stroke="#4338CA" strokeWidth="1" strokeOpacity="0.3" />
      <circle cx="16" cy="16" r="12" fill="none" stroke="rgba(255,255,255,0.12)" strokeWidth="0.6" />
      <path
        d="M14 22h5.5c.69 0 1.3-.42 1.55-1.05l2.15-5.2c.07-.17.1-.35.1-.55V14c0-.83-.67-1.5-1.5-1.5h-4.34l.65-3.13.02-.21c0-.31-.13-.6-.33-.8L17 8l-4.5 4.5c-.28.28-.5.67-.5 1.1V20.5c0 .83.67 1.5 1.5 1.5h.5zm0-9.5l2.5-2.5-.7 3.5H23v1.2l-2 5.3H14v-7.5zM10 14h2.5v8H10v-8z"
        fill="white"
        fillOpacity="0.95"
      />
      <ellipse cx="12" cy="10" rx="4" ry="1.5" fill="rgba(255,255,255,0.1)" transform="rotate(-15 12 10)" />
    </svg>
  );
}

// ===== HCOIN ICON (Orange/Premium with H) =====
export function HCoinIcon({ size = 24, className = '' }: { size?: number; className?: string }) {
  const id = React.useId();
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" fill="none" className={className}>
      <defs>
        <linearGradient id={`hcoinGrad-${id}`} x1="4" y1="4" x2="28" y2="28">
          <stop offset="0%" stopColor="#FDBA74" />
          <stop offset="35%" stopColor="#FB923C" />
          <stop offset="70%" stopColor="#F97316" />
          <stop offset="100%" stopColor="#EA580C" />
        </linearGradient>
        <radialGradient id={`hcoinGlow-${id}`} cx="0.3" cy="0.3" r="0.7">
          <stop offset="0%" stopColor="rgba(255,255,255,0.25)" />
          <stop offset="100%" stopColor="rgba(255,255,255,0)" />
        </radialGradient>
      </defs>
      <circle cx="16" cy="16" r="14" fill={`url(#hcoinGrad-${id})`} />
      <circle cx="16" cy="16" r="14" fill={`url(#hcoinGlow-${id})`} />
      <circle cx="16" cy="16" r="13" fill="none" stroke="rgba(255,255,255,0.2)" strokeWidth="0.5" />
      <circle cx="16" cy="16" r="11" fill="none" stroke="rgba(255,255,255,0.15)" strokeWidth="0.5" strokeDasharray="1.5 1.5" />
      <text x="16" y="21" textAnchor="middle" fontSize="13" fontWeight="800" fill="rgba(255,255,255,0.95)" fontFamily="system-ui, -apple-system, sans-serif">H</text>
    </svg>
  );
}

// ===== ESTRELA ICON (Polished golden star) =====
export function EstrelaIcon({ size = 24, className = '' }: { size?: number; className?: string }) {
  const id = React.useId();
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" fill="none" className={className}>
      <defs>
        <linearGradient id={`starGrad-${id}`} x1="4" y1="3" x2="28" y2="28">
          <stop offset="0%" stopColor="#FDE68A" />
          <stop offset="30%" stopColor="#FBBF24" />
          <stop offset="70%" stopColor="#F59E0B" />
          <stop offset="100%" stopColor="#D97706" />
        </linearGradient>
        <filter id={`starShadow-${id}`} x="-10%" y="-10%" width="120%" height="120%">
          <feDropShadow dx="0" dy="0.5" stdDeviation="0.5" floodColor="#D97706" floodOpacity="0.3" />
        </filter>
      </defs>
      <path
        d="M16 3l3.7 7.5L28 12l-6 5.8 1.4 8.2L16 22l-7.4 4 1.4-8.2L4 12l8.3-1.5L16 3z"
        fill={`url(#starGrad-${id})`}
        stroke="#B45309"
        strokeWidth="0.6"
        strokeOpacity="0.4"
        filter={`url(#starShadow-${id})`}
      />
      <path
        d="M16 6l2.5 5.2L24 12.5l-4 3.9.95 5.6L16 19.2l-5 2.8.95-5.6-4-3.9 5.5-1.3L16 6z"
        fill="none"
        stroke="rgba(255,255,255,0.25)"
        strokeWidth="0.5"
      />
    </svg>
  );
}
