import { Card, CardContent } from '@/components/ui/card';
import { SellerMonthlyStats } from '@/hooks/useSellerProfile';
import { HCoinIcon, EstrelaIcon, CurtidaIcon } from './CoinIcons';
import { Target, Phone, AlertTriangle, Trophy } from 'lucide-react';
import { motion } from 'framer-motion';

interface ProfileMiniCardsProps {
  curtidasMes: number;
  hcoinsMes: number;
  estrelasMes: number;
  monthlyStats: SellerMonthlyStats | null;
  isComercial: boolean;
  canSeeDetails: boolean;
  lastReconhecimento?: { comentario: string | null; tipo: string } | null;
}

function MiniCard({ icon, value, label, accent }: { icon: React.ReactNode; value: string | number; label: string; accent?: boolean }) {
  return (
    <Card className="bg-white/80 backdrop-blur-sm rounded-[20px] shadow-sm border border-white/60 hover:shadow-md transition-shadow">
      <CardContent className="p-4 text-center">
        <div className="flex justify-center mb-1.5">{icon}</div>
        <p className={`text-xl font-bold ${accent ? 'text-[#FF6A00]' : 'text-[#121216]'}`}>{value}</p>
        <p className="text-[10px] text-[#121216]/45 uppercase tracking-wider mt-1 font-medium">{label}</p>
      </CardContent>
    </Card>
  );
}

export function ProfileMiniCards({
  curtidasMes, hcoinsMes, estrelasMes, monthlyStats, isComercial, canSeeDetails, lastReconhecimento,
}: ProfileMiniCardsProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: 0.1 }}
    >
      {/* Recognition cards */}
      <div className={`grid gap-3 ${isComercial && canSeeDetails ? 'grid-cols-2 sm:grid-cols-3 lg:grid-cols-6' : 'grid-cols-2 sm:grid-cols-3'}`}>
        <MiniCard icon={<CurtidaIcon size={28} />} value={curtidasMes} label="Curtidas" />
        <MiniCard icon={<HCoinIcon size={28} />} value={hcoinsMes} label="HCoins" />
        <MiniCard icon={<EstrelaIcon size={28} />} value={estrelasMes} label="Estrelas" />

        {isComercial && canSeeDetails && monthlyStats && (
          <>
            <MiniCard icon={<Target className="h-7 w-7 text-orange-500" />} value={`${Math.round(monthlyStats.percentualVendas * 100)}%`} label="Meta Vendas" accent />
            <MiniCard icon={<Phone className="h-7 w-7 text-blue-500" />} value={`${monthlyStats.realizadoLigacoes}/${monthlyStats.metaLigacoes}`} label="Ligações" />
            <MiniCard icon={<AlertTriangle className="h-7 w-7 text-red-500" />} value={monthlyStats.errosCriticos} label="Erros" />
          </>
        )}
      </div>

      {/* Score badge for visitors on commercial profiles */}
      {isComercial && !canSeeDetails && monthlyStats && (
        <div className="mt-3">
          <Card className="bg-white/80 backdrop-blur-sm rounded-[20px] shadow-sm border border-white/60">
            <CardContent className="p-4 flex items-center gap-3">
              <Trophy className="h-7 w-7 text-amber-500" />
              <div>
                <p className="text-sm font-medium text-[#121216]">Score do Mês</p>
                <p className="text-2xl font-bold text-[#FF6A00]">{monthlyStats.score}</p>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Last recognition highlight */}
      {lastReconhecimento?.comentario && (
        <Card className="bg-white/80 backdrop-blur-sm rounded-[20px] shadow-sm border border-white/60 mt-3">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              {lastReconhecimento.tipo === 'CURTIDA' && <CurtidaIcon size={22} />}
              {lastReconhecimento.tipo === 'HCOIN' && <HCoinIcon size={22} />}
              {lastReconhecimento.tipo === 'ESTRELA' && <EstrelaIcon size={22} />}
              <div className="flex-1 min-w-0">
                <p className="text-[10px] text-[#121216]/45 uppercase tracking-wider mb-1 font-medium">Último Reconhecimento</p>
                <p className="text-sm text-[#121216]/80 line-clamp-2">{lastReconhecimento.comentario}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </motion.div>
  );
}
