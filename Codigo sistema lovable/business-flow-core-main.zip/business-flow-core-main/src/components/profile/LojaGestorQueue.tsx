import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { HCoinIcon } from './CoinIcons';
import { Check, X, Package, ShoppingBag, Settings, ScrollText, Plus, Pencil, Info, AlertTriangle } from 'lucide-react';
import { toast } from 'sonner';
import { format, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';

// ─── Orders Tab ───
interface QueueOrder {
  id: string;
  user_id: string;
  status: string;
  requested_at: string;
  hcoins_price_snapshot: number;
  notes: string | null;
  item_name: string | null;
  cancel_reason: string | null;
  seller_name: string;
  item_category: string;
}

const STATUS_LABELS: Record<string, { label: string; color: string }> = {
  REQUESTED: { label: 'Pendente', color: 'bg-amber-50 text-amber-700 border-amber-200' },
  APPROVED: { label: 'Aprovado', color: 'bg-blue-50 text-blue-700 border-blue-200' },
  DELIVERED: { label: 'Entregue', color: 'bg-emerald-50 text-emerald-700 border-emerald-200' },
  FULFILLED: { label: 'Entregue', color: 'bg-emerald-50 text-emerald-700 border-emerald-200' },
  REJECTED: { label: 'Rejeitado', color: 'bg-red-50 text-red-700 border-red-200' },
  CANCELED: { label: 'Cancelado', color: 'bg-gray-50 text-gray-700 border-gray-200' },
};

// ─── Main Component ───
export function LojaGestorQueue() {
  const { seller } = useAuth();
  const [activeTab, setActiveTab] = useState('pedidos');

  return (
    <div className="space-y-4">
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="w-full bg-white/70 backdrop-blur-sm rounded-xl p-1 h-auto flex-wrap">
          <TabsTrigger value="pedidos" className="rounded-lg text-xs px-3 py-1.5 data-[state=active]:bg-[#121216] data-[state=active]:text-white">
            <Package className="h-3.5 w-3.5 mr-1" /> Pedidos
          </TabsTrigger>
          <TabsTrigger value="itens" className="rounded-lg text-xs px-3 py-1.5 data-[state=active]:bg-[#121216] data-[state=active]:text-white">
            <ShoppingBag className="h-3.5 w-3.5 mr-1" /> Itens
          </TabsTrigger>
          <TabsTrigger value="regras" className="rounded-lg text-xs px-3 py-1.5 data-[state=active]:bg-[#121216] data-[state=active]:text-white">
            <Settings className="h-3.5 w-3.5 mr-1" /> Regras
          </TabsTrigger>
          <TabsTrigger value="logs" className="rounded-lg text-xs px-3 py-1.5 data-[state=active]:bg-[#121216] data-[state=active]:text-white">
            <ScrollText className="h-3.5 w-3.5 mr-1" /> Logs
          </TabsTrigger>
        </TabsList>

        <TabsContent value="pedidos"><OrdersPanel sellerId={seller?.id} /></TabsContent>
        <TabsContent value="itens"><ItemsPanel sellerId={seller?.id} /></TabsContent>
        <TabsContent value="regras"><RulesPanel /></TabsContent>
        <TabsContent value="logs"><LogsPanel /></TabsContent>
      </Tabs>
    </div>
  );
}

// ─── ORDERS PANEL ───
function OrdersPanel({ sellerId }: { sellerId?: string }) {
  const [orders, setOrders] = useState<QueueOrder[]>([]);
  const [loading, setLoading] = useState(true);
  const [rejectingId, setRejectingId] = useState<string | null>(null);
  const [rejectReason, setRejectReason] = useState('');
  const [processing, setProcessing] = useState<string | null>(null);
  const [filter, setFilter] = useState<'pending' | 'all'>('pending');

  const fetchOrders = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase
      .from('shop_orders')
      .select('id, user_id, status, requested_at, hcoins_price_snapshot, notes, item_name, cancel_reason, sellers!shop_orders_user_id_fkey(name), shop_items(name, category)')
      .order('requested_at', { ascending: false });

    const mapped = (data || []).map((o: any) => ({
      id: o.id,
      user_id: o.user_id,
      status: o.status,
      requested_at: o.requested_at,
      hcoins_price_snapshot: o.hcoins_price_snapshot,
      notes: o.notes,
      item_name: o.item_name || o.shop_items?.name || '?',
      cancel_reason: o.cancel_reason,
      seller_name: o.sellers?.name || '?',
      item_category: o.shop_items?.category || '?',
    }));
    setOrders(mapped);
    setLoading(false);
  }, []);

  useEffect(() => { fetchOrders(); }, [fetchOrders]);

  const handleApprove = async (orderId: string) => {
    if (!sellerId) return;
    setProcessing(orderId);
    try {
      const { error } = await supabase.rpc('fn_shop_approve_v2', { p_order_id: orderId, p_decided_by: sellerId });
      if (error) throw error;
      toast.success('Pedido aprovado — HCoins debitados');
      fetchOrders();
    } catch (err: any) {
      toast.error('Erro ao aprovar: ' + err.message);
    } finally {
      setProcessing(null);
    }
  };

  const handleReject = async (orderId: string) => {
    if (!sellerId || !rejectReason.trim()) { toast.error('Motivo obrigatório'); return; }
    setProcessing(orderId);
    try {
      const { error } = await supabase.rpc('fn_shop_reject_v2', {
        p_order_id: orderId,
        p_decided_by: sellerId,
        p_reason: rejectReason,
      });
      if (error) throw error;
      toast.success('Pedido rejeitado — HCoins devolvidos');
      setRejectingId(null);
      setRejectReason('');
      fetchOrders();
    } catch (err: any) {
      toast.error('Erro: ' + err.message);
    } finally {
      setProcessing(null);
    }
  };

  const handleDeliver = async (orderId: string) => {
    if (!sellerId) return;
    setProcessing(orderId);
    try {
      const { error } = await supabase.rpc('fn_shop_deliver_v2', { p_order_id: orderId, p_decided_by: sellerId });
      if (error) throw error;
      toast.success('Pedido marcado como entregue');
      fetchOrders();
    } catch (err: any) {
      toast.error('Erro: ' + err.message);
    } finally {
      setProcessing(null);
    }
  };

  const filtered = filter === 'pending'
    ? orders.filter(o => ['REQUESTED', 'APPROVED'].includes(o.status))
    : orders;

  if (loading) return <div className="py-8 text-center text-[#121216]/40">Carregando...</div>;

  return (
    <div className="space-y-3 mt-3">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold text-[#121216]">Solicitações</h3>
        <div className="flex gap-1">
          <Button variant={filter === 'pending' ? 'default' : 'outline'} size="sm" onClick={() => setFilter('pending')} className="rounded-xl text-xs h-7">
            Pendentes
          </Button>
          <Button variant={filter === 'all' ? 'default' : 'outline'} size="sm" onClick={() => setFilter('all')} className="rounded-xl text-xs h-7">
            Todas
          </Button>
        </div>
      </div>

      {filtered.length === 0 ? (
        <p className="text-sm text-[#121216]/40 text-center py-8">Nenhuma solicitação {filter === 'pending' ? 'pendente' : ''}</p>
      ) : (
        <div className="space-y-2">
          {filtered.map(order => {
            const stCfg = STATUS_LABELS[order.status] || STATUS_LABELS.REQUESTED;
            return (
              <Card key={order.id} className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-sm border border-white/60">
                <CardContent className="p-4 space-y-2">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-[#121216]">{order.seller_name}</p>
                      <p className="text-xs text-[#121216]/60">{order.item_name}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="flex items-center gap-1 text-xs text-[#FF6A00]">
                          <HCoinIcon size={12} /> {order.hcoins_price_snapshot}
                        </span>
                        <span className="text-[10px] text-[#121216]/40">
                          {format(parseISO(order.requested_at), "dd/MM/yy HH:mm", { locale: ptBR })}
                        </span>
                      </div>
                    </div>
                    <Badge variant="outline" className={`text-xs ${stCfg.color}`}>{stCfg.label}</Badge>
                  </div>

                  {order.cancel_reason && <p className="text-[10px] text-red-500 italic">Motivo: {order.cancel_reason}</p>}

                  {order.status === 'REQUESTED' && (
                    <div className="flex items-center gap-2 pt-1 border-t border-[#F4F4F4]">
                      <Button size="sm" disabled={processing === order.id} onClick={() => handleApprove(order.id)} className="rounded-xl text-xs bg-emerald-600 hover:bg-emerald-700 text-white h-7">
                        <Check className="h-3 w-3 mr-1" /> Aprovar
                      </Button>
                      {rejectingId === order.id ? (
                        <div className="flex-1 flex items-center gap-2">
                          <Textarea value={rejectReason} onChange={e => setRejectReason(e.target.value)} placeholder="Motivo da rejeição..." rows={1} className="rounded-xl text-xs flex-1" />
                          <Button size="sm" disabled={processing === order.id || !rejectReason.trim()} onClick={() => handleReject(order.id)} className="rounded-xl text-xs bg-red-600 hover:bg-red-700 text-white h-7">
                            Confirmar
                          </Button>
                        </div>
                      ) : (
                        <Button size="sm" variant="outline" onClick={() => setRejectingId(order.id)} className="rounded-xl text-xs text-red-600 border-red-200 h-7">
                          <X className="h-3 w-3 mr-1" /> Rejeitar
                        </Button>
                      )}
                    </div>
                  )}
                  {order.status === 'APPROVED' && (
                    <div className="pt-1 border-t border-[#F4F4F4]">
                      <Button size="sm" disabled={processing === order.id} onClick={() => handleDeliver(order.id)} className="rounded-xl text-xs bg-[#FF6A00] hover:bg-[#FF6A00]/90 text-white h-7">
                        <Package className="h-3 w-3 mr-1" /> Marcar Entregue
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ─── ITEMS PANEL (CRUD) ───
function ItemsPanel({ sellerId }: { sellerId?: string }) {
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingItem, setEditingItem] = useState<any | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [saving, setSaving] = useState(false);

  const [form, setForm] = useState({
    name: '', description: '', category: 'TEMPO', hcoins_price: 10,
    cooldown_days: 30, monthly_limit_per_user: 0, is_active: true,
    rules: '', requires_approval: true, sort_order: 10, sku: '',
  });

  const fetchItems = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase.from('shop_items').select('*').order('sort_order');
    setItems(data || []);
    setLoading(false);
  }, []);

  useEffect(() => { fetchItems(); }, [fetchItems]);

  const resetForm = () => {
    setForm({ name: '', description: '', category: 'TEMPO', hcoins_price: 10, cooldown_days: 30, monthly_limit_per_user: 0, is_active: true, rules: '', requires_approval: true, sort_order: 10, sku: '' });
    setEditingItem(null);
    setShowForm(false);
  };

  const startEdit = (item: any) => {
    setForm({
      name: item.name, description: item.description || '', category: item.category,
      hcoins_price: item.hcoins_price, cooldown_days: item.cooldown_days,
      monthly_limit_per_user: item.monthly_limit_per_user, is_active: item.is_active,
      rules: item.rules || '', requires_approval: item.requires_approval,
      sort_order: item.sort_order, sku: item.sku || '',
    });
    setEditingItem(item);
    setShowForm(true);
  };

  const handleSave = async () => {
    if (!form.name.trim()) { toast.error('Nome obrigatório'); return; }
    setSaving(true);
    try {
      const payload = {
        ...form,
        description: form.description || null,
        rules: form.rules || null,
        sku: form.sku || null,
        updated_by: sellerId,
        updated_at: new Date().toISOString(),
      };

      if (editingItem) {
        const { error } = await supabase.from('shop_items').update(payload).eq('id', editingItem.id);
        if (error) throw error;
        toast.success('Item atualizado');
      } else {
        const { error } = await supabase.from('shop_items').insert({ ...payload, created_by: sellerId });
        if (error) throw error;
        toast.success('Item criado');
      }
      resetForm();
      fetchItems();
    } catch (err: any) {
      toast.error('Erro: ' + err.message);
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <div className="py-8 text-center text-[#121216]/40">Carregando...</div>;

  return (
    <div className="space-y-3 mt-3">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold text-[#121216]">Itens da Loja</h3>
        <Button size="sm" onClick={() => { resetForm(); setShowForm(true); }} className="rounded-xl text-xs h-7 bg-[#FF6A00] hover:bg-[#FF6A00]/90 text-white">
          <Plus className="h-3 w-3 mr-1" /> Novo Item
        </Button>
      </div>

      {showForm && (
        <Card className="bg-white/90 rounded-2xl shadow-sm border border-[#FF6A00]/20">
          <CardContent className="p-4 space-y-3">
            <h4 className="text-xs font-semibold text-[#121216]">{editingItem ? 'Editar Item' : 'Novo Item'}</h4>
            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2">
                <Label className="text-xs">Nome</Label>
                <Input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} className="rounded-xl text-xs h-8" />
              </div>
              <div className="col-span-2">
                <Label className="text-xs">Descrição</Label>
                <Textarea value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} rows={2} className="rounded-xl text-xs" />
              </div>
              <div>
                <Label className="text-xs">Categoria</Label>
                <Select value={form.category} onValueChange={v => setForm(f => ({ ...f, category: v }))}>
                  <SelectTrigger className="rounded-xl text-xs h-8"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="TEMPO">Tempo</SelectItem>
                    <SelectItem value="FINANCEIRO">Financeiro</SelectItem>
                    <SelectItem value="ESTRATEGICO">Estratégico</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs">SKU</Label>
                <Input value={form.sku} onChange={e => setForm(f => ({ ...f, sku: e.target.value }))} className="rounded-xl text-xs h-8" placeholder="Ex: TIME_1H" />
              </div>
              <div>
                <Label className="text-xs">Preço (HCoins)</Label>
                <Input type="number" value={form.hcoins_price} onChange={e => setForm(f => ({ ...f, hcoins_price: +e.target.value }))} className="rounded-xl text-xs h-8" />
              </div>
              <div>
                <Label className="text-xs">Cooldown (dias)</Label>
                <Input type="number" value={form.cooldown_days} onChange={e => setForm(f => ({ ...f, cooldown_days: +e.target.value }))} className="rounded-xl text-xs h-8" />
              </div>
              <div>
                <Label className="text-xs">Limite mensal (0=sem)</Label>
                <Input type="number" value={form.monthly_limit_per_user} onChange={e => setForm(f => ({ ...f, monthly_limit_per_user: +e.target.value }))} className="rounded-xl text-xs h-8" />
              </div>
              <div>
                <Label className="text-xs">Ordem</Label>
                <Input type="number" value={form.sort_order} onChange={e => setForm(f => ({ ...f, sort_order: +e.target.value }))} className="rounded-xl text-xs h-8" />
              </div>
              <div className="col-span-2">
                <Label className="text-xs">Regras/Observações</Label>
                <Textarea value={form.rules} onChange={e => setForm(f => ({ ...f, rules: e.target.value }))} rows={2} className="rounded-xl text-xs" />
              </div>
              <div className="flex items-center gap-3">
                <Switch checked={form.is_active} onCheckedChange={v => setForm(f => ({ ...f, is_active: v }))} />
                <Label className="text-xs">Ativo</Label>
              </div>
              <div className="flex items-center gap-3">
                <Switch checked={form.requires_approval} onCheckedChange={v => setForm(f => ({ ...f, requires_approval: v }))} />
                <Label className="text-xs">Requer aprovação</Label>
              </div>
            </div>
            <div className="flex gap-2 pt-2">
              <Button size="sm" onClick={handleSave} disabled={saving} className="rounded-xl text-xs bg-[#FF6A00] hover:bg-[#FF6A00]/90 text-white">
                {saving ? '...' : editingItem ? 'Salvar' : 'Criar'}
              </Button>
              <Button size="sm" variant="outline" onClick={resetForm} className="rounded-xl text-xs">Cancelar</Button>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="space-y-2">
        {items.map(item => (
          <Card key={item.id} className={`bg-white/80 backdrop-blur-sm rounded-2xl shadow-sm border ${item.is_active ? 'border-white/60' : 'border-red-200 opacity-60'}`}>
            <CardContent className="p-3 flex items-center gap-3">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <p className="text-sm font-medium text-[#121216] truncate">{item.name}</p>
                  {!item.is_active && <Badge variant="outline" className="text-[10px] border-red-200 text-red-500">Inativo</Badge>}
                </div>
                <div className="flex items-center gap-2 mt-0.5">
                  <span className="flex items-center gap-1 text-xs text-[#FF6A00]"><HCoinIcon size={12} /> {item.hcoins_price}</span>
                  <span className="text-[10px] text-[#121216]/35">{item.category} · CD:{item.cooldown_days}d · Lim:{item.monthly_limit_per_user}/mês</span>
                </div>
              </div>
              <Button size="sm" variant="ghost" onClick={() => startEdit(item)} className="rounded-xl h-7 w-7 p-0">
                <Pencil className="h-3.5 w-3.5" />
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}

// ─── RULES PANEL ───
function RulesPanel() {
  const [rules, setRules] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    supabase.from('shop_rules').select('*').limit(1).maybeSingle().then(({ data }) => {
      setRules(data || {});
      setLoading(false);
    });
  }, []);

  const handleSave = async () => {
    if (!rules?.id) return;
    setSaving(true);
    const { error } = await supabase.from('shop_rules').update({
      transfer_hcoins_max_sent_month: rules.transfer_hcoins_max_sent_month,
      transfer_hcoins_max_recv_month: rules.transfer_hcoins_max_recv_month,
      transfer_block_size: rules.transfer_block_size,
      allow_hcoins_transfer: rules.allow_hcoins_transfer,
      allow_xp_transfer: rules.allow_xp_transfer,
      updated_at: new Date().toISOString(),
    }).eq('id', rules.id);
    if (error) toast.error('Erro: ' + error.message);
    else toast.success('Regras atualizadas');
    setSaving(false);
  };

  if (loading) return <div className="py-8 text-center text-[#121216]/40">Carregando...</div>;

  return (
    <Card className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-sm border border-white/60 mt-3">
      <CardContent className="p-4 space-y-4">
        <h3 className="text-sm font-semibold text-[#121216] flex items-center gap-2">
          <Settings className="h-4 w-4 text-[#FF6A00]" /> Regras Globais da Loja
        </h3>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label className="text-xs">Max HCoins enviados/mês</Label>
            <Input type="number" value={rules?.transfer_hcoins_max_sent_month || 0}
              onChange={e => setRules((r: any) => ({ ...r, transfer_hcoins_max_sent_month: +e.target.value }))}
              className="rounded-xl text-xs h-8" />
          </div>
          <div>
            <Label className="text-xs">Max HCoins recebidos/mês</Label>
            <Input type="number" value={rules?.transfer_hcoins_max_recv_month || 0}
              onChange={e => setRules((r: any) => ({ ...r, transfer_hcoins_max_recv_month: +e.target.value }))}
              className="rounded-xl text-xs h-8" />
          </div>
          <div>
            <Label className="text-xs">Bloco de transferência</Label>
            <Input type="number" value={rules?.transfer_block_size || 5}
              onChange={e => setRules((r: any) => ({ ...r, transfer_block_size: +e.target.value }))}
              className="rounded-xl text-xs h-8" />
          </div>
          <div className="flex items-center gap-3 pt-4">
            <Switch checked={rules?.allow_hcoins_transfer ?? true}
              onCheckedChange={v => setRules((r: any) => ({ ...r, allow_hcoins_transfer: v }))} />
            <Label className="text-xs">Permitir transferência HCoins</Label>
          </div>
          <div className="flex items-center gap-3">
            <Switch checked={rules?.allow_xp_transfer ?? true}
              onCheckedChange={v => setRules((r: any) => ({ ...r, allow_xp_transfer: v }))} />
            <Label className="text-xs">Permitir transferência XP</Label>
          </div>
        </div>
        <Button size="sm" onClick={handleSave} disabled={saving} className="rounded-xl text-xs bg-[#FF6A00] hover:bg-[#FF6A00]/90 text-white">
          {saving ? '...' : 'Salvar Regras'}
        </Button>
      </CardContent>
    </Card>
  );
}

// ─── LOGS PANEL ───
function LogsPanel() {
  const [logs, setLogs] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    supabase.from('hcoins_log')
      .select('*, sellers!hcoins_log_user_id_fkey(name)')
      .order('created_at', { ascending: false })
      .limit(100)
      .then(({ data }) => {
        setLogs((data || []).map((l: any) => ({
          ...l,
          user_name: l.sellers?.name || '?',
        })));
        setLoading(false);
      });
  }, []);

  if (loading) return <div className="py-8 text-center text-[#121216]/40">Carregando...</div>;

  const EVENT_LABELS: Record<string, string> = {
    SHOP_RESERVE: 'Reserva (Loja)',
    SHOP_DEBIT_FINAL: 'Débito Final',
    SHOP_RELEASE: 'Estorno (Rejeição)',
    SHOP_PURCHASE: 'Compra (Loja)',
    RECOG_HCOIN_TRANSFER_OUT: 'Transferência (saída)',
    RECOG_HCOIN_TRANSFER_IN: 'Transferência (entrada)',
    XP_CONVERSION: 'Conversão de XP',
    ADJUST_ADMIN: 'Ajuste Admin',
  };

  return (
    <div className="space-y-2 mt-3">
      <h3 className="text-sm font-semibold text-[#121216] flex items-center gap-2">
        <ScrollText className="h-4 w-4 text-[#FF6A00]" /> Logs de HCoins (somente leitura)
      </h3>
      {logs.length === 0 ? (
        <p className="text-sm text-[#121216]/40 text-center py-8">Nenhum log encontrado</p>
      ) : (
        logs.map(log => (
          <Card key={log.id} className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-sm border border-white/60">
            <CardContent className="p-3 flex items-center gap-3">
              <div className="flex-1 min-w-0">
                <p className="text-xs font-medium text-[#121216]">{log.user_name}</p>
                <p className="text-[10px] text-[#121216]/50">
                  {EVENT_LABELS[log.event_type] || log.event_type}
                </p>
              </div>
              <div className="text-right">
                <p className={`text-sm font-bold ${log.hcoins_delta >= 0 ? 'text-emerald-600' : 'text-red-500'}`}>
                  {log.hcoins_delta >= 0 ? '+' : ''}{log.hcoins_delta}
                </p>
                <p className="text-[10px] text-[#121216]/40">
                  {format(parseISO(log.created_at), "dd/MM HH:mm", { locale: ptBR })}
                </p>
              </div>
            </CardContent>
          </Card>
        ))
      )}
    </div>
  );
}
