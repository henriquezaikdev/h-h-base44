import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Star, History, Medal, Gem } from 'lucide-react';
import { EstrelaIcon } from './CoinIcons';
import { format, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { motion } from 'framer-motion';

const STAR_ICON: Record<string, React.ReactNode> = {
  BRONZE: <Medal className="h-5 w-5 text-amber-700" />,
  PRATA: <Medal className="h-5 w-5 text-gray-400" />,
  OURO: <Medal className="h-5 w-5 text-yellow-500" />,
  CRISTAL: <Gem className="h-5 w-5 text-purple-500" />,
};

const REASON_LABELS: Record<string, string> = {
  MARGEM_ACIMA_MEDIA: 'Margem acima da média',
  VENDA_ESTRATEGICA: 'Venda estratégica',
  EXCELENCIA_ATENDIMENTO: 'Excelência no atendimento',
  EXCELENCIA_OPERACIONAL: 'Excelência operacional',
  ORGANIZACAO_EXEMPLAR: 'Organização exemplar',
  INICIATIVA_ESTRATEGICA: 'Iniciativa estratégica',
  LIDERANCA_APOIO_EQUIPE: 'Liderança / Apoio à equipe',
  RESOLVEU_PEPINO: 'Resolveu um pepino',
  CONVERSAO_AUTOMATICA: 'Conversão automática',
  OUTRO: 'Outro',
};

interface EstrelasProfileTabProps {
  sellerId: string;
}

export function EstrelasProfileTab({ sellerId }: EstrelasProfileTabProps) {
  const [balance, setBalance] = useState<any>(null);
  const [ledger, setLedger] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetch = async () => {
      const [balRes, ledgerRes] = await Promise.all([
        supabase.from('seller_stars').select('*').eq('seller_id', sellerId).maybeSingle(),
        supabase.from('star_ledger').select('*, grantor:sellers!star_ledger_granted_by_user_id_fkey(name)')
          .eq('to_user_id', sellerId)
          .order('created_at', { ascending: false })
          .limit(30),
      ]);
      const stars = balRes.data;
      setBalance({
        bronze_count: stars?.bronze_stars || 0,
        silver_count: stars?.silver_stars || 0,
        gold_count: stars?.gold_stars || 0,
        crystal_count: 0,
      });
      setLedger(ledgerRes.data || []);
      setLoading(false);
    };
    fetch();
  }, [sellerId]);

  if (loading) return <div className="py-8 text-center text-[#121216]/40 animate-pulse">Carregando estrelas...</div>;

  const b = balance || { bronze_count: 0, silver_count: 0, gold_count: 0, crystal_count: 0 };

  return (
    <div className="mt-4 space-y-4">
      {/* Balance cards with progress */}
      <Card className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-sm border border-white/60">
        <CardHeader className="pb-2">
          <CardTitle className="text-base text-[#121216] flex items-center gap-2">
            <Star className="h-4 w-4 text-[#FF6A00]" /> Minhas Estrelas
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <StarCard icon={<Medal className="h-8 w-8 text-amber-700" />} label="Bronze" count={b.bronze_count} nextAt={5} nextLabel="→ 1 Prata" />
            <StarCard icon={<Medal className="h-8 w-8 text-gray-400" />} label="Prata" count={b.silver_count} nextAt={5} nextLabel="→ 1 Ouro" />
            <StarCard icon={<Medal className="h-8 w-8 text-yellow-500" />} label="Ouro" count={b.gold_count} nextAt={5} nextLabel="→ 1 Cristal" />
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="text-center p-4 rounded-xl bg-gradient-to-br from-purple-50 to-violet-50 border border-purple-100"
            >
              <Gem className="h-8 w-8 text-purple-500" />
              <p className="text-2xl font-bold text-[#121216] mt-1">{b.crystal_count}</p>
              <p className="text-xs text-[#121216]/50">Cristal</p>
              {b.crystal_count > 0 && (
                <p className="text-[10px] text-purple-600 mt-1 font-medium">
                  R$ {(b.crystal_count * 1000).toLocaleString('pt-BR')} em prêmios
                </p>
              )}
            </motion.div>
          </div>

          {/* Conversion rules */}
          <div className="text-center text-xs text-[#121216]/40 pt-2 border-t border-[#F4F4F4]">
            5 Bronze = 1 Prata · 5 Prata = 1 Ouro · 5 Ouro = 1 Cristal (R$ 1.000)
          </div>
        </CardContent>
      </Card>

      {/* Ledger history */}
      <Card className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-sm border border-white/60">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm text-[#121216]/60 flex items-center gap-2">
            <History className="h-4 w-4" /> Histórico de Estrelas
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {ledger.length === 0 ? (
            <p className="text-sm text-[#121216]/40 text-center py-6">Nenhuma estrela ainda</p>
          ) : (
            <div className="divide-y divide-[#F4F4F4]">
              {ledger.map(entry => (
                <div key={entry.id} className="px-4 py-3 flex items-start gap-3">
                  <span className="flex-shrink-0">{STAR_ICON[entry.star_type] || <Star className="h-5 w-5 text-amber-500" />}</span>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium text-[#121216]">
                        {entry.star_type} ×{entry.quantity}
                      </span>
                      {entry.reason_code === 'CONVERSAO_AUTOMATICA' && (
                        <Badge variant="outline" className="text-[10px] rounded-lg bg-blue-50 text-blue-600 border-blue-200">
                          Conversão
                        </Badge>
                      )}
                    </div>
                    <p className="text-xs text-[#121216]/50 mt-0.5">
                      {REASON_LABELS[entry.reason_code] || entry.reason_code}
                      {entry.grantor?.name && ` · por ${entry.grantor.name}`}
                    </p>
                    {entry.comment && <p className="text-xs text-[#121216]/60 mt-1 italic">{entry.comment}</p>}
                  </div>
                  <span className="text-xs text-[#121216]/40 whitespace-nowrap">
                    {format(parseISO(entry.created_at), 'dd/MM/yy', { locale: ptBR })}
                  </span>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function StarCard({ icon, label, count, nextAt, nextLabel }: {
  icon: React.ReactNode; label: string; count: number; nextAt: number; nextLabel: string;
}) {
  const pct = Math.min((count / nextAt) * 100, 100);
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      className="text-center p-4 rounded-xl bg-[#F4F4F4]/50 border border-[#F4F4F4]"
    >
      <div className="flex justify-center">{icon}</div>
      <p className="text-2xl font-bold text-[#121216] mt-1">{count}</p>
      <p className="text-xs text-[#121216]/50">{label}</p>
      <div className="mt-2">
        <Progress value={pct} className="h-1.5" />
        <p className="text-[10px] text-[#121216]/40 mt-1">{count}/{nextAt} {nextLabel}</p>
      </div>
    </motion.div>
  );
}
