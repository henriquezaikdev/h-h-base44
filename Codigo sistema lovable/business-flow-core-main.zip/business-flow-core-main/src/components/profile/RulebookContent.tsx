import { Zap, Star, ShoppingBag, Heart, Award, Diamond, AlertTriangle, Users, BookOpen } from 'lucide-react';
import { HCoinIcon, EstrelaIcon } from './CoinIcons';

/** Static rulebook content — the "encyclopedia" of system rules */
export function RulebookContent() {
  return (
    <div className="space-y-8 text-sm text-[#121216]/80 leading-relaxed">
      {/* 4.1 Visão Geral */}
      <Section icon={<BookOpen className="h-4 w-4 text-[#FF6A00]" />} title="Visão Geral">
        <ul className="list-disc list-inside space-y-1">
          <li><strong>XP:</strong> pontuação de comportamento e produtividade (automático pelo sistema)</li>
          <li><strong>HCoins:</strong> moeda interna, convertida automaticamente a partir de XP</li>
          <li><strong>Loja H&H:</strong> resgate de benefícios usando HCoins (controlado e com aprovação)</li>
          <li><strong>Reconhecimento:</strong> cultura entre colegas — com ou sem transferência de XP/HCoins</li>
          <li><strong>Estrelas:</strong> reputação institucional (concedida manualmente pelo gestor)</li>
          <li><strong>Cristal (💎):</strong> conquista máxima — prêmio de R$ 1.000</li>
        </ul>
      </Section>

      {/* 4.2 XP — Como ganha */}
      <Section icon={<Zap className="h-4 w-4 text-[#FF6A00]" />} title="XP — Como Ganha">
        <ul className="list-disc list-inside space-y-1">
          <li><strong>Tarefas:</strong> só dão XP se concluídas no prazo e com resultado válido</li>
          <li><strong>Venda vinculada:</strong> XP atribuído apenas se houver pedido real em até 7 dias</li>
          <li><strong>Contatos:</strong> XP só pela meta mensal atingida (não por contato individual)</li>
          <li><strong>Meta comercial:</strong> XP ao bater a meta do mês</li>
          <li><strong>Cadastro completo:</strong> XP por cadastro ativo com comprador + aniversário preenchidos</li>
          <li><strong>Ranking mensal:</strong> bônus de XP para o top 3 (se estiver ativo no mês)</li>
        </ul>
      </Section>

      {/* 4.3 XP — Como perde */}
      <Section icon={<AlertTriangle className="h-4 w-4 text-red-500" />} title="XP — Como Perde">
        <ul className="list-disc list-inside space-y-1">
          <li>Tarefa vencida por faixas: 4–15 dias, 15–30 dias, {'>'}30 dias (penalidade crescente)</li>
          <li>Cliente ativo com cadastro incompleto (sem comprador/aniversário) — teto mensal</li>
          <li>O XP do mês nunca fica negativo (piso 0)</li>
        </ul>
      </Section>

      {/* 4.4 HCoins */}
      <Section icon={<HCoinIcon size={18} />} title="HCoins — Conversão e Limites">
        <ul className="list-disc list-inside space-y-1">
          <li>Conversão mensal automática: <strong>1000 XP = 1 HCoin</strong></li>
          <li>Teto mensal de conversão: <strong>40 HCoins</strong></li>
          <li>Gestor não aparece em ranking e não exibe saldo publicamente</li>
        </ul>
      </Section>

      {/* 4.5 Loja */}
      <Section icon={<ShoppingBag className="h-4 w-4 text-[#FF6A00]" />} title="Loja H&H — Como Funciona">
        <ul className="list-disc list-inside space-y-1">
          <li>Acesse via Perfil → aba Loja</li>
          <li>Itens possuem preço em HCoins, cooldown e limite de estoque</li>
          <li>Alguns itens exigem aprovação do gestor antes da entrega</li>
          <li><strong>Resgate bloqueado</strong> para quem não aceitou o Regulamento vigente</li>
        </ul>
      </Section>

      {/* 4.6 Reconhecimento */}
      <Section icon={<Heart className="h-4 w-4 text-pink-500" />} title="Reconhecimento — Tipos e Regras">
        <ul className="list-disc list-inside space-y-1">
          <li><strong>Simples:</strong> sem transferência — gera +1 XP simbólico para quem recebe</li>
          <li><strong>Com transferência:</strong> transfere XP e/ou HCoins (sai do saldo do emissor)</li>
          <li>Limite mensal de envio: 50 XP e 30 HCoins; máximo 20 XP e 20 HCoins por destinatário</li>
          <li>Mínimo por transferência: 1 (quantidade livre)</li>
          <li>Proibido reconhecer a si mesmo</li>
          <li>No feed público, o motivo e contexto são exibidos, mas <strong>quantidades não</strong></li>
        </ul>
      </Section>

      {/* 4.7 Estrelas */}
      <Section icon={<EstrelaIcon size={18} />} title="Estrelas — Manual Completo">
        <p className="mb-2">
          Estrelas representam <strong>reputação institucional</strong>. São permanentes — nunca são perdidas, compradas ou transferidas.
        </p>

        <h4 className="font-semibold text-[#121216] mt-3 mb-1.5">⭐ Como ganhar Estrelas</h4>

        <p className="font-medium mt-2 mb-1">1. Concessão manual pelo Gestor</p>
        <ul className="list-disc list-inside space-y-0.5 ml-2">
          <li>O gestor pode conceder estrelas a qualquer momento como reconhecimento</li>
          <li>Motivo obrigatório para cada concessão</li>
          <li>Registrada no histórico com data, motivo e responsável</li>
        </ul>

        <p className="font-medium mt-3 mb-1">2. Pedidos de Alta Performance (automático)</p>
        <p className="text-xs text-muted-foreground mb-1">Válido para pedidos emitidos a partir de março/2026</p>
        <div className="bg-muted/40 rounded-xl p-3 mt-1">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-border/50">
                <th className="text-left py-1.5 font-semibold">Faixa</th>
                <th className="text-left py-1.5 font-semibold">Total do Pedido</th>
                <th className="text-left py-1.5 font-semibold">Margem Real Mínima</th>
                <th className="text-left py-1.5 font-semibold">Estrela</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-b border-border/30">
                <td className="py-1.5">1</td>
                <td className="py-1.5">≥ R$ 600</td>
                <td className="py-1.5">50%</td>
                <td className="py-1.5">1 Bronze ⭐</td>
              </tr>
              <tr className="border-b border-border/30">
                <td className="py-1.5">2</td>
                <td className="py-1.5">≥ R$ 1.000</td>
                <td className="py-1.5">45%</td>
                <td className="py-1.5">1 Bronze ⭐</td>
              </tr>
              <tr>
                <td className="py-1.5">3</td>
                <td className="py-1.5">≥ R$ 1.500</td>
                <td className="py-1.5">40%</td>
                <td className="py-1.5">1 Bronze ⭐</td>
              </tr>
            </tbody>
          </table>
          <ul className="list-disc list-inside space-y-0.5 mt-2 text-xs text-muted-foreground">
            <li>Cada pedido concede <strong>no máximo 1 estrela</strong> (a melhor faixa atingida)</li>
            <li>Proteção automática contra duplicidade: mesmo pedido nunca gera duas estrelas</li>
            <li>Exemplo: pedido de R$ 2.000 com 50% de margem = 1 estrela bronze (não 3)</li>
          </ul>
        </div>

        <p className="font-medium mt-3 mb-1">3. Metas por Disciplina (via recalcular)</p>
        <ul className="list-disc list-inside space-y-0.5 ml-2">
          <li>3 dias consecutivos batendo todas as metas diárias = 1 estrela bronze</li>
          <li>Metas: ligações + WhatsApp + zero erros operacionais</li>
        </ul>

        <h4 className="font-semibold text-[#121216] mt-4 mb-1.5">🔄 Conversão Automática</h4>
        <div className="bg-muted/40 rounded-xl p-3">
          <ul className="list-disc list-inside space-y-1">
            <li><strong>5 Bronze</strong> → 1 Prata</li>
            <li><strong>5 Prata</strong> → 1 Ouro</li>
            <li><strong>5 Ouro</strong> → 1 Cristal 💎</li>
          </ul>
          <p className="text-xs text-muted-foreground mt-2">
            A conversão é automática e em cascata. Ao acumular 5 estrelas de um nível, elas são convertidas para 1 do nível superior.
          </p>
        </div>

        <h4 className="font-semibold text-[#121216] mt-4 mb-1.5">📊 Quantas estrelas preciso para cada nível?</h4>
        <div className="bg-muted/40 rounded-xl p-3">
          <ul className="list-disc list-inside space-y-1 text-xs">
            <li><strong>1 Prata</strong> = 5 bronze</li>
            <li><strong>1 Ouro</strong> = 25 bronze (5 prata × 5 bronze)</li>
            <li><strong>1 Cristal 💎</strong> = 125 bronze (5 ouro × 25 bronze) → Prêmio de <strong>R$ 1.000</strong></li>
          </ul>
        </div>

        <h4 className="font-semibold text-[#121216] mt-4 mb-1.5">📍 Onde vejo minhas estrelas?</h4>
        <ul className="list-disc list-inside space-y-0.5 ml-2">
          <li>No topo do seu perfil (badge de estrelas)</li>
          <li>Na aba <strong>Estrelas</strong> do perfil — histórico completo com motivos</li>
          <li>No card de Conquistas (visão compacta)</li>
        </ul>

        <h4 className="font-semibold text-[#121216] mt-4 mb-1.5">⚠️ Regras Importantes</h4>
        <ul className="list-disc list-inside space-y-0.5 ml-2">
          <li>Estrelas são <strong>permanentes</strong> — nunca expiram ou são removidas</li>
          <li>Não podem ser compradas, vendidas ou transferidas</li>
          <li>Todos os registros são imutáveis para auditoria</li>
        </ul>
      </Section>

      {/* 4.8 Cristal */}
      <Section icon={<Diamond className="h-4 w-4 text-purple-500" />} title="Cristal (R$ 1.000)">
        <ul className="list-disc list-inside space-y-1">
          <li>Nasce <strong>apenas</strong> por conversão automática de 5 estrelas Ouro</li>
          <li>Dispara registro de prêmio R$ 1.000 e anúncio público no feed</li>
          <li>Pagamento controlado pelo gestor (status pendente → pago)</li>
        </ul>
      </Section>

      {/* 4.9 Regras por cargo */}
      <Section icon={<Users className="h-4 w-4 text-blue-500" />} title="Regras por Cargo">
        <ul className="list-disc list-inside space-y-1">
          <li><strong>Gestor:</strong> não participa publicamente do jogo; possui controles administrativos</li>
          <li><strong>Vendedor:</strong> níveis Ovo/Pena/Águia + XP/HCoins/Loja/Estrelas/Feed</li>
          <li><strong>Administrativo:</strong> XP/HCoins/Loja/Estrelas/Feed, sem nível comercial</li>
        </ul>
      </Section>

      {/* 4.10 Penalidades */}
      <Section icon={<AlertTriangle className="h-4 w-4 text-amber-500" />} title="Penalidades e Antifraude">
        <ul className="list-disc list-inside space-y-1">
          <li>Sem XP por obrigação — apenas por resultado e prazo</li>
          <li>Tarefa atrasada: penalidade, não bônus</li>
          <li>Vínculo de venda é automático por pedido real</li>
          <li>Todos os logs são imutáveis para auditoria</li>
        </ul>
      </Section>
    </div>
  );
}

function Section({ icon, title, children }: { icon: React.ReactNode; title: string; children: React.ReactNode }) {
  return (
    <section>
      <h3 className="font-bold text-[#121216] mb-2 flex items-center gap-2">
        {icon} {title}
      </h3>
      {children}
    </section>
  );
}
