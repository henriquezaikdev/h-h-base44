import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { HCoinIcon } from './CoinIcons';
import { ShoppingBag, Clock, DollarSign, Sparkles, Lock, Package, Info, AlertTriangle, Zap, ArrowRight, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { format, parseISO, differenceInDays } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { motion } from 'framer-motion';

interface ShopItem {
  id: string;
  name: string;
  category: string;
  hcoins_price: number;
  is_active: boolean;
  requires_approval: boolean;
  cooldown_days: number;
  monthly_limit_per_user: number;
  description: string | null;
  rules: string | null;
  sort_order: number;
  sku: string | null;
}

interface ShopOrder {
  id: string;
  item_id: string;
  status: string;
  requested_at: string;
  decided_at: string | null;
  notes: string | null;
  hcoins_price_snapshot: number;
  item_name: string | null;
  cancel_reason: string | null;
  shop_item?: ShopItem;
}

const CATEGORY_CONFIG: Record<string, { icon: React.ReactNode; label: string; color: string }> = {
  TEMPO: { icon: <Clock className="h-4 w-4" />, label: 'Tempo', color: 'bg-blue-50 text-blue-700 border-blue-200' },
  FINANCEIRO: { icon: <DollarSign className="h-4 w-4" />, label: 'Financeiro', color: 'bg-emerald-50 text-emerald-700 border-emerald-200' },
  ESTRATEGICO: { icon: <Sparkles className="h-4 w-4" />, label: 'Estratégico', color: 'bg-purple-50 text-purple-700 border-purple-200' },
};

const STATUS_CONFIG: Record<string, { label: string; color: string }> = {
  REQUESTED: { label: 'Aguardando aprovação', color: 'bg-amber-50 text-amber-700 border-amber-200' },
  APPROVED: { label: 'Aprovado', color: 'bg-blue-50 text-blue-700 border-blue-200' },
  REJECTED: { label: 'Rejeitado', color: 'bg-red-50 text-red-700 border-red-200' },
  DELIVERED: { label: 'Entregue', color: 'bg-emerald-50 text-emerald-700 border-emerald-200' },
  FULFILLED: { label: 'Entregue', color: 'bg-emerald-50 text-emerald-700 border-emerald-200' },
  CANCELED: { label: 'Cancelado', color: 'bg-gray-50 text-gray-700 border-gray-200' },
};

interface LojaHHProps {
  sellerId: string;
  isOwnProfile: boolean;
}

export function LojaHH({ sellerId, isOwnProfile }: LojaHHProps) {
  const { seller } = useAuth();
  const [items, setItems] = useState<ShopItem[]>([]);
  const [orders, setOrders] = useState<ShopOrder[]>([]);
  const [balance, setBalance] = useState(0);
  const [reserved, setReserved] = useState(0);
  const [xpTotal, setXpTotal] = useState(0);
  const [xpSpent, setXpSpent] = useState(0);
  const [loading, setLoading] = useState(true);
  const [purchasing, setPurchasing] = useState<string | null>(null);
  const [convertQty, setConvertQty] = useState(1);
  const [converting, setConverting] = useState(false);

  const available = balance - reserved;
  const xpAvailable = xpTotal - xpSpent;
  const maxConvertible = Math.floor(xpAvailable / 1000);

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const [{ data: itemsData }, { data: ordersData }, { data: sellerData }] = await Promise.all([
        supabase.from('shop_items').select('*').eq('is_active', true).order('sort_order'),
        supabase.from('shop_orders').select('*, shop_items(*)').eq('user_id', sellerId).order('requested_at', { ascending: false }),
        supabase.from('sellers').select('hcoins_balance, hcoins_reserved, xp_total, xp_spent').eq('id', sellerId).maybeSingle(),
      ]);
      setItems((itemsData || []) as unknown as ShopItem[]);
      setOrders((ordersData || []).map((o: any) => ({ ...o, shop_item: o.shop_items })) as ShopOrder[]);
      setBalance(sellerData?.hcoins_balance || 0);
      setReserved(sellerData?.hcoins_reserved || 0);
      setXpTotal(sellerData?.xp_total || 0);
      setXpSpent((sellerData as any)?.xp_spent || 0);
    } catch (err) {
      console.error('Error fetching shop data:', err);
    } finally {
      setLoading(false);
    }
  }, [sellerId]);

  useEffect(() => { fetchData(); }, [fetchData]);

  const getBlockReason = (item: ShopItem): string | null => {
    if (available < item.hcoins_price) return `Saldo insuficiente (${available}/${item.hcoins_price})`;

    const now = new Date();
    const thisMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
    const itemOrders = orders.filter(o => o.item_id === item.id && !['REJECTED', 'CANCELED'].includes(o.status));

    if (item.monthly_limit_per_user > 0) {
      const monthOrders = itemOrders.filter(o => o.requested_at.startsWith(thisMonth));
      if (monthOrders.length >= item.monthly_limit_per_user) return `Limite mensal atingido (${item.monthly_limit_per_user}x)`;
    }

    const lastOrder = itemOrders[0];
    if (lastOrder && item.cooldown_days > 0) {
      const daysSince = differenceInDays(now, parseISO(lastOrder.requested_at));
      if (daysSince < item.cooldown_days) {
        const remaining = item.cooldown_days - daysSince;
        return `Cooldown: aguarde ${remaining} dia${remaining > 1 ? 's' : ''}`;
      }
    }

    return null;
  };

  const handlePurchase = async (item: ShopItem) => {
    if (!seller?.id || seller.id !== sellerId) return;
    const blockReason = getBlockReason(item);
    if (blockReason) { toast.error(blockReason); return; }

    setPurchasing(item.id);
    try {
      const { data, error } = await supabase.rpc('fn_shop_request', {
        p_user_id: sellerId,
        p_item_id: item.id,
        p_qty: 1,
      });

      if (error) throw error;

      toast.success('Solicitação enviada! Aguardando aprovação do gestor.');
      fetchData();
    } catch (err: any) {
      console.error('Purchase error:', err);
      toast.error(err.message || 'Erro ao processar solicitação');
    } finally {
      setPurchasing(null);
    }
  };

  const handleXpConversion = async () => {
    if (!seller?.id || seller.id !== sellerId) return;
    if (convertQty <= 0 || convertQty > maxConvertible) {
      toast.error(`Quantidade inválida. Máximo: ${maxConvertible}`);
      return;
    }
    setConverting(true);
    try {
      const sb = supabase as any;
      const { error } = await sb.rpc('fn_xp_to_hcoins', {
        p_user_id: sellerId,
        p_qty: convertQty,
      });
      if (error) throw error;
      toast.success(`${convertQty} HCoin(s) adquirido(s) com ${convertQty * 1000} XP!`);
      setConvertQty(1);
      fetchData();
    } catch (err: any) {
      toast.error(err.message || 'Erro na conversão');
    } finally {
      setConverting(false);
    }
  };

  if (loading) return <div className="py-8 text-center text-muted-foreground">Carregando loja...</div>;

  const grouped = {
    TEMPO: items.filter(i => i.category === 'TEMPO'),
    FINANCEIRO: items.filter(i => i.category === 'FINANCEIRO'),
    ESTRATEGICO: items.filter(i => i.category === 'ESTRATEGICO'),
  };

  return (
    <div className="mt-4 space-y-4">
      {/* Balance header */}
      <Card className="bg-gradient-to-r from-[#FF6A00]/10 to-amber-50 backdrop-blur-sm rounded-2xl shadow-sm border border-[#FF6A00]/20">
        <CardContent className="p-4 flex items-center gap-4">
          <div className="h-12 w-12 rounded-xl bg-[#FF6A00]/10 flex items-center justify-center">
            <HCoinIcon size={28} />
          </div>
          <div className="flex-1">
            <p className="text-2xl font-bold text-[#121216]">{available}</p>
            <p className="text-xs text-[#121216]/50">HCoins disponíveis</p>
          </div>
          {reserved > 0 && (
            <div className="text-right">
              <p className="text-sm font-medium text-amber-600">{reserved}</p>
              <p className="text-[10px] text-[#121216]/40">Reservados</p>
            </div>
          )}
        </CardContent>
      </Card>

      <Tabs defaultValue="catalogo">
        <TabsList className="w-full bg-white/70 backdrop-blur-sm rounded-xl p-1 h-auto">
          <TabsTrigger value="catalogo" className="rounded-lg text-xs px-4 py-1.5 data-[state=active]:bg-[#121216] data-[state=active]:text-white">
            <ShoppingBag className="h-3.5 w-3.5 mr-1.5" /> Catálogo
          </TabsTrigger>
          <TabsTrigger value="pedidos" className="rounded-lg text-xs px-4 py-1.5 data-[state=active]:bg-[#121216] data-[state=active]:text-white">
            <Package className="h-3.5 w-3.5 mr-1.5" /> Meus Pedidos
          </TabsTrigger>
          <TabsTrigger value="info" className="rounded-lg text-xs px-4 py-1.5 data-[state=active]:bg-[#121216] data-[state=active]:text-white">
            <Info className="h-3.5 w-3.5 mr-1.5" /> Regras
          </TabsTrigger>
        </TabsList>

        <TabsContent value="catalogo">
          {/* XP → HCoin Conversion */}
          {isOwnProfile && (
            <Card className="bg-gradient-to-r from-blue-50 to-purple-50 backdrop-blur-sm rounded-2xl shadow-sm border border-blue-200/50 mt-3 mb-4">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-3">
                  <Zap className="h-4 w-4 text-blue-600" />
                  <h4 className="text-sm font-semibold text-foreground">Converter XP → HCoins</h4>
                </div>
                <p className="text-xs text-muted-foreground mb-3">
                  Taxa: 1.000 XP = 1 HCoin · XP disponível: <strong>{xpAvailable.toLocaleString('pt-BR')}</strong> · Máximo: <strong>{maxConvertible}</strong> HCoin(s)
                </p>
                {maxConvertible > 0 ? (
                  <div className="flex items-center gap-2">
                    <div className="flex items-center gap-1.5 flex-1">
                      <Input
                        type="number"
                        min={1}
                        max={maxConvertible}
                        value={convertQty}
                        onChange={(e) => setConvertQty(Math.max(1, Math.min(maxConvertible, parseInt(e.target.value) || 1)))}
                        className="w-20 h-9 text-sm"
                      />
                      <span className="text-xs text-muted-foreground whitespace-nowrap">
                        = {(convertQty * 1000).toLocaleString('pt-BR')} XP
                      </span>
                    </div>
                    <Button
                      size="sm"
                      disabled={converting || convertQty <= 0 || convertQty > maxConvertible}
                      onClick={handleXpConversion}
                      className="gap-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white shrink-0"
                    >
                      {converting ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <ArrowRight className="h-3.5 w-3.5" />}
                      Converter
                    </Button>
                  </div>
                ) : (
                  <p className="text-xs text-muted-foreground italic">XP insuficiente para conversão (mínimo 1.000 XP)</p>
                )}
              </CardContent>
            </Card>
          )}
          <div className="space-y-5 mt-3">
            {(['TEMPO', 'FINANCEIRO', 'ESTRATEGICO'] as const).map(cat => {
              const config = CATEGORY_CONFIG[cat];
              const catItems = grouped[cat];
              if (!catItems.length) return null;
              return (
                <div key={cat}>
                  <div className="flex items-center gap-2 mb-2">
                    <Badge variant="outline" className={`${config.color} text-xs gap-1`}>
                      {config.icon} {config.label}
                    </Badge>
                  </div>
                  <div className="grid gap-3">
                    {catItems.map(item => {
                      const blockReason = isOwnProfile ? getBlockReason(item) : null;
                      const isBlocked = !!blockReason;
                      return (
                        <motion.div key={item.id} initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }}>
                          <Card className={`bg-white/80 backdrop-blur-sm rounded-2xl shadow-sm border ${isBlocked ? 'border-[#121216]/10 opacity-70' : 'border-white/60'}`}>
                            <CardContent className="p-4">
                              <div className="flex items-start justify-between gap-3">
                                <div className="flex-1 min-w-0">
                                  <h4 className="text-sm font-semibold text-[#121216]">{item.name}</h4>
                                  {item.description && (
                                    <p className="text-xs text-[#121216]/55 mt-0.5">{item.description}</p>
                                  )}
                                  <div className="flex flex-wrap items-center gap-2 mt-2">
                                    <span className="flex items-center gap-1 text-xs font-medium text-[#FF6A00]">
                                      <HCoinIcon size={14} /> {item.hcoins_price}
                                    </span>
                                    <span className="text-[10px] text-[#121216]/35">
                                      Cooldown: {item.cooldown_days}d
                                      {item.monthly_limit_per_user > 0 && ` · Limite: ${item.monthly_limit_per_user}/mês`}
                                    </span>
                                  </div>
                                  {item.rules && (
                                    <p className="text-[10px] text-[#121216]/40 mt-1 italic">{item.rules}</p>
                                  )}
                                  {isBlocked && blockReason && (
                                    <p className="text-[10px] text-red-500 mt-1 flex items-center gap-1">
                                      <Lock className="h-3 w-3" /> {blockReason}
                                    </p>
                                  )}
                                </div>
                                {isOwnProfile && (
                                  <Button
                                    size="sm"
                                    disabled={isBlocked || purchasing === item.id}
                                    onClick={() => handlePurchase(item)}
                                    className="rounded-xl bg-[#FF6A00] hover:bg-[#FF6A00]/90 text-white text-xs shrink-0"
                                  >
                                    {purchasing === item.id ? '...' : 'Solicitar'}
                                  </Button>
                                )}
                              </div>
                            </CardContent>
                          </Card>
                        </motion.div>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        </TabsContent>

        <TabsContent value="pedidos">
          <div className="space-y-2 mt-3">
            {orders.length === 0 ? (
              <p className="text-sm text-[#121216]/40 text-center py-8">Nenhum pedido ainda</p>
            ) : (
              orders.map(order => {
                const statusCfg = STATUS_CONFIG[order.status] || STATUS_CONFIG.REQUESTED;
                return (
                  <Card key={order.id} className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-sm border border-white/60">
                    <CardContent className="p-4 flex items-center gap-3">
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-[#121216] truncate">
                          {order.item_name || order.shop_item?.name || 'Item'}
                        </p>
                        <div className="flex items-center gap-2 mt-1">
                          <span className="flex items-center gap-1 text-xs text-[#FF6A00]">
                            <HCoinIcon size={12} /> {order.hcoins_price_snapshot}
                          </span>
                          <span className="text-[10px] text-[#121216]/40">
                            {format(parseISO(order.requested_at), "dd/MM/yy HH:mm", { locale: ptBR })}
                          </span>
                        </div>
                        {order.cancel_reason && (
                          <p className="text-[10px] text-red-500 mt-1 italic">Motivo: {order.cancel_reason}</p>
                        )}
                        {order.notes && !order.cancel_reason && (
                          <p className="text-[10px] text-[#121216]/50 mt-1 italic">{order.notes}</p>
                        )}
                      </div>
                      <Badge variant="outline" className={`text-xs ${statusCfg.color}`}>
                        {statusCfg.label}
                      </Badge>
                    </CardContent>
                  </Card>
                );
              })
            )}
          </div>
        </TabsContent>

        <TabsContent value="info">
          <Card className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-sm border border-white/60 mt-3">
            <CardContent className="p-5 space-y-4">
              <h3 className="text-sm font-semibold text-[#121216] flex items-center gap-2">
                <AlertTriangle className="h-4 w-4 text-amber-500" /> Regulamento da Loja H&H
              </h3>
              <div className="text-xs text-[#121216]/70 space-y-2 leading-relaxed">
                <p><strong>HCoins não é dinheiro.</strong> É um benefício simbólico interno, sem valor monetário ou direito adquirido.</p>
                <p><strong>Todos os resgates estão sujeitos à aprovação do gestor.</strong> O pedido cria uma reserva no seu saldo até a decisão.</p>
                <p><strong>Disponibilidade operacional.</strong> Itens da categoria Tempo dependem da disponibilidade da empresa.</p>
                <p><strong>Cooldown e limites mensais</strong> são aplicados por item. Verifique as regras de cada benefício antes de solicitar.</p>
                <p><strong>Se um pedido for rejeitado</strong>, os HCoins reservados voltam automaticamente para o seu saldo.</p>
                <p><strong>Log imutável.</strong> Todas as transações são registradas e não podem ser alteradas ou excluídas.</p>
                <p><strong>Sem direito adquirido.</strong> A empresa pode alterar preços, itens e regras a qualquer momento.</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
