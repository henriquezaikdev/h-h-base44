import { useState, useCallback, lazy, Suspense, useEffect, useMemo } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { useAuth } from '@/hooks/useAuth';
import { useSellerProfile } from '@/hooks/useSellerProfile';
import { useErrosCriticos } from '@/hooks/useErrosCriticos';
import { useReconhecimentos, CATEGORIA_LABELS } from '@/hooks/useReconhecimentos';
import { ProfileHeroSection, StarsDisplayData } from './ProfileHeroSection';
import { ProfileStoriesBar } from './ProfileStoriesBar';
import { LevelExplanationBlock } from './LevelExplanationBlock';
import { ProfileEditModal } from './ProfileEditModal';
import { HCoinIcon, EstrelaIcon, CurtidaIcon } from './CoinIcons';
import { GlowingEffect } from '@/components/ui/glowing-effect';

// Lazy-load ProfileFeedMural — only loads when Visão Geral tab is visible
const ProfileFeedMural = lazy(() => import('./ProfileFeedMural').then(m => ({ default: m.ProfileFeedMural })));
const RegrasXPInline = lazy(() => import('@/pages/RegrasXP'));
const XpExtratoLazy = lazy(() => import('./XpExtrato').then(m => ({ default: m.XpExtrato })));
import { CienciaBanner } from '@/components/ciencia/CienciaBanner';
import { CampanhaBanner } from '@/components/campanhas/CampanhaBanner';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  Heart, History, Trophy, Shield, ShieldAlert,
  AlertTriangle, CheckCircle, CheckCircle2, XCircle, Zap, TrendingUp, Target,
  Star, BookOpen, ShoppingBag, Eye, Award, Loader2, Crown, CalendarDays, Phone, Edit3,
} from 'lucide-react';
import { format, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { motion } from 'framer-motion';
import { supabase } from '@/integrations/supabase/client';
// useEffect already imported above

// Lazy load heavy components
const SellerEvolution = lazy(() => import('@/pages/SellerEvolution'));
const CampanhaSellerView = lazy(() => import('@/components/campanhas/CampanhaSellerView').then(m => ({ default: m.CampanhaSellerView })));
const CampanhaGestorPanel = lazy(() => import('@/components/campanhas/CampanhaGestorPanel').then(m => ({ default: m.CampanhaGestorPanel })));
const LojaHH = lazy(() => import('@/components/profile/LojaHH').then(m => ({ default: m.LojaHH })));
const LojaGestorQueue = lazy(() => import('@/components/profile/LojaGestorQueue').then(m => ({ default: m.LojaGestorQueue })));
const EstrelasProfileTab = lazy(() => import('@/components/profile/EstrelasProfileTab').then(m => ({ default: m.EstrelasProfileTab })));
const EstrelasGestorPanel = lazy(() => import('@/components/profile/EstrelasGestorPanel').then(m => ({ default: m.EstrelasGestorPanel })));
const RulebookGestorPanel = lazy(() => import('@/components/profile/RulebookGestorPanel').then(m => ({ default: m.RulebookGestorPanel })));
const RulebookContentComponent = lazy(() => import('@/components/profile/RulebookContent').then(m => ({ default: m.RulebookContent })));
const IncentiveCampaignGestor = lazy(() => import('@/components/campanhas/IncentiveCampaignGestor').then(m => ({ default: m.IncentiveCampaignGestor })));
const IncentiveCampaignPublic = lazy(() => import('@/components/campanhas/IncentiveCampaignPublic').then(m => ({ default: m.IncentiveCampaignPublic })));
const LazyAwardStarsModal = lazy(() => import('@/components/gestor/AwardStarsModal').then(m => ({ default: m.AwardStarsModal })));
const LazyRecognitionModalTop = lazy(() => import('./RecognitionModal').then(m => ({ default: m.RecognitionModal })));
import { DepartmentStatsCard } from './DepartmentStatsCard';
import { DepartmentHistoricoTab } from './DepartmentHistoricoTab';

const NIVEL_CONFIG: Record<string, { emoji: string; label: string; color: string }> = {
  OVO: { emoji: '🥚', label: 'Ovo', color: 'bg-gray-100 text-gray-700' },
  PENA: { emoji: '🪶', label: 'Pena', color: 'bg-blue-100 text-blue-700' },
  AGUIA: { emoji: '🦅', label: 'Águia', color: 'bg-amber-100 text-amber-700' },
};

const ERRO_TIPO_LABELS: Record<string, string> = {
  PRODUTO_ERRADO: 'Produto Errado',
  FALTA_RETORNO: 'Falta de Retorno',
  PEDIDO_ERRADO: 'Pedido Errado',
  INFO_ERRADA: 'Informação Errada',
  OUTRO: 'Outro',
};

const ERRO_ORIGEM_LABELS: Record<string, string> = {
  FINANCEIRO: 'Financeiro',
  LOGISTICA: 'Logística',
  COMERCIAL: 'Comercial',
  ADMIN: 'Admin',
};

const REASON_LABELS: Record<string, string> = {
  AJUDA_NA_NEGOCIACAO: 'Ajuda na negociação',
  VENDA_RELEVANTE: 'Venda relevante',
  EXCELENCIA_ATENDIMENTO: 'Excelência no atendimento',
  EXCELENCIA_OPERACIONAL: 'Excelência operacional',
  ORGANIZACAO_EXEMPLAR: 'Organização exemplar',
  INICIATIVA_ESTRATEGICA: 'Iniciativa estratégica',
  APOIO_A_EQUIPE: 'Apoio à equipe',
  ENTREGA_RAPIDA: 'Entrega rápida',
  RESOLVEU_PEPINO: 'Resolveu um pepino',
  OUTRO: 'Outro',
};

function getTipoIcon(tipo: string) {
  if (tipo === 'CURTIDA') return <CurtidaIcon size={22} />;
  if (tipo === 'HCOIN') return <HCoinIcon size={22} />;
  if (tipo === 'ESTRELA') return <EstrelaIcon size={22} />;
  return <span className="text-xl">🎁</span>;
}

const TAB_STYLE = "rounded-xl text-xs gap-1.5 px-4 md:px-5 py-2.5 font-semibold transition-all whitespace-nowrap shrink-0 data-[state=active]:bg-[#3B5BDB] data-[state=active]:text-white data-[state=active]:shadow-md data-[state=inactive]:text-gray-500 data-[state=inactive]:hover:text-gray-700 data-[state=inactive]:hover:bg-gray-100/80";

interface ProfileHubContentProps {
  sellerId: string;
  isOwnProfile: boolean;
  canSeeDetails: boolean;
}

function SaasCard({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={`relative bg-white rounded-2xl border border-gray-200 shadow-sm ${className}`}>
      <GlowingEffect
        spread={40}
        glow
        disabled
        proximity={0}
        inactiveZone={0.01}
        borderWidth={2}
      />
      {children}
    </div>
  );
}

// Componente inline para registro de erros operacionais (exclusivo Anna Cristina)
function ErroRegistroInline({ sellerId, registrarErro, onClose }: {
  sellerId: string;
  registrarErro: (dados: { vendedor_id: string; tipo: string; origem: string; descricao: string }) => Promise<void>;
  onClose: () => void;
}) {
  const [formData, setFormData] = useState({ tipo: '', origem: '', descricao: '' });
  const [saving, setSaving] = useState(false);

  const handleSubmit = async () => {
    if (!formData.tipo || !formData.origem || !formData.descricao.trim()) return;
    setSaving(true);
    await registrarErro({ vendedor_id: sellerId, tipo: formData.tipo, origem: formData.origem, descricao: formData.descricao });
    setFormData({ tipo: '', origem: '', descricao: '' });
    setSaving(false);
    onClose();
  };

  return (
    <Card className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-sm border border-red-200">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm flex items-center gap-2 text-red-600">
          <AlertTriangle className="h-4 w-4" /> Registrar Erro Operacional
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1">
            <Label className="text-xs">Tipo</Label>
            <Select value={formData.tipo} onValueChange={v => setFormData(p => ({ ...p, tipo: v }))}>
              <SelectTrigger className="rounded-xl text-xs h-8">
                <SelectValue placeholder="Selecione..." />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="pedido_errado">Pedido Errado</SelectItem>
                <SelectItem value="dados_incorretos">Dados Incorretos</SelectItem>
                <SelectItem value="atraso_processo">Atraso no Processo</SelectItem>
                <SelectItem value="falha_comunicacao">Falha de Comunicação</SelectItem>
                <SelectItem value="erro_financeiro">Erro Financeiro</SelectItem>
                <SelectItem value="outro">Outro</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1">
            <Label className="text-xs">Origem</Label>
            <Select value={formData.origem} onValueChange={v => setFormData(p => ({ ...p, origem: v }))}>
              <SelectTrigger className="rounded-xl text-xs h-8">
                <SelectValue placeholder="Selecione..." />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="auditoria_interna">Auditoria Interna</SelectItem>
                <SelectItem value="reclamacao_cliente">Reclamação de Cliente</SelectItem>
                <SelectItem value="conferencia">Conferência</SelectItem>
                <SelectItem value="sistema">Sistema</SelectItem>
                <SelectItem value="outro">Outro</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        <div className="space-y-1">
          <Label className="text-xs">Descrição</Label>
          <Textarea
            value={formData.descricao}
            onChange={e => setFormData(p => ({ ...p, descricao: e.target.value }))}
            placeholder="Descreva o erro operacional..."
            className="rounded-xl text-xs min-h-[60px]"
          />
        </div>
        <div className="flex gap-2 justify-end">
          <Button variant="ghost" size="sm" onClick={onClose} className="rounded-xl text-xs">Cancelar</Button>
          <Button
            size="sm"
            onClick={handleSubmit}
            disabled={saving || !formData.tipo || !formData.origem || !formData.descricao.trim()}
            className="rounded-xl text-xs bg-red-600 hover:bg-red-700 text-white"
          >
            {saving ? 'Registrando...' : 'Registrar Erro'}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

export function ProfileHubContent({ sellerId, isOwnProfile, canSeeDetails }: ProfileHubContentProps) {
  const { seller: currentSeller, isOwner } = useAuth();
  const { profile, monthlyStats, loading, refetch } = useSellerProfile(sellerId);
  const { erros, errosAtivosMes, registrarErro, invalidarErro } = useErrosCriticos(sellerId);
  const { reconhecimentos, darReconhecimento, curtidasMes, hcoinsMes, estrelasMes, carteira } = useReconhecimentos(sellerId);
  
  // Fetch stars for hero display
  const { data: heroStarsData } = useQuery<StarsDisplayData | null>({
    queryKey: ['hero_stars', sellerId],
    queryFn: async () => {
      const { data } = await supabase
        .from('seller_stars')
        .select('bronze_stars, silver_stars, gold_stars')
        .eq('seller_id', sellerId)
        .maybeSingle();
      return data ? { ...data, crystal_stars: 0 } as StarsDisplayData : null;
    },
  });

  const [editOpen, setEditOpen] = useState(false);
  const [reconhecerOpen, setReconhecerOpen] = useState(false);
  const [awardStarsOpen, setAwardStarsOpen] = useState(false);
  const [hcoinsModalOpen, setHcoinsModalOpen] = useState(false);
  const [erroFormOpen, setErroFormOpen] = useState(false);

  // IDs da Anna Cristina (admin com permissão de registrar erros)
  const ANNA_SELLER_IDS = ['2be02843-4f03-46be-bd64-0f02bc53f2a0', '53280181-1118-4e9a-9e00-9d807d070f9c'];
  const isAnna = currentSeller?.id ? ANNA_SELLER_IDS.includes(currentSeller.id) : false;

  // O perfil sendo visualizado é de um vendedor comercial?
  // REGRA: role === 'vendedor' OU is_sales_active === true → layout de vendedor
  const isProfileComercial = profile?.role === 'vendedor' || profile?.is_sales_active === true;
  // Quem visualiza é gestor (owner/admin)?
  const isViewerGestor = isOwner || currentSeller?.role === 'admin';
  // Mostrar abas comerciais? Sim se o perfil é vendedor E (é próprio perfil OU gestor visitando)
  const showCommercialTabs = isProfileComercial && (isOwnProfile || isViewerGestor);
  // Perfil é administrativo (não-vendedor)?
  const isProfileAdministrativo = !isProfileComercial;
  // Gestor (owner/master) = não exibe XP/HCoins/Estrelas/Score no PRÓPRIO perfil
  const isProfileGestor = isOwner && isOwnProfile;
  // Admin (não-vendedor, não-gestor, não-sales-active) = não exibe Ovo/Pena/Águia nem Performance
  const isProfileAdmin = profile?.role === 'admin' && !isOwner && !profile?.is_sales_active;

  if (loading || !profile) {
    return (
      <div className="flex items-center justify-center min-h-[40vh]">
        <div className="animate-pulse text-gray-400">Carregando perfil...</div>
      </div>
    );
  }

  const nivel = NIVEL_CONFIG[profile.nivel_atual] || NIVEL_CONFIG.OVO;

  return (
    <div className="space-y-5">
      {/* CIÊNCIA BANNER */}
      {isOwnProfile && <CienciaBanner />}
      {isOwnProfile && <CampanhaBanner />}

      {/* STORIES BAR */}
      <div className="bg-white rounded-2xl border border-gray-200/60 shadow-sm px-4 py-3">
        <ProfileStoriesBar />
      </div>

      {/* HERO */}
      <ProfileHeroSection
        profile={profile}
        monthlyStats={monthlyStats}
        starsData={heroStarsData}
        isOwnProfile={isOwnProfile}
        canSeeDetails={canSeeDetails}
        isOwner={isOwner}
        onEditProfile={() => setEditOpen(true)}
        onReconhecer={() => setReconhecerOpen(true)}
        onAwardStars={() => setAwardStarsOpen(true)}
        onSendHCoins={() => setHcoinsModalOpen(true)}
        onRegistrarErro={isAnna && !isOwnProfile ? () => setErroFormOpen(true) : undefined}
      />

      {/* Formulário inline de Registrar Erro — exclusivo Anna Cristina */}
      {isAnna && !isOwnProfile && erroFormOpen && (
        <ErroRegistroInline
          sellerId={sellerId}
          registrarErro={registrarErro}
          onClose={() => setErroFormOpen(false)}
        />
      )}

      {/* TABS — New structure */}
      <Tabs defaultValue="visao-geral">
        <div className="overflow-x-auto -mx-3 px-3 md:mx-0 md:px-0">
          <TabsList className="w-max md:w-full bg-gray-50/80 rounded-2xl border border-gray-200/50 p-1.5 h-auto flex-nowrap md:flex-wrap gap-1">
            <TabsTrigger value="visao-geral" className={TAB_STYLE}>
              <Eye className="h-3.5 w-3.5" /> Visão Geral
            </TabsTrigger>
            {(isOwnProfile || canSeeDetails) && (
              <TabsTrigger value="xp-ranking" className={TAB_STYLE}>
                <Trophy className="h-3.5 w-3.5" /> XP & Ranking
              </TabsTrigger>
            )}
            <TabsTrigger value="reconhecimentos" className={TAB_STYLE}>
              <Heart className="h-3.5 w-3.5" /> Reconhecimentos
            </TabsTrigger>
            {!isProfileGestor && (
              <TabsTrigger value="loja" className={TAB_STYLE}>
                <ShoppingBag className="h-3.5 w-3.5" /> Loja H&H
              </TabsTrigger>
            )}
            {isProfileGestor && (
              <TabsTrigger value="loja-gestao" className={TAB_STYLE}>
                <ShoppingBag className="h-3.5 w-3.5" /> Loja (Gestão)
              </TabsTrigger>
            )}
            <TabsTrigger value="estrelas" className={TAB_STYLE}>
              <Star className="h-3.5 w-3.5" /> Estrelas
            </TabsTrigger>
            {isProfileGestor && (
              <TabsTrigger value="estrelas-gestao" className={TAB_STYLE}>
                <Award className="h-3.5 w-3.5" /> Estrelas (Gestão)
              </TabsTrigger>
            )}
            <TabsTrigger value="regras" className={TAB_STYLE}>
              <BookOpen className="h-3.5 w-3.5" /> Regras
            </TabsTrigger>
            {isProfileGestor && (
              <TabsTrigger value="regras-gestao" className={TAB_STYLE}>
                <BookOpen className="h-3.5 w-3.5" /> Regras (Gestão)
              </TabsTrigger>
            )}
            {(isOwnProfile || canSeeDetails) && (
              <TabsTrigger value="qualidade" className={TAB_STYLE}>
                <Shield className="h-3.5 w-3.5" /> Qualidade
              </TabsTrigger>
            )}
            {(isOwnProfile || canSeeDetails) && (
              <TabsTrigger value="evolucao" className={TAB_STYLE}>
                <TrendingUp className="h-3.5 w-3.5" /> Evolução
              </TabsTrigger>
            )}
            {(isOwnProfile || canSeeDetails) && (
              <TabsTrigger value="campanhas" className={TAB_STYLE}>
                <Target className="h-3.5 w-3.5" /> Campanhas
              </TabsTrigger>
            )}
            <TabsTrigger value="incentivo" className={TAB_STYLE}>
              <Trophy className="h-3.5 w-3.5" /> Incentivo
            </TabsTrigger>
            <TabsTrigger value="historico" className={TAB_STYLE}>
              <History className="h-3.5 w-3.5" /> Histórico
            </TabsTrigger>
          </TabsList>
        </div>

        {/* ABA 1 — VISÃO GERAL */}
        <TabsContent value="visao-geral">
          <div className="mt-4 space-y-4">
            {/* Mini stat cards — special view for Owner/Master */}
            {isProfileGestor ? (
              <div className="grid grid-cols-3 gap-3">
                <MiniStatCard icon={<Crown className="h-5 w-5 text-amber-500" />} value="Master" label="Nível" />
                <MiniStatCard icon={<HCoinIcon size={20} />} value="∞" label="HCoins" />
                <MiniStatCard icon={<EstrelaIcon size={20} />} value="∞" label="Estrelas" />
              </div>
            ) : (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <MiniStatCard icon={<Zap className="h-5 w-5 text-[#FF6A00]" />} value={profile.xp_total - (profile.xp_spent || 0)} label="XP" xpProgress={{ level: profile.level, xpTotal: profile.xp_total }} />
                <MiniStatCard icon={<Zap className="h-5 w-5 text-blue-500" />} value={(profile as any).xp_month ?? 0} label="XP Mês" />
                <MiniStatCard icon={<HCoinIcon size={20} />} value={(profile as any).hcoins_balance ?? 0} label="HCoins" />
                <MiniStatCard icon={<EstrelaIcon size={20} />} value={(heroStarsData?.bronze_stars || 0) + (heroStarsData?.silver_stars || 0) * 5 + (heroStarsData?.gold_stars || 0) * 25 + (heroStarsData?.crystal_stars || 0) * 125} label="Estrelas" />
              </div>
            )}

            {/* Monthly recognition summary */}
            <SaasCard className="p-6">
              <p className="text-sm text-gray-500 mb-3">Reconhecimentos do Mês</p>
                <div className="flex items-center gap-6">
                  <div className="flex items-center gap-2">
                    <CurtidaIcon size={18} />
                    <span className="text-lg font-bold text-gray-900">{curtidasMes}</span>
                    <span className="text-xs text-gray-400">curtidas</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <HCoinIcon size={18} />
                    <span className="text-lg font-bold text-gray-900">{hcoinsMes}</span>
                    <span className="text-xs text-gray-400">hcoins</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <EstrelaIcon size={18} />
                    <span className="text-lg font-bold text-gray-900">{estrelasMes}</span>
                    <span className="text-xs text-gray-400">estrelas</span>
                  </div>
                </div>
            </SaasCard>

            {/* Commercial stats for sellers — hidden for gestor and admin */}
            {isProfileComercial && !isProfileGestor && !isProfileAdmin && canSeeDetails && monthlyStats && (
              <SaasCard className="p-6">
                <p className="text-sm text-gray-500 font-medium mb-4 uppercase tracking-wider">Performance Comercial</p>
                  <div className="grid grid-cols-3 gap-6">
                    <div className="flex flex-col items-center">
                      <p className="text-3xl font-bold text-[#FF6A00]">{Math.round(monthlyStats.percentualVendas * 100)}%</p>
                      <p className="text-xs text-gray-400 mt-1">Meta Vendas</p>
                    </div>
                    <div className="flex flex-col items-center">
                      <p className="text-3xl font-bold text-blue-600">{monthlyStats.realizadoLigacoes}/{monthlyStats.metaLigacoes}</p>
                      <p className="text-xs text-gray-400 mt-1">Ligações</p>
                    </div>
                    <div className="flex flex-col items-center">
                      <p className={`text-3xl font-bold ${monthlyStats.errosCriticos === 0 ? 'text-emerald-600' : 'text-red-600'}`}>{monthlyStats.errosCriticos}</p>
                      <p className="text-xs text-gray-400 mt-1">Erros</p>
                    </div>
                  </div>
              </SaasCard>
            )}

            {/* Department-specific stats for admin profiles (Anna Cristina, Adriana) */}
            {isProfileAdministrativo && !isProfileGestor && (isOwnProfile || canSeeDetails) && (
              <DepartmentStatsCard sellerId={sellerId} department={profile.department || null} />
            )}

            {/* Mural H&H Feed — lazy loaded */}
            <Suspense fallback={<div className="animate-pulse bg-gray-100 rounded-2xl h-64" />}>
              <ProfileFeedMural />
            </Suspense>
          </div>
        </TabsContent>

        {/* ABA 2 — XP & RANKING */}
        {(isOwnProfile || canSeeDetails) && (
          <TabsContent value="xp-ranking">
            <div className="mt-4 space-y-4">
              {/* XP Summary */}
              <SaasCard className="p-6">
                <p className="text-base text-gray-900 flex items-center gap-2 font-semibold mb-4">
                    <Zap className="h-4 w-4 text-[#FF6A00]" /> XP & Progressão
                </p>
                <div className="space-y-4">
                  <div className="grid grid-cols-3 gap-4">
                    <div className="text-center p-4 rounded-xl bg-orange-50">
                      <p className="text-3xl font-bold text-[#FF6A00]">{(profile.xp_total - (profile.xp_spent || 0)).toLocaleString('pt-BR')}</p>
                      <p className="text-xs text-gray-500 mt-1">XP</p>
                    </div>
                    <div className="text-center p-4 rounded-xl bg-emerald-50">
                      <p className="text-3xl font-bold text-emerald-600">{(profile as any).xp_month ?? 0}</p>
                      <p className="text-xs text-gray-500 mt-1">XP do Mês</p>
                    </div>
                    <div className="text-center p-4 rounded-xl bg-blue-50">
                      <p className="text-3xl font-bold text-blue-600">Nível {profile.level}</p>
                      <p className="text-xs text-gray-500 mt-1">{nivel.label}</p>
                    </div>
                  </div>
                  {monthlyStats && (
                    <div className="space-y-3 pt-3 border-t border-gray-100">
                      <div className="flex items-center justify-between">
                        <p className="text-sm font-semibold text-gray-900">Score do Mês</p>
                        <p className="text-2xl font-bold text-[#FF6A00]">{monthlyStats.score}</p>
                      </div>
                      <ScorePillarBar icon={<CheckCircle2 className="h-4 w-4 text-emerald-500" />} label="Tarefas no Prazo" value={monthlyStats.scoreTarefasNoPrazo} max={30} tooltip="Tarefas concluídas antes do vencimento" />
                      <ScorePillarBar icon={<CalendarDays className="h-4 w-4 text-blue-500" />} label="Frequência de Uso" value={monthlyStats.scoreFrequencia} max={30} tooltip="Dias ativos no mês (ações ou tarefas concluídas)" />
                      <ScorePillarBar icon={<Target className="h-4 w-4 text-orange-500" />} label="Execução" value={monthlyStats.scoreExecucao} max={25} tooltip="Tarefas concluídas vs atribuídas" />
                      <ScorePillarBar icon={<Zap className="h-4 w-4 text-amber-500" />} label="Sem Atrasos" value={monthlyStats.scoreSemAtrasos} max={15} tooltip="Penalidade por tarefas vencidas (-3 pts cada)" />
                    </div>
                  )}
                </div>
              </SaasCard>

              {/* Level Explanation */}
              <LevelExplanationBlock
                currentLevel={profile.level}
                xpTotal={profile.xp_total}
                levelInfo={{ name: nivel.label, emoji: nivel.emoji }}
                nextLevelXp={getXpForLevel(profile.level).next}
                currentLevelXp={getXpForLevel(profile.level).current}
              />

              {/* Extrato de XP */}
              <Suspense fallback={<div className="py-4 text-center text-muted-foreground animate-pulse">Carregando extrato...</div>}>
                <XpExtratoLazy userId={sellerId} />
              </Suspense>

              {/* Ranking */}
              <RankingTab sellerId={sellerId} canSeeDetails={canSeeDetails} />

              {/* Regras de XP inline */}
              <Suspense fallback={<div className="py-4 text-center text-muted-foreground animate-pulse">Carregando regras...</div>}>
                <RegrasXPInline />
              </Suspense>
            </div>
          </TabsContent>
        )}

        {/* ABA 3 — RECONHECIMENTOS */}
        <TabsContent value="reconhecimentos">
          <ReconhecimentosTab
            sellerId={sellerId}
            isOwnProfile={isOwnProfile}
            isOwner={isOwner}
          />
        </TabsContent>

        {/* ABA 5 — ESTRELAS (removed from tabs for administrativo) */}

        {/* LOJA H&H TAB */}
        {!isProfileGestor && (
          <TabsContent value="loja">
            <Suspense fallback={<div className="py-8 text-center text-[#121216]/40 animate-pulse">Carregando loja...</div>}>
              <LojaHH sellerId={sellerId} isOwnProfile={isOwnProfile} />
            </Suspense>
          </TabsContent>
        )}

        {/* LOJA GESTÃO TAB */}
        {isProfileGestor && (
          <TabsContent value="loja-gestao">
            <Suspense fallback={<div className="py-8 text-center text-[#121216]/40 animate-pulse">Carregando gestão...</div>}>
              <LojaGestorQueue />
            </Suspense>
          </TabsContent>
        )}

        {/* ESTRELAS TAB */}
        <TabsContent value="estrelas">
          <Suspense fallback={<div className="py-8 text-center text-[#121216]/40 animate-pulse">Carregando estrelas...</div>}>
            <EstrelasProfileTab sellerId={sellerId} />
          </Suspense>
        </TabsContent>

        {/* ESTRELAS GESTÃO TAB */}
        {isProfileGestor && (
          <TabsContent value="estrelas-gestao">
            <Suspense fallback={<div className="py-8 text-center text-[#121216]/40 animate-pulse">Carregando gestão...</div>}>
              <EstrelasGestorPanel />
            </Suspense>
          </TabsContent>
        )}

        {/* ABA REGRAS DO SISTEMA */}
        <TabsContent value="regras">
          <RulebookTab />
        </TabsContent>

        {/* REGRAS GESTÃO TAB */}
        {isProfileGestor && (
          <TabsContent value="regras-gestao">
            <Suspense fallback={<div className="py-8 text-center text-[#121216]/40 animate-pulse">Carregando gestão...</div>}>
              <RulebookGestorPanel />
            </Suspense>
          </TabsContent>
        )}

        {/* QUALIDADE TAB */}
        {(isOwnProfile || canSeeDetails) && (
          <TabsContent value="qualidade">
            <QualidadeTab
              sellerId={sellerId}
              erros={erros}
              errosAtivosMes={errosAtivosMes}
              registrarErro={registrarErro}
              invalidarErro={invalidarErro}
              canRegister={canSeeDetails && currentSeller?.id !== sellerId}
              canInvalidate={canSeeDetails}
              isOwnProfile={isOwnProfile}
            />
          </TabsContent>
        )}

        {/* EVOLUÇÃO TAB */}
        {(isOwnProfile || canSeeDetails) && (
          <TabsContent value="evolucao">
            <div className="mt-4">
              <Suspense fallback={
                <Card className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-sm border border-white/60">
                  <CardContent className="p-8 text-center text-[#121216]/40">
                    <div className="animate-pulse">Carregando Evolução...</div>
                  </CardContent>
                </Card>
              }>
                <SellerEvolution />
              </Suspense>
            </div>
          </TabsContent>
        )}

        {/* CAMPANHAS TAB */}
        {(isOwnProfile || canSeeDetails) && (
          <TabsContent value="campanhas">
            <div className="mt-4">
              <Suspense fallback={
                <Card className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-sm border border-white/60">
                  <CardContent className="p-8 text-center text-[#121216]/40">
                    <div className="animate-pulse">Carregando Campanhas...</div>
                  </CardContent>
                </Card>
              }>
                {isOwner && isOwnProfile ? (
                  <CampanhaGestorPanel />
                ) : (
                  <CampanhaSellerView sellerId={sellerId} />
                )}
              </Suspense>
            </div>
          </TabsContent>
        )}

        {/* INCENTIVO TAB */}
        <TabsContent value="incentivo">
          <div className="mt-4">
            <Suspense fallback={<div className="py-8 text-center text-muted-foreground animate-pulse">Carregando...</div>}>
              {isOwner && isOwnProfile ? (
                <IncentiveCampaignGestor />
              ) : (
                <IncentiveCampaignPublic />
              )}
            </Suspense>
          </div>
        </TabsContent>

        {/* HISTÓRICO TAB */}
        <TabsContent value="historico">
          {isProfileAdministrativo && !isProfileGestor ? (
            <DepartmentHistoricoTab sellerId={sellerId} department={profile.department || null} />
          ) : (
            <HistoricoTab sellerId={sellerId} isVisitor={!isOwnProfile && !canSeeDetails} />
          )}
        </TabsContent>
      </Tabs>

      {/* Quality indicator for visitors on vendedor profiles */}
      {isProfileComercial && !isOwnProfile && !canSeeDetails && (
        <Card className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-sm border border-white/60">
          <CardContent className="p-4 flex items-center gap-3">
            <Shield className="h-5 w-5 text-[#121216]/40" />
            <span className="text-sm text-[#121216]">Qualidade:</span>
            <Badge
              variant="outline"
              className={
                (errosAtivosMes?.length || 0) === 0 ? 'text-emerald-600 border-emerald-200' :
                (errosAtivosMes?.length || 0) <= 3 ? 'text-amber-600 border-amber-200' :
                'text-red-600 border-red-200'
              }
            >
              {(errosAtivosMes?.length || 0) === 0 ? 'OK' : (errosAtivosMes?.length || 0) <= 3 ? 'Alerta' : 'Crítico'}
            </Badge>
          </CardContent>
        </Card>
      )}

      {/* Recognition inline form */}
      {reconhecerOpen && !isOwnProfile && (
        <InlineReconhecerForm
          sellerId={sellerId}
          darReconhecimento={darReconhecimento}
          carteira={carteira}
          isOwner={isOwner}
          onClose={() => setReconhecerOpen(false)}
        />
      )}

      {/* Mural H&H Feed — inside Visão Geral area */}

      {/* Edit modal */}
      {editOpen && (
        <ProfileEditModal
          open={editOpen}
          onOpenChange={setEditOpen}
          profile={profile}
          onSaved={refetch}
        />
      )}

      {/* Award Stars Modal (Master only) */}
      {awardStarsOpen && isOwner && !isOwnProfile && (
        <Suspense fallback={null}>
          <LazyAwardStarsModal
            open={awardStarsOpen}
            onOpenChange={setAwardStarsOpen}
            sellers={[{ id: sellerId, name: profile.name }]}
            onSuccess={refetch}
          />
        </Suspense>
      )}

      {/* HCoins Modal (Master only) */}
      {hcoinsModalOpen && isOwner && !isOwnProfile && (
        <Suspense fallback={null}>
          <LazyRecognitionModalTop
            open={hcoinsModalOpen}
            onOpenChange={setHcoinsModalOpen}
            preselectedUserId={sellerId}
            onSuccess={refetch}
          />
        </Suspense>
      )}
    </div>
  );
}

// ===== MINI STAT CARD =====
function getXpForLevel(level: number): { current: number; next: number } {
  const thresholds = [0, 100, 300, 600, 1000, 1500, 2200, 3000, 4000, 5500, 7500, 10000, 13000, 17000, 22000, 28000, 35000, 45000, 60000, 80000];
  const currentThreshold = thresholds[Math.min(level - 1, thresholds.length - 1)] || 0;
  const nextThreshold = thresholds[Math.min(level, thresholds.length - 1)] || currentThreshold + 5000;
  return { current: currentThreshold, next: nextThreshold };
}

function MiniStatCard({ icon, value, label, xpProgress }: { icon: React.ReactNode; value: number | string; label: string; xpProgress?: { level: number; xpTotal: number } }) {
  const xpBar = xpProgress ? (() => {
    const { current, next } = getXpForLevel(xpProgress.level);
    const inLevel = Math.max(0, xpProgress.xpTotal - current);
    const needed = Math.max(1, next - current);
    return Math.min(100, Math.round((inLevel / needed) * 100));
  })() : null;

  return (
    <SaasCard className="p-4 md:p-5">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-xl bg-gray-50 flex items-center justify-center shrink-0">{icon}</div>
          <div className="min-w-0 flex-1">
            <p className="text-lg md:text-xl font-bold text-gray-900 leading-none">{typeof value === 'number' ? value.toLocaleString('pt-BR') : value}</p>
            <p className="text-[10px] text-gray-400 uppercase tracking-wider mt-1 font-medium">{label}</p>
          </div>
        </div>
        {xpBar !== null && (
          <div className="mt-3 space-y-1">
            <div className="h-1.5 w-full bg-gray-100 rounded-full overflow-hidden">
              <div className="h-full bg-gradient-to-r from-[#3B5BDB] to-[#5B7EF5] rounded-full transition-all" style={{ width: `${xpBar}%` }} />
            </div>
            <p className="text-[9px] text-gray-400 text-right">{xpBar}% para Nível {xpProgress!.level + 1}</p>
          </div>
        )}
    </SaasCard>
  );
}

// ===== SCORE PILLAR BAR =====
function ScorePillarBar({ icon, label, value, max, tooltip }: { icon: React.ReactNode; label: string; value: number; max: number; tooltip: string }) {
  const pct = max > 0 ? (value / max) * 100 : 0;
  const barColor = pct >= 70 ? 'bg-emerald-500' : pct >= 40 ? 'bg-amber-500' : 'bg-red-500';

  return (
    <div className="space-y-1.5" title={tooltip}>
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="h-7 w-7 rounded-lg bg-gray-50 flex items-center justify-center">{icon}</div>
          <span className="text-xs font-medium text-gray-600">{label}</span>
        </div>
        <span className="text-xs font-bold text-gray-900">{value}/{max}</span>
      </div>
      <div className="h-2 rounded-full bg-gray-100 overflow-hidden">
        <div className={`h-full rounded-full transition-all duration-500 ${barColor}`} style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}


function InlineReconhecerForm({ sellerId, darReconhecimento, carteira, isOwner, onClose }: any) {
  const [tipo, setTipo] = useState<string>('CURTIDA');
  const [categoria, setCategoria] = useState<string>('OUTRO');
  const [comentario, setComentario] = useState('');
  const [quantidade, setQuantidade] = useState(1);

  const handleSubmit = async () => {
    await darReconhecimento({
      vendedor_recebe_id: sellerId,
      tipo,
      categoria,
      comentario: comentario || undefined,
      quantidade: tipo === 'HCOIN' ? quantidade : 1,
    });
    onClose();
  };

  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}>
      <Card className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-sm border border-white/60">
        <CardHeader className="pb-2">
          <CardTitle className="text-base text-[#121216]">Reconhecer</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs text-[#121216]/60">Tipo</Label>
              <Select value={tipo} onValueChange={setTipo}>
                <SelectTrigger className="rounded-xl"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="CURTIDA">
                    <span className="flex items-center gap-1.5"><CurtidaIcon size={16} /> Curtida</span>
                  </SelectItem>
                  <SelectItem value="HCOIN">
                    <span className="flex items-center gap-1.5"><HCoinIcon size={16} /> HCoin</span>
                  </SelectItem>
                  {isOwner && (
                    <SelectItem value="ESTRELA">
                      <span className="flex items-center gap-1.5"><EstrelaIcon size={16} /> Estrela</span>
                    </SelectItem>
                  )}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs text-[#121216]/60">Categoria</Label>
              <Select value={categoria} onValueChange={setCategoria}>
                <SelectTrigger className="rounded-xl"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {Object.entries(CATEGORIA_LABELS).map(([k, v]) => (
                    <SelectItem key={k} value={k}>{v}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {tipo === 'HCOIN' && (
            <div>
              <Label className="text-xs text-[#121216]/60">Quantidade (max 10)</Label>
              <Input
                type="number"
                min={1}
                max={10}
                value={quantidade}
                onChange={e => setQuantidade(Math.max(1, Math.min(10, Number(e.target.value))))}
                className="rounded-xl w-24"
              />
            </div>
          )}

          <div>
            <Label className="text-xs text-[#121216]/60">
              Comentário {(tipo === 'HCOIN' || tipo === 'ESTRELA') ? '(obrigatório)' : '(opcional)'}
            </Label>
            <Textarea value={comentario} onChange={e => setComentario(e.target.value)} placeholder="Motivo..." rows={2} className="rounded-xl" />
          </div>
          <div className="flex items-center gap-3">
            <p className="text-xs text-[#121216]/40 flex items-center gap-2">
              Saldo: <HCoinIcon size={14} /> {isOwner ? '∞' : carteira.saldo_hcoins} · <EstrelaIcon size={14} /> {isOwner ? '∞' : carteira.saldo_estrelas}
            </p>
            <div className="flex-1" />
            <Button onClick={onClose} variant="ghost" size="sm" className="rounded-xl">Cancelar</Button>
            <Button onClick={handleSubmit} size="sm" className="rounded-xl bg-[#FF6A00] hover:bg-[#FF6A00]/90 text-white">Enviar</Button>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

// ===== RECONHECIMENTOS TAB =====
function ReconhecimentosTab({ sellerId, isOwnProfile, isOwner }: { sellerId: string; isOwnProfile: boolean; isOwner: boolean }) {
  const { seller: currentSeller } = useAuth();
  const [recogs, setRecogs] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editMessage, setEditMessage] = useState('');
  const [saving, setSaving] = useState(false);

  const fetchRecogs = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase
      .from('recognitions')
      .select('*, from_seller:sellers!recognitions_from_user_id_fkey(name, avatar_url), to_seller:sellers!recognitions_to_user_id_fkey(name, avatar_url)')
      .or(`to_user_id.eq.${sellerId},from_user_id.eq.${sellerId}`)
      .order('created_at', { ascending: false })
      .limit(30);
    setRecogs(data || []);
    setLoading(false);
  }, [sellerId]);

  useEffect(() => { fetchRecogs(); }, [fetchRecogs]);

  const handleStartEdit = (r: any) => {
    setEditingId(r.id);
    setEditMessage(r.message || '');
  };

  const handleSaveEdit = async (id: string) => {
    if (!editMessage.trim()) return;
    setSaving(true);
    const { error } = await supabase
      .from('recognitions')
      .update({ message: editMessage.trim() })
      .eq('id', id);
    if (error) {
      toast('Erro ao salvar edição');
    } else {
      setRecogs(prev => prev.map(r => r.id === id ? { ...r, message: editMessage.trim() } : r));
      toast.success('Mensagem atualizada');
    }
    setEditingId(null);
    setSaving(false);
  };

  const LazyRecognitionModal = lazy(() => import('./RecognitionModal').then(m => ({ default: m.RecognitionModal })));

  return (
    <div className="mt-4 space-y-3">
      {!isOwnProfile && (
        <Button onClick={() => setModalOpen(true)} className="w-full rounded-xl bg-[#FF6A00] hover:bg-[#FF6A00]/90 text-white gap-2">
          <Heart className="h-4 w-4" /> Reconhecer {isOwnProfile ? '' : 'este colaborador'}
        </Button>
      )}

      {loading ? (
        <p className="text-sm text-[#121216]/40 text-center py-8 animate-pulse">Carregando...</p>
      ) : (
        <div className="space-y-2">
          {recogs.map((r: any) => {
            const isReceived = r.to_user_id === sellerId;
            const otherName = isReceived ? r.from_seller?.name : r.to_seller?.name;
            const hasTransfer = r.xp_transferred > 0 || r.hcoins_transferred > 0;
            const isAuthor = currentSeller?.id === r.from_user_id;
            const isEditing = editingId === r.id;

            return (
              <Card key={r.id} className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-sm border border-white/60">
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <div className="h-8 w-8 rounded-full bg-[#FF6A00]/10 flex items-center justify-center shrink-0">
                      <Heart className="h-4 w-4 text-[#FF6A00]" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-xs font-medium text-[#121216]">
                          {isReceived ? `De ${otherName || '?'}` : `Para ${otherName || '?'}`}
                        </span>
                        <Badge variant="outline" className="text-[10px] rounded-lg">{REASON_LABELS[r.reason_code] || r.reason_code}</Badge>
                        {hasTransfer && (
                          <Badge variant="outline" className="text-[10px] rounded-lg bg-amber-50 text-amber-700 border-amber-200">
                            {r.xp_transferred > 0 && 'Transferiu XP'}
                            {r.xp_transferred > 0 && r.hcoins_transferred > 0 && ' + '}
                            {r.hcoins_transferred > 0 && 'HCoins'}
                          </Badge>
                        )}
                        <span className="text-[10px] text-[#121216]/30">
                          {format(parseISO(r.created_at), 'dd/MM HH:mm', { locale: ptBR })}
                        </span>
                      </div>

                      {isEditing ? (
                        <div className="mt-1.5 space-y-2">
                          <Input
                            value={editMessage}
                            onChange={e => setEditMessage(e.target.value)}
                            className="text-sm rounded-xl h-8"
                            autoFocus
                          />
                          <div className="flex gap-1.5">
                            <Button size="sm" variant="ghost" onClick={() => setEditingId(null)} className="h-6 text-[10px] rounded-lg px-2">
                              Cancelar
                            </Button>
                            <Button
                              size="sm"
                              onClick={() => handleSaveEdit(r.id)}
                              disabled={saving || !editMessage.trim()}
                              className="h-6 text-[10px] rounded-lg px-2 bg-[#FF6A00] hover:bg-[#FF6A00]/90 text-white"
                            >
                              {saving ? 'Salvando...' : 'Salvar'}
                            </Button>
                          </div>
                        </div>
                      ) : (
                        <div className="flex items-start gap-1.5 mt-0.5">
                          <p className="text-sm text-[#121216]/70 line-clamp-2 flex-1">{r.message}</p>
                          {isAuthor && (
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-5 w-5 shrink-0 text-[#121216]/30 hover:text-[#121216]/60"
                              onClick={() => handleStartEdit(r)}
                              title="Editar mensagem"
                            >
                              <Edit3 className="h-3 w-3" />
                            </Button>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
          {recogs.length === 0 && (
            <p className="text-sm text-[#121216]/40 text-center py-8">Nenhum reconhecimento ainda</p>
          )}
        </div>
      )}

      {modalOpen && (
        <Suspense fallback={null}>
          <LazyRecognitionModal
            open={modalOpen}
            onOpenChange={setModalOpen}
            preselectedUserId={isOwnProfile ? undefined : sellerId}
            onSuccess={fetchRecogs}
          />
        </Suspense>
      )}
    </div>
  );
}

// ===== RANKING TAB =====
function RankingTab({ sellerId, canSeeDetails }: { sellerId: string; canSeeDetails: boolean }) {
  const [sellers, setSellers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [rankingMode, setRankingMode] = useState<'xp_total' | 'xp_month' | 'hcoins_total' | 'hcoins_month'>('xp_total');

  useEffect(() => {
    const fetchRanking = async () => {
      const { data } = await supabase
        .from('sellers')
        .select('id, name, avatar_url, nivel_atual, xp_total, xp_month, hcoins_balance, hcoins_earned_total, role, department, is_manager')
        .eq('status', 'ATIVO');
      // Exclude gestores from ranking
      const filtered = (data || []).filter((s: any) => !(s.is_manager && s.role === 'master'));
      setSellers(filtered);
      setLoading(false);
    };
    fetchRanking();
  }, []);

  if (loading) return <div className="py-8 text-center text-[#121216]/40">Carregando ranking...</div>;

  const getSortKey = (s: any) => {
    if (rankingMode === 'xp_total') return s.xp_total || 0;
    if (rankingMode === 'xp_month') return s.xp_month || 0;
    if (rankingMode === 'hcoins_total') return s.hcoins_earned_total || 0;
    return s.hcoins_balance || 0;
  };

  const sorted = [...sellers].sort((a, b) => getSortKey(b) - getSortKey(a));

  const modeLabel = {
    xp_total: 'XP Total',
    xp_month: 'XP Mês',
    hcoins_total: 'HCoins Total',
    hcoins_month: 'HCoins Saldo',
  };

  const modeUnit = rankingMode.startsWith('xp') ? 'XP' : 'HC';

  return (
    <Card className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-sm border border-white/60">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2 text-[#121216]">
            <Trophy className="h-4 w-4 text-[#FF6A00]" /> Ranking Geral
          </CardTitle>
          <Select value={rankingMode} onValueChange={(v: any) => setRankingMode(v)}>
            <SelectTrigger className="w-[140px] h-8 rounded-xl text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="xp_total">XP Total</SelectItem>
              <SelectItem value="xp_month">XP Mês</SelectItem>
              <SelectItem value="hcoins_total">HCoins Total</SelectItem>
              <SelectItem value="hcoins_month">HCoins Saldo</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <div className="divide-y divide-[#F4F4F4]">
          {sorted.map((s, i) => {
            const nivel = NIVEL_CONFIG[s.nivel_atual] || NIVEL_CONFIG.OVO;
            const isMe = s.id === sellerId;
            return (
              <div key={s.id} className={`flex items-center gap-3 px-4 py-3 ${isMe ? 'bg-[#FF6A00]/5' : ''}`}>
                <span className="text-lg font-bold text-[#121216]/30 w-8 text-center">
                  {i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `${i + 1}º`}
                </span>
                <Avatar className="h-8 w-8">
                  <AvatarImage src={s.avatar_url || undefined} />
                  <AvatarFallback className="text-xs bg-[#F4F4F4] text-[#121216]">{s.name?.[0]}</AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <p className={`text-sm font-medium truncate ${isMe ? 'text-[#FF6A00] font-bold' : 'text-[#121216]'}`}>{s.name}</p>
                </div>
                <div className="text-right">
                  <span className="text-sm font-bold text-[#121216]">{getSortKey(s)}</span>
                  <span className="text-[10px] text-[#121216]/40 ml-1">{modeUnit}</span>
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}

// ===== QUALIDADE TAB =====
function QualidadeTab({ sellerId, erros, errosAtivosMes, registrarErro, invalidarErro, canRegister, canInvalidate, isOwnProfile }: any) {
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({ tipo: '', origem: '', descricao: '' });
  const [invalidando, setInvalidando] = useState<string | null>(null);
  const [motivoInvalidacao, setMotivoInvalidacao] = useState('');

  const handleSubmit = async () => {
    if (!formData.tipo || !formData.origem || !formData.descricao.trim()) return;
    await registrarErro({ vendedor_id: sellerId, tipo: formData.tipo, origem: formData.origem, descricao: formData.descricao });
    setFormData({ tipo: '', origem: '', descricao: '' });
    setShowForm(false);
  };

  const handleInvalidar = async (erroId: string) => {
    await invalidarErro(erroId, motivoInvalidacao);
    setInvalidando(null);
    setMotivoInvalidacao('');
  };

  return (
    <div className="mt-4 space-y-3">
      <Card className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-sm border border-white/60">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Shield className="h-5 w-5 text-[#121216]/40" />
              <div>
                <p className="text-sm font-medium text-[#121216]">Erros Críticos do Mês</p>
                <p className="text-2xl font-bold text-[#121216]">{errosAtivosMes?.length || 0}</p>
              </div>
            </div>
            {canRegister && (
              <Button variant="outline" size="sm" onClick={() => setShowForm(!showForm)} className="rounded-xl text-xs">
                <AlertTriangle className="h-3.5 w-3.5 mr-1" /> Registrar Erro
              </Button>
            )}
          </div>

          {showForm && canRegister && (
            <div className="mt-4 space-y-3 border-t border-[#F4F4F4] pt-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-xs text-[#121216]/60">Tipo</Label>
                  <Select value={formData.tipo} onValueChange={v => setFormData(p => ({ ...p, tipo: v }))}>
                    <SelectTrigger className="rounded-xl"><SelectValue placeholder="Selecione" /></SelectTrigger>
                    <SelectContent>
                      {Object.entries(ERRO_TIPO_LABELS).map(([k, v]) => (
                        <SelectItem key={k} value={k}>{v}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-xs text-[#121216]/60">Origem</Label>
                  <Select value={formData.origem} onValueChange={v => setFormData(p => ({ ...p, origem: v }))}>
                    <SelectTrigger className="rounded-xl"><SelectValue placeholder="Selecione" /></SelectTrigger>
                    <SelectContent>
                      {Object.entries(ERRO_ORIGEM_LABELS).map(([k, v]) => (
                        <SelectItem key={k} value={k}>{v}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div>
                <Label className="text-xs text-[#121216]/60">Descrição</Label>
                <Textarea
                  value={formData.descricao}
                  onChange={e => setFormData(p => ({ ...p, descricao: e.target.value }))}
                  placeholder="Descreva o erro..."
                  rows={2}
                  className="rounded-xl"
                />
              </div>
              <Button onClick={handleSubmit} size="sm" className="rounded-xl bg-[#FF6A00] hover:bg-[#FF6A00]/90 text-white">
                Registrar
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      <div className="space-y-2">
        {(erros || []).map((erro: any) => (
          <Card key={erro.id} className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-sm border border-white/60">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {erro.status === 'ativo' ? (
                    <ShieldAlert className="h-4 w-4 text-red-500" />
                  ) : erro.status === 'invalidado' ? (
                    <XCircle className="h-4 w-4 text-gray-400" />
                  ) : (
                    <CheckCircle className="h-4 w-4 text-emerald-500" />
                  )}
                  <Badge variant="outline" className="text-xs rounded-lg">{ERRO_TIPO_LABELS[erro.tipo] || erro.tipo}</Badge>
                  <Badge variant="outline" className="text-xs rounded-lg">{ERRO_ORIGEM_LABELS[erro.origem] || erro.origem}</Badge>
                  <span className="text-xs text-[#121216]/40">
                    {format(parseISO(erro.data || erro.created_at), 'dd/MM', { locale: ptBR })}
                  </span>
                </div>
                {canInvalidate && erro.status === 'ativo' && (
                  <Button variant="ghost" size="sm" onClick={() => setInvalidando(invalidando === erro.id ? null : erro.id)} className="text-xs rounded-xl">
                    Contestar
                  </Button>
                )}
              </div>
              <p className="text-sm text-[#121216]/70 mt-1">{erro.descricao}</p>
              {erro.motivo_invalidado && (
                <p className="text-xs text-amber-600 mt-1">Motivo invalidação: {erro.motivo_invalidado}</p>
              )}
              {invalidando === erro.id && (
                <div className="mt-2 flex gap-2">
                  <Input value={motivoInvalidacao} onChange={e => setMotivoInvalidacao(e.target.value)} placeholder="Motivo da contestação..." className="rounded-xl flex-1 text-xs" />
                  <Button onClick={() => handleInvalidar(erro.id)} size="sm" className="rounded-xl text-xs">Enviar</Button>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}

// ===== ESTRELAS TAB =====
function EstrelasTab({ sellerId, carteira }: { sellerId: string; carteira: any }) {
  const [stars, setStars] = useState<any>(null);
  const [achievements, setAchievements] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetch = async () => {
      const [starsRes, achievementsRes] = await Promise.all([
        supabase.from('seller_stars').select('*').eq('seller_id', sellerId).maybeSingle(),
        supabase.from('category_achievements').select('*').eq('seller_id', sellerId).order('achieved_at', { ascending: false }).limit(20),
      ]);
      setStars(starsRes.data);
      setAchievements(achievementsRes.data || []);
      setLoading(false);
    };
    fetch();
  }, [sellerId]);

  if (loading) return <div className="py-8 text-center text-[#121216]/40">Carregando estrelas...</div>;

  return (
    <div className="mt-4 space-y-4">
      <Card className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-sm border border-white/60">
        <CardHeader className="pb-2">
          <CardTitle className="text-base text-[#121216] flex items-center gap-2">
            <Star className="h-4 w-4 text-[#FF6A00]" /> Estrelas
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="text-center p-4 rounded-xl bg-amber-50">
              <p className="text-3xl">🥉</p>
              <p className="text-2xl font-bold text-[#121216] mt-1">{stars?.bronze_stars || 0}</p>
              <p className="text-xs text-[#121216]/50">Bronze</p>
            </div>
            <div className="text-center p-4 rounded-xl bg-gray-50">
              <p className="text-3xl">🥈</p>
              <p className="text-2xl font-bold text-[#121216] mt-1">{stars?.silver_stars || 0}</p>
              <p className="text-xs text-[#121216]/50">Prata</p>
            </div>
            <div className="text-center p-4 rounded-xl bg-yellow-50">
              <p className="text-3xl">🥇</p>
              <p className="text-2xl font-bold text-[#121216] mt-1">{stars?.gold_stars || 0}</p>
              <p className="text-xs text-[#121216]/50">Ouro</p>
            </div>
            <div className="text-center p-4 rounded-xl bg-purple-50">
              <p className="text-3xl">💎</p>
              <p className="text-2xl font-bold text-[#121216] mt-1">{stars?.crystal_stars || 0}</p>
              <p className="text-xs text-[#121216]/50">Cristal</p>
            </div>
          </div>

          {stars?.current_streak > 0 && (
            <div className="mt-4 p-3 rounded-xl bg-[#FF6A00]/5 text-center">
              <p className="text-sm text-[#121216]">🔥 Sequência atual: <span className="font-bold text-[#FF6A00]">{stars.current_streak} meses</span></p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Achievement history */}
      {achievements.length > 0 && (
        <Card className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-sm border border-white/60">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-[#121216]/60">Histórico de Conquistas</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="divide-y divide-[#F4F4F4]">
              {achievements.map(a => (
                <div key={a.id} className="px-4 py-3 flex items-center gap-3">
                  <EstrelaIcon size={18} />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-[#121216] truncate">{a.category_key}</p>
                    <p className="text-xs text-[#121216]/40">{a.competencia} · {a.stars_awarded} estrela(s)</p>
                  </div>
                  <span className="text-xs text-[#121216]/40">{format(parseISO(a.achieved_at), 'dd/MM/yy', { locale: ptBR })}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

// ===== RULEBOOK TAB =====
function RulebookTab() {
  const [hasRead, setHasRead] = useState(false);

  const { seller: rbUser } = useAuth();
  const rbQueryClient = useQueryClient();
  const rbUserId = rbUser?.id;
  const { data: activeRulebook, isLoading: loadingRb } = useQuery({
    queryKey: ['active-rulebook-tab'],
    queryFn: async () => {
      const { data } = await (supabase as any).from('rulebook').select('*').eq('is_active', true).limit(1).maybeSingle();
      return data;
    },
    staleTime: 1000 * 60 * 5,
  });

  const { data: acceptance, isLoading: loadingAcc } = useQuery({
    queryKey: ['rulebook-acceptance-tab', rbUserId, activeRulebook?.id],
    queryFn: async () => {
      if (!rbUserId || !activeRulebook?.id) return null;
      const { data } = await (supabase as any).from('rulebook_acceptance').select('*').eq('user_id', rbUserId).eq('rulebook_id', activeRulebook.id).maybeSingle();
      return data;
    },
    enabled: !!rbUserId && !!activeRulebook?.id,
    staleTime: 1000 * 60 * 5,
  });

  const hasAccepted = !!acceptance;
  const loading = loadingRb || loadingAcc;
  const [accepting, setAccepting] = useState(false);

  const handleAccept = async () => {
    if (!rbUserId || !activeRulebook) return;
    setAccepting(true);
    try {
      const { error } = await (supabase as any).from('rulebook_acceptance').insert({
        user_id: rbUserId,
        rulebook_id: activeRulebook.id,
        accepted_user_agent: navigator.userAgent,
      });
      if (error) throw error;
      rbQueryClient.invalidateQueries({ queryKey: ['rulebook-acceptance-tab'] });
      toast.success('Regulamento aceito com sucesso!');
    } catch {
      toast.error('Erro ao aceitar regulamento');
    }
    setAccepting(false);
  };

  if (loading) return <div className="py-8 text-center text-[#121216]/40 animate-pulse">Carregando regras...</div>;

  return (
    <div className="mt-4 space-y-4">
      {/* Acceptance banner */}
      {activeRulebook && !hasAccepted && (
        <Card className="bg-amber-50/80 border-amber-200 rounded-2xl shadow-sm">
          <CardContent className="p-4 flex items-start gap-3">
            <AlertTriangle className="h-5 w-5 text-amber-600 mt-0.5 shrink-0" />
            <div className="flex-1">
              <p className="text-sm font-semibold text-amber-800">Aceite pendente</p>
              <p className="text-xs text-amber-700 mt-0.5">
                Você pode trabalhar normalmente, mas <strong>bônus, loja e campanhas ficam bloqueados</strong> até aceitar o regulamento vigente ({activeRulebook.version_label}).
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      {activeRulebook && hasAccepted && (
        <Card className="bg-emerald-50/80 border-emerald-200 rounded-2xl shadow-sm">
          <CardContent className="p-4 flex items-center gap-3">
            <CheckCircle className="h-5 w-5 text-emerald-600 shrink-0" />
            <div>
              <p className="text-sm font-semibold text-emerald-800">Regulamento aceito</p>
              <p className="text-xs text-emerald-700 mt-0.5">
                Versão {activeRulebook.version_label} — aceito em {acceptance?.accepted_at ? format(parseISO(acceptance.accepted_at), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR }) : ''}.
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Content */}
      <Card className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-sm border border-white/60">
        <CardHeader>
          <CardTitle className="text-base text-[#121216] flex items-center gap-2">
            <BookOpen className="h-4 w-4 text-[#FF6A00]" /> Regulamento do Sistema
            {activeRulebook && (
              <Badge variant="outline" className="text-[10px] rounded-lg ml-auto">{activeRulebook.version_label}</Badge>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Suspense fallback={<div className="py-4 animate-pulse text-[#121216]/40">Carregando...</div>}>
            <RulebookContentComponent />
          </Suspense>
        </CardContent>
      </Card>

      {/* Custom content from published rulebook */}
      {activeRulebook?.content_html && (
        <Card className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-sm border border-white/60">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-[#121216]/60">Conteúdo Adicional do Gestor</CardTitle>
          </CardHeader>
          <CardContent>
            <div
              className="prose prose-sm dark:prose-invert max-w-none max-h-[400px] overflow-y-auto p-3 rounded-xl bg-[#F4F4F4]/50"
              dangerouslySetInnerHTML={{ __html: activeRulebook.content_html }}
            />
          </CardContent>
        </Card>
      )}

      {/* Acceptance button */}
      {activeRulebook && !hasAccepted && (
        <Card className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-sm border border-white/60">
          <CardContent className="p-5 space-y-4">
            <div className="flex items-start gap-3">
              <input
                type="checkbox"
                id="read-rulebook"
                checked={hasRead}
                onChange={e => setHasRead(e.target.checked)}
                className="mt-1 rounded"
              />
              <label htmlFor="read-rulebook" className="text-sm text-[#121216]/70 cursor-pointer leading-relaxed">
                Declaro que li e compreendi o Regulamento do Sistema ({activeRulebook.title} {activeRulebook.version_label}).
              </label>
            </div>
            <Button
              onClick={handleAccept}
              disabled={!hasRead || accepting}
              className="w-full rounded-xl gap-2"
              size="lg"
            >
              {accepting ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <CheckCircle className="h-4 w-4" />
              )}
              Li e Concordo
            </Button>
            <p className="text-xs text-[#121216]/40 text-center">Seu aceite será registrado com data, hora e navegador.</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

// ===== HISTORICO TAB =====
function HistoricoTab({ sellerId, isVisitor }: { sellerId: string; isVisitor: boolean }) {
  const [events, setEvents] = useState<any[]>([]);
  const [docs, setDocs] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchHistory = async () => {
      const [eventsRes, docsRes] = await Promise.all([
        supabase
          .from('feed_events')
          .select('*')
          .or(`actor_user_id.eq.${sellerId},target_user_id.eq.${sellerId}`)
          .eq('hidden', false)
          .order('created_at', { ascending: false })
          .limit(isVisitor ? 10 : 30),
        supabase
          .from('seller_levels')
          .select('id, versao_documento, pdf_metas_url, status_ciencia, ciente_em, enviado_para_ciencia_em')
          .eq('seller_id', sellerId)
          .not('pdf_metas_url', 'is', null)
      ]);
      setEvents(eventsRes.data || []);
      setDocs(docsRes.data || []);
      setLoading(false);
    };
    fetchHistory();
  }, [sellerId, isVisitor]);

  if (loading) return <div className="py-8 text-center text-[#121216]/40">Carregando histórico...</div>;

  return (
    <div className="mt-4 space-y-4">
      {docs.length > 0 && (
        <div>
          <h3 className="text-xs font-semibold text-[#121216]/50 uppercase tracking-wider mb-2 flex items-center gap-1.5">
            <History className="h-3.5 w-3.5" /> Documentos de Metas
          </h3>
          <div className="space-y-2">
            {docs.map(doc => (
              <Card key={doc.id} className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-sm border border-white/60">
                <CardContent className="p-4 flex items-center gap-3">
                  <div className="h-9 w-9 rounded-xl bg-[#FF6A00]/10 flex items-center justify-center shrink-0">
                    <History className="h-4 w-4 text-[#FF6A00]" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-[#121216]">Termo de Ciência — v{doc.versao_documento}</p>
                    <div className="flex items-center gap-2 mt-0.5">
                      <Badge variant="outline" className={`text-[10px] rounded-lg ${
                        doc.status_ciencia === 'CIENTE' ? 'bg-emerald-50 text-emerald-600 border-emerald-200' :
                        doc.status_ciencia === 'AGUARDANDO_CIENCIA' ? 'bg-amber-50 text-amber-600 border-amber-200' :
                        doc.status_ciencia === 'EXPIRADA' ? 'bg-red-50 text-red-600 border-red-200' :
                        'bg-gray-50 text-gray-600 border-gray-200'
                      }`}>
                        {doc.status_ciencia === 'CIENTE' ? '✅ Ciente' : doc.status_ciencia === 'AGUARDANDO_CIENCIA' ? '⏳ Aguardando' : doc.status_ciencia === 'EXPIRADA' ? '❌ Expirada' : doc.status_ciencia}
                      </Badge>
                      {doc.ciente_em && (
                        <span className="text-[10px] text-[#121216]/40">
                          {format(parseISO(doc.ciente_em), 'dd/MM/yyyy HH:mm', { locale: ptBR })}
                        </span>
                      )}
                    </div>
                  </div>
                  {doc.pdf_metas_url && (
                    <Button variant="ghost" size="sm" onClick={() => window.open(doc.pdf_metas_url, '_blank')} className="rounded-xl text-xs text-[#FF6A00]">
                      Abrir
                    </Button>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {events.map(ev => (
        <Card key={ev.id} className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-sm border border-white/60">
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="text-xs rounded-lg capitalize">{ev.type}</Badge>
              <span className="text-xs text-[#121216]/40">{format(parseISO(ev.created_at), 'dd/MM HH:mm', { locale: ptBR })}</span>
            </div>
            <p className="text-sm font-medium text-[#121216] mt-1">{ev.title}</p>
            {ev.subtitle && <p className="text-xs text-[#121216]/50 mt-0.5">{ev.subtitle}</p>}
          </CardContent>
        </Card>
      ))}
      {events.length === 0 && docs.length === 0 && (
        <p className="text-sm text-[#121216]/40 text-center py-8">Nenhum histórico ainda</p>
      )}
    </div>
  );
}
