import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { MessageCircle, Send, Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import { format, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface ProfileCommentsProps {
  profileUserId: string;
  isOwnProfile: boolean;
}

interface Comment {
  id: string;
  content: string;
  created_at: string;
  author_user_id: string;
  author_name?: string;
  author_avatar?: string;
}

export function ProfileComments({ profileUserId, isOwnProfile }: ProfileCommentsProps) {
  const { seller, isOwner } = useAuth();
  const [comments, setComments] = useState<Comment[]>([]);
  const [newComment, setNewComment] = useState('');
  const [sending, setSending] = useState(false);

  const fetchComments = useCallback(async () => {
    const { data } = await (supabase as any)
      .from('profile_comments')
      .select('id, content, created_at, author_user_id')
      .eq('profile_user_id', profileUserId)
      .order('created_at', { ascending: false })
      .limit(30);

    if (data && data.length > 0) {
      const authorIds = [...new Set(data.map((c: any) => c.author_user_id))];
      const { data: sellers } = await supabase
        .from('sellers')
        .select('id, name, avatar_url')
        .in('id', authorIds as string[]);

      const sellerMap = new Map((sellers || []).map(s => [s.id, s]));
      setComments(data.map((c: any) => ({
        ...c,
        author_name: sellerMap.get(c.author_user_id)?.name || 'Usuário',
        author_avatar: sellerMap.get(c.author_user_id)?.avatar_url || undefined,
      })));
    } else {
      setComments([]);
    }
  }, [profileUserId]);

  useEffect(() => { fetchComments(); }, [fetchComments]);

  const handleSend = async () => {
    if (!newComment.trim() || !seller?.id) return;
    setSending(true);
    try {
      const { error } = await (supabase as any)
        .from('profile_comments')
        .insert({
          profile_user_id: profileUserId,
          author_user_id: seller.id,
          content: newComment.trim().slice(0, 300),
        });
      if (error) throw error;
      setNewComment('');
      toast.success('Comentário enviado!');
      fetchComments();
    } catch {
      toast.error('Erro ao enviar comentário');
    } finally {
      setSending(false);
    }
  };

  const handleDelete = async (commentId: string) => {
    const { error } = await (supabase as any)
      .from('profile_comments')
      .delete()
      .eq('id', commentId);
    if (!error) {
      setComments(prev => prev.filter(c => c.id !== commentId));
      toast.success('Comentário removido');
    }
  };

  return (
    <Card className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-sm border border-white/60 mt-4">
      <CardHeader className="pb-2">
        <CardTitle className="text-base flex items-center gap-2 text-[#121216]">
          <MessageCircle className="h-4 w-4" /> Comentários
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {/* Input */}
        {seller && (
          <div className="flex gap-2">
            <Textarea
              value={newComment}
              onChange={e => setNewComment(e.target.value.slice(0, 300))}
              placeholder="Deixe um comentário..."
              rows={2}
              className="rounded-xl flex-1 text-sm"
              maxLength={300}
            />
            <Button
              size="sm"
              onClick={handleSend}
              disabled={sending || !newComment.trim()}
              className="rounded-xl bg-[#FF6A00] hover:bg-[#FF6A00]/90 text-white self-end"
            >
              <Send className="h-4 w-4" />
            </Button>
          </div>
        )}
        {newComment.length > 0 && (
          <p className="text-[10px] text-[#121216]/40 text-right">{newComment.length}/300</p>
        )}

        {/* Comments list */}
        <div className="space-y-2 max-h-[400px] overflow-y-auto">
          {comments.map(c => {
            const initials = (c.author_name || 'U').split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase();
            const canDelete = seller?.id === c.author_user_id || isOwner || isOwnProfile;
            return (
              <div key={c.id} className="flex gap-3 p-3 rounded-xl bg-white/60 border border-white/40">
                <Avatar className="h-8 w-8 flex-shrink-0">
                  <AvatarImage src={c.author_avatar || undefined} />
                  <AvatarFallback className="text-xs bg-[#F4F4F4]">{initials}</AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-medium text-[#121216]">{c.author_name}</span>
                    <span className="text-[10px] text-[#121216]/40">{format(parseISO(c.created_at), 'dd/MM HH:mm', { locale: ptBR })}</span>
                    {canDelete && (
                      <button onClick={() => handleDelete(c.id)} className="ml-auto text-[#121216]/30 hover:text-red-500 transition-colors">
                        <Trash2 className="h-3 w-3" />
                      </button>
                    )}
                  </div>
                  <p className="text-sm text-[#121216]/70 mt-0.5">{c.content}</p>
                </div>
              </div>
            );
          })}
          {comments.length === 0 && (
            <p className="text-sm text-[#121216]/40 text-center py-4">Nenhum comentário ainda. Seja o primeiro!</p>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
