import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { format, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Zap, TrendingUp, TrendingDown, Loader2 } from 'lucide-react';
import { motion } from 'framer-motion';

const EVENT_LABELS: Record<string, string> = {
  // Task (seller result-based)
  TASK_DONE: 'Tarefa concluída (resultado)',
  // Task (admin/logistics)
  TASK_DONE_ADMIN: 'Tarefa concluída',
  // Admin/task legacy
  ADMIN_TASK_ONTIME: 'Tarefa concluída no prazo',
  ADMIN_TASK_LATE: 'Tarefa concluída com atraso',
  // Cotação
  COTACAO_RESPONDIDA: 'Respondeu solicitação de orçamento',
  COTACAO_APROVADA: 'Orçamento aprovado',
  ADMIN_QUOTE_APPROVED: 'Cotação aprovada',
  cotacao_aprovada: 'Cotação aprovada',
  // Compras
  ADMIN_PURCHASE_ORDER: 'Ordem de compra criada',
  COMPRAS_FEED: 'Ação no feed de compras',
  ADMIN_FEED_ACTION: 'Ação no feed de compras',
  COMPRA_RECEBIDA: 'Mercadoria recebida',
  compra_created: 'Compra registrada',
  compras_feed: 'Ação no feed de compras',
  // Delivery
  DELIVERY_CONFIRMED: 'Entrega confirmada ao cliente',
  ENTREGA_CONCLUIDA: 'Entrega concluída',
  logistics_delivery: 'Entrega realizada',
  logistics_receiving: 'Recebimento de mercadoria',
  // Reabastecimento
  REABASTECIMENTO: 'Reabastecimento concluído',
  // Social / Feed
  FEED_POST: 'Postagem no feed',
  AVATAR_UPDATE: 'Atualização de foto de perfil',
  STATUS_POST: 'Status publicado',
  // Penalties
  TASK_OVERDUE_PENALTY: 'Penalidade: tarefa vencida',
  PENALTY_OVERDUE_4_15: 'Penalidade: atraso 4-15 dias',
  PENALTY_OVERDUE_15_30: 'Penalidade: atraso 15-30 dias',
  PENALTY_OVERDUE_30PLUS: 'Penalidade: atraso 30+ dias',
  PONTO_ESQUECIDO: 'Esquecimento de ponto',
  PONTO_DIARIO_SEM_CORRECAO: 'Ponto sem correção (diário)',
  // Bonuses
  MEDAL_BRONZE: 'Medalha de Bronze conquistada',
  MEDAL_PRATA: 'Medalha de Prata conquistada',
  MEDAL_OURO: 'Medalha de Ouro conquistada',
  HCOIN_RECEIVED: 'H-Coin recebida',
  HCOIN_PURCHASE: 'Conversão XP → H-Coin',
  PROFILE_COMPLETE: 'Perfil completo',
  CATEGORY_GOAL_MET: 'Meta de categoria atingida',
  AJUSTE_HISTORICO: 'Ajuste histórico',
  // Misc
  task_completed: 'Tarefa concluída',
  abastecimento: 'Abastecimento registrado',
};

function getLabel(eventType: string, meta: any): string {
  if (meta?.description) return meta.description;
  return EVENT_LABELS[eventType] || eventType.replace(/_/g, ' ');
}

interface XpExtratoProps {
  userId: string;
}

export function XpExtrato({ userId }: XpExtratoProps) {
  const { data: logs, isLoading } = useQuery({
    queryKey: ['xp-extrato', userId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('xp_log')
        .select('id, event_type, xp_delta, created_at, meta_json')
        .eq('user_id', userId)
        .order('created_at', { ascending: false })
        .limit(100);
      if (error) throw error;
      return data || [];
    },
    enabled: !!userId,
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!logs || logs.length === 0) {
    return (
      <Card className="border-dashed">
        <CardContent className="p-6 text-center">
          <Zap className="h-8 w-8 text-muted-foreground/30 mx-auto mb-2" />
          <p className="text-sm text-muted-foreground">Nenhuma movimentação de XP registrada</p>
        </CardContent>
      </Card>
    );
  }

  const totalGanho = logs.filter(l => l.xp_delta > 0).reduce((s, l) => s + l.xp_delta, 0);
  const totalPerdido = logs.filter(l => l.xp_delta < 0).reduce((s, l) => s + l.xp_delta, 0);

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.1 }} className="space-y-4">
      {/* Summary */}
      <div className="grid grid-cols-2 gap-3">
        <Card className="border-emerald-500/20 bg-emerald-500/[0.03]">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-emerald-500/10 flex items-center justify-center shrink-0">
              <TrendingUp className="h-5 w-5 text-emerald-600" />
            </div>
            <div>
              <p className="text-xl font-bold text-emerald-600 leading-none">+{totalGanho.toLocaleString('pt-BR')}</p>
              <p className="text-[11px] text-muted-foreground mt-0.5">XP ganho</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-red-500/20 bg-red-500/[0.03]">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-red-500/10 flex items-center justify-center shrink-0">
              <TrendingDown className="h-5 w-5 text-red-600" />
            </div>
            <div>
              <p className="text-xl font-bold text-red-600 leading-none">{totalPerdido.toLocaleString('pt-BR')}</p>
              <p className="text-[11px] text-muted-foreground mt-0.5">XP perdido</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Transaction list */}
      <Card>
        <CardContent className="p-0">
          <div className="px-4 py-3 border-b border-border">
            <h4 className="text-sm font-semibold flex items-center gap-2">
              <Zap className="h-4 w-4 text-amber-500" /> Extrato de XP
            </h4>
          </div>
          <ScrollArea className="max-h-[400px]">
            <div className="divide-y divide-border/60">
              {logs.map((log) => {
                const isPositive = log.xp_delta > 0;
                const label = getLabel(log.event_type, log.meta_json);
                return (
                  <div key={log.id} className="flex items-center gap-3 px-4 py-3 hover:bg-muted/30 transition-colors">
                    <div className={`h-7 w-7 rounded-full flex items-center justify-center shrink-0 ${
                      isPositive ? 'bg-emerald-500/10' : 'bg-red-500/10'
                    }`}>
                      {isPositive
                        ? <TrendingUp className="h-3.5 w-3.5 text-emerald-600" />
                        : <TrendingDown className="h-3.5 w-3.5 text-red-600" />
                      }
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm truncate">{label}</p>
                      <p className="text-[11px] text-muted-foreground">
                        {format(parseISO(log.created_at), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}
                      </p>
                    </div>
                    <Badge
                      variant="outline"
                      className={`text-xs font-semibold shrink-0 ${
                        isPositive
                          ? 'border-emerald-500/30 text-emerald-600 bg-emerald-500/[0.06]'
                          : 'border-red-500/30 text-red-600 bg-red-500/[0.06]'
                      }`}
                    >
                      {isPositive ? '+' : ''}{log.xp_delta} XP
                    </Badge>
                  </div>
                );
              })}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>
    </motion.div>
  );
}