import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { HCoinIcon } from './CoinIcons';
import { Zap, Search } from 'lucide-react';
import { toast } from 'sonner';

const REASON_CODES: Record<string, string> = {
  AJUDA_NA_NEGOCIACAO: 'Ajuda na negociação',
  VENDA_RELEVANTE: 'Venda relevante',
  EXCELENCIA_ATENDIMENTO: 'Excelência no atendimento',
  EXCELENCIA_OPERACIONAL: 'Excelência operacional',
  ORGANIZACAO_EXEMPLAR: 'Organização exemplar',
  INICIATIVA_ESTRATEGICA: 'Iniciativa estratégica',
  APOIO_A_EQUIPE: 'Apoio à equipe',
  ENTREGA_RAPIDA: 'Entrega rápida',
  RESOLVEU_PEPINO: 'Resolveu um pepino',
  OUTRO: 'Outro',
};

const CONTEXT_TYPES: Record<string, string> = {
  NONE: 'Sem contexto',
  CLIENT: 'Cliente',
  ORDER: 'Pedido',
  TASK: 'Tarefa',
  PURCHASE: 'Compras',
  DELIVERY: 'Recebimento/Entrega',
  FINANCE: 'Financeiro',
};

interface RecognitionModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  preselectedUserId?: string;
  onSuccess: () => void;
}

export function RecognitionModal({ open, onOpenChange, preselectedUserId, onSuccess }: RecognitionModalProps) {
  const { seller, isOwner } = useAuth();
  const [step, setStep] = useState(1);
  const [sellers, setSellers] = useState<any[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(false);

  // Form state
  const [toUserId, setToUserId] = useState(preselectedUserId || '');
  const [reasonCode, setReasonCode] = useState('');
  const [message, setMessage] = useState('');
  const [contextType, setContextType] = useState('NONE');
  const [transferXp, setTransferXp] = useState(false);
  const [transferHcoins, setTransferHcoins] = useState(false);
  const [xpAmount, setXpAmount] = useState(1);
  const [hcoinsAmount, setHcoinsAmount] = useState(1);

  // Sender info
  const [senderInfo, setSenderInfo] = useState<{ xp_month: number; hcoins_balance: number; xp_sent_this_month: number; hcoins_sent_this_month: number } | null>(null);

  useEffect(() => {
    if (!open) return;
    const fetchSellers = async () => {
      const { data } = await supabase
        .from('sellers')
        .select('id, name, avatar_url, role, department')
        .eq('status', 'ATIVO')
        .order('name');
      setSellers((data || []).filter((s: any) => s.id !== seller?.id));
    };
    const fetchSenderInfo = async () => {
      if (!seller?.id) return;
      const { data } = await supabase
        .from('sellers')
        .select('xp_month, hcoins_balance, xp_sent_this_month, hcoins_sent_this_month')
        .eq('id', seller.id)
        .maybeSingle();
      setSenderInfo(data as any);
    };
    fetchSellers();
    fetchSenderInfo();
  }, [open, seller?.id]);

  useEffect(() => {
    if (preselectedUserId) { setToUserId(preselectedUserId); setStep(2); }
  }, [preselectedUserId]);

  // Auto-generate message template
  useEffect(() => {
    if (!reasonCode || !toUserId) return;
    const target = sellers.find(s => s.id === toUserId);
    const reasonLabel = REASON_CODES[reasonCode] || reasonCode;
    if (target && !message) {
      setMessage(`Reconheço ${target.name} por ${reasonLabel.toLowerCase()}.`);
    }
  }, [reasonCode, toUserId]);

  const handleSubmit = async () => {
    if (!seller?.id || !toUserId || !reasonCode || !message.trim()) {
      toast.error('Preencha todos os campos obrigatórios');
      return;
    }

    const type = (transferXp || transferHcoins) ? 'WITH_TRANSFER' : 'SIMPLE';
    const xp = transferXp ? xpAmount : 0;
    const hcoins = transferHcoins ? hcoinsAmount : 0;

    setLoading(true);
    try {
      const { error } = await supabase.rpc('fn_send_recognition', {
        p_from_id: seller.id,
        p_to_id: toUserId,
        p_type: type,
        p_reason_code: reasonCode,
        p_message: message,
        p_context_type: contextType,
        p_context_ref_id: null,
        p_xp_amount: xp,
        p_hcoins_amount: hcoins,
      });

      if (error) throw error;

      toast.success('Reconhecimento enviado!');
      onOpenChange(false);
      onSuccess();
      // Reset
      setStep(1);
      setToUserId(preselectedUserId || '');
      setReasonCode('');
      setMessage('');
      setContextType('NONE');
      setTransferXp(false);
      setTransferHcoins(false);
      setXpAmount(1);
      setHcoinsAmount(1);
    } catch (err: any) {
      const msg = err.message || 'Erro ao enviar';
      toast.error(msg.includes('limit') || msg.includes('Insufficient') || msg.includes('exceeded') ? msg : 'Erro ao enviar reconhecimento');
    } finally {
      setLoading(false);
    }
  };

  const filteredSellers = sellers.filter(s =>
    s.name.toLowerCase().includes(search.toLowerCase())
  );

  const selectedSeller = sellers.find(s => s.id === toUserId);
  const isManager = isOwner;
  const maxXpRemaining = isManager ? 999 : Math.min(50 - (senderInfo?.xp_sent_this_month || 0), senderInfo?.xp_month || 0);
  const maxHcoinsRemaining = isManager ? 999 : Math.min(30 - (senderInfo?.hcoins_sent_this_month || 0), senderInfo?.hcoins_balance || 0);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md rounded-2xl">
        <DialogHeader>
          <DialogTitle className="text-base">
            {step === 1 ? 'Escolher colaborador' : step === 2 ? 'Motivo e contexto' : 'Confirmar'}
          </DialogTitle>
        </DialogHeader>

        {/* STEP 1 — Choose who */}
        {step === 1 && (
          <div className="space-y-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-[#121216]/30" />
              <Input
                placeholder="Buscar colaborador..."
                value={search}
                onChange={e => setSearch(e.target.value)}
                className="pl-9 rounded-xl"
              />
            </div>
            <div className="max-h-60 overflow-y-auto space-y-1">
              {filteredSellers.map(s => (
                <button
                  key={s.id}
                  onClick={() => { setToUserId(s.id); setStep(2); }}
                  className={`w-full flex items-center gap-3 p-2.5 rounded-xl hover:bg-[#121216]/5 transition-colors ${toUserId === s.id ? 'bg-[#FF6A00]/10' : ''}`}
                >
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={s.avatar_url || undefined} />
                    <AvatarFallback className="text-xs bg-[#F4F4F4]">{s.name?.[0]}</AvatarFallback>
                  </Avatar>
                  <div className="text-left">
                    <p className="text-sm font-medium text-[#121216]">{s.name}</p>
                    <p className="text-[10px] text-[#121216]/40">{s.role} {s.department ? `· ${s.department}` : ''}</p>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* STEP 2 — Reason + context */}
        {step === 2 && (
          <div className="space-y-3">
            {selectedSeller && (
              <div className="flex items-center gap-2 p-2 rounded-xl bg-[#FF6A00]/5">
                <Avatar className="h-7 w-7">
                  <AvatarImage src={selectedSeller.avatar_url || undefined} />
                  <AvatarFallback className="text-xs">{selectedSeller.name?.[0]}</AvatarFallback>
                </Avatar>
                <span className="text-sm font-medium text-[#121216]">{selectedSeller.name}</span>
                <Button variant="ghost" size="sm" className="ml-auto text-xs h-6" onClick={() => setStep(1)}>Trocar</Button>
              </div>
            )}

            <div>
              <Label className="text-xs text-[#121216]/60">Motivo *</Label>
              <Select value={reasonCode} onValueChange={setReasonCode}>
                <SelectTrigger className="rounded-xl"><SelectValue placeholder="Selecione o motivo" /></SelectTrigger>
                <SelectContent>
                  {Object.entries(REASON_CODES).map(([k, v]) => (
                    <SelectItem key={k} value={k}>{v}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-xs text-[#121216]/60">Contexto (opcional)</Label>
              <Select value={contextType} onValueChange={setContextType}>
                <SelectTrigger className="rounded-xl"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {Object.entries(CONTEXT_TYPES).map(([k, v]) => (
                    <SelectItem key={k} value={k}>{v}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-xs text-[#121216]/60">Mensagem *</Label>
              <Textarea
                value={message}
                onChange={e => setMessage(e.target.value)}
                placeholder="Escreva sua mensagem de reconhecimento..."
                rows={3}
                className="rounded-xl"
              />
            </div>

            <Button onClick={() => setStep(3)} disabled={!reasonCode || !message.trim()} className="w-full rounded-xl bg-[#121216] text-white">
              Próximo
            </Button>
          </div>
        )}

        {/* STEP 3 — Transfer options + confirm */}
        {step === 3 && (
          <div className="space-y-4">
            <div className="p-3 rounded-xl bg-[#F4F4F4]/50">
              <p className="text-xs text-[#121216]/50 mb-1">Para: <strong>{selectedSeller?.name}</strong></p>
              <p className="text-xs text-[#121216]/50">Motivo: <strong>{REASON_CODES[reasonCode]}</strong></p>
              <p className="text-sm text-[#121216] mt-1 italic">"{message}"</p>
            </div>

            <div className="space-y-3">
              <p className="text-xs font-medium text-[#121216]/60 uppercase tracking-wide">Transferência (opcional)</p>

              {/* XP transfer */}
              <div className="flex items-center gap-3">
                <Checkbox id="transfer-xp" checked={transferXp} onCheckedChange={(v) => setTransferXp(!!v)} />
                <label htmlFor="transfer-xp" className="flex items-center gap-1.5 text-sm text-[#121216] cursor-pointer">
                  <Zap className="h-4 w-4 text-[#FF6A00]" /> Transferir XP
                </label>
              </div>
              {transferXp && (
                <div className="pl-7 space-y-2">
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setXpAmount(Math.max(1, xpAmount - 1))}
                      disabled={xpAmount <= 1}
                      className="h-9 w-9 rounded-lg border border-border bg-muted/50 flex items-center justify-center text-foreground hover:bg-muted transition-colors disabled:opacity-30 disabled:cursor-not-allowed font-bold text-lg"
                    >
                      −
                    </button>
                    <Input
                      type="text"
                      inputMode="numeric"
                      value={xpAmount}
                      onChange={e => {
                        const val = e.target.value.replace(/\D/g, '');
                        if (val === '') { setXpAmount(1); return; }
                        setXpAmount(Math.max(1, Math.min(maxXpRemaining, Number(val))));
                      }}
                      className="rounded-lg w-16 h-9 text-center text-sm font-semibold"
                    />
                    <button
                      type="button"
                      onClick={() => setXpAmount(Math.min(maxXpRemaining, xpAmount + 1))}
                      disabled={xpAmount >= maxXpRemaining}
                      className="h-9 w-9 rounded-lg border border-border bg-muted/50 flex items-center justify-center text-foreground hover:bg-muted transition-colors disabled:opacity-30 disabled:cursor-not-allowed font-bold text-lg"
                    >
                      +
                    </button>
                    <span className="text-xs text-muted-foreground ml-1">XP</span>
                  </div>
                  <p className="text-[10px] text-muted-foreground">
                    Disponível: {isManager ? '∞' : maxXpRemaining} XP
                  </p>
                </div>
              )}

              {/* HCoins transfer */}
              <div className="flex items-center gap-3">
                <Checkbox id="transfer-hcoins" checked={transferHcoins} onCheckedChange={(v) => setTransferHcoins(!!v)} />
                <label htmlFor="transfer-hcoins" className="flex items-center gap-1.5 text-sm text-[#121216] cursor-pointer">
                  <HCoinIcon size={16} /> Transferir HCoins
                </label>
              </div>
              {transferHcoins && (
                <div className="pl-7 space-y-2">
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setHcoinsAmount(Math.max(1, hcoinsAmount - 1))}
                      disabled={hcoinsAmount <= 1}
                      className="h-9 w-9 rounded-lg border border-border bg-muted/50 flex items-center justify-center text-foreground hover:bg-muted transition-colors disabled:opacity-30 disabled:cursor-not-allowed font-bold text-lg"
                    >
                      −
                    </button>
                    <Input
                      type="text"
                      inputMode="numeric"
                      value={hcoinsAmount}
                      onChange={e => {
                        const val = e.target.value.replace(/\D/g, '');
                        if (val === '') { setHcoinsAmount(1); return; }
                        setHcoinsAmount(Math.max(1, Math.min(maxHcoinsRemaining, Number(val))));
                      }}
                      className="rounded-lg w-16 h-9 text-center text-sm font-semibold"
                    />
                    <button
                      type="button"
                      onClick={() => setHcoinsAmount(Math.min(maxHcoinsRemaining, hcoinsAmount + 1))}
                      disabled={hcoinsAmount >= maxHcoinsRemaining}
                      className="h-9 w-9 rounded-lg border border-border bg-muted/50 flex items-center justify-center text-foreground hover:bg-muted transition-colors disabled:opacity-30 disabled:cursor-not-allowed font-bold text-lg"
                    >
                      +
                    </button>
                    <span className="text-xs text-muted-foreground ml-1">HC</span>
                  </div>
                  <p className="text-[10px] text-muted-foreground">
                    Disponível: {isManager ? '∞' : maxHcoinsRemaining} HC
                  </p>
                </div>
              )}
            </div>

            <div className="flex gap-2">
              <Button variant="outline" onClick={() => setStep(2)} className="flex-1 rounded-xl">Voltar</Button>
              <Button
                onClick={handleSubmit}
                disabled={loading}
                className="flex-1 rounded-xl bg-[#FF6A00] hover:bg-[#FF6A00]/90 text-white"
              >
                {loading ? 'Enviando...' : 'Confirmar'}
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
