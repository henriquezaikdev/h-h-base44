import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { BookOpen, Plus, CheckCircle, XCircle, Send, Loader2 } from 'lucide-react';
import { format, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { toast } from 'sonner';
import type { Rulebook } from '@/hooks/useRulebook';

export function RulebookGestorPanel() {
  const { seller } = useAuth();
  const [versions, setVersions] = useState<Rulebook[]>([]);
  const [acceptances, setAcceptances] = useState<Record<string, any[]>>({});
  const [sellers, setSellers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [createOpen, setCreateOpen] = useState(false);
  const [publishing, setPublishing] = useState<string | null>(null);

  // Form state
  const [newTitle, setNewTitle] = useState('Regulamento do Sistema H&H');
  const [newVersion, setNewVersion] = useState('v1.0');
  const [newContent, setNewContent] = useState('');
  const [creating, setCreating] = useState(false);

  const fetchData = async () => {
    const sb = supabase as any;
    const versionsRes = await sb.from('rulebook').select('*').order('created_at', { ascending: false });
    const sellersRes = await sb.from('sellers').select('id, name, role').eq('is_active', true);
    setVersions((versionsRes.data || []) as Rulebook[]);
    setSellers(sellersRes.data || []);

    const active = (versionsRes.data || []).find((v: any) => v.is_active);
    if (active) {
      const accRes = await sb.from('rulebook_acceptance').select('*').eq('rulebook_id', active.id);
      setAcceptances({ [active.id]: accRes.data || [] });
    }
    setLoading(false);
  };

  useEffect(() => { fetchData(); }, []);

  const handleCreate = async () => {
    if (!newTitle || !newVersion || !newContent) {
      toast.error('Preencha todos os campos');
      return;
    }
    setCreating(true);
    const sb = supabase as any;
    const { error } = await sb.from('rulebook').insert({
      title: newTitle,
      version_label: newVersion,
      content_html: newContent,
    });
    if (error) {
      toast.error('Erro ao criar versão');
    } else {
      toast.success('Versão criada (não publicada ainda)');
      setCreateOpen(false);
      setNewContent('');
      fetchData();
    }
    setCreating(false);
  };

  const handlePublish = async (rulebookId: string) => {
    if (!seller?.id) return;
    setPublishing(rulebookId);
    const { error } = await (supabase as any).rpc('fn_publish_rulebook', {
      p_rulebook_id: rulebookId,
      p_publisher_id: seller.id,
    });
    if (error) {
      toast.error('Erro ao publicar');
    } else {
      toast.success('Regulamento publicado! Todos precisam aceitar novamente.');
      fetchData();
    }
    setPublishing(null);
  };

  const activeVersion = versions.find(v => v.is_active);
  const activeAcceptances = activeVersion ? (acceptances[activeVersion.id] || []) : [];
  const acceptedUserIds = new Set(activeAcceptances.map(a => a.user_id));
  const pendingSellers = sellers.filter(s => !acceptedUserIds.has(s.id));
  const acceptedSellers = sellers.filter(s => acceptedUserIds.has(s.id));

  if (loading) return <div className="py-8 text-center text-[#121216]/40 animate-pulse">Carregando...</div>;

  return (
    <div className="mt-4 space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h3 className="text-base font-bold text-[#121216] flex items-center gap-2">
          <BookOpen className="h-4 w-4 text-[#FF6A00]" /> Gestão do Regulamento
        </h3>
        <Dialog open={createOpen} onOpenChange={setCreateOpen}>
          <DialogTrigger asChild>
            <Button size="sm" className="rounded-xl gap-1.5">
              <Plus className="h-3.5 w-3.5" /> Nova Versão
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle>Criar Nova Versão do Regulamento</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label>Título</Label>
                  <Input value={newTitle} onChange={e => setNewTitle(e.target.value)} className="rounded-xl" />
                </div>
                <div>
                  <Label>Versão</Label>
                  <Input value={newVersion} onChange={e => setNewVersion(e.target.value)} placeholder="v1.0" className="rounded-xl" />
                </div>
              </div>
              <div>
                <Label>Conteúdo (HTML)</Label>
                <Textarea
                  value={newContent}
                  onChange={e => setNewContent(e.target.value)}
                  placeholder="Conteúdo do regulamento em HTML..."
                  rows={10}
                  className="rounded-xl text-xs font-mono"
                />
              </div>
              <Button onClick={handleCreate} disabled={creating} className="w-full rounded-xl gap-2">
                {creating ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
                Criar Versão
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Versions list */}
      <Card className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-sm border border-white/60">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm text-[#121216]/60">Versões do Regulamento</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {versions.length === 0 && (
            <p className="text-sm text-[#121216]/40 text-center py-4">Nenhuma versão criada</p>
          )}
          {versions.map(v => (
            <div key={v.id} className="flex items-center gap-3 p-3 rounded-xl bg-[#F4F4F4]/50">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-semibold text-[#121216]">{v.title}</span>
                  <Badge variant="outline" className="text-[10px] rounded-lg">{v.version_label}</Badge>
                  {v.is_active && (
                    <Badge className="text-[10px] rounded-lg bg-emerald-100 text-emerald-700 border-emerald-200">Ativa</Badge>
                  )}
                </div>
                <p className="text-xs text-[#121216]/40 mt-0.5">
                  Criada em {format(parseISO(v.created_at), "dd/MM/yyyy", { locale: ptBR })}
                  {v.published_at && ` · Publicada em ${format(parseISO(v.published_at), "dd/MM/yyyy HH:mm", { locale: ptBR })}`}
                </p>
              </div>
              {!v.is_active && (
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handlePublish(v.id)}
                  disabled={publishing === v.id}
                  className="rounded-xl gap-1.5 text-xs"
                >
                  {publishing === v.id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Send className="h-3.5 w-3.5" />}
                  Publicar
                </Button>
              )}
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Acceptance status */}
      {activeVersion && (
        <Card className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-sm border border-white/60">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-[#121216]/60">
              Status de Aceite — {activeVersion.version_label}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {/* Pending */}
            {pendingSellers.length > 0 && (
              <div>
                <p className="text-xs font-semibold text-amber-600 mb-1.5 flex items-center gap-1">
                  <XCircle className="h-3.5 w-3.5" /> Pendentes ({pendingSellers.length})
                </p>
                <div className="flex flex-wrap gap-1.5">
                  {pendingSellers.map(s => (
                    <Badge key={s.id} variant="outline" className="text-[10px] rounded-lg bg-amber-50 text-amber-600 border-amber-200">
                      {s.name}
                    </Badge>
                  ))}
                </div>
              </div>
            )}
            {/* Accepted */}
            {acceptedSellers.length > 0 && (
              <div>
                <p className="text-xs font-semibold text-emerald-600 mb-1.5 flex items-center gap-1">
                  <CheckCircle className="h-3.5 w-3.5" /> Aceitos ({acceptedSellers.length})
                </p>
                <div className="flex flex-wrap gap-1.5">
                  {acceptedSellers.map(s => (
                    <Badge key={s.id} variant="outline" className="text-[10px] rounded-lg bg-emerald-50 text-emerald-600 border-emerald-200">
                      {s.name}
                    </Badge>
                  ))}
                </div>
              </div>
            )}
            {pendingSellers.length === 0 && acceptedSellers.length === 0 && (
              <p className="text-sm text-[#121216]/40 text-center py-2">Nenhum colaborador ativo encontrado</p>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
