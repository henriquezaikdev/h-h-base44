import { useState, useRef } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { SellerProfileData } from '@/hooks/useSellerProfile';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Camera, Upload } from 'lucide-react';
import { toast } from 'sonner';

interface ProfileEditModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  profile: SellerProfileData;
  onSaved: () => void;
}

export function ProfileEditModal({ open, onOpenChange, profile, onSaved }: ProfileEditModalProps) {
  const [displayName, setDisplayName] = useState(profile.display_name || profile.name);
  const [bio, setBio] = useState(profile.bio || '');
  const [sobreMim, setSobreMim] = useState(profile.sobre_mim || '');
  const [avatarPreview, setAvatarPreview] = useState(profile.avatar_url || '');
  const [coverPreview, setCoverPreview] = useState(profile.cover_url || '');
  const [lovedOnePreview, setLovedOnePreview] = useState(profile.loved_one_photo_url || '');
  const [lovedOneName, setLovedOneName] = useState(profile.loved_one_name || '');
  const [avatarFile, setAvatarFile] = useState<File | null>(null);
  const [coverFile, setCoverFile] = useState<File | null>(null);
  const [lovedOneFile, setLovedOneFile] = useState<File | null>(null);
  const [saving, setSaving] = useState(false);
  const avatarInputRef = useRef<HTMLInputElement>(null);
  const coverInputRef = useRef<HTMLInputElement>(null);
  const lovedOneInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>, type: 'avatar' | 'cover' | 'loved_one') => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      toast.error('Imagem deve ter no máximo 5MB');
      return;
    }
    const url = URL.createObjectURL(file);
    if (type === 'avatar') { setAvatarFile(file); setAvatarPreview(url); }
    else if (type === 'cover') { setCoverFile(file); setCoverPreview(url); }
    else if (type === 'loved_one') { setLovedOneFile(file); setLovedOnePreview(url); }
  };

  const uploadFile = async (file: File, path: string) => {
    const { error } = await supabase.storage.from('profile-assets').upload(path, file, { upsert: true });
    if (error) throw error;
    const { data } = supabase.storage.from('profile-assets').getPublicUrl(path);
    return `${data.publicUrl}?t=${Date.now()}`;
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const updates: Record<string, any> = {
        display_name: displayName.trim() || null,
        bio: bio.trim() || null,
        sobre_mim: sobreMim.trim() || null,
        loved_one_name: lovedOneName.trim() || null,
      };

      if (avatarFile && profile.user_id) {
        const ext = avatarFile.name.split('.').pop() || 'jpg';
        const url = await uploadFile(avatarFile, `${profile.user_id}/avatar.${ext}`);
        updates.avatar_url = url;
      }

      if (coverFile && profile.user_id) {
        const ext = coverFile.name.split('.').pop() || 'jpg';
        const url = await uploadFile(coverFile, `${profile.user_id}/cover.${ext}`);
        updates.cover_url = url;
      }

      if (lovedOneFile && profile.user_id) {
        const ext = lovedOneFile.name.split('.').pop() || 'jpg';
        const url = await uploadFile(lovedOneFile, `${profile.user_id}/loved_one.${ext}`);
        updates.loved_one_photo_url = url;
      }

      const { error } = await (supabase as any)
        .from('sellers')
        .update(updates)
        .eq('id', profile.id);

      if (error) throw error;
      toast.success('Perfil atualizado!');
      onSaved();
      onOpenChange(false);
    } catch (err: any) {
      toast.error(err.message || 'Erro ao salvar perfil');
    } finally {
      setSaving(false);
    }
  };

  const initials = displayName.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase();

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md bg-white rounded-2xl">
        <DialogHeader>
          <DialogTitle className="text-[#121216]">Editar Perfil</DialogTitle>
        </DialogHeader>

        <div className="space-y-5">
          {/* Cover preview */}
          <div>
            <Label className="text-xs text-[#121216]/60">Capa</Label>
            <div
              className="h-24 rounded-xl mt-1 cursor-pointer relative overflow-hidden group"
              style={{
                background: coverPreview
                  ? `url(${coverPreview}) center/cover no-repeat`
                  : 'linear-gradient(135deg, #FF6A00, #FFB877)',
              }}
              onClick={() => coverInputRef.current?.click()}
            >
              <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-colors flex items-center justify-center">
                <Upload className="h-5 w-5 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
            </div>
            <input ref={coverInputRef} type="file" accept="image/*" className="hidden" onChange={e => handleFileSelect(e, 'cover')} />
          </div>

          {/* Avatar preview */}
          <div className="flex items-center gap-4">
            <div className="relative cursor-pointer" onClick={() => avatarInputRef.current?.click()}>
              <Avatar className="h-16 w-16 border-2 border-[#FF6A00]/20">
                <AvatarImage src={avatarPreview || undefined} />
                <AvatarFallback className="bg-[#FF6A00] text-white font-bold">{initials}</AvatarFallback>
              </Avatar>
              <div className="absolute -bottom-1 -right-1 bg-[#FF6A00] rounded-full p-1">
                <Camera className="h-3 w-3 text-white" />
              </div>
            </div>
            <div className="text-xs text-[#121216]/50">Clique para alterar<br />Max 5MB · JPG, PNG, WebP</div>
            <input ref={avatarInputRef} type="file" accept="image/*" className="hidden" onChange={e => handleFileSelect(e, 'avatar')} />
          </div>

          {/* Name */}
          <div>
            <Label className="text-xs text-[#121216]/60">Nome Exibido</Label>
            <Input
              value={displayName}
              onChange={e => setDisplayName(e.target.value)}
              className="mt-1 rounded-xl"
              maxLength={60}
            />
          </div>

          {/* Bio */}
          <div>
            <Label className="text-xs text-[#121216]/60">Bio ({bio.length}/200)</Label>
            <Input
              value={bio}
              onChange={e => setBio(e.target.value.slice(0, 200))}
              className="mt-1 rounded-xl"
              placeholder="Uma frase sobre você..."
              maxLength={200}
            />
          </div>

          {/* Sobre mim */}
          <div>
            <Label className="text-xs text-[#121216]/60">Sobre mim ({sobreMim.length}/400)</Label>
            <Textarea
              value={sobreMim}
              onChange={e => setSobreMim(e.target.value.slice(0, 400))}
              className="mt-1 rounded-xl"
              placeholder="Conte mais sobre você..."
              rows={3}
              maxLength={400}
            />
          </div>

          {/* Foto Motivacional */}
          <div>
            <Label className="text-xs text-[#121216]/60">Foto Motivacional (ente querido)</Label>
            <p className="text-[10px] text-[#121216]/40 mb-1">Aparece quando você bater a meta de vendas 🎉</p>
            <div className="flex items-center gap-4">
              <div className="relative cursor-pointer" onClick={() => lovedOneInputRef.current?.click()}>
                {lovedOnePreview ? (
                  <img src={lovedOnePreview} alt="Ente querido" className="w-16 h-16 rounded-full object-cover border-2 border-amber-400/40" />
                ) : (
                  <div className="w-16 h-16 rounded-full bg-amber-50 border-2 border-dashed border-amber-300 flex items-center justify-center">
                    <Camera className="h-5 w-5 text-amber-400" />
                  </div>
                )}
              </div>
              <div className="flex-1">
                <Input
                  value={lovedOneName}
                  onChange={e => setLovedOneName(e.target.value.slice(0, 60))}
                  className="rounded-xl text-sm"
                  placeholder="Nome (ex: Minha família)"
                  maxLength={60}
                />
              </div>
              <input ref={lovedOneInputRef} type="file" accept="image/*" className="hidden" onChange={e => handleFileSelect(e, 'loved_one')} />
            </div>
          </div>

          <div className="flex gap-2 justify-end">
            <Button variant="ghost" onClick={() => onOpenChange(false)} className="rounded-xl">Cancelar</Button>
            <Button
              onClick={handleSave}
              disabled={saving}
              className="rounded-xl bg-[#FF6A00] hover:bg-[#FF6A00]/90 text-white"
            >
              {saving ? 'Salvando...' : 'Salvar'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
