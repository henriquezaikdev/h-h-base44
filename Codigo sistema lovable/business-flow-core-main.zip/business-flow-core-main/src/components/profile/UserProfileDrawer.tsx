import { useState } from 'react';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { useUserScore, getXpProgress, getXpForNextLevel, SmartAlert, ScoreBreakdown } from '@/hooks/useUserScore';
import { useCoinsAndMedals } from '@/hooks/useCoinsAndMedals';
import { useAuth } from '@/hooks/useAuth';
import { GiveCoinModal } from '@/components/coins/GiveCoinModal';
import {
  Star, Zap, Trophy, Coins, AlertTriangle, CheckCircle2, Info, XCircle,
  Shield, TrendingUp, Clock, Target, BarChart3, Flame,
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface UserProfileDrawerProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  sellerId: string;
  sellerName: string;
  sellerRole?: string;
  sellerDepartment?: string | null;
  sellerAvatarUrl?: string | null;
}

const LEVEL_NAMES: Record<number, string> = {
  1: 'Iniciante',
  2: 'Aprendiz',
  3: 'Profissional',
  4: 'Especialista',
  5: 'Mestre',
};

function getLevelName(level: number): string {
  if (level <= 5) return LEVEL_NAMES[level] || `Nível ${level}`;
  return `Lenda ${level - 5}`;
}

function ScoreBar({ label, value, icon: Icon }: { label: string; value: number; icon: any }) {
  const color = value >= 80 ? 'bg-emerald-500' : value >= 60 ? 'bg-amber-500' : 'bg-red-500';
  return (
    <div className="space-y-1">
      <div className="flex items-center justify-between text-xs">
        <span className="flex items-center gap-1.5 text-muted-foreground">
          <Icon className="h-3 w-3" /> {label}
        </span>
        <span className="font-semibold">{value}%</span>
      </div>
      <div className="h-2 rounded-full bg-muted overflow-hidden">
        <div className={cn("h-full rounded-full transition-all", color)} style={{ width: `${value}%` }} />
      </div>
    </div>
  );
}

function AlertCard({ alert }: { alert: SmartAlert }) {
  const styles = {
    danger: { icon: XCircle, bg: 'bg-red-500/10 border-red-500/25', text: 'text-red-600' },
    warning: { icon: AlertTriangle, bg: 'bg-amber-500/10 border-amber-500/25', text: 'text-amber-600' },
    info: { icon: Info, bg: 'bg-blue-500/10 border-blue-500/25', text: 'text-blue-600' },
    success: { icon: CheckCircle2, bg: 'bg-emerald-500/10 border-emerald-500/25', text: 'text-emerald-600' },
  };
  const s = styles[alert.type];
  const Icon = s.icon;

  return (
    <div className={cn("p-3 rounded-lg border flex items-start gap-2.5", s.bg)}>
      <Icon className={cn("h-4 w-4 mt-0.5 shrink-0", s.text)} />
      <p className="text-xs leading-relaxed">{alert.message}</p>
    </div>
  );
}

export function UserProfileDrawer({
  open,
  onOpenChange,
  sellerId,
  sellerName,
  sellerRole,
  sellerDepartment,
  sellerAvatarUrl,
}: UserProfileDrawerProps) {
  const { seller, isAdminOrOwner } = useAuth();
  const { score, breakdown, xp, level, alerts, loading } = useUserScore(sellerId);
  const { balance, coins7d, coins30d, medals, loading: coinsLoading } = useCoinsAndMedals(sellerId);
  const [showCoinModal, setShowCoinModal] = useState(false);

  const isOwnProfile = seller?.id === sellerId;
  const canSeeDetails = isOwnProfile || isAdminOrOwner;
  const xpProgress = getXpProgress(xp, level);
  const nextLevelXp = getXpForNextLevel(level);
  const weights: Record<string, number> = { tarefasNoPrazo: 30, frequenciaUso: 30, execucao: 25, semAtrasos: 15 };
  const initials = sellerName.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase();

  const deptLabel = sellerDepartment === 'financeiro_gestora'
    ? 'Financeiro/Gestora'
    : sellerDepartment === 'logistica'
      ? 'Logística'
      : sellerRole === 'vendedor'
        ? 'Vendedor'
        : sellerRole || 'Equipe';

  const scoreColor = score >= 80 ? 'text-emerald-500' : score >= 60 ? 'text-amber-500' : 'text-red-500';

  const allBreakdownItems: { key: keyof ScoreBreakdown; label: string; icon: any; max: number }[] = [
    { key: 'tarefasNoPrazo', label: 'Tarefas no Prazo', icon: Clock, max: 30 },
    { key: 'frequenciaUso', label: 'Frequência de Uso', icon: Flame, max: 30 },
    { key: 'execucao', label: 'Execução', icon: Target, max: 25 },
    { key: 'semAtrasos', label: 'Sem Atrasos', icon: Shield, max: 15 },
  ];
  const breakdownItems = allBreakdownItems;

  return (
    <>
      <Sheet open={open} onOpenChange={onOpenChange}>
        <SheetContent side="right" className="w-full sm:max-w-md p-0">
          <SheetHeader className="px-6 pt-6 pb-0">
            <SheetTitle className="sr-only">Perfil de {sellerName}</SheetTitle>
          </SheetHeader>

          <ScrollArea className="h-[calc(100vh-2rem)]">
            <div className="px-6 pb-8 space-y-5">
              {/* ===== HEADER ===== */}
              <div className="flex flex-col items-center text-center pt-2">
                <Avatar className="h-20 w-20 border-2 border-primary/20 mb-3">
                  <AvatarFallback className="text-xl font-bold bg-primary/10 text-primary">
                    {initials}
                  </AvatarFallback>
                </Avatar>
                <h2 className="text-lg font-bold">{sellerName}</h2>
                <Badge variant="secondary" className="mt-1">{deptLabel}</Badge>

                <div className="flex items-center gap-2 mt-3">
                  <div className="flex items-center gap-1 px-3 py-1.5 rounded-full bg-primary/10">
                    <Star className="h-4 w-4 text-primary" />
                    <span className="text-sm font-bold text-primary">Nv. {level}</span>
                    <span className="text-xs text-muted-foreground">• {getLevelName(level)}</span>
                  </div>
                </div>

                {/* XP Progress */}
                <div className="w-full mt-3 space-y-1">
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>{xp} XP</span>
                    <span>{nextLevelXp} XP</span>
                  </div>
                  <Progress value={xpProgress} className="h-2.5" />
                </div>

                {/* Score */}
                <div className="flex items-center gap-2 mt-3">
                  <span className="text-xs text-muted-foreground">Score:</span>
                  <span className={cn("text-2xl font-black", scoreColor)}>{score}</span>
                  <span className="text-xs text-muted-foreground">/100</span>
                </div>

                {/* Action buttons */}
                {!isOwnProfile && (
                  <div className="flex gap-2 mt-3">
                    <Button size="sm" variant="outline" onClick={() => setShowCoinModal(true)}>
                      <Coins className="h-3.5 w-3.5 mr-1" /> Dar H-Coin
                    </Button>
                  </div>
                )}
              </div>

              <Separator />

              {/* ===== SCORE BREAKDOWN ===== */}
              {canSeeDetails && (
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm flex items-center gap-2">
                      <TrendingUp className="h-4 w-4 text-primary" />
                      Desempenho (30 dias)
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {breakdownItems.map(item => (
                      <ScoreBar
                        key={item.key}
                        label={`${item.label} (${breakdown[item.key]}/${item.max})`}
                        value={Math.round((breakdown[item.key] / item.max) * 100)}
                        icon={item.icon}
                      />
                    ))}
                  </CardContent>
                </Card>
              )}

              {/* ===== MEDALS ===== */}
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm flex items-center gap-2">
                    <Trophy className="h-4 w-4 text-amber-500" />
                    Medalhas ({medals.length})
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {medals.length > 0 ? (
                    <div className="flex flex-wrap gap-2">
                      {medals.slice(0, 12).map(um => {
                        const tierColor = um.medal?.tier === 'OURO'
                          ? 'bg-amber-500/10 text-amber-600 border-amber-500/30'
                          : um.medal?.tier === 'PRATA'
                            ? 'bg-slate-400/10 text-slate-500 border-slate-400/30'
                            : 'bg-orange-500/10 text-orange-600 border-orange-500/30';
                        return (
                          <Badge key={um.id} className={tierColor}>
                            {um.medal?.name || 'Medalha'}
                          </Badge>
                        );
                      })}
                    </div>
                  ) : (
                    <p className="text-xs text-muted-foreground text-center py-2">Nenhuma medalha ainda</p>
                  )}
                </CardContent>
              </Card>

              {/* ===== H-COINS ===== */}
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm flex items-center gap-2">
                    <Coins className="h-4 w-4 text-yellow-500" />
                    H-Coins
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-3 gap-2 text-center">
                    <div className="p-2 rounded-lg bg-muted/30">
                      <p className="text-lg font-bold">{balance}</p>
                      <p className="text-[10px] text-muted-foreground">Saldo</p>
                    </div>
                    <div className="p-2 rounded-lg bg-muted/30">
                      <p className="text-lg font-bold">{coins7d}</p>
                      <p className="text-[10px] text-muted-foreground">7 dias</p>
                    </div>
                    <div className="p-2 rounded-lg bg-muted/30">
                      <p className="text-lg font-bold">{coins30d}</p>
                      <p className="text-[10px] text-muted-foreground">30 dias</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* ===== SMART ALERTS ===== */}
              {canSeeDetails && alerts.length > 0 && (
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm flex items-center gap-2">
                      <Zap className="h-4 w-4 text-amber-500" />
                      Alertas Inteligentes
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    {alerts.map(alert => (
                      <AlertCard key={alert.id} alert={alert} />
                    ))}
                  </CardContent>
                </Card>
              )}
            </div>
          </ScrollArea>
        </SheetContent>
      </Sheet>

      {showCoinModal && (
        <GiveCoinModal
          open={showCoinModal}
          onOpenChange={setShowCoinModal}
          recipientId={sellerId}
          recipientName={sellerName}
        />
      )}
    </>
  );
}
