import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { format, parseISO, startOfMonth, subMonths } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { CheckCircle2, Clock, ShoppingCart, Package, Truck, ClipboardList } from 'lucide-react';

interface Props {
  sellerId: string;
  department: string | null;
}

const STATUS_COLORS: Record<string, string> = {
  concluida: 'bg-emerald-50 text-emerald-600 border-emerald-200',
  pendente: 'bg-amber-50 text-amber-600 border-amber-200',
  cancelada: 'bg-red-50 text-red-600 border-red-200',
  arquivada: 'bg-gray-50 text-gray-500 border-gray-200',
};

const STATUS_LABELS: Record<string, string> = {
  concluida: 'Concluída',
  pendente: 'Pendente',
  cancelada: 'Cancelada',
  arquivada: 'Arquivada',
};

export function DepartmentHistoricoTab({ sellerId, department }: Props) {
  const [tasks, setTasks] = useState<any[]>([]);
  const [cotacoes, setCotacoes] = useState<any[]>([]);
  const [compras, setCompras] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const isFinanceiro = department === 'financeiro_gestora';

  useEffect(() => {
    const fetch = async () => {
      setLoading(true);
      const threeMonthsAgo = format(startOfMonth(subMonths(new Date(), 3)), 'yyyy-MM-dd');

      // Fetch completed/recent tasks
      const { data: taskData } = await supabase
        .from('tasks')
        .select('id, notes, task_date, status, priority, task_category, completed_at, clients!tasks_client_id_fkey(company_name)')
        .or(`created_by_seller_id.eq.${sellerId},assigned_to_seller_id.eq.${sellerId}`)
        .eq('is_deleted', false)
        .gte('task_date', threeMonthsAgo)
        .order('task_date', { ascending: false })
        .limit(50);

      setTasks((taskData || []).map((t: any) => ({
        ...t,
        client_name: t.clients?.company_name || 'Rotina',
      })));

      if (isFinanceiro) {
        // Fetch cotações
        const { data: cotData } = await supabase
          .from('cotacoes_fornecedor')
          .select('id, status_cotacao, data_solicitada, valor_total, fornecedores:fornecedor_id(nome_fantasia), solicitacoes_compra:solicitacao_id(titulo)')
          .gte('created_at', threeMonthsAgo)
          .order('created_at', { ascending: false })
          .limit(30);

        setCotacoes((cotData || []).map((c: any) => ({
          id: c.id,
          status: c.status_cotacao,
          date: c.data_solicitada,
          valor: c.valor_total,
          fornecedor: (c.fornecedores as any)?.nome_fantasia || 'N/A',
          titulo: (c.solicitacoes_compra as any)?.titulo || 'Sem título',
        })));

        // Fetch compras
        const { data: compData } = await supabase
          .from('compras')
          .select('id, data_compra, status_compra, valor_total, fornecedores:fornecedor_id(nome_fantasia)')
          .gte('created_at', threeMonthsAgo)
          .order('created_at', { ascending: false })
          .limit(30);

        setCompras((compData || []).map((c: any) => ({
          id: c.id,
          date: c.data_compra,
          status: c.status_compra,
          valor: c.valor_total,
          fornecedor: (c.fornecedores as any)?.nome_fantasia || 'N/A',
        })));
      }

      setLoading(false);
    };
    fetch();
  }, [sellerId, isFinanceiro]);

  if (loading) return <div className="py-8 text-center text-gray-400 animate-pulse">Carregando histórico...</div>;

  return (
    <div className="mt-4">
      <Tabs defaultValue="tarefas">
        <TabsList className="bg-gray-100 rounded-xl p-1 h-auto">
          <TabsTrigger value="tarefas" className="text-xs rounded-lg gap-1.5 px-3 py-1.5">
            <ClipboardList className="h-3.5 w-3.5" /> Tarefas ({tasks.length})
          </TabsTrigger>
          {isFinanceiro && (
            <>
              <TabsTrigger value="cotacoes" className="text-xs rounded-lg gap-1.5 px-3 py-1.5">
                <ShoppingCart className="h-3.5 w-3.5" /> Cotações ({cotacoes.length})
              </TabsTrigger>
              <TabsTrigger value="compras" className="text-xs rounded-lg gap-1.5 px-3 py-1.5">
                <Package className="h-3.5 w-3.5" /> Compras ({compras.length})
              </TabsTrigger>
            </>
          )}
        </TabsList>

        <TabsContent value="tarefas">
          <div className="space-y-2 mt-3">
            {tasks.length === 0 && <p className="text-sm text-gray-400 text-center py-6">Nenhuma tarefa nos últimos 3 meses</p>}
            {tasks.map(t => (
              <Card key={t.id} className="bg-white rounded-xl shadow-sm border border-gray-100">
                <CardContent className="p-3 flex items-center gap-3">
                  {t.status === 'concluida' ? (
                    <CheckCircle2 className="h-4 w-4 text-emerald-500 shrink-0" />
                  ) : (
                    <Clock className="h-4 w-4 text-amber-500 shrink-0" />
                  )}
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-900 truncate">{t.notes || 'Sem descrição'}</p>
                    <div className="flex items-center gap-2 mt-0.5">
                      <span className="text-[10px] text-gray-400">{t.client_name}</span>
                      {t.task_category && (
                        <Badge variant="outline" className="text-[9px] px-1 py-0 rounded">{t.task_category}</Badge>
                      )}
                    </div>
                  </div>
                  <div className="flex flex-col items-end gap-1 shrink-0">
                    <Badge variant="outline" className={`text-[9px] px-1.5 py-0 rounded ${STATUS_COLORS[t.status] || ''}`}>
                      {STATUS_LABELS[t.status] || t.status}
                    </Badge>
                    <span className="text-[10px] text-gray-400">
                      {format(parseISO(t.task_date), 'dd/MM', { locale: ptBR })}
                    </span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {isFinanceiro && (
          <TabsContent value="cotacoes">
            <div className="space-y-2 mt-3">
              {cotacoes.length === 0 && <p className="text-sm text-gray-400 text-center py-6">Nenhuma cotação nos últimos 3 meses</p>}
              {cotacoes.map(c => (
                <Card key={c.id} className="bg-white rounded-xl shadow-sm border border-gray-100">
                  <CardContent className="p-3 flex items-center gap-3">
                    <ShoppingCart className="h-4 w-4 text-amber-500 shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-900 truncate">{c.titulo}</p>
                      <span className="text-[10px] text-gray-400">{c.fornecedor}</span>
                    </div>
                    <div className="flex flex-col items-end gap-1 shrink-0">
                      <Badge variant="outline" className="text-[9px] px-1.5 py-0 rounded">{c.status}</Badge>
                      {c.valor && <span className="text-xs font-semibold text-gray-700">R$ {Number(c.valor).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>}
                      <span className="text-[10px] text-gray-400">{c.date ? format(parseISO(c.date), 'dd/MM', { locale: ptBR }) : ''}</span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        )}

        {isFinanceiro && (
          <TabsContent value="compras">
            <div className="space-y-2 mt-3">
              {compras.length === 0 && <p className="text-sm text-gray-400 text-center py-6">Nenhuma compra nos últimos 3 meses</p>}
              {compras.map(c => (
                <Card key={c.id} className="bg-white rounded-xl shadow-sm border border-gray-100">
                  <CardContent className="p-3 flex items-center gap-3">
                    <Package className="h-4 w-4 text-cyan-500 shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-900">{c.fornecedor}</p>
                    </div>
                    <div className="flex flex-col items-end gap-1 shrink-0">
                      <Badge variant="outline" className="text-[9px] px-1.5 py-0 rounded">{c.status}</Badge>
                      {c.valor && <span className="text-xs font-semibold text-gray-700">R$ {Number(c.valor).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>}
                      <span className="text-[10px] text-gray-400">{c.date ? format(parseISO(c.date), 'dd/MM', { locale: ptBR }) : ''}</span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        )}
      </Tabs>
    </div>
  );
}
