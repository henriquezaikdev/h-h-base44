import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Star, Award, Loader2, Sparkles, History } from 'lucide-react';
import { toast } from 'sonner';
import { format, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';

const REASON_OPTIONS = [
  { value: 'MARGEM_ACIMA_MEDIA', label: 'Margem acima da média' },
  { value: 'VENDA_ESTRATEGICA', label: 'Venda estratégica' },
  { value: 'EXCELENCIA_ATENDIMENTO', label: 'Excelência no atendimento' },
  { value: 'EXCELENCIA_OPERACIONAL', label: 'Excelência operacional' },
  { value: 'ORGANIZACAO_EXEMPLAR', label: 'Organização exemplar' },
  { value: 'INICIATIVA_ESTRATEGICA', label: 'Iniciativa estratégica' },
  { value: 'LIDERANCA_APOIO_EQUIPE', label: 'Liderança / Apoio à equipe' },
  { value: 'RESOLVEU_PEPINO', label: 'Resolveu um pepino' },
  { value: 'OUTRO', label: 'Outro (exige comentário)' },
];

const STAR_EMOJI: Record<string, string> = {
  BRONZE: '🥉',
  PRATA: '🥈',
  OURO: '🥇',
  CRISTAL: '💎',
};

interface Seller {
  id: string;
  name: string;
  role: string;
}

interface StarBalance {
  user_id: string;
  bronze_count: number;
  silver_count: number;
  gold_count: number;
  crystal_count: number;
}

export function EstrelasGestorPanel() {
  const [sellers, setSellers] = useState<Seller[]>([]);
  const [balances, setBalances] = useState<Record<string, StarBalance>>({});
  const [ledger, setLedger] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [grantOpen, setGrantOpen] = useState(false);
  const [historyOpen, setHistoryOpen] = useState<string | null>(null);

  // Grant form
  const [selectedSeller, setSelectedSeller] = useState('');
  const [starType, setStarType] = useState<'BRONZE' | 'PRATA' | 'OURO'>('BRONZE');
  const [quantity, setQuantity] = useState(1);
  const [reasonCode, setReasonCode] = useState('');
  const [comment, setComment] = useState('');
  const [saving, setSaving] = useState(false);

  const fetchData = useCallback(async () => {
    const [sellersRes, balancesRes] = await Promise.all([
      supabase.from('sellers').select('id, name, role').order('name'),
      supabase.from('star_balances').select('*'),
    ]);

    setSellers(sellersRes.data || []);
    const bMap: Record<string, StarBalance> = {};
    (balancesRes.data || []).forEach((b: any) => { bMap[b.user_id] = b; });
    setBalances(bMap);
    setLoading(false);
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  const fetchHistory = async (userId: string) => {
    const { data } = await supabase
      .from('star_ledger')
      .select('*')
      .eq('to_user_id', userId)
      .order('created_at', { ascending: false })
      .limit(50);
    setLedger(data || []);
    setHistoryOpen(userId);
  };

  const handleGrant = async () => {
    if (!selectedSeller || !reasonCode) {
      toast.error('Selecione vendedor e motivo');
      return;
    }
    if (reasonCode === 'OUTRO' && !comment.trim()) {
      toast.error('Comentário obrigatório para motivo "Outro"');
      return;
    }

    setSaving(true);
    try {
      // Get the seller ID for the current auth user (FK references sellers.id, not auth.users.id)
      const authUser = (await supabase.auth.getUser()).data.user;
      const { data: grantorSeller } = await supabase
        .from('sellers')
        .select('id')
        .eq('user_id', authUser?.id)
        .maybeSingle();

      const { data, error } = await supabase.rpc('fn_grant_star', {
        p_to_user_id: selectedSeller,
        p_granted_by: grantorSeller?.id || null,
        p_star_type: starType,
        p_quantity: quantity,
        p_reason_code: reasonCode,
        p_comment: comment || null,
      });

      if (error) throw error;

      const result = data as any;
      const sellerName = sellers.find(s => s.id === selectedSeller)?.name || '';

      let msg = `${STAR_EMOJI[starType]} ${quantity} estrela(s) ${starType} concedida(s) para ${sellerName}`;
      if (result?.conversions?.length > 0) {
        const convTexts = result.conversions.map((c: any) => `${STAR_EMOJI[c.type]} ${c.type}`);
        msg += ` — Conversões: ${convTexts.join(', ')}`;
      }
      if (result?.new_crystals > 0) {
        msg += ` 💎 CRISTAL conquistada! Prêmio R$ 1.000 registrado.`;
      }

      toast.success(msg);
      setGrantOpen(false);
      setSelectedSeller('');
      setStarType('BRONZE');
      setQuantity(1);
      setReasonCode('');
      setComment('');
      fetchData();
    } catch (err: any) {
      toast.error(err.message || 'Erro ao conceder estrela');
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <div className="py-8 text-center text-[#121216]/40 animate-pulse">Carregando...</div>;

  return (
    <div className="mt-4 space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-base font-bold text-[#121216] flex items-center gap-2">
          <Award className="h-5 w-5 text-[#FF6A00]" /> Estrelas & Reconhecimento
        </h3>
        <Button onClick={() => setGrantOpen(true)} className="rounded-xl gap-2">
          <Sparkles className="h-4 w-4" /> Conceder Estrela
        </Button>
      </div>

      {/* Sellers table */}
      <Card className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-sm border border-white/60">
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-[#F4F4F4]">
                  <th className="text-left px-4 py-3 text-[#121216]/50 font-medium">Colaborador</th>
                  <th className="text-left px-4 py-3 text-[#121216]/50 font-medium">Cargo</th>
                  <th className="text-center px-3 py-3">🥉</th>
                  <th className="text-center px-3 py-3">🥈</th>
                  <th className="text-center px-3 py-3">🥇</th>
                  <th className="text-center px-3 py-3">💎</th>
                  <th className="text-right px-4 py-3">Ações</th>
                </tr>
              </thead>
              <tbody>
                {sellers.map(s => {
                  const b = balances[s.id];
                  return (
                    <tr key={s.id} className="border-b border-[#F4F4F4] last:border-0 hover:bg-[#F4F4F4]/30">
                      <td className="px-4 py-3 font-medium text-[#121216]">{s.name}</td>
                      <td className="px-4 py-3 text-[#121216]/60 capitalize">{s.role}</td>
                      <td className="text-center px-3 py-3 font-bold">{b?.bronze_count || 0}</td>
                      <td className="text-center px-3 py-3 font-bold">{b?.silver_count || 0}</td>
                      <td className="text-center px-3 py-3 font-bold">{b?.gold_count || 0}</td>
                      <td className="text-center px-3 py-3 font-bold">{b?.crystal_count || 0}</td>
                      <td className="text-right px-4 py-3 space-x-1">
                        <Button
                          variant="ghost"
                          size="sm"
                          className="rounded-xl text-xs"
                          onClick={() => { setSelectedSeller(s.id); setGrantOpen(true); }}
                        >
                          Conceder
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="rounded-xl text-xs"
                          onClick={() => fetchHistory(s.id)}
                        >
                          <History className="h-3.5 w-3.5" />
                        </Button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Grant Modal */}
      <Dialog open={grantOpen} onOpenChange={v => { if (!saving) setGrantOpen(v); }}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Award className="h-5 w-5 text-[#FF6A00]" /> Conceder Estrela
            </DialogTitle>
            <DialogDescription>
              Reconheça o desempenho de um colaborador. Cristal é gerado apenas por conversão automática.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label>Colaborador</Label>
              <Select value={selectedSeller} onValueChange={setSelectedSeller}>
                <SelectTrigger><SelectValue placeholder="Selecione..." /></SelectTrigger>
                <SelectContent>
                  {sellers.map(s => (
                    <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Tipo de Estrela</Label>
              <div className="flex gap-2">
                {(['BRONZE', 'PRATA', 'OURO'] as const).map(t => (
                  <button
                    key={t}
                    type="button"
                    onClick={() => setStarType(t)}
                    className={`flex-1 p-3 rounded-xl border-2 transition-all text-center ${
                      starType === t ? 'border-[#FF6A00] bg-[#FF6A00]/5' : 'border-[#F4F4F4] hover:border-[#FF6A00]/30'
                    }`}
                  >
                    <span className="text-2xl">{STAR_EMOJI[t]}</span>
                    <p className="text-xs font-medium mt-1 text-[#121216]">{t}</p>
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <Label>Quantidade (1–3)</Label>
              <Input
                type="number"
                min={1}
                max={3}
                value={quantity}
                onChange={e => setQuantity(Math.min(3, Math.max(1, parseInt(e.target.value) || 1)))}
                className="w-24 rounded-xl"
              />
            </div>

            <div className="space-y-2">
              <Label>Motivo *</Label>
              <Select value={reasonCode} onValueChange={setReasonCode}>
                <SelectTrigger><SelectValue placeholder="Selecione o motivo..." /></SelectTrigger>
                <SelectContent>
                  {REASON_OPTIONS.map(r => (
                    <SelectItem key={r.value} value={r.value}>{r.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Comentário {reasonCode === 'OUTRO' ? '*' : '(opcional)'}</Label>
              <Textarea
                value={comment}
                onChange={e => setComment(e.target.value)}
                placeholder="Detalhe o reconhecimento..."
                rows={2}
                className="rounded-xl"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setGrantOpen(false)} disabled={saving} className="rounded-xl">
              Cancelar
            </Button>
            <Button onClick={handleGrant} disabled={saving || !selectedSeller || !reasonCode} className="rounded-xl gap-2">
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
              {saving ? 'Salvando...' : 'Confirmar'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* History Modal */}
      <Dialog open={!!historyOpen} onOpenChange={() => setHistoryOpen(null)}>
        <DialogContent className="sm:max-w-lg max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <History className="h-5 w-5 text-[#FF6A00]" /> Histórico de Estrelas
            </DialogTitle>
            <DialogDescription>
              {sellers.find(s => s.id === historyOpen)?.name}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-2 mt-2">
            {ledger.length === 0 && <p className="text-sm text-[#121216]/40 text-center py-4">Nenhum registro</p>}
            {ledger.map(entry => (
              <div key={entry.id} className="flex items-start gap-3 p-3 rounded-xl bg-[#F4F4F4]/50">
                <span className="text-xl">{STAR_EMOJI[entry.star_type]}</span>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium text-[#121216]">
                      {entry.star_type} ×{entry.quantity}
                    </span>
                    {entry.reason_code === 'CONVERSAO_AUTOMATICA' && (
                      <Badge variant="outline" className="text-[10px] rounded-lg">Auto</Badge>
                    )}
                  </div>
                  <p className="text-xs text-[#121216]/50 mt-0.5">
                    {REASON_OPTIONS.find(r => r.value === entry.reason_code)?.label || entry.reason_code}
                  </p>
                  {entry.comment && <p className="text-xs text-[#121216]/60 mt-1">{entry.comment}</p>}
                </div>
                <span className="text-xs text-[#121216]/40 whitespace-nowrap">
                  {format(parseISO(entry.created_at), 'dd/MM/yy', { locale: ptBR })}
                </span>
              </div>
            ))}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
