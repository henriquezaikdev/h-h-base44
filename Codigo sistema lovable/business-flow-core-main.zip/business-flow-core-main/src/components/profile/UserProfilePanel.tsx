import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useCoinsAndMedals } from '@/hooks/useCoinsAndMedals';
import { MedalsDisplay } from '@/components/coins/MedalsDisplay';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  CheckCircle,
  AlertTriangle,
  Clock,
  Flame,
  Coins,
  Activity,
  Briefcase,
  User,
} from 'lucide-react';
import { format, parseISO, subDays } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { motion } from 'framer-motion';

interface UserProfilePanelProps {
  userId: string;
}

interface SellerProfile {
  id: string;
  name: string;
  email: string | null;
  role: string;
  department: string | null;
  avatar_url: string | null;
  bio: string | null;
  xp_total: number;
  xp_spent: number;
  level: number;
  score_current: number;
  last_login_at: string | null;
}

interface TaskKPIs {
  completedCount: number;
  onTimePercent: number;
  overdueOpen: number;
  criticalOpen: number;
}

interface ActivityItem {
  id: string;
  action_type: string;
  entity_id: string | null;
  meta_json: any;
  created_at: string;
}

const ROLE_LABELS: Record<string, string> = {
  admin: 'Administrador',
  vendedor: 'Vendedor',
  owner: 'Proprietário',
  comprador: 'Comprador',
  financeiro_gestora: 'Financeiro / Gestora',
  logistica: 'Logística',
};

const DEPT_LABELS: Record<string, string> = {
  vendas: 'Vendas',
  financeiro_gestora: 'Financeiro / Gestão',
  logistica: 'Logística',
  compras: 'Compras',
};

const ACTION_LABELS: Record<string, string> = {
  task_completed: 'Concluiu tarefa',
  task_created: 'Criou tarefa',
  task_bucket_moved: 'Moveu tarefa',
  pendency_resolved: 'Resolveu pendência',
};

export function UserProfilePanel({ userId }: UserProfilePanelProps) {
  const [profile, setProfile] = useState<SellerProfile | null>(null);
  const [kpis, setKpis] = useState<TaskKPIs>({ completedCount: 0, onTimePercent: 0, overdueOpen: 0, criticalOpen: 0 });
  const [activities, setActivities] = useState<ActivityItem[]>([]);
  const [loading, setLoading] = useState(true);

  const { balance, coins7d, coins30d, medals, loading: loadingCoins } = useCoinsAndMedals(userId);

  const fetchProfile = useCallback(async () => {
    if (!userId) return;
    setLoading(true);
    try {
      // Profile
      const { data: seller } = await supabase
        .from('sellers')
        .select('id, name, email, role, department, avatar_url, bio, xp_total, xp_spent, level, score_current, last_login_at')
        .eq('id', userId)
        .maybeSingle();

      if (seller) setProfile(seller as unknown as SellerProfile);

      // KPIs (30 days)
      const thirtyDaysAgo = subDays(new Date(), 30).toISOString();
      const today = new Date().toISOString().split('T')[0];

      // Completed tasks in 30d
      const { data: completedTasks } = await supabase
        .from('tasks')
        .select('id, completed_at, task_date')
        .eq('created_by_seller_id', userId)
        .eq('status', 'concluida')
        .gte('completed_at', thirtyDaysAgo);

      const completed = completedTasks || [];
      const onTime = completed.filter(t => {
        if (!t.completed_at || !t.task_date) return false;
        return t.completed_at.split('T')[0] <= t.task_date;
      });

      // Overdue open
      const { count: overdueCount } = await supabase
        .from('tasks')
        .select('id', { count: 'exact', head: true })
        .eq('created_by_seller_id', userId)
        .neq('status', 'concluida')
        .neq('status', 'cancelada')
        .is('archived_at', null)
        .lt('task_date', today);

      // Critical open
      const { count: criticalCount } = await supabase
        .from('tasks')
        .select('id', { count: 'exact', head: true })
        .eq('created_by_seller_id', userId)
        .neq('status', 'concluida')
        .neq('status', 'cancelada')
        .is('archived_at', null)
        .eq('priority', 'alta');

      setKpis({
        completedCount: completed.length,
        onTimePercent: completed.length > 0 ? Math.round((onTime.length / completed.length) * 100) : 0,
        overdueOpen: overdueCount || 0,
        criticalOpen: criticalCount || 0,
      });

      // Activity log
      const { data: activityData } = await supabase
        .from('task_activity_log')
        .select('id, action_type, entity_id, meta_json, created_at')
        .eq('user_id', userId)
        .order('created_at', { ascending: false })
        .limit(10);

      setActivities((activityData || []) as ActivityItem[]);
    } catch (err) {
      console.error('Error fetching profile:', err);
    } finally {
      setLoading(false);
    }
  }, [userId]);

  useEffect(() => {
    fetchProfile();
  }, [fetchProfile]);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-16">
        <div className="animate-pulse text-muted-foreground text-sm">Carregando perfil...</div>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="flex items-center justify-center py-16">
        <p className="text-muted-foreground text-sm">Perfil não encontrado</p>
      </div>
    );
  }

  const initials = profile.name
    .split(' ')
    .map(n => n[0])
    .join('')
    .slice(0, 2)
    .toUpperCase();

  return (
    <ScrollArea className="h-full">
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="p-5 space-y-5"
      >
        {/* Header Card */}
        <div className="relative overflow-hidden rounded-xl border bg-gradient-to-br from-primary/10 via-background to-accent/10 p-5">
          <div className="flex items-start gap-4">
            <Avatar className="h-16 w-16 border-2 border-primary/20 shadow-md">
              <AvatarImage src={profile.avatar_url || undefined} />
              <AvatarFallback className="bg-primary/10 text-primary text-lg font-semibold">
                {initials}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <h3 className="text-lg font-bold truncate">{profile.name}</h3>
              <div className="flex flex-wrap items-center gap-1.5 mt-1">
                <Badge variant="secondary" className="text-xs">
                  <Briefcase className="h-3 w-3 mr-1" />
                  {ROLE_LABELS[profile.role] || profile.role}
                </Badge>
                {profile.department && (
                  <Badge variant="outline" className="text-xs">
                    {DEPT_LABELS[profile.department] || profile.department}
                  </Badge>
                )}
              </div>
              {profile.bio && (
                <p className="text-sm text-muted-foreground mt-2 line-clamp-2">{profile.bio}</p>
              )}
            </div>
          </div>
          <div className="flex items-center gap-4 mt-4 pt-3 border-t border-border/50">
            <div className="text-center flex-1">
              <p className="text-xl font-bold text-primary">{profile.level}</p>
              <p className="text-[10px] text-muted-foreground uppercase tracking-wide">Nível</p>
            </div>
            <Separator orientation="vertical" className="h-8" />
            <div className="text-center flex-1">
              <p className="text-xl font-bold">{(profile.xp_total - (profile.xp_spent || 0)).toLocaleString('pt-BR')}</p>
              <p className="text-[10px] text-muted-foreground uppercase tracking-wide">XP</p>
            </div>
            <Separator orientation="vertical" className="h-8" />
            <div className="text-center flex-1">
              <p className="text-xl font-bold">{profile.score_current}</p>
              <p className="text-[10px] text-muted-foreground uppercase tracking-wide">Score</p>
            </div>
          </div>
        </div>

        {/* KPIs (30d) */}
        <div>
          <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-3 flex items-center gap-1.5">
            <Activity className="h-3.5 w-3.5" />
            Desempenho — 30 dias
          </h4>
          <div className="grid grid-cols-2 gap-2.5">
            <Card className="border-emerald-500/20">
              <CardContent className="p-3 flex items-center gap-3">
                <div className="h-9 w-9 rounded-lg bg-emerald-500/10 flex items-center justify-center shrink-0">
                  <CheckCircle className="h-4.5 w-4.5 text-emerald-600" />
                </div>
                <div>
                  <p className="text-lg font-bold leading-none">{kpis.onTimePercent}%</p>
                  <p className="text-[10px] text-muted-foreground mt-0.5">No prazo ({kpis.completedCount})</p>
                </div>
              </CardContent>
            </Card>
            <Card className="border-red-500/20">
              <CardContent className="p-3 flex items-center gap-3">
                <div className="h-9 w-9 rounded-lg bg-red-500/10 flex items-center justify-center shrink-0">
                  <AlertTriangle className="h-4.5 w-4.5 text-red-600" />
                </div>
                <div>
                  <p className="text-lg font-bold leading-none">{kpis.overdueOpen}</p>
                  <p className="text-[10px] text-muted-foreground mt-0.5">Atrasadas</p>
                </div>
              </CardContent>
            </Card>
            <Card className="border-orange-500/20">
              <CardContent className="p-3 flex items-center gap-3">
                <div className="h-9 w-9 rounded-lg bg-orange-500/10 flex items-center justify-center shrink-0">
                  <Flame className="h-4.5 w-4.5 text-orange-600" />
                </div>
                <div>
                  <p className="text-lg font-bold leading-none">{kpis.criticalOpen}</p>
                  <p className="text-[10px] text-muted-foreground mt-0.5">Críticas abertas</p>
                </div>
              </CardContent>
            </Card>
            <Card className="border-blue-500/20">
              <CardContent className="p-3 flex items-center gap-3">
                <div className="h-9 w-9 rounded-lg bg-blue-500/10 flex items-center justify-center shrink-0">
                  <CheckCircle className="h-4.5 w-4.5 text-blue-600" />
                </div>
                <div>
                  <p className="text-lg font-bold leading-none">{kpis.completedCount}</p>
                  <p className="text-[10px] text-muted-foreground mt-0.5">Concluídas</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* H-Coins */}
        <div>
          <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-3 flex items-center gap-1.5">
            <Coins className="h-3.5 w-3.5" />
            H-Coins
          </h4>
          {loadingCoins ? (
            <div className="text-sm text-muted-foreground py-2">Carregando...</div>
          ) : (
            <Card>
              <CardContent className="p-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-full bg-amber-500/10 flex items-center justify-center">
                      <Coins className="h-5 w-5 text-amber-600" />
                    </div>
                    <div>
                      <p className="text-2xl font-bold">{balance}</p>
                      <p className="text-[10px] text-muted-foreground">Saldo atual</p>
                    </div>
                  </div>
                  <div className="flex gap-4 text-center">
                    <div>
                      <p className="text-sm font-semibold">{coins7d}</p>
                      <p className="text-[10px] text-muted-foreground">7 dias</p>
                    </div>
                    <div>
                      <p className="text-sm font-semibold">{coins30d}</p>
                      <p className="text-[10px] text-muted-foreground">30 dias</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Medals */}
        <div>
          <MedalsDisplay medals={medals} compact maxShow={6} />
        </div>

        {/* Activity */}
        <div>
          <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-3 flex items-center gap-1.5">
            <Clock className="h-3.5 w-3.5" />
            Atividade Recente
          </h4>
          {activities.length === 0 ? (
            <p className="text-sm text-muted-foreground py-3">Nenhuma atividade registrada</p>
          ) : (
            <div className="space-y-1.5">
              {activities.map((a) => (
                <div key={a.id} className="flex items-center gap-3 py-2 px-3 rounded-lg bg-muted/30 hover:bg-muted/50 transition-colors">
                  <div className="h-6 w-6 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                    <Activity className="h-3 w-3 text-primary" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm truncate">
                      {ACTION_LABELS[a.action_type] || a.action_type}
                    </p>
                  </div>
                  <span className="text-[10px] text-muted-foreground shrink-0">
                    {format(parseISO(a.created_at), "dd/MM HH:mm", { locale: ptBR })}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </motion.div>
    </ScrollArea>
  );
}
