import { useState, useEffect, useCallback, useRef } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Search, ThumbsUp, MessageCircle, ImagePlus, Send, X, Loader2, MoreHorizontal, Pencil, Trash2,
} from 'lucide-react';
import { format, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from 'sonner';

// Only show user-created social posts, not system events
const SOCIAL_EVENT_TYPES = ['USER_POST', 'RECOGNITION'];
const SYSTEM_EVENT_TYPES = ['MEDAL_EARNED', 'STAR_GRANTED', 'STAR_CONVERTED', 'CRYSTAL_EARNED', 'XP_MILESTONE', 'SYSTEM', 'HCOINS_CONVERSION', 'SHOP_REQUESTED', 'SHOP_APPROVED', 'SHOP_FULFILLED'];

interface FeedEvent {
  id: string;
  event_type: string;
  actor_user_id: string | null;
  target_user_id: string | null;
  title: string;
  body: string;
  subtitle: string | null;
  image_url: string | null;
  visibility: string;
  meta_json: any;
  created_at: string;
  actor?: { name: string } | null;
  target?: { name: string } | null;
  like_count: number;
  user_liked: boolean;
  comment_count: number;
}

interface FeedComment {
  id: string;
  content: string;
  created_at: string;
  user_id: string;
  user?: { name: string } | null;
}

export function ProfileFeedMural() {
  const { seller } = useAuth();
  const [events, setEvents] = useState<FeedEvent[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [likeLoading, setLikeLoading] = useState<string | null>(null);
  const [visibleCount, setVisibleCount] = useState(5);

  // Post creation state
  const [postText, setPostText] = useState('');
  const [postImage, setPostImage] = useState<File | null>(null);
  const [postImagePreview, setPostImagePreview] = useState<string | null>(null);
  const [posting, setPosting] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Comments state
  const [expandedComments, setExpandedComments] = useState<Set<string>>(new Set());
  const [comments, setComments] = useState<Record<string, FeedComment[]>>({});
  const [newComment, setNewComment] = useState<Record<string, string>>({});
  const [loadingComments, setLoadingComments] = useState<Set<string>>(new Set());

  // Edit/Delete state
  const [editingPostId, setEditingPostId] = useState<string | null>(null);
  const [editText, setEditText] = useState('');
  const [editSaving, setEditSaving] = useState(false);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [deleting, setDeleting] = useState(false);

  const fetchEvents = useCallback(async () => {
    const { data: eventsData } = await supabase
      .from('feed_events')
      .select(`
        *,
        actor:sellers!feed_events_actor_user_id_fkey(name),
        target:sellers!feed_events_target_user_id_fkey(name)
      `)
      .not('event_type', 'in', `(${SYSTEM_EVENT_TYPES.join(',')})`)
      .or('hidden.is.null,hidden.eq.false')
      .order('created_at', { ascending: false })
      .limit(50);

    if (!eventsData) {
      setEvents([]);
      setLoading(false);
      return;
    }

    const eventIds = eventsData.map(e => e.id);

    const [likesRes, userLikesRes, commentsCountRes] = await Promise.all([
      supabase.from('feed_likes').select('event_id').in('event_id', eventIds),
      seller?.id
        ? supabase.from('feed_likes').select('event_id').in('event_id', eventIds).eq('user_id', seller.id)
        : Promise.resolve({ data: [] }),
      supabase.from('feed_comments').select('feed_event_id').in('feed_event_id', eventIds).eq('deleted', false),
    ]);

    const likeCounts: Record<string, number> = {};
    (likesRes.data || []).forEach((l: any) => {
      likeCounts[l.event_id] = (likeCounts[l.event_id] || 0) + 1;
    });

    const commentCounts: Record<string, number> = {};
    (commentsCountRes.data || []).forEach((c: any) => {
      commentCounts[c.feed_event_id] = (commentCounts[c.feed_event_id] || 0) + 1;
    });

    const userLikedSet = new Set((userLikesRes.data || []).map((l: any) => l.event_id));

    const mapped: FeedEvent[] = eventsData.map((e: any) => ({
      ...e,
      body: e.body || e.subtitle || '',
      event_type: e.event_type || 'USER_POST',
      like_count: likeCounts[e.id] || 0,
      user_liked: userLikedSet.has(e.id),
      comment_count: commentCounts[e.id] || 0,
    }));

    setEvents(mapped);
    setLoading(false);
  }, [seller?.id]);

  useEffect(() => { fetchEvents(); }, [fetchEvents]);

  // Handle image selection
  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      toast.error('Imagem deve ter no máximo 5MB');
      return;
    }
    setPostImage(file);
    setPostImagePreview(URL.createObjectURL(file));
  };

  const removeImage = () => {
    setPostImage(null);
    setPostImagePreview(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  // Create a new post
  const handleCreatePost = async () => {
    if (!seller?.id || (!postText.trim() && !postImage)) return;
    setPosting(true);

    try {
      let imageUrl: string | null = null;

      // Upload image if present
      if (postImage) {
        const ext = postImage.name.split('.').pop();
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) throw new Error('Not authenticated');
        const path = `${user.id}/${Date.now()}.${ext}`;
        const { error: uploadErr } = await supabase.storage
          .from('feed-photos')
          .upload(path, postImage);

        if (uploadErr) throw uploadErr;

        const { data: urlData } = supabase.storage
          .from('feed-photos')
          .getPublicUrl(path);

        imageUrl = urlData.publicUrl;
      }

      const { error } = await supabase.from('feed_events').insert({
        type: 'USER_POST',
        event_type: 'USER_POST',
        actor_user_id: seller.id,
        target_user_id: seller.id,
        title: seller.name || 'Usuário',
        body: postText.trim() || null,
        image_url: imageUrl,
        visibility: 'PUBLIC',
      });

      if (error) throw error;

      setPostText('');
      removeImage();
      toast.success('Post publicado!');
      fetchEvents();
    } catch (err) {
      console.error('Error creating post:', err);
      toast.error('Erro ao publicar');
    } finally {
      setPosting(false);
    }
  };

  // Like / unlike
  const handleLike = async (eventId: string, currentlyLiked: boolean) => {
    if (!seller?.id || likeLoading) return;
    setLikeLoading(eventId);

    try {
      if (currentlyLiked) {
        await supabase.from('feed_likes').delete().eq('event_id', eventId).eq('user_id', seller.id);
      } else {
        await supabase.from('feed_likes').insert({ event_id: eventId, user_id: seller.id });
      }

      setEvents(prev => prev.map(e =>
        e.id === eventId
          ? { ...e, user_liked: !currentlyLiked, like_count: e.like_count + (currentlyLiked ? -1 : 1) }
          : e
      ));
    } catch {
      toast.error('Erro ao curtir');
    } finally {
      setLikeLoading(null);
    }
  };

  // Comments
  const toggleComments = async (eventId: string) => {
    const next = new Set(expandedComments);
    if (next.has(eventId)) {
      next.delete(eventId);
    } else {
      next.add(eventId);
      if (!comments[eventId]) {
        await fetchComments(eventId);
      }
    }
    setExpandedComments(next);
  };

  const fetchComments = async (eventId: string) => {
    setLoadingComments(prev => new Set(prev).add(eventId));
    const { data } = await supabase
      .from('feed_comments')
      .select('*, user:sellers!feed_comments_user_id_fkey(name)')
      .eq('feed_event_id', eventId)
      .eq('deleted', false)
      .order('created_at', { ascending: true });

    setComments(prev => ({ ...prev, [eventId]: data || [] }));
    setLoadingComments(prev => {
      const next = new Set(prev);
      next.delete(eventId);
      return next;
    });
  };

  const handleComment = async (eventId: string) => {
    const text = newComment[eventId]?.trim();
    if (!text || !seller?.id) return;

    await supabase.from('feed_comments').insert({
      feed_event_id: eventId,
      user_id: seller.id,
      content: text,
    });

    setNewComment(prev => ({ ...prev, [eventId]: '' }));
    await fetchComments(eventId);
    setEvents(prev => prev.map(e =>
      e.id === eventId ? { ...e, comment_count: e.comment_count + 1 } : e
    ));
  };

  // Edit post
  const handleStartEdit = (event: FeedEvent) => {
    setEditingPostId(event.id);
    setEditText(event.body || '');
  };

  const handleSaveEdit = async () => {
    if (!editingPostId) return;
    setEditSaving(true);
    try {
      const { error } = await supabase
        .from('feed_events')
        .update({ body: editText.trim() || null })
        .eq('id', editingPostId);
      if (error) throw error;
      setEvents(prev => prev.map(e =>
        e.id === editingPostId ? { ...e, body: editText.trim() } : e
      ));
      setEditingPostId(null);
      setEditText('');
      toast.success('Post atualizado!');
    } catch {
      toast.error('Erro ao editar post');
    } finally {
      setEditSaving(false);
    }
  };

  // Delete post
  const handleDeletePost = async () => {
    if (!deleteConfirmId) return;
    setDeleting(true);
    try {
      const { error } = await supabase
        .from('feed_events')
        .update({ hidden: true })
        .eq('id', deleteConfirmId);
      if (error) throw error;
      setEvents(prev => prev.filter(e => e.id !== deleteConfirmId));
      setDeleteConfirmId(null);
      toast.success('Post excluído!');
    } catch {
      toast.error('Erro ao excluir post');
    } finally {
      setDeleting(false);
    }
  };

  const canEditPost = (event: FeedEvent) => event.actor_user_id === seller?.id;
  const canDeletePost = (event: FeedEvent) =>
    event.actor_user_id === seller?.id || seller?.role === 'owner' || seller?.role === 'master';

  // Filter by search
  const filtered = events.filter(e => {
    if (!search) return true;
    const s = search.toLowerCase();
    return (
      e.title.toLowerCase().includes(s) ||
      e.body.toLowerCase().includes(s) ||
      (e.actor?.name || '').toLowerCase().includes(s)
    );
  });

  useEffect(() => { setVisibleCount(5); }, [search]);

  const visibleEvents = filtered.slice(0, visibleCount);
  const hasMore = filtered.length > visibleCount;

  const getInitials = (name: string) =>
    name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase();

  return (
    <div className="space-y-4">
      {/* Header */}
      <div>
        <h2 className="text-base font-semibold text-foreground">Mural H&H</h2>
        <p className="text-xs text-muted-foreground mt-0.5">Compartilhe momentos, fotos e mensagens com a equipe.</p>
      </div>

      {/* Create Post */}
      <div className="bg-card rounded-2xl border border-border shadow-sm p-4">
        <div className="flex items-start gap-3">
          <Avatar className="h-9 w-9 shrink-0">
            <AvatarFallback className="text-xs bg-orange-50 text-[#FF6A00] font-semibold">
              {seller?.name ? getInitials(seller.name) : '?'}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 space-y-3">
            <Textarea
              value={postText}
              onChange={e => setPostText(e.target.value)}
              placeholder="O que você quer compartilhar?"
              className="resize-none min-h-[60px] border-0 bg-muted/30 rounded-xl text-sm placeholder:text-muted-foreground/50 focus-visible:ring-1 focus-visible:ring-[#FF6A00]/30"
              rows={2}
            />

            {/* Image Preview */}
            <AnimatePresence>
              {postImagePreview && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className="relative"
                >
                  <img
                    src={postImagePreview}
                    alt="Preview"
                    className="w-full max-h-64 object-cover rounded-xl"
                  />
                  <Button
                    variant="ghost"
                    size="icon"
                    className="absolute top-2 right-2 h-7 w-7 bg-black/50 hover:bg-black/70 text-white rounded-full"
                    onClick={removeImage}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </motion.div>
              )}
            </AnimatePresence>

            <div className="flex items-center justify-between">
              <Button
                variant="ghost"
                size="sm"
                className="rounded-xl text-xs gap-1.5 text-muted-foreground hover:text-[#FF6A00] hover:bg-orange-50"
                onClick={() => fileInputRef.current?.click()}
              >
                <ImagePlus className="h-4 w-4" />
                Foto
              </Button>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={handleImageSelect}
              />
              <Button
                size="sm"
                className="rounded-xl text-xs gap-1.5 bg-[#FF6A00] hover:bg-[#FF6A00]/90 text-white"
                onClick={handleCreatePost}
                disabled={posting || (!postText.trim() && !postImage)}
              >
                {posting ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Send className="h-3.5 w-3.5" />}
                Publicar
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground/40" />
        <Input
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="Buscar no feed..."
          className="pl-10 rounded-xl bg-card border-border text-foreground placeholder:text-muted-foreground/40"
        />
      </div>

      {/* Posts */}
      {loading ? (
        <div className="space-y-3">
          {[1, 2, 3].map(i => (
            <div key={i} className="rounded-2xl animate-pulse h-32 bg-muted/50" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="bg-card rounded-2xl border border-border p-8 text-center text-muted-foreground">
          Nenhuma publicação encontrada. Seja o primeiro a postar!
        </div>
      ) : (
        <>
          <AnimatePresence initial={false}>
            {visibleEvents.map((event, idx) => (
              <motion.div
                key={event.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ delay: idx * 0.03 }}
              >
                <div className="bg-card rounded-2xl border border-border shadow-sm mb-3 overflow-hidden">
                  {/* Post Header */}
                  <div className="p-4 pb-0">
                    <div className="flex items-center gap-3">
                      <Avatar className="h-9 w-9">
                        <AvatarFallback className="text-xs bg-orange-50 text-[#FF6A00] font-semibold">
                          {event.actor?.name ? getInitials(event.actor.name) : '??'}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-semibold text-foreground truncate">
                          {event.actor?.name || event.title}
                        </p>
                        <p className="text-[11px] text-muted-foreground">
                          {format(parseISO(event.created_at), "dd 'de' MMMM 'às' HH:mm", { locale: ptBR })}
                        </p>
                      </div>
                      {(canEditPost(event) || canDeletePost(event)) && (
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-foreground">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end" className="w-40">
                            {canEditPost(event) && (
                              <DropdownMenuItem onClick={() => handleStartEdit(event)} className="gap-2 text-xs">
                                <Pencil className="h-3.5 w-3.5" />
                                Editar
                              </DropdownMenuItem>
                            )}
                            {canDeletePost(event) && (
                              <DropdownMenuItem onClick={() => setDeleteConfirmId(event.id)} className="gap-2 text-xs text-destructive focus:text-destructive">
                                <Trash2 className="h-3.5 w-3.5" />
                                Excluir
                              </DropdownMenuItem>
                            )}
                          </DropdownMenuContent>
                        </DropdownMenu>
                      )}
                    </div>
                  </div>

                  {/* Post Body */}
                  {editingPostId === event.id ? (
                    <div className="px-4 pt-3 space-y-2">
                      <Textarea
                        value={editText}
                        onChange={e => setEditText(e.target.value)}
                        className="resize-none min-h-[60px] text-sm rounded-xl"
                        rows={3}
                        autoFocus
                      />
                      <div className="flex gap-2 justify-end">
                        <Button variant="ghost" size="sm" className="text-xs rounded-xl" onClick={() => setEditingPostId(null)} disabled={editSaving}>
                          Cancelar
                        </Button>
                        <Button size="sm" className="text-xs rounded-xl bg-[#FF6A00] hover:bg-[#FF6A00]/90 text-white" onClick={handleSaveEdit} disabled={editSaving}>
                          {editSaving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : 'Salvar'}
                        </Button>
                      </div>
                    </div>
                  ) : event.body ? (
                    <div className="px-4 pt-3">
                      <p className="text-sm text-foreground leading-relaxed whitespace-pre-wrap">{event.body}</p>
                    </div>
                  ) : null}

                  {/* Post Image */}
                  {event.image_url && (
                    <div className="mt-3 rounded-lg overflow-hidden">
                      <img
                        src={event.image_url}
                        alt="Post"
                        className="w-full h-auto object-contain"
                        loading="lazy"
                      />
                    </div>
                  )}

                  {/* Like & Comment Counts */}
                  {(event.like_count > 0 || event.comment_count > 0) && (
                    <div className="px-4 pt-3 flex items-center gap-4 text-xs text-muted-foreground">
                      {event.like_count > 0 && (
                        <span>{event.like_count} curtida{event.like_count > 1 ? 's' : ''}</span>
                      )}
                      {event.comment_count > 0 && (
                        <button
                          className="hover:underline"
                          onClick={() => toggleComments(event.id)}
                        >
                          {event.comment_count} comentário{event.comment_count > 1 ? 's' : ''}
                        </button>
                      )}
                    </div>
                  )}

                  {/* Actions */}
                  <div className="px-4 py-2 mt-1 border-t border-border/50 flex items-center gap-1">
                    <Button
                      variant="ghost"
                      size="sm"
                      className={`flex-1 rounded-xl text-xs gap-1.5 ${event.user_liked ? 'text-[#FF6A00]' : 'text-muted-foreground'} hover:bg-orange-50`}
                      onClick={() => handleLike(event.id, event.user_liked)}
                      disabled={likeLoading === event.id}
                    >
                      <ThumbsUp className={`h-4 w-4 ${event.user_liked ? 'fill-[#FF6A00]' : ''}`} />
                      Curtir
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="flex-1 rounded-xl text-xs gap-1.5 text-muted-foreground hover:bg-muted/50"
                      onClick={() => toggleComments(event.id)}
                    >
                      <MessageCircle className="h-4 w-4" />
                      Comentar
                    </Button>
                  </div>

                  {/* Comments Section */}
                  <AnimatePresence>
                    {expandedComments.has(event.id) && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        className="border-t border-border/50 overflow-hidden"
                      >
                        <div className="p-4 space-y-3">
                          {loadingComments.has(event.id) ? (
                            <div className="flex justify-center py-2">
                              <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
                            </div>
                          ) : (
                            <>
                              {(comments[event.id] || []).map(comment => (
                                <div key={comment.id} className="flex items-start gap-2">
                                  <Avatar className="h-6 w-6 shrink-0">
                                    <AvatarFallback className="text-[8px] bg-muted text-muted-foreground font-semibold">
                                      {comment.user?.name ? getInitials(comment.user.name) : '??'}
                                    </AvatarFallback>
                                  </Avatar>
                                  <div className="bg-muted/50 rounded-xl px-3 py-2 text-xs">
                                    <span className="font-semibold text-foreground">{comment.user?.name || 'Usuário'}</span>
                                    <p className="text-foreground/80 mt-0.5">{comment.content}</p>
                                  </div>
                                </div>
                              ))}
                            </>
                          )}

                          {/* New comment input */}
                          <div className="flex items-center gap-2">
                            <Avatar className="h-6 w-6 shrink-0">
                              <AvatarFallback className="text-[8px] bg-orange-50 text-[#FF6A00] font-semibold">
                                {seller?.name ? getInitials(seller.name) : '?'}
                              </AvatarFallback>
                            </Avatar>
                            <Input
                              value={newComment[event.id] || ''}
                              onChange={e => setNewComment(prev => ({ ...prev, [event.id]: e.target.value }))}
                              placeholder="Escreva um comentário..."
                              className="flex-1 h-8 rounded-full text-xs bg-muted/30 border-border"
                              onKeyDown={e => {
                                if (e.key === 'Enter' && !e.shiftKey) {
                                  e.preventDefault();
                                  handleComment(event.id);
                                }
                              }}
                            />
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8 text-[#FF6A00] hover:bg-orange-50"
                              onClick={() => handleComment(event.id)}
                              disabled={!newComment[event.id]?.trim()}
                            >
                              <Send className="h-3.5 w-3.5" />
                            </Button>
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>

          {hasMore && (
            <div className="text-center pt-2">
              <Button
                variant="ghost"
                size="sm"
                className="text-xs text-muted-foreground hover:text-foreground"
                onClick={() => setVisibleCount(prev => prev + 5)}
              >
                Ver mais ({filtered.length - visibleCount} restantes)
              </Button>
            </div>
          )}
        </>
      )}

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={!!deleteConfirmId} onOpenChange={open => !open && setDeleteConfirmId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Excluir publicação?</AlertDialogTitle>
            <AlertDialogDescription>
              Essa ação não pode ser desfeita. A publicação será removida do feed.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeletePost}
              disabled={deleting}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {deleting ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : null}
              Excluir
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
