import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { SellerProfileData, SellerMonthlyStats } from '@/hooks/useSellerProfile';
import { Edit3, Heart, Star, Coins, AlertTriangle, Zap } from 'lucide-react';
import { motion } from 'framer-motion';

const NIVEL_CONFIG: Record<string, { label: string; emoji: string }> = {
  OVO: { label: 'Ovo', emoji: '🥚' },
  PENA: { label: 'Pena', emoji: '🪶' },
  AGUIA: { label: 'Águia', emoji: '🦅' },
};

const ROLE_LABELS: Record<string, string> = {
  vendedor: 'Vendedor',
  compras: 'Compras',
  financeiro: 'Financeiro',
  logistica: 'Logística',
  administrativo: 'Administrativo',
  master: 'Master',
  gestor: 'Gestor',
};

// XP thresholds per level (simplified progression)
function getXpForLevel(level: number): { current: number; next: number } {
  const thresholds = [0, 100, 300, 600, 1000, 1500, 2200, 3000, 4000, 5500, 7500, 10000, 13000, 17000, 22000, 28000, 35000, 45000, 60000, 80000];
  const currentThreshold = thresholds[Math.min(level - 1, thresholds.length - 1)] || 0;
  const nextThreshold = thresholds[Math.min(level, thresholds.length - 1)] || currentThreshold + 5000;
  return { current: currentThreshold, next: nextThreshold };
}

export interface StarsDisplayData {
  bronze_stars: number;
  silver_stars: number;
  gold_stars: number;
  crystal_stars?: number;
}

interface ProfileHeroSectionProps {
  profile: SellerProfileData;
  monthlyStats: SellerMonthlyStats | null;
  starsData?: StarsDisplayData | null;
  isOwnProfile: boolean;
  canSeeDetails: boolean;
  isOwner: boolean;
  onEditProfile: () => void;
  onReconhecer: () => void;
  onAwardStars?: () => void;
  onSendHCoins?: () => void;
  onRegistrarErro?: () => void;
}

export function ProfileHeroSection({
  profile, monthlyStats, starsData, isOwnProfile, canSeeDetails, isOwner, onEditProfile, onReconhecer, onAwardStars, onSendHCoins, onRegistrarErro
}: ProfileHeroSectionProps) {
  const nivel = NIVEL_CONFIG[profile.nivel_atual] || NIVEL_CONFIG.OVO;
  const isComercial = profile.role === 'vendedor';
  const displayName = profile.display_name || profile.name;
  const roleLabel = ROLE_LABELS[profile.role] || profile.role;
  const initials = displayName.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase();

  const totalStars = (starsData?.bronze_stars || 0) + (starsData?.silver_stars || 0) + (starsData?.gold_stars || 0) + (starsData?.crystal_stars || 0);
  const hasStars = totalStars > 0;

  // XP progress calculation
  const { current: xpLevelStart, next: xpLevelEnd } = getXpForLevel(profile.level);
  const xpInLevel = Math.max(0, profile.xp_total - xpLevelStart);
  const xpNeeded = Math.max(1, xpLevelEnd - xpLevelStart);
  const xpPercent = Math.min(100, Math.round((xpInLevel / xpNeeded) * 100));

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, ease: 'easeOut' }}
      className="relative overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-sm"
    >
      {/* Cover gradient band */}
      <div className="h-24 md:h-32 bg-gradient-to-r from-[#3B5BDB] via-[#5B7EF5] to-[#7B9CFF] relative">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImciIHdpZHRoPSI2MCIgaGVpZ2h0PSI2MCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PGNpcmNsZSBjeD0iMzAiIGN5PSIzMCIgcj0iMSIgZmlsbD0icmdiYSgyNTUsMjU1LDI1NSwwLjA4KSIvPjwvcGF0dGVybj48L2RlZnM+PHJlY3QgZmlsbD0idXJsKCNnKSIgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIvPjwvc3ZnPg==')] opacity-50" />
        
        {/* Action buttons on cover */}
        <div className="absolute top-3 right-3 md:top-4 md:right-5 flex flex-wrap gap-1.5 md:gap-2">
          {(isOwnProfile || isOwner) && (
            <Button
              variant="secondary"
              size="sm"
              onClick={onEditProfile}
              className="gap-1.5 rounded-xl bg-white/90 hover:bg-white text-gray-700 text-xs shadow-sm backdrop-blur-sm border-0 h-8"
            >
              <Edit3 className="h-3 w-3" /> Editar
            </Button>
          )}
          {!isOwnProfile && (
            <Button
              size="sm"
              onClick={onReconhecer}
              className="gap-1.5 rounded-xl bg-white/90 hover:bg-white text-[#FF6A00] text-xs shadow-sm backdrop-blur-sm border-0 h-8"
            >
              <Heart className="h-3 w-3" /> Reconhecer
            </Button>
          )}
          {isOwner && !isOwnProfile && onAwardStars && (
            <Button
              size="sm"
              variant="secondary"
              onClick={onAwardStars}
              className="gap-1 rounded-xl bg-white/90 hover:bg-white text-gray-700 text-xs shadow-sm backdrop-blur-sm border-0 h-8"
            >
              <Star className="h-3 w-3 text-amber-500" /> Estrelas
            </Button>
          )}
          {isOwner && !isOwnProfile && onSendHCoins && (
            <Button
              size="sm"
              variant="secondary"
              onClick={onSendHCoins}
              className="gap-1 rounded-xl bg-white/90 hover:bg-white text-gray-700 text-xs shadow-sm backdrop-blur-sm border-0 h-8"
            >
              <Coins className="h-3 w-3 text-orange-500" /> HCoins
            </Button>
          )}
          {!isOwnProfile && onRegistrarErro && (
            <Button
              size="sm"
              variant="secondary"
              onClick={onRegistrarErro}
              className="gap-1 rounded-xl bg-white/90 hover:bg-white text-red-600 text-xs shadow-sm backdrop-blur-sm border-0 h-8"
            >
              <AlertTriangle className="h-3 w-3" /> Erro
            </Button>
          )}
        </div>
      </div>

      {/* Profile content area */}
      <div className="px-4 pb-5 md:px-6 md:pb-6">
        {/* Avatar overlapping cover */}
        <div className="-mt-10 md:-mt-14 flex items-end gap-4 md:gap-5">
          <Avatar className="h-[80px] w-[80px] md:h-[110px] md:w-[110px] border-4 border-white shadow-lg shrink-0 ring-2 ring-gray-100">
            <AvatarImage src={profile.avatar_url || undefined} />
            <AvatarFallback className="bg-[#3B5BDB] text-white text-lg md:text-2xl font-semibold">
              {initials}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0 pb-1">
            <h1 className="text-lg md:text-2xl font-bold text-gray-900 leading-tight truncate tracking-tight">{displayName}</h1>
            <p className="text-xs md:text-sm text-gray-500 mt-1">
              {roleLabel}
              {profile.department ? ` · ${profile.department}` : ''}
            </p>
          </div>
        </div>

        {/* Bio */}
        {(profile.bio || profile.sobre_mim) && (
          <p className="text-xs md:text-sm text-gray-500 mt-3 line-clamp-2 leading-relaxed max-w-2xl">
            {profile.bio || profile.sobre_mim}
          </p>
        )}

        {/* Badges row */}
        <div className="flex items-center gap-1.5 md:gap-2 mt-3 flex-wrap">
          <Badge variant="secondary" className="bg-emerald-50 text-emerald-700 border-0 text-[10px] md:text-xs rounded-full font-medium px-2.5">
            Ativo
          </Badge>
          {isComercial && (
            <Badge variant="secondary" className="bg-[#3B5BDB]/8 text-[#3B5BDB] border-0 text-[10px] md:text-xs rounded-full font-medium px-2.5">
              {nivel.emoji} {nivel.label}
            </Badge>
          )}
          {isComercial && monthlyStats && (
            <Badge
              variant="secondary"
              className={`border-0 text-[10px] md:text-xs rounded-full font-medium px-2.5 ${
                monthlyStats.bonusAtivo
                  ? 'bg-emerald-50 text-emerald-700'
                  : 'bg-red-50 text-red-700'
              }`}
            >
              {monthlyStats.bonusAtivo ? '✓ Bônus Ativo' : '✗ Bônus Bloqueado'}
            </Badge>
          )}
          {hasStars && (
            <div className="flex items-center gap-1 ml-0.5">
              {(starsData?.crystal_stars || 0) > 0 && (
                <span className="text-[10px] md:text-xs font-medium text-purple-600 bg-purple-50 rounded-full px-2 py-0.5">💎 {starsData!.crystal_stars}</span>
              )}
              {(starsData?.gold_stars || 0) > 0 && (
                <span className="text-[10px] md:text-xs font-medium text-yellow-700 bg-yellow-50 rounded-full px-2 py-0.5">🥇 {starsData!.gold_stars}</span>
              )}
              {(starsData?.silver_stars || 0) > 0 && (
                <span className="text-[10px] md:text-xs font-medium text-gray-600 bg-gray-100 rounded-full px-2 py-0.5">🥈 {starsData!.silver_stars}</span>
              )}
              {(starsData?.bronze_stars || 0) > 0 && (
                <span className="text-[10px] md:text-xs font-medium text-amber-700 bg-amber-50 rounded-full px-2 py-0.5">🥉 {starsData!.bronze_stars}</span>
              )}
            </div>
          )}
        </div>

        {/* Stats strip */}
        <div className="mt-4 pt-4 border-t border-gray-100">
          <div className="grid grid-cols-3 gap-3 md:gap-6">
            <div className="text-center">
              <p className="text-xl md:text-2xl font-bold text-[#3B5BDB]">{profile.level}</p>
              <p className="text-[10px] md:text-xs text-gray-400 uppercase tracking-wider font-medium mt-0.5">Nível</p>
            </div>
            <div className="text-center">
              <p className="text-xl md:text-2xl font-bold text-gray-900">{(profile.xp_total - (profile.xp_spent || 0)).toLocaleString('pt-BR')}</p>
              <p className="text-[10px] md:text-xs text-gray-400 uppercase tracking-wider font-medium mt-0.5">XP</p>
            </div>
            <div className="text-center">
              <p className="text-xl md:text-2xl font-bold text-gray-900">{profile.score_current}</p>
              <p className="text-[10px] md:text-xs text-gray-400 uppercase tracking-wider font-medium mt-0.5">Score</p>
            </div>
          </div>
          
          {/* XP Progress bar */}
          <div className="mt-4 space-y-1.5">
            <div className="flex items-center justify-between text-[10px] md:text-xs">
              <span className="text-gray-500 font-medium flex items-center gap-1">
                <Zap className="h-3 w-3 text-[#FF6A00]" />
                Progresso para Nível {profile.level + 1}
              </span>
              <span className="text-gray-400">{xpInLevel.toLocaleString('pt-BR')} / {xpNeeded.toLocaleString('pt-BR')} XP</span>
            </div>
            <Progress 
              value={xpPercent} 
              className="h-2 bg-gray-100" 
            />
          </div>
        </div>
      </div>
    </motion.div>
  );
}
