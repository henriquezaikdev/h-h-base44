import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { format, startOfMonth, endOfMonth } from "date-fns";
import { Card, CardContent } from "@/components/ui/card";
import { UserCheck, UserX, AlertTriangle } from "lucide-react";
import { useNavigate } from "react-router-dom";

export function RHHojeCard() {
  const navigate = useNavigate();
  const today = format(new Date(), "yyyy-MM-dd");

  const { data: totalColabs = 0 } = useQuery({
    queryKey: ["rh-card-total"],
    queryFn: async () => {
      const { count } = await supabase.from("genyo_colaboradores" as any).select("*", { count: "exact", head: true }).eq("status", "ativo");
      return count || 0;
    },
  });

  const { data: pontosHoje = [] } = useQuery({
    queryKey: ["rh-card-pontos", today],
    queryFn: async () => {
      const { data } = await supabase.from("genyo_pontos" as any).select("status, colaborador_id").eq("data", today);
      return (data as any[]) || [];
    },
  });

  // Count recurring late arrivals (3+ in current month)
  const mesInicio = format(startOfMonth(new Date()), "yyyy-MM-dd");
  const mesFim = format(endOfMonth(new Date()), "yyyy-MM-dd");

  const { data: atrasosRecorrentes = 0 } = useQuery({
    queryKey: ["rh-card-atrasos-recorrentes", mesInicio],
    queryFn: async () => {
      const { data } = await supabase.from("genyo_pontos" as any)
        .select("colaborador_id")
        .eq("status", "atrasado")
        .gte("data", mesInicio)
        .lte("data", mesFim);
      if (!data) return 0;
      const counts = new Map<number, number>();
      (data as any[]).forEach((p: any) => counts.set(p.colaborador_id, (counts.get(p.colaborador_id) || 0) + 1));
      return Array.from(counts.values()).filter(c => c >= 3).length;
    },
  });

  const presentes = pontosHoje.filter((p: any) => p.status === "presente").length;
  const ausentes = totalColabs - presentes;

  return (
    <Card className="cursor-pointer hover:border-primary/30 transition-colors" onClick={() => navigate("/rh")}>
      <CardContent className="p-3 space-y-2">
        <p className="text-[11px] uppercase tracking-wide text-muted-foreground font-semibold">RH Hoje</p>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5">
            <UserCheck className="h-4 w-4 text-[#16A34A]" />
            <span className="text-[16px] font-semibold">{presentes}/{totalColabs}</span>
            <span className="text-[11px] text-muted-foreground">presentes</span>
          </div>
          <div className="flex items-center gap-1.5">
            <UserX className="h-4 w-4 text-[#DC2626]" />
            <span className="text-[16px] font-semibold">{ausentes}</span>
            <span className="text-[11px] text-muted-foreground">ausências</span>
          </div>
        </div>
        {atrasosRecorrentes > 0 && (
          <div className="flex items-center gap-1.5 text-[11px] text-[#CA8A04]">
            <AlertTriangle className="h-3 w-3" />
            {atrasosRecorrentes} colaborador(es) com 3+ atrasos no mês
          </div>
        )}
        <p className="text-[11px] text-primary cursor-pointer hover:underline">Ver detalhes →</p>
      </CardContent>
    </Card>
  );
}
