import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import {
  CheckCircle2, XCircle, Clock, AlertTriangle, Loader2, Timer, CalendarClock, Eye,
} from "lucide-react";
import { toast } from "sonner";

type CronJob = {
  jobid: number;
  jobname: string;
  schedule: string;
  active: boolean;
};

type AutoSyncLog = {
  id: string;
  started_at: string;
  finished_at: string | null;
  status: string;
  records_fetched: number;
  records_created: number;
  records_skipped: number;
  error_message: string | null;
  details: any;
  trigger: string;
};

export function AutomacaoPanel() {
  const queryClient = useQueryClient();
  const [togglingJob, setTogglingJob] = useState<string | null>(null);
  const [showFailDetails, setShowFailDetails] = useState(false);

  // Fetch cron job statuses
  const { data: cronJobs = [], isLoading: loadingJobs } = useQuery({
    queryKey: ["cron-jobs-vendas"],
    queryFn: async () => {
      const { data, error } = await supabase.rpc("get_sync_vendas_cron_status" as any);
      if (error) {
        console.error("Error fetching cron jobs:", error);
        return [];
      }
      return (data as any[]) || [];
    },
    refetchInterval: 30000,
  });

  // Fetch last 10 automatic executions
  const { data: autoLogs = [] } = useQuery({
    queryKey: ["auto-sync-logs"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("hh_sync_logs")
        .select("*")
        .eq("module", "vendas")
        .eq("trigger", "cron")
        .order("started_at", { ascending: false })
        .limit(10);
      if (error) throw error;
      return data as AutoSyncLog[];
    },
    refetchInterval: 15000,
  });

  // Detect consecutive failures
  const consecutiveFailures = (() => {
    let count = 0;
    for (const log of autoLogs) {
      if (log.status === "error") count++;
      else break;
    }
    return count;
  })();

  const incrementalJob = cronJobs.find((j: any) => j.jobname === "sync-vendas-incremental");
  const dailyJob = cronJobs.find((j: any) => j.jobname === "sync-vendas-diario-completo");

  const toggleJob = async (jobname: string, currentActive: boolean) => {
    setTogglingJob(jobname);
    try {
      const { error } = await supabase.rpc("toggle_sync_vendas_cron" as any, {
        p_jobname: jobname,
        p_active: !currentActive,
      });
      if (error) throw error;
      toast.success(`Job "${jobname}" ${!currentActive ? "ativado" : "desativado"}`);
      queryClient.invalidateQueries({ queryKey: ["cron-jobs-vendas"] });
    } catch (err: any) {
      toast.error(`Erro ao alterar job: ${err.message}`);
    } finally {
      setTogglingJob(null);
    }
  };

  const getNextExecution = (schedule: string): string => {
    // Simple estimation based on cron pattern
    const now = new Date();
    if (schedule === "*/30 * * * *") {
      const next = new Date(now);
      const mins = next.getMinutes();
      const nextSlot = mins < 30 ? 30 : 60;
      next.setMinutes(nextSlot % 60, 0, 0);
      if (nextSlot === 60) next.setHours(next.getHours() + 1);
      return format(next, "HH:mm", { locale: ptBR });
    }
    if (schedule.startsWith("0 9")) {
      // Daily at 09:00 UTC = 06:00 BRT
      return "06:00 (BRT)";
    }
    return schedule;
  };

  const statusBadge = (status: string) => {
    if (status === "success") return <Badge className="bg-green-600 text-white text-[10px]"><CheckCircle2 className="h-3 w-3 mr-1" />OK</Badge>;
    if (status === "error") return <Badge variant="destructive" className="text-[10px]"><XCircle className="h-3 w-3 mr-1" />Erro</Badge>;
    return <Badge className="bg-yellow-500 text-black text-[10px]"><Clock className="h-3 w-3 mr-1" />Rodando</Badge>;
  };

  return (
    <div className="space-y-4">
      {/* Failure alert */}
      {consecutiveFailures >= 3 && (
        <Card className="border-2 border-destructive/50">
          <CardContent className="pt-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-destructive" />
                <div>
                  <p className="text-sm font-semibold text-destructive">Sync com falhas</p>
                  <p className="text-xs text-muted-foreground">
                    {consecutiveFailures} execuções automáticas consecutivas falharam.
                  </p>
                </div>
                <Badge variant="destructive" className="ml-2">Sync com falhas</Badge>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowFailDetails(!showFailDetails)}
                className="border-destructive text-destructive hover:bg-destructive/10"
              >
                <Eye className="h-3 w-3 mr-1" /> Ver detalhes
              </Button>
            </div>
            {showFailDetails && (
              <div className="mt-3 space-y-1 max-h-40 overflow-y-auto">
                {autoLogs.filter(l => l.status === "error").slice(0, 5).map((log) => (
                  <div key={log.id} className="text-xs bg-destructive/5 rounded p-2 border border-destructive/20">
                    <span className="text-muted-foreground">
                      {format(new Date(log.started_at), "dd/MM HH:mm", { locale: ptBR })}:
                    </span>{" "}
                    <span className="text-destructive">{log.error_message || "Erro desconhecido"}</span>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Job toggles */}
      <div className="grid md:grid-cols-2 gap-4">
        <JobCard
          title="Sync Incremental"
          description="A cada 30 minutos — busca pedidos das últimas 2 horas"
          icon={<Timer className="h-4 w-4 text-primary" />}
          job={incrementalJob}
          loading={loadingJobs || togglingJob === "sync-vendas-incremental"}
          onToggle={() => incrementalJob && toggleJob("sync-vendas-incremental", incrementalJob.active)}
          nextExecution={incrementalJob?.schedule ? getNextExecution(incrementalJob.schedule) : null}
          lastLog={autoLogs.find(l => l.details?.mode === "incremental")}
        />
        <JobCard
          title="Sync Diário Completo"
          description="Todo dia às 06:00 — busca todos os pedidos do dia anterior"
          icon={<CalendarClock className="h-4 w-4 text-primary" />}
          job={dailyJob}
          loading={loadingJobs || togglingJob === "sync-vendas-diario-completo"}
          onToggle={() => dailyJob && toggleJob("sync-vendas-diario-completo", dailyJob.active)}
          nextExecution={dailyJob?.schedule ? getNextExecution(dailyJob.schedule) : null}
          lastLog={autoLogs.find(l => l.details?.mode === "daily")}
        />
      </div>

      {/* Auto execution history */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm">Últimas 10 Execuções Automáticas</CardTitle>
        </CardHeader>
        <CardContent>
          {autoLogs.length === 0 ? (
            <p className="text-xs text-muted-foreground py-4 text-center">Nenhuma execução automática registrada.</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-xs">Data</TableHead>
                  <TableHead className="text-xs">Modo</TableHead>
                  <TableHead className="text-xs">Status</TableHead>
                  <TableHead className="text-xs">Buscados</TableHead>
                  <TableHead className="text-xs">Criados</TableHead>
                  <TableHead className="text-xs">Ignorados</TableHead>
                  <TableHead className="text-xs">Duração</TableHead>
                  <TableHead className="text-xs">Erro</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {autoLogs.map(log => {
                  const duration = log.finished_at && log.started_at
                    ? Math.round((new Date(log.finished_at).getTime() - new Date(log.started_at).getTime()) / 1000)
                    : null;
                  return (
                    <TableRow key={log.id}>
                      <TableCell className="text-xs">
                        {format(new Date(log.started_at), "dd/MM HH:mm", { locale: ptBR })}
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className="text-[10px]">
                          {log.details?.mode || "?"}
                        </Badge>
                      </TableCell>
                      <TableCell>{statusBadge(log.status)}</TableCell>
                      <TableCell className="text-xs">{log.records_fetched}</TableCell>
                      <TableCell className="text-xs">{log.records_created}</TableCell>
                      <TableCell className="text-xs">{log.records_skipped}</TableCell>
                      <TableCell className="text-xs text-muted-foreground">
                        {duration !== null ? `${duration}s` : "-"}
                      </TableCell>
                      <TableCell className="text-xs text-destructive max-w-48 truncate">
                        {log.error_message || "-"}
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function JobCard({
  title, description, icon, job, loading, onToggle, nextExecution, lastLog,
}: {
  title: string;
  description: string;
  icon: React.ReactNode;
  job: any;
  loading: boolean;
  onToggle: () => void;
  nextExecution: string | null;
  lastLog?: AutoSyncLog;
}) {
  const isActive = job?.active ?? false;

  return (
    <Card className={`border ${isActive ? "border-primary/30" : "border-muted"}`}>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm flex items-center gap-2">
            {icon} {title}
          </CardTitle>
          {loading ? (
            <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
          ) : job ? (
            <Switch
              checked={isActive}
              onCheckedChange={onToggle}
              className={isActive ? "data-[state=checked]:bg-primary" : ""}
            />
          ) : (
            <Badge variant="outline" className="text-[10px] text-muted-foreground">Não configurado</Badge>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-2">
        <p className="text-xs text-muted-foreground">{description}</p>

        {job && (
          <div className="space-y-1 text-xs">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Status:</span>
              <Badge variant={isActive ? "default" : "secondary"} className="text-[10px]">
                {isActive ? "Ativo" : "Inativo"}
              </Badge>
            </div>
            {nextExecution && isActive && (
              <div className="flex justify-between">
                <span className="text-muted-foreground">Próxima execução:</span>
                <span className="font-mono">{nextExecution}</span>
              </div>
            )}
            {lastLog && (
              <div className="flex justify-between">
                <span className="text-muted-foreground">Última execução:</span>
                <span className="flex items-center gap-1">
                  {lastLog.status === "success" ? (
                    <CheckCircle2 className="h-3 w-3 text-green-600" />
                  ) : (
                    <XCircle className="h-3 w-3 text-destructive" />
                  )}
                  {format(new Date(lastLog.started_at), "dd/MM HH:mm", { locale: ptBR })}
                </span>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
