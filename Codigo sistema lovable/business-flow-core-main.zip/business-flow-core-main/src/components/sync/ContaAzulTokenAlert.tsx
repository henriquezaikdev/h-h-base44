import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { AlertTriangle, ExternalLink } from "lucide-react";

/**
 * Detects invalid_grant errors in recent sync logs and shows a prominent alert
 * with a direct reconnect button. Works on any page.
 */
export function ContaAzulTokenAlert() {
  const { data: hasTokenError } = useQuery({
    queryKey: ["conta-azul-token-status"],
    queryFn: async () => {
      const { data } = await supabase
        .from("hh_sync_logs")
        .select("error_message")
        .in("module", ["vendas", "produtos"])
        .eq("status", "error")
        .order("started_at", { ascending: false })
        .limit(3);

      if (!data?.length) return false;
      return data.some(
        (log) => log.error_message?.includes("invalid_grant")
      );
    },
    refetchInterval: 60_000,
    staleTime: 30_000,
  });

  if (!hasTokenError) return null;

  return (
    <div className="flex items-center justify-between gap-3 rounded-lg border border-red-500/40 bg-red-50 dark:bg-red-950/30 px-4 py-3">
      <div className="flex items-center gap-3 min-w-0">
        <AlertTriangle className="h-5 w-5 shrink-0 text-red-600 dark:text-red-400" />
        <div className="min-w-0">
          <p className="text-sm font-semibold text-red-700 dark:text-red-300">
            Token do Conta Azul expirado
          </p>
          <p className="text-xs text-red-600/80 dark:text-red-400/80 truncate">
            O sync automático está parado. Reconecte para retomar.
          </p>
        </div>
      </div>
      <a
        href="https://auth.contaazul.com/login?response_type=code&client_id=2dndpag0bu77c5s12ntav0c5sp&redirect_uri=https://tzzbllhvpmpijbdidmtx.supabase.co/functions/v1/conta-azul-callback"
        className="inline-flex shrink-0 items-center gap-1.5 rounded-md px-3 py-1.5 text-sm font-medium text-white shadow-sm transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#3B5BDB]"
        style={{ backgroundColor: '#3B5BDB' }}
        onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = '#2f4fc4')}
        onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = '#3B5BDB')}
      >
        <ExternalLink className="h-3.5 w-3.5" />
        Reconectar Conta Azul
      </a>
    </div>
  );
}
