import { Component, ErrorInfo, ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { AlertTriangle, RefreshCw, Home, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { safeRemoveDrafts } from '@/lib/safeStorage';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null,
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo);
  }

  // Reseta o erro sem recarregar a página
  private handleRetry = () => {
    this.setState({ hasError: false, error: null });
  };

  // Recarrega SOMENTE quando usuário clica no botão
  private handleReload = () => {
    window.location.reload();
  };

  private handleClearDrafts = () => {
    safeRemoveDrafts();
    window.location.reload();
  };


  public render() {
    if (this.state.hasError) {
      return (
        <div className="flex flex-col items-center justify-center min-h-[400px] p-8">
          <div className="w-16 h-16 bg-destructive/10 rounded-full flex items-center justify-center mb-6">
            <AlertTriangle className="h-8 w-8 text-destructive" />
          </div>
          <h2 className="text-xl font-semibold text-foreground mb-2">
            Ocorreu um erro inesperado
          </h2>
          <p className="text-muted-foreground text-center mb-6 max-w-md">
            Algo deu errado. Tente novamente ou recarregue a página se o problema persistir.
          </p>
          <div className="flex gap-3 flex-wrap justify-center">
            <Button onClick={this.handleRetry} className="gap-2">
              <RefreshCw size={16} />
              Tentar novamente
            </Button>
            <Button onClick={this.handleReload} variant="outline" className="gap-2">
              <RefreshCw size={16} />
              Recarregar página
            </Button>
            <Button onClick={this.handleClearDrafts} variant="outline" className="gap-2">
              <Trash2 size={16} />
              Limpar rascunhos
            </Button>
            <Button asChild variant="ghost" className="gap-2">
              <Link to="/">
                <Home size={16} />
                Início
              </Link>
            </Button>
          </div>
          {import.meta.env.DEV && this.state.error && (
            <pre className="mt-6 p-4 bg-muted rounded-lg text-xs text-muted-foreground max-w-2xl overflow-auto">
              {this.state.error.message}
              {'\n'}
              {this.state.error.stack}
            </pre>
          )}
        </div>
      );
    }

    return this.props.children;
  }
}
