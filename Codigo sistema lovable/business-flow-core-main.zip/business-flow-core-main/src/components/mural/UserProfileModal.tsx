import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Dialog, DialogContent, DialogTitle } from '@/components/ui/dialog';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Loader2, Star, Zap, Award, ExternalLink, Trophy, Heart, MessageSquare, Clock, Briefcase } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { format, formatDistanceToNow } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface UserProfileModalProps {
  userId: string | null;
  open: boolean;
  onClose: () => void;
}

interface UserProfile {
  id: string;
  name: string;
  display_name: string | null;
  avatar_url: string | null;
  cover_url: string | null;
  role: string;
  department: string | null;
  nivel_atual: string;
  level: number;
  xp_total: number;
  score_current: number;
  bio: string | null;
  sobre_mim: string | null;
}

interface RecentPost {
  id: string;
  texto: string;
  imagem_url: string | null;
  created_at: string;
  likes_count: number;
  comments_count: number;
}

interface RecentRecognition {
  id: string;
  tipo: string;
  motivo: string | null;
  mensagem: string | null;
  de_nome: string;
  created_at: string;
}

const ROLE_LABELS: Record<string, string> = {
  vendedor: 'Vendedor',
  compras: 'Compras',
  financeiro: 'Financeiro',
  logistica: 'Logística',
  administrativo: 'Administrativo',
  master: 'Master',
  gestor: 'Gestor',
  admin: 'Administrador',
  owner: 'Proprietário',
};

const NIVEL_CONFIG: Record<string, { emoji: string; label: string }> = {
  OVO: { emoji: '🥚', label: 'Ovo' },
  PENA: { emoji: '🪶', label: 'Pena' },
  AGUIA: { emoji: '🦅', label: 'Águia' },
};

function getXpForLevel(level: number): { current: number; next: number } {
  const t = [0, 100, 300, 600, 1000, 1500, 2200, 3000, 4000, 5500, 7500, 10000, 13000, 17000, 22000, 28000, 35000, 45000, 60000, 80000];
  const cur = t[Math.min(level - 1, t.length - 1)] || 0;
  const nxt = t[Math.min(level, t.length - 1)] || cur + 5000;
  return { current: cur, next: nxt };
}

export function UserProfileModal({ userId, open, onClose }: UserProfileModalProps) {
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [recentPosts, setRecentPosts] = useState<RecentPost[]>([]);
  const [recognitions, setRecognitions] = useState<RecentRecognition[]>([]);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    if (!userId || !open) return;
    setLoading(true);
    setProfile(null);
    setRecentPosts([]);
    setRecognitions([]);

    const fetchAll = async () => {
      // Profile
      const { data: profileData } = await supabase
        .from('sellers')
        .select('id, name, display_name, avatar_url, cover_url, role, department, nivel_atual, level, xp_total, score_current, bio, sobre_mim')
        .eq('id', userId)
        .single();
      setProfile(profileData as UserProfile | null);

      // Recent posts
      const { data: postsData } = await supabase
        .from('hh_mural_posts')
        .select('id, texto, imagem_url, created_at')
        .eq('autor_id', userId)
        .order('created_at', { ascending: false })
        .limit(3);

      if (postsData && postsData.length > 0) {
        const postIds = postsData.map(p => p.id);
        const [likesRes, commentsRes] = await Promise.all([
          supabase.from('hh_mural_reacoes').select('post_id').in('post_id', postIds),
          supabase.from('hh_mural_comentarios').select('post_id').in('post_id', postIds),
        ]);
        const likesMap: Record<string, number> = {};
        const commentsMap: Record<string, number> = {};
        (likesRes.data || []).forEach((r: any) => { likesMap[r.post_id] = (likesMap[r.post_id] || 0) + 1; });
        (commentsRes.data || []).forEach((c: any) => { commentsMap[c.post_id] = (commentsMap[c.post_id] || 0) + 1; });

        setRecentPosts(postsData.map(p => ({
          ...p,
          likes_count: likesMap[p.id] || 0,
          comments_count: commentsMap[p.id] || 0,
        })));
      }

      // Recent recognitions received
      const { data: recsData } = await supabase
        .from('reconhecimentos')
        .select('id, tipo, categoria, comentario, criado_por_user_id, created_at')
        .eq('vendedor_recebe_id', userId)
        .order('created_at', { ascending: false })
        .limit(5);

      if (recsData && recsData.length > 0) {
        const deIds = [...new Set(recsData.map((r) => r.criado_por_user_id))];
        const { data: deSellers } = await supabase.from('sellers').select('id, name').in('id', deIds);
        const deMap = new Map((deSellers || []).map(s => [s.id, s.name]));

        setRecognitions(recsData.map((r) => ({
          id: r.id,
          tipo: r.tipo,
          motivo: r.categoria,
          mensagem: r.comentario,
          de_nome: deMap.get(r.criado_por_user_id) || 'Alguém',
          created_at: r.created_at,
        })));
      }

      setLoading(false);
    };

    fetchAll();
  }, [userId, open]);

  const getInitials = (name: string) =>
    name.split(' ').map(n => n[0]).slice(0, 2).join('').toUpperCase();

  const nivel = profile ? (NIVEL_CONFIG[profile.nivel_atual] || NIVEL_CONFIG.OVO) : NIVEL_CONFIG.OVO;
  const xpInfo = profile ? getXpForLevel(profile.level) : { current: 0, next: 100 };
  const xpInLevel = profile ? Math.max(0, profile.xp_total - xpInfo.current) : 0;
  const xpNeeded = Math.max(1, xpInfo.next - xpInfo.current);
  const xpPercent = Math.min(100, Math.round((xpInLevel / xpNeeded) * 100));

  const getRecoIcon = (tipo: string) => {
    if (tipo === 'CURTIDA') return '👏';
    if (tipo === 'HCOIN') return '🪙';
    if (tipo === 'ESTRELA') return '⭐';
    return '🎁';
  };

  return (
    <Dialog open={open} onOpenChange={() => onClose()}>
      <DialogContent className="max-w-md p-0 overflow-hidden rounded-2xl border-gray-200">
        <DialogTitle className="sr-only">Perfil do usuário</DialogTitle>
        {loading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="h-8 w-8 animate-spin text-[#3B5BDB]" />
          </div>
        ) : profile ? (
          <ScrollArea className="max-h-[85vh]">
            <div>
              {/* Cover */}
              <div className="h-28 bg-gradient-to-r from-[#3B5BDB] via-[#5B7EF5] to-[#7B9CFF] relative">
                {profile.cover_url && (
                  <img src={profile.cover_url} alt="" className="w-full h-full object-cover absolute inset-0" />
                )}
                <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImciIHdpZHRoPSI2MCIgaGVpZ2h0PSI2MCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PGNpcmNsZSBjeD0iMzAiIGN5PSIzMCIgcj0iMSIgZmlsbD0icmdiYSgyNTUsMjU1LDI1NSwwLjA4KSIvPjwvcGF0dGVybj48L2RlZnM+PHJlY3QgZmlsbD0idXJsKCNnKSIgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIvPjwvc3ZnPg==')] opacity-50" />
              </div>

              {/* Avatar overlapping cover */}
              <div className="px-5 -mt-12 relative z-10">
                <Avatar className="h-24 w-24 border-4 border-white shadow-xl ring-2 ring-gray-100">
                  <AvatarImage src={profile.avatar_url || undefined} />
                  <AvatarFallback className="bg-[#3B5BDB] text-white text-xl font-bold">
                    {getInitials(profile.name)}
                  </AvatarFallback>
                </Avatar>
              </div>

              {/* Info section */}
              <div className="px-5 pb-5 pt-3 space-y-4">
                {/* Name, role, department */}
                <div>
                  <h3 className="text-xl font-bold text-gray-900 tracking-tight">
                    {profile.display_name || profile.name}
                  </h3>
                  <div className="flex items-center gap-2 mt-1.5 flex-wrap">
                    <Badge variant="secondary" className="bg-[#3B5BDB]/8 text-[#3B5BDB] border-0 text-[10px] rounded-full font-medium px-2.5">
                      <Briefcase className="h-2.5 w-2.5 mr-1" />
                      {ROLE_LABELS[profile.role] || profile.role}
                    </Badge>
                    {profile.department && (
                      <Badge variant="outline" className="text-[10px] rounded-full border-gray-200 text-gray-500 px-2.5">
                        {profile.department}
                      </Badge>
                    )}
                    <Badge variant="secondary" className="bg-gray-50 text-gray-600 border-0 text-[10px] rounded-full font-medium px-2.5">
                      {nivel.emoji} {nivel.label}
                    </Badge>
                  </div>
                </div>

                {/* Bio */}
                {(profile.bio || profile.sobre_mim) && (
                  <p className="text-xs text-gray-500 leading-relaxed line-clamp-3">
                    {profile.sobre_mim || profile.bio}
                  </p>
                )}

                {/* Stats grid */}
                <div className="grid grid-cols-3 gap-2.5">
                  <div className="bg-gray-50 rounded-xl p-3 text-center">
                    <div className="flex items-center justify-center gap-1 text-[#3B5BDB]">
                      <Trophy className="h-4 w-4" />
                      <span className="text-lg font-bold">{profile.level}</span>
                    </div>
                    <p className="text-[10px] text-gray-400 uppercase tracking-wider mt-0.5 font-medium">Nível</p>
                  </div>
                  <div className="bg-gray-50 rounded-xl p-3 text-center">
                    <div className="flex items-center justify-center gap-1 text-gray-900">
                      <Zap className="h-4 w-4 text-[#FF6A00]" />
                      <span className="text-lg font-bold">{profile.xp_total.toLocaleString('pt-BR')}</span>
                    </div>
                    <p className="text-[10px] text-gray-400 uppercase tracking-wider mt-0.5 font-medium">XP</p>
                  </div>
                  <div className="bg-gray-50 rounded-xl p-3 text-center">
                    <div className="flex items-center justify-center gap-1 text-gray-900">
                      <Award className="h-4 w-4 text-amber-500" />
                      <span className="text-lg font-bold">{profile.score_current}</span>
                    </div>
                    <p className="text-[10px] text-gray-400 uppercase tracking-wider mt-0.5 font-medium">Score</p>
                  </div>
                </div>

                {/* XP Progress bar */}
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between text-[10px]">
                    <span className="text-gray-500 font-medium flex items-center gap-1">
                      <Zap className="h-3 w-3 text-[#FF6A00]" />
                      Progresso para Nível {profile.level + 1}
                    </span>
                    <span className="text-gray-400">{xpPercent}%</span>
                  </div>
                  <Progress value={xpPercent} className="h-1.5 bg-gray-100" />
                </div>

                {/* Recognitions */}
                {recognitions.length > 0 && (
                  <div className="space-y-2">
                    <h4 className="text-xs font-semibold text-gray-700 flex items-center gap-1.5">
                      <Heart className="h-3.5 w-3.5 text-pink-500" />
                      Reconhecimentos Recentes
                    </h4>
                    <div className="space-y-1.5">
                      {recognitions.slice(0, 3).map(rec => (
                        <div key={rec.id} className="flex items-start gap-2 bg-gray-50 rounded-lg px-3 py-2">
                          <span className="text-sm shrink-0">{getRecoIcon(rec.tipo)}</span>
                          <div className="min-w-0 flex-1">
                            <p className="text-[11px] text-gray-700">
                              <span className="font-semibold">{rec.de_nome}</span>
                              {rec.mensagem && <span className="text-gray-500"> — "{rec.mensagem}"</span>}
                            </p>
                            <p className="text-[10px] text-gray-400 mt-0.5">
                              {formatDistanceToNow(new Date(rec.created_at), { addSuffix: true, locale: ptBR })}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Recent posts */}
                {recentPosts.length > 0 && (
                  <div className="space-y-2">
                    <h4 className="text-xs font-semibold text-gray-700 flex items-center gap-1.5">
                      <MessageSquare className="h-3.5 w-3.5 text-[#3B5BDB]" />
                      Posts Recentes no Mural
                    </h4>
                    <div className="space-y-1.5">
                      {recentPosts.map(post => (
                        <div key={post.id} className="bg-gray-50 rounded-lg px-3 py-2">
                          <p className="text-[11px] text-gray-700 line-clamp-2">{post.texto}</p>
                          {post.imagem_url && (
                            <img src={post.imagem_url} alt="" className="mt-1.5 h-16 w-full object-cover rounded-md" />
                          )}
                          <div className="flex items-center gap-3 mt-1.5">
                            <span className="text-[10px] text-gray-400 flex items-center gap-0.5">
                              <Heart className="h-2.5 w-2.5" /> {post.likes_count}
                            </span>
                            <span className="text-[10px] text-gray-400 flex items-center gap-0.5">
                              <MessageSquare className="h-2.5 w-2.5" /> {post.comments_count}
                            </span>
                            <span className="text-[10px] text-gray-400 ml-auto flex items-center gap-0.5">
                              <Clock className="h-2.5 w-2.5" />
                              {formatDistanceToNow(new Date(post.created_at), { addSuffix: true, locale: ptBR })}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Full profile link */}
                <Button
                  variant="outline"
                  size="sm"
                  className="w-full text-xs gap-1.5 rounded-xl border-gray-200 hover:bg-gray-50"
                  onClick={() => {
                    onClose();
                    navigate(`/perfil/${profile.id}`);
                  }}
                >
                  <ExternalLink className="h-3.5 w-3.5" />
                  Ver perfil completo
                </Button>
              </div>
            </div>
          </ScrollArea>
        ) : (
          <div className="py-16 text-center text-gray-400 text-sm">
            Usuário não encontrado.
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
