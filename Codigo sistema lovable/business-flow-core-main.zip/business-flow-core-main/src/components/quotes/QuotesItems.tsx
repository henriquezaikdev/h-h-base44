import { useState, useEffect, useMemo } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { 
  Loader2, Package, TrendingDown, DollarSign, 
  Building2, Search, ArrowUpDown, AlertCircle, Plus, Save, X,
  AlertTriangle, ShoppingCart
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { toast } from 'sonner';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';

interface QuotesItemsProps {
  sellerId?: string | null;
  startDate?: string;
  endDate?: string;
}

interface ItemSummary {
  product_name: string;
  total_quantity: number;
  total_value: number;
  occurrences: number;
  avg_price: number;
  clients: string[];
  has_comparison: boolean;
  competitor_prices: { price: number; source: string; where: string }[];
  quote_item_ids: string[];
  gap_percentual: number | null;
  avg_competitor_price: number | null;
}

export function QuotesItems({ sellerId, startDate, endDate }: QuotesItemsProps) {
  const { seller } = useAuth();
  const [loading, setLoading] = useState(true);
  const [items, setItems] = useState<any[]>([]);
  const [comparisons, setComparisons] = useState<any[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState<'value' | 'quantity' | 'occurrences'>('value');

  // Modal de comparativo
  const [showComparisonModal, setShowComparisonModal] = useState(false);
  const [selectedItem, setSelectedItem] = useState<ItemSummary | null>(null);
  const [compPrice, setCompPrice] = useState('');
  const [compWhere, setCompWhere] = useState('');
  const [compSource, setCompSource] = useState<'cliente' | 'pesquisa' | 'vendedor'>('cliente');
  const [compNotes, setCompNotes] = useState('');
  const [savingComparison, setSavingComparison] = useState(false);

  useEffect(() => {
    fetchData();
  }, [sellerId, startDate, endDate]);

  const fetchData = async () => {
    setLoading(true);
    try {
      let query = supabase
        .from('quote_items')
        .select(`
          *,
          quotes!inner(id, client_id, seller_id, quote_date, status, clients(company_name))
        `)
        .eq('quotes.status', 'perdido');

      if (sellerId) {
        query = query.eq('quotes.seller_id', sellerId);
      }
      if (startDate) {
        query = query.gte('quotes.quote_date', startDate);
      }
      if (endDate) {
        query = query.lte('quotes.quote_date', endDate);
      }

      const { data: itemsData, error: itemsError } = await query;
      if (itemsError) throw itemsError;
      setItems(itemsData || []);

      const itemIds = (itemsData || []).map(i => i.id);
      if (itemIds.length > 0) {
        const { data: comparisonsData } = await supabase
          .from('quote_item_comparisons')
          .select('*')
          .in('quote_item_id', itemIds);
        
        setComparisons(comparisonsData || []);
      }
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  // Aggregate items by product name
  const itemsSummary = useMemo(() => {
    const summary: Record<string, ItemSummary> = {};

    items.forEach(item => {
      const key = item.product_name.toLowerCase().trim();
      if (!summary[key]) {
        summary[key] = {
          product_name: item.product_name,
          total_quantity: 0,
          total_value: 0,
          occurrences: 0,
          avg_price: 0,
          clients: [],
          has_comparison: false,
          competitor_prices: [],
          quote_item_ids: [],
          gap_percentual: null,
          avg_competitor_price: null,
        };
      }

      if (item.id && !summary[key].quote_item_ids.includes(item.id)) {
        summary[key].quote_item_ids.push(item.id);
      }

      summary[key].total_quantity += item.quantity || 0;
      summary[key].total_value += item.subtotal || 0;
      summary[key].occurrences++;
      
      const clientName = item.quotes?.clients?.company_name;
      if (clientName && !summary[key].clients.includes(clientName)) {
        summary[key].clients.push(clientName);
      }

      const itemComparisons = comparisons.filter(c => c.quote_item_id === item.id);
      if (itemComparisons.length > 0) {
        summary[key].has_comparison = true;
        itemComparisons.forEach(comp => {
          summary[key].competitor_prices.push({
            price: comp.preco_concorrente,
            source: comp.fonte_informacao,
            where: comp.onde_comprou || 'N/A',
          });
        });
      }
    });

    // Calculate average prices and gap
    Object.values(summary).forEach(item => {
      if (item.total_quantity > 0) {
        item.avg_price = item.total_value / item.total_quantity;
      }
      if (item.competitor_prices.length > 0) {
        const totalCompetitor = item.competitor_prices.reduce((s, c) => s + c.price, 0);
        item.avg_competitor_price = totalCompetitor / item.competitor_prices.length;
        if (item.avg_competitor_price > 0) {
          item.gap_percentual = ((item.avg_price - item.avg_competitor_price) / item.avg_competitor_price) * 100;
        }
      }
    });

    return Object.values(summary);
  }, [items, comparisons]);

  // Filter and sort
  const filteredItems = useMemo(() => {
    let filtered = itemsSummary.filter(item =>
      item.product_name.toLowerCase().includes(searchTerm.toLowerCase())
    );

    filtered.sort((a, b) => {
      if (sortBy === 'value') return b.total_value - a.total_value;
      if (sortBy === 'quantity') return b.total_quantity - a.total_quantity;
      return b.occurrences - a.occurrences;
    });

    return filtered;
  }, [itemsSummary, searchTerm, sortBy]);

  // Renegotiation list: occurrences >= 2 AND gap > 0 (H&H more expensive)
  const renegotiationItems = useMemo(() => {
    return itemsSummary
      .filter(item => item.occurrences >= 2 && item.gap_percentual !== null && item.gap_percentual > 0)
      .sort((a, b) => b.total_value - a.total_value);
  }, [itemsSummary]);

  // KPIs
  const totalValue = useMemo(() => 
    itemsSummary.reduce((sum, i) => sum + i.total_value, 0), [itemsSummary]);
  const totalItems = itemsSummary.length;
  const itemsWithComparison = itemsSummary.filter(i => i.has_comparison).length;
  const topItem = filteredItems[0];

  const formatCurrency = (value: number) => 
    new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);

  const getGapBadge = (gap: number | null) => {
    if (gap === null) return <span className="text-muted-foreground text-xs">—</span>;
    const sign = gap > 0 ? '+' : '';
    if (gap > 15) return <Badge className="bg-red-500/10 text-red-600 border-red-500/20 text-xs">{sign}{gap.toFixed(1)}%</Badge>;
    if (gap > 5) return <Badge className="bg-yellow-500/10 text-yellow-700 border-yellow-500/20 text-xs">{sign}{gap.toFixed(1)}%</Badge>;
    if (gap > 0) return <Badge className="bg-foreground/5 text-muted-foreground border-foreground/10 text-xs">{sign}{gap.toFixed(1)}%</Badge>;
    return <Badge className="bg-green-500/10 text-green-600 border-green-500/20 text-xs">{sign}{gap.toFixed(1)}%</Badge>;
  };

  const getUrgencyBadge = (gap: number) => {
    if (gap > 15) return <Badge className="bg-red-500/10 text-red-600 border-red-500/20 text-xs">Alta</Badge>;
    if (gap > 5) return <Badge className="bg-yellow-500/10 text-yellow-700 border-yellow-500/20 text-xs">Média</Badge>;
    return <Badge className="bg-foreground/5 text-muted-foreground border-foreground/10 text-xs">Baixa</Badge>;
  };

  const handleOpenComparison = (item: ItemSummary) => {
    setSelectedItem(item);
    setCompPrice('');
    setCompWhere('');
    setCompSource('cliente');
    setCompNotes('');
    setShowComparisonModal(true);
  };

  const handleSaveComparison = async () => {
    if (!selectedItem || !compPrice) {
      toast.error('Informe o preço do concorrente');
      return;
    }

    const price = parseFloat(compPrice.replace(',', '.'));
    if (isNaN(price) || price < 0) {
      toast.error('Preço inválido');
      return;
    }

    if (!selectedItem.quote_item_ids.length) {
      toast.error('Nenhum item encontrado para adicionar comparativo');
      return;
    }

    setSavingComparison(true);
    try {
      const { error } = await supabase
        .from('quote_item_comparisons')
        .insert({
          quote_item_id: selectedItem.quote_item_ids[0],
          preco_concorrente: price,
          onde_comprou: compWhere.trim() || null,
          fonte_informacao: compSource,
          observacao_concorrencia: compNotes.trim() || null,
          created_by: seller?.id,
        });

      if (error) throw error;

      toast.success('Preço comparativo adicionado');
      setShowComparisonModal(false);
      fetchData();
    } catch (error) {
      console.error('Error saving comparison:', error);
      toast.error('Erro ao salvar comparativo');
    } finally {
      setSavingComparison(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center py-12">
        <Loader2 className="animate-spin h-8 w-8 text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="border-red-200 dark:border-red-800">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-red-100 dark:bg-red-900/50 rounded-lg">
                <TrendingDown className="h-5 w-5 text-red-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Valor Total</p>
                <p className="text-xl font-bold text-red-600">{formatCurrency(totalValue)}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-orange-100 dark:bg-orange-900/50 rounded-lg">
                <Package className="h-5 w-5 text-orange-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Produtos Únicos</p>
                <p className="text-xl font-bold">{totalItems}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-100 dark:bg-blue-900/50 rounded-lg">
                <Building2 className="h-5 w-5 text-blue-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Com Comparativo</p>
                <p className="text-xl font-bold">{itemsWithComparison}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-purple-100 dark:bg-purple-900/50 rounded-lg">
                <AlertCircle className="h-5 w-5 text-purple-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Mais Perdido</p>
                <p className="text-sm font-bold truncate max-w-[150px]" title={topItem?.product_name}>
                  {topItem?.product_name || 'N/A'}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-4">
        <div className="relative flex-1 min-w-[200px] max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Buscar produto..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-9"
          />
        </div>

        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground">Ordenar por:</span>
          <Button 
            variant={sortBy === 'value' ? 'default' : 'outline'} 
            size="sm"
            onClick={() => setSortBy('value')}
          >
            Valor
          </Button>
          <Button 
            variant={sortBy === 'quantity' ? 'default' : 'outline'} 
            size="sm"
            onClick={() => setSortBy('quantity')}
          >
            Quantidade
          </Button>
          <Button 
            variant={sortBy === 'occurrences' ? 'default' : 'outline'} 
            size="sm"
            onClick={() => setSortBy('occurrences')}
          >
            Ocorrências
          </Button>
        </div>
      </div>

      {/* Items Table — with new Gap de Preço column */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Package className="h-5 w-5" />
            Itens Perdidos ({filteredItems.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {filteredItems.length === 0 ? (
            <div className="text-center py-12">
              <Package className="h-12 w-12 text-muted-foreground/50 mx-auto mb-4" />
              <p className="text-lg font-medium">Nenhum item encontrado</p>
              <p className="text-muted-foreground mt-1">
                Não há itens de orçamentos perdidos no período selecionado.
              </p>
            </div>
          ) : (
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[30%]">Produto</TableHead>
                    <TableHead className="text-center">Qtd Total</TableHead>
                    <TableHead className="text-center">Ocorrências</TableHead>
                    <TableHead className="text-right">Preço Médio</TableHead>
                    <TableHead className="text-right">Valor Total</TableHead>
                    <TableHead className="text-center">Comparativo</TableHead>
                    <TableHead className="text-center">Gap de Preço</TableHead>
                    <TableHead className="text-center w-[70px]">Ação</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredItems.slice(0, 50).map((item, idx) => (
                    <TableRow key={idx}>
                      <TableCell>
                        <div>
                          <p className="font-medium">{item.product_name}</p>
                          <p className="text-xs text-muted-foreground">
                            {item.clients.slice(0, 2).join(', ')}
                            {item.clients.length > 2 && ` +${item.clients.length - 2}`}
                          </p>
                        </div>
                      </TableCell>
                      <TableCell className="text-center">
                        <Badge variant="outline">{item.total_quantity}</Badge>
                      </TableCell>
                      <TableCell className="text-center">
                        <Badge variant="secondary">{item.occurrences}x</Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        {formatCurrency(item.avg_price)}
                      </TableCell>
                      <TableCell className="text-right font-bold text-red-600">
                        {formatCurrency(item.total_value)}
                      </TableCell>
                      <TableCell className="text-center">
                        {item.has_comparison ? (
                          <div className="space-y-1">
                            {item.competitor_prices.slice(0, 2).map((cp, i) => (
                              <Badge 
                                key={i} 
                                variant="outline" 
                                className="bg-blue-50 dark:bg-blue-950 text-blue-700 dark:text-blue-300 border-blue-200 dark:border-blue-800 text-xs"
                              >
                                {formatCurrency(cp.price)} - {cp.where}
                              </Badge>
                            ))}
                          </div>
                        ) : (
                          <span className="text-muted-foreground text-xs">—</span>
                        )}
                      </TableCell>
                      <TableCell className="text-center">
                        {getGapBadge(item.gap_percentual)}
                      </TableCell>
                      <TableCell className="text-center">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleOpenComparison(item)}
                          title="Adicionar preço do concorrente"
                        >
                          <Plus className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Top 10 Chart */}
      {filteredItems.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Top 10 Produtos Mais Perdidos</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {filteredItems.slice(0, 10).map((item, idx) => {
              const maxValue = filteredItems[0].total_value;
              const percentage = (item.total_value / maxValue) * 100;
              
              return (
                <div key={idx}>
                  <div className="flex items-center justify-between text-sm mb-1">
                    <div className="flex items-center gap-2">
                      <span className="w-6 h-6 bg-red-100 dark:bg-red-900/50 rounded-full flex items-center justify-center text-xs font-bold text-red-600">
                        {idx + 1}
                      </span>
                      <span className="font-medium truncate max-w-[300px]" title={item.product_name}>
                        {item.product_name}
                      </span>
                    </div>
                    <span className="font-bold text-red-600">{formatCurrency(item.total_value)}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Progress value={percentage} className="h-2 flex-1" />
                    <span className="text-xs text-muted-foreground w-12 text-right">
                      {item.occurrences}x
                    </span>
                  </div>
                </div>
              );
            })}
          </CardContent>
        </Card>
      )}

      {/* Pauta de Renegociação para Compras */}
      <Card className="border-yellow-200 dark:border-yellow-800 bg-yellow-50/50 dark:bg-yellow-950/20">
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <ShoppingCart className="h-5 w-5 text-yellow-600" />
            Produtos para Compras Renegociar
          </CardTitle>
          <p className="text-xs text-muted-foreground mt-1">
            Produtos com ≥2 ocorrências de perda e preço H&H acima do concorrente
          </p>
        </CardHeader>
        <CardContent>
          {renegotiationItems.length === 0 ? (
            <div className="text-center py-8">
              <AlertTriangle className="h-10 w-10 text-muted-foreground/40 mx-auto mb-3" />
              <p className="text-sm text-muted-foreground">
                Nenhum produto com comparativo de preço registrado ainda.
              </p>
            </div>
          ) : (
            <div className="rounded-md border border-yellow-200 dark:border-yellow-800">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[30%]">Produto</TableHead>
                    <TableHead className="text-center">Ocorrências</TableHead>
                    <TableHead className="text-right">Preço Médio H&H</TableHead>
                    <TableHead className="text-right">Preço Médio Concorrente</TableHead>
                    <TableHead className="text-center">Gap %</TableHead>
                    <TableHead className="text-right">Valor em Risco</TableHead>
                    <TableHead className="text-center">Urgência</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {renegotiationItems.map((item, idx) => (
                    <TableRow key={idx}>
                      <TableCell className="font-medium">{item.product_name}</TableCell>
                      <TableCell className="text-center">
                        <Badge variant="secondary">{item.occurrences}x</Badge>
                      </TableCell>
                      <TableCell className="text-right">{formatCurrency(item.avg_price)}</TableCell>
                      <TableCell className="text-right">{formatCurrency(item.avg_competitor_price || 0)}</TableCell>
                      <TableCell className="text-center">
                        {getGapBadge(item.gap_percentual)}
                      </TableCell>
                      <TableCell className="text-right font-bold text-red-600">
                        {formatCurrency(item.total_value)}
                      </TableCell>
                      <TableCell className="text-center">
                        {getUrgencyBadge(item.gap_percentual || 0)}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Modal Adicionar Preço Comparativo */}
      <Dialog open={showComparisonModal} onOpenChange={setShowComparisonModal}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <DollarSign className="h-5 w-5 text-blue-600" />
              Adicionar Preço do Concorrente
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="p-3 bg-muted/50 rounded-lg">
              <p className="text-sm text-muted-foreground">Produto:</p>
              <p className="font-medium">{selectedItem?.product_name}</p>
              <p className="text-sm text-muted-foreground mt-1">
                Nosso preço médio: {selectedItem ? formatCurrency(selectedItem.avg_price) : '—'}
              </p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Preço do Concorrente *</Label>
                <Input
                  placeholder="0,00"
                  value={compPrice}
                  onChange={(e) => setCompPrice(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label>Onde comprou</Label>
                <Input
                  placeholder="Ex: Kalunga, Amazon..."
                  value={compWhere}
                  onChange={(e) => setCompWhere(e.target.value)}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label>Fonte da informação</Label>
              <Select value={compSource} onValueChange={(v: 'cliente' | 'pesquisa' | 'vendedor') => setCompSource(v)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="cliente">Cliente informou</SelectItem>
                  <SelectItem value="pesquisa">Pesquisa de mercado</SelectItem>
                  <SelectItem value="vendedor">Vendedor pesquisou</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Observações (opcional)</Label>
              <Textarea
                placeholder="Detalhes adicionais..."
                value={compNotes}
                onChange={(e) => setCompNotes(e.target.value)}
                rows={2}
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowComparisonModal(false)}>
              Cancelar
            </Button>
            <Button onClick={handleSaveComparison} disabled={savingComparison || !compPrice}>
              {savingComparison ? (
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
              ) : (
                <Save className="h-4 w-4 mr-2" />
              )}
              Salvar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
