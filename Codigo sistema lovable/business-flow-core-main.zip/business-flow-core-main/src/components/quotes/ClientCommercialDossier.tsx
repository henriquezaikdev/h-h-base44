import { useState, useEffect, useMemo } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { 
  Loader2, ArrowLeft, Building2, FileX2, TrendingDown, 
  Target, Calendar, User, DollarSign, Save, MessageSquare,
  Edit2, AlertTriangle, CheckCircle, Clock, ExternalLink, Lock
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { 
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue 
} from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { format, parseISO, differenceInMonths } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { useNavigate } from 'react-router-dom';

interface ClientCommercialDossierProps {
  clientId: string;
  onBack: () => void;
  sellerId?: string | null;
}

const LOSS_REASONS: Record<string, { label: string; color: string }> = {
  preco: { label: 'Preço', color: '#ef4444' },
  prazo: { label: 'Prazo', color: '#f97316' },
  concorrente: { label: 'Concorrente', color: '#eab308' },
  estoque: { label: 'Estoque', color: '#22c55e' },
  sem_retorno: { label: 'Sem Retorno', color: '#6366f1' },
  outro: { label: 'Outro', color: '#a855f7' },
};

export function ClientCommercialDossier({ clientId, onBack, sellerId }: ClientCommercialDossierProps) {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { seller } = useAuth();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [client, setClient] = useState<any>(null);
  const [quotes, setQuotes] = useState<any[]>([]);
  const [comments, setComments] = useState<any[]>([]);
  const [comparisons, setComparisons] = useState<any[]>([]);
  const [editMode, setEditMode] = useState(false);
  const [newComment, setNewComment] = useState('');
  
  // Editable fields
  const [perfilPreco, setPerfilPreco] = useState('medio');
  const [perfilPrazo, setPerfilPrazo] = useState('normal');
  const [indiceDificuldade, setIndiceDificuldade] = useState('medio');
  const [statusComercial, setStatusComercial] = useState('ativo');
  const [observacaoComercial, setObservacaoComercial] = useState('');

  useEffect(() => {
    fetchData();
  }, [clientId]);

  const fetchData = async () => {
    setLoading(true);
    try {
      // Fetch client data
      const { data: clientData, error: clientError } = await supabase
        .from('clients')
        .select('*')
        .eq('id', clientId)
        .single();

      if (clientError) throw clientError;
      setClient(clientData);
      
      // Set editable fields
      setPerfilPreco(clientData.perfil_preco || 'medio');
      setPerfilPrazo(clientData.perfil_prazo || 'normal');
      setIndiceDificuldade(clientData.indice_dificuldade || 'medio');
      setStatusComercial(clientData.status_comercial || 'ativo');
      setObservacaoComercial(clientData.observacao_comercial || '');

      // Fetch quotes with items - Não filtra por seller para mostrar todo o histórico do cliente
      const { data: quotesData, error: quotesError } = await supabase
        .from('quotes')
        .select(`
          *,
          seller:sellers!quotes_seller_id_fkey(name),
          quote_items(id, product_name, quantity, unit_price, subtotal)
        `)
        .eq('client_id', clientId)
        .eq('status', 'perdido')
        .order('quote_date', { ascending: false });
      if (quotesError) throw quotesError;
      setQuotes(quotesData || []);

      // Fetch comparisons for all items
      const allItemIds = (quotesData || []).flatMap(q => (q.quote_items || []).map((i: any) => i.id));
      if (allItemIds.length > 0) {
        const { data: compsData } = await supabase
          .from('quote_item_comparisons')
          .select('*')
          .in('quote_item_id', allItemIds);
        setComparisons(compsData || []);
      } else {
        setComparisons([]);
      }

      // Fetch comments for all quotes
      if (quotesData && quotesData.length > 0) {
        const quoteIds = quotesData.map(q => q.id);
        const { data: commentsData } = await supabase
          .from('quote_comments')
          .select('*')
          .in('quote_id', quoteIds)
          .order('created_at', { ascending: false });
        
        setComments(commentsData || []);
      }
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSaveProfile = async () => {
    setSaving(true);
    try {
      const { error } = await supabase
        .from('clients')
        .update({
          perfil_preco: perfilPreco,
          perfil_prazo: perfilPrazo,
          indice_dificuldade: indiceDificuldade,
          status_comercial: statusComercial,
          observacao_comercial: observacaoComercial,
        })
        .eq('id', clientId);

      if (error) throw error;

      toast({
        title: 'Perfil atualizado',
        description: 'As informações comerciais foram salvas.',
      });
      setEditMode(false);
      fetchData();
    } catch (error) {
      console.error('Error saving profile:', error);
      toast({
        title: 'Erro ao salvar',
        description: 'Não foi possível salvar as alterações.',
        variant: 'destructive',
      });
    } finally {
      setSaving(false);
    }
  };

  const handleAddComment = async (quoteId: string) => {
    if (!newComment.trim()) return;

    try {
      const { error } = await supabase
        .from('quote_comments')
        .insert({
          quote_id: quoteId,
          comment: newComment,
          created_by: seller?.id,
          created_by_name: seller?.name,
        });

      if (error) throw error;

      toast({ title: 'Comentário adicionado' });
      setNewComment('');
      fetchData();
    } catch (error) {
      console.error('Error adding comment:', error);
      toast({
        title: 'Erro',
        description: 'Não foi possível adicionar o comentário.',
        variant: 'destructive',
      });
    }
  };

  // Analytics
  const analytics = useMemo(() => {
    const totalLostValue = quotes.reduce((sum, q) => sum + (q.total || 0), 0);
    const avgQuoteValue = quotes.length > 0 ? totalLostValue / quotes.length : 0;
    
    // Loss reasons breakdown
    const reasonsCount: Record<string, number> = {};
    quotes.forEach(q => {
      const reason = q.loss_reason || 'outro';
      reasonsCount[reason] = (reasonsCount[reason] || 0) + 1;
    });
    const mainReason = Object.entries(reasonsCount)
      .sort((a, b) => b[1] - a[1])[0]?.[0] || null;

    // Most lost items
    const itemsCount: Record<string, { count: number; value: number }> = {};
    quotes.forEach(q => {
      (q.quote_items || []).forEach((item: any) => {
        const key = item.product_name;
        if (!itemsCount[key]) itemsCount[key] = { count: 0, value: 0 };
        itemsCount[key].count += item.quantity;
        itemsCount[key].value += item.subtotal;
      });
    });
    const topLostItems = Object.entries(itemsCount)
      .map(([name, data]) => ({ name, ...data }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 5);

    // Competitors with price info
    const competitors: Record<string, { count: number; totalPrice: number }> = {};
    quotes.filter(q => q.competitor).forEach(q => {
      if (!competitors[q.competitor]) {
        competitors[q.competitor] = { count: 0, totalPrice: 0 };
      }
      competitors[q.competitor].count++;
      if (q.competitor_price) {
        competitors[q.competitor].totalPrice += q.competitor_price;
      }
    });

    // Aggregated competitor prices for "price" reason
    const quotesWithPrice = quotes.filter(q => q.loss_reason === 'preco' && q.competitor_price);
    const totalOurPriceForPriceReason = quotesWithPrice.reduce((sum, q) => sum + (q.total || 0), 0);
    const totalCompetitorPrice = quotesWithPrice.reduce((sum, q) => sum + (q.competitor_price || 0), 0);
    const priceDifference = totalOurPriceForPriceReason - totalCompetitorPrice;
    const priceDifferencePercent = totalOurPriceForPriceReason > 0 
      ? ((priceDifference / totalOurPriceForPriceReason) * 100).toFixed(1) 
      : '0';

    // Historical classification (12+ months = cold, 24+ months = hidden)
    const now = new Date();
    const recentQuotes = quotes.filter(q => {
      const monthsAgo = differenceInMonths(now, parseISO(q.quote_date));
      return monthsAgo <= 12;
    });
    const coldQuotes = quotes.filter(q => {
      const monthsAgo = differenceInMonths(now, parseISO(q.quote_date));
      return monthsAgo > 12 && monthsAgo <= 24;
    });

    return {
      totalLostValue,
      avgQuoteValue,
      totalQuotes: quotes.length,
      mainReason,
      reasonsCount,
      topLostItems,
      competitors,
      recentQuotes,
      coldQuotes,
      quotesWithPrice,
      totalOurPriceForPriceReason,
      totalCompetitorPrice,
      priceDifference,
      priceDifferencePercent,
    };
  }, [quotes]);

  const formatCurrency = (value: number) => 
    new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);

  if (loading) {
    return (
      <div className="flex justify-center py-12">
        <Loader2 className="animate-spin h-8 w-8 text-primary" />
      </div>
    );
  }

  if (!client) {
    return (
      <div className="text-center py-12">
        <p>Cliente não encontrado</p>
        <Button variant="outline" onClick={onBack} className="mt-4">
          Voltar
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={onBack}>
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <div className="flex-1">
          <div className="flex items-center gap-3">
            <h2 className="text-2xl font-bold">{client.company_name}</h2>
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => navigate(`/clients/${clientId}`)}
            >
              <ExternalLink className="h-4 w-4 mr-2" />
              Ver Ficha Completa
            </Button>
          </div>
          <p className="text-muted-foreground">Dossiê Comercial</p>
        </div>
      </div>

      <Tabs defaultValue="profile" className="space-y-6">
        <TabsList>
          <TabsTrigger value="profile" className="flex items-center gap-2">
            <Building2 className="h-4 w-4" />
            Perfil Comercial
          </TabsTrigger>
          <TabsTrigger value="history" className="flex items-center gap-2">
            <FileX2 className="h-4 w-4" />
            Histórico ({quotes.length})
          </TabsTrigger>
          <TabsTrigger value="items" className="flex items-center gap-2">
            <Target className="h-4 w-4" />
            Itens Perdidos
          </TabsTrigger>
        </TabsList>

        {/* Profile Tab */}
        <TabsContent value="profile" className="space-y-6">
          {/* KPIs */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card className="border-red-200 dark:border-red-800">
              <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-red-100 dark:bg-red-900/50 rounded-lg">
                    <TrendingDown className="h-5 w-5 text-red-600" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Total Perdido</p>
                    <p className="text-xl font-bold text-red-600">
                      {formatCurrency(analytics.totalLostValue)}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-orange-100 dark:bg-orange-900/50 rounded-lg">
                    <FileX2 className="h-5 w-5 text-orange-600" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Orçamentos</p>
                    <p className="text-xl font-bold">{analytics.totalQuotes}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-blue-100 dark:bg-blue-900/50 rounded-lg">
                    <DollarSign className="h-5 w-5 text-blue-600" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Ticket Médio</p>
                    <p className="text-xl font-bold">{formatCurrency(analytics.avgQuoteValue)}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-purple-100 dark:bg-purple-900/50 rounded-lg">
                    <AlertTriangle className="h-5 w-5 text-purple-600" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Principal Motivo</p>
                    <p className="text-xl font-bold capitalize">
                      {LOSS_REASONS[analytics.mainReason || '']?.label || 'N/A'}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Commercial Profile */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-lg">Perfil Comercial</CardTitle>
              {!editMode ? (
                <Button variant="outline" size="sm" onClick={() => setEditMode(true)}>
                  <Edit2 className="h-4 w-4 mr-2" />
                  Editar
                </Button>
              ) : (
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={() => setEditMode(false)}>
                    Cancelar
                  </Button>
                  <Button size="sm" onClick={handleSaveProfile} disabled={saving}>
                    {saving ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Save className="h-4 w-4 mr-2" />}
                    Salvar
                  </Button>
                </div>
              )}
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                  <label className="text-sm text-muted-foreground">Perfil de Preço</label>
                  {editMode ? (
                    <Select value={perfilPreco} onValueChange={setPerfilPreco}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="baixo">Baixo</SelectItem>
                        <SelectItem value="medio">Médio</SelectItem>
                        <SelectItem value="alto">Alto</SelectItem>
                      </SelectContent>
                    </Select>
                  ) : (
                    <p className="font-medium capitalize">{perfilPreco}</p>
                  )}
                </div>

                <div>
                  <label className="text-sm text-muted-foreground">Perfil de Prazo</label>
                  {editMode ? (
                    <Select value={perfilPrazo} onValueChange={setPerfilPrazo}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="rapido">Rápido</SelectItem>
                        <SelectItem value="normal">Normal</SelectItem>
                        <SelectItem value="flexivel">Flexível</SelectItem>
                      </SelectContent>
                    </Select>
                  ) : (
                    <p className="font-medium capitalize">{perfilPrazo}</p>
                  )}
                </div>

                <div>
                  <label className="text-sm text-muted-foreground">Índice de Dificuldade</label>
                  {editMode ? (
                    <Select value={indiceDificuldade} onValueChange={setIndiceDificuldade}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="facil">Fácil</SelectItem>
                        <SelectItem value="medio">Médio</SelectItem>
                        <SelectItem value="dificil">Difícil</SelectItem>
                      </SelectContent>
                    </Select>
                  ) : (
                    <p className="font-medium capitalize">{indiceDificuldade}</p>
                  )}
                </div>

                <div>
                  <label className="text-sm text-muted-foreground">Status Comercial</label>
                  {editMode ? (
                    <Select value={statusComercial} onValueChange={setStatusComercial}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="ativo">Ativo</SelectItem>
                        <SelectItem value="frio">Frio</SelectItem>
                        <SelectItem value="apenas_cotador">Apenas Cotador</SelectItem>
                      </SelectContent>
                    </Select>
                  ) : (
                    <Badge variant="outline" className={
                      statusComercial === 'ativo' ? 'bg-green-100 text-green-700' :
                      statusComercial === 'frio' ? 'bg-blue-100 text-blue-700' :
                      'bg-orange-100 text-orange-700'
                    }>
                      {statusComercial === 'apenas_cotador' ? 'Apenas Cotador' : 
                       statusComercial.charAt(0).toUpperCase() + statusComercial.slice(1)}
                    </Badge>
                  )}
                </div>
              </div>

              <div>
                <label className="text-sm text-muted-foreground">Observação Comercial</label>
                {editMode ? (
                  <Textarea
                    value={observacaoComercial}
                    onChange={(e) => setObservacaoComercial(e.target.value)}
                    placeholder="Observações sobre o perfil comercial do cliente..."
                    rows={3}
                  />
                ) : (
                  <p className="text-sm mt-1">
                    {observacaoComercial || <span className="text-muted-foreground italic">Nenhuma observação</span>}
                  </p>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Loss Reasons Breakdown */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Motivos de Perda</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-6 gap-4">
                {Object.entries(analytics.reasonsCount).map(([reason, count]) => {
                  const config = LOSS_REASONS[reason] || { label: reason, color: '#94a3b8' };
                  return (
                    <div 
                      key={reason}
                      className="p-3 rounded-lg text-center"
                      style={{ backgroundColor: config.color + '15', borderColor: config.color + '40' }}
                    >
                      <p className="text-2xl font-bold" style={{ color: config.color }}>{count}</p>
                      <p className="text-xs text-muted-foreground">{config.label}</p>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          {/* Análise de Preço vs Concorrência */}
          {analytics.quotesWithPrice.length > 0 && (
            <Card className="border-blue-200 dark:border-blue-800">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <DollarSign className="h-5 w-5 text-blue-600" />
                  Análise de Preço vs Concorrência
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div className="p-3 bg-muted/30 rounded-lg">
                    <p className="text-sm text-muted-foreground">Nosso Preço Total</p>
                    <p className="text-xl font-bold">{formatCurrency(analytics.totalOurPriceForPriceReason)}</p>
                  </div>
                  <div className="p-3 bg-blue-50 dark:bg-blue-950/30 rounded-lg">
                    <p className="text-sm text-muted-foreground">Preço Concorrente Total</p>
                    <p className="text-xl font-bold text-blue-600">{formatCurrency(analytics.totalCompetitorPrice)}</p>
                  </div>
                  <div className={`p-3 rounded-lg ${analytics.priceDifference > 0 ? 'bg-red-50 dark:bg-red-950/30' : 'bg-green-50 dark:bg-green-950/30'}`}>
                    <p className="text-sm text-muted-foreground">Diferença</p>
                    <p className={`text-xl font-bold ${analytics.priceDifference > 0 ? 'text-red-600' : 'text-green-600'}`}>
                      {analytics.priceDifference > 0 ? '+' : ''}{formatCurrency(analytics.priceDifference)}
                    </p>
                  </div>
                  <div className="p-3 bg-muted/30 rounded-lg">
                    <p className="text-sm text-muted-foreground">% Acima</p>
                    <p className={`text-xl font-bold ${Number(analytics.priceDifferencePercent) > 0 ? 'text-red-600' : 'text-green-600'}`}>
                      {analytics.priceDifferencePercent}%
                    </p>
                  </div>
                </div>
                <p className="text-xs text-muted-foreground">
                  Baseado em {analytics.quotesWithPrice.length} orçamento(s) perdido(s) por preço com informação do concorrente.
                </p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* History Tab */}
        <TabsContent value="history" className="space-y-4">
          {analytics.recentQuotes.length === 0 && analytics.coldQuotes.length === 0 ? (
            <div className="text-center py-12 bg-muted/30 rounded-lg">
              <FileX2 className="h-12 w-12 text-muted-foreground/50 mx-auto mb-4" />
              <p className="text-lg font-medium">Nenhum orçamento perdido</p>
            </div>
          ) : (
            <>
              {/* Recent Quotes (last 12 months) */}
              {analytics.recentQuotes.length > 0 && (
                <div>
                  <h3 className="font-medium text-lg mb-3 flex items-center gap-2">
                    <CheckCircle className="h-5 w-5 text-green-600" />
                    Histórico Recente (últimos 12 meses)
                  </h3>
                  <div className="space-y-3">
                    {analytics.recentQuotes.map((quote) => (
                      <QuoteCard 
                        key={quote.id} 
                        quote={quote} 
                        comments={comments.filter(c => c.quote_id === quote.id)}
                        onAddComment={handleAddComment}
                        newComment={newComment}
                        setNewComment={setNewComment}
                      />
                    ))}
                  </div>
                </div>
              )}

              {/* Cold Quotes (12-24 months) */}
              {analytics.coldQuotes.length > 0 && (
                <div>
                  <h3 className="font-medium text-lg mb-3 flex items-center gap-2">
                    <Clock className="h-5 w-5 text-blue-600" />
                    Histórico Frio (12-24 meses)
                  </h3>
                  <div className="space-y-3 opacity-75">
                    {analytics.coldQuotes.map((quote) => (
                      <QuoteCard 
                        key={quote.id} 
                        quote={quote} 
                        comments={comments.filter(c => c.quote_id === quote.id)}
                        onAddComment={handleAddComment}
                        newComment={newComment}
                        setNewComment={setNewComment}
                        isCold
                      />
                    ))}
                  </div>
                </div>
              )}
            </>
          )}
        </TabsContent>

        <TabsContent value="items" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Itens Mais Perdidos</CardTitle>
            </CardHeader>
            <CardContent>
              {analytics.topLostItems.length > 0 ? (
                <div className="space-y-4">
                  {analytics.topLostItems.map((item, idx) => {
                    // Find comparisons for this product
                    const allItemIds = quotes.flatMap(q => 
                      (q.quote_items || [])
                        .filter((qi: any) => qi.product_name.toLowerCase().trim() === item.name.toLowerCase().trim())
                        .map((qi: any) => qi.id)
                    );
                    const itemComps = comparisons.filter(c => allItemIds.includes(c.quote_item_id));
                    const hasComps = itemComps.length > 0;
                    let avgCompPrice = 0;
                    let gap = 0;
                    let compSource = '';
                    
                    if (hasComps) {
                      avgCompPrice = itemComps.reduce((s: number, c: any) => s + c.preco_concorrente, 0) / itemComps.length;
                      const avgHH = item.count > 0 ? item.value / item.count : 0;
                      gap = avgCompPrice > 0 ? ((avgHH - avgCompPrice) / avgCompPrice) * 100 : 0;
                      compSource = itemComps[0]?.onde_comprou || itemComps[0]?.fonte_informacao || '';
                    }

                    return (
                      <div key={idx} className="p-3 bg-muted/30 rounded-lg">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <span className="w-8 h-8 bg-red-100 dark:bg-red-900/50 rounded-full flex items-center justify-center text-sm font-bold text-red-600">
                              #{idx + 1}
                            </span>
                            <div>
                              <p className="font-medium">{item.name}</p>
                              <p className="text-sm text-muted-foreground">{item.count} unidades</p>
                            </div>
                          </div>
                          <p className="text-lg font-bold text-red-600">{formatCurrency(item.value)}</p>
                        </div>
                        {hasComps && (
                          <div className="mt-2 ml-11 flex items-center gap-2 flex-wrap">
                            <span className={`text-xs font-medium ${gap > 0 ? 'text-red-600' : 'text-green-600'}`}>
                              H&H cobrou {gap > 0 ? '+' : ''}{gap.toFixed(1)}% {gap > 0 ? 'acima' : 'abaixo'} do concorrente
                            </span>
                            {compSource && (
                              <span className="text-xs text-muted-foreground">({compSource})</span>
                            )}
                            {gap > 15 ? (
                              <Badge className="bg-red-500/10 text-red-600 border-red-500/20 text-xs">Gap alto</Badge>
                            ) : gap > 5 ? (
                              <Badge className="bg-yellow-500/10 text-yellow-700 border-yellow-500/20 text-xs">Gap moderado</Badge>
                            ) : gap > 0 ? (
                              <Badge className="bg-foreground/5 text-muted-foreground border-foreground/10 text-xs">Gap baixo</Badge>
                            ) : (
                              <Badge className="bg-green-500/10 text-green-600 border-green-500/20 text-xs">Competitivo</Badge>
                            )}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              ) : (
                <p className="text-center text-muted-foreground py-8">Nenhum item registrado</p>
              )}
            </CardContent>
          </Card>

          {/* Histórico de Preço */}
          {(() => {
            const allItemIds = quotes.flatMap(q => (q.quote_items || []).map((qi: any) => qi.id));
            const clientComps = comparisons.filter(c => allItemIds.includes(c.quote_item_id));
            if (clientComps.length === 0) return null;

            const priceQuotes = quotes.filter(q => q.loss_reason === 'preco');
            const allGaps: number[] = [];
            
            analytics.topLostItems.forEach(item => {
              const ids = quotes.flatMap(q =>
                (q.quote_items || [])
                  .filter((qi: any) => qi.product_name.toLowerCase().trim() === item.name.toLowerCase().trim())
                  .map((qi: any) => qi.id)
              );
              const comps = comparisons.filter(c => ids.includes(c.quote_item_id));
              if (comps.length > 0) {
                const avgComp = comps.reduce((s: number, c: any) => s + c.preco_concorrente, 0) / comps.length;
                const avgHH = item.count > 0 ? item.value / item.count : 0;
                if (avgComp > 0) allGaps.push(((avgHH - avgComp) / avgComp) * 100);
              }
            });

            const avgGap = allGaps.length > 0 ? allGaps.reduce((a, b) => a + b, 0) / allGaps.length : 0;

            return (
              <Card className="border-l-4 border-l-primary">
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <DollarSign className="h-5 w-5 text-primary" />
                    Como este cliente compara preços
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    Este cliente perdeu <strong className="text-foreground">{priceQuotes.length}</strong> orçamento(s) por preço.
                    Em <strong className="text-foreground">{clientComps.length}</strong> ocasião(ões) havia comparativo registrado.
                    Gap médio: <strong className={avgGap > 0 ? 'text-red-600' : 'text-green-600'}>
                      {avgGap > 0 ? '+' : ''}{avgGap.toFixed(1)}%
                    </strong>.
                  </p>
                </CardContent>
              </Card>
            );
          })()}
        </TabsContent>
      </Tabs>
    </div>
  );
}

// Quote Card Component - EXIBE ORÇAMENTOS COMO REGISTROS BLOQUEADOS E IMUTÁVEIS
function QuoteCard({ 
  quote, 
  comments, 
  onAddComment, 
  newComment, 
  setNewComment,
  isCold = false 
}: { 
  quote: any; 
  comments: any[];
  onAddComment: (quoteId: string) => void;
  newComment: string;
  setNewComment: (value: string) => void;
  isCold?: boolean;
}) {
  const [showComments, setShowComments] = useState(false);
  const reasonConfig = LOSS_REASONS[quote.loss_reason] || { label: 'Outro', color: '#94a3b8' };
  const isLocked = !!quote.locked_at;

  const formatCurrency = (value: number) => 
    new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);

  return (
    <div className={`rounded-lg border p-4 ${isCold ? 'bg-blue-50/30 dark:bg-blue-950/10 border-blue-200' : 'bg-red-50/30 dark:bg-red-950/10 border-red-200'}`}>
      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2">
            <p className="font-semibold">Orçamento #{quote.quote_number}</p>
            <Badge 
              variant="outline" 
              style={{ backgroundColor: reasonConfig.color + '20', borderColor: reasonConfig.color, color: reasonConfig.color }}
            >
              {reasonConfig.label}
            </Badge>
            {isLocked && (
              <Badge variant="outline" className="bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400">
                <Lock className="h-3 w-3 mr-1" />
                Bloqueado
              </Badge>
            )}
            {isCold && <Badge variant="outline" className="bg-blue-100 text-blue-700">Histórico Frio</Badge>}
          </div>
          <div className="flex items-center gap-3 text-sm text-muted-foreground mt-1">
            <span className="flex items-center gap-1">
              <Calendar className="h-3.5 w-3.5" />
              {format(parseISO(quote.quote_date), "dd/MM/yyyy", { locale: ptBR })}
            </span>
            {quote.seller?.name && (
              <span className="flex items-center gap-1">
                <User className="h-3.5 w-3.5" />
                {quote.seller.name}
              </span>
            )}
            {quote.competitor && (
              <span className="flex items-center gap-1">
                <Building2 className="h-3.5 w-3.5" />
                {quote.competitor}
              </span>
            )}
          </div>
        </div>
        <div className="text-right">
          <p className="text-xl font-bold text-red-600">{formatCurrency(quote.total)}</p>
          {quote.competitor_price && (
            <p className="text-sm text-blue-600">
              Concorrente: {formatCurrency(quote.competitor_price)}
            </p>
          )}
          <p className="text-sm text-muted-foreground">{quote.quote_items?.length || 0} itens</p>
        </div>
      </div>

      {quote.loss_notes && (
        <p className="mt-2 text-sm text-muted-foreground italic">"{quote.loss_notes}"</p>
      )}

      {/* Aviso de imutabilidade */}
      {isLocked && (
        <div className="mt-3 p-2 bg-amber-50/50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-800 rounded text-xs text-amber-700 dark:text-amber-400 flex items-center gap-2">
          <Lock className="h-3.5 w-3.5" />
          <span>Registro histórico imutável. Apenas observações podem ser adicionadas.</span>
        </div>
      )}

      {/* Comments Section - FUNCIONA COMO LOG IMUTÁVEL */}
      <div className="mt-3 pt-3 border-t border-border/50">
        <Button 
          variant="ghost" 
          size="sm" 
          onClick={() => setShowComments(!showComments)}
          className="text-muted-foreground"
        >
          <MessageSquare className="h-4 w-4 mr-2" />
          Observações ({comments.length})
        </Button>

        {showComments && (
          <div className="mt-3 space-y-3">
            {/* Histórico de observações - apenas leitura */}
            {comments.length > 0 ? (
              <div className="space-y-2 max-h-48 overflow-y-auto">
                {comments.map((comment) => (
                  <div key={comment.id} className="p-2 bg-muted/50 rounded text-sm border-l-2 border-primary/30">
                    <div className="flex items-center justify-between text-xs text-muted-foreground mb-1">
                      <span className="font-medium">{comment.created_by_name || 'Sistema'}</span>
                      <span>{format(parseISO(comment.created_at), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}</span>
                    </div>
                    <p className="text-foreground">{comment.comment}</p>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground italic">Nenhuma observação registrada</p>
            )}
            
            {/* Adicionar nova observação */}
            <div className="pt-3 border-t border-border/30">
              <p className="text-xs text-muted-foreground mb-2">
                Adicionar observação (registro permanente com data e usuário)
              </p>
              <div className="flex gap-2">
                <Textarea
                  placeholder="Nova observação..."
                  value={newComment}
                  onChange={(e) => setNewComment(e.target.value)}
                  rows={2}
                  className="text-sm"
                />
                <Button 
                  size="sm" 
                  onClick={() => onAddComment(quote.id)}
                  disabled={!newComment.trim()}
                >
                  Registrar
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
