import { useState, useEffect } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { BarChart3, Users, Package, TrendingDown } from 'lucide-react';
import { 
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue 
} from '@/components/ui/select';
import { User } from 'lucide-react';
import { QuotesOverview } from './QuotesOverview';
import { QuotesClients } from './QuotesClients';
import { QuotesItems } from './QuotesItems';
import { QuoteAlertsPanel } from './QuoteAlertsPanel';
import { LostSalesReport } from '@/components/reports/LostSalesReport';
import { useUIStatePersistence } from '@/hooks/useUIStatePersistence';
import { usePeriodFilter } from '@/hooks/usePeriodFilter';
import { PeriodFilter } from '@/components/ui/PeriodFilter';

interface QuotesModuleProps {
  sellerId?: string | null;
  isAdmin?: boolean;
  sellers?: { id: string; name: string }[];
  onSellerChange?: (sellerId: string | null) => void;
}

export function QuotesModule({ sellerId, isAdmin, sellers, onSellerChange }: QuotesModuleProps) {
  const { getState, saveState } = useUIStatePersistence({ trackScroll: true, scopeKey: 'quotes' });
  const initialState = getState();
  
  const [activeTab, setActiveTab] = useState(initialState?.activeTab || 'overview');
  const periodFilter = usePeriodFilter('month', 'quotes');

  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
    saveState({ activeTab: tab });
  };

  const { startDate, endDate } = periodFilter;

  return (
    <div className="space-y-6">
      <QuoteAlertsPanel sellerId={sellerId} />

      {/* Filters Header */}
      <div className="flex flex-wrap items-center gap-4">
        <PeriodFilter filter={periodFilter} />

        {/* Seller Filter (Admin only) */}
        {isAdmin && sellers && onSellerChange && (
          <div className="flex items-center gap-2 ml-auto">
            <User className="h-4 w-4 text-muted-foreground" />
            <Select 
              value={sellerId || 'all'} 
              onValueChange={(v) => onSellerChange(v === 'all' ? null : v)}
            >
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Todos vendedores" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos vendedores</SelectItem>
                {sellers.map(s => (
                  <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}
      </div>

      {/* Module Tabs */}
      <Tabs value={activeTab} onValueChange={handleTabChange} className="space-y-6">
        <TabsList className="grid w-full max-w-2xl grid-cols-4">
          <TabsTrigger value="overview" className="flex items-center gap-2">
            <BarChart3 className="h-4 w-4" />
            Visão Geral
          </TabsTrigger>
          <TabsTrigger value="clients" className="flex items-center gap-2">
            <Users className="h-4 w-4" />
            Clientes
          </TabsTrigger>
          <TabsTrigger value="items" className="flex items-center gap-2">
            <Package className="h-4 w-4" />
            Itens
          </TabsTrigger>
          <TabsTrigger value="lost_sales" className="flex items-center gap-2">
            <TrendingDown className="h-4 w-4" />
            Vendas Perdidas
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <QuotesOverview 
            sellerId={sellerId}
            startDate={startDate}
            endDate={endDate}
          />
        </TabsContent>

        <TabsContent value="clients">
          <QuotesClients sellerId={sellerId} />
        </TabsContent>

        <TabsContent value="items">
          <QuotesItems 
            sellerId={sellerId}
            startDate={startDate}
            endDate={endDate}
          />
        </TabsContent>

        <TabsContent value="lost_sales">
          <LostSalesReport />
        </TabsContent>
      </Tabs>
    </div>
  );
}
