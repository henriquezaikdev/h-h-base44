import { useState } from 'react';
import { 
  AlertTriangle, ShoppingCart, ChevronDown, ChevronUp, Info
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { useQuoteAlerts } from '@/hooks/useQuoteAlerts';
import { motion, AnimatePresence } from 'framer-motion';

interface QuoteAlertsPanelProps {
  sellerId?: string | null;
}

export function QuoteAlertsPanel({ sellerId }: QuoteAlertsPanelProps) {
  const { renegotiationItems, alertCount, loading } = useQuoteAlerts(sellerId);
  const [isExpanded, setIsExpanded] = useState(true);

  const formatCurrency = (value: number) =>
    new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);

  const getGapBadge = (gap: number) => {
    if (gap > 15) return <Badge className="bg-red-500/10 text-red-600 border-red-500/20 text-xs">+{gap.toFixed(1)}%</Badge>;
    if (gap > 5) return <Badge className="bg-yellow-500/10 text-yellow-700 border-yellow-500/20 text-xs">+{gap.toFixed(1)}%</Badge>;
    return <Badge className="bg-foreground/5 text-muted-foreground border-foreground/10 text-xs">+{gap.toFixed(1)}%</Badge>;
  };

  const getUrgencyBadge = (gap: number) => {
    if (gap > 15) return <Badge className="bg-red-500/10 text-red-600 border-red-500/20 text-xs">Alta</Badge>;
    if (gap > 5) return <Badge className="bg-yellow-500/10 text-yellow-700 border-yellow-500/20 text-xs">Média</Badge>;
    return <Badge className="bg-foreground/5 text-muted-foreground border-foreground/10 text-xs">Baixa</Badge>;
  };

  if (loading) {
    return (
      <Card className="border">
        <CardHeader className="pb-3">
          <Skeleton className="h-5 w-40" />
        </CardHeader>
        <CardContent className="space-y-2">
          <Skeleton className="h-16 w-full" />
          <Skeleton className="h-16 w-full" />
        </CardContent>
      </Card>
    );
  }

  if (alertCount === 0) {
    return null;
  }

  return (
    <Card className="border border-orange-200 dark:border-orange-800 bg-orange-50/30 dark:bg-orange-950/10">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CardTitle className="text-base font-semibold flex items-center gap-2">
              <AlertTriangle className="h-4 w-4 text-orange-500" />
              Pauta de Compras — Ação Necessária
            </CardTitle>
            <Badge variant="secondary" className="text-xs">
              {alertCount}
            </Badge>
          </div>
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7"
            onClick={() => setIsExpanded(!isExpanded)}
          >
            {isExpanded ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
          </Button>
        </div>
        <p className="text-xs text-muted-foreground mt-1">
          Produtos perdidos por preço com comparativo de concorrente registrado
        </p>
      </CardHeader>

      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
          >
            <CardContent className="pt-0">
              <div className="rounded-md border border-orange-200 dark:border-orange-800">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[30%]">Produto</TableHead>
                      <TableHead className="text-center">Ocorrências</TableHead>
                      <TableHead className="text-right">Preço Médio H&H</TableHead>
                      <TableHead className="text-right">Preço Concorrente</TableHead>
                      <TableHead className="text-center">Gap %</TableHead>
                      <TableHead className="text-right">Valor em Risco</TableHead>
                      <TableHead className="text-center">Urgência</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {renegotiationItems.map((item, idx) => (
                      <TableRow key={idx}>
                        <TableCell className="font-medium">{item.product_name}</TableCell>
                        <TableCell className="text-center">
                          <Badge variant="secondary">{item.occurrences}x</Badge>
                        </TableCell>
                        <TableCell className="text-right">{formatCurrency(item.avg_hh_price)}</TableCell>
                        <TableCell className="text-right">{formatCurrency(item.avg_competitor_price)}</TableCell>
                        <TableCell className="text-center">{getGapBadge(item.gap_percentual)}</TableCell>
                        <TableCell className="text-right font-bold text-red-600">
                          {formatCurrency(item.total_value)}
                        </TableCell>
                        <TableCell className="text-center">{getUrgencyBadge(item.gap_percentual)}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              <div className="mt-4 pt-3 border-t border-border/50">
                <p className="text-xs text-muted-foreground flex items-center gap-1.5">
                  <Info className="h-3 w-3 shrink-0" />
                  <span>Produtos com ≥2 ocorrências de perda e preço H&H acima do concorrente.</span>
                </p>
              </div>
            </CardContent>
          </motion.div>
        )}
      </AnimatePresence>
    </Card>
  );
}
