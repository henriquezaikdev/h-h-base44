import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Loader2, FileX2, Calendar, Building2, User, DollarSign, AlertCircle } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { format, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { ClientCommercialDossier } from './ClientCommercialDossier';

interface QuotesOverviewProps {
  sellerId?: string | null;
  startDate?: string;
  endDate?: string;
}

interface Quote {
  id: string;
  quote_number: string;
  quote_date: string;
  total: number;
  status: string;
  loss_reason: string | null;
  competitor: string | null;
  loss_notes: string | null;
  client_id: string;
  seller_id: string | null;
  clients: { company_name: string; ranking_tier: string | null } | null;
  sellers: { name: string } | null;
}

const LOSS_REASONS: Record<string, { label: string; color: string }> = {
  preco: { label: 'Preço', color: 'destructive' },
  prazo: { label: 'Prazo', color: 'secondary' },
  concorrente: { label: 'Concorrente', color: 'outline' },
  estoque: { label: 'Estoque', color: 'secondary' },
  sem_retorno: { label: 'Sem Retorno', color: 'outline' },
  outro: { label: 'Outro', color: 'outline' },
  outros: { label: 'Outros', color: 'outline' },
};

export function QuotesOverview({ sellerId, startDate, endDate }: QuotesOverviewProps) {
  const [loading, setLoading] = useState(true);
  const [quotes, setQuotes] = useState<Quote[]>([]);
  const [selectedClientId, setSelectedClientId] = useState<string | null>(null);

  useEffect(() => {
    fetchQuotes();
  }, [sellerId, startDate, endDate]);

  const fetchQuotes = async () => {
    setLoading(true);
    try {
      let query = supabase
        .from('quotes')
        .select(`
          id,
          quote_number,
          quote_date,
          total,
          status,
          loss_reason,
          competitor,
          loss_notes,
          client_id,
          seller_id,
          clients(company_name, ranking_tier),
          sellers!quotes_seller_id_fkey(name)
        `)
        .order('quote_date', { ascending: false });

      if (sellerId) {
        query = query.eq('seller_id', sellerId);
      }
      if (startDate) {
        query = query.gte('quote_date', startDate);
      }
      if (endDate) {
        query = query.lte('quote_date', endDate);
      }

      const { data, error } = await query;
      if (error) throw error;
      setQuotes(data || []);
    } catch (error) {
      console.error('Error fetching quotes:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (value: number) =>
    new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);

  if (loading) {
    return (
      <div className="flex justify-center py-12">
        <Loader2 className="animate-spin h-8 w-8 text-primary" />
      </div>
    );
  }

  // Se um cliente está selecionado, mostra o dossiê comercial
  if (selectedClientId) {
    return (
      <div className="space-y-4">
        <Button variant="ghost" onClick={() => setSelectedClientId(null)}>
          ← Voltar para lista
        </Button>
        <ClientCommercialDossier 
          clientId={selectedClientId} 
          onBack={() => setSelectedClientId(null)} 
        />
      </div>
    );
  }

  if (quotes.length === 0) {
    return (
      <Card>
        <CardContent className="py-12 text-center">
          <FileX2 className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
          <h3 className="text-lg font-medium mb-2">Nenhum orçamento registrado</h3>
          <p className="text-muted-foreground text-sm">
            Importe orçamentos perdidos para construir sua memória comercial.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <div className="text-sm text-muted-foreground mb-4">
        {quotes.length} orçamento(s) encontrado(s)
      </div>

      <div className="space-y-3">
        {quotes.map((quote) => (
          <Card key={quote.id} className="hover:border-primary/50 transition-colors">
            <CardContent className="p-4">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1 min-w-0">
                  {/* Header: Número e Status */}
                  <div className="flex items-center gap-2 mb-2">
                    <span className="font-medium">#{quote.quote_number}</span>
                    <Badge variant={quote.status === 'perdido' ? 'destructive' : quote.status === 'ganhou' ? 'default' : 'secondary'}>
                      {quote.status === 'perdido' ? 'Perdido' : quote.status === 'ganhou' ? 'Ganhou' : 'Em aberto'}
                    </Badge>
                    {quote.loss_reason && LOSS_REASONS[quote.loss_reason] && (
                      <Badge variant="outline">
                        {LOSS_REASONS[quote.loss_reason].label}
                      </Badge>
                    )}
                  </div>

                  {/* Cliente */}
                  <button
                    onClick={() => setSelectedClientId(quote.client_id)}
                    className="flex items-center gap-2 text-sm text-primary hover:underline mb-2"
                  >
                    <Building2 className="h-4 w-4" />
                    {quote.clients?.company_name || 'Cliente não encontrado'}
                  </button>

                  {/* Info Row */}
                  <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <Calendar className="h-4 w-4" />
                      {format(parseISO(quote.quote_date), 'dd/MM/yyyy', { locale: ptBR })}
                    </span>
                    <span className="flex items-center gap-1">
                      <DollarSign className="h-4 w-4" />
                      {formatCurrency(quote.total)}
                    </span>
                    {quote.sellers?.name && (
                      <span className="flex items-center gap-1">
                        <User className="h-4 w-4" />
                        {quote.sellers.name}
                      </span>
                    )}
                    {quote.competitor && (
                      <span className="flex items-center gap-1">
                        <AlertCircle className="h-4 w-4" />
                        Concorrente: {quote.competitor}
                      </span>
                    )}
                  </div>

                  {/* Notas */}
                  {quote.loss_notes && (
                    <p className="text-sm text-muted-foreground mt-2 italic">
                      "{quote.loss_notes}"
                    </p>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
