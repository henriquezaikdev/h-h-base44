import { useState, useEffect, useMemo } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { 
  Loader2, Building2, ChevronRight, Search, 
  TrendingDown, FileX2, AlertCircle, Filter
} from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue 
} from '@/components/ui/select';
import { ClientCommercialDossier } from './ClientCommercialDossier';

interface ClientQuoteData {
  id: string;
  company_name: string;
  cnpj: string | null;
  perfil_preco: string;
  perfil_prazo: string;
  indice_dificuldade: string;
  status_comercial: string;
  ranking_tier: string;
  total_lost_quotes: number;
  total_lost_value: number;
  last_quote_date: string | null;
  main_loss_reason: string | null;
}

const PERFIL_PRECO: Record<string, { label: string; className: string }> = {
  baixo: { label: 'Preço Baixo', className: 'bg-green-100 text-green-700 border-green-200' },
  medio: { label: 'Preço Médio', className: 'bg-blue-100 text-blue-700 border-blue-200' },
  alto: { label: 'Preço Alto', className: 'bg-purple-100 text-purple-700 border-purple-200' },
};

const STATUS_COMERCIAL: Record<string, { label: string; className: string }> = {
  ativo: { label: 'Ativo', className: 'bg-emerald-100 text-emerald-700 border-emerald-200' },
  frio: { label: 'Frio', className: 'bg-blue-100 text-blue-700 border-blue-200' },
  apenas_cotador: { label: 'Apenas Cotador', className: 'bg-orange-100 text-orange-700 border-orange-200' },
};

const INDICE_DIFICULDADE: Record<string, { label: string; className: string }> = {
  facil: { label: 'Fácil', className: 'bg-green-100 text-green-700 border-green-200' },
  medio: { label: 'Médio', className: 'bg-yellow-100 text-yellow-700 border-yellow-200' },
  dificil: { label: 'Difícil', className: 'bg-red-100 text-red-700 border-red-200' },
};

interface QuotesClientsProps {
  sellerId?: string | null;
}

export function QuotesClients({ sellerId }: QuotesClientsProps) {
  const [loading, setLoading] = useState(true);
  const [clients, setClients] = useState<ClientQuoteData[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [selectedClientId, setSelectedClientId] = useState<string | null>(null);

  useEffect(() => {
    fetchClients();
  }, [sellerId]);

  const fetchClients = async () => {
    setLoading(true);
    try {
      // Fetch all clients with their quote stats
      const { data: clientsData, error: clientsError } = await supabase
        .from('clients')
        .select(`
          id, company_name, cnpj, ranking_tier,
          perfil_preco, perfil_prazo, indice_dificuldade, status_comercial
        `)
        .eq('is_deleted', false)
        .order('company_name');

      if (clientsError) throw clientsError;

      // Fetch quotes for these clients - Não filtra por seller para mostrar todo o histórico do cliente
      const { data: quotesData, error: quotesError } = await supabase
        .from('quotes')
        .select('client_id, total, quote_date, loss_reason')
        .eq('status', 'perdido');
      if (quotesError) throw quotesError;

      // Aggregate quote data per client
      const quotesByClient: Record<string, { 
        count: number; 
        value: number; 
        lastDate: string | null;
        reasons: Record<string, number>;
      }> = {};

      (quotesData || []).forEach(q => {
        if (!quotesByClient[q.client_id]) {
          quotesByClient[q.client_id] = { count: 0, value: 0, lastDate: null, reasons: {} };
        }
        quotesByClient[q.client_id].count++;
        quotesByClient[q.client_id].value += q.total || 0;
        
        if (!quotesByClient[q.client_id].lastDate || q.quote_date > quotesByClient[q.client_id].lastDate) {
          quotesByClient[q.client_id].lastDate = q.quote_date;
        }
        
        const reason = q.loss_reason || 'outro';
        quotesByClient[q.client_id].reasons[reason] = (quotesByClient[q.client_id].reasons[reason] || 0) + 1;
      });

      // Combine data - only show clients with lost quotes
      const combinedData: ClientQuoteData[] = (clientsData || [])
        .filter(c => quotesByClient[c.id])
        .map(client => {
          const quoteData = quotesByClient[client.id];
          const mainReason = Object.entries(quoteData.reasons)
            .sort((a, b) => b[1] - a[1])[0]?.[0] || null;

          return {
            ...client,
            total_lost_quotes: quoteData.count,
            total_lost_value: quoteData.value,
            last_quote_date: quoteData.lastDate,
            main_loss_reason: mainReason,
          };
        })
        .sort((a, b) => b.total_lost_value - a.total_lost_value);

      setClients(combinedData);
    } catch (error) {
      console.error('Error fetching clients:', error);
    } finally {
      setLoading(false);
    }
  };

  const filteredClients = useMemo(() => {
    return clients.filter(client => {
      const matchesSearch = client.company_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (client.cnpj && client.cnpj.includes(searchTerm));
      
      const matchesStatus = statusFilter === 'all' || client.status_comercial === statusFilter;
      
      return matchesSearch && matchesStatus;
    });
  }, [clients, searchTerm, statusFilter]);

  const formatCurrency = (value: number) => 
    new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);

  if (loading) {
    return (
      <div className="flex justify-center py-12">
        <Loader2 className="animate-spin h-8 w-8 text-primary" />
      </div>
    );
  }

  if (selectedClientId) {
    return (
      <ClientCommercialDossier 
        clientId={selectedClientId} 
        onBack={() => setSelectedClientId(null)}
        sellerId={sellerId}
      />
    );
  }

  return (
    <div className="space-y-6">
      {/* Filters */}
      <div className="flex flex-wrap items-center gap-4">
        <div className="relative flex-1 min-w-[200px] max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Buscar cliente..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-9"
          />
        </div>

        <div className="flex items-center gap-2">
          <Filter className="h-4 w-4 text-muted-foreground" />
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Status comercial" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos os status</SelectItem>
              <SelectItem value="ativo">Ativos</SelectItem>
              <SelectItem value="frio">Frios</SelectItem>
              <SelectItem value="apenas_cotador">Apenas Cotadores</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="ml-auto bg-muted/50 px-4 py-2 rounded-lg">
          <span className="text-sm text-muted-foreground">
            {filteredClients.length} clientes com orçamentos perdidos
          </span>
        </div>
      </div>

      {/* Clients List */}
      {filteredClients.length === 0 ? (
        <div className="text-center py-12 bg-muted/30 rounded-lg">
          <Building2 className="h-12 w-12 text-muted-foreground/50 mx-auto mb-4" />
          <p className="text-lg font-medium">Nenhum cliente encontrado</p>
          <p className="text-muted-foreground mt-1">
            Não há clientes com orçamentos perdidos no período selecionado.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredClients.map((client) => {
            const statusConfig = STATUS_COMERCIAL[client.status_comercial] || STATUS_COMERCIAL.ativo;
            const precoConfig = PERFIL_PRECO[client.perfil_preco] || PERFIL_PRECO.medio;
            const dificuldadeConfig = INDICE_DIFICULDADE[client.indice_dificuldade] || INDICE_DIFICULDADE.medio;

            return (
              <div
                key={client.id}
                className="rounded-lg border bg-card hover:shadow-md transition-all cursor-pointer"
                onClick={() => setSelectedClientId(client.id)}
              >
                <div className="flex items-center justify-between p-4">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-lg bg-red-100 dark:bg-red-900/50 flex items-center justify-center">
                      <Building2 className="h-6 w-6 text-red-600" />
                    </div>
                    
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="font-semibold text-lg">{client.company_name}</p>
                        <Badge variant="outline" className={statusConfig.className}>
                          {statusConfig.label}
                        </Badge>
                      </div>
                      
                      <div className="flex items-center gap-3 mt-1">
                        <Badge variant="outline" className={precoConfig.className}>
                          {precoConfig.label}
                        </Badge>
                        <Badge variant="outline" className={dificuldadeConfig.className}>
                          {dificuldadeConfig.label}
                        </Badge>
                        {client.main_loss_reason && (
                          <span className="text-sm text-muted-foreground flex items-center gap-1">
                            <AlertCircle className="h-3.5 w-3.5" />
                            Principal: {client.main_loss_reason}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-6">
                    <div className="text-center">
                      <div className="flex items-center gap-1 text-red-600">
                        <FileX2 className="h-4 w-4" />
                        <span className="text-xl font-bold">{client.total_lost_quotes}</span>
                      </div>
                      <p className="text-xs text-muted-foreground">orçamentos</p>
                    </div>

                    <div className="text-center">
                      <div className="flex items-center gap-1 text-red-600">
                        <TrendingDown className="h-4 w-4" />
                        <span className="text-xl font-bold">{formatCurrency(client.total_lost_value)}</span>
                      </div>
                      <p className="text-xs text-muted-foreground">perdidos</p>
                    </div>

                    <Button variant="ghost" size="icon">
                      <ChevronRight className="h-5 w-5" />
                    </Button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
