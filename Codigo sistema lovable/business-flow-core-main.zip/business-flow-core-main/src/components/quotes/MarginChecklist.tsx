import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import {
  AlertTriangle,
  CheckCircle2,
  Loader2,
  DollarSign,
  Percent,
} from 'lucide-react';
import { formatCurrency } from '@/lib/utils';

interface QuoteItem {
  id: string;
  product_id: string | null;
  product_name: string;
  quantity: number;
  unit_price: number;
  subtotal: number;
  product?: {
    id: string;
    name: string;
    cost_price: number | null;
    category: string | null;
  };
}

interface ItemWithMargin extends QuoteItem {
  costPrice: number | null;
  margin: number | null;
  marginPercent: number | null;
  hasIssue: boolean;
  issueType: 'no_product' | 'no_cost' | 'low_margin' | null;
}

interface MarginChecklistProps {
  quoteId: string;
  open: boolean;
  onClose: () => void;
  onApprove: () => void;
  minMarginPercent?: number;
}

export function MarginChecklist({
  quoteId,
  open,
  onClose,
  onApprove,
  minMarginPercent = 15,
}: MarginChecklistProps) {
  const [items, setItems] = useState<ItemWithMargin[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [editingCosts, setEditingCosts] = useState<Record<string, string>>({});
  const [batchMargin, setBatchMargin] = useState('');
  const [applyBatchMargin, setApplyBatchMargin] = useState(false);

  const fetchItems = useCallback(async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('quote_items')
        .select(`
          id,
          product_id,
          product_name,
          quantity,
          unit_price,
          subtotal,
          product:products(id, name, cost_price, category)
        `)
        .eq('quote_id', quoteId);

      if (error) throw error;

      const itemsWithMargin: ItemWithMargin[] = (data || []).map((item) => {
        const costPrice = item.product?.cost_price ?? null;
        let margin: number | null = null;
        let marginPercent: number | null = null;
        let hasIssue = false;
        let issueType: ItemWithMargin['issueType'] = null;

        if (!item.product_id) {
          hasIssue = true;
          issueType = 'no_product';
        } else if (costPrice === null || costPrice <= 0) {
          hasIssue = true;
          issueType = 'no_cost';
        } else {
          margin = item.unit_price - costPrice;
          marginPercent = (margin / item.unit_price) * 100;
          
          if (marginPercent < minMarginPercent) {
            hasIssue = true;
            issueType = 'low_margin';
          }
        }

        return {
          ...item,
          product: item.product || undefined,
          costPrice,
          margin,
          marginPercent,
          hasIssue,
          issueType,
        };
      });

      setItems(itemsWithMargin);
    } catch (error) {
      console.error('Erro ao carregar itens:', error);
      toast.error('Erro ao carregar itens do orçamento');
    } finally {
      setLoading(false);
    }
  }, [quoteId, minMarginPercent]);

  useEffect(() => {
    if (open) {
      fetchItems();
    }
  }, [open, fetchItems]);

  const handleCostChange = (itemId: string, value: string) => {
    setEditingCosts((prev) => ({ ...prev, [itemId]: value }));
  };

  const handleSaveCost = async (item: ItemWithMargin) => {
    const newCostStr = editingCosts[item.id];
    if (!newCostStr) return;

    const newCost = parseFloat(newCostStr.replace(',', '.'));
    if (isNaN(newCost) || newCost < 0) {
      toast.error('Custo inválido');
      return;
    }

    setSaving(true);
    try {
      // Atualizar o custo no produto
      if (item.product_id) {
        await supabase
          .from('products')
          .update({ cost_price: newCost })
          .eq('id', item.product_id);
      }

      toast.success('Custo atualizado!');
      setEditingCosts((prev) => {
        const next = { ...prev };
        delete next[item.id];
        return next;
      });
      fetchItems();
    } catch (error) {
      console.error('Erro ao salvar custo:', error);
      toast.error('Erro ao salvar custo');
    } finally {
      setSaving(false);
    }
  };

  const handleApplyBatchMargin = async () => {
    const targetMargin = parseFloat(batchMargin.replace(',', '.'));
    if (isNaN(targetMargin) || targetMargin < 0 || targetMargin > 100) {
      toast.error('Margem inválida (0-100%)');
      return;
    }

    setSaving(true);
    try {
      // Para cada item sem custo, calcular o custo baseado na margem desejada
      // Margem% = (preço - custo) / preço * 100
      // custo = preço * (1 - margem% / 100)
      const itemsToUpdate = items.filter(
        (i) => i.product_id && (i.costPrice === null || i.costPrice <= 0)
      );

      for (const item of itemsToUpdate) {
        const newCost = item.unit_price * (1 - targetMargin / 100);
        
        await supabase
          .from('products')
          .update({ cost_price: newCost })
          .eq('id', item.product_id);
      }

      toast.success(`Custos calculados para ${itemsToUpdate.length} item(ns)`);
      fetchItems();
      setApplyBatchMargin(false);
      setBatchMargin('');
    } catch (error) {
      console.error('Erro ao aplicar margem em lote:', error);
      toast.error('Erro ao aplicar margem em lote');
    } finally {
      setSaving(false);
    }
  };

  const issuesCount = items.filter((i) => i.hasIssue).length;
  const canApprove = issuesCount === 0;

  const getIssueBadge = (item: ItemWithMargin) => {
    switch (item.issueType) {
      case 'no_product':
        return <Badge variant="destructive">Sem produto vinculado</Badge>;
      case 'no_cost':
        return <Badge variant="destructive">Sem custo</Badge>;
      case 'low_margin':
        return <Badge className="bg-amber-500">Margem baixa ({item.marginPercent?.toFixed(1)}%)</Badge>;
      default:
        return <Badge variant="secondary" className="bg-green-500/20 text-green-700">OK</Badge>;
    }
  };

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Percent size={20} />
            Checklist de Margens
          </DialogTitle>
          <DialogDescription>
            Valide as margens de todos os itens antes de gerar/finalizar o orçamento.
            Margem mínima: <strong>{minMarginPercent}%</strong>
          </DialogDescription>
        </DialogHeader>

        {loading ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : (
          <>
            {/* Resumo */}
            <div className="flex items-center gap-4 p-4 rounded-lg bg-muted/50">
              {issuesCount > 0 ? (
                <>
                  <AlertTriangle className="h-6 w-6 text-amber-500" />
                  <div>
                    <p className="font-medium text-amber-700 dark:text-amber-400">
                      {issuesCount} item(ns) com problemas
                    </p>
                    <p className="text-sm text-muted-foreground">
                      Resolva os problemas antes de continuar
                    </p>
                  </div>
                </>
              ) : (
                <>
                  <CheckCircle2 className="h-6 w-6 text-green-500" />
                  <div>
                    <p className="font-medium text-green-700 dark:text-green-400">
                      Todos os itens validados!
                    </p>
                    <p className="text-sm text-muted-foreground">
                      Pronto para gerar/enviar o orçamento
                    </p>
                  </div>
                </>
              )}
            </div>

            {/* Ação em lote */}
            <div className="flex items-center gap-4 p-4 border rounded-lg">
              <div className="flex items-center gap-2">
                <Checkbox
                  id="batch-margin"
                  checked={applyBatchMargin}
                  onCheckedChange={(v) => setApplyBatchMargin(!!v)}
                />
                <Label htmlFor="batch-margin" className="text-sm">
                  Aplicar margem padrão para itens sem custo:
                </Label>
              </div>
              <Input
                type="text"
                value={batchMargin}
                onChange={(e) => setBatchMargin(e.target.value)}
                placeholder="Ex: 18"
                className="w-24"
                disabled={!applyBatchMargin}
              />
              <span className="text-sm text-muted-foreground">%</span>
              <Button
                size="sm"
                variant="outline"
                onClick={handleApplyBatchMargin}
                disabled={!applyBatchMargin || !batchMargin || saving}
              >
                {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Aplicar'}
              </Button>
            </div>

            {/* Tabela de itens */}
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Produto</TableHead>
                  <TableHead className="text-right">Preço Venda</TableHead>
                  <TableHead className="text-right">Custo Unit.</TableHead>
                  <TableHead className="text-right">Margem</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {items.map((item) => (
                  <TableRow key={item.id} className={item.hasIssue ? 'bg-destructive/5' : ''}>
                    <TableCell>
                      <div>
                        <p className="font-medium">{item.product_name}</p>
                        {item.product?.category && (
                          <p className="text-xs text-muted-foreground">{item.product.category}</p>
                        )}
                      </div>
                    </TableCell>
                    <TableCell className="text-right font-mono">
                      {formatCurrency(item.unit_price)}
                    </TableCell>
                    <TableCell className="text-right">
                      {editingCosts[item.id] !== undefined ? (
                        <div className="flex items-center gap-1 justify-end">
                          <Input
                            type="text"
                            value={editingCosts[item.id]}
                            onChange={(e) => handleCostChange(item.id, e.target.value)}
                            className="w-24 h-8 text-right font-mono"
                            placeholder="0,00"
                          />
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => handleSaveCost(item)}
                            disabled={saving}
                          >
                            <CheckCircle2 size={14} />
                          </Button>
                        </div>
                      ) : (
                        <span className="font-mono">
                          {item.costPrice !== null ? formatCurrency(item.costPrice) : '—'}
                        </span>
                      )}
                    </TableCell>
                    <TableCell className="text-right">
                      {item.marginPercent !== null ? (
                        <span className={`font-mono ${item.marginPercent < minMarginPercent ? 'text-amber-600' : 'text-green-600'}`}>
                          {item.marginPercent.toFixed(1)}%
                        </span>
                      ) : (
                        '—'
                      )}
                    </TableCell>
                    <TableCell>{getIssueBadge(item)}</TableCell>
                    <TableCell className="text-right">
                      {item.product_id && item.issueType === 'no_cost' && editingCosts[item.id] === undefined && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleCostChange(item.id, '')}
                        >
                          <DollarSign size={14} className="mr-1" />
                          Definir custo
                        </Button>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </>
        )}

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={onClose}>
            Cancelar
          </Button>
          <Button onClick={onApprove} disabled={!canApprove || loading || saving}>
            {canApprove ? (
              <>
                <CheckCircle2 size={16} className="mr-2" />
                Aprovar e Continuar
              </>
            ) : (
              'Resolva os problemas primeiro'
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
