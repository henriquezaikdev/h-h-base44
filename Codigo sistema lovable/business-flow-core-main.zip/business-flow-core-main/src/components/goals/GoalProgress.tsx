interface GoalProgressProps {
  label: string;
  current: number;
  target: number;
  unit?: string;
  showPercentage?: boolean;
}

export function GoalProgress({ label, current, target, unit = '', showPercentage = true }: GoalProgressProps) {
  const percentage = target > 0 ? Math.min((current / target) * 100, 100) : 0;
  const isComplete = percentage >= 100;
  
  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between text-sm">
        <span className="text-muted-foreground">{label}</span>
        <span className="font-medium text-foreground">
          {unit === 'R$' ? `R$ ${current.toLocaleString('pt-BR')}` : current}
          {' / '}
          {unit === 'R$' ? `R$ ${target.toLocaleString('pt-BR')}` : target}
          {showPercentage && (
            <span className={`ml-2 ${isComplete ? 'text-status-active' : 'text-muted-foreground'}`}>
              ({percentage.toFixed(0)}%)
            </span>
          )}
        </span>
      </div>
      <div className="progress-bar">
        <div
          className={`progress-fill ${isComplete ? 'bg-status-active' : ''}`}
          style={{ width: `${percentage}%` }}
        />
      </div>
    </div>
  );
}
