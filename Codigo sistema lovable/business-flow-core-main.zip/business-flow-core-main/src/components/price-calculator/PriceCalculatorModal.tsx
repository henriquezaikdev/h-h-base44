import { useState, useMemo, useCallback } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Calculator, Copy, Eraser, ChevronDown, Sparkles, ClipboardPaste, Tag, AlertTriangle, ShieldCheck, TrendingUp, Info, Target } from 'lucide-react';
import { toast } from 'sonner';
import { usePriceCalculatorData, simulatePrice, getAdminDetails, type PriceBandInfo, type CommissionStatus } from '@/hooks/usePriceCalculatorData';

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  sellerId: string | null;
  isAdmin?: boolean;
}

function parseCurrency(value: string): number {
  if (!value) return 0;
  const cleaned = value.replace(/[^\d.,\-]/g, '').replace(',', '.');
  return parseFloat(cleaned) || 0;
}

function formatBRL(value: number): string {
  return value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

const STATUS_STYLES: Record<string, { bg: string; text: string }> = {
  prejuizo: { bg: 'bg-destructive/10', text: 'text-destructive' },
  muito_baixo: { bg: 'bg-orange-500/10', text: 'text-orange-600' },
  no_limite: { bg: 'bg-yellow-500/10', text: 'text-yellow-700 dark:text-yellow-500' },
  bom: { bg: 'bg-emerald-500/10', text: 'text-emerald-600' },
  otimo: { bg: 'bg-emerald-600/15', text: 'text-emerald-700 dark:text-emerald-400' },
};

const COMMISSION_COLORS: Record<CommissionStatus, { bg: string; text: string }> = {
  zerada: { bg: 'bg-destructive/10', text: 'text-destructive' },
  limitada: { bg: 'bg-orange-500/10', text: 'text-orange-600' },
  ativa: { bg: 'bg-emerald-500/10', text: 'text-emerald-600' },
  saudavel: { bg: 'bg-emerald-600/15', text: 'text-emerald-700 dark:text-emerald-400' },
};

type PriceZone = 'abaixo_piso' | 'no_piso' | 'entre_piso_seguranca' | 'seguranca' | 'entre_seguranca_saudavel' | 'saudavel' | 'acima_saudavel';

function classifyPriceZone(effectivePrice: number, minPrice: number, healthyPrice: number, idealPrice: number): PriceZone {
  if (effectivePrice < minPrice * 0.98) return 'abaixo_piso';
  if (effectivePrice < minPrice * 1.02) return 'no_piso';
  if (effectivePrice < healthyPrice * 0.98) return 'entre_piso_seguranca';
  if (effectivePrice < healthyPrice * 1.02) return 'seguranca';
  if (effectivePrice < idealPrice * 0.98) return 'entre_seguranca_saudavel';
  if (effectivePrice < idealPrice * 1.02) return 'saudavel';
  return 'acima_saudavel';
}

const ZONE_CONFIG: Record<PriceZone, { label: string; color: string; bg: string; border: string; icon: 'danger' | 'warning' | 'info' | 'success' }> = {
  abaixo_piso: { label: 'Abaixo do piso operacional', color: 'text-destructive', bg: 'bg-destructive/8', border: 'border-destructive/30', icon: 'danger' },
  no_piso: { label: 'No piso / no limite', color: 'text-orange-600', bg: 'bg-orange-500/8', border: 'border-orange-500/30', icon: 'warning' },
  entre_piso_seguranca: { label: 'Entre piso e segurança', color: 'text-orange-600', bg: 'bg-orange-500/8', border: 'border-orange-500/30', icon: 'warning' },
  seguranca: { label: 'Em faixa de segurança', color: 'text-yellow-700 dark:text-yellow-500', bg: 'bg-yellow-500/8', border: 'border-yellow-500/30', icon: 'info' },
  entre_seguranca_saudavel: { label: 'Entre segurança e saudável', color: 'text-emerald-600', bg: 'bg-emerald-500/8', border: 'border-emerald-500/30', icon: 'success' },
  saudavel: { label: 'Em faixa saudável', color: 'text-emerald-700 dark:text-emerald-400', bg: 'bg-emerald-600/10', border: 'border-emerald-600/40', icon: 'success' },
  acima_saudavel: { label: 'Acima da faixa saudável', color: 'text-emerald-700 dark:text-emerald-400', bg: 'bg-emerald-600/12', border: 'border-emerald-600/50', icon: 'success' },
};

function getActiveBandVariant(zone: PriceZone): PriceBandInfo['variant'] | null {
  if (zone === 'abaixo_piso' || zone === 'no_piso') return 'danger';
  if (zone === 'entre_piso_seguranca' || zone === 'seguranca') return 'warning';
  if (zone === 'entre_seguranca_saudavel' || zone === 'saudavel' || zone === 'acima_saudavel') return 'ideal';
  return null;
}

export function PriceCalculatorModal({ open, onOpenChange, sellerId, isAdmin }: Props) {
  const config = usePriceCalculatorData(sellerId);

  const [unitCost, setUnitCost] = useState('');
  const [quantity, setQuantity] = useState('1');
  const [unitPrice, setUnitPrice] = useState('');
  const [discountPct, setDiscountPct] = useState('');
  const [discountVal, setDiscountVal] = useState('');
  const [pasteText, setPasteText] = useState('');
  const [showPaste, setShowPaste] = useState(false);

  const costNum = parseCurrency(unitCost);
  const qtyNum = parseInt(quantity) || 1;
  const priceNum = parseCurrency(unitPrice);
  const discPct = parseFloat(discountPct) || 0;

  const simulation = useMemo(() => {
    if (costNum <= 0 || priceNum <= 0) return null;
    return simulatePrice(costNum, qtyNum, priceNum, discPct, config);
  }, [costNum, qtyNum, priceNum, discPct, config]);

  const bandsOnly = useMemo(() => {
    if (costNum <= 0) return null;
    return simulatePrice(costNum, 1, costNum * 2, 0, config);
  }, [costNum, config]);

  const adminDetails = useMemo(() => {
    if (!simulation || !isAdmin) return null;
    return getAdminDetails(simulation, config);
  }, [simulation, isAdmin, config]);

  const priceZone = useMemo(() => {
    if (!simulation) return null;
    return classifyPriceZone(simulation.effectiveUnitPrice, simulation.minPrice, simulation.healthyPrice, simulation.idealPrice);
  }, [simulation]);

  const activeBandVariant = priceZone ? getActiveBandVariant(priceZone) : null;

  const handleClear = useCallback(() => {
    setUnitCost('');
    setQuantity('1');
    setUnitPrice('');
    setDiscountPct('');
    setDiscountVal('');
    setPasteText('');
  }, []);

  const handleDiscountPctChange = (val: string) => {
    setDiscountPct(val);
    const pct = parseFloat(val) || 0;
    if (priceNum > 0 && qtyNum > 0) {
      setDiscountVal((priceNum * qtyNum * pct / 100).toFixed(2));
    }
  };

  const handleDiscountValChange = (val: string) => {
    setDiscountVal(val);
    const dv = parseCurrency(val);
    const total = priceNum * qtyNum;
    if (total > 0) {
      setDiscountPct(((dv / total) * 100).toFixed(1));
    }
  };

  const handlePaste = () => {
    const text = pasteText.toLowerCase().replace(/[=:]/g, ' ');
    const numbers = text.match(/[\d]+[.,]?\d*/g);
    if (numbers && numbers.length >= 2) {
      setUnitCost(numbers[0].replace(',', '.'));
      if (numbers.length >= 3) {
        setQuantity(parseInt(numbers[1]).toString());
        setUnitPrice(numbers[2].replace(',', '.'));
      } else {
        setUnitPrice(numbers[1].replace(',', '.'));
      }
      toast.success('Valores preenchidos!');
    } else {
      toast.error('Não foi possível interpretar os valores colados.');
    }
  };

  const handleUseRecommended = () => {
    if (simulation) {
      setUnitPrice(simulation.idealPrice.toFixed(2));
      setDiscountPct('');
      setDiscountVal('');
    }
  };

  const handleCopy = () => {
    if (!simulation) return;
    const text = [
      `Preço simulado: ${formatBRL(simulation.effectiveUnitPrice)}`,
      `Margem estimada: ${simulation.marginPercent.toFixed(1)}%`,
      `Status: ${simulation.statusLabel}`,
      `${simulation.commissionStatusLabel}`,
      `Piso operacional: ${formatBRL(simulation.minPrice)}`,
      `Faixa de segurança: ${formatBRL(simulation.healthyPrice)}`,
      `Faixa saudável: ${formatBRL(simulation.idealPrice)}`,
    ].join('\n');
    navigator.clipboard.writeText(text);
    toast.success('Resultado copiado!');
  };

  const priceRangesReady = costNum > 0;
  const displayBands = priceRangesReady ? (bandsOnly?.bands ?? []) : [];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[580px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-lg">
            <Calculator className="h-5 w-5 text-primary" />
            Calculadora Inteligente de Preço
          </DialogTitle>
          <DialogDescription className="text-[13px]">
            Simule o preço de venda e veja se ele está abaixo do piso operacional, em faixa de segurança ou em faixa saudável.
          </DialogDescription>
        </DialogHeader>

        {/* Block 1 — Quick Input */}
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="text-[12px] font-medium text-muted-foreground mb-1 block">Custo unitário (R$)</label>
            <Input type="text" inputMode="decimal" placeholder="0,00" value={unitCost} onChange={e => setUnitCost(e.target.value)} className="h-9 text-sm" />
          </div>
          <div>
            <label className="text-[12px] font-medium text-muted-foreground mb-1 block">Quantidade</label>
            <Input type="number" inputMode="numeric" placeholder="1" min={1} value={quantity} onChange={e => setQuantity(e.target.value)} className="h-9 text-sm" />
          </div>
          <div>
            <label className="text-[12px] font-medium text-muted-foreground mb-1 block">Preço de venda unit. (R$)</label>
            <Input type="text" inputMode="decimal" placeholder="0,00" value={unitPrice} onChange={e => setUnitPrice(e.target.value)} className="h-9 text-sm" />
          </div>
          {/* Discount area — clear layout */}
          <div>
            <label className="text-[12px] font-medium text-muted-foreground mb-1 block">Desconto</label>
            <div className="grid grid-cols-2 gap-1.5">
              <div className="relative">
                <Input type="text" inputMode="decimal" placeholder="0" value={discountPct} onChange={e => handleDiscountPctChange(e.target.value)} className="h-9 text-sm pr-7" />
                <span className="absolute right-2 top-1/2 -translate-y-1/2 text-[11px] font-medium text-muted-foreground pointer-events-none bg-muted/60 rounded px-1">%</span>
              </div>
              <div className="relative">
                <Input type="text" inputMode="decimal" placeholder="0,00" value={discountVal} onChange={e => handleDiscountValChange(e.target.value)} className="h-9 text-sm pr-8" />
                <span className="absolute right-2 top-1/2 -translate-y-1/2 text-[11px] font-medium text-muted-foreground pointer-events-none bg-muted/60 rounded px-1">R$</span>
              </div>
            </div>
          </div>
        </div>

        {/* Total */}
        {simulation && (
          <div className="flex items-center justify-between px-3 py-2 rounded-lg bg-muted/50 border">
            <span className="text-[12px] font-medium text-muted-foreground">Valor total da venda</span>
            <span className="text-sm font-semibold">{formatBRL(simulation.totalRevenue)}</span>
          </div>
        )}

        {/* Block 2 — Paste */}
        <Collapsible open={showPaste} onOpenChange={setShowPaste}>
          <CollapsibleTrigger asChild>
            <button className="flex items-center gap-1.5 text-[11px] text-muted-foreground hover:text-foreground transition-colors">
              <ClipboardPaste className="h-3.5 w-3.5" />
              Colar valores
              <ChevronDown className={`h-3 w-3 transition-transform ${showPaste ? 'rotate-180' : ''}`} />
            </button>
          </CollapsibleTrigger>
          <CollapsibleContent className="mt-2 space-y-2">
            <p className="text-[11px] text-muted-foreground">
              Cole informações rápidas de custo, quantidade e preço. O sistema tenta preencher os campos automaticamente.
            </p>
            <Textarea rows={2} placeholder="Ex: custo 127,80 quantidade 4 venda 189,90" value={pasteText} onChange={e => setPasteText(e.target.value)} className="text-[12px] min-h-[52px]" />
            <Button variant="outline" size="sm" onClick={handlePaste} disabled={!pasteText.trim()} className="text-[11px] h-7">
              Preencher campos
            </Button>
          </CollapsibleContent>
        </Collapsible>

        {/* ===== PRICE ZONE CLASSIFICATION (always visible when simulation exists) ===== */}
        {simulation && priceZone && (
          <div className={`rounded-lg border-2 px-3 py-2.5 flex items-center gap-2.5 ${ZONE_CONFIG[priceZone].bg} ${ZONE_CONFIG[priceZone].border}`}>
            <Target className={`h-4 w-4 shrink-0 ${ZONE_CONFIG[priceZone].color}`} />
            <div className="flex-1 min-w-0">
              <p className={`text-[13px] font-bold ${ZONE_CONFIG[priceZone].color}`}>
                {ZONE_CONFIG[priceZone].label}
              </p>
              <p className="text-[11px] text-muted-foreground">
                Preço efetivo: {formatBRL(simulation.effectiveUnitPrice)} · Margem: {simulation.marginPercent.toFixed(1)}%
              </p>
            </div>
            <div className="flex flex-col items-end gap-0.5">
              <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-[10px] font-semibold ${STATUS_STYLES[simulation.status]?.bg} ${STATUS_STYLES[simulation.status]?.text}`}>
                {simulation.statusLabel}
              </span>
              <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-[10px] font-semibold ${COMMISSION_COLORS[simulation.commissionStatus]?.bg} ${COMMISSION_COLORS[simulation.commissionStatus]?.text}`}>
                {simulation.commissionStatusLabel}
              </span>
            </div>
          </div>
        )}

        {/* Block 4 — Price Bands (with active highlight) */}
        {priceRangesReady && displayBands.length > 0 && (
          <div className="space-y-2 pt-1">
            <h4 className="text-[12px] font-semibold text-muted-foreground uppercase tracking-wider flex items-center gap-1.5">
              <Tag className="h-3.5 w-3.5" /> Faixas de Referência
            </h4>
            <div className="grid grid-cols-3 gap-2">
              {displayBands.map((band, i) => (
                <PriceBandCard key={i} band={band} isActive={activeBandVariant === band.variant && simulation !== null} />
              ))}
            </div>
            {/* Intermediate zone note */}
            {config.commissionEnabled && (
              <p className="text-[10px] text-muted-foreground italic leading-relaxed flex items-start gap-1.5 px-1">
                <Info className="h-3 w-3 mt-0.5 shrink-0" />
                Entre o piso operacional e a faixa saudável pode existir uma zona com comissão zerada ou muito limitada e resultado apertado. Evite ancorar sua negociação nessa região.
              </p>
            )}
          </div>
        )}

        {/* ===== RESUMO DA NEGOCIAÇÃO (always visible) ===== */}
        {simulation && priceZone && (
          <div className={`rounded-lg border-2 px-4 py-3 space-y-2 ${
            simulation.status === 'prejuizo' ? 'border-destructive/40 bg-destructive/5' :
            simulation.status === 'muito_baixo' ? 'border-orange-500/40 bg-orange-500/5' :
            simulation.status === 'no_limite' ? 'border-yellow-500/40 bg-yellow-500/5' :
            simulation.status === 'bom' ? 'border-emerald-500/30 bg-emerald-500/5' :
            'border-emerald-600/40 bg-emerald-600/8'
          }`}>
            <div className="flex items-center gap-2">
              <Sparkles className={`h-4 w-4 ${ZONE_CONFIG[priceZone].color}`} />
              <p className="text-[12px] font-bold uppercase tracking-wider text-foreground">Resumo da Negociação</p>
            </div>
            <p className="text-[13px] leading-relaxed font-medium">{simulation.negotiationSummary}</p>
            <div className="flex flex-wrap gap-1.5 pt-0.5">
              <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-[10px] font-semibold ${STATUS_STYLES[simulation.status]?.bg} ${STATUS_STYLES[simulation.status]?.text}`}>
                {simulation.statusLabel}
              </span>
              <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-[10px] font-semibold ${COMMISSION_COLORS[simulation.commissionStatus]?.bg} ${COMMISSION_COLORS[simulation.commissionStatus]?.text}`}>
                {simulation.commissionStatusLabel}
              </span>
              <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-[10px] font-semibold ${ZONE_CONFIG[priceZone].bg} ${ZONE_CONFIG[priceZone].color}`}>
                {ZONE_CONFIG[priceZone].label}
              </span>
            </div>
          </div>
        )}

        {/* ===== LEITURA DA SIMULAÇÃO (always visible, not collapsed) ===== */}
        {simulation && (
          <div className="rounded-lg border bg-muted/30 p-3 space-y-1.5">
            <div className="flex items-center gap-1.5 mb-1">
              <Info className="h-3.5 w-3.5 text-muted-foreground" />
              <p className="text-[11px] font-bold text-muted-foreground uppercase tracking-wider">Leitura da Simulação</p>
            </div>
            <div className="space-y-1 text-[11px]">
              <DetailRow label="Custo unitário" value={formatBRL(simulation.unitCost)} />
              <DetailRow label="Quantidade" value={String(simulation.quantity)} />
              <DetailRow label="Preço digitado" value={formatBRL(simulation.unitPrice)} />
              {simulation.discountPercent > 0 && (
                <>
                  <DetailRow label="Desconto %" value={`${simulation.discountPercent.toFixed(1)}%`} />
                  <DetailRow label="Desconto R$" value={formatBRL(simulation.discountValue)} />
                  <DetailRow label="Preço efetivo (c/ desc.)" value={formatBRL(simulation.effectiveUnitPrice)} />
                </>
              )}
              <hr className="border-border/50 my-1" />
              <DetailRow label="Receita total" value={formatBRL(simulation.totalRevenue)} />
              <DetailRow label="Custo total" value={formatBRL(simulation.totalCost)} />
              <DetailRow label="Impostos + logística" value={formatBRL(simulation.taxAndLogistics)} />
              <DetailRow label="Comissão estimada" value={formatBRL(simulation.commissionValue)} />
              <hr className="border-border/50 my-1" />
              <div className="flex justify-between font-bold text-foreground">
                <span>Margem estimada</span>
                <span>{simulation.marginPercent.toFixed(1)}%</span>
              </div>
              <div className="flex justify-between font-bold text-foreground">
                <span>Lucro estimado</span>
                <span>{formatBRL(simulation.estimatedProfit)}</span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium text-muted-foreground">Status comissão</span>
                <span className={`font-semibold ${COMMISSION_COLORS[simulation.commissionStatus]?.text}`}>
                  {simulation.commissionStatusLabel}
                </span>
              </div>
            </div>
          </div>
        )}

        {/* Admin details (collapsible, invisible to sellers) */}
        {isAdmin && simulation && adminDetails && (
          <Collapsible>
            <CollapsibleTrigger asChild>
              <button className="flex items-center gap-1.5 text-[11px] text-muted-foreground hover:text-foreground transition-colors mt-1">
                <Sparkles className="h-3.5 w-3.5" />
                Detalhes do cálculo
                <ChevronDown className="h-3 w-3" />
              </button>
            </CollapsibleTrigger>
            <CollapsibleContent className="mt-2 p-3 rounded-lg bg-muted/30 border space-y-1.5 text-[11px] text-muted-foreground">
              <DetailRow label="Impostos" value={`${(adminDetails.taxRate * 100).toFixed(0)}%`} />
              <DetailRow label="Logística" value={`${(adminDetails.logisticsRate * 100).toFixed(0)}%`} />
              <DetailRow label="Comissão ativa" value={adminDetails.commissionEnabled ? 'Sim' : 'Não'} />
              {adminDetails.commissionEnabled && (
                <DetailRow label="Faixa comissão" value={`${adminDetails.commissionBandUsed} (${adminDetails.commissionRateUsed}%)`} />
              )}
              <DetailRow label="Margem bruta" value={`${adminDetails.grossMarginBeforeDeductions.toFixed(1)}%`} />
              <DetailRow label="Margem líquida" value={`${adminDetails.netMarginAfterAll.toFixed(1)}%`} />
              <hr className="border-border/50" />
              <DetailRow label="Piso operacional" value={adminDetails.minPriceLogic} />
              <DetailRow label="Faixa de segurança" value={adminDetails.recommendedPriceLogic} />
              <DetailRow label="Faixa saudável" value={adminDetails.idealPriceLogic} />
            </CollapsibleContent>
          </Collapsible>
        )}

        {/* Block 6 — Actions */}
        <div className="flex items-center gap-2 pt-2 border-t">
          <Button variant="ghost" size="sm" onClick={handleClear} className="text-[12px] h-8">
            <Eraser className="h-3.5 w-3.5 mr-1" /> Limpar
          </Button>
          {simulation && (
            <>
              <Button variant="outline" size="sm" onClick={handleUseRecommended} className="text-[12px] h-8">
                Usar faixa saudável
              </Button>
              <Button variant="outline" size="sm" onClick={handleCopy} className="text-[12px] h-8">
                <Copy className="h-3.5 w-3.5 mr-1" /> Copiar resultado
              </Button>
            </>
          )}
          <div className="flex-1" />
          <Button variant="secondary" size="sm" onClick={() => onOpenChange(false)} className="text-[12px] h-8">
            Fechar
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function ResultCard({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border bg-muted/30 px-3 py-2 text-center">
      <p className="text-[10px] text-muted-foreground uppercase tracking-wide">{label}</p>
      <p className="text-sm font-semibold mt-0.5">{value}</p>
    </div>
  );
}

function PriceBandCard({ band, isActive }: { band: PriceBandInfo; isActive?: boolean }) {
  const variantStyles = {
    danger: 'border-destructive/40 bg-destructive/5',
    warning: 'border-yellow-500/30 bg-yellow-500/5',
    success: 'border-emerald-500/30 bg-emerald-500/5',
    ideal: 'border-emerald-600/40 bg-emerald-600/10',
  };

  const activeStyles = {
    danger: 'ring-2 ring-destructive/50 border-destructive/60 shadow-sm shadow-destructive/10',
    warning: 'ring-2 ring-yellow-500/50 border-yellow-500/60 shadow-sm shadow-yellow-500/10',
    success: 'ring-2 ring-emerald-500/50 border-emerald-500/60 shadow-sm shadow-emerald-500/10',
    ideal: 'ring-2 ring-emerald-600/50 border-emerald-600/60 shadow-sm shadow-emerald-600/10',
  };

  const iconMap = {
    danger: <AlertTriangle className="h-3.5 w-3.5 text-destructive" />,
    warning: <ShieldCheck className="h-3.5 w-3.5 text-yellow-600" />,
    success: <ShieldCheck className="h-3.5 w-3.5 text-emerald-600" />,
    ideal: <TrendingUp className="h-3.5 w-3.5 text-emerald-700 dark:text-emerald-400" />,
  };

  const commColors = COMMISSION_COLORS[band.commissionStatus];

  return (
    <div className={`relative rounded-lg border p-2.5 space-y-1.5 transition-all ${variantStyles[band.variant]} ${isActive ? activeStyles[band.variant] : ''}`}>
      {isActive && (
        <span className="absolute -top-2 left-2 bg-primary text-primary-foreground text-[8px] font-bold uppercase px-1.5 py-0.5 rounded-full tracking-wider">
          Preço atual
        </span>
      )}
      <div className="flex items-center gap-1.5">
        {iconMap[band.variant]}
        <p className="text-[10px] font-bold text-muted-foreground uppercase leading-none">{band.label}</p>
      </div>
      <p className="text-sm font-bold">{formatBRL(band.price)}</p>
      <p className="text-[10px] text-muted-foreground leading-tight">{band.description}</p>
      <div className="space-y-0.5">
        <span className={`inline-flex items-center rounded-full px-1.5 py-0.5 text-[9px] font-semibold ${commColors.bg} ${commColors.text}`}>
          {band.commissionLabel}
        </span>
        <p className="text-[9px] text-muted-foreground">{band.resultLabel}</p>
      </div>
    </div>
  );
}

function DetailRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between">
      <span className="font-medium text-muted-foreground">{label}</span>
      <span>{value}</span>
    </div>
  );
}
