import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { FileUp, Eye, CheckCircle2, Clock, XCircle, Upload } from 'lucide-react';
import { usePurchaseImports } from '@/hooks/useGestaoComprasData';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { ImportCompraWizard } from './ImportCompraWizard';
import { BulkXmlImportDialog } from './BulkXmlImportDialog';

const STATUS_DISPLAY: Record<string, { label: string; className: string; icon: any }> = {
  RASCUNHO: { label: 'Rascunho', className: 'text-muted-foreground border-muted', icon: Clock },
  EM_REVISAO: { label: 'Em Revisão', className: 'text-amber-600 border-amber-300', icon: Eye },
  CONFIRMADO: { label: 'Confirmado', className: 'text-emerald-600 border-emerald-300', icon: CheckCircle2 },
  CANCELADO: { label: 'Cancelado', className: 'text-destructive border-destructive/30', icon: XCircle },
};

export function ImportComprasTab() {
  const [showWizard, setShowWizard] = useState(false);
  const [showBulkXml, setShowBulkXml] = useState(false);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const { data: imports = [], isLoading } = usePurchaseImports();

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <h2 className="text-lg font-semibold">Importações de Compra</h2>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setShowBulkXml(true)} className="gap-2">
            <Upload className="h-4 w-4" /> Importar XMLs em Lote
          </Button>
          <Button onClick={() => { setSelectedId(null); setShowWizard(true); }} className="gap-2">
            <FileUp className="h-4 w-4" /> Importar Compra (PDF/XML/Imagem)
          </Button>
        </div>
      </div>

      {isLoading ? (
        <div className="flex justify-center py-16">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
        </div>
      ) : imports.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center text-muted-foreground">
            Nenhuma importação de compra. Clique em "Importar Compra" para começar.
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-2">
          {imports.map((imp: any) => {
            const display = STATUS_DISPLAY[imp.status] || STATUS_DISPLAY.RASCUNHO;
            const Icon = display.icon;
            return (
              <Card
                key={imp.id}
                className="cursor-pointer hover:border-primary/40 transition-colors"
                onClick={() => { setSelectedId(imp.id); setShowWizard(true); }}
              >
                <CardContent className="p-4">
                  <div className="flex items-center justify-between gap-3">
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-sm">{imp.fornecedor?.razao_social || imp.fornecedor?.nome_fantasia || 'Fornecedor'}</span>
                        {imp.reference_number && <span className="text-xs text-muted-foreground">Ref: {imp.reference_number}</span>}
                      </div>
                      <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
                        {imp.file_name && <span>{imp.file_name}</span>}
                        {imp.document_date && <span>{format(new Date(imp.document_date), 'dd/MM/yyyy', { locale: ptBR })}</span>}
                        <span>{format(new Date(imp.created_at), 'dd/MM HH:mm', { locale: ptBR })}</span>
                      </div>
                    </div>
                    <Badge variant="outline" className={`text-[10px] font-medium gap-1 ${display.className}`}>
                      <Icon className="h-3 w-3" /> {display.label}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {showWizard && (
        <ImportCompraWizard
          open={showWizard}
          onOpenChange={setShowWizard}
          importId={selectedId}
        />
      )}

      <BulkXmlImportDialog
        open={showBulkXml}
        onOpenChange={setShowBulkXml}
      />
    </div>
  );
}
