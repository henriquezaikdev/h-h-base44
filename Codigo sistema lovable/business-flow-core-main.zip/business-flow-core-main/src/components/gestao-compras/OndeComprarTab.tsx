import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Search, BarChart3, PackageSearch, Loader2, Plus } from 'lucide-react';
import { useOndeComprarData } from '@/hooks/useHistoricoPrecos';
import { formatCurrency } from '@/lib/utils';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { HistoricoPrecoDrawer } from './HistoricoPrecoDrawer';
import { RegistrarPrecoModal } from './RegistrarPrecoModal';

export function OndeComprarTab() {
  const [search, setSearch] = useState('');
  const [selectedPair, setSelectedPair] = useState<{
    productId: string;
    productName: string;
    fornecedorId?: string;
    fornecedorNome: string;
  } | null>(null);
  const [showRegistrar, setShowRegistrar] = useState(false);

  const { data: results = [], isLoading } = useOndeComprarData(search);

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between gap-3">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Buscar produto ou SKU..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="pl-9 focus:border-primary focus:ring-primary"
          />
        </div>
        <Button
          onClick={() => setShowRegistrar(true)}
          className="gap-2"
        >
          <Plus className="h-4 w-4" />
          Registrar Preço
        </Button>
      </div>

      {/* Content */}
      {isLoading ? (
        <div className="flex flex-col items-center justify-center py-16 gap-3">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <p className="text-sm text-muted-foreground">Buscando...</p>
        </div>
      ) : results.length === 0 ? (
        <Card>
          <CardContent className="py-16 text-center">
            <PackageSearch className="h-12 w-12 mx-auto text-muted-foreground/40 mb-3" />
            <p className="text-muted-foreground font-medium">
              {search
                ? 'Nenhum produto encontrado'
                : 'Base de preços vazia. Confirme compras ou registre preços manualmente.'}
            </p>
            {search && (
              <p className="text-sm text-muted-foreground mt-1">
                Tente outro termo de busca ou registre um preço manualmente.
              </p>
            )}
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-5">
          {results.map((item: any) => (
            <Card key={item.product.id}>
              <CardContent className="p-4">
                {/* Product header */}
                <div className="flex items-center gap-2 mb-3">
                  <h3 className="font-semibold text-sm text-foreground">{item.product.name}</h3>
                  {item.product.sku && (
                    <Badge variant="outline" className="text-[10px] font-mono">
                      {item.product.sku}
                    </Badge>
                  )}
                  <Badge variant="secondary" className="text-[10px]">
                    {item.fornecedores.length} fornecedor(es)
                  </Badge>
                </div>

                {item.fornecedores.length === 0 ? (
                  <p className="text-sm text-muted-foreground py-4 text-center">
                    Nenhum histórico de preço registrado para este produto
                  </p>
                ) : (
                  <div className="overflow-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="text-[11px] uppercase tracking-wider font-semibold">Fornecedor</TableHead>
                          <TableHead className="text-[11px] uppercase tracking-wider font-semibold text-right">Último Preço</TableHead>
                          <TableHead className="text-[11px] uppercase tracking-wider font-semibold text-right">Data Última Compra</TableHead>
                          <TableHead className="text-[11px] uppercase tracking-wider font-semibold text-right">Menor 90d</TableHead>
                          <TableHead className="text-[11px] uppercase tracking-wider font-semibold text-right">Maior 90d</TableHead>
                          <TableHead className="text-[11px] uppercase tracking-wider font-semibold text-right">Qtd Histórica</TableHead>
                          <TableHead className="text-[11px] uppercase tracking-wider font-semibold w-[100px]" />
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {item.fornecedores.map((f: any, idx: number) => {
                          const isBest = idx === 0 && item.fornecedores.length > 1;
                          return (
                            <TableRow key={f.fornecedor_id || f.fornecedor_nome} className="group">
                              <TableCell className="text-sm font-medium">
                                <div className="flex items-center gap-2">
                                  {f.fornecedor_nome}
                                  {isBest && (
                                    <Badge className="bg-emerald-500/10 text-emerald-700 border-emerald-500/20 text-[10px] h-5">
                                      Melhor Preço
                                    </Badge>
                                  )}
                                </div>
                              </TableCell>
                              <TableCell className="text-sm font-bold text-right font-mono">
                                {formatCurrency(f.ultimo_preco)}
                              </TableCell>
                              <TableCell className="text-sm text-right text-muted-foreground">
                                {f.data_ultima_compra
                                  ? format(new Date(f.data_ultima_compra + 'T00:00:00'), 'dd/MM/yyyy', { locale: ptBR })
                                  : '—'}
                              </TableCell>
                              <TableCell className="text-sm text-right text-muted-foreground font-mono">
                                {f.menor_preco_90d != null ? formatCurrency(f.menor_preco_90d) : '—'}
                              </TableCell>
                              <TableCell className="text-sm text-right text-muted-foreground font-mono">
                                {f.maior_preco_90d != null ? formatCurrency(f.maior_preco_90d) : '—'}
                              </TableCell>
                              <TableCell className="text-sm text-right text-muted-foreground">
                                {f.qtd_historica > 0 ? f.qtd_historica.toFixed(0) : '—'}
                              </TableCell>
                              <TableCell>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="gap-1.5 text-xs opacity-70 group-hover:opacity-100 hover:bg-accent"
                                  onClick={() =>
                                    setSelectedPair({
                                      productId: item.product.id,
                                      productName: item.product.name,
                                      fornecedorId: f.fornecedor_id,
                                      fornecedorNome: f.fornecedor_nome,
                                    })
                                  }
                                >
                                  <BarChart3 className="h-3.5 w-3.5" />
                                  Ver Histórico
                                </Button>
                              </TableCell>
                            </TableRow>
                          );
                        })}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Drawer: Price History Detail */}
      <HistoricoPrecoDrawer
        open={!!selectedPair}
        onClose={() => setSelectedPair(null)}
        productId={selectedPair?.productId}
        productName={selectedPair?.productName}
        fornecedorId={selectedPair?.fornecedorId}
        fornecedorNome={selectedPair?.fornecedorNome}
      />

      {/* Modal: Manual Price Entry */}
      <RegistrarPrecoModal
        open={showRegistrar}
        onClose={() => setShowRegistrar(false)}
      />
    </div>
  );
}
