import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Loader2, Plus, BarChart3, Building2, Send, Trash2 } from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { toast } from 'sonner';
import { CotacaoInputPanel } from './CotacaoInputPanel';
import { CotacaoReviewForm } from './CotacaoReviewForm';
import { CotacaoComparativo } from './CotacaoComparativo';
import { CotacaoVinculoBanner } from './CotacaoVinculoBanner';
import { SolicitacaoItensReferencia } from './SolicitacaoItensReferencia';

interface SupplierQuoteData {
  id: string;
  supplier_id: string | null;
  supplier_name: string;
  document_date: string | null;
  notes: string | null;
  created_at: string;
  lines: {
    id: string;
    raw_description: string;
    qty: number;
    unit: string | null;
    unit_price: number | null;
    total_price: number | null;
    product_id: string | null;
    payment_terms: string | null;
    delivery_days: number | null;
    is_winner: boolean;
    observations: string | null;
  }[];
}

interface SessionData {
  id: string;
  titulo: string;
  descricao: string | null;
  status: string;
  created_at: string;
  solicitacao_compra_id: string | null;
  origem: string | null;
}

interface CotacaoSessionDetailProps {
  sessionId: string;
  onBack: () => void;
  onNavigateToPainel?: () => void;
}

export function CotacaoSessionDetail({ sessionId, onBack, onNavigateToPainel }: CotacaoSessionDetailProps) {
  const [session, setSession] = useState<SessionData | null>(null);
  const [quotes, setQuotes] = useState<SupplierQuoteData[]>([]);
  const [loading, setLoading] = useState(true);
  const [showInput, setShowInput] = useState(false);
  const [reviewData, setReviewData] = useState<any>(null);
  const [showComparativo, setShowComparativo] = useState(false);
  const [initialLoadDone, setInitialLoadDone] = useState(false);

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      // Fetch session
      const { data: sessionData, error: sessionError } = await supabase
        .from('cotacao_sessoes' as any)
        .select('*')
        .eq('id', sessionId)
        .single();

      if (sessionError) throw sessionError;
      setSession(sessionData as any);

      // Fetch quotes with lines
      const { data: quotesData, error: quotesError } = await supabase
        .from('supplier_quotes')
        .select(`
          id, supplier_id, document_date, notes, created_at, status,
          fornecedores:supplier_id(razao_social, nome_fantasia),
          supplier_quote_lines(id, raw_description, qty, unit, unit_price, total_price, product_id, payment_terms, delivery_days, is_winner, observations)
        `)
        .eq('session_id', sessionId)
        .order('created_at', { ascending: true });

      if (quotesError) throw quotesError;

      setQuotes((quotesData || []).map((q: any) => ({
        id: q.id,
        supplier_id: q.supplier_id,
        supplier_name: q.fornecedores?.nome_fantasia || q.fornecedores?.razao_social || 'Fornecedor',
        document_date: q.document_date,
        notes: q.notes,
        created_at: q.created_at,
        lines: (q.supplier_quote_lines || []).sort((a: any, b: any) => (a.line_index || 0) - (b.line_index || 0)),
      })));
    } catch (error) {
      console.error('Error fetching session:', error);
      toast.error('Erro ao carregar sessão');
    } finally {
      setLoading(false);
      if (!initialLoadDone) {
        setInitialLoadDone(true);
      }
    }
  }, [sessionId]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  // Auto-show input panel only on first load when no quotes exist
  useEffect(() => {
    if (initialLoadDone && !loading && quotes.length === 0 && !reviewData) {
      setShowInput(true);
    }
  }, [initialLoadDone]); // eslint-disable-line react-hooks/exhaustive-deps

  const handleExtracted = (data: any) => {
    setReviewData(data);
    setShowInput(false);
  };

  const handleReviewSaved = () => {
    setReviewData(null);
    fetchData();
  };

  const handleDeleteQuote = async (quoteId: string) => {
    if (!confirm('Remover esta cotação de fornecedor?')) return;

    try {
      await supabase.from('supplier_quote_lines').delete().eq('supplier_quote_id', quoteId);
      await supabase.from('supplier_quotes').delete().eq('id', quoteId);
      toast.success('Cotação removida');
      fetchData();
    } catch (error) {
      toast.error('Erro ao remover');
    }
  };

  const handleSendToKanban = async () => {
    toast.info('Funcionalidade "Enviar para Painel do Comprador" será integrada ao fluxo de solicitação de compra.');
  };

  const handleReopenSession = async () => {
    if (!confirm('Deseja reabrir esta sessão de cotação?')) return;
    try {
      await supabase
        .from('cotacao_sessoes' as any)
        .update({ status: 'aberta' } as any)
        .eq('id', sessionId);
      toast.success('Sessão reaberta com sucesso');
      fetchData();
    } catch (error) {
      toast.error('Erro ao reabrir sessão');
    }
  };

  const formatCurrency = (v: number) =>
    new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(v);

  if (loading) {
    return (
      <div className="flex justify-center py-12">
        <Loader2 className="animate-spin h-8 w-8 text-primary" />
      </div>
    );
  }

  if (!session) {
    return (
      <div className="text-center py-12">
        <p>Sessão não encontrada</p>
        <Button variant="outline" onClick={onBack} className="mt-4">Voltar</Button>
      </div>
    );
  }

  const isClosed = session.status === 'fechada';

  // Show comparativo full screen
  if (showComparativo && quotes.length >= 1) {
    return (
      <div className="space-y-4">
        <Button variant="ghost" onClick={() => setShowComparativo(false)} className="gap-2">
          <ArrowLeft className="h-4 w-4" /> Voltar ao detalhe
        </Button>
        <CotacaoComparativo
          sessionId={sessionId}
          quotes={quotes}
          solicitacaoCompraId={session.solicitacao_compra_id}
          onClose={() => setShowComparativo(false)}
          onRefresh={() => {
            setShowComparativo(false);
            fetchData();
          }}
          onNavigateToPainel={onNavigateToPainel}
        />
      </div>
    );
  }

  const hasSolicitacaoVinculo = !!session.solicitacao_compra_id;

  return (
    <div className="space-y-4">
      {/* BLOCO 2: Banner de vínculo */}
      {hasSolicitacaoVinculo && (
        <CotacaoVinculoBanner solicitacaoCompraId={session.solicitacao_compra_id!} />
      )}

      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={onBack}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-semibold">{session.titulo}</h2>
              <Badge variant={isClosed ? 'outline' : 'secondary'}>
                {isClosed ? 'Fechada' : 'Aberta'}
              </Badge>
            </div>
            {session.descricao && (
              <p className="text-sm text-muted-foreground">{session.descricao}</p>
            )}
          </div>
        </div>

        <div className="flex gap-2">
          {!isClosed && (
            <>
              <Button variant="outline" onClick={() => { setShowInput(true); setReviewData(null); }}>
                <Plus className="h-4 w-4 mr-2" />
                Adicionar Fornecedor
              </Button>
              {quotes.length > 0 && (
                <Button
                  variant="outline"
                  onClick={() => {
                    const lastQuote = quotes[quotes.length - 1];
                    const reuseData = {
                      fornecedor_nome: '',
                      fornecedor_cnpj: null,
                      data_orcamento: null,
                      condicao_pagamento: null,
                      prazo_entrega_geral: null,
                      valor_frete: null,
                      observacoes_gerais: null,
                      itens: lastQuote.lines.map(l => ({
                        descricao: l.raw_description,
                        quantidade: l.qty,
                        unidade: l.unit || undefined,
                        preco_unitario: 0,
                        preco_total: 0,
                        prazo_entrega_dias: l.delivery_days || undefined,
                        observacoes: l.observations || undefined,
                        product_id: l.product_id || undefined,
                      })),
                    };
                    setShowInput(false);
                    setReviewData(reuseData);
                    toast.info(`${lastQuote.lines.length} itens copiados de "${lastQuote.supplier_name}" — preencha o novo fornecedor e preços`);
                  }}
                >
                  <ArrowLeft className="h-4 w-4 mr-2 rotate-180" />
                  Reaproveitar última cotação
                </Button>
              )}
            </>
          )}
          {quotes.length >= 1 && (
            <Button onClick={() => setShowComparativo(true)}>
              <BarChart3 className="h-4 w-4 mr-2" />
              Comparativo
            </Button>
          )}
          {isClosed && (
            <>
              <Button variant="outline" onClick={handleReopenSession}>
                <ArrowLeft className="h-4 w-4 mr-2" />
                Reabrir Cotação
              </Button>
              <Button variant="outline" onClick={handleSendToKanban}>
                <Send className="h-4 w-4 mr-2" />
                Enviar para Painel do Comprador
              </Button>
            </>
          )}
        </div>
      </div>

      {/* Two column layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left: Input / Review or Suppliers list */}
        <div className="lg:col-span-1 space-y-4">
          {showInput && !reviewData && (
            <CotacaoInputPanel
              sessionId={sessionId}
              onExtracted={handleExtracted}
            />
          )}

          {/* BLOCO 3: Itens da Solicitação (referência) */}
          {hasSolicitacaoVinculo && (
            <SolicitacaoItensReferencia solicitacaoCompraId={session.solicitacao_compra_id!} />
          )}

          {/* Suppliers list */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm text-muted-foreground">
                Fornecedores ({quotes.length})
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {quotes.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-4">
                  Nenhum fornecedor adicionado ainda
                </p>
              ) : (
                quotes.map(q => {
                  const total = q.lines.reduce((sum, l) => sum + (l.total_price || 0), 0);
                  const hasWinner = q.lines.some(l => l.is_winner);
                  return (
                    <div
                      key={q.id}
                      className={`p-3 rounded-lg border ${hasWinner ? 'border-green-300 bg-green-50/50 dark:bg-green-950/20' : ''}`}
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="flex items-center gap-2">
                            <Building2 className="h-4 w-4 text-muted-foreground" />
                            <span className="font-medium text-sm">{q.supplier_name}</span>
                            {hasWinner && (
                              <Badge variant="outline" className="bg-green-100 text-green-700 text-[10px]">
                                Ganhador
                              </Badge>
                            )}
                          </div>
                          <p className="text-xs text-muted-foreground mt-1">
                            {q.lines.length} itens · {formatCurrency(total)}
                          </p>
                        </div>
                        {!isClosed && (
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-6 w-6"
                            onClick={() => handleDeleteQuote(q.id)}
                          >
                            <Trash2 className="h-3 w-3 text-muted-foreground" />
                          </Button>
                        )}
                      </div>
                    </div>
                  );
                })
              )}
            </CardContent>
          </Card>
        </div>

        {/* Right: Review form or detail */}
        <div className="lg:col-span-2">
          {reviewData ? (
            <CotacaoReviewForm
              data={reviewData}
              sessionId={sessionId}
              onSaved={handleReviewSaved}
              onCancel={() => setReviewData(null)}
            />
          ) : quotes.length > 0 ? (
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm text-muted-foreground">
                  Detalhes dos Itens Cotados
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {quotes.map(q => (
                    <div key={q.id}>
                      <p className="font-medium text-sm mb-2 flex items-center gap-2">
                        <Building2 className="h-4 w-4" />
                        {q.supplier_name}
                        {q.document_date && (
                          <span className="text-muted-foreground text-xs">
                            — {format(new Date(q.document_date), 'dd/MM/yyyy', { locale: ptBR })}
                          </span>
                        )}
                      </p>
                      <div className="rounded border overflow-x-auto">
                        <table className="w-full text-sm">
                          <thead>
                            <tr className="bg-muted/30">
                              <th className="text-left p-2">Descrição</th>
                              <th className="text-center p-2 w-16">Qtd</th>
                              <th className="text-right p-2 w-28">Preço Unit.</th>
                              <th className="text-right p-2 w-28">Total</th>
                              <th className="text-center p-2 w-20">Prazo</th>
                            </tr>
                          </thead>
                          <tbody>
                            {q.lines.map(line => (
                              <tr key={line.id} className={`border-t ${line.is_winner ? 'bg-green-50 dark:bg-green-950/20' : ''}`}>
                                <td className="p-2">{line.raw_description}</td>
                                <td className="text-center p-2">{line.qty} {line.unit}</td>
                                <td className="text-right p-2 font-mono">
                                  {line.unit_price !== null ? formatCurrency(line.unit_price) : '—'}
                                </td>
                                <td className="text-right p-2 font-mono font-semibold">
                                  {line.total_price !== null ? formatCurrency(line.total_price) : '—'}
                                </td>
                                <td className="text-center p-2 text-muted-foreground">
                                  {line.delivery_days ? `${line.delivery_days}d` : '—'}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                          <tfoot>
                            <tr className="border-t bg-muted/20">
                              <td colSpan={3} className="p-2 font-semibold text-right">Total:</td>
                              <td className="p-2 text-right font-mono font-bold">
                                {formatCurrency(q.lines.reduce((s, l) => s + (l.total_price || 0), 0))}
                              </td>
                              <td />
                            </tr>
                          </tfoot>
                        </table>
                      </div>
                      {q.notes && (
                        <p className="text-xs text-muted-foreground mt-1 italic">Obs: {q.notes}</p>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardContent className="py-12 text-center">
                <Building2 className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium mb-2">Adicione a primeira resposta</h3>
                <p className="text-muted-foreground text-sm">
                  Cole o texto do WhatsApp ou faça upload do PDF/imagem do fornecedor
                </p>
                {!showInput && (
                  <Button onClick={() => { setShowInput(true); setReviewData(null); }} className="mt-4">
                    <Plus className="h-4 w-4 mr-2" />
                    Adicionar Fornecedor
                  </Button>
                )}
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
