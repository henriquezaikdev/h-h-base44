import { useState, useEffect, useRef } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Loader2 } from 'lucide-react';
import { useProductSearch, useFornecedorSearch, useRegistrarPreco } from '@/hooks/useHistoricoPrecos';
import { format } from 'date-fns';

interface RegistrarPrecoModalProps {
  open: boolean;
  onClose: () => void;
}

export function RegistrarPrecoModal({ open, onClose }: RegistrarPrecoModalProps) {
  const [produtoSearch, setProdutoSearch] = useState('');
  const [fornecedorSearch, setFornecedorSearch] = useState('');
  const [selectedProduct, setSelectedProduct] = useState<{ id: string; name: string } | null>(null);
  const [selectedFornecedor, setSelectedFornecedor] = useState<{ id: string; nome: string } | null>(null);
  const [preco, setPreco] = useState('');
  const [quantidade, setQuantidade] = useState('');
  const [dataCompra, setDataCompra] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [observacao, setObservacao] = useState('');
  const [showProductDropdown, setShowProductDropdown] = useState(false);
  const [showFornecedorDropdown, setShowFornecedorDropdown] = useState(false);

  const { data: products = [] } = useProductSearch(produtoSearch);
  const { data: fornecedores = [] } = useFornecedorSearch(fornecedorSearch);
  const mutation = useRegistrarPreco();

  const productRef = useRef<HTMLDivElement>(null);
  const fornecedorRef = useRef<HTMLDivElement>(null);

  // Reset on close
  useEffect(() => {
    if (!open) {
      setProdutoSearch('');
      setFornecedorSearch('');
      setSelectedProduct(null);
      setSelectedFornecedor(null);
      setPreco('');
      setQuantidade('');
      setDataCompra(format(new Date(), 'yyyy-MM-dd'));
      setObservacao('');
    }
  }, [open]);

  const canSave = selectedProduct && selectedFornecedor && preco && parseFloat(preco) > 0 && dataCompra;

  const handleSave = () => {
    if (!canSave) return;
    mutation.mutate(
      {
        product_id: selectedProduct!.id,
        fornecedor_nome: selectedFornecedor!.nome,
        fornecedor_id: selectedFornecedor!.id,
        preco_unitario: parseFloat(preco.replace(',', '.')),
        quantidade: quantidade ? parseFloat(quantidade.replace(',', '.')) : undefined,
        data_compra: dataCompra,
        observacao: observacao.trim() || undefined,
      },
      {
        onSuccess: () => onClose(),
      }
    );
  };

  return (
    <Dialog open={open} onOpenChange={v => !v && onClose()}>
      <DialogContent className="sm:max-w-[460px]">
        <DialogHeader>
          <DialogTitle>Registrar Preço</DialogTitle>
        </DialogHeader>

        <div className="grid gap-4 py-2">
          {/* Produto */}
          <div className="grid gap-1.5" ref={productRef}>
            <Label>Produto *</Label>
            {selectedProduct ? (
              <div className="flex items-center gap-2 p-2 rounded-md bg-muted text-sm">
                <span className="flex-1 font-medium">{selectedProduct.name}</span>
                <Button variant="ghost" size="sm" className="h-6 px-2 text-xs" onClick={() => { setSelectedProduct(null); setProdutoSearch(''); }}>
                  Trocar
                </Button>
              </div>
            ) : (
              <div className="relative">
                <Input
                  placeholder="Buscar produto..."
                  value={produtoSearch}
                  onChange={e => { setProdutoSearch(e.target.value); setShowProductDropdown(true); }}
                  onFocus={() => setShowProductDropdown(true)}
                  onBlur={() => setTimeout(() => setShowProductDropdown(false), 200)}
                />
                {showProductDropdown && produtoSearch.length >= 2 && (
                  <div className="absolute z-50 top-full mt-1 w-full bg-background border rounded-md shadow-lg max-h-48 overflow-auto">
                    {products.length === 0 ? (
                      <p className="p-3 text-sm text-muted-foreground text-center">Nenhum produto encontrado</p>
                    ) : (
                      products.map((p: any) => (
                        <button
                          key={p.id}
                          className="w-full text-left px-3 py-2 text-sm hover:bg-accent transition-colors"
                          onMouseDown={() => { setSelectedProduct({ id: p.id, name: p.name }); setProdutoSearch(''); setShowProductDropdown(false); }}
                        >
                          <span className="font-medium">{p.name}</span>
                          {p.sku && <span className="ml-2 text-muted-foreground text-xs font-mono">{p.sku}</span>}
                        </button>
                      ))
                    )}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Fornecedor */}
          <div className="grid gap-1.5" ref={fornecedorRef}>
            <Label>Fornecedor *</Label>
            {selectedFornecedor ? (
              <div className="flex items-center gap-2 p-2 rounded-md bg-muted text-sm">
                <span className="flex-1 font-medium">{selectedFornecedor.nome}</span>
                <Button variant="ghost" size="sm" className="h-6 px-2 text-xs" onClick={() => { setSelectedFornecedor(null); setFornecedorSearch(''); }}>
                  Trocar
                </Button>
              </div>
            ) : (
              <div className="relative">
                <Input
                  placeholder="Buscar fornecedor..."
                  value={fornecedorSearch}
                  onChange={e => { setFornecedorSearch(e.target.value); setShowFornecedorDropdown(true); }}
                  onFocus={() => setShowFornecedorDropdown(true)}
                  onBlur={() => setTimeout(() => setShowFornecedorDropdown(false), 200)}
                />
                {showFornecedorDropdown && fornecedorSearch.length >= 2 && (
                  <div className="absolute z-50 top-full mt-1 w-full bg-background border rounded-md shadow-lg max-h-48 overflow-auto">
                    {fornecedores.length === 0 ? (
                      <p className="p-3 text-sm text-muted-foreground text-center">Nenhum fornecedor encontrado</p>
                    ) : (
                      fornecedores.map((f: any) => (
                        <button
                          key={f.id}
                          className="w-full text-left px-3 py-2 text-sm hover:bg-accent transition-colors"
                          onMouseDown={() => { setSelectedFornecedor({ id: f.id, nome: f.razao_social || f.nome_fantasia }); setFornecedorSearch(''); setShowFornecedorDropdown(false); }}
                        >
                          {f.razao_social || f.nome_fantasia}
                          {f.cnpj && <span className="ml-2 text-muted-foreground text-xs">{f.cnpj}</span>}
                        </button>
                      ))
                    )}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Price + Qty row */}
          <div className="grid grid-cols-2 gap-3">
            <div className="grid gap-1.5">
              <Label>Preço Unitário (R$) *</Label>
              <Input
                placeholder="0,00"
                value={preco}
                onChange={e => setPreco(e.target.value)}
              />
            </div>
            <div className="grid gap-1.5">
              <Label>Quantidade</Label>
              <Input
                placeholder="Ex: 10"
                value={quantidade}
                onChange={e => setQuantidade(e.target.value)}
              />
            </div>
          </div>

          {/* Date */}
          <div className="grid gap-1.5">
            <Label>Data da Compra *</Label>
            <Input
              type="date"
              value={dataCompra}
              onChange={e => setDataCompra(e.target.value)}
            />
          </div>

          {/* Observação */}
          <div className="grid gap-1.5">
            <Label>Observação</Label>
            <Textarea
              placeholder="Informações adicionais..."
              value={observacao}
              onChange={e => setObservacao(e.target.value)}
              rows={2}
            />
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={onClose}>
            Cancelar
          </Button>
          <Button onClick={handleSave} disabled={!canSave || mutation.isPending}>
            {mutation.isPending ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                Salvando...
              </>
            ) : (
              'Salvar'
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
