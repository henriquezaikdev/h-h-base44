import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { FileText, Plus, Upload, CheckCircle2, Clock, Trash2, Loader2 } from 'lucide-react';
import { useFornecedores } from '@/hooks/useComprasData';
import { useSupplierQuotes, useCreateSupplierQuote, useSupplierQuoteLines, useAddSupplierQuoteLine, useConfirmSupplierQuote } from '@/hooks/useGestaoComprasData';
import { supabase } from '@/integrations/supabase/client';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { formatCurrency } from '@/lib/utils';
import { toast } from 'sonner';

export function ImportOrcamentosTab() {
  const [showNew, setShowNew] = useState(false);
  const [selectedQuote, setSelectedQuote] = useState<any>(null);
  const { data: quotes = [], isLoading } = useSupplierQuotes();

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold">Orçamentos de Fornecedor</h2>
        <Button onClick={() => setShowNew(true)} className="gap-2">
          <FileText className="h-4 w-4" /> Importar Orçamento
        </Button>
      </div>

      {isLoading ? (
        <div className="flex justify-center py-16">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
        </div>
      ) : quotes.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center text-muted-foreground">
            Nenhum orçamento. Importe um para comparar preços.
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-2">
          {quotes.map((q: any) => (
            <Card key={q.id} className="cursor-pointer hover:border-primary/40 transition-colors" onClick={() => setSelectedQuote(q)}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <p className="font-semibold text-sm">{q.fornecedor?.razao_social || 'Fornecedor'}</p>
                    <p className="text-xs text-muted-foreground">
                      {q.reference_number && `Ref: ${q.reference_number} • `}
                      {q.document_date && format(new Date(q.document_date), 'dd/MM/yyyy', { locale: ptBR })}
                      {!q.document_date && format(new Date(q.created_at), 'dd/MM/yyyy', { locale: ptBR })}
                    </p>
                  </div>
                  <Badge variant="outline" className={`text-[10px] gap-1 ${q.status === 'CONFIRMADO' ? 'text-emerald-600 border-emerald-300' : 'text-muted-foreground border-muted'}`}>
                    {q.status === 'CONFIRMADO' ? <CheckCircle2 className="h-3 w-3" /> : <Clock className="h-3 w-3" />}
                    {q.status}
                  </Badge>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <NewQuoteDialog open={showNew} onOpenChange={setShowNew} />

      {selectedQuote && (
        <QuoteDetailSheet
          quote={selectedQuote}
          open={!!selectedQuote}
          onOpenChange={v => !v && setSelectedQuote(null)}
        />
      )}
    </div>
  );
}

function NewQuoteDialog({ open, onOpenChange }: { open: boolean; onOpenChange: (v: boolean) => void }) {
  const [supplierId, setSupplierId] = useState('');
  const [docDate, setDocDate] = useState('');
  const [refNumber, setRefNumber] = useState('');
  const [notes, setNotes] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [extracting, setExtracting] = useState(false);
  const { data: fornecedores = [] } = useFornecedores();
  const createQuote = useCreateSupplierQuote();
  const addLine = useAddSupplierQuoteLine();

  const handleSubmit = async () => {
    if (!supplierId) { toast.error('Selecione o fornecedor'); return; }

    let fileUrl = '';
    let fileName = '';
    let docKind = 'PDF';

    if (file) {
      fileName = file.name;
      docKind = file.type.startsWith('image/') ? 'IMAGE' : 'PDF';
      const path = `quotes/${Date.now()}_${file.name}`;
      const { error: uploadErr } = await supabase.storage.from('compras-docs').upload(path, file);
      if (uploadErr) { toast.error('Erro no upload: ' + uploadErr.message); return; }
      const { data: urlData } = supabase.storage.from('compras-docs').getPublicUrl(path);
      fileUrl = urlData.publicUrl;
    }

    const result = await createQuote.mutateAsync({
      supplier_id: supplierId,
      document_kind: docKind,
      file_url: fileUrl || null,
      file_name: fileName || null,
      document_date: docDate || null,
      reference_number: refNumber || null,
      notes: notes || null,
    });

    // Try extraction
    if (file && result) {
      setExtracting(true);
      try {
        const reader = new FileReader();
        const base64 = await new Promise<string>((resolve) => {
          reader.onload = () => resolve((reader.result as string).split(',')[1]);
          reader.readAsDataURL(file);
        });

        const { data: fnData } = await supabase.functions.invoke('extract-purchase-doc', {
          body: { fileBase64: base64, fileName: file.name, mimeType: file.type },
        });

        if (fnData?.success && fnData?.data?.items) {
          for (let i = 0; i < fnData.data.items.length; i++) {
            const item = fnData.data.items[i];
            await addLine.mutateAsync({
              supplier_quote_id: (result as any).id,
              line_index: i,
              raw_description: item.description || 'Sem descrição',
              qty: item.qty || 1,
              unit: item.unit || null,
              unit_price: item.unit_price || null,
              total_price: item.total_price || null,
            });
          }
          toast.success(`${fnData.data.items.length} itens extraídos!`);
        }
      } catch (err) {
        toast.info('Extração automática indisponível.');
      } finally {
        setExtracting(false);
      }
    }

    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Importar Orçamento</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Label>Documento (PDF ou Imagem)</Label>
            <div className="mt-1.5 border-2 border-dashed rounded-lg p-4 text-center">
              <input type="file" accept=".pdf,image/png,image/jpeg" onChange={e => setFile(e.target.files?.[0] || null)} className="hidden" id="quote-file" />
              <label htmlFor="quote-file" className="cursor-pointer">
                <Upload className="h-6 w-6 mx-auto text-muted-foreground mb-1" />
                <p className="text-xs text-muted-foreground">{file ? file.name : 'Selecionar arquivo'}</p>
              </label>
            </div>
          </div>
          <div>
            <Label>Fornecedor</Label>
            <Select value={supplierId} onValueChange={setSupplierId}>
              <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
              <SelectContent>
                {fornecedores.map((f: any) => (
                  <SelectItem key={f.id} value={f.id}>{f.razao_social || f.nome_fantasia}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div><Label>Data</Label><Input type="date" value={docDate} onChange={e => setDocDate(e.target.value)} /></div>
            <div><Label>Referência</Label><Input value={refNumber} onChange={e => setRefNumber(e.target.value)} /></div>
          </div>
          <div><Label>Notas</Label><Textarea value={notes} onChange={e => setNotes(e.target.value)} rows={2} /></div>
          <Button onClick={handleSubmit} disabled={!supplierId || createQuote.isPending || extracting} className="w-full gap-2">
            {extracting ? <><Loader2 className="h-4 w-4 animate-spin" /> Extraindo...</> : 'Salvar Orçamento'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function QuoteDetailSheet({ quote, open, onOpenChange }: { quote: any; open: boolean; onOpenChange: (v: boolean) => void }) {
  const { data: lines = [] } = useSupplierQuoteLines(quote.id);
  const confirmQuote = useConfirmSupplierQuote();
  const addLine = useAddSupplierQuoteLine();
  const [desc, setDesc] = useState('');
  const [qty, setQty] = useState('1');
  const [price, setPrice] = useState('');

  const total = lines.reduce((s: number, l: any) => s + (l.total_price || (l.qty * (l.unit_price || 0)) || 0), 0);

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="sm:max-w-[500px]">
        <SheetHeader>
          <SheetTitle className="text-sm">{quote.fornecedor?.razao_social} — Orçamento</SheetTitle>
        </SheetHeader>

        <div className="mt-4 space-y-3">
          <div className="flex items-center justify-between">
            <Badge variant="outline" className="text-xs">{quote.status}</Badge>
            <span className="text-sm font-bold">Total: {formatCurrency(total)}</span>
          </div>

          <div className="space-y-2 max-h-[400px] overflow-y-auto">
            {lines.map((l: any) => (
              <div key={l.id} className="p-2.5 rounded-md bg-muted/40 text-sm">
                <p className="font-medium">{l.raw_description}</p>
                <p className="text-xs text-muted-foreground">
                  Qtd: {l.qty} {l.unit || ''} {l.unit_price ? `• ${formatCurrency(l.unit_price)}` : ''} {l.total_price ? `• Total: ${formatCurrency(l.total_price)}` : ''}
                </p>
              </div>
            ))}
          </div>

          {quote.status === 'RASCUNHO' && (
            <>
              <div className="grid grid-cols-[1fr_60px_80px_auto] gap-2 items-end">
                <Input placeholder="Descrição" value={desc} onChange={e => setDesc(e.target.value)} className="text-sm" />
                <Input type="number" placeholder="Qtd" value={qty} onChange={e => setQty(e.target.value)} className="text-sm" />
                <Input type="number" placeholder="Preço" value={price} onChange={e => setPrice(e.target.value)} className="text-sm" />
                <Button size="sm" onClick={async () => {
                  if (!desc.trim()) return;
                  await addLine.mutateAsync({
                    supplier_quote_id: quote.id,
                    line_index: lines.length,
                    raw_description: desc.trim(),
                    qty: Number(qty) || 1,
                    unit_price: Number(price) || null,
                    total_price: (Number(qty) || 1) * (Number(price) || 0) || null,
                  });
                  setDesc(''); setQty('1'); setPrice('');
                }}><Plus className="h-4 w-4" /></Button>
              </div>

              <Button className="w-full gap-2" onClick={() => confirmQuote.mutateAsync(quote.id)} disabled={confirmQuote.isPending}>
                <CheckCircle2 className="h-4 w-4" /> Confirmar Orçamento
              </Button>
            </>
          )}
        </div>
      </SheetContent>
    </Sheet>
  );
}
