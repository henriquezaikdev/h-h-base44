import { useState } from 'react';
import { Link2, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { ComprasDetailSheet } from '@/components/compras/ComprasDetailSheet';

interface CotacaoVinculoBannerProps {
  solicitacaoCompraId: string;
}

export function CotacaoVinculoBanner({ solicitacaoCompraId }: CotacaoVinculoBannerProps) {
  const [showSheet, setShowSheet] = useState(false);

  const { data: solicitacao } = useQuery({
    queryKey: ['solicitacao_vinculo', solicitacaoCompraId],
    enabled: !!solicitacaoCompraId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from('solicitacoes_compra')
        .select('id, titulo, solicitante:sellers!solicitacoes_compra_solicitante_id_fkey(id, name)')
        .eq('id', solicitacaoCompraId)
        .single();
      if (error) throw error;
      return data;
    },
  });

  if (!solicitacao) return null;

  return (
    <>
      <div
        className="flex items-center justify-between gap-3 px-4 py-3 rounded-lg border"
        style={{
          backgroundColor: '#EEF2FF',
          borderColor: '#C7D2FE',
        }}
      >
        <div className="flex items-center gap-2 min-w-0">
          <Link2 className="h-4 w-4 shrink-0" style={{ color: '#3B5BDB' }} />
          <p className="text-sm truncate" style={{ color: '#3730A3' }}>
            Cotação vinculada à solicitação: <strong>{solicitacao.titulo}</strong>
            {(solicitacao as any).solicitante?.name && (
              <> — Solicitante: <strong>{(solicitacao as any).solicitante.name}</strong></>
            )}
          </p>
        </div>
        <Button
          variant="outline"
          size="sm"
          className="shrink-0 gap-1.5 text-xs"
          style={{ borderColor: '#A5B4FC', color: '#3B5BDB' }}
          onClick={() => setShowSheet(true)}
        >
          <ExternalLink className="h-3.5 w-3.5" />
          Ver Solicitação
        </Button>
      </div>

      {showSheet && (
        <ComprasDetailSheet
          open={showSheet}
          onOpenChange={setShowSheet}
          solicitacaoId={solicitacaoCompraId}
          initialTab="detalhes"
        />
      )}
    </>
  );
}
