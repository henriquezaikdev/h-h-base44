import { useState, useRef } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Upload, FileText, CheckCircle2, AlertTriangle, Loader2, X } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useFornecedores, useSaveFornecedor } from '@/hooks/useComprasData';
import { useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { formatCurrency } from '@/lib/utils';

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
}

type FileStatus = 'aguardando' | 'processando' | 'importado' | 'erro';

interface XmlFileEntry {
  file: File;
  status: FileStatus;
  supplierName: string;
  totalValue: number;
  docNumber: string;
  error?: string;
}

const STATUS_CONFIG: Record<FileStatus, { label: string; className: string; icon: any }> = {
  aguardando: { label: 'Aguardando', className: 'text-muted-foreground border-muted', icon: FileText },
  processando: { label: 'Processando', className: 'text-primary border-primary/30', icon: Loader2 },
  importado: { label: 'Importado', className: 'text-emerald-600 border-emerald-300', icon: CheckCircle2 },
  erro: { label: 'Erro', className: 'text-destructive border-destructive/30', icon: AlertTriangle },
};

function parseNFeXml(xmlText: string) {
  const parser = new DOMParser();
  const doc = parser.parseFromString(xmlText, 'text/xml');

  const getText = (parent: Document | Element, tag: string) => {
    const el = parent.getElementsByTagName(tag)[0];
    return el?.textContent?.trim() || '';
  };

  const emit = doc.getElementsByTagName('emit')[0];
  const ide = doc.getElementsByTagName('ide')[0];

  const supplierName = emit ? getText(emit, 'xNome') : '';
  const supplierCnpj = emit ? getText(emit, 'CNPJ') : '';
  const docDate = ide ? getText(ide, 'dhEmi') : '';
  const docNumber = ide ? getText(ide, 'nNF') : '';

  let formattedDate = '';
  if (docDate) {
    try { formattedDate = docDate.substring(0, 10); } catch { formattedDate = docDate; }
  }

  const detNodes = doc.getElementsByTagName('det');
  const items: any[] = [];
  for (let i = 0; i < detNodes.length; i++) {
    const prod = detNodes[i].getElementsByTagName('prod')[0];
    if (!prod) continue;
    items.push({
      description: getText(prod, 'xProd'),
      code: getText(prod, 'cProd'),
      qty: parseFloat(getText(prod, 'qCom')) || 1,
      unit: getText(prod, 'uCom') || 'UN',
      unit_price: parseFloat(getText(prod, 'vUnCom')) || 0,
      total_price: parseFloat(getText(prod, 'vProd')) || 0,
    });
  }

  return { supplierName, supplierCnpj, docDate: formattedDate, docNumber, items };
}

export function BulkXmlImportDialog({ open, onOpenChange }: Props) {
  const [entries, setEntries] = useState<XmlFileEntry[]>([]);
  const [processing, setProcessing] = useState(false);
  const [processed, setProcessed] = useState(0);
  const [summary, setSummary] = useState<{ success: number; errors: number } | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const queryClient = useQueryClient();

  const { data: fornecedores = [] } = useFornecedores();
  const saveFornecedor = useSaveFornecedor();

  const handleFilesSelected = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    const xmlFiles = files.filter(f => f.name.toLowerCase().endsWith('.xml'));
    if (xmlFiles.length === 0) {
      toast.error('Selecione ao menos um arquivo XML');
      return;
    }

    const newEntries: XmlFileEntry[] = [];
    for (const file of xmlFiles) {
      try {
        const text = await file.text();
        const parsed = parseNFeXml(text);
        const totalValue = parsed.items.reduce((acc, it) => acc + (it.total_price || 0), 0);
        newEntries.push({
          file,
          status: 'aguardando',
          supplierName: parsed.supplierName || 'Fornecedor não identificado',
          totalValue,
          docNumber: parsed.docNumber,
        });
      } catch {
        newEntries.push({
          file,
          status: 'erro',
          supplierName: '-',
          totalValue: 0,
          docNumber: '-',
          error: 'Erro ao ler XML',
        });
      }
    }

    setEntries(newEntries);
    setSummary(null);
    setProcessed(0);
  };

  const findOrCreateSupplier = async (supplierName: string): Promise<string | null> => {
    const searchNorm = supplierName.trim().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');

    // Refresh fornecedores list
    const latestFornecedores = (fornecedores as any[]).length > 0 ? fornecedores : [];

    for (const f of latestFornecedores as any[]) {
      const razao = (f.razao_social || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
      const fantasia = (f.nome_fantasia || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
      if (razao === searchNorm || fantasia === searchNorm) return f.id;

      const searchWords = searchNorm.split(/\s+/).filter((w: string) => w.length > 2);
      const checkOverlap = (target: string) => {
        if (!target) return 0;
        const targetWords = target.split(/\s+/).filter((w: string) => w.length > 2);
        return searchWords.filter((w: string) => targetWords.some((tw: string) => tw.includes(w) || w.includes(tw))).length;
      };
      const overlap = Math.max(checkOverlap(razao), checkOverlap(fantasia));
      const minWords = Math.max(2, Math.ceil(searchWords.length * 0.5));
      if (overlap >= minWords) return f.id;
    }

    // Create new supplier
    try {
      const result = await saveFornecedor.mutateAsync({ razao_social: supplierName.trim() });
      await queryClient.invalidateQueries({ queryKey: ['fornecedores'] });
      return result?.id || null;
    } catch {
      return null;
    }
  };

  const handleImportAll = async () => {
    setProcessing(true);
    setProcessed(0);
    setSummary(null);
    let success = 0;
    let errors = 0;

    const { data: { user } } = await supabase.auth.getUser();

    for (let idx = 0; idx < entries.length; idx++) {
      const entry = entries[idx];
      if (entry.status === 'erro') {
        errors++;
        setProcessed(idx + 1);
        continue;
      }

      // Update status to processing
      setEntries(prev => prev.map((e, i) => i === idx ? { ...e, status: 'processando' as FileStatus } : e));

      try {
        const text = await entry.file.text();
        const parsed = parseNFeXml(text);

        // Find or create supplier
        const supplierId = await findOrCreateSupplier(parsed.supplierName || entry.file.name);
        if (!supplierId) throw new Error('Falha ao identificar fornecedor');

        // Upload file
        const path = `imports/${Date.now()}_${entry.file.name}`;
        const { error: uploadErr } = await supabase.storage.from('compras-docs').upload(path, entry.file);
        if (uploadErr) throw new Error('Erro no upload: ' + uploadErr.message);
        const { data: urlData } = supabase.storage.from('compras-docs').getPublicUrl(path);

        // Create purchase_import record
        const { data: importRecord, error: importErr } = await supabase
          .from('purchase_imports' as any)
          .insert({
            supplier_id: supplierId,
            document_kind: 'XML',
            file_url: urlData.publicUrl,
            file_name: entry.file.name,
            document_date: parsed.docDate || null,
            reference_number: parsed.docNumber || null,
            notes: parsed.supplierCnpj ? `CNPJ: ${parsed.supplierCnpj}` : null,
            created_by: user?.id,
            status: 'RASCUNHO',
          } as any)
          .select()
          .single();

        if (importErr || !importRecord) throw new Error(importErr?.message || 'Erro ao criar importação');

        const importId = (importRecord as any).id;

        // Insert lines
        for (let i = 0; i < parsed.items.length; i++) {
          const item = parsed.items[i];
          await supabase.from('purchase_import_lines' as any).insert({
            purchase_import_id: importId,
            line_index: i,
            raw_description: item.description || 'Sem descrição',
            qty: item.qty || 1,
            unit: item.unit || null,
            unit_price: item.unit_price || null,
            total_price: item.total_price || null,
          } as any);
        }

        // Auto-confirm (update to CONFIRMADO)
        const { error: confirmErr } = await supabase
          .from('purchase_imports' as any)
          .update({ status: 'CONFIRMADO', confirmed_by: user?.id } as any)
          .eq('id', importId);

        if (confirmErr) throw new Error('Erro ao confirmar: ' + confirmErr.message);

        setEntries(prev => prev.map((e, i) => i === idx ? { ...e, status: 'importado' as FileStatus } : e));
        success++;
      } catch (err: any) {
        setEntries(prev => prev.map((e, i) => i === idx ? { ...e, status: 'erro' as FileStatus, error: err.message } : e));
        errors++;
      }

      setProcessed(idx + 1);
    }

    setSummary({ success, errors });
    setProcessing(false);
    queryClient.invalidateQueries({ queryKey: ['purchase_imports'] });
    queryClient.invalidateQueries({ queryKey: ['stock_receipts'] });
    queryClient.invalidateQueries({ queryKey: ['supplier_product_prices'] });

    if (success > 0) {
      toast.success(`${success} XML(s) importado(s) com sucesso!`);
    }
  };

  const handleRemoveEntry = (idx: number) => {
    setEntries(prev => prev.filter((_, i) => i !== idx));
  };

  const handleClose = (v: boolean) => {
    if (!processing) {
      setEntries([]);
      setSummary(null);
      setProcessed(0);
      onOpenChange(v);
    }
  };

  const aguardandoCount = entries.filter(e => e.status === 'aguardando').length;

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Upload className="h-5 w-5" />
            Importar XMLs em Lote
          </DialogTitle>
        </DialogHeader>

        {/* File selection */}
        {entries.length === 0 && (
          <div className="border-2 border-dashed rounded-lg p-8 text-center">
            <input
              ref={inputRef}
              type="file"
              accept=".xml"
              multiple
              onChange={handleFilesSelected}
              className="hidden"
              id="bulk-xml-input"
            />
            <label htmlFor="bulk-xml-input" className="cursor-pointer">
              <Upload className="h-10 w-10 mx-auto text-muted-foreground mb-3" />
              <p className="text-sm font-medium">Clique para selecionar múltiplos arquivos XML (NF-e)</p>
              <p className="text-xs text-muted-foreground mt-1">Todos serão processados e confirmados automaticamente</p>
            </label>
          </div>
        )}

        {/* File list */}
        {entries.length > 0 && (
          <div className="space-y-4">
            {/* Progress */}
            {processing && (
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Processando...</span>
                  <span className="font-medium">{processed}/{entries.length}</span>
                </div>
                <Progress value={(processed / entries.length) * 100} className="h-2" />
              </div>
            )}

            {/* Summary */}
            {summary && (
              <div className={`p-3 rounded-lg border ${summary.errors > 0 ? 'border-amber-300 bg-amber-50 dark:bg-amber-950/20' : 'border-emerald-300 bg-emerald-50 dark:bg-emerald-950/20'}`}>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-emerald-600" />
                  <span className="text-sm font-medium">
                    {summary.success} importado(s) com sucesso
                    {summary.errors > 0 && <span className="text-destructive ml-2">• {summary.errors} com erro</span>}
                  </span>
                </div>
              </div>
            )}

            {/* File entries */}
            <div className="space-y-2 max-h-[400px] overflow-y-auto">
              {entries.map((entry, idx) => {
                const cfg = STATUS_CONFIG[entry.status];
                const Icon = cfg.icon;
                return (
                  <div key={idx} className="flex items-center gap-3 p-3 rounded-lg border bg-card">
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <FileText className="h-4 w-4 text-muted-foreground shrink-0" />
                        <span className="text-sm font-medium truncate">{entry.file.name}</span>
                      </div>
                      <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground ml-6">
                        <span>{entry.supplierName}</span>
                        {entry.docNumber && <span>NF {entry.docNumber}</span>}
                        {entry.totalValue > 0 && <span className="font-medium text-foreground">{formatCurrency(entry.totalValue)}</span>}
                      </div>
                      {entry.error && (
                        <p className="text-xs text-destructive mt-1 ml-6">{entry.error}</p>
                      )}
                    </div>
                    <Badge variant="outline" className={`text-[10px] font-medium gap-1 shrink-0 ${cfg.className}`}>
                      <Icon className={`h-3 w-3 ${entry.status === 'processando' ? 'animate-spin' : ''}`} />
                      {cfg.label}
                    </Badge>
                    {entry.status === 'aguardando' && !processing && (
                      <Button variant="ghost" size="icon" className="h-7 w-7 shrink-0" onClick={() => handleRemoveEntry(idx)}>
                        <X className="h-3.5 w-3.5" />
                      </Button>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Actions */}
            <div className="flex justify-between">
              {!processing && !summary && (
                <>
                  <Button variant="outline" onClick={() => { setEntries([]); if (inputRef.current) inputRef.current.value = ''; }}>
                    Limpar
                  </Button>
                  <Button onClick={handleImportAll} disabled={aguardandoCount === 0} className="gap-2">
                    <CheckCircle2 className="h-4 w-4" />
                    Importar Todos ({aguardandoCount})
                  </Button>
                </>
              )}
              {summary && (
                <Button onClick={() => handleClose(false)} className="ml-auto">Fechar</Button>
              )}
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
