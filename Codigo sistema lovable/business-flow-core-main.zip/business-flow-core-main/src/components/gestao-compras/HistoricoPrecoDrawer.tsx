import { Drawer, DrawerContent, DrawerHeader, DrawerTitle, DrawerClose } from '@/components/ui/drawer';
import { Button } from '@/components/ui/button';
import { Loader2, X, TrendingUp } from 'lucide-react';
import { useHistoricoPrecoDetalhe } from '@/hooks/useHistoricoPrecos';
import { formatCurrency } from '@/lib/utils';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Badge } from '@/components/ui/badge';

interface HistoricoPrecoDrawerProps {
  open: boolean;
  onClose: () => void;
  productId?: string;
  productName?: string;
  fornecedorId?: string;
  fornecedorNome?: string;
}

export function HistoricoPrecoDrawer({
  open,
  onClose,
  productId,
  productName,
  fornecedorId,
  fornecedorNome,
}: HistoricoPrecoDrawerProps) {
  const { data: history = [], isLoading } = useHistoricoPrecoDetalhe(
    productId,
    fornecedorId,
    fornecedorNome
  );

  // Prepare chart data (ascending order for chart)
  const chartData = [...history]
    .sort((a: any, b: any) => new Date(a.data_compra).getTime() - new Date(b.data_compra).getTime())
    .map((h: any) => ({
      date: format(new Date(h.data_compra + 'T00:00:00'), 'dd/MM/yy', { locale: ptBR }),
      preco: Number(h.preco_unitario),
    }));

  return (
    <Drawer open={open} onOpenChange={v => !v && onClose()}>
      <DrawerContent className="max-h-[85vh]">
        <DrawerHeader className="flex items-start justify-between pr-2">
          <div>
            <DrawerTitle className="text-sm font-semibold">{productName}</DrawerTitle>
            <p className="text-xs text-muted-foreground mt-0.5">{fornecedorNome}</p>
          </div>
          <DrawerClose asChild>
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 hover:bg-muted"
            >
              <X className="h-4 w-4" />
            </Button>
          </DrawerClose>
        </DrawerHeader>

        <div className="px-4 pb-6 overflow-auto max-h-[70vh]">
          {isLoading ? (
            <div className="flex flex-col items-center justify-center py-12 gap-2">
              <Loader2 className="h-6 w-6 animate-spin text-primary" />
              <p className="text-sm text-muted-foreground">Carregando...</p>
            </div>
          ) : history.length === 0 ? (
            <div className="text-center py-12">
              <TrendingUp className="h-10 w-10 mx-auto text-muted-foreground/30 mb-2" />
              <p className="text-sm text-muted-foreground">Sem histórico de preços</p>
            </div>
          ) : (
            <>
              {/* Chart */}
              {chartData.length > 1 && (
                <div className="mb-5 bg-muted/30 rounded-lg p-3">
                  <p className="text-[11px] uppercase tracking-wider font-semibold text-muted-foreground mb-2">
                    Evolução do Preço
                  </p>
                  <ResponsiveContainer width="100%" height={180}>
                    <LineChart data={chartData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                      <XAxis dataKey="date" tick={{ fontSize: 10 }} stroke="hsl(var(--muted-foreground))" />
                      <YAxis
                        tick={{ fontSize: 10 }}
                        stroke="hsl(var(--muted-foreground))"
                        tickFormatter={(v: number) => `R$${v.toFixed(0)}`}
                      />
                      <Tooltip
                        formatter={(value: number) => [formatCurrency(value), 'Preço']}
                        contentStyle={{
                          fontSize: 12,
                          background: 'hsl(var(--background))',
                          border: '1px solid hsl(var(--border))',
                          borderRadius: 8,
                        }}
                      />
                      <Line
                        type="monotone"
                        dataKey="preco"
                        stroke="hsl(var(--primary))"
                        strokeWidth={2}
                        dot={{ r: 3, fill: 'hsl(var(--primary))' }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              )}

              {/* List */}
              <div className="space-y-2">
                {history.map((h: any) => (
                  <div
                    key={h.id}
                    className="flex items-center justify-between p-3 rounded-lg bg-muted/40 text-sm"
                  >
                    <div>
                      <p className="text-xs text-muted-foreground">
                        {h.data_compra
                          ? format(new Date(h.data_compra + 'T00:00:00'), 'dd/MM/yyyy', { locale: ptBR })
                          : '—'}
                      </p>
                      {h.documento_referencia && (
                        <p className="text-[10px] text-muted-foreground">
                          Ref: {h.documento_referencia}
                        </p>
                      )}
                      {h.origem && (
                        <Badge variant="outline" className="text-[9px] mt-0.5 h-4">
                          {h.origem === 'nota_fiscal' ? 'NF' : h.origem === 'cotacao' ? 'Cotação' : 'Manual'}
                        </Badge>
                      )}
                    </div>
                    <div className="text-right">
                      <p className="font-bold font-mono">{formatCurrency(h.preco_unitario)}</p>
                      {h.quantidade && (
                        <p className="text-[10px] text-muted-foreground">
                          Qtd: {Number(h.quantidade).toFixed(0)}
                        </p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>
      </DrawerContent>
    </Drawer>
  );
}
