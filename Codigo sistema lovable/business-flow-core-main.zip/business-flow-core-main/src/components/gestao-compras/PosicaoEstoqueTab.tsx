import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Package, RefreshCw, Loader2, AlertTriangle, Search, ChevronLeft, ChevronRight, TrendingDown, DollarSign, AlertCircle, Filter } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import { useQuery } from '@tanstack/react-query';

interface StockProduct {
  id: string;
  sku: string | null;
  name: string;
  estoqueSaldo: number;
  custo: number | null;
  scorePrioridade: number | null;
  category: string | null;
  estoqueAtualizadoEm: string | null;
}

const PAGE_SIZE = 50;

const formatBRL = (v: number | null) => {
  if (v == null || v <= 0) return null;
  return `R$ ${v.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
};

const formatBRLValue = (v: number) =>
  `R$ ${v.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

type SortCol = 'sku' | 'name' | 'category' | 'estoqueSaldo' | 'custo' | 'scorePrioridade';

const sortColToDbCol: Record<SortCol, string> = {
  sku: 'sku',
  name: 'name',
  category: 'category',
  estoqueSaldo: 'estoque_saldo',
  custo: 'cost_price',
  scorePrioridade: 'estoque_saldo',
};

export function PosicaoEstoqueTab() {
  const [products, setProducts] = useState<StockProduct[]>([]);
  const [loading, setLoading] = useState(true);
  const [totalCount, setTotalCount] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [search, setSearch] = useState('');
  const [debouncedSearch, setDebouncedSearch] = useState('');
  const [filter, setFilter] = useState<'all' | 'baixo' | 'sem_custo' | 'ruptura'>('all');
  const [sortCol, setSortCol] = useState<SortCol>('estoqueSaldo');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('asc');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const toggleSort = (col: SortCol) => {
    if (sortCol === col) {
      setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    } else {
      setSortCol(col);
      setSortDir(col === 'estoqueSaldo' || col === 'custo' || col === 'scorePrioridade' ? 'desc' : 'asc');
    }
    setCurrentPage(1);
  };

  const sortIndicator = (col: SortCol) => sortCol === col ? (sortDir === 'asc' ? ' ↑' : ' ↓') : '';

  const [syncing, setSyncing] = useState(false);
  const [syncProgress, setSyncProgress] = useState<{
    currentPage: number;
    totalBatches: number;
    totalProducts: number;
    totalProcessed: number;
    updated: number;
    failed: number;
    message: string;
  } | null>(null);

  // ── Fetch available categories ──
  const { data: availableCategories } = useQuery({
    queryKey: ['stock-categories'],
    queryFn: async () => {
      const { data } = await supabase
        .from('v_hh_produtos_com_estoque' as any)
        .select('category')
        .eq('active', true)
        .not('estoque_saldo', 'is', null)
        .not('category', 'is', null);

      if (!data) return [];
      const unique = [...new Set((data as any[]).map(d => d.category).filter(Boolean))].sort();
      return unique as string[];
    },
    staleTime: 120_000,
  });

  // ── KPI Summary ──
  const { data: kpis, refetch: refetchKpis } = useQuery({
    queryKey: ['stock-kpis', selectedCategory],
    queryFn: async () => {
      let query = supabase
        .from('v_hh_produtos_com_estoque' as any)
        .select('estoque_saldo, cost_price')
        .eq('active', true)
        .not('estoque_saldo', 'is', null);

      if (selectedCategory !== 'all') {
        query = query.eq('category', selectedCategory);
      }

      const { data } = await query;

      if (!data) return { custoTotal: 0, ruptura: 0, baixo: 0, semCusto: 0 };

      let custoTotal = 0;
      let ruptura = 0;
      let baixo = 0;
      let semCusto = 0;

      for (const p of data as any[]) {
        const qty = p.estoque_saldo ?? 0;
        const cost = p.cost_price ?? 0;

        if (qty > 0 && cost > 0) custoTotal += qty * cost;
        if (qty <= 0) ruptura++;
        if (qty > 0 && qty <= 5) baixo++;
        if (!cost || cost <= 0) semCusto++;
      }

      return { custoTotal, ruptura, baixo, semCusto };
    },
    staleTime: 60_000,
  });

  const applyFilters = (query: any) => {
    if (debouncedSearch) {
      query = query.or(`name.ilike.%${debouncedSearch}%,sku.ilike.%${debouncedSearch}%`);
    }
    if (selectedCategory !== 'all') {
      query = query.eq('category', selectedCategory);
    }
    if (filter === 'baixo') {
      query = query.lte('estoque_saldo', 5).gt('estoque_saldo', 0);
    } else if (filter === 'sem_custo') {
      query = query.or('cost_price.is.null,cost_price.eq.0');
    } else if (filter === 'ruptura') {
      query = query.lte('estoque_saldo', 0);
    }
    return query;
  };

  const fetchProducts = useCallback(async () => {
    setLoading(true);
    try {
      let countQuery = supabase
        .from('v_hh_produtos_com_estoque' as any)
        .select('id', { count: 'exact', head: true })
        .eq('active', true)
        .not('estoque_saldo', 'is', null);
      countQuery = applyFilters(countQuery);

      const { count } = await countQuery;
      setTotalCount(count || 0);

      const dbCol = sortColToDbCol[sortCol];
      let query = supabase
        .from('v_hh_produtos_com_estoque' as any)
        .select('id, sku, name, estoque_saldo, cost_price, category, estoque_atualizado_em')
        .eq('active', true)
        .not('estoque_saldo', 'is', null)
        .order(dbCol, { ascending: sortDir === 'asc', nullsFirst: false });

      query = applyFilters(query);

      const from = (currentPage - 1) * PAGE_SIZE;
      query = query.range(from, from + PAGE_SIZE - 1);

      const { data } = await query;

      if (data) {
        setProducts((data as any[]).map((p: any) => ({
          id: p.id,
          sku: p.sku,
          name: p.name,
          estoqueSaldo: p.estoque_saldo ?? 0,
          custo: p.cost_price,
          scorePrioridade: null,
          category: p.category,
          estoqueAtualizadoEm: p.estoque_atualizado_em,
        })));
      }
    } catch (err) {
      console.error('Error fetching stock products:', err);
    } finally {
      setLoading(false);
    }
  }, [currentPage, debouncedSearch, filter, sortCol, sortDir, selectedCategory]);

  useEffect(() => {
    fetchProducts();
  }, [fetchProducts]);

  useEffect(() => {
    const timeout = setTimeout(() => setDebouncedSearch(search), 300);
    return () => clearTimeout(timeout);
  }, [search]);

  const handleSyncEstoque = async () => {
    setSyncing(true);

    const BATCH_SIZE = 100;

    const { count: totalProducts } = await supabase
      .from('products')
      .select('id', { count: 'exact', head: true })
      .not('conta_azul_id', 'is', null)
      .eq('active', true);

    const tp = totalProducts || 0;
    const totalBatches = Math.ceil(tp / BATCH_SIZE) || 1;

    setSyncProgress({ currentPage: 0, totalBatches, totalProducts: tp, totalProcessed: 0, updated: 0, failed: 0, message: 'Iniciando sincronização...' });

    let page = 1;
    let hasMore = true;
    let totalUpdated = 0;
    let totalFailed = 0;
    let totalProcessed = 0;

    try {
      while (hasMore) {
        setSyncProgress({
          currentPage: page,
          totalBatches,
          totalProducts: tp,
          totalProcessed,
          updated: totalUpdated,
          failed: totalFailed,
          message: `Processando lote ${page} de ${totalBatches}...`,
        });

        const { data, error } = await supabase.functions.invoke('conta-azul-sync-estoque', {
          body: { trigger: 'manual', page, page_size: BATCH_SIZE },
        });

        if (error) throw new Error(error.message || 'Erro na sincronização');
        if (!data?.ok && data?.error) throw new Error(data.error);

        const summary = data?.summary || {};
        const batchDurationMs = Number(summary.duration_ms || 0);
        const batch429Count = Number(summary.http_429_count || 0);
        const batchRetry429Hits = Number(summary.retry_429_hits || 0);

        totalUpdated += summary.updated_stock_count || 0;
        totalFailed += (summary.http_fail_count || 0) + (summary.parse_fail_count || 0);
        totalProcessed += summary.api_calls || 0;

        console.info(
          `[sync-estoque-ui] lote=${page}/${totalBatches} itens=${summary.products_considered || 0} ` +
          `duracao=${batchDurationMs}ms 429=${batch429Count} retry429=${batchRetry429Hits} ` +
          `atualizados=${summary.updated_stock_count || 0} falhas=${(summary.http_fail_count || 0) + (summary.parse_fail_count || 0)}`,
        );

        hasMore = data?.has_more === true;
        page++;
      }

      setSyncProgress({
        currentPage: page - 1,
        totalBatches,
        totalProducts: tp,
        totalProcessed,
        updated: totalUpdated,
        failed: totalFailed,
        message: 'Sincronização concluída!',
      });

      toast.success(`Estoque sincronizado: ${totalUpdated} atualizados`, {
        description: totalFailed > 0 ? `${totalFailed} falha(s)` : undefined,
      });

      fetchProducts();
      refetchKpis();
    } catch (err: any) {
      toast.error(err.message || 'Erro ao sincronizar estoque');
      setSyncProgress(prev => prev ? { ...prev, message: `Erro: ${err.message}` } : null);
    } finally {
      setSyncing(false);
      setTimeout(() => setSyncProgress(null), 5000);
    }
  };

  const totalPages = Math.ceil(totalCount / PAGE_SIZE);

  const filterChips: { value: typeof filter; label: string }[] = [
    { value: 'all', label: 'Todos' },
    { value: 'ruptura', label: '🚨 Ruptura (≤0)' },
    { value: 'baixo', label: '⚠️ Baixo (≤5)' },
    { value: 'sem_custo', label: '💰 Sem Custo' },
  ];

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-3">
          <Package className="h-5 w-5 text-primary" />
          <div>
            <h2 className="text-lg font-semibold">Posição de Estoque</h2>
            <p className="text-sm text-muted-foreground">Saldo, custo e score dos produtos ativos</p>
          </div>
        </div>
        <Button onClick={handleSyncEstoque} disabled={syncing} size="sm">
          {syncing ? <Loader2 className="h-4 w-4 mr-1.5 animate-spin" /> : <RefreshCw className="h-4 w-4 mr-1.5" />}
          Sincronizar Saldos (Conta Azul)
        </Button>
      </div>

      {/* KPI Summary Cards */}
      {kpis && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <div className="rounded-lg border border-border/60 bg-background p-3" style={{ minHeight: 72 }}>
            <p className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">Custo Total em Estoque</p>
            <p className="text-[22px] font-semibold text-primary mt-0.5 leading-tight">{formatBRLValue(kpis.custoTotal)}</p>
          </div>
          <div className="rounded-lg border border-border/60 bg-background p-3" style={{ minHeight: 72 }}>
            <p className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground flex items-center gap-1">
              <TrendingDown className="h-3 w-3" /> Produtos em Ruptura
            </p>
            <p className="text-[22px] font-semibold text-destructive mt-0.5 leading-tight">{kpis.ruptura}</p>
          </div>
          <div className="rounded-lg border border-border/60 bg-background p-3" style={{ minHeight: 72 }}>
            <p className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground flex items-center gap-1">
              <AlertCircle className="h-3 w-3" /> Estoque Baixo
            </p>
            <p className="text-[22px] font-semibold text-warning mt-0.5 leading-tight">{kpis.baixo}</p>
          </div>
          <div className="rounded-lg border border-border/60 bg-background p-3" style={{ minHeight: 72 }}>
            <p className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground flex items-center gap-1">
              <DollarSign className="h-3 w-3" /> Sem Custo
            </p>
            <p className="text-[22px] font-semibold text-muted-foreground mt-0.5 leading-tight">{kpis.semCusto}</p>
          </div>
        </div>
      )}

      {/* Sync Progress */}
      {syncProgress && (
        <div className="rounded-lg border border-primary/20 bg-primary/5 p-4 space-y-2">
          <p className="text-sm font-medium text-foreground">{syncProgress.message}</p>
          <div className="flex gap-4 text-xs text-muted-foreground">
            <span>Lote: <strong>{syncProgress.currentPage}/{syncProgress.totalBatches}</strong></span>
            <span>Processados: <strong>{syncProgress.totalProcessed}/{syncProgress.totalProducts}</strong></span>
            <span className="text-status-active">Atualizados: <strong>{syncProgress.updated}</strong></span>
            {syncProgress.failed > 0 && (
              <span className="text-destructive">Falhas: <strong>{syncProgress.failed}</strong></span>
            )}
          </div>
          {syncing && <Progress value={undefined} className="h-1.5" />}
        </div>
      )}

      {/* Filters + Category */}
      <div className="flex flex-wrap items-center gap-2">
        {filterChips.map(chip => (
          <Button
            key={chip.value}
            variant={filter === chip.value ? 'default' : 'outline'}
            size="sm"
            onClick={() => { setFilter(chip.value); setCurrentPage(1); }}
          >
            {chip.label}
          </Button>
        ))}
        <div className="flex items-center gap-1.5 ml-auto">
          <Filter className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
          <Select value={selectedCategory} onValueChange={(v) => { setSelectedCategory(v); setCurrentPage(1); }}>
            <SelectTrigger className="h-8 w-[200px] text-xs">
              <SelectValue placeholder="Todas as categorias" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todas as categorias</SelectItem>
              {(availableCategories || []).map(cat => (
                <SelectItem key={cat} value={cat}>{cat}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" size={18} />
        <Input
          placeholder="Buscar por nome ou SKU..."
          value={search}
          onChange={(e) => { setSearch(e.target.value); setCurrentPage(1); }}
          className="pl-10"
        />
      </div>

      {/* Table */}
      <div className="card-section p-0 overflow-hidden">
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full" />
          </div>
        ) : products.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
            <Package size={48} className="mb-4 opacity-50" />
            <p>Nenhum produto encontrado</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="data-table">
              <thead>
                <tr>
                  <th className="cursor-pointer select-none" onClick={() => toggleSort('sku')}>SKU{sortIndicator('sku')}</th>
                  <th className="cursor-pointer select-none" onClick={() => toggleSort('name')}>Produto{sortIndicator('name')}</th>
                  <th className="cursor-pointer select-none" onClick={() => toggleSort('category')}>Categoria{sortIndicator('category')}</th>
                  <th className="text-right cursor-pointer select-none" onClick={() => toggleSort('estoqueSaldo')}>Qtd Atual{sortIndicator('estoqueSaldo')}</th>
                  <th className="text-right cursor-pointer select-none" onClick={() => toggleSort('custo')}>Custo Unit.{sortIndicator('custo')}</th>
                  <th className="text-center cursor-pointer select-none" onClick={() => toggleSort('scorePrioridade')}>Score{sortIndicator('scorePrioridade')}</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {products.map((p) => (
                  <tr key={p.id}>
                    <td className="font-mono text-xs text-muted-foreground">{p.sku || '-'}</td>
                    <td className="font-medium text-foreground text-sm">{p.name}</td>
                    <td className="text-xs text-muted-foreground">{p.category || <span className="italic">Sem cat.</span>}</td>
                    <td className="text-right">
                      <span className={p.estoqueSaldo <= 0 ? 'text-destructive font-semibold' : p.estoqueSaldo <= 5 ? 'text-warning font-semibold' : 'text-foreground'}>
                        {p.estoqueSaldo}
                      </span>
                    </td>
                    <td className="text-right text-sm">
                      {formatBRL(p.custo) || <span className="text-destructive">-</span>}
                    </td>
                    <td className="text-center">
                      {p.scorePrioridade != null ? (
                        <span className={`font-mono text-xs font-semibold ${
                          p.scorePrioridade > 0.5 ? 'text-status-active' :
                          p.scorePrioridade > 0 ? 'text-foreground' : 'text-muted-foreground'
                        }`}>
                          {p.scorePrioridade.toFixed(2)}
                        </span>
                      ) : <span className="text-muted-foreground/50">-</span>}
                    </td>
                    <td>
                      {p.estoqueSaldo <= 0 ? (
                        <Badge variant="destructive" className="text-[10px]">
                          <AlertTriangle className="h-3 w-3 mr-0.5" /> Ruptura
                        </Badge>
                      ) : p.estoqueSaldo <= 5 ? (
                        <Badge className="bg-warning/10 text-warning border-warning/30 text-[10px]">Baixo</Badge>
                      ) : (
                        <Badge variant="secondary" className="text-[10px]">OK</Badge>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between flex-wrap gap-2">
          <p className="text-sm text-muted-foreground">
            {(currentPage - 1) * PAGE_SIZE + 1} - {Math.min(currentPage * PAGE_SIZE, totalCount)} de {totalCount}
          </p>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={() => setCurrentPage(p => Math.max(1, p - 1))} disabled={currentPage === 1}>
              <ChevronLeft size={16} className="mr-1" /> Anterior
            </Button>
            <span className="text-sm text-muted-foreground px-2">{currentPage} / {totalPages}</span>
            <Button variant="outline" size="sm" onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))} disabled={currentPage === totalPages}>
              Próxima <ChevronRight size={16} className="ml-1" />
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
