import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ClipboardList, Package } from 'lucide-react';

interface SolicitacaoItensReferenciaProps {
  solicitacaoCompraId: string;
}

export function SolicitacaoItensReferencia({ solicitacaoCompraId }: SolicitacaoItensReferenciaProps) {
  const { data: itens = [] } = useQuery({
    queryKey: ['solicitacao_itens_ref', solicitacaoCompraId],
    enabled: !!solicitacaoCompraId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from('solicitacao_itens')
        .select('id, descricao_livre, quantidade, unidade, observacoes_item, produto:produto_id(id, name, sku)')
        .eq('solicitacao_id', solicitacaoCompraId)
        .order('created_at', { ascending: true });
      if (error) throw error;
      return data || [];
    },
  });

  if (itens.length === 0) return null;

  return (
    <Card className="border" style={{ borderColor: '#C7D2FE' }}>
      <CardHeader className="pb-2">
        <CardTitle className="text-sm flex items-center gap-2" style={{ color: '#3B5BDB' }}>
          <ClipboardList className="h-4 w-4" />
          Itens da Solicitação ({itens.length})
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-2">
        {itens.map((item: any) => (
          <div
            key={item.id}
            className="flex items-start gap-2 p-2 rounded-md text-sm"
            style={{ backgroundColor: '#EEF2FF' }}
          >
            <Package className="h-3.5 w-3.5 mt-0.5 shrink-0 text-muted-foreground" />
            <div className="min-w-0 flex-1">
              <p className="font-medium text-foreground truncate">
                {item.produto?.name || item.descricao_livre || '—'}
              </p>
              <div className="flex items-center gap-2 text-xs text-muted-foreground mt-0.5">
                <span>Qtd: {item.quantidade} {item.unidade || 'un'}</span>
                {item.produto?.sku && <span>• SKU: {item.produto.sku}</span>}
              </div>
              {item.observacoes_item && (
                <p className="text-xs text-muted-foreground mt-0.5 italic">{item.observacoes_item}</p>
              )}
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}
