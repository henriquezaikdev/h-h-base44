import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import { Trophy, Check, Loader2, ArrowRight } from 'lucide-react';
import { toast } from 'sonner';

interface SupplierQuote {
  id: string;
  supplier_id: string;
  supplier_name: string;
  document_date: string | null;
  notes: string | null;
  lines: {
    id: string;
    raw_description: string;
    qty: number;
    unit: string | null;
    unit_price: number | null;
    total_price: number | null;
    product_id: string | null;
    payment_terms: string | null;
    delivery_days: number | null;
    is_winner: boolean;
  }[];
}

interface CotacaoComparativoProps {
  sessionId: string;
  quotes: SupplierQuote[];
  solicitacaoCompraId?: string | null;
  onClose: () => void;
  onRefresh: () => void;
  onNavigateToPainel?: () => void;
}

export function CotacaoComparativo({ sessionId, quotes, solicitacaoCompraId, onClose, onRefresh, onNavigateToPainel }: CotacaoComparativoProps) {
  const { seller } = useAuth();
  const [closing, setClosing] = useState(false);

  // Initialize winners from DB data
  const initialWinners: Record<string, string> = {};
  quotes.forEach(q => {
    q.lines.forEach(line => {
      if (line.is_winner) {
        const key = line.raw_description.toLowerCase().trim();
        if (!initialWinners[key]) initialWinners[key] = line.id;
      }
    });
  });
  const [winners, setWinners] = useState<Record<string, string>>(initialWinners);

  if (quotes.length < 1) {
    return (
      <Card>
        <CardContent className="py-8 text-center">
          <p className="text-muted-foreground">
            Adicione pelo menos 1 fornecedor para visualizar o comparativo
          </p>
        </CardContent>
      </Card>
    );
  }

  // Build comparison matrix: group lines by normalized description
  const allDescriptions = new Map<string, { original: string; bySupplier: Map<string, typeof quotes[0]['lines'][0]> }>();

  quotes.forEach(q => {
    q.lines.forEach(line => {
      const key = line.raw_description.toLowerCase().trim();
      if (!allDescriptions.has(key)) {
        allDescriptions.set(key, { original: line.raw_description, bySupplier: new Map() });
      }
      allDescriptions.get(key)!.bySupplier.set(q.id, line);
    });
  });

  const descriptions = Array.from(allDescriptions.entries());

  const formatCurrency = (v: number) =>
    new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(v);

  const handleSetWinner = (descKey: string, lineId: string) => {
    setWinners(prev => ({ ...prev, [descKey]: lineId }));
  };

  const handleSetAllWinnersBySupplier = (quoteId: string) => {
    const newWinners: Record<string, string> = {};
    descriptions.forEach(([key, { bySupplier }]) => {
      const line = bySupplier.get(quoteId);
      if (line) newWinners[key] = line.id;
    });
    setWinners(newWinners);
  };

  // Find cheapest per item
  const cheapestByDesc = new Map<string, { lineId: string; price: number }>();
  descriptions.forEach(([key, { bySupplier }]) => {
    let min = Infinity;
    let minId = '';
    bySupplier.forEach((line) => {
      if (line.unit_price !== null && line.unit_price < min) {
        min = line.unit_price;
        minId = line.id;
      }
    });
    if (minId) cheapestByDesc.set(key, { lineId: minId, price: min });
  });

  const handleFecharCotacao = async () => {
    const winnerLineIds = Object.values(winners);
    if (winnerLineIds.length === 0) {
      toast.error('Defina pelo menos um ganhador');
      return;
    }

    setClosing(true);
    try {
      // 1. Mark all lines as NOT winner first
      const allLineIds = quotes.flatMap(q => q.lines.map(l => l.id));
      await supabase
        .from('supplier_quote_lines')
        .update({ is_winner: false })
        .in('id', allLineIds);

      // 2. Mark winners
      await supabase
        .from('supplier_quote_lines')
        .update({ is_winner: true })
        .in('id', winnerLineIds);

      // 3. Update supplier_product_prices and supplier_price_history for winners with product_id (BLOCO 5)
      for (const [descKey, lineId] of Object.entries(winners)) {
        const desc = allDescriptions.get(descKey);
        if (!desc) continue;

        // Find the line and its supplier
        for (const q of quotes) {
          const line = q.lines.find(l => l.id === lineId);
          if (line && line.product_id && line.unit_price) {
            // Upsert into supplier_product_prices with origin tracking
            await supabase
              .from('supplier_product_prices')
              .upsert({
                supplier_id: q.supplier_id,
                product_id: line.product_id,
                last_price: line.unit_price,
                last_date: new Date().toISOString().split('T')[0],
                last_reference: `cotacao_${sessionId.substring(0, 8)}`,
                cotacao_sessao_id: sessionId,
                origem_registro: 'cotacao',
              } as any, { onConflict: 'supplier_id,product_id' });

            // Insert into supplier_price_history (append-only)
            await supabase
              .from('supplier_price_history')
              .insert({
                supplier_id: q.supplier_id,
                product_id: line.product_id,
                price: line.unit_price,
                qty: line.qty,
                document_date: new Date().toISOString().split('T')[0],
                reference_number: `cotacao_${sessionId.substring(0, 8)}`,
                cotacao_sessao_id: sessionId,
                origem_registro: 'cotacao',
              } as any);

            break;
          }
        }
      }

      // 4. Update session status
      await supabase
        .from('cotacao_sessoes' as any)
        .update({
          status: 'fechada',
          fechada_em: new Date().toISOString(),
          fechada_por: seller?.id,
        })
        .eq('id', sessionId);

      // 5. If linked to a solicitacao, route to approval or auto-approve
      if (solicitacaoCompraId) {
        // Fetch solicitante to determine routing
        const { data: sol } = await supabase
          .from('solicitacoes_compra')
          .select('solicitante_id, titulo')
          .eq('id', solicitacaoCompraId)
          .single();

        const isSelfApproval = sol?.solicitante_id === seller?.id;
        const nextStatus = isSelfApproval
          ? 'APROVADA_PARA_COMPRAR'
          : 'AGUARDANDO_APROVACAO_SOLICITANTE';

        await supabase
          .from('solicitacoes_compra')
          .update({ status: nextStatus })
          .eq('id', solicitacaoCompraId);

        // 6. Insert feed event
        await supabase
          .from('compras_feed')
          .insert({
            solicitacao_id: solicitacaoCompraId,
            tipo_evento: 'MUDANCA_STATUS',
            mensagem: isSelfApproval
              ? 'Cotação fechada — aprovada automaticamente (comprador = solicitante)'
              : 'Cotação fechada — aguardando aprovação do solicitante',
            usuario_id: seller?.id,
          });

        // 7. Notify solicitante if different person
        if (!isSelfApproval && sol?.solicitante_id) {
          await supabase
            .from('seller_notifications')
            .insert({
              seller_id: sol.solicitante_id,
              title: 'Cotação pronta para aprovação',
              message: `A cotação para "${sol.titulo || 'Solicitação'}" foi fechada e aguarda sua aprovação`,
              type: 'alert',
              metadata: { event_type: 'MUDANCA_STATUS', request_id: solicitacaoCompraId } as any,
            });
        }
      }

      toast.success('Cotação fechada com sucesso!');

      // 7. Redirect to Painel do Comprador
      if (onNavigateToPainel) {
        onNavigateToPainel();
      } else {
        onRefresh();
      }
    } catch (error) {
      console.error('Error closing quotation:', error);
      toast.error('Erro ao fechar cotação');
    } finally {
      setClosing(false);
    }
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2">
            <Trophy className="h-4 w-4 text-amber-500" />
            Comparativo de Cotação
          </CardTitle>
          <div className="flex gap-2">
            {quotes.map(q => (
              <Button
                key={q.id}
                variant="outline"
                size="sm"
                className="text-xs"
                onClick={() => handleSetAllWinnersBySupplier(q.id)}
              >
                Tudo para {q.supplier_name.substring(0, 15)}
              </Button>
            ))}
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="rounded-md border overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[200px] bg-muted/30">Item</TableHead>
                {quotes.map(q => (
                  <TableHead key={q.id} className="text-center min-w-[160px]">
                    <div className="font-semibold">{q.supplier_name}</div>
                  </TableHead>
                ))}
                <TableHead className="text-center w-[100px]">Ganhador</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {descriptions.map(([key, { original, bySupplier }]) => {
                const cheapest = cheapestByDesc.get(key);
                return (
                  <TableRow key={key}>
                    <TableCell className="font-medium text-sm bg-muted/10">
                      {original}
                    </TableCell>
                    {quotes.map(q => {
                      const line = bySupplier.get(q.id);
                      if (!line) {
                        return (
                          <TableCell key={q.id} className="text-center text-muted-foreground text-sm">
                            —
                          </TableCell>
                        );
                      }
                      const isCheapest = cheapest?.lineId === line.id;
                      const isWinner = winners[key] === line.id;

                      return (
                        <TableCell
                          key={q.id}
                          className={`text-center cursor-pointer transition-colors ${
                            isWinner ? 'bg-green-50 dark:bg-green-950/30' : 'hover:bg-muted/30'
                          }`}
                          onClick={() => handleSetWinner(key, line.id)}
                        >
                          <div className="space-y-1">
                            <div className={`font-mono text-sm font-semibold ${isCheapest ? 'text-green-600' : ''}`}>
                              {line.unit_price !== null ? formatCurrency(line.unit_price) : '—'}
                            </div>
                            {isCheapest && (
                              <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200 text-[10px]">
                                Menor
                              </Badge>
                            )}
                            {line.delivery_days && (
                              <p className="text-[10px] text-muted-foreground">{line.delivery_days}d entrega</p>
                            )}
                            {line.payment_terms && (
                              <p className="text-[10px] text-muted-foreground">{line.payment_terms}</p>
                            )}
                          </div>
                        </TableCell>
                      );
                    })}
                    <TableCell className="text-center">
                      {winners[key] ? (
                        <Check className="h-4 w-4 text-green-600 mx-auto" />
                      ) : (
                        <span className="text-xs text-muted-foreground">Clique</span>
                      )}
                    </TableCell>
                  </TableRow>
                );
              })}

              {/* Totals row */}
              <TableRow className="bg-muted/20 font-semibold">
                <TableCell>TOTAL</TableCell>
                {quotes.map(q => {
                  const total = q.lines.reduce((sum, l) => sum + (l.total_price || 0), 0);
                  return (
                    <TableCell key={q.id} className="text-center font-mono">
                      {formatCurrency(total)}
                    </TableCell>
                  );
                })}
                <TableCell />
              </TableRow>
            </TableBody>
          </Table>
        </div>

        <div className="flex justify-between items-center mt-4 pt-4 border-t">
          <p className="text-sm text-muted-foreground">
            {Object.keys(winners).length} de {descriptions.length} itens definidos
          </p>
          <div className="flex gap-2">
            <Button variant="outline" onClick={onClose}>Voltar</Button>
            <Button
              onClick={handleFecharCotacao}
              disabled={closing || Object.keys(winners).length === 0}
              className="gap-2"
            >
              {closing ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Trophy className="h-4 w-4" />
              )}
              Fechar Cotação
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
