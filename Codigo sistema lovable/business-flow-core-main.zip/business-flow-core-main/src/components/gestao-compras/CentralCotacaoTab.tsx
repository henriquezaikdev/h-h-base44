import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { Plus, FileSearch, Loader2, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { toast } from 'sonner';
import { CotacaoSessionDetail } from './CotacaoSessionDetail';
import { NovaCotacaoModal } from './NovaCotacaoModal';

interface CotacaoSessao {
  id: string;
  titulo: string;
  descricao: string | null;
  status: string;
  created_at: string;
  fornecedor_vencedor_id: string | null;
  fechada_em: string | null;
  quote_count: number;
}

const STATUS_MAP: Record<string, { label: string; variant: 'default' | 'secondary' | 'destructive' | 'outline' }> = {
  aberta: { label: 'Aberta', variant: 'secondary' },
  em_comparacao: { label: 'Em Comparação', variant: 'default' },
  fechada: { label: 'Fechada', variant: 'outline' },
  cancelada: { label: 'Cancelada', variant: 'destructive' },
};

interface CentralCotacaoTabProps {
  externalSessionId?: string | null;
  onExternalSessionConsumed?: () => void;
  onNavigateToPainel?: () => void;
}

export function CentralCotacaoTab({ externalSessionId, onExternalSessionConsumed, onNavigateToPainel }: CentralCotacaoTabProps) {
  const { seller } = useAuth();
  const [sessions, setSessions] = useState<CotacaoSessao[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [showNewModal, setShowNewModal] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<string | null>(null);

  // Handle external session opening from Kanban
  useEffect(() => {
    if (externalSessionId) {
      setSelectedId(externalSessionId);
      onExternalSessionConsumed?.();
    }
  }, [externalSessionId]);

  const handleDelete = async (id: string) => {
    try {
      // Delete related quotes first, then session
      await supabase.from('supplier_quotes').delete().eq('session_id', id);
      const { error } = await supabase.from('cotacao_sessoes').delete().eq('id', id);
      if (error) throw error;
      toast.success('Cotação excluída');
      setSessions(prev => prev.filter(s => s.id !== id));
    } catch (err: any) {
      toast.error('Erro ao excluir: ' + (err.message || ''));
    }
    setDeleteTarget(null);
  };

  useEffect(() => {
    fetchSessions();
  }, []);

  const fetchSessions = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('cotacao_sessoes')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;

      // Count quotes per session
      const sessionsData = (data || []) as any[];
      const sessionIds = sessionsData.map(s => s.id);
      
      let quoteCounts: Record<string, number> = {};
      if (sessionIds.length > 0) {
        const { data: quotes } = await supabase
          .from('supplier_quotes')
          .select('id, session_id')
          .in('session_id', sessionIds);
        
        (quotes || []).forEach((q: any) => {
          quoteCounts[q.session_id] = (quoteCounts[q.session_id] || 0) + 1;
        });
      }

      setSessions(sessionsData.map(s => ({
        ...s,
        quote_count: quoteCounts[s.id] || 0,
      })));
    } catch (error) {
      console.error('Error fetching sessions:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSessionCreated = (id: string) => {
    setShowNewModal(false);
    fetchSessions();
    setSelectedId(id);
  };

  if (selectedId) {
    return (
      <CotacaoSessionDetail
        sessionId={selectedId}
        onBack={() => {
          setSelectedId(null);
          fetchSessions();
        }}
        onNavigateToPainel={onNavigateToPainel}
      />
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold">Central de Cotação</h2>
          <p className="text-sm text-muted-foreground">
            Cole textos de WhatsApp ou faça upload de PDFs/imagens — a IA extrai os dados automaticamente
          </p>
        </div>
        <Button onClick={() => setShowNewModal(true)}>
          <Plus className="h-4 w-4 mr-2" />
          Nova Cotação
        </Button>
      </div>

      {loading ? (
        <div className="flex justify-center py-12">
          <Loader2 className="animate-spin h-8 w-8 text-primary" />
        </div>
      ) : sessions.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <FileSearch className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium mb-2">Nenhuma cotação iniciada</h3>
            <p className="text-muted-foreground text-sm mb-4">
              Crie uma sessão de cotação para começar a receber respostas de fornecedores
            </p>
            <Button onClick={() => setShowNewModal(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Criar Primeira Cotação
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-3">
          {sessions.map((session) => {
            const statusConfig = STATUS_MAP[session.status] || STATUS_MAP.aberta;
            return (
              <Card
                key={session.id}
                className="cursor-pointer hover:border-primary/50 transition-colors"
                onClick={() => setSelectedId(session.id)}
              >
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <p className="font-semibold truncate">{session.titulo}</p>
                        <Badge variant={statusConfig.variant}>
                          {statusConfig.label}
                        </Badge>
                      </div>
                      {session.descricao && (
                        <p className="text-sm text-muted-foreground truncate">{session.descricao}</p>
                      )}
                      <p className="text-xs text-muted-foreground mt-1">
                        {format(new Date(session.created_at), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}
                      </p>
                    </div>
                    <div className="flex items-center gap-3 ml-4">
                      <div className="text-center">
                        <p className="text-2xl font-bold text-primary">{session.quote_count}</p>
                        <p className="text-xs text-muted-foreground">fornecedores</p>
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-muted-foreground hover:text-destructive"
                        onClick={(e) => { e.stopPropagation(); setDeleteTarget(session.id); }}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      <NovaCotacaoModal
        open={showNewModal}
        onClose={() => setShowNewModal(false)}
        onCreated={handleSessionCreated}
        sellerId={seller?.id}
      />

      <AlertDialog open={!!deleteTarget} onOpenChange={(v) => !v && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Excluir cotação?</AlertDialogTitle>
            <AlertDialogDescription>
              Esta ação é irreversível. A sessão e todas as respostas de fornecedores serão removidas.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={() => deleteTarget && handleDelete(deleteTarget)}
            >
              Excluir
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
