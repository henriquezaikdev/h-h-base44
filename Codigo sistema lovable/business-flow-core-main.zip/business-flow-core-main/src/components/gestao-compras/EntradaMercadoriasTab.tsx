import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { PackageCheck, Clock, CheckCircle2 } from 'lucide-react';
import { useStockReceipts, usePurchaseImportLines, useLancarEntrada } from '@/hooks/useGestaoComprasData';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { formatCurrency } from '@/lib/utils';

export function EntradaMercadoriasTab() {
  const [selectedReceipt, setSelectedReceipt] = useState<any>(null);
  const { data: receipts = [], isLoading } = useStockReceipts();
  const { data: importLines = [] } = usePurchaseImportLines(selectedReceipt?.purchase_import_id);
  const lancar = useLancarEntrada();

  const [receiptLines, setReceiptLines] = useState<Record<string, { qty: string; cost: string }>>({});

  const handleOpenReceipt = (receipt: any) => {
    setSelectedReceipt(receipt);
    setReceiptLines({});
  };

  const handleLancar = async () => {
    if (!selectedReceipt) return;
    const lines = importLines
      .filter((l: any) => l.matched_product_id)
      .map((l: any) => ({
        product_id: l.matched_product_id,
        qty_received: Number(receiptLines[l.id]?.qty) || l.qty || 0,
        unit_cost: Number(receiptLines[l.id]?.cost) || l.unit_price || 0,
      }))
      .filter(l => l.qty_received > 0);

    if (lines.length === 0) return;
    await lancar.mutateAsync({ receiptId: selectedReceipt.id, lines });
    setSelectedReceipt(null);
  };

  return (
    <div className="space-y-4">
      <h2 className="text-lg font-semibold">Entrada de Mercadorias</h2>

      {isLoading ? (
        <div className="flex justify-center py-16">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
        </div>
      ) : receipts.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center text-muted-foreground">
            Nenhuma entrada pendente. Confirme uma compra para criar uma entrada.
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-2">
          {receipts.map((r: any) => {
            const isLancada = r.status === 'LANCADA';
            return (
              <Card key={r.id} className="cursor-pointer hover:border-primary/40 transition-colors" onClick={() => !isLancada && handleOpenReceipt(r)}>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between gap-3">
                    <div>
                      <p className="font-semibold text-sm">{r.import?.fornecedor?.razao_social || 'Compra'}</p>
                      <p className="text-xs text-muted-foreground">
                        Ref: {r.import?.reference_number || '—'} • {format(new Date(r.created_at), 'dd/MM/yyyy', { locale: ptBR })}
                      </p>
                    </div>
                    <Badge variant="outline" className={`text-[10px] gap-1 ${isLancada ? 'text-emerald-600 border-emerald-300' : 'text-amber-600 border-amber-300'}`}>
                      {isLancada ? <CheckCircle2 className="h-3 w-3" /> : <Clock className="h-3 w-3" />}
                      {isLancada ? 'Lançada' : 'Rascunho'}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      <Sheet open={!!selectedReceipt} onOpenChange={v => !v && setSelectedReceipt(null)}>
        <SheetContent className="sm:max-w-[500px]">
          <SheetHeader>
            <SheetTitle className="flex items-center gap-2">
              <PackageCheck className="h-5 w-5" /> Lançar Entrada
            </SheetTitle>
          </SheetHeader>

          <div className="mt-4 space-y-3">
            {importLines.filter((l: any) => l.matched_product_id).map((l: any) => (
              <div key={l.id} className="p-3 rounded-lg border space-y-2">
                <p className="text-sm font-medium">{l.produto?.name || l.raw_description}</p>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <Label className="text-xs">Qtd Recebida</Label>
                    <Input
                      type="number"
                      className="h-8 text-sm"
                      defaultValue={l.qty}
                      onChange={e => setReceiptLines(prev => ({
                        ...prev,
                        [l.id]: { ...prev[l.id], qty: e.target.value, cost: prev[l.id]?.cost || String(l.unit_price || 0) }
                      }))}
                    />
                  </div>
                  <div>
                    <Label className="text-xs">Custo Unitário</Label>
                    <Input
                      type="number"
                      className="h-8 text-sm"
                      defaultValue={l.unit_price || 0}
                      onChange={e => setReceiptLines(prev => ({
                        ...prev,
                        [l.id]: { ...prev[l.id], cost: e.target.value, qty: prev[l.id]?.qty || String(l.qty || 0) }
                      }))}
                    />
                  </div>
                </div>
              </div>
            ))}

            <Button onClick={handleLancar} disabled={lancar.isPending} className="w-full gap-2">
              <PackageCheck className="h-4 w-4" /> Lançar Entrada
            </Button>
          </div>
        </SheetContent>
      </Sheet>
    </div>
  );
}
