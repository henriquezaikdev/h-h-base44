import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import { Loader2, Check, Search, Plus, Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import { normalizeSupplierQuoteDocumentKind, forceValidDocumentKind } from '@/lib/normalizeSupplierQuoteDocumentKind';
import { NovoFornecedorModal, findFornecedorByCnpj, stripCnpj, isValidCnpj } from './NovoFornecedorModal';
import { ItemHistoricoBadge } from './ItemHistoricoBadge';

interface ExtractedItem {
  descricao: string;
  quantidade: number;
  unidade?: string;
  preco_unitario: number;
  preco_total?: number;
  prazo_entrega_dias?: number;
  observacoes?: string;
  product_id?: string;
  product_match_name?: string;
}

interface ExtractedData {
  fornecedor_nome: string;
  fornecedor_cnpj?: string | null;
  document_kind?: 'PDF' | 'IMAGE';
  data_orcamento?: string | null;
  condicao_pagamento?: string | null;
  prazo_entrega_geral?: number | null;
  valor_frete?: number | null;
  observacoes_gerais?: string | null;
  itens: ExtractedItem[];
}

interface CotacaoReviewFormProps {
  data: ExtractedData;
  sessionId: string;
  onSaved: () => void;
  onCancel: () => void;
}

interface Fornecedor {
  id: string;
  razao_social: string;
  nome_fantasia: string | null;
}

interface ProductOption {
  id: string;
  name: string;
  sku: string | null;
}

export function CotacaoReviewForm({ data: rawData, sessionId, onSaved, onCancel }: CotacaoReviewFormProps) {
  // Força document_kind válido na montagem — protege perda de estado na troca de aba
  const data = { ...rawData, document_kind: forceValidDocumentKind(rawData.document_kind) };
  const { seller } = useAuth();
  const [saving, setSaving] = useState(false);
  const [fornecedores, setFornecedores] = useState<Fornecedor[]>([]);
  const [selectedFornecedorId, setSelectedFornecedorId] = useState<string>('');
  const [fornecedorNome, setFornecedorNome] = useState(data.fornecedor_nome);
  const [fornecedorSearch, setFornecedorSearch] = useState('');
  const [showFornecedorDropdown, setShowFornecedorDropdown] = useState(false);
  const [showNovoFornecedor, setShowNovoFornecedor] = useState(false);

  // CNPJ: extracted by AI or entered manually
  const extractedCnpj = data.fornecedor_cnpj ? stripCnpj(data.fornecedor_cnpj) : '';
  const [manualCnpj, setManualCnpj] = useState('');
  const cnpjNeedsManualInput = !extractedCnpj; // AI didn't extract CNPJ
  const effectiveCnpj = extractedCnpj || stripCnpj(manualCnpj);

  const [dataOrcamento, setDataOrcamento] = useState(() => {
    const raw = data.data_orcamento || '';
    const ddmmyyyy = raw.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
    if (ddmmyyyy) return `${ddmmyyyy[3]}-${ddmmyyyy[2]}-${ddmmyyyy[1]}`;
    return raw;
  });
  const [condicaoPagamento, setCondicaoPagamento] = useState(data.condicao_pagamento || '');
  const [prazoGeral, setPrazoGeral] = useState(data.prazo_entrega_geral?.toString() || '');
  const [valorFrete, setValorFrete] = useState(data.valor_frete?.toString() || '');
  const [observacoes, setObservacoes] = useState(data.observacoes_gerais || '');
  const [validadeOrcamento, setValidadeOrcamento] = useState('');
  const [itens, setItens] = useState<ExtractedItem[]>(data.itens.map(i => ({
    ...i,
    unidade: i.unidade || 'un',
    preco_total: i.preco_total || i.quantidade * i.preco_unitario,
  })));

  // Validation errors
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const [itemErrors, setItemErrors] = useState<Record<string, string>>({});
  const [submitted, setSubmitted] = useState(false);

  // Product search
  const [products, setProducts] = useState<ProductOption[]>([]);
  const [productSearch, setProductSearch] = useState('');
  const [searchingProducts, setSearchingProducts] = useState(false);
  const [editingItemIdx, setEditingItemIdx] = useState<number | null>(null);

  useEffect(() => {
    fetchFornecedores();
  }, []);

  // Auto-match by CNPJ when AI extracted it
  useEffect(() => {
    if (extractedCnpj && extractedCnpj.length === 14) {
      findFornecedorByCnpj(extractedCnpj).then(match => {
        if (match) {
          setSelectedFornecedorId(match.id);
          setFornecedores(prev => {
            if (prev.find(f => f.id === match.id)) return prev;
            return [...prev, match];
          });
          toast.info(`Fornecedor "${match.nome_fantasia || match.razao_social}" vinculado automaticamente pelo CNPJ.`);
        }
      });
    }
  }, [extractedCnpj]);

  useEffect(() => {
    if (productSearch.length >= 2) {
      searchProducts(productSearch);
    }
  }, [productSearch]);

  const fetchFornecedores = async () => {
    const { data } = await supabase
      .from('fornecedores')
      .select('id, razao_social, nome_fantasia')
      .eq('ativo', true)
      .order('razao_social');
    setFornecedores(data || []);

    // Auto-match by CNPJ first, then fallback to name
    if (data && !selectedFornecedorId) {
      // If we have a CNPJ from AI, the useEffect above handles it
      if (!extractedCnpj) {
        const match = data.find(f =>
          f.razao_social.toLowerCase().includes(fornecedorNome.toLowerCase()) ||
          (f.nome_fantasia && f.nome_fantasia.toLowerCase().includes(fornecedorNome.toLowerCase()))
        );
        if (match) setSelectedFornecedorId(match.id);
      }
    }
  };

  const filteredFornecedores = fornecedorSearch.length >= 1
    ? fornecedores.filter(f =>
        f.razao_social.toLowerCase().includes(fornecedorSearch.toLowerCase()) ||
        (f.nome_fantasia && f.nome_fantasia.toLowerCase().includes(fornecedorSearch.toLowerCase()))
      )
    : fornecedores;

  const selectedFornecedor = fornecedores.find(f => f.id === selectedFornecedorId);

  const searchProducts = async (term: string) => {
    setSearchingProducts(true);
    const { data } = await supabase
      .from('products')
      .select('id, name, sku')
      .or(`name.ilike.%${term}%,sku.ilike.%${term}%`)
      .eq('active', true)
      .limit(10);
    setProducts(data || []);
    setSearchingProducts(false);
  };

  const handleItemChange = (idx: number, field: string, value: any) => {
    setItens(prev => prev.map((item, i) => {
      if (i !== idx) return item;
      const updated = { ...item, [field]: value };
      if (field === 'quantidade' || field === 'preco_unitario') {
        updated.preco_total = (updated.quantidade || 0) * (updated.preco_unitario || 0);
      }
      return updated;
    }));
    // Clear item error
    if (submitted) {
      setItemErrors(prev => {
        const next = { ...prev };
        delete next[`${idx}_${field}`];
        return next;
      });
    }
  };

  const handleLinkProduct = (idx: number, product: ProductOption) => {
    setItens(prev => prev.map((item, i) =>
      i === idx ? { ...item, product_id: product.id, product_match_name: product.name } : item
    ));
    setEditingItemIdx(null);
    setProductSearch('');
  };

  const handleRemoveItem = (idx: number) => {
    setItens(prev => prev.filter((_, i) => i !== idx));
  };

  const handleAddItem = () => {
    setItens(prev => [...prev, {
      descricao: '',
      quantidade: 1,
      unidade: 'un',
      preco_unitario: 0,
      preco_total: 0,
    }]);
  };

  const handleFornecedorCreated = (f: { id: string; razao_social: string; nome_fantasia: string | null }) => {
    setFornecedores(prev => [...prev, f]);
    setSelectedFornecedorId(f.id);
    setFornecedorSearch('');
    if (submitted) setFieldErrors(prev => ({ ...prev, fornecedor: '' }));
  };

  const totalGeral = itens.reduce((sum, i) => sum + (i.preco_total || 0), 0) + parseFloat(valorFrete || '0');

  const validate = (): boolean => {
    const fErrs: Record<string, string> = {};
    const iErrs: Record<string, string> = {};

    if (!selectedFornecedorId) {
      fErrs.fornecedor = 'Selecione ou cadastre um fornecedor';
      // If no fornecedor selected and CNPJ is required manually, validate it
      if (cnpjNeedsManualInput && !isValidCnpj(manualCnpj)) {
        fErrs.cnpj = 'CNPJ é obrigatório (14 dígitos numéricos)';
      }
    }
    if (itens.length === 0) fErrs.itens = 'Adicione pelo menos um item à cotação';

    itens.forEach((item, idx) => {
      if (!item.preco_unitario || item.preco_unitario <= 0) {
        iErrs[`${idx}_preco_unitario`] = 'Informe o preço unitário';
      }
      if (!item.quantidade || item.quantidade <= 0) {
        iErrs[`${idx}_quantidade`] = 'Informe a quantidade';
      }
    });

    setFieldErrors(fErrs);
    setItemErrors(iErrs);
    return Object.keys(fErrs).length === 0 && Object.keys(iErrs).length === 0;
  };

  const handleSave = async () => {
    setSubmitted(true);
    const isValid = validate();
    if (!isValid) {
      toast.error('Revise os campos obrigatórios antes de salvar.');
      return;
    }

    setSaving(true);
    try {
      // Resolve created_by: FK aponta para auth.users(id), NÃO sellers(id)
      const { data: { user } } = await supabase.auth.getUser();
      const createdBy = user?.id ?? null;

      if (!createdBy) {
        toast.error('Usuário não identificado. Faça login novamente.');
        setSaving(false);
        return;
      }

      // Resolve fornecedor by selection or CNPJ (lookup/create)
      let supplierId = selectedFornecedorId;
      if (!supplierId) {
        const cnpjDigits = stripCnpj(effectiveCnpj);

        if (!isValidCnpj(cnpjDigits)) {
          toast.error('Informe um CNPJ válido (14 dígitos) para continuar.');
          return;
        }

        const existing = await findFornecedorByCnpj(cnpjDigits);
        if (existing) {
          supplierId = existing.id;
          setSelectedFornecedorId(existing.id);
          setFornecedores((prev) => prev.some((f) => f.id === existing.id) ? prev : [...prev, existing]);
        } else {
          const { data: createdSupplier, error: supplierError } = await supabase
            .from('fornecedores')
            .insert({
              razao_social: fornecedorNome?.trim() || 'Fornecedor sem nome',
              nome_fantasia: null,
              cnpj: cnpjDigits,
              ativo: true,
            })
            .select('id, razao_social, nome_fantasia')
            .single();

          if (supplierError) throw supplierError;
          supplierId = createdSupplier.id;
          setSelectedFornecedorId(createdSupplier.id);
          setFornecedores((prev) => [...prev, createdSupplier]);
        }
      }

      // 1. Create supplier_quote
      const quotePayload = {
        session_id: sessionId,
        supplier_id: supplierId,
        document_kind: forceValidDocumentKind(
          normalizeSupplierQuoteDocumentKind({
            documentKind: data.document_kind,
          })
        ),
        document_date: dataOrcamento || null,
        notes: [condicaoPagamento, validadeOrcamento ? `Válido até: ${validadeOrcamento}` : '', observacoes].filter(Boolean).join(' | ') || null,
        status: 'CONFIRMADO',
        created_by: createdBy,
      };

      const { data: quoteData, error: quoteError } = await supabase
        .from('supplier_quotes')
        .insert(quotePayload)
        .select('id')
        .single();

      if (quoteError) throw quoteError;

      // 2. Create quote lines (save supplier + items together)
      const linesPayload = itens.map((item, index) => ({
        supplier_quote_id: quoteData.id,
        line_index: index,
        raw_description: item.descricao?.trim() || `Item ${index + 1}`,
        qty: item.quantidade || 1,
        unit: item.unidade || 'un',
        unit_price: item.preco_unitario || null,
        total_price: item.preco_total ?? ((item.quantidade || 1) * (item.preco_unitario || 0)),
        product_id: item.product_id || null,
        payment_terms: condicaoPagamento || null,
        delivery_days: item.prazo_entrega_dias ?? (prazoGeral ? Number(prazoGeral) : null),
        observations: item.observacoes || null,
        is_winner: false,
      }));

      const { error: linesError } = await supabase
        .from('supplier_quote_lines')
        .insert(linesPayload);

      if (linesError) {
        // rollback quote to avoid quote with zero items
        await supabase.from('supplier_quotes').delete().eq('id', quoteData.id);
        throw linesError;
      }

      // 3. Advance solicitacao status if linked
      try {
        const { data: sessionData } = await supabase
          .from('cotacao_sessoes')
          .select('solicitacao_compra_id')
          .eq('id', sessionId)
          .single();

        // Status advance removed — status should only change when the buyer
        // explicitly closes the quotation via the Comparativo "Fechar Cotação" button.
      } catch (statusErr) {
        console.warn('Falha ao avançar status da solicitação:', statusErr);
      }

      toast.success('Cotação salva com sucesso!');
      onSaved();
    } catch (error: any) {
      console.error('Error:', error);
      toast.error(`Erro: ${error?.message || 'Tente novamente.'}`);
    } finally {
      setSaving(false);
    }
  };

  const formatCurrency = (v: number) =>
    new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(v);

  return (
    <Card className="border-primary/30">
      <CardHeader className="pb-3">
        <CardTitle className="text-base">Revisar Dados Extraídos</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Fornecedor */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>Fornecedor *</Label>
            {selectedFornecedor ? (
              <div className="flex items-center gap-2 p-2.5 rounded-md bg-muted border text-sm">
                <span className="flex-1 font-medium">
                  {selectedFornecedor.nome_fantasia || selectedFornecedor.razao_social}
                </span>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-6 px-2 text-xs"
                  onClick={() => { setSelectedFornecedorId(''); setFornecedorSearch(''); }}
                >
                  Trocar
                </Button>
              </div>
            ) : (
              <div className="relative">
                <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
                <Input
                  placeholder="Buscar fornecedor..."
                  value={fornecedorSearch}
                  onChange={e => { setFornecedorSearch(e.target.value); setShowFornecedorDropdown(true); }}
                  onFocus={() => setShowFornecedorDropdown(true)}
                  onBlur={() => setTimeout(() => setShowFornecedorDropdown(false), 200)}
                  className="pl-8"
                />
                {showFornecedorDropdown && (
                  <div className="absolute z-50 top-full mt-1 w-full bg-background border rounded-md shadow-lg max-h-52 overflow-auto">
                    {filteredFornecedores.length === 0 ? (
                      <div className="p-2">
                        <p className="text-sm text-muted-foreground text-center py-1">Nenhum fornecedor encontrado</p>
                        <button
                          className="w-full text-left px-3 py-2 text-sm font-medium text-primary hover:bg-accent rounded transition-colors flex items-center gap-1.5"
                          onMouseDown={() => { setShowFornecedorDropdown(false); setShowNovoFornecedor(true); }}
                        >
                          <Plus className="h-3.5 w-3.5" />
                          Cadastrar novo fornecedor
                        </button>
                      </div>
                    ) : (
                      <>
                        {filteredFornecedores.map(f => (
                          <button
                            key={f.id}
                            className="w-full text-left px-3 py-2 text-sm hover:bg-accent transition-colors"
                            onMouseDown={() => {
                              setSelectedFornecedorId(f.id);
                              setFornecedorSearch('');
                              setShowFornecedorDropdown(false);
                              if (submitted) setFieldErrors(prev => ({ ...prev, fornecedor: '' }));
                            }}
                          >
                            {f.nome_fantasia || f.razao_social}
                          </button>
                        ))}
                        <div className="border-t">
                          <button
                            className="w-full text-left px-3 py-2 text-sm font-medium text-primary hover:bg-accent transition-colors flex items-center gap-1.5"
                            onMouseDown={() => { setShowFornecedorDropdown(false); setShowNovoFornecedor(true); }}
                          >
                            <Plus className="h-3.5 w-3.5" />
                            Cadastrar novo fornecedor
                          </button>
                        </div>
                      </>
                    )}
                  </div>
                )}
              </div>
            )}
            {fieldErrors.fornecedor && (
              <p className="text-xs text-destructive">{fieldErrors.fornecedor}</p>
            )}
            <p className="text-xs text-muted-foreground">
              IA detectou: <strong>{fornecedorNome}</strong>
              {extractedCnpj && <> · CNPJ: <strong>{extractedCnpj.replace(/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/, '$1.$2.$3/$4-$5')}</strong></>}
            </p>
            {/* CNPJ manual input when AI didn't extract it and no supplier selected */}
            {cnpjNeedsManualInput && !selectedFornecedorId && (
              <div className="mt-2 space-y-1">
                <Label className="text-xs">CNPJ do Fornecedor *</Label>
                <Input
                  placeholder="00.000.000/0000-00"
                  value={manualCnpj}
                  onChange={e => { setManualCnpj(e.target.value); if (submitted) setFieldErrors(prev => ({ ...prev, cnpj: '' })); }}
                  className={fieldErrors.cnpj ? 'border-destructive' : ''}
                />
                {fieldErrors.cnpj && <p className="text-xs text-destructive">{fieldErrors.cnpj}</p>}
                <p className="text-[10px] text-muted-foreground">A IA não conseguiu extrair o CNPJ. Preencha manualmente.</p>
              </div>
            )}
          </div>

          <div className="space-y-2">
            <Label>Data do Orçamento</Label>
            <Input
              type="date"
              value={dataOrcamento}
              onChange={(e) => setDataOrcamento(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label>Validade do Orçamento</Label>
            <Input
              type="date"
              value={validadeOrcamento}
              onChange={(e) => setValidadeOrcamento(e.target.value)}
            />
            <p className="text-[11px] text-muted-foreground">Até quando este orçamento é válido</p>
          </div>

          <div className="space-y-2">
            <Label>Condição de Pagamento</Label>
            <Input
              value={condicaoPagamento}
              onChange={(e) => setCondicaoPagamento(e.target.value)}
              placeholder="Ex: 30/60/90 dias"
            />
          </div>

          <div className="space-y-2">
            <Label>Prazo de Entrega (dias)</Label>
            <Input
              type="number"
              value={prazoGeral}
              onChange={(e) => setPrazoGeral(e.target.value)}
              placeholder="Ex: 15"
            />
          </div>

          <div className="space-y-2">
            <Label>Valor do Frete</Label>
            <Input
              value={valorFrete}
              onChange={(e) => setValorFrete(e.target.value)}
              placeholder="0,00"
            />
          </div>
        </div>

        {/* Items table */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <Label>Itens ({itens.length})</Label>
            <Button
              variant="outline"
              size="sm"
              className="gap-1.5 text-xs border-primary text-primary hover:bg-accent"
              onClick={handleAddItem}
            >
              <Plus className="h-3.5 w-3.5" />
              Adicionar Item
            </Button>
          </div>

          {fieldErrors.itens && (
            <p className="text-xs text-destructive mb-2">{fieldErrors.itens}</p>
          )}

          {itens.length > 0 && (
            <div className="rounded-md border overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[30%]">Descrição</TableHead>
                    <TableHead className="w-[100px]">Qtd</TableHead>
                    <TableHead className="w-[60px]">Un.</TableHead>
                    <TableHead className="text-right w-[120px]">Preço Unit.</TableHead>
                    <TableHead className="text-right w-[120px]">Total</TableHead>
                    <TableHead className="w-[160px]">Produto Vinculado</TableHead>
                    <TableHead className="w-[60px]"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {itens.map((item, idx) => (
                    <TableRow key={idx}>
                      <TableCell>
                        <Input
                          value={item.descricao}
                          onChange={(e) => handleItemChange(idx, 'descricao', e.target.value)}
                          className="h-8 text-sm"
                        />
                      </TableCell>
                      <TableCell>
                        <div>
                          <Input
                            type="number"
                            value={item.quantidade}
                            onChange={(e) => handleItemChange(idx, 'quantidade', parseFloat(e.target.value) || 0)}
                            className={`h-8 text-sm w-20 ${itemErrors[`${idx}_quantidade`] ? 'border-destructive' : ''}`}
                          />
                          {itemErrors[`${idx}_quantidade`] && (
                            <p className="text-[10px] text-destructive mt-0.5">{itemErrors[`${idx}_quantidade`]}</p>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Input
                          value={item.unidade}
                          onChange={(e) => handleItemChange(idx, 'unidade', e.target.value)}
                          className="h-8 text-sm w-14"
                        />
                      </TableCell>
                      <TableCell className="text-right">
                        <div>
                          <Input
                            type="number"
                            step="0.01"
                            value={item.preco_unitario}
                            onChange={(e) => handleItemChange(idx, 'preco_unitario', parseFloat(e.target.value) || 0)}
                            className={`h-8 text-sm w-28 text-right ${itemErrors[`${idx}_preco_unitario`] ? 'border-destructive' : ''}`}
                          />
                          {itemErrors[`${idx}_preco_unitario`] && (
                            <p className="text-[10px] text-destructive mt-0.5">{itemErrors[`${idx}_preco_unitario`]}</p>
                          )}
                        </div>
                      </TableCell>
                      <TableCell className="text-right font-mono text-sm">
                        {formatCurrency(item.preco_total || 0)}
                      </TableCell>
                      <TableCell>
                        {item.product_id ? (
                          <div className="flex flex-col gap-1">
                            <Badge variant="outline" className="bg-emerald-50 text-emerald-700 border-emerald-200 text-xs dark:bg-emerald-950/20">
                              ✓ {item.product_match_name?.substring(0, 20)}
                            </Badge>
                            {/* BLOCO 4: History badge */}
                            <ItemHistoricoBadge productId={item.product_id} />
                          </div>
                        ) : editingItemIdx === idx ? (
                          <div className="relative">
                            <Input
                              value={productSearch}
                              onChange={(e) => setProductSearch(e.target.value)}
                              placeholder="Buscar..."
                              className="h-7 text-xs pr-6"
                              autoFocus
                              onBlur={() => setTimeout(() => setEditingItemIdx(null), 200)}
                            />
                            {products.length > 0 && productSearch.length >= 2 && (
                              <div className="absolute top-8 left-0 right-0 bg-background border rounded-md shadow-lg z-50 max-h-40 overflow-y-auto">
                                {products.map(p => (
                                  <button
                                    key={p.id}
                                    className="w-full text-left px-2 py-1.5 text-xs hover:bg-accent transition-colors"
                                    onMouseDown={() => handleLinkProduct(idx, p)}
                                  >
                                    {p.name} {p.sku && <span className="text-muted-foreground">({p.sku})</span>}
                                  </button>
                                ))}
                              </div>
                            )}
                          </div>
                        ) : (
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-7 text-xs"
                            onClick={() => {
                              setEditingItemIdx(idx);
                              setProductSearch(item.descricao.substring(0, 20));
                            }}
                          >
                            <Search className="h-3 w-3 mr-1" />
                            Vincular
                          </Button>
                        )}
                      </TableCell>
                      <TableCell>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-6 w-6 text-muted-foreground hover:text-destructive hover:bg-destructive/10"
                          onClick={() => handleRemoveItem(idx)}
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}

          <div className="flex justify-end mt-2 pr-2">
            <p className="text-sm font-semibold">
              Total: <span className="text-lg">{formatCurrency(totalGeral)}</span>
            </p>
          </div>
        </div>

        {/* Actions */}
        <div className="flex justify-end gap-2 pt-4 border-t">
          <Button variant="outline" onClick={onCancel} className="hover:bg-muted">
            Cancelar
          </Button>
          <Button
            onClick={handleSave}
            disabled={saving}
          >
            {saving ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                Salvando...
              </>
            ) : (
              <>
                <Check className="h-4 w-4" />
                Confirmar e Salvar
              </>
            )}
          </Button>
        </div>
      </CardContent>

      {/* Novo Fornecedor sub-modal */}
      <NovoFornecedorModal
        open={showNovoFornecedor}
        onClose={() => setShowNovoFornecedor(false)}
        onCreated={handleFornecedorCreated}
      />
    </Card>
  );
}
