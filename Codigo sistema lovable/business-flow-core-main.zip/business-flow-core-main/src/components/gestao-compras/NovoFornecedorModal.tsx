import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Loader2 } from 'lucide-react';
import { toast } from 'sonner';

/** Strip non-digits from CNPJ string */
export function stripCnpj(raw: string): string {
  return raw.replace(/\D/g, '');
}

/** Validate CNPJ has exactly 14 digits */
export function isValidCnpj(raw: string): boolean {
  return stripCnpj(raw).length === 14;
}

/** Format CNPJ as 00.000.000/0000-00 */
export function formatCnpj(raw: string): string {
  const d = stripCnpj(raw);
  if (d.length !== 14) return raw;
  return `${d.slice(0,2)}.${d.slice(2,5)}.${d.slice(5,8)}/${d.slice(8,12)}-${d.slice(12,14)}`;
}

/** Lookup existing fornecedor by CNPJ (digits only). Returns null if not found. */
export async function findFornecedorByCnpj(cnpjDigits: string): Promise<{ id: string; razao_social: string; nome_fantasia: string | null } | null> {
  // Search both formatted and digits-only since DB may store either
  const { data } = await supabase
    .from('fornecedores')
    .select('id, razao_social, nome_fantasia, cnpj')
    .eq('ativo', true);

  if (!data) return null;

  const match = data.find(f => f.cnpj && stripCnpj(f.cnpj) === cnpjDigits);
  return match ? { id: match.id, razao_social: match.razao_social, nome_fantasia: match.nome_fantasia } : null;
}

interface NovoFornecedorModalProps {
  open: boolean;
  onClose: () => void;
  onCreated: (fornecedor: { id: string; razao_social: string; nome_fantasia: string | null }) => void;
  initialCnpj?: string;
}

export function NovoFornecedorModal({ open, onClose, onCreated, initialCnpj }: NovoFornecedorModalProps) {
  const [razaoSocial, setRazaoSocial] = useState('');
  const [nomeFantasia, setNomeFantasia] = useState('');
  const [cnpj, setCnpj] = useState(initialCnpj || '');
  const [telefone, setTelefone] = useState('');
  const [email, setEmail] = useState('');
  const [observacao, setObservacao] = useState('');
  const [saving, setSaving] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const resetForm = () => {
    setRazaoSocial('');
    setNomeFantasia('');
    setCnpj('');
    setTelefone('');
    setEmail('');
    setObservacao('');
    setErrors({});
  };

  const validate = () => {
    const errs: Record<string, string> = {};
    if (!razaoSocial.trim()) errs.razaoSocial = 'Razão social é obrigatória';
    
    const cnpjDigits = stripCnpj(cnpj);
    if (!cnpjDigits) {
      errs.cnpj = 'CNPJ é obrigatório';
    } else if (cnpjDigits.length !== 14) {
      errs.cnpj = 'CNPJ deve ter 14 dígitos numéricos';
    }
    
    if (email.trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) errs.email = 'E-mail inválido';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSave = async () => {
    if (!validate()) return;

    setSaving(true);
    try {
      const cnpjDigits = stripCnpj(cnpj);

      // Deduplicate by CNPJ: check if fornecedor already exists
      const existing = await findFornecedorByCnpj(cnpjDigits);
      if (existing) {
        toast.info(`Fornecedor "${existing.nome_fantasia || existing.razao_social}" já cadastrado com este CNPJ. Vinculado automaticamente.`);
        onCreated(existing);
        resetForm();
        onClose();
        return;
      }

      const { data, error } = await supabase
        .from('fornecedores')
        .insert({
          razao_social: razaoSocial.trim(),
          nome_fantasia: nomeFantasia.trim() || null,
          cnpj: formatCnpj(cnpjDigits),
          telefone: telefone.trim() || null,
          email: email.trim() || null,
          observacoes: observacao.trim() || null,
          ativo: true,
        })
        .select('id, razao_social, nome_fantasia')
        .single();

      if (error) throw error;

      toast.success('Fornecedor cadastrado com sucesso');
      onCreated(data);
      resetForm();
      onClose();
    } catch (err: any) {
      console.error('Error creating fornecedor:', err);
      toast.error(err.message || 'Erro ao cadastrar fornecedor');
    } finally {
      setSaving(false);
    }
  };

  const handleClose = () => {
    resetForm();
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={v => !v && handleClose()}>
      <DialogContent className="sm:max-w-[460px]">
        <DialogHeader>
          <DialogTitle>Cadastrar Novo Fornecedor</DialogTitle>
        </DialogHeader>

        <div className="grid gap-4 py-2">
          <div className="grid gap-1.5">
            <Label>Razão Social *</Label>
            <Input
              placeholder="Nome da empresa"
              value={razaoSocial}
              onChange={e => { setRazaoSocial(e.target.value); setErrors(prev => ({ ...prev, razaoSocial: '' })); }}
            />
            {errors.razaoSocial && <p className="text-xs text-destructive">{errors.razaoSocial}</p>}
          </div>

          <div className="grid gap-1.5">
            <Label>Nome Fantasia</Label>
            <Input
              placeholder="Nome fantasia (opcional)"
              value={nomeFantasia}
              onChange={e => setNomeFantasia(e.target.value)}
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="grid gap-1.5">
              <Label>CNPJ *</Label>
              <Input
                placeholder="00.000.000/0000-00"
                value={cnpj}
                onChange={e => { setCnpj(e.target.value); setErrors(prev => ({ ...prev, cnpj: '' })); }}
              />
              {errors.cnpj && <p className="text-xs text-destructive">{errors.cnpj}</p>}
            </div>
            <div className="grid gap-1.5">
              <Label>Telefone</Label>
              <Input
                placeholder="(00) 00000-0000"
                value={telefone}
                onChange={e => setTelefone(e.target.value)}
              />
            </div>
          </div>

          <div className="grid gap-1.5">
            <Label>E-mail</Label>
            <Input
              placeholder="contato@empresa.com"
              value={email}
              onChange={e => { setEmail(e.target.value); setErrors(prev => ({ ...prev, email: '' })); }}
            />
            {errors.email && <p className="text-xs text-destructive">{errors.email}</p>}
          </div>

          <div className="grid gap-1.5">
            <Label>Observação</Label>
            <Textarea
              placeholder="Observações sobre o fornecedor..."
              value={observacao}
              onChange={e => setObservacao(e.target.value)}
              rows={2}
            />
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={handleClose} className="hover:bg-muted">
            Cancelar
          </Button>
          <Button
            onClick={handleSave}
            disabled={saving || !razaoSocial.trim() || !stripCnpj(cnpj)}
          >
            {saving ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                Salvando...
              </>
            ) : (
              'Salvar Fornecedor'
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
