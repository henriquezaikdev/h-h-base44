import { useState, useRef } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Loader2, Upload, Sparkles, FileText, Image, X, Zap, Brain } from 'lucide-react';
import { toast } from 'sonner';
import { Badge } from '@/components/ui/badge';

interface ExtractedData {
  fornecedor_nome: string;
  fornecedor_cnpj?: string | null;
  document_kind?: 'PDF' | 'IMAGE';
  data_orcamento?: string | null;
  condicao_pagamento?: string | null;
  prazo_entrega_geral?: number | null;
  valor_frete?: number | null;
  observacoes_gerais?: string | null;
  _extraction_mode?: string;
  _extraction_reason?: string;
  itens: {
    descricao: string;
    quantidade: number;
    unidade?: string;
    preco_unitario: number;
    preco_total?: number;
    prazo_entrega_dias?: number;
    observacoes?: string;
  }[];
}

interface CotacaoInputPanelProps {
  sessionId: string;
  onExtracted: (data: ExtractedData) => void;
}

type ExtractionMode = 'auto' | 'rapida' | 'ia';

export function CotacaoInputPanel({ sessionId, onExtracted }: CotacaoInputPanelProps) {
  const [text, setText] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [processing, setProcessing] = useState(false);
  const [extractionMode, setExtractionMode] = useState<ExtractionMode>('auto');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selected = e.target.files?.[0];
    if (!selected) return;

    const validTypes = ['application/pdf', 'image/jpeg', 'image/png', 'image/webp'];
    if (!validTypes.includes(selected.type)) {
      toast.error('Formato não suportado. Use PDF, JPG, PNG ou WebP.');
      return;
    }

    if (selected.size > 10 * 1024 * 1024) {
      toast.error('Arquivo muito grande. Máximo 10MB.');
      return;
    }

    setFile(selected);
  };

  const handleExtract = async () => {
    if (!text.trim() && !file) {
      toast.error('Cole um texto ou anexe um arquivo');
      return;
    }

    setProcessing(true);
    try {
      let fileBase64: string | undefined;
      let fileMimeType: string | undefined;
      let fileName: string | undefined;

      if (file) {
        const buffer = await file.arrayBuffer();
        fileBase64 = btoa(
          new Uint8Array(buffer).reduce((data, byte) => data + String.fromCharCode(byte), '')
        );
        fileMimeType = file.type;
        fileName = file.name;
      }

      const { data, error } = await supabase.functions.invoke('cotacao-extrair-dados', {
        body: {
          text: text.trim() || undefined,
          fileBase64,
          fileMimeType,
          fileName,
          extractionMode: extractionMode === 'auto' ? undefined : extractionMode,
        },
      });

      if (error) throw error;

      if (data.error) {
        toast.error(data.error);
        return;
      }

      if (!data.itens || data.itens.length === 0) {
        toast.error('Nenhum item encontrado no conteúdo');
        return;
      }

      const modeLabel = data._extraction_mode === 'regex' ? '⚡ Regex (grátis)' : '🧠 IA';
      toast.success(`${data.itens.length} itens extraídos de "${data.fornecedor_nome}" via ${modeLabel}`);
      onExtracted(data);
      setText('');
      setFile(null);
    } catch (error: any) {
      console.error('Extraction error:', error);
      if (error?.status === 429) {
        toast.error('Limite de requisições excedido. Aguarde alguns segundos.');
      } else if (error?.status === 402) {
        toast.error('Créditos insuficientes para IA.');
      } else {
        toast.error('Erro ao extrair dados. Tente novamente.');
      }
    } finally {
      setProcessing(false);
    }
  };

  const hasFile = !!file;
  const isImageOrPdf = hasFile && (file?.type.startsWith('image/') || file?.type === 'application/pdf');

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2">
          <Sparkles className="h-4 w-4 text-primary" />
          Adicionar Resposta de Fornecedor
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Text input */}
        <div className="space-y-2">
          <Label className="text-sm">Texto do WhatsApp / E-mail</Label>
          <Textarea
            placeholder="Cole aqui a resposta do fornecedor recebida por WhatsApp, e-mail ou qualquer texto com os preços..."
            value={text}
            onChange={(e) => setText(e.target.value)}
            rows={6}
            className="resize-none"
          />
        </div>

        {/* File upload */}
        <div className="space-y-2">
          <Label className="text-sm">PDF / Imagem do Orçamento (opcional)</Label>
          <input
            ref={fileInputRef}
            type="file"
            accept=".pdf,.jpg,.jpeg,.png,.webp"
            onChange={handleFileSelect}
            className="hidden"
          />
          
          {file ? (
            <div className="flex items-center gap-2 p-3 bg-muted/50 rounded-lg border">
              {file.type === 'application/pdf' ? (
                <FileText className="h-5 w-5 text-red-500 shrink-0" />
              ) : (
                <Image className="h-5 w-5 text-blue-500 shrink-0" />
              )}
              <span className="text-sm flex-1 truncate">{file.name}</span>
              <span className="text-xs text-muted-foreground">
                {(file.size / 1024).toFixed(0)} KB
              </span>
              <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => setFile(null)}>
                <X className="h-3 w-3" />
              </Button>
            </div>
          ) : (
            <Button
              variant="outline"
              className="w-full h-20 border-dashed"
              onClick={() => fileInputRef.current?.click()}
            >
              <Upload className="h-5 w-5 mr-2 text-muted-foreground" />
              <span className="text-muted-foreground">
                Clique para anexar PDF ou imagem
              </span>
            </Button>
          )}
        </div>

        {/* Extraction mode selector */}
        <div className="space-y-2">
          <Label className="text-sm">Modo de Extração</Label>
          <div className="flex gap-2">
            <Button
              type="button"
              variant={extractionMode === 'auto' ? 'default' : 'outline'}
              size="sm"
              className="flex-1"
              onClick={() => setExtractionMode('auto')}
            >
              <Sparkles className="h-3.5 w-3.5 mr-1.5" />
              Auto
            </Button>
            <Button
              type="button"
              variant={extractionMode === 'rapida' ? 'default' : 'outline'}
              size="sm"
              className="flex-1"
              onClick={() => setExtractionMode('rapida')}
              disabled={isImageOrPdf && !text.trim()}
            >
              <Zap className="h-3.5 w-3.5 mr-1.5" />
              Rápida
              <Badge variant="secondary" className="ml-1.5 text-[10px] px-1 py-0">
                Grátis
              </Badge>
            </Button>
            <Button
              type="button"
              variant={extractionMode === 'ia' ? 'default' : 'outline'}
              size="sm"
              className="flex-1"
              onClick={() => setExtractionMode('ia')}
            >
              <Brain className="h-3.5 w-3.5 mr-1.5" />
              IA Profunda
            </Button>
          </div>
          <p className="text-xs text-muted-foreground">
            {extractionMode === 'auto' && 'O sistema decide automaticamente: textos simples usam regex (grátis), complexos usam IA.'}
            {extractionMode === 'rapida' && 'Usa regex local sem custo. Ideal para textos curtos de WhatsApp com poucos itens.'}
            {extractionMode === 'ia' && 'Usa IA para máxima precisão. Consome créditos. Ideal para PDFs, imagens e textos complexos.'}
          </p>
        </div>

        {/* Extract button */}
        <Button
          className="w-full"
          onClick={handleExtract}
          disabled={processing || (!text.trim() && !file)}
        >
          {processing ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin mr-2" />
              Extraindo dados...
            </>
          ) : (
            <>
              {extractionMode === 'rapida' ? (
                <Zap className="h-4 w-4 mr-2" />
              ) : (
                <Sparkles className="h-4 w-4 mr-2" />
              )}
              {extractionMode === 'rapida' ? 'Extrair (Regex)' : extractionMode === 'ia' ? 'Extrair com IA' : 'Extrair'}
            </>
          )}
        </Button>
      </CardContent>
    </Card>
  );
}
