import { useState, useEffect, useCallback } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle
} from '@/components/ui/alert-dialog';
import { Upload, Plus, Trash2, CheckCircle2, Search, ArrowRight, ArrowLeft, Loader2, AlertTriangle, Package, Sparkles } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useFornecedores, useSaveFornecedor } from '@/hooks/useComprasData';
import {
  useCreatePurchaseImport, usePurchaseImportLines, useAddPurchaseImportLine,
  useUpdatePurchaseImportLine, useDeletePurchaseImportLine, useConfirmPurchaseImport,
  useUpdatePurchaseImport,
} from '@/hooks/useGestaoComprasData';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { formatCurrency } from '@/lib/utils';

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  importId: string | null;
}

const STEPS = ['Upload', 'Itens', 'Match', 'Revisão', 'Confirmar'];

export function ImportCompraWizard({ open, onOpenChange, importId }: Props) {
  const [step, setStep] = useState(0);
  const [currentImportId, setCurrentImportId] = useState<string | null>(importId);
  const [showConfirm, setShowConfirm] = useState(false);
  const queryClient = useQueryClient();

  // Step 1 state
  const [file, setFile] = useState<File | null>(null);
  const [filePreview, setFilePreview] = useState<string | null>(null);
  const [supplierId, setSupplierId] = useState('');
  const [docDate, setDocDate] = useState('');
  const [refNumber, setRefNumber] = useState('');
  const [notes, setNotes] = useState('');
  const [newSupplierName, setNewSupplierName] = useState('');
  const [showNewSupplier, setShowNewSupplier] = useState(false);
  const [extracting, setExtracting] = useState(false);
  const [extractedInfo, setExtractedInfo] = useState<{ supplier_name?: string; document_number?: string; document_date?: string; notes?: string } | null>(null);
  const [autoSupplierCreated, setAutoSupplierCreated] = useState(false);

  // Step 2 state - manual lines
  const [manualDesc, setManualDesc] = useState('');
  const [manualQty, setManualQty] = useState('1');
  const [manualUnit, setManualUnit] = useState('UN');
  const [manualPrice, setManualPrice] = useState('');

  // Step 3 state - match
  const [productSearch, setProductSearch] = useState('');
  const [matchingLineId, setMatchingLineId] = useState<string | null>(null);
  const [newProductName, setNewProductName] = useState('');
  const [newProductCategoryId, setNewProductCategoryId] = useState('');
  const [showNewProduct, setShowNewProduct] = useState(false);

  // Temp extracted items before import is created
  const [extractedItems, setExtractedItems] = useState<any[]>([]);

  const { data: fornecedores = [] } = useFornecedores();
  const saveFornecedor = useSaveFornecedor();
  const createImport = useCreatePurchaseImport();
  const updateImport = useUpdatePurchaseImport();
  const addLine = useAddPurchaseImportLine();
  const updateLine = useUpdatePurchaseImportLine();
  const deleteLine = useDeletePurchaseImportLine();
  const confirmImport = useConfirmPurchaseImport();
  const { data: lines = [], refetch: refetchLines } = usePurchaseImportLines(currentImportId || undefined);

  const { data: categories = [] } = useQuery({
    queryKey: ['categories_all'],
    queryFn: async () => {
      const { data, error } = await supabase.from('categories').select('*').eq('active', true).order('name');
      if (error) throw error;
      return data;
    },
  });

  const [debouncedSearch, setDebouncedSearch] = useState('');
  useEffect(() => {
    const t = setTimeout(() => setDebouncedSearch(productSearch), 300);
    return () => clearTimeout(t);
  }, [productSearch]);

  const { data: productResults = [] } = useQuery({
    queryKey: ['product_search_gestao', debouncedSearch],
    enabled: debouncedSearch.length >= 2,
    queryFn: async () => {
      const { data, error } = await supabase
        .from('products')
        .select('id, name, sku')
        .eq('active', true)
        .or(`name.ilike.%${debouncedSearch}%,sku.ilike.%${debouncedSearch}%`)
        .order('name')
        .limit(15);
      if (error) throw error;
      return data;
    },
  });

  // If editing existing import, load data
  useEffect(() => {
    if (importId) {
      setCurrentImportId(importId);
      supabase.from('purchase_imports' as any).select('*').eq('id', importId).single().then(({ data }) => {
        if (data) {
          setSupplierId((data as any).supplier_id || '');
          setDocDate((data as any).document_date || '');
          setRefNumber((data as any).reference_number || '');
          setNotes((data as any).notes || '');
          if ((data as any).status === 'CONFIRMADO') setStep(4);
          else if ((data as any).status === 'EM_REVISAO') setStep(2);
          else setStep(1);
        }
      });
    }
  }, [importId]);

  // Parse NF-e XML directly without AI
  const parseNFeXml = (xmlText: string) => {
    const parser = new DOMParser();
    const doc = parser.parseFromString(xmlText, 'text/xml');

    const getText = (parent: Document | Element, tag: string) => {
      const el = parent.getElementsByTagName(tag)[0];
      return el?.textContent?.trim() || '';
    };

    const emit = doc.getElementsByTagName('emit')[0];
    const ide = doc.getElementsByTagName('ide')[0];

    const supplierName = emit ? getText(emit, 'xNome') : '';
    const supplierCnpj = emit ? getText(emit, 'CNPJ') : '';
    const docDate = ide ? getText(ide, 'dhEmi') : '';
    const docNumber = ide ? getText(ide, 'nNF') : '';

    // Parse date to YYYY-MM-DD
    let formattedDate = '';
    if (docDate) {
      try {
        formattedDate = docDate.substring(0, 10); // "2024-01-15T..." → "2024-01-15"
      } catch { formattedDate = docDate; }
    }

    // Parse items from <det> nodes
    const detNodes = doc.getElementsByTagName('det');
    const items: any[] = [];
    for (let i = 0; i < detNodes.length; i++) {
      const prod = detNodes[i].getElementsByTagName('prod')[0];
      if (!prod) continue;
      items.push({
        description: getText(prod, 'xProd'),
        code: getText(prod, 'cProd'),
        qty: parseFloat(getText(prod, 'qCom')) || 1,
        unit: getText(prod, 'uCom') || 'UN',
        unit_price: parseFloat(getText(prod, 'vUnCom')) || 0,
        total_price: parseFloat(getText(prod, 'vProd')) || 0,
      });
    }

    return { supplierName, supplierCnpj, docDate: formattedDate, docNumber, items };
  };

  // Auto-extract on file upload
  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (!f) return;
    setFile(f);
    if (f.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = () => setFilePreview(reader.result as string);
      reader.readAsDataURL(f);
    } else {
      setFilePreview(null);
    }

    const isXml = f.name.toLowerCase().endsWith('.xml') || f.type === 'text/xml' || f.type === 'application/xml';

    setExtracting(true);
    setExtractedInfo(null);
    setExtractedItems([]);
    setAutoSupplierCreated(false);

    try {
      if (isXml) {
        // ── XML: parse directly, no AI needed ──
        const xmlText = await f.text();
        const parsed = parseNFeXml(xmlText);

        if (parsed.docDate) setDocDate(parsed.docDate);
        if (parsed.docNumber) setRefNumber(parsed.docNumber);

        setExtractedInfo({
          supplier_name: parsed.supplierName,
          document_number: parsed.docNumber,
          document_date: parsed.docDate,
          notes: parsed.supplierCnpj ? `CNPJ: ${parsed.supplierCnpj}` : undefined,
        });
        if (parsed.supplierCnpj) setNotes(`CNPJ: ${parsed.supplierCnpj}`);

        // Auto-match or create supplier
        if (parsed.supplierName) {
          await autoMatchOrCreateSupplier(parsed.supplierName);
        }

        if (parsed.items.length > 0) {
          setExtractedItems(parsed.items);
          toast.success(`${parsed.items.length} itens extraídos do XML!`);
        } else {
          toast.info('XML processado mas nenhum item encontrado.');
        }
      } else {
        // ── PDF/Image: use AI extraction ──
        const reader = new FileReader();
        const base64 = await new Promise<string>((resolve) => {
          reader.onload = () => {
            const result = reader.result as string;
            resolve(result.split(',')[1]);
          };
          reader.readAsDataURL(f);
        });

        const { data: fnData, error: fnErr } = await supabase.functions.invoke('extract-purchase-doc', {
          body: { fileBase64: base64, fileName: f.name, mimeType: f.type },
        });

        if (!fnErr && fnData?.success && fnData?.data) {
          const extracted = fnData.data;

          if (extracted.document_date) setDocDate(extracted.document_date);
          if (extracted.document_number) setRefNumber(extracted.document_number);
          if (extracted.notes) setNotes(extracted.notes);

          setExtractedInfo({
            supplier_name: extracted.supplier_name,
            document_number: extracted.document_number,
            document_date: extracted.document_date,
            notes: extracted.notes,
          });

          if (extracted.supplier_name) {
            await autoMatchOrCreateSupplier(extracted.supplier_name);
          }

          if (extracted.items?.length > 0) {
            setExtractedItems(extracted.items);
            toast.success(`${extracted.items.length} itens extraídos automaticamente!`);
          }
        } else {
          toast.info('Extração automática não retornou dados. Preencha manualmente.');
        }
      }
    } catch (err) {
      console.error('Extraction error:', err);
      toast.info('Erro na extração. Preencha manualmente.');
    } finally {
      setExtracting(false);
    }
  };

  const autoMatchOrCreateSupplier = async (supplierName: string) => {
    const searchNorm = supplierName.trim().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    
    let bestMatch: any = null;
    let bestScore = 0;
    
    for (const f of fornecedores as any[]) {
      const razao = (f.razao_social || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
      const fantasia = (f.nome_fantasia || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
      
      if (razao === searchNorm || fantasia === searchNorm) {
        bestMatch = f; bestScore = 100; break;
      }
      
      const searchWords = searchNorm.split(/\s+/).filter(w => w.length > 2);
      const checkOverlap = (target: string) => {
        if (!target) return 0;
        const targetWords = target.split(/\s+/).filter(w => w.length > 2);
        const matching = searchWords.filter(w => targetWords.some(tw => tw.includes(w) || w.includes(tw)));
        return matching.length;
      };
      
      const overlap = Math.max(checkOverlap(razao), checkOverlap(fantasia));
      const minWords = Math.max(2, Math.ceil(searchWords.length * 0.5));
      if (overlap >= minWords && overlap > bestScore) {
        bestMatch = f;
        bestScore = overlap;
      }
    }

    if (bestMatch) {
      setSupplierId(bestMatch.id);
    } else {
      try {
        const result = await saveFornecedor.mutateAsync({ razao_social: supplierName.trim() });
        await queryClient.invalidateQueries({ queryKey: ['fornecedores'] });
        if (result?.id) {
          setTimeout(() => setSupplierId(result.id), 300);
        }
        setAutoSupplierCreated(true);
      } catch (err) {
        console.error('Failed to auto-create supplier:', err);
      }
    }
  };

  const handleCreateSupplier = async () => {
    if (!newSupplierName.trim()) return;
    const result = await saveFornecedor.mutateAsync({ razao_social: newSupplierName.trim() });
    await queryClient.invalidateQueries({ queryKey: ['fornecedores'] });
    if (result?.id) {
      setTimeout(() => setSupplierId(result.id), 300);
    }
    setNewSupplierName('');
    setShowNewSupplier(false);
  };

  const handleStep1Submit = async () => {
    if (!supplierId) { toast.error('Selecione o fornecedor'); return; }

    let fileUrl = '';
    let fileName = '';
    let docKind = 'PDF';

    if (file) {
      fileName = file.name;
      docKind = file.name.toLowerCase().endsWith('.xml') ? 'XML' : file.type.startsWith('image/') ? 'IMAGE' : 'PDF';

      const path = `imports/${Date.now()}_${file.name}`;
      const { error: uploadErr } = await supabase.storage.from('compras-docs').upload(path, file);
      if (uploadErr) { toast.error('Erro no upload: ' + uploadErr.message); return; }
      const { data: urlData } = supabase.storage.from('compras-docs').getPublicUrl(path);
      fileUrl = urlData.publicUrl;
    }

    let newImportId = currentImportId;

    if (currentImportId) {
      await updateImport.mutateAsync({
        id: currentImportId,
        updates: { supplier_id: supplierId, document_date: docDate || null, reference_number: refNumber || null, notes: notes || null },
      });
    } else {
      const result = await createImport.mutateAsync({
        supplier_id: supplierId,
        document_kind: docKind,
        file_url: fileUrl || undefined,
        file_name: fileName || undefined,
        document_date: docDate || undefined,
        reference_number: refNumber || undefined,
        notes: notes || undefined,
      });
      newImportId = (result as any).id;
      setCurrentImportId(newImportId);
    }

    // Insert extracted items if we have them
    if (extractedItems.length > 0 && newImportId) {
      for (let i = 0; i < extractedItems.length; i++) {
        const item = extractedItems[i];
        await supabase.from('purchase_import_lines' as any).insert({
          purchase_import_id: newImportId,
          line_index: i,
          raw_description: item.description || 'Sem descrição',
          qty: item.qty || 1,
          unit: item.unit || null,
          unit_price: item.unit_price || null,
          total_price: item.total_price || null,
        } as any);
      }
      setExtractedItems([]);
    }

    setStep(1);
    refetchLines();
  };

  const handleAddManualLine = async () => {
    if (!currentImportId || !manualDesc.trim()) return;
    await addLine.mutateAsync({
      purchase_import_id: currentImportId,
      line_index: lines.length,
      raw_description: manualDesc.trim(),
      qty: Number(manualQty) || 1,
      unit: manualUnit || null,
      unit_price: Number(manualPrice) || null,
      total_price: (Number(manualQty) || 1) * (Number(manualPrice) || 0) || null,
    });
    setManualDesc('');
    setManualQty('1');
    setManualPrice('');
  };

  const handleMatchProduct = async (lineId: string, productId: string, productName: string) => {
    if (!currentImportId) return;
    await updateLine.mutateAsync({
      id: lineId,
      importId: currentImportId,
      updates: { matched_product_id: productId, matched_product_name: productName, match_status: 'MATCHED' },
    });
    setMatchingLineId(null);
    setProductSearch('');
  };

  const handleCreateNewProduct = async (lineId: string) => {
    if (!newProductName.trim() || !newProductCategoryId) {
      toast.error('Nome e categoria são obrigatórios');
      return;
    }
    const trimmedName = newProductName.trim();
    const normalizedName = trimmedName.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9\s]/g, '').replace(/\s+/g, ' ').trim();
    // Get the unit_price from the import line to set as cost_price
    const sourceLine = lines.find((l: any) => l.id === lineId);
    const costPrice = sourceLine?.unit_price || null;
    const { data: newProd, error } = await supabase
      .from('products')
      .insert({ name: trimmedName, normalized_name: normalizedName, active: true, cost_price: costPrice, category_id: newProductCategoryId } as any)
      .select()
      .single();
    if (error) { toast.error(error.message); return; }

    await updateLine.mutateAsync({
      id: lineId,
      importId: currentImportId!,
      updates: {
        matched_product_id: newProd.id,
        matched_product_name: newProductName.trim(),
        matched_category_id: newProductCategoryId,
        match_status: 'NOVO_CRIADO',
      },
    });
    setShowNewProduct(false);
    setNewProductName('');
    setNewProductCategoryId('');
    setMatchingLineId(null);
  };

  const handleConfirm = async () => {
    if (!currentImportId) return;
    const pendingLines = lines.filter((l: any) => l.match_status === 'PENDENTE');
    if (pendingLines.length > 0) {
      toast.error(`${pendingLines.length} item(ns) ainda sem match. Volte ao passo de Match.`);
      return;
    }
    await confirmImport.mutateAsync(currentImportId);
    setShowConfirm(false);
    onOpenChange(false);
  };

  const totalValue = lines.reduce((acc: number, l: any) => acc + (l.total_price || (l.qty * (l.unit_price || 0)) || 0), 0);
  const matchedCount = lines.filter((l: any) => l.match_status !== 'PENDENTE').length;
  const pendingCount = lines.filter((l: any) => l.match_status === 'PENDENTE').length;
  const newCount = lines.filter((l: any) => l.match_status === 'NOVO_CRIADO').length;

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Package className="h-5 w-5" />
              Importar Compra
            </DialogTitle>
          </DialogHeader>

          {/* Step indicator */}
          <div className="flex items-center gap-1 mb-4">
            {STEPS.map((s, i) => (
              <div key={s} className="flex items-center gap-1">
                <div className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium ${
                  i === step ? 'bg-primary text-primary-foreground' :
                  i < step ? 'bg-primary/20 text-primary' : 'bg-muted text-muted-foreground'
                }`}>
                  <span>{i + 1}</span>
                  <span className="hidden sm:inline">{s}</span>
                </div>
                {i < STEPS.length - 1 && <ArrowRight className="h-3 w-3 text-muted-foreground" />}
              </div>
            ))}
          </div>

          {/* STEP 0: Upload */}
          {step === 0 && (
            <div className="space-y-4">
              <div>
                <Label>Documento (XML, PDF ou Imagem)</Label>
                <div className="mt-1.5 border-2 border-dashed rounded-lg p-6 text-center">
                  <input type="file" accept=".xml,.pdf,image/png,image/jpeg,image/jpg" onChange={handleFileChange} className="hidden" id="purchase-file" />
                  <label htmlFor="purchase-file" className="cursor-pointer">
                    <Upload className="h-8 w-8 mx-auto text-muted-foreground mb-2" />
                    <p className="text-sm text-muted-foreground">{file ? file.name : 'Clique para selecionar XML (NF-e), PDF ou imagem'}</p>
                  </label>
                  {filePreview && <img src={filePreview} alt="Preview" className="mt-3 max-h-40 mx-auto rounded border" />}
                </div>
              </div>

              {/* Extraction status */}
              {extracting && (
                <div className="flex items-center gap-3 p-3 rounded-lg border border-primary/30 bg-primary/5">
                  <Loader2 className="h-5 w-5 animate-spin text-primary" />
                  <div>
                    <p className="text-sm font-medium">Extraindo dados com IA...</p>
                    <p className="text-xs text-muted-foreground">Fornecedor, data, referência e itens serão preenchidos automaticamente</p>
                  </div>
                </div>
              )}

              {/* Extraction success summary */}
              {!extracting && extractedInfo && (
                <div className="p-3 rounded-lg border border-emerald-300 bg-emerald-50/50 dark:bg-emerald-950/20 space-y-1">
                  <div className="flex items-center gap-2">
                    <Sparkles className="h-4 w-4 text-emerald-600" />
                    <p className="text-sm font-medium text-emerald-700 dark:text-emerald-400">Dados extraídos automaticamente</p>
                  </div>
                  <div className="text-xs text-muted-foreground space-y-0.5 ml-6">
                    {extractedInfo.supplier_name && (
                      <p>Fornecedor: <span className="font-medium text-foreground">{extractedInfo.supplier_name}</span>
                        {autoSupplierCreated && <Badge className="ml-2 bg-emerald-600 text-white text-[9px] h-4">Cadastrado automaticamente</Badge>}
                      </p>
                    )}
                    {extractedInfo.document_date && <p>Data: <span className="font-medium text-foreground">{extractedInfo.document_date}</span></p>}
                    {extractedInfo.document_number && <p>Referência: <span className="font-medium text-foreground">{extractedInfo.document_number}</span></p>}
                    {extractedItems.length > 0 && <p>Itens encontrados: <span className="font-medium text-foreground">{extractedItems.length}</span></p>}
                  </div>
                </div>
              )}

              <div>
                <Label>Fornecedor *</Label>
                <Select value={supplierId} onValueChange={setSupplierId}>
                  <SelectTrigger><SelectValue placeholder="Selecione o fornecedor" /></SelectTrigger>
                  <SelectContent>
                    {fornecedores.map((f: any) => (
                      <SelectItem key={f.id} value={f.id}>{f.razao_social || f.nome_fantasia}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button variant="link" size="sm" className="text-xs px-0 mt-1" onClick={() => setShowNewSupplier(!showNewSupplier)}>
                  + Criar fornecedor rápido
                </Button>
                {showNewSupplier && (
                  <div className="flex gap-2 mt-1">
                    <Input placeholder="Nome do fornecedor" value={newSupplierName} onChange={e => setNewSupplierName(e.target.value)} />
                    <Button size="sm" onClick={handleCreateSupplier} disabled={saveFornecedor.isPending}>Criar</Button>
                  </div>
                )}
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label>Data do documento</Label>
                  <Input type="date" value={docDate} onChange={e => setDocDate(e.target.value)} />
                </div>
                <div>
                  <Label>Nº Referência/Pedido</Label>
                  <Input value={refNumber} onChange={e => setRefNumber(e.target.value)} placeholder="Opcional" />
                </div>
              </div>

              <div>
                <Label>Observações</Label>
                <Textarea value={notes} onChange={e => setNotes(e.target.value)} rows={2} placeholder="Opcional" />
              </div>

              <Button onClick={handleStep1Submit} disabled={!supplierId || createImport.isPending || extracting} className="w-full gap-2">
                {createImport.isPending ? <><Loader2 className="h-4 w-4 animate-spin" /> Salvando...</> : <>Avançar <ArrowRight className="h-4 w-4" /></>}
              </Button>
            </div>
          )}

          {/* STEP 1: Items */}
          {step === 1 && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-sm">Itens da Compra ({lines.length})</h3>
              </div>

              {lines.length > 0 && (
                <div className="space-y-2 max-h-[300px] overflow-y-auto">
                  {lines.map((l: any, i: number) => (
                    <div key={l.id} className="flex items-center justify-between gap-2 p-2.5 rounded-md bg-muted/40 text-sm">
                      <div className="min-w-0 flex-1">
                        <p className="font-medium truncate">{l.raw_description}</p>
                        <p className="text-xs text-muted-foreground">
                          Qtd: {l.qty} {l.unit || 'un'} {l.unit_price ? `• ${formatCurrency(l.unit_price)}/un` : ''} {l.total_price ? `• Total: ${formatCurrency(l.total_price)}` : ''}
                        </p>
                      </div>
                      <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive" onClick={() => deleteLine.mutateAsync({ id: l.id, importId: currentImportId! })}>
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  ))}
                </div>
              )}

              <Separator />
              <div className="space-y-2">
                <Label className="text-xs font-medium">Adicionar item manualmente</Label>
                <div className="grid grid-cols-[1fr_60px_60px_80px_auto] gap-2 items-end">
                  <div>
                    <Input placeholder="Descrição do item" value={manualDesc} onChange={e => setManualDesc(e.target.value)} className="text-sm" />
                  </div>
                  <div>
                    <Input type="number" placeholder="Qtd" value={manualQty} onChange={e => setManualQty(e.target.value)} className="text-sm" />
                  </div>
                  <div>
                    <Input placeholder="Un" value={manualUnit} onChange={e => setManualUnit(e.target.value)} className="text-sm" />
                  </div>
                  <div>
                    <Input type="number" placeholder="Preço" value={manualPrice} onChange={e => setManualPrice(e.target.value)} className="text-sm" />
                  </div>
                  <Button size="sm" onClick={handleAddManualLine} disabled={!manualDesc.trim()}>
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              <div className="flex justify-between">
                <Button variant="outline" onClick={() => setStep(0)} className="gap-2">
                  <ArrowLeft className="h-4 w-4" /> Voltar
                </Button>
                <Button onClick={() => setStep(2)} disabled={lines.length === 0} className="gap-2">
                  Match de Produtos <ArrowRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          )}

          {/* STEP 2: Match */}
          {step === 2 && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-sm">Match de Produtos</h3>
                <div className="flex gap-2">
                  <Badge variant="secondary" className="text-xs">{matchedCount} matched</Badge>
                  {pendingCount > 0 && <Badge variant="destructive" className="text-xs">{pendingCount} pendente(s)</Badge>}
                </div>
              </div>

              <div className="space-y-3 max-h-[400px] overflow-y-auto">
                {lines.map((l: any) => (
                  <div key={l.id} className={`p-3 rounded-lg border ${l.match_status === 'PENDENTE' ? 'border-amber-300 bg-amber-50/50 dark:bg-amber-950/20' : 'border-emerald-300 bg-emerald-50/50 dark:bg-emerald-950/20'}`}>
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0 flex-1">
                        <p className="text-sm font-medium">{l.raw_description}</p>
                        <p className="text-xs text-muted-foreground mt-0.5">
                          Qtd: {l.qty} {l.unit || ''} {l.unit_price ? `• ${formatCurrency(l.unit_price)}` : ''}
                        </p>
                      </div>
                      {l.match_status !== 'PENDENTE' ? (
                        <Badge className="bg-emerald-600 text-white text-[10px] gap-1 shrink-0">
                          <CheckCircle2 className="h-3 w-3" />
                          {l.match_status === 'NOVO_CRIADO' ? 'Novo' : 'Matched'}
                          {l.matched_product_name && `: ${l.matched_product_name}`}
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="text-amber-600 border-amber-300 text-[10px] shrink-0">
                          <AlertTriangle className="h-3 w-3 mr-1" /> Pendente
                        </Badge>
                      )}
                    </div>

                    {l.match_status === 'PENDENTE' && (
                      <div className="mt-2 space-y-2">
                        {matchingLineId === l.id ? (
                          <>
                            <div className="relative">
                              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
                              <Input
                                placeholder="Buscar produto no sistema..."
                                value={productSearch}
                                onChange={e => setProductSearch(e.target.value)}
                                className="pl-8 text-sm h-8"
                              />
                            </div>
                            {productResults.length > 0 && (
                              <div className="max-h-32 overflow-y-auto space-y-1 border rounded p-1">
                                {productResults.map((p: any) => (
                                  <button
                                    key={p.id}
                                    className="w-full text-left px-2 py-1.5 rounded text-xs hover:bg-muted transition-colors"
                                    onClick={() => handleMatchProduct(l.id, p.id, p.name)}
                                  >
                                    <span className="font-medium">{p.name}</span>
                                    {p.sku && <span className="text-muted-foreground ml-2">({p.sku})</span>}
                                  </button>
                                ))}
                              </div>
                            )}
                            <div className="flex gap-2">
                              <Button variant="outline" size="sm" className="text-xs h-7" onClick={() => { setShowNewProduct(true); setNewProductName(l.raw_description); }}>
                                <Plus className="h-3 w-3 mr-1" /> Criar novo produto
                              </Button>
                              <Button variant="ghost" size="sm" className="text-xs h-7" onClick={() => setMatchingLineId(null)}>
                                Cancelar
                              </Button>
                            </div>

                            {showNewProduct && matchingLineId === l.id && (
                              <div className="p-3 border rounded-lg bg-muted/30 space-y-2">
                                <Label className="text-xs">Nome do produto *</Label>
                                <Input value={newProductName} onChange={e => setNewProductName(e.target.value)} className="text-sm h-8" />
                                <Label className="text-xs">Categoria *</Label>
                                <Select value={newProductCategoryId} onValueChange={setNewProductCategoryId}>
                                  <SelectTrigger className="h-8 text-sm"><SelectValue placeholder="Selecione" /></SelectTrigger>
                                  <SelectContent>
                                    {categories.map((c: any) => (
                                      <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                                <Button size="sm" className="w-full h-7 text-xs" onClick={() => handleCreateNewProduct(l.id)} disabled={!newProductName.trim() || !newProductCategoryId}>
                                  Criar e vincular
                                </Button>
                              </div>
                            )}
                          </>
                        ) : (
                          <Button variant="outline" size="sm" className="text-xs h-7 gap-1" onClick={() => { setMatchingLineId(l.id); setProductSearch(''); }}>
                            <Search className="h-3 w-3" /> Vincular produto
                          </Button>
                        )}
                      </div>
                    )}
                  </div>
                ))}
              </div>

              <div className="flex justify-between">
                <Button variant="outline" onClick={() => setStep(1)} className="gap-2">
                  <ArrowLeft className="h-4 w-4" /> Voltar
                </Button>
                <Button onClick={() => setStep(3)} disabled={pendingCount > 0} className="gap-2">
                  Revisão <ArrowRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          )}

          {/* STEP 3: Review */}
          {step === 3 && (
            <div className="space-y-4">
              <h3 className="font-semibold text-sm">Revisão Final</h3>

              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 rounded-lg border bg-muted/30 text-center">
                  <p className="text-2xl font-bold">{lines.length}</p>
                  <p className="text-xs text-muted-foreground">Itens</p>
                </div>
                <div className="p-4 rounded-lg border bg-muted/30 text-center">
                  <p className="text-2xl font-bold">{formatCurrency(totalValue)}</p>
                  <p className="text-xs text-muted-foreground">Total estimado</p>
                </div>
                <div className="p-4 rounded-lg border bg-muted/30 text-center">
                  <p className="text-2xl font-bold text-emerald-600">{matchedCount}</p>
                  <p className="text-xs text-muted-foreground">Matched</p>
                </div>
                <div className="p-4 rounded-lg border bg-muted/30 text-center">
                  <p className="text-2xl font-bold text-amber-600">{newCount}</p>
                  <p className="text-xs text-muted-foreground">Produtos Novos</p>
                </div>
              </div>

              <div className="p-3 border rounded-lg bg-amber-50 dark:bg-amber-950/20 border-amber-300 text-sm text-amber-800 dark:text-amber-300">
                <AlertTriangle className="h-4 w-4 inline mr-2" />
                Ao confirmar, os preços serão atualizados no "Onde Comprar" e uma entrada de mercadoria será criada automaticamente.
              </div>

              <div className="flex justify-between">
                <Button variant="outline" onClick={() => setStep(2)} className="gap-2">
                  <ArrowLeft className="h-4 w-4" /> Voltar
                </Button>
                <Button onClick={() => setShowConfirm(true)} className="gap-2">
                  <CheckCircle2 className="h-4 w-4" /> Confirmar Compra
                </Button>
              </div>
            </div>
          )}

          {/* STEP 4: Done */}
          {step === 4 && (
            <div className="py-8 text-center space-y-3">
              <CheckCircle2 className="h-12 w-12 mx-auto text-emerald-600" />
              <h3 className="text-lg font-semibold">Compra Confirmada!</h3>
              <p className="text-sm text-muted-foreground">Preços atualizados e entrada de mercadoria criada.</p>
              <Button onClick={() => onOpenChange(false)}>Fechar</Button>
            </div>
          )}
        </DialogContent>
      </Dialog>

      <AlertDialog open={showConfirm} onOpenChange={setShowConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmar importação de compra?</AlertDialogTitle>
            <AlertDialogDescription>
              Esta ação irá: atualizar preços no "Onde Comprar", registrar histórico de preços e criar entrada de mercadoria em rascunho.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleConfirm} disabled={confirmImport.isPending}>
              {confirmImport.isPending ? 'Confirmando...' : 'Confirmar'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
