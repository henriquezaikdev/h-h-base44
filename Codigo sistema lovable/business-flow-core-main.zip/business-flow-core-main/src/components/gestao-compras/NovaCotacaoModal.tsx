import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Loader2 } from 'lucide-react';
import { toast } from 'sonner';

interface NovaCotacaoModalProps {
  open: boolean;
  onClose: () => void;
  onCreated: (id: string) => void;
  sellerId?: string;
}

export function NovaCotacaoModal({ open, onClose, onCreated, sellerId }: NovaCotacaoModalProps) {
  const [titulo, setTitulo] = useState('');
  const [descricao, setDescricao] = useState('');
  const [saving, setSaving] = useState(false);

  const handleCreate = async () => {
    if (!titulo.trim()) {
      toast.error('Informe o título da cotação');
      return;
    }

    setSaving(true);
    try {
      const { data, error } = await supabase
        .from('cotacao_sessoes')
        .insert({
          titulo: titulo.trim(),
          descricao: descricao.trim() || null,
          created_by: sellerId || null,
          status: 'aberta',
        })
        .select('id')
        .single();

      if (error) throw error;
      toast.success('Sessão de cotação criada');
      setTitulo('');
      setDescricao('');
      onCreated((data as any).id);
    } catch (error) {
      console.error('Error creating session:', error);
      toast.error('Erro ao criar sessão');
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Nova Sessão de Cotação</DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label>Título *</Label>
            <Input
              placeholder="Ex: Cotação Materiais Escritório - Março"
              value={titulo}
              onChange={(e) => setTitulo(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label>Descrição (opcional)</Label>
            <Textarea
              placeholder="Observações sobre esta cotação..."
              value={descricao}
              onChange={(e) => setDescricao(e.target.value)}
              rows={3}
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancelar</Button>
          <Button onClick={handleCreate} disabled={saving || !titulo.trim()}>
            {saving && <Loader2 className="h-4 w-4 animate-spin mr-2" />}
            Criar Sessão
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
