import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Clock, TrendingDown, TrendingUp, ExternalLink } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';

interface ItemHistoricoBadgeProps {
  productId: string;
  onNavigateOndeComprar?: (productId: string) => void;
}

export function ItemHistoricoBadge({ productId, onNavigateOndeComprar }: ItemHistoricoBadgeProps) {
  const [expanded, setExpanded] = useState(false);

  const { data: historico, isLoading } = useQuery({
    queryKey: ['item_historico_badge', productId],
    enabled: !!productId,
    staleTime: 60_000,
    queryFn: async () => {
      // Fetch quote lines history
      const { data: quoteLines } = await supabase
        .from('supplier_quote_lines')
        .select(`
          id, unit_price, is_winner, created_at,
          supplier_quotes!inner(supplier_id, session_id,
            fornecedores:supplier_id(razao_social, nome_fantasia)
          )
        `)
        .eq('product_id', productId)
        .order('created_at', { ascending: false })
        .limit(50);

      // Fetch supplier_product_prices (last known prices)
      const { data: productPrices } = await supabase
        .from('supplier_product_prices' as any)
        .select('last_price, last_date, min_price_90d, max_price_90d, fornecedor:supplier_id(razao_social, nome_fantasia)')
        .eq('product_id', productId)
        .order('last_date', { ascending: false })
        .limit(10);

      // Fetch supplier_price_history (actual purchases)
      const { data: priceHistory } = await supabase
        .from('supplier_price_history' as any)
        .select('price, document_date, reference_number')
        .eq('product_id', productId)
        .order('document_date', { ascending: false })
        .limit(10);

      const totalCotacoes = quoteLines?.length || 0;
      if (totalCotacoes === 0 && (!productPrices || productPrices.length === 0) && (!priceHistory || priceHistory.length === 0)) {
        return null; // No history
      }

      // Find last winner
      const lastWinner = (quoteLines || []).find((l: any) => l.is_winner);
      const lastWinnerName = lastWinner
        ? ((lastWinner as any).supplier_quotes?.fornecedores?.nome_fantasia || (lastWinner as any).supplier_quotes?.fornecedores?.razao_social)
        : null;

      // Min price from quotes
      const quotePrices = (quoteLines || [])
        .map((l: any) => l.unit_price)
        .filter((p: any) => p != null && p > 0);
      const minQuotePrice = quotePrices.length > 0 ? Math.min(...quotePrices) : null;

      // Last purchase price
      const lastPurchasePrice = priceHistory && priceHistory.length > 0 ? (priceHistory[0] as any).price : null;

      // 90d range from supplier_product_prices
      const allPricesData = (productPrices || []) as any[];
      let min90 = null as number | null;
      let max90 = null as number | null;
      for (const p of allPricesData) {
        if (p.min_price_90d != null && (min90 === null || p.min_price_90d < min90)) min90 = p.min_price_90d;
        if (p.max_price_90d != null && (max90 === null || p.max_price_90d > max90)) max90 = p.max_price_90d;
      }

      return {
        totalCotacoes,
        lastWinnerName,
        minQuotePrice,
        lastPurchasePrice,
        min90,
        max90,
      };
    },
  });

  if (isLoading || !historico) return null;

  const formatCurrency = (v: number) =>
    new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(v);

  return (
    <div className="relative inline-block">
      <Badge
        variant="outline"
        className="cursor-pointer gap-1 text-[10px] font-medium transition-colors hover:bg-accent"
        style={{ borderColor: '#A5B4FC', color: '#3B5BDB' }}
        onClick={() => setExpanded(!expanded)}
      >
        <Clock className="h-3 w-3" />
        Histórico disponível
      </Badge>

      {expanded && (
        <div
          className="absolute z-50 top-full mt-1 left-0 w-72 rounded-lg border bg-background shadow-lg p-3 space-y-2"
          style={{ borderColor: '#C7D2FE' }}
        >
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div>
              <p className="text-muted-foreground">Cotações anteriores</p>
              <p className="font-semibold">{historico.totalCotacoes}</p>
            </div>
            {historico.lastWinnerName && (
              <div>
                <p className="text-muted-foreground">Último vencedor</p>
                <p className="font-semibold truncate">{historico.lastWinnerName}</p>
              </div>
            )}
            {historico.minQuotePrice !== null && (
              <div>
                <p className="text-muted-foreground flex items-center gap-1">
                  <TrendingDown className="h-3 w-3 text-green-600" /> Menor preço cotação
                </p>
                <p className="font-semibold text-green-700">{formatCurrency(historico.minQuotePrice)}</p>
              </div>
            )}
            {historico.lastPurchasePrice !== null && (
              <div>
                <p className="text-muted-foreground">Último preço compra</p>
                <p className="font-semibold">{formatCurrency(historico.lastPurchasePrice)}</p>
              </div>
            )}
            {historico.min90 !== null && historico.max90 !== null && (
              <div className="col-span-2">
                <p className="text-muted-foreground flex items-center gap-1">
                  <TrendingUp className="h-3 w-3" /> Faixa 90 dias
                </p>
                <p className="font-semibold">
                  {formatCurrency(historico.min90)} — {formatCurrency(historico.max90)}
                </p>
              </div>
            )}
          </div>

          {onNavigateOndeComprar && (
            <Button
              variant="outline"
              size="sm"
              className="w-full gap-1.5 text-xs mt-1"
              style={{ borderColor: '#A5B4FC', color: '#3B5BDB' }}
              onClick={() => {
                setExpanded(false);
                onNavigateOndeComprar(productId);
              }}
            >
              <ExternalLink className="h-3 w-3" />
              Ver Onde Comprar
            </Button>
          )}

          <button
            className="absolute top-1 right-2 text-muted-foreground hover:text-foreground text-xs"
            onClick={() => setExpanded(false)}
          >
            ✕
          </button>
        </div>
      )}
    </div>
  );
}
