import { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { Phone, MessageCircle, Calendar, Clock, Flag, Loader2, Target, Lock } from 'lucide-react';
import { cn } from '@/lib/utils';
import { TaskData, ContactReason, CONTACT_REASON_OPTIONS } from '@/hooks/useTasksData';
import { useTaskDatePermission } from '@/hooks/useTaskDatePermission';

interface Seller {
  id: string;
  name: string;
}

interface EditTaskModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  task: TaskData;
  sellers: Seller[];
  onUpdated: () => void;
}

const priorityOptions = [
  { value: 'alta', label: 'Alta', color: 'text-red-600 border-red-500 bg-red-500/5' },
  { value: 'media', label: 'Média', color: 'text-yellow-600 border-yellow-500 bg-yellow-500/5' },
  { value: 'baixa', label: 'Baixa', color: 'text-green-600 border-green-500 bg-green-500/5' },
];

export function EditTaskModal({
  open,
  onOpenChange,
  task,
  sellers,
  onUpdated,
}: EditTaskModalProps) {
  const [contactType, setContactType] = useState<'ligacao' | 'whatsapp'>('ligacao');
  const [contactReason, setContactReason] = useState<ContactReason>('RETORNO');
  const [taskDate, setTaskDate] = useState('');
  const [taskTime, setTaskTime] = useState('');
  const [notes, setNotes] = useState('');
  const [priority, setPriority] = useState<'alta' | 'media' | 'baixa'>('media');
  const [responsibleSellerId, setResponsibleSellerId] = useState<string>('');
  const [saving, setSaving] = useState(false);

  const { canEditDate } = useTaskDatePermission();
  const isCompleted = task.status === 'concluida';

  const reasonConfig = CONTACT_REASON_OPTIONS.find(r => r.value === contactReason) || CONTACT_REASON_OPTIONS[0];

  useEffect(() => {
    if (open && task) {
      setContactType(task.contactType);
      setContactReason(task.contactReason || 'RETORNO');
      setTaskDate(task.taskDate);
      setTaskTime(task.taskTime || '');
      setNotes(task.notes || '');
      setPriority(task.priority || 'media');
      setResponsibleSellerId(task.createdBySellerId || '');
    }
  }, [open, task]);

  const handleSave = async () => {
    if (!taskDate) {
      toast.error('Selecione uma data.');
      return;
    }

    if (!responsibleSellerId) {
      toast.error('Selecione um responsável.');
      return;
    }

    if (!contactReason) {
      toast.error('Selecione o motivo do contato.');
      return;
    }

    setSaving(true);

    try {
      const updateData: Record<string, any> = {
        contact_type: contactType,
        contact_reason: contactReason,
        notes: notes.trim() || null,
        created_by_seller_id: responsibleSellerId,
        priority,
      };

      // Only allow date/time changes for pending tasks AND if user has permission
      if (!isCompleted && canEditDate) {
        updateData.task_date = taskDate;
        updateData.task_time = taskTime || null;
      }

      const { error } = await supabase
        .from('tasks')
        .update(updateData)
        .eq('id', task.id);

      if (error) {
        // Check if it's the date block error
        if (error.message?.includes('DATA_BLOQUEADA') || error.message?.includes('Não é permitido alterar a data')) {
          toast.error('Data da tarefa é travada. Solicite ao Henrique ou cancele e crie outra com a data correta.');
          return;
        }
        throw error;
      }

      toast.success('Tarefa atualizada com sucesso!');
      onOpenChange(false);
      onUpdated();
    } catch (error: any) {
      console.error('Error updating task:', error);
      toast.error(error.message || 'Erro ao atualizar tarefa');
    } finally {
      setSaving(false);
    }
  };

  // Determine if date field should be disabled
  const isDateDisabled = isCompleted || !canEditDate;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Editar Tarefa</DialogTitle>
        </DialogHeader>

        <div className="space-y-5 pt-4">
          {/* Header with reason + client */}
          <div className="p-3 bg-muted/50 rounded-lg">
            <div className="flex items-center gap-2 flex-wrap mb-1">
              <Badge variant="outline" className={cn('text-xs', reasonConfig.color)}>
                {reasonConfig.label}
              </Badge>
              <span className="text-sm text-muted-foreground">—</span>
              <span className="font-medium">{task.clientName}</span>
            </div>
            {isCompleted && (
              <p className="text-xs text-muted-foreground mt-1">
                ⚠️ Tarefa concluída - edição limitada (tipo, responsável e observações)
              </p>
            )}
          </div>

          {/* Contact Reason */}
          <div className="space-y-2">
            <Label className="flex items-center gap-2">
              <Target className="h-4 w-4" />
              Motivo do Contato *
            </Label>
            <Select value={contactReason} onValueChange={(v) => setContactReason(v as ContactReason)}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione o motivo..." />
              </SelectTrigger>
              <SelectContent>
                {CONTACT_REASON_OPTIONS.map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Contact Type */}
          <div className="space-y-3">
            <Label>Tipo de contato *</Label>
            <RadioGroup
              value={contactType}
              onValueChange={(value) => setContactType(value as 'ligacao' | 'whatsapp')}
              className="grid grid-cols-2 gap-3"
            >
              <div
                className={cn(
                  'flex items-center gap-3 p-4 rounded-lg border cursor-pointer transition-colors',
                  contactType === 'ligacao'
                    ? 'border-primary bg-primary/5'
                    : 'border-border hover:bg-muted/50'
                )}
                onClick={() => setContactType('ligacao')}
              >
                <RadioGroupItem value="ligacao" id="edit-ligacao" className="sr-only" />
                <Phone className="h-5 w-5 text-primary" />
                <Label htmlFor="edit-ligacao" className="cursor-pointer font-medium">
                  Ligação
                </Label>
              </div>

              <div
                className={cn(
                  'flex items-center gap-3 p-4 rounded-lg border cursor-pointer transition-colors',
                  contactType === 'whatsapp'
                    ? 'border-green-500 bg-green-500/5'
                    : 'border-border hover:bg-muted/50'
                )}
                onClick={() => setContactType('whatsapp')}
              >
                <RadioGroupItem value="whatsapp" id="edit-whatsapp" className="sr-only" />
                <MessageCircle className="h-5 w-5 text-green-500" />
                <Label htmlFor="edit-whatsapp" className="cursor-pointer font-medium">
                  WhatsApp
                </Label>
              </div>
            </RadioGroup>
          </div>

          {/* Responsible Seller */}
          <div className="space-y-2">
            <Label>Responsável *</Label>
            <Select value={responsibleSellerId} onValueChange={setResponsibleSellerId}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione o responsável" />
              </SelectTrigger>
              <SelectContent>
                {sellers.map((seller) => (
                  <SelectItem key={seller.id} value={seller.id}>
                    {seller.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-xs text-muted-foreground">
              Alterar o responsável atualizará os relatórios de produtividade.
            </p>
          </div>

          {/* Priority */}
          <div className="space-y-3">
            <Label className="flex items-center gap-2">
              <Flag className="h-4 w-4" />
              Prioridade
            </Label>
            <RadioGroup
              value={priority}
              onValueChange={(value) => setPriority(value as 'alta' | 'media' | 'baixa')}
              className="grid grid-cols-3 gap-3"
            >
              {priorityOptions.map((option) => (
                <div
                  key={option.value}
                  className={cn(
                    'flex items-center justify-center gap-2 p-3 rounded-lg border cursor-pointer transition-colors text-sm font-medium',
                    priority === option.value
                      ? option.color
                      : 'border-border hover:bg-muted/50'
                  )}
                  onClick={() => setPriority(option.value as 'alta' | 'media' | 'baixa')}
                >
                  <RadioGroupItem value={option.value} id={`edit-priority-${option.value}`} className="sr-only" />
                  <Label htmlFor={`edit-priority-${option.value}`} className="cursor-pointer">
                    {option.label}
                  </Label>
                </div>
              ))}
            </RadioGroup>
          </div>

          {/* Date and Time - Only editable for pending tasks AND if user has permission */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="editTaskDate" className="flex items-center gap-2">
                <Calendar className="h-4 w-4" />
                Data *
                {isDateDisabled && !isCompleted && (
                  <Lock className="h-3 w-3 text-muted-foreground" />
                )}
              </Label>
              <Input
                id="editTaskDate"
                type="date"
                value={taskDate}
                onChange={(e) => setTaskDate(e.target.value)}
                disabled={isDateDisabled}
                className={isDateDisabled ? 'cursor-not-allowed opacity-60' : ''}
              />
              {isDateDisabled && !isCompleted && (
                <p className="text-xs text-muted-foreground">
                  🔒 Data bloqueada. Cancele e crie nova tarefa se necessário.
                </p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="editTaskTime" className="flex items-center gap-2">
                <Clock className="h-4 w-4" />
                Hora (opcional)
              </Label>
              <Input
                id="editTaskTime"
                type="time"
                value={taskTime}
                onChange={(e) => setTaskTime(e.target.value)}
                disabled={isDateDisabled}
                className={isDateDisabled ? 'cursor-not-allowed opacity-60' : ''}
              />
            </div>
          </div>

          {/* Notes */}
          <div className="space-y-2">
            <Label htmlFor="editNotes">Observações</Label>
            <Textarea
              id="editNotes"
              placeholder="Adicione detalhes sobre esta tarefa..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={3}
            />
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={saving}>
            Cancelar
          </Button>
          <Button onClick={handleSave} disabled={saving}>
            {saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
            Salvar Alterações
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
