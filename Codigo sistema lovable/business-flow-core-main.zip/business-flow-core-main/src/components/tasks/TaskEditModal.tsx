import { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { Phone, MessageCircle, Calendar, Clock, Flag, Lock } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useTaskDatePermission } from '@/hooks/useTaskDatePermission';

interface TaskEditModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  task: {
    id: string;
    clientId: string;
    clientName: string;
    contactType: string;
    taskDate: string;
    taskTime: string | null;
    notes: string | null;
    priority?: 'alta' | 'media' | 'baixa';
  } | null;
  onSaved: () => void;
}

const priorityOptions = [
  { value: 'alta', label: 'Alta', color: 'text-red-600 border-red-500 bg-red-500/5' },
  { value: 'media', label: 'Média', color: 'text-yellow-600 border-yellow-500 bg-yellow-500/5' },
  { value: 'baixa', label: 'Baixa', color: 'text-green-600 border-green-500 bg-green-500/5' },
];

export function TaskEditModal({
  open,
  onOpenChange,
  task,
  onSaved,
}: TaskEditModalProps) {
  const [contactType, setContactType] = useState<'ligacao' | 'whatsapp'>('ligacao');
  const [taskDate, setTaskDate] = useState('');
  const [taskTime, setTaskTime] = useState('');
  const [notes, setNotes] = useState('');
  const [priority, setPriority] = useState<'alta' | 'media' | 'baixa'>('media');
  const [saving, setSaving] = useState(false);

  const { canEditDate } = useTaskDatePermission();

  useEffect(() => {
    if (task) {
      setContactType(task.contactType as 'ligacao' | 'whatsapp');
      setTaskDate(task.taskDate);
      setTaskTime(task.taskTime || '');
      setNotes(task.notes || '');
      setPriority(task.priority || 'media');
    }
  }, [task]);

  const handleSave = async () => {
    if (!task) return;

    if (!taskDate) {
      toast.error('Selecione uma data.');
      return;
    }

    setSaving(true);

    try {
      const updateData: Record<string, any> = {
        contact_type: contactType,
        notes: notes.trim() || null,
        priority,
      };

      // Only include date/time if user has permission
      if (canEditDate) {
        updateData.task_date = taskDate;
        updateData.task_time = taskTime || null;
      }

      const { error } = await supabase
        .from('tasks')
        .update(updateData)
        .eq('id', task.id);

      if (error) {
        // Check if it's the date block error
        if (error.message?.includes('DATA_BLOQUEADA') || error.message?.includes('Não é permitido alterar a data')) {
          toast.error('Data da tarefa é travada. Solicite ao Henrique ou cancele e crie outra com a data correta.');
          return;
        }
        throw error;
      }

      toast.success('Tarefa atualizada!');
      onOpenChange(false);
      onSaved();
    } catch (error: any) {
      console.error('Error updating task:', error);
      toast.error(error.message || 'Erro ao atualizar tarefa');
    } finally {
      setSaving(false);
    }
  };

  if (!task) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Editar Tarefa</DialogTitle>
        </DialogHeader>

        <div className="space-y-5 pt-4">
          {/* Client (read-only) */}
          <div className="space-y-2">
            <Label>Cliente</Label>
            <div className="p-3 bg-muted rounded-lg">
              <p className="font-medium">{task.clientName}</p>
            </div>
          </div>

          {/* Contact Type */}
          <div className="space-y-3">
            <Label>Tipo de contato</Label>
            <RadioGroup
              value={contactType}
              onValueChange={(value) => setContactType(value as 'ligacao' | 'whatsapp')}
              className="grid grid-cols-2 gap-3"
            >
              <div
                className={cn(
                  'flex items-center gap-3 p-4 rounded-lg border cursor-pointer transition-colors',
                  contactType === 'ligacao'
                    ? 'border-primary bg-primary/5'
                    : 'border-border hover:bg-muted/50'
                )}
                onClick={() => setContactType('ligacao')}
              >
                <RadioGroupItem value="ligacao" id="edit-ligacao" className="sr-only" />
                <Phone className="h-5 w-5 text-primary" />
                <Label htmlFor="edit-ligacao" className="cursor-pointer font-medium">
                  Ligação
                </Label>
              </div>

              <div
                className={cn(
                  'flex items-center gap-3 p-4 rounded-lg border cursor-pointer transition-colors',
                  contactType === 'whatsapp'
                    ? 'border-green-500 bg-green-500/5'
                    : 'border-border hover:bg-muted/50'
                )}
                onClick={() => setContactType('whatsapp')}
              >
                <RadioGroupItem value="whatsapp" id="edit-whatsapp" className="sr-only" />
                <MessageCircle className="h-5 w-5 text-green-500" />
                <Label htmlFor="edit-whatsapp" className="cursor-pointer font-medium">
                  WhatsApp
                </Label>
              </div>
            </RadioGroup>
          </div>

          {/* Priority */}
          <div className="space-y-3">
            <Label className="flex items-center gap-2">
              <Flag className="h-4 w-4" />
              Prioridade
            </Label>
            <RadioGroup
              value={priority}
              onValueChange={(value) => setPriority(value as 'alta' | 'media' | 'baixa')}
              className="grid grid-cols-3 gap-3"
            >
              {priorityOptions.map((option) => (
                <div
                  key={option.value}
                  className={cn(
                    'flex items-center justify-center gap-2 p-3 rounded-lg border cursor-pointer transition-colors text-sm font-medium',
                    priority === option.value
                      ? option.color
                      : 'border-border hover:bg-muted/50'
                  )}
                  onClick={() => setPriority(option.value as 'alta' | 'media' | 'baixa')}
                >
                  <RadioGroupItem value={option.value} id={`priority-${option.value}`} className="sr-only" />
                  <Label htmlFor={`priority-${option.value}`} className="cursor-pointer">
                    {option.label}
                  </Label>
                </div>
              ))}
            </RadioGroup>
          </div>

          {/* Date and Time */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="editTaskDate" className="flex items-center gap-2">
                <Calendar className="h-4 w-4" />
                Data
                {!canEditDate && <Lock className="h-3 w-3 text-muted-foreground" />}
              </Label>
              <Input
                id="editTaskDate"
                type="date"
                value={taskDate}
                onChange={(e) => setTaskDate(e.target.value)}
                disabled={!canEditDate}
                className={!canEditDate ? 'cursor-not-allowed opacity-60' : ''}
              />
              {!canEditDate && (
                <p className="text-xs text-muted-foreground">
                  🔒 Data bloqueada. Cancele e crie nova tarefa.
                </p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="editTaskTime" className="flex items-center gap-2">
                <Clock className="h-4 w-4" />
                Hora (opcional)
              </Label>
              <Input
                id="editTaskTime"
                type="time"
                value={taskTime}
                onChange={(e) => setTaskTime(e.target.value)}
                disabled={!canEditDate}
                className={!canEditDate ? 'cursor-not-allowed opacity-60' : ''}
              />
            </div>
          </div>

          {/* Notes */}
          <div className="space-y-2">
            <Label htmlFor="editNotes">Observações</Label>
            <Textarea
              id="editNotes"
              placeholder="Adicione detalhes..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={3}
            />
          </div>

          {/* Actions */}
          <div className="flex gap-3 pt-4">
            <Button
              variant="outline"
              onClick={() => onOpenChange(false)}
              className="flex-1"
            >
              Cancelar
            </Button>
            <Button onClick={handleSave} disabled={saving} className="flex-1">
              {saving ? 'Salvando...' : 'Salvar'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
