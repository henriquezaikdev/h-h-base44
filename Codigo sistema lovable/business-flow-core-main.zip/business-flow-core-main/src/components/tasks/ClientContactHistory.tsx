import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { format, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { 
  Phone, 
  MessageCircle, 
  CheckCircle, 
  XCircle,
  Loader2,
  History,
  User,
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

interface ContactHistoryItem {
  id: string;
  contact_type: 'ligacao' | 'whatsapp';
  completed_at: string;
  completion_notes: string | null;
  contact_successful: boolean | null;
  is_attempt: boolean | null;
  seller_name: string | null;
}

interface ClientContactHistoryProps {
  clientId: string | null;
  className?: string;
}

export function ClientContactHistory({ clientId, className }: ClientContactHistoryProps) {
  const [contacts, setContacts] = useState<ContactHistoryItem[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (clientId) {
      fetchContactHistory();
    } else {
      setContacts([]);
    }
  }, [clientId]);

  const fetchContactHistory = async () => {
    if (!clientId) return;
    
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('tasks')
        .select(`
          id,
          contact_type,
          completed_at,
          completion_notes,
          contact_successful,
          is_attempt,
          sellers:created_by_seller_id(name)
        `)
        .eq('client_id', clientId)
        .eq('status', 'concluida')
        .not('completed_at', 'is', null)
        .order('completed_at', { ascending: false })
        .limit(2);

      if (error) throw error;

      const formatted: ContactHistoryItem[] = (data || []).map((item: any) => ({
        id: item.id,
        contact_type: item.contact_type,
        completed_at: item.completed_at,
        completion_notes: item.completion_notes,
        contact_successful: item.contact_successful,
        is_attempt: item.is_attempt,
        seller_name: item.sellers?.name || null,
      }));

      setContacts(formatted);
    } catch (error) {
      console.error('Error fetching contact history:', error);
      setContacts([]);
    } finally {
      setLoading(false);
    }
  };

  if (!clientId) return null;

  if (loading) {
    return (
      <div className={cn("flex items-center gap-2 text-sm text-muted-foreground py-2", className)}>
        <Loader2 className="h-4 w-4 animate-spin" />
        <span>Carregando histórico...</span>
      </div>
    );
  }

  if (contacts.length === 0) {
    return (
      <div className={cn("text-sm text-muted-foreground italic py-2", className)}>
        Nenhum contato registrado com este cliente
      </div>
    );
  }

  return (
    <div className={cn("space-y-2", className)}>
      <div className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
        <History className="h-4 w-4" />
        <span>Últimos {contacts.length} contato{contacts.length > 1 ? 's' : ''}</span>
      </div>
      
      <div className="space-y-2">
        {contacts.map((contact) => (
          <div
            key={contact.id}
            className={cn(
              "p-3 rounded-lg border text-sm",
              contact.contact_successful 
                ? "bg-emerald-500/5 border-emerald-500/20" 
                : "bg-amber-500/5 border-amber-500/20"
            )}
          >
            {/* Header: Date, Type, Status */}
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                {contact.contact_type === 'whatsapp' ? (
                  <MessageCircle className="h-3.5 w-3.5 text-emerald-600" />
                ) : (
                  <Phone className="h-3.5 w-3.5 text-blue-600" />
                )}
                <span className="text-muted-foreground text-xs">
                  {format(parseISO(contact.completed_at), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}
                </span>
              </div>
              
              {contact.contact_successful ? (
                <Badge variant="outline" className="text-xs bg-emerald-500/10 text-emerald-600 border-emerald-500/30">
                  <CheckCircle className="h-3 w-3 mr-1" />
                  Sucesso
                </Badge>
              ) : (
                <Badge variant="outline" className="text-xs bg-amber-500/10 text-amber-600 border-amber-500/30">
                  <XCircle className="h-3 w-3 mr-1" />
                  Tentativa
                </Badge>
              )}
            </div>
            
            {/* Notes */}
            {contact.completion_notes && (
              <p className="text-foreground line-clamp-2">
                {contact.completion_notes}
              </p>
            )}
            
            {/* Seller */}
            {contact.seller_name && (
              <div className="flex items-center gap-1 mt-2 text-xs text-muted-foreground">
                <User className="h-3 w-3" />
                <span>{contact.seller_name}</span>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
