import { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandItem,
  CommandList,
} from '@/components/ui/command';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/useAuth';
import { useSellerDepartment } from '@/hooks/useSellerDepartment';
import { upsertTask } from '@/lib/taskUtils';
import { buildDraftKey, readDraft, writeDraft, clearDraft, hasDraft } from '@/lib/drafts';
import { CONTACT_REASON_OPTIONS, ContactReason } from '@/hooks/useTasksData';
import { SELLER_METRICS_QUERY_KEY } from '@/hooks/useSellerMetrics';
import { Phone, MessageCircle, Check, ChevronsUpDown, Calendar as CalendarIcon, Clock, Flag, Target, Layers } from 'lucide-react';
import { Calendar as CalendarPicker } from '@/components/ui/calendar';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { cn } from '@/lib/utils';

interface Client {
  id: string;
  company_name: string;
}

interface TaskModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  clientId?: string;
  clientName?: string;
  onSaved: () => void;
}

export type ModuleType = 'CRM' | 'COTACAO' | 'COMPRA' | 'NOTA_FISCAL' | 'INTERNA';

const MODULE_TYPE_OPTIONS: { value: ModuleType; label: string }[] = [
  { value: 'CRM', label: 'CRM (Cliente)' },
  { value: 'COTACAO', label: 'Cotação' },
  { value: 'COMPRA', label: 'Compra' },
  { value: 'NOTA_FISCAL', label: 'Nota Fiscal' },
  { value: 'INTERNA', label: 'Interna' },
];

const priorityOptions = [
  { value: 'alta', label: 'Alta', color: 'text-red-600 border-red-500 bg-red-500/5' },
  { value: 'media', label: 'Média', color: 'text-yellow-600 border-yellow-500 bg-yellow-500/5' },
  { value: 'baixa', label: 'Baixa', color: 'text-green-600 border-green-500 bg-green-500/5' },
];

export function TaskModal({
  open,
  onOpenChange,
  clientId,
  clientName,
  onSaved,
}: TaskModalProps) {
  const queryClient = useQueryClient();
  const [clients, setClients] = useState<Client[]>([]);
  const [selectedClientId, setSelectedClientId] = useState<string>(clientId || '');
  const [selectedClientName, setSelectedClientName] = useState<string>(clientName || '');
  const [contactType, setContactType] = useState<'ligacao' | 'whatsapp'>('ligacao');
  const [contactReason, setContactReason] = useState<ContactReason>('RETORNO');
  const [taskDate, setTaskDate] = useState('');
  const [taskTime, setTaskTime] = useState('');
  const [notes, setNotes] = useState('');
  const [priority, setPriority] = useState<'alta' | 'media' | 'baixa'>('media');
  const [clientPopoverOpen, setClientPopoverOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();
  const { user, seller } = useAuth();
  const { department } = useSellerDepartment();

  // Default module based on department
  const defaultModule: ModuleType = (department === 'financeiro_gestora' || department === 'logistica') ? 'COTACAO' : 'CRM';
  const [moduleType, setModuleType] = useState<ModuleType>(defaultModule);

  // Update default when department loads
  useEffect(() => {
    if (department === 'financeiro_gestora' || department === 'logistica') {
      setModuleType('COTACAO');
    }
  }, [department]);

  const draftKey = useMemo(() => {
    if (!open) return null;
    return buildDraftKey([
      'clientes',
      'draft',
      user?.id || 'unknown',
      selectedClientId || clientId || 'no-client',
      'taskModal',
    ]);
  }, [open, user?.id, selectedClientId, clientId]);

  const hasNotesDraft = useMemo(() => {
    return draftKey ? hasDraft(draftKey, 'session') : false;
  }, [draftKey]);

  // Restore draft when modal opens
  useEffect(() => {
    if (!open || !draftKey) return;

    const stored = readDraft<{ value: any }>(draftKey, 'session');
    if (stored?.value) {
      const v = stored.value as Partial<{
        selectedClientId: string;
        selectedClientName: string;
        contactType: 'ligacao' | 'whatsapp';
        contactReason: ContactReason;
        taskDate: string;
        taskTime: string;
        notes: string;
        priority: 'alta' | 'media' | 'baixa';
      }>;

      if (typeof v.selectedClientId === 'string' && v.selectedClientId) setSelectedClientId(v.selectedClientId);
      if (typeof v.selectedClientName === 'string') setSelectedClientName(v.selectedClientName);
      if (v.contactType === 'ligacao' || v.contactType === 'whatsapp') setContactType(v.contactType);
      if (v.contactReason) setContactReason(v.contactReason);
      if (typeof v.taskDate === 'string' && v.taskDate) setTaskDate(v.taskDate);
      if (typeof v.taskTime === 'string') setTaskTime(v.taskTime);
      if (typeof v.notes === 'string') setNotes(v.notes);
      if (v.priority === 'alta' || v.priority === 'media' || v.priority === 'baixa') setPriority(v.priority);
    }
  }, [open, draftKey]);

  // Autosave draft (debounce)
  useEffect(() => {
    if (!open || !draftKey) return;

    const t = setTimeout(() => {
      writeDraft(
        draftKey,
        {
          value: {
            selectedClientId,
            selectedClientName,
            contactType,
            contactReason,
            taskDate,
            taskTime,
            notes,
            priority,
          },
          savedAt: Date.now(),
        },
        'session'
      );
    }, 500);

    return () => clearTimeout(t);
  }, [open, draftKey, selectedClientId, selectedClientName, contactType, contactReason, taskDate, taskTime, notes, priority]);


  const [clientSearch, setClientSearch] = useState('');
  const [loadingClients, setLoadingClients] = useState(false);
  const [clientsError, setClientsError] = useState<string | null>(null);

  const buscarClientes = useCallback(async (term: string) => {
    const clean = term.trim();

    console.log('[CLIENT_SEARCH] term:', clean);
    console.log('[CLIENT_SEARCH] calling buscarClientes');

    // Não buscar com 1 caractere (evita parecer "bugado" e reduz carga)
    if (clean.length > 0 && clean.length < 2) {
      setClientsError(null);
      setClients([]);
      console.log('[CLIENT_SEARCH] results length:', 0);
      return;
    }

    setLoadingClients(true);
    setClientsError(null);

    try {
      let query = supabase
        .from('clients')
        .select('id, company_name')
        .eq('is_deleted', false);

      if (clean.length === 0) {
        // Recentes ao abrir (prova que está buscando)
        query = query.order('updated_at', { ascending: false }).limit(10);
      } else {
        // Busca por nome e também por CNPJ (mesma ideia usada em outras telas)
        query = query
          .or(`company_name.ilike.%${clean}%,cnpj.ilike.%${clean}%`)
          .order('company_name')
          .limit(25);
      }

      const { data, error } = await query;

      if (error) {
        console.error('[CLIENT_SEARCH] error:', error);
        setClientsError(error.message || 'Erro ao buscar clientes');
        setClients([]);
        console.log('[CLIENT_SEARCH] results length:', 0);
        return;
      }

      const results = data ?? [];
      setClients(results);
      console.log('[CLIENT_SEARCH] results length:', results.length);
    } catch (err: any) {
      console.error('[CLIENT_SEARCH] error:', err);
      setClientsError(err?.message || 'Erro ao buscar clientes');
      setClients([]);
      console.log('[CLIENT_SEARCH] results length:', 0);
    } finally {
      setLoadingClients(false);
    }
  }, []);

  // Ao abrir, buscar recentes imediatamente (searchTerm vazio)
  useEffect(() => {
    if (!clientPopoverOpen) return;
    void buscarClientes('');
  }, [clientPopoverOpen, buscarClientes]);

  // Busca com debounce ao digitar
  useEffect(() => {
    if (!clientPopoverOpen) return;

    const timer = setTimeout(() => {
      void buscarClientes(clientSearch);
    }, 350);

    return () => clearTimeout(timer);
  }, [clientSearch, clientPopoverOpen, buscarClientes]);

  // Ref to prevent double submit
  const isSubmittingRef = useRef(false);

  const handleSave = useCallback(async () => {
    // Prevent double submit
    if (saving || isSubmittingRef.current) {
      return;
    }

    if (moduleType === 'CRM' && !selectedClientId) {
      toast({
        title: 'Erro',
        description: 'Selecione um cliente para tarefas CRM.',
        variant: 'destructive',
      });
      return;
    }

    if (!taskDate) {
      toast({
        title: 'Erro',
        description: 'Selecione uma data.',
        variant: 'destructive',
      });
      return;
    }

    if (!contactReason) {
      toast({
        title: 'Erro',
        description: 'Selecione o motivo do contato.',
        variant: 'destructive',
      });
      return;
    }

    isSubmittingRef.current = true;
    setSaving(true);

    try {
      await upsertTask(supabase, {
        client_id: moduleType === 'CRM' ? selectedClientId : null,
        contact_type: contactType,
        contact_reason: contactReason,
        task_date: taskDate,
        task_time: taskTime || null,
        notes: notes.trim() || null,
        created_by_seller_id: seller?.id || null,
        priority,
        source: 'manual',
        module_type: moduleType,
      });

      toast({
        title: 'Tarefa criada',
        description: `Tarefa agendada para ${new Date(taskDate).toLocaleDateString('pt-BR')}.`,
      });

      // INVALIDAR CACHE DE MÉTRICAS PARA ATUALIZAÇÃO IMEDIATA
      queryClient.invalidateQueries({ queryKey: [SELLER_METRICS_QUERY_KEY] });

      if (draftKey) clearDraft(draftKey, 'session');

      onOpenChange(false);
      resetForm();
      onSaved();
    } catch (error: any) {
      console.error('Error saving task:', error);
      toast({
        title: 'Erro ao criar tarefa',
        description: error.message,
        variant: 'destructive',
      });
    } finally {
      setSaving(false);
      isSubmittingRef.current = false;
    }
  }, [saving, selectedClientId, taskDate, contactType, contactReason, taskTime, notes, seller?.id, priority, moduleType, onOpenChange, onSaved, toast, draftKey]);


  const resetForm = () => {
    if (!clientId) {
      setSelectedClientId('');
      setSelectedClientName('');
    }
    setContactType('ligacao');
    setContactReason('RETORNO');
    // Reset to today in São Paulo timezone
    const today = new Intl.DateTimeFormat('sv-SE', {
      timeZone: 'America/Sao_Paulo',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    }).format(new Date());
    setTaskDate(today);
    setTaskTime('');
    setNotes('');
    setPriority('media');
    setModuleType(defaultModule);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Nova Tarefa</DialogTitle>
        </DialogHeader>

        <div className="space-y-5 pt-4">
          {/* Module Type - REQUIRED, FIRST */}
          <div className="space-y-2">
            <Label className="flex items-center gap-2">
              <Layers className="h-4 w-4" />
              Vínculo / Módulo *
            </Label>
            <Select value={moduleType} onValueChange={(v) => setModuleType(v as ModuleType)}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione o módulo..." />
              </SelectTrigger>
              <SelectContent>
                {MODULE_TYPE_OPTIONS.map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Contact Reason - REQUIRED */}
          <div className="space-y-2">
            <Label className="flex items-center gap-2">
              <Target className="h-4 w-4" />
              Motivo do Contato *
            </Label>
            <Select value={contactReason} onValueChange={(v) => setContactReason(v as ContactReason)}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione o motivo..." />
              </SelectTrigger>
              <SelectContent>
                {CONTACT_REASON_OPTIONS.map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Client Selection - only when module is CRM */}
          {moduleType === 'CRM' && !clientId && (
            <div className="space-y-2">
              <Label>Cliente *</Label>
              <Popover open={clientPopoverOpen} onOpenChange={setClientPopoverOpen}>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    role="combobox"
                    aria-expanded={clientPopoverOpen}
                    className="w-full justify-between"
                  >
                    {selectedClientName || 'Selecione um cliente...'}
                    <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-full p-0" align="start">
                  <Command shouldFilter={false}>
                    {/* INPUT CONTROLADO (sem cmdk Input) */}
                    <div className="border-b p-2">
                      <Input
                        placeholder="Buscar cliente..."
                        value={clientSearch}
                        onChange={(e) => {
                          const term = e.target.value;
                          console.log('[CLIENT_SEARCH] term:', term);
                          setClientSearch(term);
                        }}
                      />
                    </div>

                    <CommandList>
                      {loadingClients ? (
                        <div className="p-4 text-center text-sm text-muted-foreground">Carregando...</div>
                      ) : clientsError ? (
                        <div className="p-4 text-center text-sm text-destructive">
                          Erro ao buscar clientes: {clientsError}
                        </div>
                      ) : clientSearch.trim().length > 0 && clientSearch.trim().length < 2 ? (
                        <div className="p-4 text-center text-sm text-muted-foreground">
                          Digite pelo menos 2 letras para buscar.
                        </div>
                      ) : clients.length === 0 ? (
                        <CommandEmpty>
                          {clientSearch.trim().length === 0 ? 'Nenhum cliente recente encontrado.' : 'Nenhum cliente encontrado.'}
                        </CommandEmpty>
                      ) : (
                        <CommandGroup
                          heading={clientSearch.trim().length === 0 ? 'Recentes' : 'Resultados'}
                          className="max-h-60 overflow-y-auto"
                        >
                          {clients.map((client) => (
                            <CommandItem
                              key={client.id}
                              value={client.company_name}
                              onSelect={() => {
                                setSelectedClientId(client.id);
                                setSelectedClientName(client.company_name);
                                setClientPopoverOpen(false);
                                setClientSearch('');
                              }}
                            >
                              <Check
                                className={cn(
                                  'mr-2 h-4 w-4',
                                  selectedClientId === client.id ? 'opacity-100' : 'opacity-0'
                                )}
                              />
                              {client.company_name}
                            </CommandItem>
                          ))}
                        </CommandGroup>
                      )}
                    </CommandList>
                  </Command>
                </PopoverContent>
              </Popover>
            </div>
          )}
          {moduleType === 'CRM' && clientId && (
            <div className="space-y-2">
              <Label>Cliente</Label>
              <div className="p-3 bg-muted rounded-lg">
                <p className="font-medium">{clientName}</p>
              </div>
            </div>
          )}

          {/* Contact Type */}
          <div className="space-y-3">
            <Label>Tipo de contato *</Label>
            <RadioGroup
              value={contactType}
              onValueChange={(value) => setContactType(value as 'ligacao' | 'whatsapp')}
              className="grid grid-cols-2 gap-3"
            >
              <div
                className={cn(
                  'flex items-center gap-3 p-4 rounded-lg border cursor-pointer transition-colors',
                  contactType === 'ligacao'
                    ? 'border-primary bg-primary/5'
                    : 'border-border hover:bg-muted/50'
                )}
                onClick={() => setContactType('ligacao')}
              >
                <RadioGroupItem value="ligacao" id="ligacao" className="sr-only" />
                <Phone className="h-5 w-5 text-primary" />
                <Label htmlFor="ligacao" className="cursor-pointer font-medium">
                  Ligação
                </Label>
              </div>

              <div
                className={cn(
                  'flex items-center gap-3 p-4 rounded-lg border cursor-pointer transition-colors',
                  contactType === 'whatsapp'
                    ? 'border-green-500 bg-green-500/5'
                    : 'border-border hover:bg-muted/50'
                )}
                onClick={() => setContactType('whatsapp')}
              >
                <RadioGroupItem value="whatsapp" id="whatsapp" className="sr-only" />
                <MessageCircle className="h-5 w-5 text-green-500" />
                <Label htmlFor="whatsapp" className="cursor-pointer font-medium">
                  WhatsApp
                </Label>
              </div>
            </RadioGroup>
          </div>

          {/* Priority */}
          <div className="space-y-3">
            <Label className="flex items-center gap-2">
              <Flag className="h-4 w-4" />
              Prioridade
            </Label>
            <RadioGroup
              value={priority}
              onValueChange={(value) => setPriority(value as 'alta' | 'media' | 'baixa')}
              className="grid grid-cols-3 gap-3"
            >
              {priorityOptions.map((option) => (
                <div
                  key={option.value}
                  className={cn(
                    'flex items-center justify-center gap-2 p-3 rounded-lg border cursor-pointer transition-colors text-sm font-medium',
                    priority === option.value
                      ? option.color
                      : 'border-border hover:bg-muted/50'
                  )}
                  onClick={() => setPriority(option.value as 'alta' | 'media' | 'baixa')}
                >
                  <RadioGroupItem value={option.value} id={`new-priority-${option.value}`} className="sr-only" />
                  <Label htmlFor={`new-priority-${option.value}`} className="cursor-pointer">
                    {option.label}
                  </Label>
                </div>
              ))}
            </RadioGroup>
          </div>

          {/* Date and Time */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="flex items-center gap-2">
                <CalendarIcon className="h-4 w-4" />
                Data *
              </Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className={cn("w-full justify-start text-left font-normal", !taskDate && "text-muted-foreground")}>
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {taskDate ? format(new Date(taskDate + 'T12:00:00'), "dd/MM/yyyy") : 'Selecionar data'}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0 z-[10200]" align="start">
                  <CalendarPicker
                    mode="single"
                    selected={taskDate ? new Date(taskDate + 'T12:00:00') : undefined}
                    onSelect={(d) => d && setTaskDate(format(d, 'yyyy-MM-dd'))}
                    disabled={(date) => date < new Date(new Date().toDateString())}
                    locale={ptBR}
                    initialFocus
                    className="pointer-events-auto"
                  />
                </PopoverContent>
              </Popover>
            </div>

            <div className="space-y-2">
              <Label htmlFor="taskTime" className="flex items-center gap-2">
                <Clock className="h-4 w-4" />
                Hora (opcional)
              </Label>
              <Input
                id="taskTime"
                type="time"
                value={taskTime}
                onChange={(e) => setTaskTime(e.target.value)}
              />
            </div>
          </div>

          {/* Notes */}
          <div className="space-y-2">
            <Label htmlFor="notes">Observações (opcional)</Label>
            <Textarea
              id="notes"
              placeholder="Adicione detalhes sobre esta tarefa..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={3}
            />
          </div>

          {/* Actions */}
          <div className="flex gap-3 pt-4">
            <Button
              variant="outline"
              onClick={() => onOpenChange(false)}
              className="flex-1"
            >
              Cancelar
            </Button>
            <Button onClick={handleSave} disabled={saving} className="flex-1">
              {saving ? 'Salvando...' : 'Criar Tarefa'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
