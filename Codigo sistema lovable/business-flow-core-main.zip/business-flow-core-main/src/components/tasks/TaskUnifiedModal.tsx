import { useState, useEffect, useCallback, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQueryClient } from '@tanstack/react-query';
import { useSellerDepartment } from '@/hooks/useSellerDepartment';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { Checkbox } from '@/components/ui/checkbox';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Command, CommandEmpty, CommandGroup, CommandItem, CommandList } from '@/components/ui/command';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { 
  Phone, 
  MessageCircle, 
  CheckCircle, 
  PhoneOff, 
  MessageSquareOff,
  Calendar,
  Clock,
  Flag,
  Target,
  Building2,
  Package,
  DollarSign,
  History,
  ShoppingCart,
  FileText,
  Loader2,
  Save,
  AlertTriangle,
  User,
  ChevronDown,
  ChevronUp,
  Plus,
  X,
  Check,
  ChevronsUpDown,
  CreditCard,
  ClipboardCheck,
  ExternalLink,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { TaskData, ContactReason, CONTACT_REASON_OPTIONS, PlanningProduct } from '@/hooks/useTasksData';
import { useTaskDatePermission } from '@/hooks/useTaskDatePermission';
import { useAuth } from '@/hooks/useAuth';
import { useClientPaymentTerm } from '@/hooks/useClientPaymentTerm';
import { SELLER_METRICS_QUERY_KEY } from '@/hooks/useSellerMetrics';
import { format, parseISO, isToday, isPast } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { TaskReplicationModal } from './TaskReplicationModal';
import { ProductSearchCombobox } from './ProductSearchCombobox';
import { upsertTask } from '@/lib/taskUtils';
import { ClientContactHistory } from './ClientContactHistory';
import { ClientOrdersModal } from '@/components/client/ClientOrdersModal';

interface Seller {
  id: string;
  name: string;
}

interface Client {
  id: string;
  company_name: string;
}

interface ClientData {
  id: string;
  company_name: string;
  cnpj: string | null;
  phone: string | null;
  email: string | null;
  ranking_tier: string | null;
  total_revenue: number | null;
  days_since_last_order: number | null;
  last_contact_at: string | null;
  observations: string | null;
  seller_id: string | null;
}

interface OrderData {
  id: string;
  order_number: string;
  order_date: string;
  total: number;
}

interface ProductHistoryItem {
  product_name: string;
  total_qty: number;
  last_price: number;
  last_order_date: string;
}

// Mode: create (new task) or edit (existing task)
type ModalMode = 'create' | 'edit';

interface TaskUnifiedModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  mode: ModalMode;
  // For edit mode - existing task data
  task?: TaskData | null;
  // For create mode - pre-selected client
  clientId?: string;
  clientName?: string;
  // Common props
  sellers: Seller[];
  onCompleted: () => void;
}

const priorityOptions = [
  { value: 'alta', label: 'Alta', color: 'text-red-600 border-red-500 bg-red-500/10' },
  { value: 'media', label: 'Média', color: 'text-amber-600 border-amber-500 bg-amber-500/10' },
  { value: 'baixa', label: 'Baixa', color: 'text-emerald-600 border-emerald-500 bg-emerald-500/10' },
];

const ATTEMPT_TYPES = [
  { value: 'whatsapp_sem_resposta', label: 'WhatsApp — sem resposta', icon: MessageSquareOff },
  { value: 'ligacao_sem_resposta', label: 'Ligação — sem resposta', icon: PhoneOff },
];

// Sub-component for Client KPIs with Payment Term
function ClientKPIs({ 
  clientData, 
  recentOrders, 
  formatCurrency,
  onOrdersClick,
}: { 
  clientData: ClientData; 
  recentOrders: OrderData[]; 
  formatCurrency: (v: number) => string;
  onOrdersClick?: () => void;
}) {
  const { avgPaymentDays, loading: loadingPayment, totalOrders } = useClientPaymentTerm(clientData.id);

  return (
    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
      <div className="p-3 bg-muted/30 rounded-lg">
        <div className="flex items-center gap-2 text-muted-foreground text-xs mb-1">
          <DollarSign className="h-3 w-3" />
          Faturamento
        </div>
        <p className="font-semibold">{formatCurrency(clientData.total_revenue || 0)}</p>
      </div>
      {/* Pedidos clicável */}
      <button
        onClick={onOrdersClick}
        className="p-3 bg-muted/30 rounded-lg text-left hover:bg-muted/50 transition-colors cursor-pointer group"
      >
        <div className="flex items-center gap-2 text-muted-foreground text-xs mb-1 group-hover:text-primary transition-colors">
          <Package className="h-3 w-3" />
          Pedidos
        </div>
        <p className="font-semibold group-hover:text-primary transition-colors">{recentOrders.length}+ pedidos</p>
      </button>
      <div className="p-3 bg-muted/30 rounded-lg">
        <div className="flex items-center gap-2 text-muted-foreground text-xs mb-1">
          <Clock className="h-3 w-3" />
          Última compra
        </div>
        <p className="font-semibold">{clientData.days_since_last_order ?? '—'} dias</p>
      </div>
      {/* Payment Term KPI */}
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <div className="p-3 bg-primary/5 border border-primary/20 rounded-lg cursor-help">
              <div className="flex items-center gap-2 text-primary text-xs mb-1">
                <CreditCard className="h-3 w-3" />
                Prazo Médio Pgto
              </div>
              {loadingPayment ? (
                <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
              ) : avgPaymentDays !== null && totalOrders > 0 ? (
                <p className="font-semibold text-primary">{avgPaymentDays} dias</p>
              ) : (
                <p className="text-sm text-muted-foreground">Sem histórico</p>
              )}
            </div>
          </TooltipTrigger>
          <TooltipContent>
            {avgPaymentDays !== null && totalOrders > 0 ? (
              <>
                <p>Baseado em {totalOrders} pedido{totalOrders > 1 ? 's' : ''}</p>
                <p className="text-xs text-muted-foreground">Calculado a partir do histórico real</p>
              </>
            ) : (
              <p>Nenhum pedido com prazo registrado</p>
            )}
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    </div>
  );
}

// Sub-component for Origin Block (compras/cotação link)
function OriginBlock({ sourceModule, relatedType, relatedId }: { sourceModule: string; relatedType: string; relatedId: string }) {
  const navigate = useNavigate();
  
  const moduleLabels: Record<string, string> = {
    compras: '🛒 Compras',
    cotacao: '📋 Cotação',
    entregas: '🚚 Entregas',
  };

  const handleOpenOrigin = () => {
    if (sourceModule === 'compras' || relatedType === 'solicitacoes_compra') {
      navigate(`/compras?solicitacao=${relatedId}`);
    } else if (sourceModule === 'cotacao' || relatedType === 'cotacao_itens') {
      navigate(`/compras?cotacao=${relatedId}`);
    } else {
      navigate('/compras');
    }
  };

  return (
    <div className="flex items-center gap-3 p-3 bg-amber-500/5 border border-amber-500/20 rounded-lg">
      <div className="w-8 h-8 rounded-lg bg-amber-500/10 flex items-center justify-center shrink-0">
        <ShoppingCart className="h-4 w-4 text-amber-600" />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-xs text-muted-foreground">Origem automática</p>
        <p className="text-sm font-medium truncate">
          {moduleLabels[sourceModule] || sourceModule || 'Sistema'}
        </p>
      </div>
      <Button variant="outline" size="sm" className="gap-1.5 shrink-0" onClick={handleOpenOrigin}>
        <ExternalLink className="h-3.5 w-3.5" />
        Abrir origem
      </Button>
    </div>
  );
}

export function TaskUnifiedModal({
  open,
  onOpenChange,
  mode,
  task,
  clientId: propClientId,
  clientName: propClientName,
  sellers,
  onCompleted,
}: TaskUnifiedModalProps) {
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const { seller } = useAuth();
  const { canEditDate } = useTaskDatePermission();
  
  // Client selection state (for create mode)
  const [selectedClientId, setSelectedClientId] = useState<string>(propClientId || '');
  const [selectedClientName, setSelectedClientName] = useState<string>(propClientName || '');
  const [clientPopoverOpen, setClientPopoverOpen] = useState(false);
  const [clientSearch, setClientSearch] = useState('');
  const [clients, setClients] = useState<Client[]>([]);
  const [loadingClients, setLoadingClients] = useState(false);
  
  // Task editing state
  const [contactType, setContactType] = useState<'ligacao' | 'whatsapp'>('ligacao');
  const [contactReason, setContactReason] = useState<ContactReason>('RETORNO');
  const [taskDate, setTaskDate] = useState('');
  const [taskTime, setTaskTime] = useState('');
  const [notes, setNotes] = useState('');
  const [priority, setPriority] = useState<'alta' | 'media' | 'baixa'>('media');
  const [responsibleSellerId, setResponsibleSellerId] = useState<string>('');
  const [assignedToSellerId, setAssignedToSellerId] = useState<string>('');
  const [saving, setSaving] = useState(false);
  
  // Role-specific fields
  const { department } = useSellerDepartment();
  const [taskCategory, setTaskCategory] = useState<string>('');
  const [taskBucket, setTaskBucket] = useState<string>('HOJE');
  const [taskSteps, setTaskSteps] = useState<Array<{ label: string; done: boolean; done_at: string | null }>>([]);
  
  // Planning section state
  const [planningNotes, setPlanningNotes] = useState('');
  const [planningProducts, setPlanningProducts] = useState<PlanningProduct[]>([]);
  const [showPlanningExpanded, setShowPlanningExpanded] = useState(true);
  
  // Orçamento em aberto state
  const [temOrcamentoAberto, setTemOrcamentoAberto] = useState(false);
  const [orcamentoCaCodigo, setOrcamentoCaCodigo] = useState('');
  const [orcamentoValor, setOrcamentoValor] = useState('');
  
  // Completion section state (edit mode only)
  const [completionNotes, setCompletionNotes] = useState('');
  const [attemptType, setAttemptType] = useState<string>('');
  const [completing, setCompleting] = useState(false);
  
  // Replication modal state
  const [showReplicationModal, setShowReplicationModal] = useState(false);
  const [pendingCompletionType, setPendingCompletionType] = useState<'whatsapp' | 'ligacao' | 'attempt' | null>(null);
  
  // Client data state
  const [clientData, setClientData] = useState<ClientData | null>(null);
  const [recentOrders, setRecentOrders] = useState<OrderData[]>([]);
  const [productHistory, setProductHistory] = useState<ProductHistoryItem[]>([]);
  const [loadingClient, setLoadingClient] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  
  // Orders modal state
  const [showOrdersModal, setShowOrdersModal] = useState(false);


  // Get today's date in São Paulo timezone
  const getTodayDate = () => {
    return new Intl.DateTimeFormat('sv-SE', {
      timeZone: 'America/Sao_Paulo',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    }).format(new Date());
  };

  // Effective client ID (from task or selected)
  const effectiveClientId = mode === 'edit' ? task?.clientId : selectedClientId;
  const effectiveClientName = mode === 'edit' ? task?.clientName : selectedClientName;

  // Search clients
  const searchClients = useCallback(async (term: string) => {
    const clean = term.trim();
    
    if (clean.length > 0 && clean.length < 2) {
      setClients([]);
      return;
    }

    setLoadingClients(true);
    try {
      let query = supabase
        .from('clients')
        .select('id, company_name')
        .eq('is_deleted', false);

      if (clean.length === 0) {
        query = query.order('updated_at', { ascending: false }).limit(10);
      } else {
        query = query
          .or(`company_name.ilike.%${clean}%,cnpj.ilike.%${clean}%`)
          .order('company_name')
          .limit(25);
      }

      const { data, error } = await query;
      if (error) throw error;
      setClients(data ?? []);
    } catch (err) {
      console.error('Error searching clients:', err);
      setClients([]);
    } finally {
      setLoadingClients(false);
    }
  }, []);

  // Fetch client data - does NOT change form fields like responsibleSellerId
  const fetchClientData = useCallback(async (clientId: string, autoSetSeller?: boolean) => {
    if (!clientId) return;
    
    setLoadingClient(true);
    try {
      const { data: client } = await supabase
        .from('clients')
        .select('id, company_name, cnpj, phone, email, ranking_tier, total_revenue, days_since_last_order, last_contact_at, observations, seller_id')
        .eq('id', clientId)
        .maybeSingle();
      
      if (client) {
        setClientData(client as ClientData);
        // Only auto-set responsible on initial load if explicitly requested
        if (autoSetSeller && client.seller_id) {
          setResponsibleSellerId(client.seller_id);
        }
      }
      
      const { data: orders } = await supabase
        .from('orders')
        .select('id, order_number, order_date, total')
        .eq('client_id', clientId)
        .order('order_date', { ascending: false })
        .limit(5);
      
      if (orders) {
        setRecentOrders(orders as OrderData[]);
      }
      
      const { data: products } = await supabase
        .from('order_items')
        .select('product_name, quantity, unit_price, orders!inner(client_id, order_date)')
        .eq('orders.client_id', clientId)
        .order('orders.order_date', { ascending: false })
        .limit(50);
      
      if (products && products.length > 0) {
        const productMap = new Map<string, ProductHistoryItem>();
        products.forEach((item: any) => {
          const existing = productMap.get(item.product_name);
          if (existing) {
            existing.total_qty += item.quantity || 0;
          } else {
            productMap.set(item.product_name, {
              product_name: item.product_name,
              total_qty: item.quantity || 0,
              last_price: item.unit_price || 0,
              last_order_date: item.orders?.order_date || '',
            });
          }
        });
        setProductHistory(Array.from(productMap.values()).slice(0, 10));
      }
    } catch (error) {
      console.error('Error fetching client data:', error);
    } finally {
      setLoadingClient(false);
    }
  }, []);

  // Initialize modal state - runs only once when modal opens
  useEffect(() => {
    if (!open) return;

    if (mode === 'edit' && task) {
      // Edit mode - load task data
      setContactType(task.contactType);
      setContactReason(task.contactReason || 'RETORNO');
      setTaskDate(task.taskDate);
      setTaskTime(task.taskTime || '');
      setNotes(task.notes || '');
      setPriority(task.priority || 'media');
      setResponsibleSellerId(task.createdBySellerId || '');
      setAssignedToSellerId(task.assignedToSellerId || '');
      // Load planning data from task
      setPlanningProducts(task.planningProducts || []);
      setPlanningNotes(task.planningNotes || '');
      setCompletionNotes('');
      setAttemptType('');
      // Load logistics fields
      setTaskSteps(task.taskSteps && task.taskSteps.length > 0 ? task.taskSteps : []);
      setTaskCategory(task.taskCategory || '');
      fetchClientData(task.clientId, false);
    } else {
      // Create mode - reset form
      setContactType('ligacao');
      setContactReason('RETORNO');
      setTaskDate(getTodayDate());
      setTaskTime('');
      setNotes('');
      setPriority('media');
      setResponsibleSellerId(seller?.id || '');
      setAssignedToSellerId('');
      setPlanningNotes('');
      setPlanningProducts([]);
      setCompletionNotes('');
      setAttemptType('');
      // Reset orçamento fields
      setTemOrcamentoAberto(false);
      setOrcamentoCaCodigo('');
      setOrcamentoValor('');
      // Reset role-specific fields
      setTaskCategory('');
      setTaskBucket('HOJE');
      setTaskSteps(department === 'logistica' ? [
        { label: 'Conferir produto', done: false, done_at: null },
        { label: 'Conferir quantidade', done: false, done_at: null },
        { label: 'Conferir nota', done: false, done_at: null },
        { label: 'Separar', done: false, done_at: null },
        { label: 'Liberar para entrega', done: false, done_at: null },
      ] : []);
      
      // If client is pre-selected
      if (propClientId) {
        setSelectedClientId(propClientId);
        setSelectedClientName(propClientName || '');
        fetchClientData(propClientId, true); // Auto-set seller on initial load
      } else {
        setSelectedClientId('');
        setSelectedClientName('');
        setClientData(null);
        setRecentOrders([]);
        setProductHistory([]);
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, mode, task?.id, propClientId]);

  // Search clients when popover opens or search changes
  useEffect(() => {
    if (!clientPopoverOpen) return;
    const timer = setTimeout(() => searchClients(clientSearch), 300);
    return () => clearTimeout(timer);
  }, [clientSearch, clientPopoverOpen, searchClients]);

  // Fetch client data when a NEW client is selected (not on every selectedClientId change)
  const handleClientSelect = useCallback((clientId: string, clientName: string) => {
    setSelectedClientId(clientId);
    setSelectedClientName(clientName);
    setClientPopoverOpen(false);
    setClientSearch('');
    // Load client data and auto-set seller only if seller not already chosen
    fetchClientData(clientId, !responsibleSellerId);
  }, [fetchClientData, responsibleSellerId]);

  const isEditMode = mode === 'edit';
  const isCompleted = isEditMode && task?.status === 'concluida';
  const isOverdue = isEditMode && task && !isCompleted && isPast(parseISO(task.taskDate)) && !isToday(parseISO(task.taskDate));
  const isDateDisabled = isCompleted || (isEditMode && !canEditDate);

  const handleSaveTask = async () => {
    // Validation
    if (!effectiveClientId) {
      toast.error('Selecione um cliente.');
      return;
    }
    
    if (!taskDate) {
      toast.error('Selecione uma data.');
      return;
    }

    if (!responsibleSellerId) {
      toast.error('Selecione um responsável.');
      return;
    }

    if (department !== 'financeiro_gestora' && !contactReason) {
      toast.error('Selecione o motivo do contato.');
      return;
    }

    // Role-specific validation
    if (department === 'financeiro_gestora' && !taskCategory) {
      toast.error('Selecione a categoria da tarefa (obrigatório para Financeiro/Gestora).');
      return;
    }

    setSaving(true);
    try {
      if (mode === 'create') {
        // Create new task - filter out empty products
        const validProducts = planningProducts.filter(p => p.name.trim());
        
        const createData: Record<string, any> = {
          client_id: effectiveClientId,
          contact_type: department === 'financeiro_gestora' ? 'ligacao' : contactType,
          contact_reason: department === 'financeiro_gestora' ? 'RETORNO' : contactReason,
          task_date: taskDate,
          task_time: taskTime || null,
          notes: notes.trim() || null,
          created_by_seller_id: responsibleSellerId,
          assigned_to_seller_id: assignedToSellerId || null,
          priority,
          source: 'manual',
          planning_products: validProducts,
          planning_notes: planningNotes.trim() || null,
          // Campos de orçamento
          tem_orcamento_aberto: temOrcamentoAberto,
          orcamento_ca_codigo: orcamentoCaCodigo.trim() || null,
          orcamento_valor: orcamentoValor ? parseFloat(orcamentoValor) : null,
          orcamento_aberto_em: temOrcamentoAberto ? new Date().toISOString() : null,
        };

        // Add role-specific fields
        if (department === 'financeiro_gestora') {
          createData.task_category = taskCategory;
          createData.task_bucket = taskBucket;
        }
        if (department === 'logistica' && taskSteps.length > 0) {
          createData.task_steps = taskSteps;
        }

        await upsertTask(supabase, createData as any);

        toast.success(`Tarefa criada para ${format(parseISO(taskDate), 'dd/MM/yyyy', { locale: ptBR })}`);
        queryClient.invalidateQueries({ queryKey: [SELLER_METRICS_QUERY_KEY] });
        queryClient.invalidateQueries({ queryKey: ['tasks'] });
        queryClient.invalidateQueries({ queryKey: ['actionCenter'] });
        onOpenChange(false);
        onCompleted();
      } else if (task) {
        // Update existing task - filter out empty products
        const validProducts = planningProducts.filter(p => p.name.trim());
        
        const updateData: Record<string, any> = {
          contact_type: contactType,
          contact_reason: contactReason,
          notes: notes.trim() || null,
          created_by_seller_id: responsibleSellerId,
          assigned_to_seller_id: assignedToSellerId || null,
          priority,
          planning_products: validProducts,
          planning_notes: planningNotes.trim() || null,
        };

        // Add role-specific fields to update
        if (department === 'financeiro_gestora') {
          updateData.task_category = taskCategory;
          updateData.task_bucket = taskBucket;
        }
        if (department === 'logistica' && taskSteps.length > 0) {
          updateData.task_steps = taskSteps;
        }

        if (!isCompleted && canEditDate) {
          updateData.task_date = taskDate;
          updateData.task_time = taskTime || null;
        }

        const { error } = await supabase
          .from('tasks')
          .update(updateData)
          .eq('id', task.id);

        if (error) throw error;

        toast.success('Tarefa atualizada!');
        queryClient.invalidateQueries({ queryKey: [SELLER_METRICS_QUERY_KEY] });
        queryClient.invalidateQueries({ queryKey: ['tasks'] });
        queryClient.invalidateQueries({ queryKey: ['actionCenter'] });
      }
    } catch (error: any) {
      console.error('Error saving task:', error);
      toast.error(error.message || 'Erro ao salvar tarefa');
    } finally {
      setSaving(false);
    }
  };

  // Completion handlers (edit mode only)
  const isNonSellerDepartment = department === 'financeiro_gestora' || department === 'logistica';
  const hasLogisticsChecklist = taskSteps.length > 0 && (department === 'logistica' || taskCategory === 'LOGISTICA');
  const checklistComplete = !hasLogisticsChecklist || taskSteps.every(s => s.done);

  // Direct completion for non-seller departments (no replication modal)
  const handleDirectCompletion = async () => {
    if (!task) return;
    if (hasLogisticsChecklist && !checklistComplete) {
      toast.error('Complete todos os passos do checklist antes de concluir');
      return;
    }
    setCompleting(true);
    try {
      const now = new Date();
      const { error } = await supabase
        .from('tasks')
        .update({
          status: 'concluida',
          completed_at: now.toISOString(),
          completion_notes: completionNotes,
          contact_successful: true,
          is_attempt: false,
        })
        .eq('id', task.id);

      if (error) throw error;
      toast.success('Tarefa concluída!');

      queryClient.invalidateQueries({ queryKey: [SELLER_METRICS_QUERY_KEY] });
      queryClient.invalidateQueries({ queryKey: ['tasks'] });
      queryClient.invalidateQueries({ queryKey: ['actionCenter'] });
      onOpenChange(false);
      onCompleted();
    } catch (error) {
      console.error('Error completing task:', error);
      toast.error('Erro ao concluir tarefa');
    } finally {
      setCompleting(false);
    }
  };

  const handleSuccessfulContactClick = (type: 'whatsapp' | 'ligacao') => {
    if (hasLogisticsChecklist && !checklistComplete) {
      toast.error('Complete todos os passos do checklist antes de concluir');
      return;
    }
    setPendingCompletionType(type);
    setShowReplicationModal(true);
  };

  const handleAttemptClick = () => {
    if (!attemptType) {
      toast.error('Selecione o tipo de tentativa');
      return;
    }
    setPendingCompletionType('attempt');
    setShowReplicationModal(true);
  };

  const executeCompletion = async () => {
    if (!pendingCompletionType || !task) return;

    setCompleting(true);
    try {
      const now = new Date();

      if (pendingCompletionType === 'attempt') {
        const contactTypeForAttempt = attemptType === 'whatsapp_sem_resposta' ? 'whatsapp' : 'ligacao';

        const { error } = await supabase
          .from('tasks')
          .update({
            status: 'concluida',
            completed_at: now.toISOString(),
            completion_notes: completionNotes,
            contact_successful: false,
            is_attempt: true,
            contact_type: contactTypeForAttempt,
          })
          .eq('id', task.id);

        if (error) throw error;
        toast.success('Tentativa registrada!');
      } else {
        const { error } = await supabase
          .from('tasks')
          .update({
            status: 'concluida',
            completed_at: now.toISOString(),
            completion_notes: completionNotes,
            contact_successful: true,
            is_attempt: false,
            contact_type: pendingCompletionType,
          })
          .eq('id', task.id);

        if (error) throw error;

        // Only update client last_contact_at for seller departments
        if (!isNonSellerDepartment && task.clientId) {
          await supabase
            .from('clients')
            .update({ last_contact_at: now.toISOString() })
            .eq('id', task.clientId);
        }

        const label = pendingCompletionType === 'whatsapp' ? 'WhatsApp' : 'Ligação';
        toast.success(`Contato via ${label} registrado!`);
      }

      queryClient.invalidateQueries({ queryKey: [SELLER_METRICS_QUERY_KEY] });
      queryClient.invalidateQueries({ queryKey: ['tasks'] });
      queryClient.invalidateQueries({ queryKey: ['actionCenter'] });
      onOpenChange(false);
      onCompleted();
    } catch (error) {
      console.error('Error completing task:', error);
      toast.error('Erro ao registrar contato');
    } finally {
      setCompleting(false);
      setPendingCompletionType(null);
    }
  };

  const handleReplicationComplete = () => {
    executeCompletion();
  };

  const addPlanningProduct = () => {
    setPlanningProducts([...planningProducts, { name: '', price: '', deadline: '' }]);
  };

  const removePlanningProduct = (index: number) => {
    setPlanningProducts(planningProducts.filter((_, i) => i !== index));
  };

  const updatePlanningProduct = (index: number, field: string, value: string) => {
    const updated = [...planningProducts];
    updated[index] = { ...updated[index], [field]: value };
    setPlanningProducts(updated);
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);
  };

  const reasonConfig = CONTACT_REASON_OPTIONS.find(r => r.value === contactReason) || CONTACT_REASON_OPTIONS[0];

  const modalTitle = mode === 'create' 
    ? 'Nova Tarefa' 
    : effectiveClientName || 'Tarefa';

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent 
        side="right" 
        className="w-full sm:max-w-[900px] p-0 flex flex-col overflow-hidden"
      >
        {/* Header */}
        <SheetHeader className="px-6 py-4 border-b shrink-0 bg-gradient-to-r from-primary/5 to-transparent">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={cn(
                'w-10 h-10 rounded-lg flex items-center justify-center',
                department === 'financeiro_gestora' ? 'bg-emerald-500/10' : contactType === 'whatsapp' ? 'bg-emerald-500/10' : 'bg-blue-500/10'
              )}>
                {department === 'financeiro_gestora' ? (
                  <DollarSign className="h-5 w-5 text-emerald-600" />
                ) : contactType === 'whatsapp' ? (
                  <MessageCircle className="h-5 w-5 text-emerald-600" />
                ) : (
                  <Phone className="h-5 w-5 text-blue-600" />
                )}
              </div>
              <div>
                <SheetTitle className="text-lg font-semibold">
                  {modalTitle}
                </SheetTitle>
                <div className="flex items-center gap-2 mt-0.5">
                  <Badge variant="outline" className={cn('text-xs', reasonConfig.color)}>
                    {reasonConfig.label}
                  </Badge>
                  {isOverdue && (
                    <Badge variant="destructive" className="text-xs">
                      <AlertTriangle className="h-3 w-3 mr-1" />
                      Atrasada
                    </Badge>
                  )}
                  {isCompleted && (
                    <Badge variant="secondary" className="text-xs bg-emerald-500/10 text-emerald-600">
                      <CheckCircle className="h-3 w-3 mr-1" />
                      Concluída
                    </Badge>
                  )}
                </div>
              </div>
            </div>
            {!isCompleted && (
              <Button
                size="sm"
                onClick={handleSaveTask}
                disabled={saving}
                className="gap-2"
              >
                {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                {mode === 'create' ? 'Criar Tarefa' : 'Salvar'}
              </Button>
            )}
          </div>
        </SheetHeader>

        {/* Content */}
        <ScrollArea className="flex-1">
          <div className="p-6 space-y-6">
            
            {/* ============= CLIENT SELECTOR (Create mode only) ============= */}
            {mode === 'create' && !propClientId && (
              <>
                <div className="space-y-4">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                      <Building2 className="h-4 w-4 text-primary" />
                    </div>
                    <h3 className="font-semibold text-base">Cliente *</h3>
                  </div>
                  
                  <div className="pl-10">
                    <Popover open={clientPopoverOpen} onOpenChange={setClientPopoverOpen}>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          role="combobox"
                          aria-expanded={clientPopoverOpen}
                          className="w-full justify-between h-11"
                        >
                          {selectedClientName || 'Selecione um cliente...'}
                          <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-[400px] p-0" align="start">
                        <Command shouldFilter={false}>
                          <div className="border-b p-2">
                            <Input
                              placeholder="Buscar cliente..."
                              value={clientSearch}
                              onChange={(e) => setClientSearch(e.target.value)}
                            />
                          </div>
                          <CommandList>
                            {loadingClients ? (
                              <div className="p-4 text-center text-sm text-muted-foreground">
                                <Loader2 className="h-4 w-4 animate-spin mx-auto mb-2" />
                                Carregando...
                              </div>
                            ) : clientSearch.trim().length > 0 && clientSearch.trim().length < 2 ? (
                              <div className="p-4 text-center text-sm text-muted-foreground">
                                Digite pelo menos 2 letras para buscar.
                              </div>
                            ) : clients.length === 0 ? (
                              <CommandEmpty>
                                {clientSearch.trim().length === 0 ? 'Nenhum cliente recente.' : 'Nenhum cliente encontrado.'}
                              </CommandEmpty>
                            ) : (
                              <CommandGroup
                                heading={clientSearch.trim().length === 0 ? 'Recentes' : 'Resultados'}
                                className="max-h-60 overflow-y-auto"
                              >
                                {clients.map((client) => (
                                  <CommandItem
                                    key={client.id}
                                    value={client.company_name}
                                    onSelect={() => handleClientSelect(client.id, client.company_name)}
                                    className="cursor-pointer"
                                  >
                                    <Check
                                      className={cn(
                                        'mr-2 h-4 w-4',
                                        selectedClientId === client.id ? 'opacity-100' : 'opacity-0'
                                      )}
                                    />
                                    {client.company_name}
                                  </CommandItem>
                                ))}
                              </CommandGroup>
                            )}
                          </CommandList>
                        </Command>
                      </PopoverContent>
                    </Popover>
                  </div>
                </div>
                <Separator />
              </>
            )}

            {/* ============= ORIGEM (COMPRAS/COTAÇÃO) ============= */}
            {isEditMode && task?.relatedType && task?.relatedId && (
              <>
                <OriginBlock
                  sourceModule={task.sourceModule || ''}
                  relatedType={task.relatedType}
                  relatedId={task.relatedId}
                />
                <Separator />
              </>
            )}

            {/* ============= SEÇÃO 1: PLANEJAMENTO DO CONTATO (hidden for financeiro_gestora) ============= */}
            {department !== 'financeiro_gestora' && (
              <>
                <div className="space-y-4">
                  <button
                    onClick={() => setShowPlanningExpanded(!showPlanningExpanded)}
                    className="flex items-center justify-between w-full text-left"
                  >
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-lg bg-violet-500/10 flex items-center justify-center">
                        <Target className="h-4 w-4 text-violet-600" />
                      </div>
                      <h3 className="font-semibold text-base">Planejamento do Contato</h3>
                    </div>
                    {showPlanningExpanded ? (
                      <ChevronUp className="h-4 w-4 text-muted-foreground" />
                    ) : (
                      <ChevronDown className="h-4 w-4 text-muted-foreground" />
                    )}
                  </button>

                  {showPlanningExpanded && (
                    <div className="pl-10 space-y-4">
                      {/* Products to offer */}
                      <div className="space-y-2">
                        <Label className="text-sm font-medium">Produtos para oferecer</Label>
                        {planningProducts.length === 0 ? (
                          <p className="text-sm text-muted-foreground">Nenhum produto adicionado</p>
                        ) : (
                          <div className="space-y-2">
                            {planningProducts.map((product, index) => (
                              <div key={index} className="flex items-center gap-2 p-2 bg-muted/30 rounded-lg">
                                <ProductSearchCombobox
                                  value={product.name}
                                  productId={product.product_id}
                                  isManual={product.isManual}
                                  onChange={(name, productId, isManual) => {
                                    const updated = [...planningProducts];
                                    updated[index] = { ...updated[index], name, product_id: productId, isManual };
                                    setPlanningProducts(updated);
                                  }}
                                  placeholder="Buscar produto..."
                                />
                                <Input
                                  value={product.price}
                                  onChange={(e) => updatePlanningProduct(index, 'price', e.target.value)}
                                  placeholder="Preço"
                                  className="w-24"
                                  disabled={isCompleted}
                                />
                                <Input
                                  value={product.deadline}
                                  onChange={(e) => updatePlanningProduct(index, 'deadline', e.target.value)}
                                  placeholder="Prazo"
                                  className="w-24"
                                  disabled={isCompleted}
                                />
                                <Button
                                  type="button"
                                  variant="ghost"
                                  size="icon"
                                  onClick={() => removePlanningProduct(index)}
                                  disabled={isCompleted}
                                  className="shrink-0 h-8 w-8"
                                >
                                  <X className="h-4 w-4" />
                                </Button>
                              </div>
                            ))}
                          </div>
                        )}
                        {!isCompleted && (
                          <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            onClick={addPlanningProduct}
                            className="gap-1"
                          >
                            <Plus className="h-3 w-3" />
                            Adicionar Produto
                          </Button>
                        )}
                      </div>

                      {/* Planning notes */}
                      <div className="space-y-2">
                        <Label className="text-sm font-medium">Notas estratégicas</Label>
                        <Textarea
                          value={planningNotes}
                          onChange={(e) => setPlanningNotes(e.target.value)}
                          placeholder="Estratégia de abordagem, argumentos, condições especiais..."
                          rows={3}
                          disabled={isCompleted}
                          className="resize-none"
                        />
                      </div>

                      {/* Product History from Client */}
                      {productHistory.length > 0 && (
                        <div className="space-y-2">
                          <Label className="text-sm font-medium flex items-center gap-1">
                            <History className="h-3 w-3" />
                            Últimos produtos comprados
                          </Label>
                          <div className="flex flex-wrap gap-1">
                            {productHistory.map((product, idx) => (
                              <Badge
                                key={idx}
                                variant="outline"
                                className="text-xs cursor-pointer hover:bg-primary/5"
                                onClick={() => {
                                  setPlanningProducts([...planningProducts, {
                                    name: product.product_name,
                                    price: formatCurrency(product.last_price),
                                    deadline: '',
                                  }]);
                                }}
                              >
                                + {product.product_name.substring(0, 25)}...
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}
                      
                      {/* Contact History - últimos 2 contatos */}
                      <ClientContactHistory clientId={effectiveClientId || null} />
                    </div>
                  )}
                </div>

                <Separator />
              </>
            )}

            {/* ============= SEÇÃO 2: DADOS DA TAREFA ============= */}
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-blue-500/10 flex items-center justify-center">
                  <FileText className="h-4 w-4 text-blue-600" />
                </div>
                <h3 className="font-semibold text-base">Dados da Tarefa</h3>
              </div>

              <div className="pl-10 grid grid-cols-2 gap-4">
                {/* Category & Bucket for financeiro_gestora - promoted to top */}
                {department === 'financeiro_gestora' && (
                  <>
                    <div className="space-y-2">
                      <Label className="text-sm">Categoria da Tarefa *</Label>
                      <Select value={taskCategory} onValueChange={setTaskCategory} disabled={isCompleted}>
                        <SelectTrigger>
                          <SelectValue placeholder="Selecione..." />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="FINANCEIRO">📌 Financeiro</SelectItem>
                          <SelectItem value="COMPRAS">📦 Compras</SelectItem>
                          <SelectItem value="ENTREGAS">🚚 Entregas</SelectItem>
                          <SelectItem value="ADMINISTRATIVO">📋 Administrativo</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label className="text-sm">Planejamento</Label>
                      <Select value={taskBucket} onValueChange={setTaskBucket} disabled={isCompleted}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="HOJE">Hoje</SelectItem>
                          <SelectItem value="AMANHA">Amanhã</SelectItem>
                          <SelectItem value="SEMANA">Esta Semana</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </>
                )}

                {/* Contact Reason - hidden for financeiro_gestora */}
                {department !== 'financeiro_gestora' && (
                  <div className="space-y-2">
                    <Label className="text-sm">Motivo do Contato *</Label>
                    <Select 
                      value={contactReason} 
                      onValueChange={(v) => setContactReason(v as ContactReason)}
                      disabled={isCompleted}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {CONTACT_REASON_OPTIONS.map((option) => (
                          <SelectItem key={option.value} value={option.value}>
                            {option.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}

                {/* Contact Type - hidden for financeiro_gestora */}
                {department !== 'financeiro_gestora' && (
                  <div className="space-y-2">
                    <Label className="text-sm">Tipo de Contato *</Label>
                    <div className="flex gap-2">
                      <Button
                        type="button"
                        variant={contactType === 'ligacao' ? 'default' : 'outline'}
                        size="sm"
                        onClick={() => !isCompleted && setContactType('ligacao')}
                        disabled={isCompleted}
                        className="flex-1 gap-2"
                      >
                        <Phone className="h-4 w-4" />
                        Ligação
                      </Button>
                      <Button
                        type="button"
                        variant={contactType === 'whatsapp' ? 'default' : 'outline'}
                        size="sm"
                        onClick={() => !isCompleted && setContactType('whatsapp')}
                        disabled={isCompleted}
                        className={cn("flex-1 gap-2", contactType === 'whatsapp' && "bg-emerald-600 hover:bg-emerald-700")}
                      >
                        <MessageCircle className="h-4 w-4" />
                        WhatsApp
                      </Button>
                    </div>
                  </div>
                )}

                {/* Date */}
                <div className="space-y-2">
                  <Label className="text-sm flex items-center gap-1">
                    <Calendar className="h-3 w-3" />
                    Data *
                  </Label>
                  <Input
                    type="date"
                    value={taskDate}
                    onChange={(e) => setTaskDate(e.target.value)}
                    disabled={isDateDisabled}
                    className={isDateDisabled ? 'opacity-60' : ''}
                  />
                </div>

                {/* Time */}
                <div className="space-y-2">
                  <Label className="text-sm flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    Hora
                  </Label>
                  <Input
                    type="time"
                    value={taskTime}
                    onChange={(e) => setTaskTime(e.target.value)}
                    disabled={isDateDisabled}
                    className={isDateDisabled ? 'opacity-60' : ''}
                  />
                </div>

                {/* Priority */}
                <div className="space-y-2">
                  <Label className="text-sm flex items-center gap-1">
                    <Flag className="h-3 w-3" />
                    Prioridade
                  </Label>
                  <div className="flex gap-1">
                    {priorityOptions.map((option) => (
                      <Button
                        key={option.value}
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => !isCompleted && setPriority(option.value as 'alta' | 'media' | 'baixa')}
                        disabled={isCompleted}
                        className={cn(
                          "flex-1 text-xs",
                          priority === option.value && option.color
                        )}
                      >
                        {option.label}
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Responsible */}
                <div className="space-y-2">
                  <Label className="text-sm flex items-center gap-1">
                    <User className="h-3 w-3" />
                    Responsável *
                  </Label>
                  <div className="flex gap-2">
                    <Select 
                      value={responsibleSellerId} 
                      onValueChange={setResponsibleSellerId}
                      disabled={isCompleted}
                    >
                      <SelectTrigger className="flex-1">
                        <SelectValue placeholder="Selecione" />
                      </SelectTrigger>
                      <SelectContent>
                        {sellers.map((s) => (
                          <SelectItem key={s.id} value={s.id}>
                            {s.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {responsibleSellerId && (
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        className="shrink-0 text-xs gap-1"
                        onClick={() => navigate(`/perfil-vendedor/${responsibleSellerId}`)}
                      >
                        <User className="h-3 w-3" />
                        Perfil
                      </Button>
                    )}
                  </div>
                </div>

                {/* Delegar para */}
                <div className="space-y-2">
                  <Label className="text-sm flex items-center gap-1">
                    <User className="h-3 w-3" />
                    Delegar para (opcional)
                  </Label>
                  <Select 
                    value={assignedToSellerId || 'none'} 
                    onValueChange={(v) => setAssignedToSellerId(v === 'none' ? '' : v)}
                    disabled={isCompleted}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Nenhum" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">Nenhum</SelectItem>
                      {sellers.filter(s => s.id !== responsibleSellerId).map((s) => (
                        <SelectItem key={s.id} value={s.id}>
                          {s.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Notes - full width */}
                <div className="col-span-2 space-y-2">
                  <Label className="text-sm">Observações da tarefa</Label>
                  <Textarea
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="Detalhes sobre esta tarefa..."
                    rows={2}
                    disabled={isCompleted}
                    className="resize-none"
                  />
                </div>
              </div>
            </div>

            {/* Seção Gestão Financeira movida para dentro de Dados da Tarefa */}

            {department === 'logistica' && !isCompleted && (
              <>
                <Separator />
                <div className="space-y-4">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-blue-500/10 flex items-center justify-center">
                      <Package className="h-4 w-4 text-blue-600" />
                    </div>
                    <h3 className="font-semibold text-base">Checklist Logística</h3>
                  </div>
                  <div className="pl-10 space-y-2">
                    {taskSteps.map((step, idx) => (
                      <div key={idx} className="flex items-center gap-3 py-1">
                        <Checkbox
                          checked={step.done}
                          onCheckedChange={(checked) => {
                            const updated = [...taskSteps];
                            updated[idx] = {
                              ...updated[idx],
                              done: !!checked,
                              done_at: checked ? new Date().toISOString() : null,
                            };
                            setTaskSteps(updated);
                          }}
                        />
                        <span className={`text-sm ${step.done ? 'line-through text-muted-foreground' : ''}`}>
                          {step.label}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </>
            )}

            <Separator />

            {/* ============= SEÇÃO ORÇAMENTO EM ABERTO (hidden for financeiro_gestora) ============= */}
            {!isCompleted && department !== 'financeiro_gestora' && (
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-amber-500/10 flex items-center justify-center">
                    <FileText className="h-4 w-4 text-amber-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-base">Orçamento em Aberto</h3>
                    <p className="text-xs text-muted-foreground">Marque se enviou orçamento para acompanhamento</p>
                  </div>
                </div>

                <div className="pl-10 space-y-3">
                  {/* Checkbox principal */}
                  <div className="flex items-center space-x-3">
                    <input
                      type="checkbox"
                      id="tem-orcamento-create"
                      checked={temOrcamentoAberto}
                      onChange={(e) => setTemOrcamentoAberto(e.target.checked)}
                      className="w-4 h-4 rounded border-amber-500 text-amber-600 focus:ring-amber-500"
                    />
                    <Label htmlFor="tem-orcamento-create" className="text-sm cursor-pointer">
                      Este cliente tem um orçamento em aberto
                    </Label>
                  </div>

                  {/* Campos condicionais */}
                  {temOrcamentoAberto && (
                    <div className="grid grid-cols-2 gap-3 p-3 rounded-lg border border-amber-500/20 bg-amber-50/50 dark:bg-amber-950/20">
                      <div className="space-y-1.5">
                        <Label className="text-xs text-muted-foreground">Código do Orçamento (CA)</Label>
                        <Input
                          value={orcamentoCaCodigo}
                          onChange={(e) => setOrcamentoCaCodigo(e.target.value)}
                          placeholder="Ex: 12345"
                          className="h-8 text-sm"
                        />
                      </div>
                      <div className="space-y-1.5">
                        <Label className="text-xs text-muted-foreground">Valor do Orçamento</Label>
                        <Input
                          type="number"
                          value={orcamentoValor}
                          onChange={(e) => setOrcamentoValor(e.target.value)}
                          placeholder="R$ 0,00"
                          className="h-8 text-sm"
                        />
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            <Separator />

            {/* ============= SEÇÃO 3: DADOS DO CLIENTE ============= */}
            {effectiveClientId && (
              <div className="space-y-4">
                <button
                  onClick={() => setShowHistory(!showHistory)}
                  className="flex items-center justify-between w-full text-left"
                >
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-amber-500/10 flex items-center justify-center">
                      <Building2 className="h-4 w-4 text-amber-600" />
                    </div>
                    <h3 className="font-semibold text-base">Dados do Cliente</h3>
                  </div>
                  {showHistory ? (
                    <ChevronUp className="h-4 w-4 text-muted-foreground" />
                  ) : (
                    <ChevronDown className="h-4 w-4 text-muted-foreground" />
                  )}
                </button>

                {loadingClient ? (
                  <div className="pl-10 flex items-center gap-2 text-sm text-muted-foreground">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Carregando...
                  </div>
                ) : clientData && (
                  <div className="pl-10 space-y-4">
                    {/* Client KPIs */}
                    <ClientKPIs 
                      clientData={clientData} 
                      recentOrders={recentOrders} 
                      formatCurrency={formatCurrency}
                      onOrdersClick={() => setShowOrdersModal(true)}
                    />

                    {/* Contact info */}
                    <div className="flex flex-wrap gap-4 text-sm">
                      {clientData.phone && (
                        <span className="flex items-center gap-1 text-muted-foreground">
                          <Phone className="h-3 w-3" />
                          {clientData.phone}
                        </span>
                      )}
                      {clientData.email && (
                        <span className="flex items-center gap-1 text-muted-foreground">
                          @{clientData.email}
                        </span>
                      )}
                      {clientData.cnpj && (
                        <span className="text-muted-foreground">CNPJ: {clientData.cnpj}</span>
                      )}
                    </div>

                    {/* Recent orders - collapsed by default */}
                    {showHistory && recentOrders.length > 0 && (
                      <div className="space-y-2">
                        <Label className="text-sm font-medium">Últimos pedidos</Label>
                        <div className="space-y-1">
                          {recentOrders.map((order) => (
                            <div
                              key={order.id}
                              className="flex items-center justify-between p-2 bg-muted/20 rounded text-sm"
                            >
                              <span className="font-medium">{order.order_number}</span>
                              <span className="text-muted-foreground">
                                {format(parseISO(order.order_date), 'dd/MM/yyyy', { locale: ptBR })}
                              </span>
                              <span className="font-medium">{formatCurrency(order.total)}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {clientData.observations && showHistory && (
                      <div className="p-3 bg-muted/20 rounded-lg">
                        <Label className="text-xs text-muted-foreground">Observações do cliente</Label>
                        <p className="text-sm mt-1">{clientData.observations}</p>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}

            {/* ============= SEÇÃO 3.5: CHECKLIST LOGÍSTICA ============= */}
            {isEditMode && !isCompleted && taskSteps.length > 0 && (department === 'logistica' || taskCategory === 'LOGISTICA') && (
              <>
                <Separator />
                <div className="space-y-4">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-blue-500/10 flex items-center justify-center">
                      <ClipboardCheck className="h-4 w-4 text-blue-600" />
                    </div>
                    <h3 className="font-semibold text-base">Checklist Obrigatório</h3>
                    <Badge variant="secondary" className="ml-auto text-xs">
                      {taskSteps.filter(s => s.done).length}/{taskSteps.length}
                    </Badge>
                  </div>
                  <div className="pl-10 space-y-2">
                    {taskSteps.map((step, idx) => (
                      <div key={idx} className="flex items-center gap-3 py-1.5">
                        <Checkbox
                          checked={step.done}
                          onCheckedChange={() => {
                            const updated = [...taskSteps];
                            updated[idx] = {
                              ...updated[idx],
                              done: !updated[idx].done,
                              done_at: !updated[idx].done ? new Date().toISOString() : null,
                            };
                            setTaskSteps(updated);
                            if (task) {
                              supabase.from('tasks').update({ task_steps: updated as any }).eq('id', task.id);
                            }
                          }}
                        />
                        <span className={cn('text-sm', step.done && 'line-through text-muted-foreground')}>
                          {step.label}
                        </span>
                        {step.done && step.done_at && (
                          <span className="text-[10px] text-muted-foreground ml-auto">
                            {format(parseISO(step.done_at), 'HH:mm')}
                          </span>
                        )}
                      </div>
                    ))}
                    {taskSteps.some(s => !s.done) && (
                      <p className="text-xs text-amber-600 flex items-center gap-1 mt-2">
                        <AlertTriangle className="h-3 w-3" />
                        Complete todos os passos para poder concluir
                      </p>
                    )}
                  </div>
                </div>
              </>
            )}

            {/* ============= SEÇÃO 4: REGISTRO DO CONTATO / CONCLUSÃO (Edit mode only) ============= */}
            {isEditMode && !isCompleted && (
              <>
                <Separator />
                {isNonSellerDepartment ? (
                  /* Simplified direct completion for financeiro_gestora and logistica */
                  <div className="space-y-4">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-lg bg-emerald-500/10 flex items-center justify-center">
                        <CheckCircle className="h-4 w-4 text-emerald-600" />
                      </div>
                      <h3 className="font-semibold text-base">Concluir Tarefa</h3>
                    </div>

                    <div className="pl-10 space-y-4">
                      <div className="space-y-2">
                        <Label className="text-sm">Observação de conclusão</Label>
                        <Textarea
                          value={completionNotes}
                          onChange={(e) => setCompletionNotes(e.target.value)}
                          placeholder="Descreva o resultado da atividade..."
                          rows={2}
                          className="resize-none"
                        />
                      </div>

                      <Button
                        className="w-full gap-2"
                        onClick={handleDirectCompletion}
                        disabled={completing || (hasLogisticsChecklist && !checklistComplete)}
                      >
                        {completing ? <Loader2 className="h-4 w-4 animate-spin" /> : <CheckCircle className="h-4 w-4" />}
                        Concluir Tarefa
                      </Button>
                    </div>
                  </div>
                ) : (
                  /* Standard seller completion flow */
                  <div className="space-y-4">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-lg bg-emerald-500/10 flex items-center justify-center">
                        <CheckCircle className="h-4 w-4 text-emerald-600" />
                      </div>
                      <h3 className="font-semibold text-base">Registrar Contato</h3>
                    </div>

                    <div className="pl-10 space-y-4">
                      {/* Completion notes */}
                      <div className="space-y-2">
                        <Label className="text-sm">Observação do contato</Label>
                        <Textarea
                          value={completionNotes}
                          onChange={(e) => setCompletionNotes(e.target.value)}
                          placeholder="Descreva o resultado do contato..."
                          rows={2}
                          className="resize-none"
                        />
                      </div>

                      {/* Successful contact buttons */}
                      <div className="space-y-2">
                        <Label className="text-sm text-muted-foreground">Conseguiu falar com o cliente?</Label>
                        <div className="grid grid-cols-2 gap-3">
                          <Button
                            variant="outline"
                            className="h-auto py-3 flex flex-col gap-1 border-emerald-500/30 hover:bg-emerald-500/10 hover:border-emerald-500/50 disabled:opacity-50"
                            onClick={() => handleSuccessfulContactClick('whatsapp')}
                            disabled={completing}
                          >
                            <MessageCircle className="h-5 w-5 text-emerald-500" />
                            <span className="font-medium text-sm">WhatsApp</span>
                          </Button>
                          <Button
                            variant="outline"
                            className="h-auto py-3 flex flex-col gap-1 border-blue-500/30 hover:bg-blue-500/10 hover:border-blue-500/50 disabled:opacity-50"
                            onClick={() => handleSuccessfulContactClick('ligacao')}
                            disabled={completing}
                          >
                            <Phone className="h-5 w-5 text-blue-500" />
                            <span className="font-medium text-sm">Ligação</span>
                          </Button>
                        </div>
                      </div>

                      {/* Divider */}
                      <div className="relative">
                        <div className="absolute inset-0 flex items-center">
                          <span className="w-full border-t" />
                        </div>
                        <div className="relative flex justify-center text-xs uppercase">
                          <span className="bg-background px-2 text-muted-foreground">
                            ou não conseguiu contato
                          </span>
                        </div>
                      </div>

                      {/* Attempt selection */}
                      <div className="space-y-2">
                        <RadioGroup value={attemptType} onValueChange={setAttemptType} className="space-y-2">
                          {ATTEMPT_TYPES.map((type) => (
                            <div
                              key={type.value}
                              className={cn(
                                'flex items-center space-x-3 p-3 rounded-lg border cursor-pointer transition-colors',
                                attemptType === type.value
                                  ? 'border-amber-500 bg-amber-500/5'
                                  : 'border-border hover:bg-muted/50'
                              )}
                              onClick={() => setAttemptType(type.value)}
                            >
                              <RadioGroupItem value={type.value} id={type.value} />
                              <type.icon className={cn(
                                'h-4 w-4',
                                attemptType === type.value ? 'text-amber-500' : 'text-muted-foreground'
                              )} />
                              <Label htmlFor={type.value} className="flex-1 cursor-pointer text-sm">
                                {type.label}
                              </Label>
                            </div>
                          ))}
                        </RadioGroup>

                        {attemptType && (
                          <Button
                            onClick={handleAttemptClick}
                            disabled={completing}
                            variant="secondary"
                            className="w-full bg-amber-500/10 hover:bg-amber-500/20 text-amber-600 border border-amber-500/20"
                          >
                            {completing && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                            Salvar Tentativa
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                )}
              </>
            )}
          </div>
        </ScrollArea>

        {/* Task Replication Modal */}
        {isEditMode && task && (
          <TaskReplicationModal
            open={showReplicationModal}
            onOpenChange={setShowReplicationModal}
            task={task}
            planningProducts={planningProducts}
            planningNotes={planningNotes}
            onCompleted={handleReplicationComplete}
          />
        )}
      </SheetContent>
      
      {/* Orders Modal */}
      <ClientOrdersModal
        open={showOrdersModal}
        onOpenChange={setShowOrdersModal}
        clientName={effectiveClientName || ''}
        clientId={effectiveClientId || null}
      />

    </Sheet>
  );
}
