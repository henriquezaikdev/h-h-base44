import { useState, useEffect, useCallback } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { 
  Phone, 
  MessageCircle, 
  CheckCircle, 
  PhoneOff, 
  MessageSquareOff,
  Calendar,
  Clock,
  Flag,
  Target,
  Building2,
  Package,
  DollarSign,
  History,
  ShoppingCart,
  FileText,
  Loader2,
  Save,
  AlertTriangle,
  User,
  ChevronDown,
  ChevronUp,
  Plus,
  X,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { TaskData, ContactReason, CONTACT_REASON_OPTIONS } from '@/hooks/useTasksData';
import { useTaskDatePermission } from '@/hooks/useTaskDatePermission';
import { useAuth } from '@/hooks/useAuth';
import { SELLER_METRICS_QUERY_KEY } from '@/hooks/useSellerMetrics';
import { format, parseISO, isToday, isPast } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { TaskReplicationModal } from './TaskReplicationModal';

interface Seller {
  id: string;
  name: string;
}

interface ClientData {
  id: string;
  company_name: string;
  cnpj: string | null;
  phone: string | null;
  email: string | null;
  ranking_tier: string | null;
  total_revenue: number | null;
  days_since_last_order: number | null;
  last_contact_at: string | null;
  observations: string | null;
  seller_id: string | null;
}

interface OrderData {
  id: string;
  order_number: string;
  order_date: string;
  total: number;
}

interface ProductHistoryItem {
  product_name: string;
  total_qty: number;
  last_price: number;
  last_order_date: string;
}

interface TaskExecutionModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  task: TaskData;
  sellers: Seller[];
  onCompleted: () => void;
}

const priorityOptions = [
  { value: 'alta', label: 'Alta', color: 'text-red-600 border-red-500 bg-red-500/10' },
  { value: 'media', label: 'Média', color: 'text-amber-600 border-amber-500 bg-amber-500/10' },
  { value: 'baixa', label: 'Baixa', color: 'text-emerald-600 border-emerald-500 bg-emerald-500/10' },
];

const ATTEMPT_TYPES = [
  { value: 'whatsapp_sem_resposta', label: 'WhatsApp — sem resposta', icon: MessageSquareOff },
  { value: 'ligacao_sem_resposta', label: 'Ligação — sem resposta', icon: PhoneOff },
];

export function TaskExecutionModal({
  open,
  onOpenChange,
  task,
  sellers,
  onCompleted,
}: TaskExecutionModalProps) {
  const queryClient = useQueryClient();
  const { seller } = useAuth();
  const { canEditDate } = useTaskDatePermission();
  
  // Task editing state
  const [contactType, setContactType] = useState<'ligacao' | 'whatsapp'>('ligacao');
  const [contactReason, setContactReason] = useState<ContactReason>('RETORNO');
  const [taskDate, setTaskDate] = useState('');
  const [taskTime, setTaskTime] = useState('');
  const [notes, setNotes] = useState('');
  const [priority, setPriority] = useState<'alta' | 'media' | 'baixa'>('media');
  const [responsibleSellerId, setResponsibleSellerId] = useState<string>('');
  const [saving, setSaving] = useState(false);
  
  // Planning section state
  const [planningNotes, setPlanningNotes] = useState('');
  const [planningProducts, setPlanningProducts] = useState<{ name: string; price: string; deadline: string }[]>([]);
  const [showPlanningExpanded, setShowPlanningExpanded] = useState(true);
  
  // Completion section state
  const [completionNotes, setCompletionNotes] = useState('');
  const [attemptType, setAttemptType] = useState<string>('');
  const [completing, setCompleting] = useState(false);
  
  // Replication modal state
  const [showReplicationModal, setShowReplicationModal] = useState(false);
  const [pendingCompletionType, setPendingCompletionType] = useState<'whatsapp' | 'ligacao' | 'attempt' | null>(null);
  
  // Client data state
  const [clientData, setClientData] = useState<ClientData | null>(null);
  const [recentOrders, setRecentOrders] = useState<OrderData[]>([]);
  const [productHistory, setProductHistory] = useState<ProductHistoryItem[]>([]);
  const [loadingClient, setLoadingClient] = useState(false);
  const [showHistory, setShowHistory] = useState(false);

  // Fetch client data - useCallback before useEffect
  const fetchClientData = useCallback(async (clientId: string) => {
    setLoadingClient(true);
    try {
      // Fetch client basic info
      const { data: client } = await supabase
        .from('clients')
        .select('id, company_name, cnpj, phone, email, ranking_tier, total_revenue, days_since_last_order, last_contact_at, observations, seller_id')
        .eq('id', clientId)
        .maybeSingle();
      
      if (client) {
        setClientData(client as ClientData);
      }
      
      // Fetch recent orders (last 5)
      const { data: orders } = await supabase
        .from('orders')
        .select('id, order_number, order_date, total')
        .eq('client_id', clientId)
        .order('order_date', { ascending: false })
        .limit(5);
      
      if (orders) {
        setRecentOrders(orders as OrderData[]);
      }
      
      // Fetch top products purchased
      const { data: products } = await supabase
        .from('order_items')
        .select('product_name, quantity, unit_price, orders!inner(client_id, order_date)')
        .eq('orders.client_id', clientId)
        .order('orders.order_date', { ascending: false })
        .limit(50);
      
      if (products && products.length > 0) {
        // Aggregate by product
        const productMap = new Map<string, ProductHistoryItem>();
        products.forEach((item: any) => {
          const existing = productMap.get(item.product_name);
          if (existing) {
            existing.total_qty += item.quantity || 0;
          } else {
            productMap.set(item.product_name, {
              product_name: item.product_name,
              total_qty: item.quantity || 0,
              last_price: item.unit_price || 0,
              last_order_date: item.orders?.order_date || '',
            });
          }
        });
        setProductHistory(Array.from(productMap.values()).slice(0, 10));
      }
    } catch (error) {
      console.error('Error fetching client data:', error);
    } finally {
      setLoadingClient(false);
    }
  }, []);

  // Load task data - hook MUST be before any early returns
  useEffect(() => {
    if (open && task) {
      setContactType(task.contactType);
      setContactReason(task.contactReason || 'RETORNO');
      setTaskDate(task.taskDate);
      setTaskTime(task.taskTime || '');
      setNotes(task.notes || '');
      setPriority(task.priority || 'media');
      setResponsibleSellerId(task.createdBySellerId || '');
      
      // Reset completion state
      setCompletionNotes('');
      setAttemptType('');
      
      // Fetch client data
      fetchClientData(task.clientId);
    }
  }, [open, task, fetchClientData]);
  
  // Early return if task is null - MUST be after all hooks
  if (!task) {
    return null;
  }
  
  const isCompleted = task.status === 'concluida';
  const isOverdue = !isCompleted && isPast(parseISO(task.taskDate)) && !isToday(parseISO(task.taskDate));
  const isDateDisabled = isCompleted || !canEditDate;

  const handleSaveTask = async () => {
    if (!taskDate) {
      toast.error('Selecione uma data.');
      return;
    }

    if (!responsibleSellerId) {
      toast.error('Selecione um responsável.');
      return;
    }

    setSaving(true);
    try {
      const updateData: Record<string, any> = {
        contact_type: contactType,
        contact_reason: contactReason,
        notes: notes.trim() || null,
        created_by_seller_id: responsibleSellerId,
        priority,
      };

      if (!isCompleted && canEditDate) {
        updateData.task_date = taskDate;
        updateData.task_time = taskTime || null;
      }

      const { error } = await supabase
        .from('tasks')
        .update(updateData)
        .eq('id', task.id);

      if (error) throw error;

      toast.success('Tarefa atualizada!');
      queryClient.invalidateQueries({ queryKey: [SELLER_METRICS_QUERY_KEY] });
      queryClient.invalidateQueries({ queryKey: ['tasks'] });
      queryClient.invalidateQueries({ queryKey: ['actionCenter'] });
    } catch (error: any) {
      console.error('Error updating task:', error);
      toast.error(error.message || 'Erro ao atualizar tarefa');
    } finally {
      setSaving(false);
    }
  };

  // Trigger completion flow - shows replication modal first
  const handleSuccessfulContactClick = (type: 'whatsapp' | 'ligacao') => {
    setPendingCompletionType(type);
    setShowReplicationModal(true);
  };

  const handleAttemptClick = () => {
    if (!attemptType) {
      toast.error('Selecione o tipo de tentativa');
      return;
    }
    setPendingCompletionType('attempt');
    setShowReplicationModal(true);
  };

  // Actually complete the task (called after replication decision)
  const executeCompletion = async () => {
    if (!pendingCompletionType) return;

    setCompleting(true);
    try {
      const now = new Date();

      if (pendingCompletionType === 'attempt') {
        // Handle attempt completion
        const contactTypeForAttempt = attemptType === 'whatsapp_sem_resposta' ? 'whatsapp' : 'ligacao';

        const { error } = await supabase
          .from('tasks')
          .update({
            status: 'concluida',
            completed_at: now.toISOString(),
            completion_notes: completionNotes,
            contact_successful: false,
            is_attempt: true,
            contact_type: contactTypeForAttempt,
          })
          .eq('id', task.id);

        if (error) throw error;
        toast.success('Tentativa registrada!');
      } else {
        // Handle successful contact (whatsapp or ligacao)
        const { error } = await supabase
          .from('tasks')
          .update({
            status: 'concluida',
            completed_at: now.toISOString(),
            completion_notes: completionNotes,
            contact_successful: true,
            is_attempt: false,
            contact_type: pendingCompletionType,
          })
          .eq('id', task.id);

        if (error) throw error;

        // Update client last_contact_at for successful contacts
        await supabase
          .from('clients')
          .update({ last_contact_at: now.toISOString() })
          .eq('id', task.clientId);

        const label = pendingCompletionType === 'whatsapp' ? 'WhatsApp' : 'Ligação';
        toast.success(`Contato via ${label} registrado!`);
      }

      queryClient.invalidateQueries({ queryKey: [SELLER_METRICS_QUERY_KEY] });
      queryClient.invalidateQueries({ queryKey: ['tasks'] });
      queryClient.invalidateQueries({ queryKey: ['actionCenter'] });
      onOpenChange(false);
      onCompleted();
    } catch (error) {
      console.error('Error completing task:', error);
      toast.error('Erro ao registrar contato');
    } finally {
      setCompleting(false);
      setPendingCompletionType(null);
    }
  };

  // Handle replication modal close - execute completion
  const handleReplicationComplete = () => {
    executeCompletion();
  };

  const addPlanningProduct = () => {
    setPlanningProducts([...planningProducts, { name: '', price: '', deadline: '' }]);
  };

  const removePlanningProduct = (index: number) => {
    setPlanningProducts(planningProducts.filter((_, i) => i !== index));
  };

  const updatePlanningProduct = (index: number, field: string, value: string) => {
    const updated = [...planningProducts];
    updated[index] = { ...updated[index], [field]: value };
    setPlanningProducts(updated);
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);
  };

  const reasonConfig = CONTACT_REASON_OPTIONS.find(r => r.value === contactReason) || CONTACT_REASON_OPTIONS[0];

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent 
        side="right" 
        className="w-full sm:max-w-[900px] p-0 flex flex-col overflow-hidden"
      >
        {/* Header */}
        <SheetHeader className="px-6 py-4 border-b shrink-0 bg-gradient-to-r from-primary/5 to-transparent">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={cn(
                'w-10 h-10 rounded-lg flex items-center justify-center',
                contactType === 'whatsapp' ? 'bg-emerald-500/10' : 'bg-blue-500/10'
              )}>
                {contactType === 'whatsapp' ? (
                  <MessageCircle className="h-5 w-5 text-emerald-600" />
                ) : (
                  <Phone className="h-5 w-5 text-blue-600" />
                )}
              </div>
              <div>
                <SheetTitle className="text-lg font-semibold">
                  {task.clientName}
                </SheetTitle>
                <div className="flex items-center gap-2 mt-0.5">
                  <Badge variant="outline" className={cn('text-xs', reasonConfig.color)}>
                    {reasonConfig.label}
                  </Badge>
                  {isOverdue && (
                    <Badge variant="destructive" className="text-xs">
                      <AlertTriangle className="h-3 w-3 mr-1" />
                      Atrasada
                    </Badge>
                  )}
                  {isCompleted && (
                    <Badge variant="secondary" className="text-xs bg-emerald-500/10 text-emerald-600">
                      <CheckCircle className="h-3 w-3 mr-1" />
                      Concluída
                    </Badge>
                  )}
                </div>
              </div>
            </div>
            {!isCompleted && (
              <Button
                size="sm"
                onClick={handleSaveTask}
                disabled={saving}
                className="gap-2"
              >
                {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                Salvar
              </Button>
            )}
          </div>
        </SheetHeader>

        {/* Content */}
        <ScrollArea className="flex-1">
          <div className="p-6 space-y-6">
            
            {/* ============= SEÇÃO 1: PLANEJAMENTO DO CONTATO ============= */}
            <div className="space-y-4">
              <button
                onClick={() => setShowPlanningExpanded(!showPlanningExpanded)}
                className="flex items-center justify-between w-full text-left"
              >
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-violet-500/10 flex items-center justify-center">
                    <Target className="h-4 w-4 text-violet-600" />
                  </div>
                  <h3 className="font-semibold text-base">Planejamento do Contato</h3>
                </div>
                {showPlanningExpanded ? (
                  <ChevronUp className="h-4 w-4 text-muted-foreground" />
                ) : (
                  <ChevronDown className="h-4 w-4 text-muted-foreground" />
                )}
              </button>

              {showPlanningExpanded && (
                <div className="pl-10 space-y-4">
                  {/* Products to offer */}
                  <div className="space-y-2">
                    <Label className="text-sm font-medium">Produtos para oferecer</Label>
                    {planningProducts.length === 0 ? (
                      <p className="text-sm text-muted-foreground">Nenhum produto adicionado</p>
                    ) : (
                      <div className="space-y-2">
                        {planningProducts.map((product, index) => (
                          <div key={index} className="flex items-center gap-2 p-2 bg-muted/30 rounded-lg">
                            <Input
                              placeholder="Produto"
                              value={product.name}
                              onChange={(e) => updatePlanningProduct(index, 'name', e.target.value)}
                              className="flex-1 h-8"
                            />
                            <Input
                              placeholder="Preço"
                              value={product.price}
                              onChange={(e) => updatePlanningProduct(index, 'price', e.target.value)}
                              className="w-24 h-8"
                            />
                            <Input
                              placeholder="Prazo"
                              value={product.deadline}
                              onChange={(e) => updatePlanningProduct(index, 'deadline', e.target.value)}
                              className="w-24 h-8"
                            />
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8 shrink-0"
                              onClick={() => removePlanningProduct(index)}
                            >
                              <X className="h-4 w-4" />
                            </Button>
                          </div>
                        ))}
                      </div>
                    )}
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={addPlanningProduct}
                      className="gap-2"
                    >
                      <Plus className="h-4 w-4" />
                      Adicionar produto
                    </Button>
                  </div>

                  {/* Strategic notes */}
                  <div className="space-y-2">
                    <Label className="text-sm font-medium">Observações estratégicas</Label>
                    <Textarea
                      placeholder="O que falar com o cliente? Pontos importantes, descontos, condições..."
                      value={planningNotes}
                      onChange={(e) => setPlanningNotes(e.target.value)}
                      rows={3}
                      className="resize-none"
                    />
                  </div>

                  {/* Quick suggestions from product history */}
                  {productHistory.length > 0 && (
                    <div className="space-y-2">
                      <Label className="text-sm font-medium text-muted-foreground">
                        Produtos que o cliente costuma comprar:
                      </Label>
                      <div className="flex flex-wrap gap-1">
                        {productHistory.slice(0, 5).map((product, idx) => (
                          <Badge
                            key={idx}
                            variant="secondary"
                            className="cursor-pointer hover:bg-secondary/80 text-xs"
                            onClick={() => {
                              setPlanningProducts([...planningProducts, {
                                name: product.product_name,
                                price: formatCurrency(product.last_price),
                                deadline: '',
                              }]);
                            }}
                          >
                            + {product.product_name.substring(0, 25)}...
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>

            <Separator />

            {/* ============= SEÇÃO 2: DADOS DA TAREFA ============= */}
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-blue-500/10 flex items-center justify-center">
                  <FileText className="h-4 w-4 text-blue-600" />
                </div>
                <h3 className="font-semibold text-base">Dados da Tarefa</h3>
              </div>

              <div className="pl-10 grid grid-cols-2 gap-4">
                {/* Contact Reason */}
                <div className="space-y-2">
                  <Label className="text-sm">Motivo do Contato</Label>
                  <Select 
                    value={contactReason} 
                    onValueChange={(v) => setContactReason(v as ContactReason)}
                    disabled={isCompleted}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {CONTACT_REASON_OPTIONS.map((option) => (
                        <SelectItem key={option.value} value={option.value}>
                          {option.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Contact Type */}
                <div className="space-y-2">
                  <Label className="text-sm">Tipo de Contato</Label>
                  <div className="flex gap-2">
                    <Button
                      type="button"
                      variant={contactType === 'ligacao' ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => !isCompleted && setContactType('ligacao')}
                      disabled={isCompleted}
                      className="flex-1 gap-2"
                    >
                      <Phone className="h-4 w-4" />
                      Ligação
                    </Button>
                    <Button
                      type="button"
                      variant={contactType === 'whatsapp' ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => !isCompleted && setContactType('whatsapp')}
                      disabled={isCompleted}
                      className={cn("flex-1 gap-2", contactType === 'whatsapp' && "bg-emerald-600 hover:bg-emerald-700")}
                    >
                      <MessageCircle className="h-4 w-4" />
                      WhatsApp
                    </Button>
                  </div>
                </div>

                {/* Date */}
                <div className="space-y-2">
                  <Label className="text-sm flex items-center gap-1">
                    <Calendar className="h-3 w-3" />
                    Data
                  </Label>
                  <Input
                    type="date"
                    value={taskDate}
                    onChange={(e) => setTaskDate(e.target.value)}
                    disabled={isDateDisabled}
                    className={isDateDisabled ? 'opacity-60' : ''}
                  />
                </div>

                {/* Time */}
                <div className="space-y-2">
                  <Label className="text-sm flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    Hora
                  </Label>
                  <Input
                    type="time"
                    value={taskTime}
                    onChange={(e) => setTaskTime(e.target.value)}
                    disabled={isDateDisabled}
                    className={isDateDisabled ? 'opacity-60' : ''}
                  />
                </div>

                {/* Priority */}
                <div className="space-y-2">
                  <Label className="text-sm flex items-center gap-1">
                    <Flag className="h-3 w-3" />
                    Prioridade
                  </Label>
                  <div className="flex gap-1">
                    {priorityOptions.map((option) => (
                      <Button
                        key={option.value}
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => !isCompleted && setPriority(option.value as 'alta' | 'media' | 'baixa')}
                        disabled={isCompleted}
                        className={cn(
                          "flex-1 text-xs",
                          priority === option.value && option.color
                        )}
                      >
                        {option.label}
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Responsible */}
                <div className="space-y-2">
                  <Label className="text-sm flex items-center gap-1">
                    <User className="h-3 w-3" />
                    Responsável
                  </Label>
                  <Select 
                    value={responsibleSellerId} 
                    onValueChange={setResponsibleSellerId}
                    disabled={isCompleted}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione" />
                    </SelectTrigger>
                    <SelectContent>
                      {sellers.map((s) => (
                        <SelectItem key={s.id} value={s.id}>
                          {s.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Notes - full width */}
                <div className="col-span-2 space-y-2">
                  <Label className="text-sm">Observações da tarefa</Label>
                  <Textarea
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="Detalhes sobre esta tarefa..."
                    rows={2}
                    disabled={isCompleted}
                    className="resize-none"
                  />
                </div>
              </div>
            </div>

            <Separator />

            {/* ============= SEÇÃO 3: DADOS DO CLIENTE ============= */}
            <div className="space-y-4">
              <button
                onClick={() => setShowHistory(!showHistory)}
                className="flex items-center justify-between w-full text-left"
              >
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-amber-500/10 flex items-center justify-center">
                    <Building2 className="h-4 w-4 text-amber-600" />
                  </div>
                  <h3 className="font-semibold text-base">Dados do Cliente</h3>
                </div>
                {showHistory ? (
                  <ChevronUp className="h-4 w-4 text-muted-foreground" />
                ) : (
                  <ChevronDown className="h-4 w-4 text-muted-foreground" />
                )}
              </button>

              {loadingClient ? (
                <div className="pl-10 flex items-center gap-2 text-sm text-muted-foreground">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Carregando...
                </div>
              ) : clientData && (
                <div className="pl-10 space-y-4">
                  {/* Client KPIs */}
                  <div className="grid grid-cols-3 gap-3">
                    <div className="p-3 bg-muted/30 rounded-lg">
                      <div className="flex items-center gap-2 text-muted-foreground text-xs mb-1">
                        <DollarSign className="h-3 w-3" />
                        Faturamento
                      </div>
                      <p className="font-semibold">{formatCurrency(clientData.total_revenue || 0)}</p>
                    </div>
                    <div className="p-3 bg-muted/30 rounded-lg">
                      <div className="flex items-center gap-2 text-muted-foreground text-xs mb-1">
                        <Package className="h-3 w-3" />
                        Pedidos
                      </div>
                      <p className="font-semibold">{recentOrders.length}+ pedidos</p>
                    </div>
                    <div className="p-3 bg-muted/30 rounded-lg">
                      <div className="flex items-center gap-2 text-muted-foreground text-xs mb-1">
                        <Clock className="h-3 w-3" />
                        Última compra
                      </div>
                      <p className="font-semibold">{clientData.days_since_last_order ?? '—'} dias</p>
                    </div>
                  </div>

                  {/* Contact info */}
                  <div className="flex flex-wrap gap-4 text-sm">
                    {clientData.phone && (
                      <span className="flex items-center gap-1 text-muted-foreground">
                        <Phone className="h-3 w-3" />
                        {clientData.phone}
                      </span>
                    )}
                    {clientData.email && (
                      <span className="flex items-center gap-1 text-muted-foreground">
                        @{clientData.email}
                      </span>
                    )}
                    {clientData.cnpj && (
                      <span className="text-muted-foreground">CNPJ: {clientData.cnpj}</span>
                    )}
                  </div>

                  {/* Recent orders - collapsed by default */}
                  {showHistory && recentOrders.length > 0 && (
                    <div className="space-y-2">
                      <Label className="text-sm font-medium">Últimos pedidos</Label>
                      <div className="space-y-1">
                        {recentOrders.map((order) => (
                          <div
                            key={order.id}
                            className="flex items-center justify-between p-2 bg-muted/20 rounded text-sm"
                          >
                            <span className="font-medium">{order.order_number}</span>
                            <span className="text-muted-foreground">
                              {format(parseISO(order.order_date), 'dd/MM/yyyy', { locale: ptBR })}
                            </span>
                            <span className="font-medium">{formatCurrency(order.total)}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {clientData.observations && showHistory && (
                    <div className="p-3 bg-muted/20 rounded-lg">
                      <Label className="text-xs text-muted-foreground">Observações do cliente</Label>
                      <p className="text-sm mt-1">{clientData.observations}</p>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* ============= SEÇÃO 4: REGISTRO DO CONTATO ============= */}
            {!isCompleted && (
              <>
                <Separator />
                <div className="space-y-4">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-emerald-500/10 flex items-center justify-center">
                      <CheckCircle className="h-4 w-4 text-emerald-600" />
                    </div>
                    <h3 className="font-semibold text-base">Registrar Contato</h3>
                  </div>

                  <div className="pl-10 space-y-4">
                    {/* Completion notes */}
                    <div className="space-y-2">
                      <Label className="text-sm">Observação do contato</Label>
                      <Textarea
                        value={completionNotes}
                        onChange={(e) => setCompletionNotes(e.target.value)}
                        placeholder="Descreva o resultado do contato..."
                        rows={2}
                        className="resize-none"
                      />
                    </div>

                    {/* Successful contact buttons */}
                    <div className="space-y-2">
                      <Label className="text-sm text-muted-foreground">Conseguiu falar com o cliente?</Label>
                      <div className="grid grid-cols-2 gap-3">
                        <Button
                          variant="outline"
                          className="h-auto py-3 flex flex-col gap-1 border-emerald-500/30 hover:bg-emerald-500/10 hover:border-emerald-500/50 disabled:opacity-50"
                          onClick={() => handleSuccessfulContactClick('whatsapp')}
                          disabled={completing}
                        >
                          <MessageCircle className="h-5 w-5 text-emerald-500" />
                          <span className="font-medium text-sm">WhatsApp</span>
                        </Button>
                        <Button
                          variant="outline"
                          className="h-auto py-3 flex flex-col gap-1 border-blue-500/30 hover:bg-blue-500/10 hover:border-blue-500/50 disabled:opacity-50"
                          onClick={() => handleSuccessfulContactClick('ligacao')}
                          disabled={completing}
                        >
                          <Phone className="h-5 w-5 text-blue-500" />
                          <span className="font-medium text-sm">Ligação</span>
                        </Button>
                      </div>
                    </div>

                    {/* Divider */}
                    <div className="relative">
                      <div className="absolute inset-0 flex items-center">
                        <span className="w-full border-t" />
                      </div>
                      <div className="relative flex justify-center text-xs uppercase">
                        <span className="bg-background px-2 text-muted-foreground">
                          ou não conseguiu contato
                        </span>
                      </div>
                    </div>

                    {/* Attempt selection */}
                    <div className="space-y-2">
                      <RadioGroup value={attemptType} onValueChange={setAttemptType} className="space-y-2">
                        {ATTEMPT_TYPES.map((type) => (
                          <div
                            key={type.value}
                            className={cn(
                              'flex items-center space-x-3 p-3 rounded-lg border cursor-pointer transition-colors',
                              attemptType === type.value
                                ? 'border-amber-500 bg-amber-500/5'
                                : 'border-border hover:bg-muted/50'
                            )}
                            onClick={() => setAttemptType(type.value)}
                          >
                            <RadioGroupItem value={type.value} id={type.value} />
                            <type.icon className={cn(
                              'h-4 w-4',
                              attemptType === type.value ? 'text-amber-500' : 'text-muted-foreground'
                            )} />
                            <Label htmlFor={type.value} className="flex-1 cursor-pointer text-sm">
                              {type.label}
                            </Label>
                          </div>
                        ))}
                      </RadioGroup>

                      {attemptType && (
                        <Button
                          onClick={handleAttemptClick}
                          disabled={completing}
                          variant="secondary"
                          className="w-full bg-amber-500/10 hover:bg-amber-500/20 text-amber-600 border border-amber-500/20"
                        >
                          {completing && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                          Salvar Tentativa
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              </>
            )}
          </div>
        </ScrollArea>

        {/* Task Replication Modal */}
        <TaskReplicationModal
          open={showReplicationModal}
          onOpenChange={setShowReplicationModal}
          task={task}
          planningProducts={planningProducts}
          planningNotes={planningNotes}
          onCompleted={handleReplicationComplete}
        />
      </SheetContent>
    </Sheet>
  );
}
