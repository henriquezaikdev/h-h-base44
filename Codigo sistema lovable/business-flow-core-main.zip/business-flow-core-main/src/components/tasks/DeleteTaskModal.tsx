import { useState } from 'react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Loader2 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { useAuth } from '@/hooks/useAuth';

interface DeleteTaskModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  taskId: string;
  isCompleted: boolean;
  onDeleted: () => void;
  // Optional: task info for logging
  taskInfo?: {
    clientId?: string;
    clientName?: string;
    taskDate?: string;
    notes?: string;
    contactType?: string;
    contactReason?: string;
    responsibleSellerId?: string;
  };
}

export function DeleteTaskModal({
  open,
  onOpenChange,
  taskId,
  isCompleted,
  onDeleted,
  taskInfo,
}: DeleteTaskModalProps) {
  const [loading, setLoading] = useState(false);
  const { seller } = useAuth();

  const handleDelete = async () => {
    setLoading(true);
    try {
      // 1) Registrar no log de exclusões ANTES de deletar
      const logData = {
        task_id: taskId,
        vendor_id: taskInfo?.responsibleSellerId || seller?.id || null,
        deleted_by: seller?.id || null,
        due_date_original: taskInfo?.taskDate || null,
        client_id: taskInfo?.clientId || null,
        client_name: taskInfo?.clientName || null,
        task_notes: taskInfo?.notes || null,
        contact_type: taskInfo?.contactType || null,
        contact_reason: taskInfo?.contactReason || null,
      };

      const { error: logError } = await supabase
        .from('task_deletions_log')
        .insert(logData);

      if (logError) {
        console.error('Error logging task deletion:', logError);
      }

      // 2) Neutralizar status para evitar bloqueio do trigger de tarefas atrasadas
      await supabase
        .from('tasks')
        .update({ status: 'cancelada', canceled_at: new Date().toISOString() } as any)
        .eq('id', taskId);

      // 3) Excluir a tarefa
      const { error } = await supabase
        .from('tasks')
        .delete()
        .eq('id', taskId);

      if (error) throw error;

      toast.success('Tarefa excluída com sucesso!');
      onOpenChange(false);
      onDeleted();
    } catch (error) {
      console.error('Error deleting task:', error);
      toast.error('Erro ao excluir tarefa');
    } finally {
      setLoading(false);
    }
  };

  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Excluir Tarefa</AlertDialogTitle>
          <AlertDialogDescription>
            Esta tarefa será excluída permanentemente. Isso irá:
            <ul className="list-disc list-inside mt-2 space-y-1">
              <li>Remover a tarefa da agenda</li>
              <li>Remover do histórico do cliente</li>
              {isCompleted && (
                <li>Subtrair dos indicadores de tarefas concluídas</li>
              )}
              <li>Registrar a exclusão nos indicadores de qualidade</li>
            </ul>
            <p className="mt-3 font-medium text-destructive">
              Esta ação não pode ser desfeita e impacta seu desempenho.
            </p>
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel disabled={loading}>Cancelar</AlertDialogCancel>
          <AlertDialogAction
            onClick={handleDelete}
            disabled={loading}
            className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
          >
            {loading && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
            Excluir
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}