import { useState } from 'react';
import { format, addDays } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Copy, CalendarPlus, Loader2, Check } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Calendar } from '@/components/ui/calendar';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { cn } from '@/lib/utils';
import { generateTaskUniqueKey } from '@/lib/taskUtils';
import { TaskData } from '@/hooks/useTasksData';

interface TaskReplicationModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  task: TaskData;
  planningProducts?: { name: string; price: string; deadline: string }[];
  planningNotes?: string;
  onCompleted: () => void;
}

export function TaskReplicationModal({
  open,
  onOpenChange,
  task,
  planningProducts = [],
  planningNotes = '',
  onCompleted,
}: TaskReplicationModalProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(
    addDays(new Date(), 1)
  );
  const [datePopoverOpen, setDatePopoverOpen] = useState(false);

  const quickDateOptions = [
    { label: 'Amanhã', days: 1 },
    { label: 'Em 2 dias', days: 2 },
    { label: 'Em 3 dias', days: 3 },
    { label: 'Em 1 semana', days: 7 },
    { label: 'Em 2 semanas', days: 14 },
  ];

  const handleReplicate = async () => {
    if (!selectedDate) {
      toast.error('Selecione uma data para a nova tarefa');
      return;
    }

    setIsSubmitting(true);

    try {
      const newTaskDate = format(selectedDate, 'yyyy-MM-dd');
      
      // Generate unique key for the new task
      const uniqueKey = generateTaskUniqueKey({
        clientId: task.clientId,
        contactType: task.contactType,
        taskDate: newTaskDate,
        source: 'replication',
      });

      // Create the replicated task - inheriting all relevant fields including planning
      const { error } = await supabase
        .from('tasks')
        .insert({
          client_id: task.clientId,
          contact_type: task.contactType, // Inherited - cannot change
          contact_reason: task.contactReason, // Inherited - cannot change
          task_date: newTaskDate,
          task_time: null, // Reset time for new task
          notes: task.notes, // Inherit notes
          priority: task.priority,
          status: 'pendente',
          created_by_seller_id: task.createdBySellerId,
          unique_key: uniqueKey,
          planning_products: planningProducts, // Inherit planning products
          planning_notes: planningNotes || task.planningNotes || null, // Inherit planning notes
        });

      if (error) throw error;

      toast.success('Tarefa replicada com sucesso!', {
        description: `Nova tarefa agendada para ${format(selectedDate, "dd 'de' MMMM", { locale: ptBR })}`,
      });

      onOpenChange(false);
      onCompleted();
    } catch (error: any) {
      console.error('Error replicating task:', error);
      toast.error(error.message || 'Erro ao replicar tarefa');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleClose = () => {
    onOpenChange(false);
    onCompleted(); // Proceed with completion flow
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Copy className="h-5 w-5 text-primary" />
            Replicar Tarefa?
          </DialogTitle>
          <DialogDescription>
            Deseja criar uma nova tarefa para continuar o contato com{' '}
            <span className="font-medium text-foreground">{task.clientName}</span>?
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="p-3 bg-muted/30 rounded-lg text-sm space-y-1">
            <p className="text-muted-foreground">A nova tarefa herdará:</p>
            <ul className="text-foreground space-y-0.5 ml-4 list-disc">
              <li>Cliente: <span className="font-medium">{task.clientName}</span></li>
              <li>Tipo: <span className="font-medium">{task.contactType === 'whatsapp' ? 'WhatsApp' : 'Ligação'}</span></li>
              <li>Motivo: <span className="font-medium">{task.contactReason}</span></li>
              {task.notes && <li>Observações da tarefa original</li>}
            </ul>
          </div>

          <div className="space-y-2">
            <Label>Quando agendar a nova tarefa?</Label>

            {/* Quick date buttons */}
            <div className="flex flex-wrap gap-1.5">
              {quickDateOptions.map((opt) => {
                const optDate = addDays(new Date(), opt.days);
                const isSelected =
                  selectedDate &&
                  format(selectedDate, 'yyyy-MM-dd') ===
                    format(optDate, 'yyyy-MM-dd');

                return (
                  <Button
                    key={opt.days}
                    type="button"
                    variant={isSelected ? 'default' : 'outline'}
                    size="sm"
                    className="h-7 text-xs"
                    onClick={() => setSelectedDate(optDate)}
                  >
                    {opt.label}
                  </Button>
                );
              })}
            </div>

            {/* Calendar picker */}
            <Popover open={datePopoverOpen} onOpenChange={setDatePopoverOpen}>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    'w-full justify-start text-left font-normal',
                    !selectedDate && 'text-muted-foreground'
                  )}
                >
                  <CalendarPlus className="mr-2 h-4 w-4" />
                  {selectedDate
                    ? format(selectedDate, "dd 'de' MMMM, yyyy", {
                        locale: ptBR,
                      })
                    : 'Selecionar data'}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={selectedDate}
                  onSelect={(date) => {
                    setSelectedDate(date);
                    setDatePopoverOpen(false);
                  }}
                  initialFocus
                  locale={ptBR}
                  disabled={(date) => date < new Date()}
                />
              </PopoverContent>
            </Popover>
          </div>
        </div>

        <DialogFooter className="gap-2 sm:gap-0">
          <Button
            variant="ghost"
            onClick={handleClose}
            disabled={isSubmitting}
          >
            Não, apenas concluir
          </Button>
          <Button
            onClick={handleReplicate}
            disabled={isSubmitting || !selectedDate}
          >
            {isSubmitting ? (
              <Loader2 size={16} className="animate-spin mr-2" />
            ) : (
              <Check size={16} className="mr-2" />
            )}
            Sim, replicar tarefa
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
