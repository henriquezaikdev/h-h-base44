import { useState, useEffect, useCallback, forwardRef } from 'react';
import { Command, CommandEmpty, CommandGroup, CommandItem, CommandList } from '@/components/ui/command';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { Search, Package, Plus, Check, Loader2, ChevronsUpDown } from 'lucide-react';
import { cn } from '@/lib/utils';

interface Product {
  id: string;
  name: string;
  sku?: string | null;
}

interface ProductSearchComboboxProps {
  value: string;
  productId?: string;
  isManual?: boolean;
  onChange: (name: string, productId?: string, isManual?: boolean) => void;
  placeholder?: string;
  disabled?: boolean;
  className?: string;
}

export const ProductSearchCombobox = forwardRef<HTMLButtonElement, ProductSearchComboboxProps>(({
  value,
  productId,
  isManual,
  onChange,
  placeholder = 'Buscar produto...',
  disabled = false,
  className,
}, ref) => {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState('');
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(false);

  // Search products in database
  const searchProducts = useCallback(async (term: string) => {
    const clean = term.trim();
    
    if (clean.length < 2) {
      setProducts([]);
      return;
    }

    setLoading(true);
    try {
      // Using single chain to avoid type recursion issues
      const { data, error } = await supabase
        .from('products')
        .select('id, name, sku')
        .ilike('name', `%${clean}%`)
        .limit(20) as { data: Product[] | null; error: Error | null };

      if (error) throw error;
      setProducts(data?.filter((p: Product) => p) || []);
    } catch (err) {
      console.error('Error searching products:', err);
      setProducts([]);
    } finally {
      setLoading(false);
    }
  }, []);

  // Debounced search
  useEffect(() => {
    if (!open) return;
    const timer = setTimeout(() => searchProducts(search), 300);
    return () => clearTimeout(timer);
  }, [search, open, searchProducts]);

  // Reset search when popover closes
  useEffect(() => {
    if (!open) {
      setSearch('');
    }
  }, [open]);

  const handleSelectProduct = (product: Product) => {
    onChange(product.name, product.id, false);
    setOpen(false);
  };

  const handleAddManual = () => {
    if (search.trim()) {
      onChange(search.trim(), undefined, true);
      setOpen(false);
    }
  };

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          ref={ref}
          variant="outline"
          role="combobox"
          aria-expanded={open}
          disabled={disabled}
          className={cn(
            "w-full justify-between h-8 font-normal",
            !value && "text-muted-foreground",
            productId && !isManual && "border-primary/50 bg-primary/5",
            className
          )}
        >
          <div className="flex items-center gap-2 truncate">
            {productId && !isManual ? (
              <Package className="h-3.5 w-3.5 text-primary shrink-0" />
            ) : (
              <Search className="h-3.5 w-3.5 shrink-0" />
            )}
            <span className="truncate">{value || placeholder}</span>
          </div>
          <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
        </Button>
      </PopoverTrigger>
      <PopoverContent 
        className="w-[300px] p-0" 
        align="start"
        onOpenAutoFocus={(e) => e.preventDefault()}
      >
        <Command shouldFilter={false}>
          <div className="flex items-center border-b px-3">
            <Search className="mr-2 h-4 w-4 shrink-0 opacity-50" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Digite para buscar..."
              className="flex h-10 w-full rounded-md bg-transparent py-3 text-sm outline-none placeholder:text-muted-foreground"
              autoFocus
            />
          </div>
          <CommandList>
            {loading ? (
              <div className="p-4 text-center text-sm text-muted-foreground">
                <Loader2 className="h-4 w-4 animate-spin mx-auto mb-2" />
                Buscando...
              </div>
            ) : search.trim().length > 0 && search.trim().length < 2 ? (
              <div className="p-4 text-center text-sm text-muted-foreground">
                Digite pelo menos 2 caracteres
              </div>
            ) : products.length === 0 && search.trim().length >= 2 ? (
              <>
                <CommandEmpty className="py-2">
                  <p className="text-sm text-muted-foreground text-center mb-2">
                    Nenhum produto encontrado
                  </p>
                </CommandEmpty>
                <div className="p-2 border-t">
                  <button
                    onClick={handleAddManual}
                    className="flex items-center gap-2 w-full p-2 text-sm hover:bg-accent rounded-md text-left"
                  >
                    <Plus className="h-4 w-4 text-primary" />
                    <span>
                      Adicionar "<strong>{search.trim()}</strong>" manualmente
                    </span>
                  </button>
                </div>
              </>
            ) : products.length > 0 ? (
              <>
                <CommandGroup heading="Produtos" className="max-h-60 overflow-y-auto">
                  {products.map((product) => (
                    <CommandItem
                      key={product.id}
                      value={product.name}
                      onSelect={() => handleSelectProduct(product)}
                      className="cursor-pointer"
                    >
                      <Check
                        className={cn(
                          'mr-2 h-4 w-4',
                          productId === product.id ? 'opacity-100' : 'opacity-0'
                        )}
                      />
                      <div className="flex-1 truncate">
                        <span>{product.name}</span>
                        {product.sku && (
                          <span className="ml-2 text-xs text-muted-foreground">
                            ({product.sku})
                          </span>
                        )}
                      </div>
                    </CommandItem>
                  ))}
                </CommandGroup>
                {search.trim().length >= 2 && (
                  <div className="p-2 border-t">
                    <button
                      onClick={handleAddManual}
                      className="flex items-center gap-2 w-full p-2 text-sm hover:bg-accent rounded-md text-left text-muted-foreground"
                    >
                      <Plus className="h-4 w-4" />
                      <span>
                        Adicionar "<strong className="text-foreground">{search.trim()}</strong>" manualmente
                      </span>
                    </button>
                  </div>
                )}
              </>
            ) : (
              <div className="p-4 text-center text-sm text-muted-foreground">
                Digite para buscar produtos na base
              </div>
            )}
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
});

ProductSearchCombobox.displayName = 'ProductSearchCombobox';
