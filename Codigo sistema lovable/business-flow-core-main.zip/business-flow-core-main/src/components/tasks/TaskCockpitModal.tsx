import { useState, useEffect, useCallback } from 'react';
import { UserProfileDrawer } from '@/components/profile/UserProfileDrawer';
import { useQueryClient } from '@tanstack/react-query';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { 
  Phone, 
  MessageCircle, 
  CheckCircle, 
  PhoneOff, 
  MessageSquareOff,
  Calendar,
  Clock,
  Flag,
  Target,
  Building2,
  Package,
  DollarSign,
  ShoppingCart,
  FileText,
  Loader2,
  Save,
  AlertTriangle,
  User,
  ChevronDown,
  ChevronUp,
  Plus,
  X,
  CreditCard,
  History,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { TaskData, ContactReason, CONTACT_REASON_OPTIONS, PlanningProduct } from '@/hooks/useTasksData';
import { useTaskDatePermission } from '@/hooks/useTaskDatePermission';
import { useAuth } from '@/hooks/useAuth';
import { useClientPaymentTerm } from '@/hooks/useClientPaymentTerm';
import { SELLER_METRICS_QUERY_KEY } from '@/hooks/useSellerMetrics';
import { format, parseISO, isToday, isPast } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { TaskReplicationModal } from './TaskReplicationModal';
import { ProductSearchCombobox } from './ProductSearchCombobox';
import { ClientContactHistory } from './ClientContactHistory';
import { ClientOrdersModal } from '@/components/client/ClientOrdersModal';

// ============================================================
// INTERFACES
// ============================================================

interface Seller {
  id: string;
  name: string;
}

interface ClientData {
  id: string;
  company_name: string;
  cnpj: string | null;
  phone: string | null;
  email: string | null;
  ranking_tier: string | null;
  total_revenue: number | null;
  days_since_last_order: number | null;
  last_contact_at: string | null;
  observations: string | null;
  seller_id: string | null;
}

interface OrderData {
  id: string;
  order_number: string;
  order_date: string;
  total: number;
}

interface ProductHistoryItem {
  product_name: string;
  total_qty: number;
  last_price: number;
  last_order_date: string;
}

// PlanningProduct is imported from useTasksData

interface TaskCockpitModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  task: TaskData;
  sellers: Seller[];
  onCompleted: () => void;
}

// ============================================================
// CONSTANTS
// ============================================================

const priorityOptions = [
  { value: 'alta', label: 'Alta', color: 'text-red-600 border-red-500 bg-red-500/10' },
  { value: 'media', label: 'Média', color: 'text-amber-600 border-amber-500 bg-amber-500/10' },
  { value: 'baixa', label: 'Baixa', color: 'text-emerald-600 border-emerald-500 bg-emerald-500/10' },
];

const ATTEMPT_TYPES = [
  { value: 'whatsapp_sem_resposta', label: 'WhatsApp — sem resposta', icon: MessageSquareOff },
  { value: 'ligacao_sem_resposta', label: 'Ligação — sem resposta', icon: PhoneOff },
];

const RANKING_LABELS: Record<string, { label: string; color: string }> = {
  top20: { label: 'Top 20', color: 'bg-amber-500/10 text-amber-600 border-amber-500/30' },
  top100: { label: 'Top 100', color: 'bg-blue-500/10 text-blue-600 border-blue-500/30' },
  top200: { label: 'Top 200', color: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/30' },
  top300: { label: 'Top 300', color: 'bg-purple-500/10 text-purple-600 border-purple-500/30' },
  eventual: { label: 'Eventual', color: 'bg-muted text-muted-foreground' },
};

// ============================================================
// SUB-COMPONENTS
// ============================================================

function ClientKPIs({ 
  clientData, 
  recentOrders, 
  formatCurrency,
  onOrdersClick,
}: { 
  clientData: ClientData; 
  recentOrders: OrderData[]; 
  formatCurrency: (v: number) => string;
  onOrdersClick?: () => void;
}) {
  const { avgPaymentDays, loading: loadingPayment, totalOrders } = useClientPaymentTerm(clientData.id);

  return (
    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
      <div className="p-2.5 bg-muted/30 rounded-lg">
        <div className="flex items-center gap-1.5 text-muted-foreground text-xs mb-0.5">
          <DollarSign className="h-3 w-3" />
          Faturamento
        </div>
        <p className="font-semibold text-sm">{formatCurrency(clientData.total_revenue || 0)}</p>
      </div>
      {/* Pedidos clicável */}
      <button
        onClick={onOrdersClick}
        className="p-2.5 bg-muted/30 rounded-lg text-left hover:bg-muted/50 transition-colors cursor-pointer group"
      >
        <div className="flex items-center gap-1.5 text-muted-foreground text-xs mb-0.5 group-hover:text-primary transition-colors">
          <Package className="h-3 w-3" />
          Pedidos
        </div>
        <p className="font-semibold text-sm group-hover:text-primary transition-colors">{recentOrders.length}+ pedidos</p>
      </button>
      <div className="p-2.5 bg-muted/30 rounded-lg">
        <div className="flex items-center gap-1.5 text-muted-foreground text-xs mb-0.5">
          <Clock className="h-3 w-3" />
          Última compra
        </div>
        <p className="font-semibold text-sm">{clientData.days_since_last_order ?? '—'} dias</p>
      </div>
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <div className="p-2.5 bg-primary/5 border border-primary/20 rounded-lg cursor-help">
              <div className="flex items-center gap-1.5 text-primary text-xs mb-0.5">
                <CreditCard className="h-3 w-3" />
                Prazo Médio
              </div>
              {loadingPayment ? (
                <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
              ) : avgPaymentDays !== null && totalOrders > 0 ? (
                <p className="font-semibold text-sm text-primary">{avgPaymentDays} dias</p>
              ) : (
                <p className="text-xs text-muted-foreground">Sem histórico</p>
              )}
            </div>
          </TooltipTrigger>
          <TooltipContent>
            {avgPaymentDays !== null && totalOrders > 0 ? (
              <p>Baseado em {totalOrders} pedido{totalOrders > 1 ? 's' : ''}</p>
            ) : (
              <p>Nenhum pedido com prazo registrado</p>
            )}
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    </div>
  );
}

// ============================================================
// MAIN COMPONENT
// ============================================================

export function TaskCockpitModal({
  open,
  onOpenChange,
  task,
  sellers,
  onCompleted,
}: TaskCockpitModalProps) {
  const queryClient = useQueryClient();
  const { seller } = useAuth();
  const { canEditDate } = useTaskDatePermission();
  
  // ========== TASK DATA STATE ==========
  const [contactType, setContactType] = useState<'ligacao' | 'whatsapp'>('ligacao');
  const [contactReason, setContactReason] = useState<ContactReason>('RETORNO');
  const [taskDate, setTaskDate] = useState('');
  const [taskTime, setTaskTime] = useState('');
  const [notes, setNotes] = useState('');
  const [priority, setPriority] = useState<'alta' | 'media' | 'baixa'>('media');
  const [responsibleSellerId, setResponsibleSellerId] = useState<string>('');
  const [saving, setSaving] = useState(false);
  
  // ========== PLANNING STATE (BLOCO A) ==========
  const [planningProducts, setPlanningProducts] = useState<PlanningProduct[]>([]);
  const [planningNotes, setPlanningNotes] = useState('');
  const [showPlanning, setShowPlanning] = useState(true);
  
  // ========== CLIENT CONTEXT STATE (BLOCO C) ==========
  const [clientData, setClientData] = useState<ClientData | null>(null);
  const [recentOrders, setRecentOrders] = useState<OrderData[]>([]);
  const [productHistory, setProductHistory] = useState<ProductHistoryItem[]>([]);
  const [loadingClient, setLoadingClient] = useState(false);
  const [showClientContext, setShowClientContext] = useState(false);
  
  // ========== CONTACT REGISTRATION STATE (BLOCO D) ==========
  const [completionNotes, setCompletionNotes] = useState('');
  const [attemptType, setAttemptType] = useState<string>('');
  const [completing, setCompleting] = useState(false);
  
  // ========== RESULT TYPE STATE (XP) ==========
  const [resultType, setResultType] = useState<string>('');
  const [resultNote, setResultNote] = useState('');
  
  // ========== ORÇAMENTO EM ABERTO STATE ==========
  const [temOrcamentoAberto, setTemOrcamentoAberto] = useState(false);
  const [orcamentoCaCodigo, setOrcamentoCaCodigo] = useState('');
  const [orcamentoValor, setOrcamentoValor] = useState('');
  
  // ========== REPLICATION STATE ==========
  const [showReplicationModal, setShowReplicationModal] = useState(false);
  const [pendingCompletionType, setPendingCompletionType] = useState<'whatsapp' | 'ligacao' | 'attempt' | null>(null);
  
  // ========== ORDERS MODAL STATE ==========
  const [showOrdersModal, setShowOrdersModal] = useState(false);
  const [showProfileDrawer, setShowProfileDrawer] = useState(false);

  // ========== DERIVED STATE ==========
  const isCompleted = task?.status === 'concluida';
  const isOverdue = task && !isCompleted && task.taskDate ? (() => { try { const d = parseISO(task.taskDate); return isPast(d) && !isToday(d); } catch { return false; } })() : false;
  const isDateDisabled = isCompleted || !canEditDate;
  const reasonConfig = CONTACT_REASON_OPTIONS.find(r => r.value === contactReason) || CONTACT_REASON_OPTIONS[0];
  const rankingConfig = RANKING_LABELS[clientData?.ranking_tier || 'eventual'] || RANKING_LABELS.eventual;

  // ========== FETCH CLIENT DATA ==========
  const fetchClientData = useCallback(async (clientId: string) => {
    if (!clientId) return;
    setLoadingClient(true);
    try {
      const { data: client } = await supabase
        .from('clients')
        .select('id, company_name, cnpj, phone, email, ranking_tier, total_revenue, days_since_last_order, last_contact_at, observations, seller_id')
        .eq('id', clientId)
        .maybeSingle();
      
      if (client) setClientData(client as ClientData);
      
      const { data: orders } = await supabase
        .from('orders')
        .select('id, order_number, order_date, total')
        .eq('client_id', clientId)
        .eq('is_deleted', false)
        .order('order_date', { ascending: false })
        .limit(5);
      
      if (orders) setRecentOrders(orders as OrderData[]);
      
      const { data: products, error: productsError } = await supabase
        .from('order_items')
        .select('product_name, quantity, unit_price, orders!inner(client_id, order_date)')
        .eq('orders.client_id', clientId)
        .limit(50);
      
      if (productsError) {
        console.error('Error fetching product history:', productsError);
      }
      
      if (products && products.length > 0) {
        const productMap = new Map<string, ProductHistoryItem>();
        products.forEach((item: any) => {
          const productName = item.product_name || 'Sem nome';
          const existing = productMap.get(productName);
          if (existing) {
            existing.total_qty += item.quantity || 0;
          } else {
            productMap.set(productName, {
              product_name: productName,
              total_qty: item.quantity || 0,
              last_price: item.unit_price || 0,
              last_order_date: item.orders?.order_date || '',
            });
          }
        });
        setProductHistory(Array.from(productMap.values()).slice(0, 10));
      }
    } catch (error) {
      console.error('Error fetching client data:', error);
    } finally {
      setLoadingClient(false);
    }
  }, []);

  // ========== INITIALIZE MODAL ==========
  useEffect(() => {
    if (!open || !task) return;
    
    // Load task data
    setContactType(task.contactType);
    setContactReason(task.contactReason || 'RETORNO');
    setTaskDate(task.taskDate);
    setTaskTime(task.taskTime || '');
    setNotes(task.notes || '');
    setPriority(task.priority || 'media');
    setResponsibleSellerId(task.createdBySellerId || '');
    
    // Load planning data from task
    setPlanningProducts(task.planningProducts || []);
    setPlanningNotes(task.planningNotes || '');
    setCompletionNotes('');
    setAttemptType('');
    setShowPlanning(true);
    setShowClientContext(false);
    
    // Load orçamento data from task
    setTemOrcamentoAberto(task.temOrcamentoAberto || false);
    setOrcamentoCaCodigo(task.orcamentoCaCodigo || '');
    setOrcamentoValor(task.orcamentoValor?.toString() || '');
    
    // Fetch client data
    if (task.clientId) {
      fetchClientData(task.clientId);
    }
  }, [open, task, fetchClientData]);

  // ========== HANDLERS ==========
  
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);
  };

  const addPlanningProduct = () => {
    setPlanningProducts([...planningProducts, { name: '', price: '', deadline: '' }]);
  };

  const removePlanningProduct = (index: number) => {
    setPlanningProducts(planningProducts.filter((_, i) => i !== index));
  };

  const updatePlanningProduct = (index: number, field: keyof PlanningProduct, value: string) => {
    const updated = [...planningProducts];
    updated[index] = { ...updated[index], [field]: value };
    setPlanningProducts(updated);
  };

  // Save task changes (preserves all original logic)
  const handleSaveTask = async () => {
    if (!taskDate) {
      toast.error('Selecione uma data.');
      return;
    }
    if (!responsibleSellerId) {
      toast.error('Selecione um responsável.');
      return;
    }

    setSaving(true);
    try {
      // Filter out empty products
      const validProducts = planningProducts.filter(p => p.name.trim());
      
      const updateData: Record<string, any> = {
        contact_type: contactType,
        contact_reason: contactReason,
        notes: notes.trim() || null,
        created_by_seller_id: responsibleSellerId,
        priority,
        planning_products: validProducts,
        planning_notes: planningNotes.trim() || null,
        // Campos de orçamento
        tem_orcamento_aberto: temOrcamentoAberto,
        orcamento_ca_codigo: orcamentoCaCodigo.trim() || null,
        orcamento_valor: orcamentoValor ? parseFloat(orcamentoValor) : null,
        orcamento_aberto_em: temOrcamentoAberto ? new Date().toISOString() : null,
      };

      if (!isCompleted && canEditDate) {
        updateData.task_date = taskDate;
        updateData.task_time = taskTime || null;
      }

      const { error } = await supabase
        .from('tasks')
        .update(updateData)
        .eq('id', task.id);

      if (error) {
        if (error.message?.includes('DATA_BLOQUEADA')) {
          toast.error('Data bloqueada. Cancele e crie nova tarefa.');
          return;
        }
        throw error;
      }

      toast.success('Tarefa atualizada!');
      queryClient.invalidateQueries({ queryKey: [SELLER_METRICS_QUERY_KEY] });
      queryClient.invalidateQueries({ queryKey: ['tasks'] });
      queryClient.invalidateQueries({ queryKey: ['actionCenter'] });
      onCompleted();
    } catch (error: any) {
      console.error('Error updating task:', error);
      toast.error(error.message || 'Erro ao atualizar tarefa');
    } finally {
      setSaving(false);
    }
  };

  // Contact registration handlers
  const handleSuccessfulContactClick = (type: 'whatsapp' | 'ligacao') => {
    setPendingCompletionType(type);
    setShowReplicationModal(true);
  };

  const handleAttemptClick = () => {
    if (!attemptType) {
      toast.error('Selecione o tipo de tentativa');
      return;
    }
    // For attempts, auto-set result type
    setResultType(attemptType === 'whatsapp_sem_resposta' ? 'SEM_RETORNO' : 'CLIENTE_NAO_ATENDEU');
    setPendingCompletionType('attempt');
    setShowReplicationModal(true);
  };

  // Execute completion (ORIGINAL LOGIC - NO CHANGES)
  const executeCompletion = async () => {
    if (!pendingCompletionType || !task) return;

    setCompleting(true);
    try {
      const now = new Date();

      if (pendingCompletionType === 'attempt') {
        const contactTypeForAttempt = attemptType === 'whatsapp_sem_resposta' ? 'whatsapp' : 'ligacao';
        const finalResultType = attemptType === 'whatsapp_sem_resposta' ? 'SEM_RETORNO' : 'CLIENTE_NAO_ATENDEU';

        const { error } = await supabase
          .from('tasks')
          .update({
            status: 'concluida',
            completed_at: now.toISOString(),
            completion_notes: completionNotes,
            contact_successful: false,
            is_attempt: true,
            contact_type: contactTypeForAttempt,
            result_type: finalResultType,
            result_note: resultNote.trim() || null,
          })
          .eq('id', task.id);

        if (error) throw error;
        toast.success('Tentativa registrada!');
      } else {
        const { error } = await supabase
          .from('tasks')
          .update({
            status: 'concluida',
            completed_at: now.toISOString(),
            completion_notes: completionNotes,
            contact_successful: true,
            is_attempt: false,
            contact_type: pendingCompletionType,
            result_type: resultType,
            result_note: resultType === 'OUTRO' ? resultNote.trim() : null,
          })
          .eq('id', task.id);

        if (error) throw error;

        await supabase
          .from('clients')
          .update({ last_contact_at: now.toISOString() })
          .eq('id', task.clientId);

        const label = pendingCompletionType === 'whatsapp' ? 'WhatsApp' : 'Ligação';
        toast.success(`Contato via ${label} registrado!`);
      }

      queryClient.invalidateQueries({ queryKey: [SELLER_METRICS_QUERY_KEY] });
      queryClient.invalidateQueries({ queryKey: ['tasks'] });
      queryClient.invalidateQueries({ queryKey: ['actionCenter'] });
      onOpenChange(false);
      onCompleted();
    } catch (error) {
      console.error('Error completing task:', error);
      toast.error('Erro ao registrar contato');
    } finally {
      setCompleting(false);
      setPendingCompletionType(null);
    }
  };

  const handleReplicationComplete = () => {
    executeCompletion();
  };

  if (!task) return null;

  // ========== RENDER ==========
  return (
    <>
      <Sheet open={open} onOpenChange={onOpenChange}>
        <SheetContent 
          side="right" 
          className="w-full sm:max-w-[960px] p-0 flex flex-col overflow-hidden"
        >
          {/* ============================================== */}
          {/* HEADER - Cliente, Motivo, Tipo, Data, Prioridade, Responsável */}
          {/* ============================================== */}
          <SheetHeader className="px-6 py-4 border-b shrink-0 bg-gradient-to-r from-primary/5 to-transparent">
            <div className="flex flex-col gap-3">
              {/* Row 1: Client name + Status badges */}
              <div className="flex items-start justify-between gap-4">
                <div className="flex items-center gap-3 min-w-0">
                  <div className={cn(
                    'w-11 h-11 rounded-xl flex items-center justify-center shrink-0',
                    contactType === 'whatsapp' ? 'bg-emerald-500/10' : 'bg-blue-500/10'
                  )}>
                    {contactType === 'whatsapp' ? (
                      <MessageCircle className="h-5 w-5 text-emerald-600" />
                    ) : (
                      <Phone className="h-5 w-5 text-blue-600" />
                    )}
                  </div>
                  <div className="min-w-0">
                    <SheetTitle className="text-lg font-semibold truncate">
                      {task.clientName}
                    </SheetTitle>
                    <div className="flex items-center gap-2 mt-1 flex-wrap">
                      <Badge variant="outline" className={cn('text-xs', reasonConfig.color)}>
                        {reasonConfig.label}
                      </Badge>
                      <Badge variant="outline" className={cn('text-xs', rankingConfig.color)}>
                        {rankingConfig.label}
                      </Badge>
                      {isOverdue && (
                        <Badge variant="destructive" className="text-xs">
                          <AlertTriangle className="h-3 w-3 mr-1" />
                          Atrasada
                        </Badge>
                      )}
                      {isCompleted && (
                        <Badge variant="secondary" className="text-xs bg-emerald-500/10 text-emerald-600">
                          <CheckCircle className="h-3 w-3 mr-1" />
                          Concluída
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>

                {/* Save button */}
                {!isCompleted && (
                  <Button
                    size="sm"
                    onClick={handleSaveTask}
                    disabled={saving}
                    className="gap-2 shrink-0"
                  >
                    {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                    Salvar
                  </Button>
                )}
              </div>

              {/* Row 2: Quick info chips */}
              <div className="flex items-center gap-3 text-sm text-muted-foreground flex-wrap">
                <span className="flex items-center gap-1">
                  <Calendar className="h-3.5 w-3.5" />
                  {task.taskDate ? (() => { try { return format(parseISO(task.taskDate), 'dd/MM/yyyy', { locale: ptBR }); } catch { return task.taskDate; } })() : '—'}
                </span>
                {task.taskTime && (
                  <span className="flex items-center gap-1">
                    <Clock className="h-3.5 w-3.5" />
                    {task.taskTime.slice(0, 5)}
                  </span>
                )}
                <span className="flex items-center gap-1">
                  <Flag className="h-3.5 w-3.5" />
                  {priorityOptions.find(p => p.value === priority)?.label || 'Média'}
                </span>
                <button
                  onClick={() => setShowProfileDrawer(true)}
                  className="flex items-center gap-1 hover:text-primary transition-colors cursor-pointer"
                >
                  <User className="h-3.5 w-3.5" />
                  <span className="underline decoration-dotted">{sellers.find(s => s.id === responsibleSellerId)?.name || 'Responsável'}</span>
                </button>
              </div>
            </div>
          </SheetHeader>

          {/* ============================================== */}
          {/* CONTENT */}
          {/* ============================================== */}
          <ScrollArea className="flex-1">
            <div className="p-6 space-y-6">
              
              {/* ============================================== */}
              {/* BLOCO A - PLANEJAMENTO DO CONTATO */}
              {/* ============================================== */}
              <div className="space-y-3">
                <button
                  onClick={() => setShowPlanning(!showPlanning)}
                  className="flex items-center justify-between w-full text-left group"
                >
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-violet-500/10 flex items-center justify-center">
                      <Target className="h-4 w-4 text-violet-600" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-base">Planejamento do Contato</h3>
                      <p className="text-xs text-muted-foreground">Roteiro mental — não gera métricas</p>
                    </div>
                  </div>
                  {showPlanning ? (
                    <ChevronUp className="h-4 w-4 text-muted-foreground group-hover:text-foreground transition-colors" />
                  ) : (
                    <ChevronDown className="h-4 w-4 text-muted-foreground group-hover:text-foreground transition-colors" />
                  )}
                </button>

                {showPlanning && (
                  <div className="pl-10 space-y-4">
                    {/* Products to offer */}
                    <div className="space-y-2">
                      <Label className="text-sm font-medium">Produtos para oferecer</Label>
                      {planningProducts.length === 0 ? (
                        <p className="text-sm text-muted-foreground italic">Nenhum produto adicionado</p>
                      ) : (
                        <div className="space-y-2">
                          {planningProducts.map((product, index) => (
                            <div key={index} className="flex items-center gap-2 p-2 bg-muted/30 rounded-lg">
                              <ProductSearchCombobox
                                value={product.name}
                                productId={product.product_id}
                                isManual={product.isManual}
                                onChange={(name, productId, isManual) => {
                                  const updated = [...planningProducts];
                                  updated[index] = { ...updated[index], name, product_id: productId, isManual };
                                  setPlanningProducts(updated);
                                }}
                                placeholder="Buscar produto..."
                                className="flex-1"
                              />
                              <Input
                                placeholder="Preço"
                                value={product.price}
                                onChange={(e) => updatePlanningProduct(index, 'price', e.target.value)}
                                className="w-24 h-8"
                              />
                              <Input
                                placeholder="Prazo"
                                value={product.deadline}
                                onChange={(e) => updatePlanningProduct(index, 'deadline', e.target.value)}
                                className="w-24 h-8"
                              />
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-8 w-8 shrink-0"
                                onClick={() => removePlanningProduct(index)}
                              >
                                <X className="h-4 w-4" />
                              </Button>
                            </div>
                          ))}
                        </div>
                      )}
                      <Button variant="outline" size="sm" onClick={addPlanningProduct} className="gap-2">
                        <Plus className="h-4 w-4" />
                        Adicionar produto
                      </Button>

                      {/* Quick suggestions from history */}
                      {productHistory.length > 0 && (
                        <div className="pt-2">
                          <p className="text-xs text-muted-foreground mb-1.5">Produtos que o cliente costuma comprar:</p>
                          <div className="flex flex-wrap gap-1">
                            {productHistory.slice(0, 5).map((product, idx) => (
                              <Badge
                                key={idx}
                                variant="secondary"
                                className="cursor-pointer hover:bg-secondary/80 text-xs"
                                onClick={() => {
                                  setPlanningProducts([...planningProducts, {
                                    name: product.product_name,
                                    price: formatCurrency(product.last_price),
                                    deadline: '',
                                  }]);
                                }}
                              >
                                + {product.product_name.substring(0, 20)}...
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Strategic notes */}
                    <div className="space-y-2">
                      <Label className="text-sm font-medium">Observações estratégicas</Label>
                      <Textarea
                        placeholder="O que falar com o cliente? Pontos importantes, descontos, condições..."
                        value={planningNotes}
                        onChange={(e) => setPlanningNotes(e.target.value)}
                        rows={3}
                        className="resize-none"
                      />
                    </div>
                    
                    {/* Contact History - últimos 2 contatos */}
                    <ClientContactHistory clientId={task?.clientId || null} />
                  </div>
                )}
              </div>

              <Separator />

              {/* ============================================== */}
              {/* BLOCO B - DADOS DA TAREFA (MOTOR ORIGINAL) */}
              {/* ============================================== */}
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-blue-500/10 flex items-center justify-center">
                    <FileText className="h-4 w-4 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-base">Dados da Tarefa</h3>
                    <p className="text-xs text-muted-foreground">Campos que alimentam métricas e relatórios</p>
                  </div>
                </div>

                <div className="pl-10 grid grid-cols-2 gap-4">
                  {/* Contact Reason */}
                  <div className="space-y-1.5">
                    <Label className="text-sm">Motivo do Contato *</Label>
                    <Select 
                      value={contactReason} 
                      onValueChange={(v) => setContactReason(v as ContactReason)}
                      disabled={isCompleted}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {CONTACT_REASON_OPTIONS.map((option) => (
                          <SelectItem key={option.value} value={option.value}>
                            {option.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Contact Type */}
                  <div className="space-y-1.5">
                    <Label className="text-sm">Tipo de Contato *</Label>
                    <div className="flex gap-2">
                      <Button
                        type="button"
                        variant={contactType === 'ligacao' ? 'default' : 'outline'}
                        size="sm"
                        onClick={() => !isCompleted && setContactType('ligacao')}
                        disabled={isCompleted}
                        className="flex-1 gap-2"
                      >
                        <Phone className="h-4 w-4" />
                        Ligação
                      </Button>
                      <Button
                        type="button"
                        variant={contactType === 'whatsapp' ? 'default' : 'outline'}
                        size="sm"
                        onClick={() => !isCompleted && setContactType('whatsapp')}
                        disabled={isCompleted}
                        className={cn("flex-1 gap-2", contactType === 'whatsapp' && "bg-emerald-600 hover:bg-emerald-700")}
                      >
                        <MessageCircle className="h-4 w-4" />
                        WhatsApp
                      </Button>
                    </div>
                  </div>

                  {/* Date */}
                  <div className="space-y-1.5">
                    <Label className="text-sm flex items-center gap-1">
                      <Calendar className="h-3 w-3" />
                      Data *
                    </Label>
                    <Input
                      type="date"
                      value={taskDate}
                      onChange={(e) => setTaskDate(e.target.value)}
                      disabled={isDateDisabled}
                      className={isDateDisabled ? 'opacity-60' : ''}
                    />
                  </div>

                  {/* Time */}
                  <div className="space-y-1.5">
                    <Label className="text-sm flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      Hora
                    </Label>
                    <Input
                      type="time"
                      value={taskTime}
                      onChange={(e) => setTaskTime(e.target.value)}
                      disabled={isDateDisabled}
                      className={isDateDisabled ? 'opacity-60' : ''}
                    />
                  </div>

                  {/* Priority */}
                  <div className="space-y-1.5">
                    <Label className="text-sm flex items-center gap-1">
                      <Flag className="h-3 w-3" />
                      Prioridade
                    </Label>
                    <div className="flex gap-1">
                      {priorityOptions.map((option) => (
                        <Button
                          key={option.value}
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => !isCompleted && setPriority(option.value as 'alta' | 'media' | 'baixa')}
                          disabled={isCompleted}
                          className={cn(
                            "flex-1 text-xs",
                            priority === option.value && option.color
                          )}
                        >
                          {option.label}
                        </Button>
                      ))}
                    </div>
                  </div>

                  {/* Responsible */}
                  <div className="space-y-1.5">
                    <Label className="text-sm flex items-center gap-1">
                      <User className="h-3 w-3" />
                      Responsável *
                    </Label>
                    <Select 
                      value={responsibleSellerId} 
                      onValueChange={setResponsibleSellerId}
                      disabled={isCompleted}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione" />
                      </SelectTrigger>
                      <SelectContent>
                        {sellers.map((s) => (
                          <SelectItem key={s.id} value={s.id}>
                            {s.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Notes - full width */}
                  <div className="col-span-2 space-y-1.5">
                    <Label className="text-sm">Observações da tarefa</Label>
                    <Textarea
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      placeholder="Detalhes sobre esta tarefa..."
                      rows={2}
                      disabled={isCompleted}
                      className="resize-none"
                    />
                  </div>
                </div>
              </div>

              <Separator />

              {/* ============================================== */}
              {/* BLOCO C - CONTEXTO DO CLIENTE */}
              {/* ============================================== */}
              <div className="space-y-3">
                <button
                  onClick={() => setShowClientContext(!showClientContext)}
                  className="flex items-center justify-between w-full text-left group"
                >
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-amber-500/10 flex items-center justify-center">
                      <Building2 className="h-4 w-4 text-amber-600" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-base">Contexto do Cliente</h3>
                      <p className="text-xs text-muted-foreground">Dados, histórico e pedidos — apenas consulta</p>
                    </div>
                  </div>
                  {showClientContext ? (
                    <ChevronUp className="h-4 w-4 text-muted-foreground group-hover:text-foreground transition-colors" />
                  ) : (
                    <ChevronDown className="h-4 w-4 text-muted-foreground group-hover:text-foreground transition-colors" />
                  )}
                </button>

                {loadingClient ? (
                  <div className="pl-10 flex items-center gap-2 text-sm text-muted-foreground py-4">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Carregando dados do cliente...
                  </div>
                ) : clientData && (
                  <div className="pl-10 space-y-4">
                    {/* Client KPIs - always visible */}
                    <ClientKPIs 
                      clientData={clientData} 
                      recentOrders={recentOrders} 
                      formatCurrency={formatCurrency}
                      onOrdersClick={() => setShowOrdersModal(true)}
                    />

                    {/* Contact info */}
                    <div className="flex flex-wrap gap-4 text-sm">
                      {clientData.phone && (
                        <span className="flex items-center gap-1 text-muted-foreground">
                          <Phone className="h-3 w-3" />
                          {clientData.phone}
                        </span>
                      )}
                      {clientData.email && (
                        <span className="flex items-center gap-1 text-muted-foreground">
                          @{clientData.email}
                        </span>
                      )}
                      {clientData.cnpj && (
                        <span className="text-muted-foreground">CNPJ: {clientData.cnpj}</span>
                      )}
                    </div>

                    {/* Expanded section */}
                    {showClientContext && (
                      <>
                        {/* Recent orders */}
                        {recentOrders.length > 0 && (
                          <div className="space-y-2">
                            <div className="flex items-center gap-2">
                              <ShoppingCart className="h-4 w-4 text-muted-foreground" />
                              <Label className="text-sm font-medium">Últimos pedidos</Label>
                            </div>
                            <div className="space-y-1">
                              {recentOrders.map((order) => (
                                <div
                                  key={order.id}
                                  className="flex items-center justify-between p-2 bg-muted/20 rounded text-sm"
                                >
                                  <span className="font-medium">{order.order_number}</span>
                                  <span className="text-muted-foreground">
                                    {format(parseISO(order.order_date), 'dd/MM/yyyy', { locale: ptBR })}
                                  </span>
                                  <span className="font-medium">{formatCurrency(order.total)}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}

                        {/* Client observations */}
                        {clientData.observations && (
                          <div className="p-3 bg-muted/20 rounded-lg">
                            <Label className="text-xs text-muted-foreground">Observações do cliente</Label>
                            <p className="text-sm mt-1">{clientData.observations}</p>
                          </div>
                        )}

                        {/* Product history */}
                        {productHistory.length > 0 && (
                          <div className="space-y-2">
                            <div className="flex items-center gap-2">
                              <History className="h-4 w-4 text-muted-foreground" />
                              <Label className="text-sm font-medium">Produtos mais comprados</Label>
                            </div>
                            <div className="flex flex-wrap gap-1">
                              {productHistory.map((product, idx) => (
                                <Badge key={idx} variant="secondary" className="text-xs">
                                  {(product.product_name || 'Sem nome').substring(0, 25)}... ({product.total_qty}x)
                                </Badge>
                              ))}
                            </div>
                          </div>
                        )}
                      </>
                    )}
                  </div>
                )}
              </div>

              {/* ============================================== */}
              {/* BLOCO E - ORÇAMENTO EM ABERTO (só se não concluída) */}
              {/* ============================================== */}
              {!isCompleted && (
                <>
                  <Separator />
                  <div className="space-y-3">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-lg bg-amber-500/10 flex items-center justify-center">
                        <FileText className="h-4 w-4 text-amber-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-base">Orçamento em Aberto</h3>
                        <p className="text-xs text-muted-foreground">Marque se enviou orçamento para acompanhamento</p>
                      </div>
                    </div>

                    <div className="pl-10 space-y-3">
                      {/* Checkbox principal */}
                      <div className="flex items-center space-x-3">
                        <input
                          type="checkbox"
                          id="tem-orcamento"
                          checked={temOrcamentoAberto}
                          onChange={(e) => setTemOrcamentoAberto(e.target.checked)}
                          className="w-4 h-4 rounded border-amber-500 text-amber-600 focus:ring-amber-500"
                        />
                        <Label htmlFor="tem-orcamento" className="text-sm cursor-pointer">
                          Este cliente tem um orçamento em aberto
                        </Label>
                      </div>

                      {/* Campos condicionais */}
                      {temOrcamentoAberto && (
                        <div className="grid grid-cols-2 gap-3 p-3 rounded-lg border border-amber-500/20 bg-amber-50/50 dark:bg-amber-950/20">
                          <div className="space-y-1.5">
                            <Label className="text-xs text-muted-foreground">Código do Orçamento (CA)</Label>
                            <Input
                              value={orcamentoCaCodigo}
                              onChange={(e) => setOrcamentoCaCodigo(e.target.value)}
                              placeholder="Ex: 12345"
                              className="h-8 text-sm"
                            />
                          </div>
                          <div className="space-y-1.5">
                            <Label className="text-xs text-muted-foreground">Valor do Orçamento</Label>
                            <Input
                              type="number"
                              value={orcamentoValor}
                              onChange={(e) => setOrcamentoValor(e.target.value)}
                              placeholder="R$ 0,00"
                              className="h-8 text-sm"
                            />
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </>
              )}

              {/* ============================================== */}
              {/* BLOCO D - REGISTRO DO CONTATO (só se não concluída) */}
              {/* ============================================== */}
              {!isCompleted && (
                <>
                  <Separator />
                  <div className="space-y-3">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-lg bg-emerald-500/10 flex items-center justify-center">
                        <CheckCircle className="h-4 w-4 text-emerald-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-base">Registrar Contato</h3>
                        <p className="text-xs text-muted-foreground">Conclusão da tarefa — gera métricas</p>
                      </div>
                    </div>

                    <div className="pl-10 space-y-4">
                      {/* Result Type - OBRIGATÓRIO para XP */}
                      <div className="space-y-1.5">
                        <Label className="text-sm font-medium">Resultado do contato</Label>
                        <Select value={resultType} onValueChange={setResultType}>
                          <SelectTrigger className={!resultType ? 'border-amber-500/50' : ''}>
                            <SelectValue placeholder="Selecione o resultado..." />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="CLIENTE_RESPONDEU">Cliente respondeu</SelectItem>
                            <SelectItem value="FOLLOWUP_AGENDADO">Follow-up agendado</SelectItem>
                            <SelectItem value="PROPOSTA_ENVIADA">Proposta enviada</SelectItem>
                            <SelectItem value="VENDA_REALIZADA">Venda realizada</SelectItem>
                            <SelectItem value="CLIENTE_NAO_ATENDEU">Cliente não atendeu</SelectItem>
                            <SelectItem value="SEM_RETORNO">Sem retorno</SelectItem>
                            <SelectItem value="OUTRO">Outro</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      {resultType === 'OUTRO' && (
                        <div className="space-y-1.5">
                          <Label className="text-sm">Descreva o resultado</Label>
                          <Input
                            value={resultNote}
                            onChange={(e) => setResultNote(e.target.value)}
                            placeholder="Ex: reunião presencial, visita técnica..."
                            className="h-9"
                          />
                        </div>
                      )}

                      {/* Completion notes */}
                      <div className="space-y-1.5">
                        <Label className="text-sm">Observação do contato</Label>
                        <Textarea
                          value={completionNotes}
                          onChange={(e) => setCompletionNotes(e.target.value)}
                          placeholder="Descreva o resultado do contato..."
                          rows={2}
                          className="resize-none"
                        />
                      </div>

                      {/* Successful contact buttons */}
                      <div className="space-y-2">
                        <Label className="text-sm text-muted-foreground">Conseguiu falar com o cliente?</Label>
                        <div className="grid grid-cols-2 gap-3">
                          <Button
                            variant="outline"
                            className="h-auto py-3 flex flex-col gap-1 border-emerald-500/30 hover:bg-emerald-500/10 hover:border-emerald-500/50 disabled:opacity-50"
                            onClick={() => handleSuccessfulContactClick('whatsapp')}
                            disabled={completing}
                          >
                            <MessageCircle className="h-5 w-5 text-emerald-500" />
                            <span className="font-medium text-sm">WhatsApp</span>
                          </Button>
                          <Button
                            variant="outline"
                            className="h-auto py-3 flex flex-col gap-1 border-blue-500/30 hover:bg-blue-500/10 hover:border-blue-500/50 disabled:opacity-50"
                            onClick={() => handleSuccessfulContactClick('ligacao')}
                            disabled={completing}
                          >
                            <Phone className="h-5 w-5 text-blue-500" />
                            <span className="font-medium text-sm">Ligação</span>
                          </Button>
                        </div>
                      </div>

                      {/* Divider */}
                      <div className="relative">
                        <div className="absolute inset-0 flex items-center">
                          <span className="w-full border-t" />
                        </div>
                        <div className="relative flex justify-center text-xs uppercase">
                          <span className="bg-background px-2 text-muted-foreground">
                            ou não conseguiu contato
                          </span>
                        </div>
                      </div>

                      {/* Attempt selection */}
                      <div className="space-y-2">
                        <RadioGroup value={attemptType} onValueChange={setAttemptType} className="space-y-2">
                          {ATTEMPT_TYPES.map((type) => (
                            <div
                              key={type.value}
                              className={cn(
                                'flex items-center space-x-3 p-3 rounded-lg border cursor-pointer transition-colors',
                                attemptType === type.value
                                  ? 'border-amber-500 bg-amber-500/5'
                                  : 'border-border hover:bg-muted/50'
                              )}
                              onClick={() => setAttemptType(type.value)}
                            >
                              <RadioGroupItem value={type.value} id={`cockpit-${type.value}`} />
                              <type.icon className={cn(
                                'h-4 w-4',
                                attemptType === type.value ? 'text-amber-500' : 'text-muted-foreground'
                              )} />
                              <Label htmlFor={`cockpit-${type.value}`} className="flex-1 cursor-pointer text-sm">
                                {type.label}
                              </Label>
                            </div>
                          ))}
                        </RadioGroup>

                        {attemptType && (
                          <Button
                            variant="outline"
                            className="w-full border-amber-500/30 text-amber-600 hover:bg-amber-500/10"
                            onClick={handleAttemptClick}
                            disabled={completing}
                          >
                            {completing ? (
                              <Loader2 className="h-4 w-4 animate-spin mr-2" />
                            ) : null}
                            Registrar tentativa
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                </>
              )}
            </div>
          </ScrollArea>
        </SheetContent>
      </Sheet>

      {/* Replication Modal */}
      {task && (
        <TaskReplicationModal
          open={showReplicationModal}
          onOpenChange={setShowReplicationModal}
          task={task}
          planningProducts={planningProducts}
          planningNotes={planningNotes}
          onCompleted={handleReplicationComplete}
        />
      )}

      {/* Orders Modal */}
      <ClientOrdersModal
        open={showOrdersModal}
        onOpenChange={setShowOrdersModal}
        clientName={task?.clientName || ''}
        clientId={task?.clientId || null}
      />

      {/* User Profile Drawer */}
      {responsibleSellerId && (
        <UserProfileDrawer
          open={showProfileDrawer}
          onOpenChange={setShowProfileDrawer}
          sellerId={responsibleSellerId}
          sellerName={sellers.find(s => s.id === responsibleSellerId)?.name || 'Usuário'}
        />
      )}
    </>
  );
}
