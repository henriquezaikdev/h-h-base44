import { useState } from 'react';
import {
  AlertDialog,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Loader2, AlertTriangle } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

const CANCEL_REASONS = [
  { value: 'cliente_nao_atendeu', label: 'Cliente não atendeu' },
  { value: 'tarefa_duplicada', label: 'Tarefa duplicada' },
  { value: 'mudanca_responsavel', label: 'Mudança de responsável' },
  { value: 'cliente_nao_precisa', label: 'Cliente não precisa mais' },
  { value: 'erro_criacao', label: 'Erro na criação' },
  { value: 'reagendado_nova_tarefa', label: 'Reagendado (nova tarefa criada)' },
  { value: 'outro', label: 'Outro motivo' },
];

interface CancelTaskModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  taskId: string;
  clientName?: string;
  onCanceled: () => void;
}

export function CancelTaskModal({
  open,
  onOpenChange,
  taskId,
  clientName,
  onCanceled,
}: CancelTaskModalProps) {
  const [loading, setLoading] = useState(false);
  const [reason, setReason] = useState('');
  const [customReason, setCustomReason] = useState('');
  const [note, setNote] = useState('');

  const handleCancel = async () => {
    const finalReason = reason === 'outro' ? customReason : CANCEL_REASONS.find(r => r.value === reason)?.label || reason;
    
    if (!finalReason || finalReason.length < 5) {
      toast.error('Informe um motivo válido (mínimo 5 caracteres)');
      return;
    }

    setLoading(true);
    try {
      const { data, error } = await supabase.rpc('cancel_task', {
        p_task_id: taskId,
        p_reason: finalReason,
        p_note: note || null,
      });

      if (error) throw error;
      
      const result = data as { success: boolean; error?: string; message?: string };
      
      if (!result.success) {
        throw new Error(result.error || 'Erro ao cancelar tarefa');
      }

      toast.success('Tarefa cancelada com sucesso');
      setReason('');
      setCustomReason('');
      setNote('');
      onOpenChange(false);
      onCanceled();
    } catch (error: any) {
      console.error('Error canceling task:', error);
      toast.error(error.message || 'Erro ao cancelar tarefa');
    } finally {
      setLoading(false);
    }
  };

  const isValid = reason && (reason !== 'outro' || customReason.length >= 5);

  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent className="max-w-md">
        <AlertDialogHeader>
          <AlertDialogTitle className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-amber-500" />
            Cancelar Tarefa
          </AlertDialogTitle>
          <AlertDialogDescription asChild>
            <div className="space-y-3">
              {clientName && (
                <p className="text-sm">
                  Cliente: <span className="font-medium">{clientName}</span>
                </p>
              )}
              <div className="bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 rounded-md p-3 text-sm text-amber-800 dark:text-amber-200">
                <strong>Atenção:</strong> O cancelamento será registrado no histórico e 
                impactará as métricas de desempenho. Tarefas canceladas aparecem nos relatórios.
              </div>
            </div>
          </AlertDialogDescription>
        </AlertDialogHeader>

        <div className="space-y-4 py-2">
          <div className="space-y-2">
            <Label htmlFor="cancel-reason" className="text-sm font-medium">
              Motivo do cancelamento <span className="text-destructive">*</span>
            </Label>
            <Select value={reason} onValueChange={setReason}>
              <SelectTrigger id="cancel-reason">
                <SelectValue placeholder="Selecione um motivo..." />
              </SelectTrigger>
              <SelectContent>
                {CANCEL_REASONS.map((r) => (
                  <SelectItem key={r.value} value={r.value}>
                    {r.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {reason === 'outro' && (
            <div className="space-y-2">
              <Label htmlFor="custom-reason" className="text-sm font-medium">
                Especifique o motivo <span className="text-destructive">*</span>
              </Label>
              <Textarea
                id="custom-reason"
                value={customReason}
                onChange={(e) => setCustomReason(e.target.value)}
                placeholder="Descreva o motivo do cancelamento..."
                className="min-h-[60px]"
              />
              {customReason.length > 0 && customReason.length < 5 && (
                <p className="text-xs text-destructive">Mínimo 5 caracteres</p>
              )}
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="cancel-note" className="text-sm font-medium">
              Observação adicional <span className="text-muted-foreground">(opcional)</span>
            </Label>
            <Textarea
              id="cancel-note"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Alguma informação adicional..."
              className="min-h-[60px]"
            />
          </div>
        </div>

        <AlertDialogFooter>
          <AlertDialogCancel disabled={loading}>Voltar</AlertDialogCancel>
          <Button
            onClick={handleCancel}
            disabled={loading || !isValid}
            variant="destructive"
          >
            {loading && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
            Cancelar Tarefa
          </Button>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}
