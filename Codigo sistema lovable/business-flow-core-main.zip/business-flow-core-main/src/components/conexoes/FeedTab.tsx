import { useState } from 'react';
import { useFeedData } from '@/hooks/useFeedData';
import { FeedCard } from './FeedCard';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Skeleton } from '@/components/ui/skeleton';
import { MessageCircle } from 'lucide-react';

interface FeedTabProps {
  isAdmin: boolean;
}

export function FeedTab({ isAdmin }: FeedTabProps) {
  const [filter, setFilter] = useState('all');
  const {
    events,
    loading,
    addReaction,
    removeReaction,
    addComment,
    fetchComments,
    hideEvent,
    deleteComment,
  } = useFeedData(filter);

  return (
    <div className="space-y-4">
      {/* Filters */}
      <Tabs value={filter} onValueChange={setFilter}>
        <TabsList className="h-8">
          <TabsTrigger value="all" className="text-xs h-7">Tudo</TabsTrigger>
          <TabsTrigger value="medals" className="text-xs h-7">Medalhas</TabsTrigger>
          <TabsTrigger value="coins" className="text-xs h-7">Reconhecimentos</TabsTrigger>
        </TabsList>
      </Tabs>

      {/* Feed */}
      {loading ? (
        <div className="space-y-3">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-28 w-full rounded-lg" />
          ))}
        </div>
      ) : events.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground">
          <MessageCircle className="h-10 w-10 mx-auto mb-3 opacity-30" />
          <p className="text-sm">Nenhum evento no feed ainda.</p>
          <p className="text-xs mt-1">Envie H-Coins ou conquiste medalhas para começar!</p>
        </div>
      ) : (
        <div className="space-y-3">
          {events.map(event => (
            <FeedCard
              key={event.id}
              event={event}
              isAdmin={isAdmin}
              onReact={addReaction}
              onRemoveReaction={removeReaction}
              onComment={addComment}
              onFetchComments={fetchComments}
              onHide={isAdmin ? hideEvent : undefined}
              onDeleteComment={isAdmin ? deleteComment : undefined}
            />
          ))}
        </div>
      )}
    </div>
  );
}
