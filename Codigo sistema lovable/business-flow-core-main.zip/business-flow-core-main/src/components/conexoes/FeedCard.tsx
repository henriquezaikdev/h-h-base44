import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { MessageCircle, Award, Coins, Flame, Eye, EyeOff, Trash2 } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { toast } from 'sonner';
import type { FeedEvent, FeedComment } from '@/hooks/useFeedData';

const REACTIONS = ['👍', '👏', '🔥', '✅'];

const typeConfig: Record<string, { icon: typeof Award; color: string; label: string }> = {
  COIN_GIVEN: { icon: Coins, color: 'text-amber-500', label: 'Reconhecimento' },
  MEDAL_EARNED: { icon: Award, color: 'text-purple-500', label: 'Medalha' },
  STREAK_REACHED: { icon: Flame, color: 'text-orange-500', label: 'Streak' },
  MILESTONE_REACHED: { icon: Award, color: 'text-emerald-500', label: 'Marco' },
};

interface FeedCardProps {
  event: FeedEvent;
  isAdmin: boolean;
  onReact: (eventId: string, reaction: string) => void;
  onRemoveReaction: (eventId: string, reaction: string) => void;
  onComment: (eventId: string, content: string) => Promise<{ error?: string }>;
  onFetchComments: (eventId: string) => Promise<FeedComment[]>;
  onHide?: (eventId: string, reason: string) => void;
  onDeleteComment?: (commentId: string, reason: string) => void;
}

export function FeedCard({
  event,
  isAdmin,
  onReact,
  onRemoveReaction,
  onComment,
  onFetchComments,
  onHide,
  onDeleteComment,
}: FeedCardProps) {
  const [showComments, setShowComments] = useState(false);
  const [comments, setComments] = useState<FeedComment[]>([]);
  const [newComment, setNewComment] = useState('');
  const [loadingComments, setLoadingComments] = useState(false);

  const config = typeConfig[event.type] || typeConfig.COIN_GIVEN;
  const Icon = config.icon;
  const initials = (event.target_name || 'U').split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase();

  const toggleComments = async () => {
    if (!showComments) {
      setLoadingComments(true);
      const data = await onFetchComments(event.id);
      setComments(data);
      setLoadingComments(false);
    }
    setShowComments(!showComments);
  };

  const handleSubmitComment = async () => {
    if (!newComment.trim()) return;
    const result = await onComment(event.id, newComment.trim());
    if (result.error) {
      toast.error(result.error);
    } else {
      setNewComment('');
      const data = await onFetchComments(event.id);
      setComments(data);
    }
  };

  return (
    <Card className="border-border/50 hover:border-border transition-colors">
      <CardContent className="p-4 space-y-3">
        {/* Header */}
        <div className="flex items-start gap-3">
          <Avatar className="h-10 w-10 shrink-0">
            <AvatarFallback className="bg-primary/10 text-primary text-sm font-semibold">
              {initials}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="font-semibold text-foreground text-sm">{event.target_name}</span>
              <Badge variant="outline" className="text-[10px] px-1.5 py-0">
                <Icon size={10} className={config.color + ' mr-1'} />
                {config.label}
              </Badge>
            </div>
            <p className="text-sm text-foreground mt-0.5">{event.title}</p>
            {event.subtitle && (
              <p className="text-xs text-muted-foreground mt-0.5">{event.subtitle}</p>
            )}
            <p className="text-[10px] text-muted-foreground/60 mt-1">
              {formatDistanceToNow(new Date(event.created_at), { addSuffix: true, locale: ptBR })}
            </p>
          </div>

          {/* Admin actions */}
          {isAdmin && onHide && (
            <Button
              variant="ghost"
              size="icon"
              className="h-7 w-7 text-muted-foreground hover:text-destructive"
              onClick={() => onHide(event.id, 'Oculto pelo admin')}
              title="Ocultar evento"
            >
              <EyeOff size={14} />
            </Button>
          )}
        </div>

        {/* Reactions */}
        <div className="flex items-center gap-1 flex-wrap">
          {REACTIONS.map(r => {
            const existing = event.reactions?.find(er => er.reaction === r);
            const isActive = event.user_reactions?.includes(r);
            return (
              <Button
                key={r}
                variant={isActive ? 'secondary' : 'ghost'}
                size="sm"
                className="h-7 px-2 text-xs gap-1"
                onClick={() => isActive ? onRemoveReaction(event.id, r) : onReact(event.id, r)}
              >
                {r} {existing ? existing.count : ''}
              </Button>
            );
          })}
          <Button
            variant="ghost"
            size="sm"
            className="h-7 px-2 text-xs gap-1 ml-auto"
            onClick={toggleComments}
          >
            <MessageCircle size={12} />
            {event.comments_count || 0}
          </Button>
        </div>

        {/* Comments */}
        {showComments && (
          <div className="space-y-2 pt-2 border-t border-border/50">
            {loadingComments ? (
              <p className="text-xs text-muted-foreground">Carregando...</p>
            ) : (
              <>
                {comments.map(c => (
                  <div key={c.id} className="flex items-start gap-2 text-xs">
                    <span className="font-medium text-foreground shrink-0">{c.user_name}:</span>
                    <span className="text-muted-foreground flex-1">{c.content}</span>
                    {isAdmin && onDeleteComment && (
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-5 w-5 text-muted-foreground hover:text-destructive shrink-0"
                        onClick={() => onDeleteComment(c.id, 'Removido pelo admin')}
                      >
                        <Trash2 size={10} />
                      </Button>
                    )}
                  </div>
                ))}
                <div className="flex gap-2">
                  <Textarea
                    value={newComment}
                    onChange={e => setNewComment(e.target.value.slice(0, 180))}
                    placeholder="Comentar... (máx 180 chars)"
                    className="min-h-[32px] h-8 text-xs resize-none"
                    onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSubmitComment(); } }}
                  />
                  <Button size="sm" className="h-8 text-xs" onClick={handleSubmitComment} disabled={!newComment.trim()}>
                    Enviar
                  </Button>
                </div>
                <p className="text-[10px] text-muted-foreground/50">{newComment.length}/180</p>
              </>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
