import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Shield, Heart, AlertTriangle, Lock } from 'lucide-react';

const rules = [
  {
    icon: Heart,
    title: 'Respeito acima de tudo',
    description: 'Trate todos com respeito. Sem ofensas, discriminação ou comentários inadequados.',
  },
  {
    icon: Shield,
    title: 'Sem exposição',
    description: 'Não compartilhe informações privadas de colegas. Feedbacks e advertências são confidenciais.',
  },
  {
    icon: AlertTriangle,
    title: 'Sem spam',
    description: 'Evite comentários repetitivos ou sem propósito. Qualidade importa mais que quantidade.',
  },
  {
    icon: Lock,
    title: 'Confidencialidade financeira',
    description: 'Não discuta salários, comissões ou dados financeiros sensíveis no feed.',
  },
];

export function MuralTab() {
  return (
    <div className="space-y-6">
      <div className="text-center space-y-2">
        <h2 className="text-lg font-bold text-foreground">Regras de Convivência</h2>
        <p className="text-sm text-muted-foreground">
          Este espaço é para reconhecimento e cultura. Mantenha-o saudável.
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        {rules.map((rule, i) => (
          <Card key={i} className="border-border/50">
            <CardContent className="p-4 flex items-start gap-3">
              <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                <rule.icon size={18} className="text-primary" />
              </div>
              <div>
                <h3 className="text-sm font-semibold text-foreground">{rule.title}</h3>
                <p className="text-xs text-muted-foreground mt-0.5">{rule.description}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="bg-muted/50">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm">📌 Sobre o sistema</CardTitle>
        </CardHeader>
        <CardContent className="text-xs text-muted-foreground space-y-1">
          <p>• <strong>H-Coins:</strong> Máximo 3 moedas/dia, 1 por pessoa.</p>
          <p>• <strong>Medalhas:</strong> Concedidas automaticamente por desempenho real.</p>
          <p>• <strong>Comentários:</strong> Máximo 3 por evento por dia, 180 caracteres.</p>
          <p>• <strong>Moderação:</strong> Admin pode ocultar eventos e remover comentários.</p>
        </CardContent>
      </Card>
    </div>
  );
}
