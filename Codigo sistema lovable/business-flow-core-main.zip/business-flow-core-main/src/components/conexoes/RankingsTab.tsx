import { useRankingsData } from '@/hooks/useFeedData';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Coins, Clock, Award, Trophy } from 'lucide-react';

const podiumColors = ['text-amber-500', 'text-slate-400', 'text-orange-600'];

function RankingCard({
  title,
  icon: Icon,
  items,
  valueLabel,
  mySellerId,
}: {
  title: string;
  icon: typeof Coins;
  items: { seller_id: string; name: string; count?: number; score?: number }[];
  valueLabel: string;
  mySellerId?: string;
}) {
  const top5 = items.slice(0, 5);
  const myItem = items.find(i => i.seller_id === mySellerId);
  const myPosition = items.findIndex(i => i.seller_id === mySellerId) + 1;
  const showMyPosition = myPosition > 5 && myItem;

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-sm flex items-center gap-2">
          <Icon size={16} className="text-primary" />
          {title}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-2">
        {top5.length === 0 ? (
          <p className="text-xs text-muted-foreground py-4 text-center">Sem dados ainda</p>
        ) : (
          <>
            {top5.map((item, i) => {
              const value = item.count ?? item.score ?? 0;
              const isMe = item.seller_id === mySellerId;
              return (
                <div
                  key={item.seller_id}
                  className={`flex items-center gap-2 py-1.5 px-2 rounded-md text-sm ${
                    isMe ? 'bg-primary/10 border border-primary/20' : ''
                  }`}
                >
                  <span className={`font-bold w-5 text-center ${podiumColors[i] || 'text-muted-foreground'}`}>
                    {i < 3 ? <Trophy size={14} /> : `${i + 1}º`}
                  </span>
                  <span className="flex-1 truncate font-medium">{item.name}</span>
                  <Badge variant="secondary" className="text-xs">
                    {value} {valueLabel}
                  </Badge>
                </div>
              );
            })}

            {showMyPosition && (
              <>
                <div className="text-center text-muted-foreground/40 text-xs">• • •</div>
                <div className="flex items-center gap-2 py-1.5 px-2 rounded-md text-sm bg-primary/10 border border-primary/20">
                  <span className="font-bold w-5 text-center text-muted-foreground">{myPosition}º</span>
                  <span className="flex-1 truncate font-medium">{myItem.name}</span>
                  <Badge variant="secondary" className="text-xs">
                    {myItem.count ?? myItem.score ?? 0} {valueLabel}
                  </Badge>
                </div>
              </>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );
}

export function RankingsTab() {
  const { coinsRanking, punctualityRanking, medalsRanking, loading, sellerId } = useRankingsData();

  if (loading) {
    return (
      <div className="grid gap-4 md:grid-cols-3">
        {Array.from({ length: 3 }).map((_, i) => (
          <Skeleton key={i} className="h-64 rounded-lg" />
        ))}
      </div>
    );
  }

  return (
    <div className="grid gap-4 md:grid-cols-3">
      <RankingCard
        title="Reconhecimento (7 dias)"
        icon={Coins}
        items={coinsRanking}
        valueLabel="coins"
        mySellerId={sellerId}
      />
      <RankingCard
        title="Pontualidade (30 dias)"
        icon={Clock}
        items={punctualityRanking}
        valueLabel="tarefas"
        mySellerId={sellerId}
      />
      <RankingCard
        title="Medalhas (60 dias)"
        icon={Award}
        items={medalsRanking}
        valueLabel="pts"
        mySellerId={sellerId}
      />
    </div>
  );
}
