import { useEffect, useRef } from 'react';
import { useLocation } from 'react-router-dom';
import { usePermissions } from '@/hooks/usePermissions';
import { Loader2, ShieldAlert } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface PermissionGuardProps {
  children: React.ReactNode;
  resourceKey?: string;
  action?: 'view' | 'create' | 'edit' | 'delete' | 'export';
  fallback?: React.ReactNode;
}

export function PermissionGuard({
  children,
  resourceKey,
  action = 'view',
  fallback,
}: PermissionGuardProps) {
  const { hasPermission, loading, canAccessRoute, error, refetch } = usePermissions();
  const location = useLocation();

  const hasBootstrappedRef = useRef(false);

  useEffect(() => {
    if (!loading && !hasBootstrappedRef.current) {
      hasBootstrappedRef.current = true;
    }
  }, [loading]);

  // Mostrar erro se permissões falharem
  if (error) {
    return (
      <div className="min-h-[50vh] flex flex-col items-center justify-center gap-4">
        <div className="p-4 rounded-full bg-destructive/10">
          <ShieldAlert className="h-12 w-12 text-destructive" />
        </div>
        <div className="text-center">
          <h2 className="text-xl font-semibold text-foreground mb-2">Erro ao carregar permissões</h2>
          <p className="text-muted-foreground mb-4">
            Não foi possível verificar suas permissões. Tente novamente.
          </p>
          <div className="flex gap-2 justify-center">
            <Button variant="outline" onClick={() => refetch()}>
              Tentar novamente
            </Button>
            <Button variant="ghost" onClick={() => (window.location.href = '/auth')}>
              Sair
            </Button>
          </div>
        </div>
      </div>
    );
  }

  // Só mostrar spinner no bootstrap inicial
  if (loading && !hasBootstrappedRef.current) {
    return (
      <div className="min-h-[50vh] flex items-center justify-center">
        <Loader2 className="animate-spin h-8 w-8 text-primary" />
      </div>
    );
  }

  // APÓS bootstrap: manter filhos SEMPRE montados
  // Se loading durante refetch, mostrar indicador sutil sem desmontar

  // Se passou resourceKey específico, verifica permissão do recurso
  if (resourceKey) {
    if (!hasPermission(resourceKey, action)) {
      if (fallback) return <>{fallback}</>;

      return (
        <div className="min-h-[50vh] flex flex-col items-center justify-center gap-4">
          <div className="p-4 rounded-full bg-destructive/10">
            <ShieldAlert className="h-12 w-12 text-destructive" />
          </div>
          <div className="text-center">
            <h2 className="text-xl font-semibold text-foreground mb-2">Acesso Negado</h2>
            <p className="text-muted-foreground mb-4">
              Você não tem permissão para acessar este recurso.
            </p>
            <Button variant="outline" onClick={() => window.history.back()}>
              Voltar
            </Button>
          </div>
        </div>
      );
    }
    return <>{children}</>;
  }

  // Verifica permissão da rota atual
  if (!canAccessRoute(location.pathname)) {
    if (fallback) return <>{fallback}</>;

    return (
      <div className="min-h-[50vh] flex flex-col items-center justify-center gap-4">
        <div className="p-4 rounded-full bg-destructive/10">
          <ShieldAlert className="h-12 w-12 text-destructive" />
        </div>
        <div className="text-center">
          <h2 className="text-xl font-semibold text-foreground mb-2">Acesso Negado</h2>
          <p className="text-muted-foreground mb-4">
            Você não tem permissão para acessar esta página.
          </p>
          <Button variant="outline" onClick={() => window.history.back()}>
            Voltar
          </Button>
        </div>
      </div>
    );
  }

  return <>{children}</>;
}


// Hook para usar em componentes que precisam verificar permissões
export function usePermissionCheck() {
  const { hasPermission, canAccessRoute, canAccessEvolutionTab, canAccessSettingsTab, canSeeAll, canSeeTeam, getScope, loading, isVendedor, hasFullAccess } = usePermissions();

  return {
    can: hasPermission,
    canRoute: canAccessRoute,
    canEvolutionTab: canAccessEvolutionTab,
    canSettingsTab: canAccessSettingsTab,
    canSeeAll,
    canSeeTeam,
    getScope,
    loading,
    isVendedor,
    hasFullAccess,
  };
}
