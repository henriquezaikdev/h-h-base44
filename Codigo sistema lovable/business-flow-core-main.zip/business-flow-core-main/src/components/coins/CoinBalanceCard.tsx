import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Coins, TrendingUp } from 'lucide-react';

interface CoinBalanceCardProps {
  balance: number;
  coins7d: number;
  coins30d: number;
  compact?: boolean;
}

export function CoinBalanceCard({ balance, coins7d, coins30d, compact }: CoinBalanceCardProps) {
  if (compact) {
    return (
      <div className="flex items-center gap-3 p-3 rounded-lg bg-amber-500/5 border border-amber-500/20">
        <div className="w-9 h-9 rounded-lg bg-amber-500/10 flex items-center justify-center">
          <Coins className="h-4 w-4 text-amber-500" />
        </div>
        <div className="flex-1">
          <p className="text-sm font-semibold text-foreground">{balance} H-Coins</p>
          <p className="text-xs text-muted-foreground">+{coins7d} últimos 7d</p>
        </div>
      </div>
    );
  }

  return (
    <Card className="border-amber-500/20 bg-amber-500/5">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm flex items-center gap-2">
          <Coins className="h-4 w-4 text-amber-500" />
          H-Coins
        </CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-3xl font-bold text-foreground">{balance}</p>
        <div className="flex gap-3 mt-2">
          <div className="flex items-center gap-1 text-xs text-muted-foreground">
            <TrendingUp className="h-3 w-3 text-emerald-500" />
            +{coins7d} <span className="text-muted-foreground/60">7d</span>
          </div>
          <div className="flex items-center gap-1 text-xs text-muted-foreground">
            <TrendingUp className="h-3 w-3 text-blue-500" />
            +{coins30d} <span className="text-muted-foreground/60">30d</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
