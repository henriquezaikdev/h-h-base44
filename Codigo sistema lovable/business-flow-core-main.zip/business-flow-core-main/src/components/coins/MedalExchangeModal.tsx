import { useState, useMemo } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { ArrowRightLeft, Coins, Minus, Plus } from 'lucide-react';

interface Medal {
  id: string;
  code: string;
  name: string;
  tier: 'BRONZE' | 'PRATA' | 'OURO';
  description: string;
}

interface UserMedal {
  id: string;
  medal_id: string;
  earned_at: string;
  context_json: any;
  medal: Medal;
}

const TIER_CONFIG = {
  BRONZE: { emoji: '🥉', hcoinsPerPair: 1, label: 'Bronze' },
  PRATA: { emoji: '🥈', hcoinsPerPair: 5, label: 'Prata' },
  OURO: { emoji: '🥇', hcoinsPerPair: 25, label: 'Ouro' },
};

interface MedalExchangeModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  medals: UserMedal[];
  userId: string;
  onExchangeComplete: () => void;
}

interface MedalGroup {
  medalId: string;
  medal: Medal;
  count: number;
}

export function MedalExchangeModal({ open, onOpenChange, medals, userId, onExchangeComplete }: MedalExchangeModalProps) {
  const [exchanging, setExchanging] = useState(false);
  const [quantities, setQuantities] = useState<Record<string, number>>({});

  const groups = useMemo(() => {
    const map = new Map<string, MedalGroup>();
    for (const um of medals) {
      const existing = map.get(um.medal_id);
      if (existing) {
        existing.count++;
      } else {
        map.set(um.medal_id, { medalId: um.medal_id, medal: um.medal, count: 1 });
      }
    }
    return Array.from(map.values()).filter(g => g.count >= 2);
  }, [medals]);

  const totalHcoins = useMemo(() => {
    let total = 0;
    for (const g of groups) {
      const qty = quantities[g.medalId] || 0;
      const tier = TIER_CONFIG[g.medal.tier];
      total += (qty / 2) * tier.hcoinsPerPair;
    }
    return total;
  }, [quantities, groups]);

  const setQty = (medalId: string, maxPairs: number, delta: number) => {
    setQuantities(prev => {
      const current = prev[medalId] || 0;
      const next = Math.max(0, Math.min(maxPairs * 2, current + delta * 2));
      return { ...prev, [medalId]: next };
    });
  };

  const handleExchange = async () => {
    const entries = Object.entries(quantities).filter(([, qty]) => qty >= 2);
    if (entries.length === 0) return;

    setExchanging(true);
    try {
      for (const [medalId, qty] of entries) {
        const { data, error } = await supabase.rpc('fn_exchange_medals', {
          p_user_id: userId,
          p_medal_id: medalId,
          p_quantity: qty,
        });
        if (error) throw error;
        const result = data as any;
        if (!result.ok) throw new Error(result.error);
      }
      toast.success(`Troca realizada! +${totalHcoins} H-Coins`);
      setQuantities({});
      onExchangeComplete();
      onOpenChange(false);
    } catch (err: any) {
      toast.error(err.message || 'Erro ao trocar medalhas');
    } finally {
      setExchanging(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ArrowRightLeft className="h-5 w-5" /> Trocar Medalhas por H-Coins
          </DialogTitle>
        </DialogHeader>

        <div className="text-xs text-muted-foreground mb-3">
          Troque suas medalhas em pares (2 em 2) por H-Coins:
          <span className="block mt-1">🥉 2 Bronze = 1 · 🥈 2 Prata = 5 · 🥇 2 Ouro = 25</span>
        </div>

        {groups.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-6">
            Você precisa de pelo menos 2 medalhas do mesmo tipo para trocar.
          </p>
        ) : (
          <div className="space-y-3">
            {groups.map(g => {
              const tier = TIER_CONFIG[g.medal.tier];
              const maxPairs = Math.floor(g.count / 2);
              const qty = quantities[g.medalId] || 0;
              const hcoinsPreview = (qty / 2) * tier.hcoinsPerPair;

              return (
                <div key={g.medalId} className="flex items-center gap-3 p-3 rounded-lg border bg-muted/30">
                  <span className="text-2xl">{tier.emoji}</span>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{g.medal.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {g.count} disponíveis · {maxPairs} par{maxPairs > 1 ? 'es' : ''}
                    </p>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Button
                      variant="outline"
                      size="icon"
                      className="h-7 w-7"
                      onClick={() => setQty(g.medalId, maxPairs, -1)}
                      disabled={qty === 0}
                    >
                      <Minus className="h-3 w-3" />
                    </Button>
                    <span className="text-sm font-bold w-6 text-center">{qty}</span>
                    <Button
                      variant="outline"
                      size="icon"
                      className="h-7 w-7"
                      onClick={() => setQty(g.medalId, maxPairs, 1)}
                      disabled={qty >= maxPairs * 2}
                    >
                      <Plus className="h-3 w-3" />
                    </Button>
                  </div>
                  {hcoinsPreview > 0 && (
                    <Badge variant="secondary" className="text-xs gap-1 shrink-0">
                      <Coins className="h-3 w-3" /> +{hcoinsPreview}
                    </Badge>
                  )}
                </div>
              );
            })}
          </div>
        )}

        <DialogFooter className="mt-4">
          {totalHcoins > 0 && (
            <div className="flex-1 text-sm font-semibold flex items-center gap-1">
              <Coins className="h-4 w-4 text-amber-500" /> Total: +{totalHcoins} H-Coins
            </div>
          )}
          <Button
            onClick={handleExchange}
            disabled={totalHcoins === 0 || exchanging}
          >
            {exchanging ? 'Trocando...' : 'Confirmar Troca'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
