import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { useCoinsAndMedals } from '@/hooks/useCoinsAndMedals';
import { CoinBalanceCard } from './CoinBalanceCard';
import { MedalsDisplay } from './MedalsDisplay';
import { TrendingUp, Target, AlertTriangle, CheckCircle2 } from 'lucide-react';

interface ProgressCardProps {
  variant: 'financeiro' | 'logistica';
}

export function ProgressCard({ variant }: ProgressCardProps) {
  const { seller } = useAuth();
  const { balance, coins7d, coins30d, medals, loading } = useCoinsAndMedals();
  const [stats, setStats] = useState({
    onTime7d: 0,
    total7d: 0,
    onTime30d: 0,
    total30d: 0,
    criticalOpen: 0,
    errors7d: 0,
    errors30d: 0,
  });

  useEffect(() => {
    if (!seller?.id) return;
    fetchStats();
  }, [seller?.id]);

  const fetchStats = async () => {
    if (!seller?.id) return;

    const now = new Date();
    const d7 = new Date(now.getTime() - 7 * 86400000).toISOString();
    const d30 = new Date(now.getTime() - 30 * 86400000).toISOString();
    const todayStr = new Date().toISOString().split('T')[0];

    // Use RPC or direct queries with type casting to avoid deep type issues
    const queryTasks = async (since: string) => {
      const { data } = await supabase.rpc('fn_evaluate_medals_for_user', { p_seller_id: seller.id }) as any;
      return data;
    };

    // Simplified: query completed tasks directly
    const { data: t7 } = await supabase
      .from('tasks' as any)
      .select('completed_at, task_date, created_at')
      .eq('created_by_seller_id', seller.id)
      .eq('status', 'concluida')
      .gte('completed_at', d7);

    const tasks7dArr = (t7 || []) as any[];
    const valid7d = tasks7dArr.filter((t: any) => {
      const diff = new Date(t.completed_at).getTime() - new Date(t.created_at).getTime();
      return diff >= 180000;
    });
    const onTime7d = valid7d.filter((t: any) => t.completed_at <= t.task_date + 'T23:59:59').length;

    const { data: t30 } = await supabase
      .from('tasks' as any)
      .select('completed_at, task_date, created_at')
      .eq('created_by_seller_id', seller.id)
      .eq('status', 'concluida')
      .gte('completed_at', d30);

    const tasks30dArr = (t30 || []) as any[];
    const valid30d = tasks30dArr.filter((t: any) => {
      const diff = new Date(t.completed_at).getTime() - new Date(t.created_at).getTime();
      return diff >= 180000;
    });
    const onTime30d = valid30d.filter((t: any) => t.completed_at <= t.task_date + 'T23:59:59').length;

    // Critical open
    const { count: criticalOpen } = await supabase
      .from('tasks' as any)
      .select('id', { count: 'exact', head: true })
      .eq('created_by_seller_id', seller.id)
      .eq('priority', 'critica')
      .in('status', ['pendente', 'em_andamento'])
      .lt('task_date', todayStr);

    // Operational errors
    const { count: errors7d } = await supabase
      .from('tasks' as any)
      .select('id', { count: 'exact', head: true })
      .eq('created_by_seller_id', seller.id)
      .eq('operational_error', true)
      .gte('completed_at', d7);

    const { count: errors30d } = await supabase
      .from('tasks' as any)
      .select('id', { count: 'exact', head: true })
      .eq('created_by_seller_id', seller.id)
      .eq('operational_error', true)
      .gte('completed_at', d30);

    setStats({
      onTime7d,
      total7d: valid7d.length,
      onTime30d,
      total30d: valid30d.length,
      criticalOpen: criticalOpen || 0,
      errors7d: errors7d || 0,
      errors30d: errors30d || 0,
    });
  };

  const pct7d = stats.total7d > 0 ? Math.round((stats.onTime7d / stats.total7d) * 100) : 0;
  const pct30d = stats.total30d > 0 ? Math.round((stats.onTime30d / stats.total30d) * 100) : 0;

  const title = variant === 'financeiro' ? 'Seu Progresso' : 'Qualidade Operacional';
  const Icon = variant === 'financeiro' ? Target : CheckCircle2;

  return (
    <Card className="border-primary/20">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm flex items-center gap-2">
          <Icon className="h-4 w-4 text-primary" />
          {title}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Performance metrics */}
        <div className="grid grid-cols-2 gap-3">
          <div className="p-3 rounded-lg bg-muted/30 border border-border/30">
            <p className="text-xs text-muted-foreground">No prazo (7d)</p>
            <p className="text-xl font-bold text-foreground">{pct7d}%</p>
            <p className="text-[10px] text-muted-foreground">{stats.onTime7d}/{stats.total7d}</p>
          </div>
          <div className="p-3 rounded-lg bg-muted/30 border border-border/30">
            <p className="text-xs text-muted-foreground">No prazo (30d)</p>
            <p className="text-xl font-bold text-foreground">{pct30d}%</p>
            <p className="text-[10px] text-muted-foreground">{stats.onTime30d}/{stats.total30d}</p>
          </div>
        </div>

        {/* Role-specific metrics */}
        {variant === 'financeiro' && stats.criticalOpen > 0 && (
          <div className="flex items-center gap-2 p-2 rounded-lg bg-destructive/5 border border-destructive/20">
            <AlertTriangle className="h-4 w-4 text-destructive" />
            <span className="text-xs text-destructive font-medium">
              {stats.criticalOpen} tarefa(s) crítica(s) vencida(s)
            </span>
          </div>
        )}

        {variant === 'logistica' && (
          <div className="grid grid-cols-2 gap-3">
            <div className="p-2 rounded-lg bg-muted/30 border border-border/30">
              <p className="text-xs text-muted-foreground">Erros (7d)</p>
              <p className={`text-lg font-bold ${stats.errors7d === 0 ? 'text-emerald-600' : 'text-destructive'}`}>
                {stats.errors7d}
              </p>
            </div>
            <div className="p-2 rounded-lg bg-muted/30 border border-border/30">
              <p className="text-xs text-muted-foreground">Erros (30d)</p>
              <p className={`text-lg font-bold ${stats.errors30d === 0 ? 'text-emerald-600' : 'text-destructive'}`}>
                {stats.errors30d}
              </p>
            </div>
          </div>
        )}

        {/* Coins */}
        <CoinBalanceCard balance={balance} coins7d={coins7d} coins30d={coins30d} compact />

        {/* Medals */}
        <MedalsDisplay medals={medals} compact maxShow={3} />
      </CardContent>
    </Card>
  );
}
