import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { toast } from 'sonner';
import { Coins, Loader2 } from 'lucide-react';

const REASONS = [
  { value: 'AJUDA', label: '🤝 Ajuda' },
  { value: 'AGILIDADE', label: '⚡ Agilidade' },
  { value: 'ORGANIZACAO', label: '📋 Organização' },
  { value: 'RESPONSABILIDADE', label: '🎯 Responsabilidade' },
  { value: 'ATENDIMENTO', label: '💬 Atendimento' },
  { value: 'OUTRO', label: '✨ Outro' },
];

interface GiveCoinModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  recipientId: string;
  recipientName: string;
  onSuccess?: () => void;
}

export function GiveCoinModal({ open, onOpenChange, recipientId, recipientName, onSuccess }: GiveCoinModalProps) {
  const { seller } = useAuth();
  const [reason, setReason] = useState('');
  const [note, setNote] = useState('');
  const [sending, setSending] = useState(false);

  const handleSend = async () => {
    if (!reason) {
      toast.error('Selecione um motivo');
      return;
    }
    if (!seller?.id) return;

    setSending(true);
    try {
      const { error } = await supabase.from('coin_transactions').insert({
        from_user_id: seller.id,
        to_user_id: recipientId,
        amount: 1,
        reason,
        note: note.trim() || null,
        day_key: new Date().toISOString().split('T')[0],
      });

      if (error) {
        if (error.message.includes('COIN_LIMIT')) {
          const msg = error.message.split('COIN_LIMIT: ')[1] || 'Limite de moedas atingido';
          toast.error(msg);
        } else if (error.message.includes('no_self_coin')) {
          toast.error('Você não pode dar H-Coin para si mesmo');
        } else {
          toast.error('Erro ao enviar H-Coin');
        }
        return;
      }

      toast.success(`H-Coin enviada para ${recipientName}!`);
      setReason('');
      setNote('');
      onOpenChange(false);
      onSuccess?.();
    } catch (err) {
      toast.error('Erro inesperado');
    } finally {
      setSending(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Coins className="h-5 w-5 text-amber-500" />
            Dar H-Coin para {recipientName}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-2">
          <div className="space-y-2">
            <Label>Motivo *</Label>
            <Select value={reason} onValueChange={setReason}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione o motivo" />
              </SelectTrigger>
              <SelectContent>
                {REASONS.map(r => (
                  <SelectItem key={r.value} value={r.value}>{r.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Nota (opcional)</Label>
            <Textarea
              placeholder="Obrigado por ajudar com..."
              value={note}
              onChange={e => setNote(e.target.value.slice(0, 120))}
              maxLength={120}
              rows={2}
            />
            <p className="text-xs text-muted-foreground text-right">{note.length}/120</p>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
          <Button onClick={handleSend} disabled={sending || !reason} className="bg-amber-500 hover:bg-amber-600 text-white">
            {sending ? <Loader2 className="animate-spin h-4 w-4 mr-1" /> : <Coins className="h-4 w-4 mr-1" />}
            Enviar H-Coin
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
