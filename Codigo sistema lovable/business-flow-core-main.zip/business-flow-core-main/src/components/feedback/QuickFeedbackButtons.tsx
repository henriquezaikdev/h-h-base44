import { useState } from 'react';
import { FEEDBACK_OPTIONS, ResultadoAcao, OrigemAcao, useFeedbackAcaoComercial } from '@/hooks/useFeedbackAcaoComercial';
import { cn } from '@/lib/utils';
import { Check, Loader2 } from 'lucide-react';

interface Props {
  clientId: string;
  origem: OrigemAcao;
  onDone?: () => void;
  compact?: boolean;
}

export function QuickFeedbackButtons({ clientId, origem, onDone, compact = false }: Props) {
  const { registrarFeedback, saving } = useFeedbackAcaoComercial();
  const [selected, setSelected] = useState<ResultadoAcao | null>(null);

  const handleSelect = async (resultado: ResultadoAcao) => {
    setSelected(resultado);
    await registrarFeedback({ clientId, resultado, origemAcao: origem });
    onDone?.();
  };

  if (selected) {
    const opt = FEEDBACK_OPTIONS.find(o => o.value === selected);
    return (
      <div className="flex items-center gap-1.5 text-[10px] text-primary font-medium">
        <Check className="h-3 w-3" />
        <span>{opt?.emoji} {opt?.label}</span>
      </div>
    );
  }

  if (compact) {
    return (
      <div className="flex flex-wrap gap-1">
        {FEEDBACK_OPTIONS.slice(0, 6).map(opt => (
          <button
            key={opt.value}
            disabled={saving}
            onClick={(e) => { e.stopPropagation(); handleSelect(opt.value); }}
            className={cn(
              "px-1.5 py-0.5 rounded-full text-[9px] font-medium transition-colors",
              opt.positive
                ? "bg-primary/10 text-primary hover:bg-primary/20"
                : "bg-muted text-muted-foreground hover:bg-muted/80"
            )}
          >
            {opt.emoji} {opt.label}
          </button>
        ))}
        {saving && <Loader2 className="h-3 w-3 animate-spin text-muted-foreground" />}
      </div>
    );
  }

  return (
    <div className="flex flex-wrap gap-1.5">
      {FEEDBACK_OPTIONS.map(opt => (
        <button
          key={opt.value}
          disabled={saving}
          onClick={(e) => { e.stopPropagation(); handleSelect(opt.value); }}
          className={cn(
            "px-2 py-1 rounded-lg text-[10px] font-medium transition-colors border",
            opt.positive
              ? "border-primary/20 bg-primary/5 text-primary hover:bg-primary/10"
              : "border-border/40 bg-muted/40 text-muted-foreground hover:bg-muted"
          )}
        >
          {opt.emoji} {opt.label}
        </button>
      ))}
      {saving && <Loader2 className="h-3.5 w-3.5 animate-spin text-muted-foreground" />}
    </div>
  );
}
