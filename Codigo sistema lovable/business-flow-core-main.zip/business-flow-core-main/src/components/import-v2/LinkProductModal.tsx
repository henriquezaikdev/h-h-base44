import { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { Search, Loader2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { StagingItem } from "./types";

interface Product {
  id: string;
  name: string;
  sku: string | null;
  cost_price: number | null;
  external_code_contaazul: string | null;
  codigo_conta_azul?: string | null;
}

interface LinkProductModalProps {
  item: StagingItem;
  onClose: () => void;
  onLink: (productId: string) => void;
}

export function LinkProductModal({ item, onClose, onLink }: LinkProductModalProps) {
  const [search, setSearch] = useState(item.extracted_external_code || item.extracted_description);
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  const suggestions = item.match_suggestions || [];

  useEffect(() => {
    searchProducts(search);
  }, []);

  const searchProducts = async (query: string) => {
    if (!query.trim()) {
      setProducts([]);
      return;
    }

    setIsLoading(true);
    try {
      const { data } = await supabase
        .from('products')
        .select('id, name, sku, cost_price, external_code_contaazul, codigo_conta_azul')
        .or(`name.ilike.%${query}%,sku.ilike.%${query}%,codigo_conta_azul.ilike.%${query}%,external_code_contaazul.ilike.%${query}%`)
        .eq('active', true)
        .limit(20);

      setProducts(data || []);
    } catch (error) {
      console.error('Erro ao buscar produtos:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSearch = () => {
    searchProducts(search);
  };

  const handleConfirm = () => {
    if (selectedProduct) {
      onLink(selectedProduct.id);
    }
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Vincular Produto</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="bg-muted p-3 rounded-md">
            <p className="text-sm text-muted-foreground">Item do PDF:</p>
            <div className="flex items-center gap-2 mt-1">
              {item.extracted_external_code && (
                <Badge variant="outline" className="font-mono">
                  {item.extracted_external_code}
                </Badge>
              )}
              <p className="font-medium">{item.extracted_description}</p>
            </div>
          </div>

          {suggestions.length > 0 && !search && (
            <div className="space-y-2">
              <Label className="text-sm text-muted-foreground">Sugestões por similaridade:</Label>
              <div className="space-y-1 border rounded-md p-2">
                {suggestions.slice(0, 5).map((sug) => (
                  <div
                    key={sug.productId}
                    onClick={() => setSelectedProduct({
                      id: sug.productId,
                      name: sug.name,
                      sku: sug.sku,
                      cost_price: sug.cost_price,
                      external_code_contaazul: sug.external_code
                    })}
                    className={`p-2 rounded cursor-pointer transition-colors ${
                      selectedProduct?.id === sug.productId 
                        ? 'bg-primary/10 border border-primary' 
                        : 'hover:bg-muted'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-medium">{sug.name}</span>
                      <Badge variant="outline" className="text-xs">
                        {sug.score}% similar
                      </Badge>
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {sug.external_code && <span className="font-mono mr-2">{sug.external_code}</span>}
                      Custo: {sug.cost_price 
                        ? `R$ ${sug.cost_price.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}` 
                        : 'Não definido'}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="flex gap-2">
            <div className="flex-1">
              <Label htmlFor="search">Buscar produto</Label>
              <Input
                id="search"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                placeholder="Nome, SKU ou código..."
              />
            </div>
            <Button 
              onClick={handleSearch} 
              className="mt-6"
              disabled={isLoading}
            >
              {isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
            </Button>
          </div>

          <ScrollArea className="h-48 border rounded-md">
            {products.length === 0 ? (
              <div className="p-4 text-center text-muted-foreground">
                {isLoading ? 'Buscando...' : 'Nenhum produto encontrado'}
              </div>
            ) : (
              <div className="divide-y">
                {products.map((product) => (
                  <div
                    key={product.id}
                    onClick={() => setSelectedProduct(product)}
                    className={`p-3 cursor-pointer hover:bg-muted transition-colors ${
                      selectedProduct?.id === product.id ? 'bg-primary/10 border-l-4 border-primary' : ''
                    }`}
                  >
                    <p className="font-medium">{product.name}</p>
                    <div className="flex gap-4 text-sm text-muted-foreground">
                      {product.codigo_conta_azul && (
                        <span className="font-mono">CA: {product.codigo_conta_azul}</span>
                      )}
                      {product.external_code_contaazul && (
                        <span className="font-mono">Legado: {product.external_code_contaazul}</span>
                      )}
                      {product.sku && <span>SKU: {product.sku}</span>}
                      <span>
                        Custo: {product.cost_price 
                          ? `R$ ${product.cost_price.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`
                          : 'Não definido'
                        }
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancelar
          </Button>
          <Button onClick={handleConfirm} disabled={!selectedProduct}>
            Vincular Produto
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
