import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AlertCircle, CheckCircle, Link, DollarSign } from "lucide-react";

interface OrderItemV2 {
  id: string;
  order_id: string;
  product_id: string | null;
  description_pdf: string;
  sku_pdf: string | null;
  quantity: number;
  unit_price: number;
  cost_price: number | null;
  missing_product: boolean;
  missing_cost: boolean;
  line_total: number;
  product?: {
    id: string;
    name: string;
    sku: string | null;
    cost_price: number | null;
  } | null;
}

interface OrderV2ReviewTableProps {
  items: OrderItemV2[];
  onLinkProduct: (item: OrderItemV2) => void;
  onSetCost: (item: OrderItemV2) => void;
}

export function OrderV2ReviewTable({ items, onLinkProduct, onSetCost }: OrderV2ReviewTableProps) {
  if (items.length === 0) {
    return (
      <div className="text-center py-8 text-muted-foreground">
        Nenhum item encontrado no pedido
      </div>
    );
  }

  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-12">Status</TableHead>
            <TableHead>Descrição PDF</TableHead>
            <TableHead>SKU PDF</TableHead>
            <TableHead>Produto Vinculado</TableHead>
            <TableHead className="text-right">Qtd</TableHead>
            <TableHead className="text-right">Preço Unit.</TableHead>
            <TableHead className="text-right">Custo Unit.</TableHead>
            <TableHead className="text-right">Total</TableHead>
            <TableHead className="w-32">Ações</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {items.map((item) => {
            const hasIssue = item.missing_product || item.missing_cost;
            
            return (
              <TableRow 
                key={item.id}
                className={hasIssue ? "bg-destructive/10" : ""}
              >
                <TableCell>
                  {hasIssue ? (
                    <AlertCircle className="h-5 w-5 text-destructive" />
                  ) : (
                    <CheckCircle className="h-5 w-5 text-green-600" />
                  )}
                </TableCell>
                <TableCell className="max-w-48 truncate" title={item.description_pdf}>
                  {item.description_pdf}
                </TableCell>
                <TableCell>
                  {item.sku_pdf || <span className="text-muted-foreground">—</span>}
                </TableCell>
                <TableCell>
                  {item.product ? (
                    <div>
                      <span className="font-medium">{item.product.name}</span>
                      {item.product.sku && (
                        <span className="text-muted-foreground text-xs ml-2">
                          ({item.product.sku})
                        </span>
                      )}
                    </div>
                  ) : (
                    <Badge variant="destructive">Não vinculado</Badge>
                  )}
                </TableCell>
                <TableCell className="text-right">{item.quantity}</TableCell>
                <TableCell className="text-right">
                  R$ {item.unit_price.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                </TableCell>
                <TableCell className="text-right">
                  {item.cost_price ? (
                    `R$ ${item.cost_price.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`
                  ) : (
                    <Badge variant="destructive">Sem custo</Badge>
                  )}
                </TableCell>
                <TableCell className="text-right font-medium">
                  R$ {item.line_total.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                </TableCell>
                <TableCell>
                  <div className="flex gap-1">
                    {item.missing_product && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => onLinkProduct(item)}
                        title="Vincular produto"
                      >
                        <Link className="h-4 w-4" />
                      </Button>
                    )}
                    {item.missing_cost && item.product && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => onSetCost(item)}
                        title="Definir custo"
                      >
                        <DollarSign className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                </TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    </div>
  );
}
