import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AlertCircle, CheckCircle, Link, DollarSign, Plus, AlertTriangle } from "lucide-react";
import { StagingItem } from "./types";

interface StagingItemsTableProps {
  items: StagingItem[];
  onLinkProduct: (item: StagingItem) => void;
  onCreateProduct: (item: StagingItem) => void;
  onSetCost: (item: StagingItem) => void;
}

export function StagingItemsTable({ items, onLinkProduct, onCreateProduct, onSetCost }: StagingItemsTableProps) {
  if (items.length === 0) {
    return (
      <div className="text-center py-8 text-muted-foreground">
        Nenhum item encontrado
      </div>
    );
  }

  const getStatusIcon = (item: StagingItem) => {
    if (item.status === 'PENDENTE') {
      return <AlertCircle className="h-5 w-5 text-destructive" />;
    }
    if (item.product && (!item.product.cost_price || item.product.cost_price <= 0)) {
      return <AlertTriangle className="h-5 w-5 text-amber-500" />;
    }
    return <CheckCircle className="h-5 w-5 text-green-600" />;
  };

  const getMatchMethodBadge = (method: string | null) => {
    if (!method) return null;

    const variants: Record<string, { label: string; className: string }> = {
      'CODIGO_CONTA_AZUL': { label: 'Código CA', className: 'bg-green-100 text-green-800' },
      'EXTERNAL_CODE': { label: 'Código (legado)', className: 'bg-green-100 text-green-800' },
      'SKU': { label: 'SKU', className: 'bg-green-100 text-green-800' },
      'ALIAS': { label: 'Alias', className: 'bg-blue-100 text-blue-800' },
      'SIMILARITY': { label: 'Similaridade', className: 'bg-amber-100 text-amber-800' },
      'MANUAL': { label: 'Manual', className: 'bg-purple-100 text-purple-800' },
    };

    const config = variants[method] || { label: method, className: '' };
    return <Badge variant="outline" className={config.className}>{config.label}</Badge>;
  };

  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-12">Status</TableHead>
            <TableHead className="w-32">Código CA</TableHead>
            <TableHead>Descrição PDF</TableHead>
            <TableHead>Produto Vinculado</TableHead>
            <TableHead className="text-right">Qtd</TableHead>
            <TableHead className="text-right">Preço Unit.</TableHead>
            <TableHead className="text-right">Custo Unit.</TableHead>
            <TableHead className="text-right">Margem</TableHead>
            <TableHead className="w-40">Ações</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {items.map((item) => {
            const isPending = item.status === 'PENDENTE';
            const hasCostIssue = item.product && (!item.product.cost_price || item.product.cost_price <= 0);
            const hasIssue = isPending || hasCostIssue;
            
            const margin = item.product?.cost_price && item.unit_price > 0
              ? ((item.unit_price - item.product.cost_price) / item.unit_price) * 100
              : null;

            return (
              <TableRow 
                key={item.id}
                className={hasIssue ? "bg-destructive/5" : ""}
              >
                <TableCell>
                  {getStatusIcon(item)}
                </TableCell>
                <TableCell>
                  {item.extracted_external_code ? (
                    <Badge variant="outline" className="font-mono">
                      {item.extracted_external_code}
                    </Badge>
                  ) : (
                    <span className="text-muted-foreground">—</span>
                  )}
                </TableCell>
                <TableCell className="max-w-48">
                  <div className="truncate" title={item.extracted_description}>
                    {item.extracted_description}
                  </div>
                  {item.match_suggestions.length > 0 && isPending && (
                    <div className="text-xs text-muted-foreground mt-1">
                      {item.match_suggestions.length} sugestão(ões)
                    </div>
                  )}
                </TableCell>
                <TableCell>
                  {item.product ? (
                    <div className="space-y-1">
                      <div className="font-medium truncate max-w-40" title={item.product.name}>
                        {item.product.name}
                      </div>
                      <div className="flex gap-1">
                        {getMatchMethodBadge(item.match_method)}
                        {item.product.external_code_contaazul && (
                          <Badge variant="outline" className="text-xs font-mono">
                            {item.product.external_code_contaazul}
                          </Badge>
                        )}
                      </div>
                    </div>
                  ) : (
                    <Badge variant="destructive">Não vinculado</Badge>
                  )}
                </TableCell>
                <TableCell className="text-right">{item.quantity}</TableCell>
                <TableCell className="text-right">
                  R$ {item.unit_price.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                </TableCell>
                <TableCell className="text-right">
                  {item.product?.cost_price ? (
                    `R$ ${item.product.cost_price.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`
                  ) : (
                    <Badge variant="destructive">Sem custo</Badge>
                  )}
                </TableCell>
                <TableCell className="text-right">
                  {margin !== null ? (
                    <span className={margin >= 0 ? 'text-green-600' : 'text-red-600'}>
                      {margin.toFixed(1)}%
                    </span>
                  ) : (
                    <span className="text-muted-foreground">—</span>
                  )}
                </TableCell>
                <TableCell>
                  <div className="flex gap-1">
                    {/* Botão definir custo - disponível se não tem custo ou para editar */}
                    {item.product && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => onSetCost(item)}
                        title={item.product.cost_price ? "Editar custo" : "Definir custo"}
                        className={hasCostIssue ? "border-amber-500 text-amber-600" : ""}
                      >
                        <DollarSign className="h-4 w-4" />
                      </Button>
                    )}
                    {/* Botão vincular - sempre disponível para trocar/vincular produto */}
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => onLinkProduct(item)}
                      title={item.product ? "Alterar produto vinculado" : "Vincular produto existente"}
                    >
                      <Link className="h-4 w-4" />
                    </Button>
                    {/* Botão criar novo - sempre disponível */}
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => onCreateProduct(item)}
                      title="Criar novo produto"
                    >
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    </div>
  );
}
