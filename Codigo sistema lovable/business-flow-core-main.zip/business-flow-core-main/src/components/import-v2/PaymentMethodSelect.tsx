import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { usePaymentMethods } from '@/hooks/usePaymentMethods';
import { Loader2, FileText, CalendarCheck, Calculator } from 'lucide-react';

interface PaymentMethodSelectProps {
  value: string;
  onChange: (value: string, termDays: number) => void;
  disabled?: boolean;
  required?: boolean;
  pdfValue?: string;  // Valor original extraído do PDF
  // NOVO: Prazo real calculado e sua fonte
  calculatedTermDays?: number;
  termSource?: 'due_date' | 'fallback' | null;
  dueDates?: string[];
}

export function PaymentMethodSelect({ 
  value, 
  onChange, 
  disabled, 
  required, 
  pdfValue,
  calculatedTermDays,
  termSource,
  dueDates
}: PaymentMethodSelectProps) {
  const { methods, loading, getTermDaysFromName } = usePaymentMethods();

  const handleChange = (selectedName: string) => {
    // Se mudar a forma de pagamento e não tem data de vencimento real,
    // recalcular o prazo baseado na nova forma selecionada
    if (termSource === 'due_date') {
      // Manter o prazo calculado pela data real
      onChange(selectedName, calculatedTermDays || 0);
    } else {
      // Usar fallback baseado na nova forma de pagamento
      const termDays = getTermDaysFromName(selectedName);
      onChange(selectedName, termDays);
    }
  };

  if (loading) {
    return (
      <div className="space-y-2">
        <Label>Forma de Pagamento {required && '*'}</Label>
        <div className="flex items-center gap-2 h-10 text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin" />
          <span className="text-sm">Carregando...</span>
        </div>
      </div>
    );
  }

  // Verificar se o valor atual é um valor customizado do PDF (não está na lista cadastrada)
  const isCustomPdfValue = value && !methods.find(m => m.name === value);

  // Determinar prazo a exibir
  const displayTermDays = calculatedTermDays !== undefined ? calculatedTermDays : getTermDaysFromName(value);

  return (
    <div className="space-y-3">
      <Label htmlFor="payment-method">Forma de Pagamento {required && <span className="text-destructive">*</span>}</Label>
      <Select value={value} onValueChange={handleChange} disabled={disabled}>
        <SelectTrigger id="payment-method" className="w-full max-w-xs">
          <SelectValue placeholder="Selecione a forma de pagamento" />
        </SelectTrigger>
        <SelectContent>
          {/* Se há valor customizado do PDF, mostrá-lo como primeira opção */}
          {isCustomPdfValue && (
            <SelectItem key="pdf-custom" value={value}>
              <span className="flex items-center gap-1">
                <FileText className="h-3 w-3" />
                {value}
              </span>
            </SelectItem>
          )}
          {methods.map((method) => (
            <SelectItem key={method.id} value={method.name}>
              {method.name}
              {method.payment_term_days > 0 && (
                <span className="text-muted-foreground ml-2 text-xs">
                  ({method.payment_term_days}d)
                </span>
              )}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
      
      {/* Indicador visual quando valor veio do PDF */}
      {value && pdfValue && isCustomPdfValue && (
        <p className="text-xs text-muted-foreground flex items-center gap-1">
          <FileText className="h-3 w-3" /> Extraído do PDF
        </p>
      )}
      
      {/* PRAZO DE PAGAMENTO CALCULADO - Destaque visual */}
      {value && (
        <div className="rounded-lg border bg-muted/50 p-3 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">Prazo de Pagamento</span>
            <Badge 
              variant={termSource === 'due_date' ? 'default' : 'secondary'}
              className="text-sm font-bold"
            >
              {displayTermDays} dias
            </Badge>
          </div>
          
          {/* Fonte do cálculo */}
          <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
            {termSource === 'due_date' ? (
              <>
                <CalendarCheck className="h-3.5 w-3.5 text-primary" />
                <span className="text-primary font-medium">Calculado via data de vencimento real</span>
              </>
            ) : (
              <>
                <Calculator className="h-3.5 w-3.5" />
                <span>Estimado pela forma de pagamento (sem vencimento no PDF)</span>
              </>
            )}
          </div>
          
          {/* Mostrar datas de vencimento se disponíveis */}
          {dueDates && dueDates.length > 0 && (
            <div className="text-xs text-muted-foreground border-t pt-2 mt-2">
              <span className="font-medium">Vencimento(s) do PDF:</span>{' '}
              {dueDates.join(', ')}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
