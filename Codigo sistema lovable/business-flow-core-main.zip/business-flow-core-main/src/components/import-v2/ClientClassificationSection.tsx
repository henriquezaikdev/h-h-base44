import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { UserPlus, Globe, Store, RotateCcw, CheckCircle2, Info, AlertCircle } from 'lucide-react';
import { cn } from '@/lib/utils';
import { supabase } from '@/integrations/supabase/client';

// Tipos de classificação
export type ClientClassificationType = 
  | 'conquistado'     // Cliente novo conquistado pelo vendedor
  | 'google'          // Cliente que veio via Google Ads/Orgânico
  | 'porta_loja'      // Cliente que veio até a loja
  | 'reativacao'      // Cliente inativo que voltou a comprar
  | 'janela_longa'    // Cliente com janela de compra longa (não conta como reativação)
  | null;             // Não precisa classificar (cliente recorrente)

interface ClientClassificationData {
  needsClassification: boolean;
  classificationType: 'new_client' | 'reactivation' | null;
  isFirstOrder: boolean;
  daysSinceLastOrder: number | null;
  lastOrderDate: string | null;
  existingClientData: {
    id: string;
    companyName: string;
    orderCount: number;
    isFromGoogle: boolean | null;
    origem: string | null;
  } | null;
}

interface ClientClassificationSectionProps {
  clientId: string;
  orderId: string;
  orderDate: string;
  onClassificationChange: (classification: ClientClassificationType) => void;
  onRequirementChange?: (required: boolean) => void;
  selectedClassification: ClientClassificationType;
}

export function ClientClassificationSection({
  clientId,
  orderId,
  orderDate,
  onClassificationChange,
  onRequirementChange,
  selectedClassification
}: ClientClassificationSectionProps) {
  const [classificationData, setClassificationData] = useState<ClientClassificationData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    checkClientStatus();
  }, [clientId, orderId, orderDate]);

  // Comunicar ao pai se classificação é obrigatória
  useEffect(() => {
    if (classificationData && onRequirementChange) {
      onRequirementChange(classificationData.needsClassification);
    }
  }, [classificationData, onRequirementChange]);

  const checkClientStatus = async () => {
    if (!clientId) {
      setLoading(false);
      return;
    }

    try {
      // Buscar dados do cliente
      const { data: client } = await supabase
        .from('clients')
        .select('id, company_name, order_count, is_from_google, origem, last_order_date, first_order_date')
        .eq('id', clientId)
        .single();

      if (!client) {
        setLoading(false);
        return;
      }

      // Buscar quantidade de pedidos existentes para este cliente (excluindo o atual)
      const { data: orders } = await supabase
        .from('orders')
        .select('id, order_date')
        .eq('client_id', clientId)
        .neq('id', orderId)
        .order('order_date', { ascending: false })
        .limit(1);

      const previousOrder = orders?.[0];
      const isFirstOrder = !previousOrder;

      let daysSinceLastOrder: number | null = null;
      let classificationType: 'new_client' | 'reactivation' | null = null;
      let needsClassification = false;

      if (isFirstOrder) {
        // É o primeiro pedido deste cliente - precisa classificar como novo
        needsClassification = true;
        classificationType = 'new_client';
      } else if (previousOrder) {
        // Calcular dias desde o último pedido
        const lastOrderDate = new Date(previousOrder.order_date);
        const currentOrderDate = new Date(orderDate);
        daysSinceLastOrder = Math.floor(
          (currentOrderDate.getTime() - lastOrderDate.getTime()) / (1000 * 60 * 60 * 24)
        );

        // Se > 90 dias, pode ser reativação
        if (daysSinceLastOrder > 90) {
          needsClassification = true;
          classificationType = 'reactivation';
        }
        // Se <= 90 dias, é cliente recorrente normal - não precisa classificar
      }

      setClassificationData({
        needsClassification,
        classificationType,
        isFirstOrder,
        daysSinceLastOrder,
        lastOrderDate: previousOrder?.order_date || null,
        existingClientData: {
          id: client.id,
          companyName: client.company_name,
          orderCount: client.order_count || 0,
          isFromGoogle: client.is_from_google,
          origem: client.origem
        }
      });

    } catch (error) {
      console.error('Erro ao verificar status do cliente:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <Card className="border-amber-500/30 bg-amber-500/5">
        <CardContent className="py-4">
          <div className="flex items-center gap-2 text-muted-foreground">
            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-amber-500"></div>
            <span className="text-sm">Verificando status do cliente...</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Se não precisa classificar (cliente recorrente normal)
  if (!classificationData?.needsClassification) {
    return (
      <Card className="border-green-500/30 bg-green-500/5">
        <CardContent className="py-4">
          <div className="flex items-center gap-2 text-green-700 dark:text-green-400">
            <CheckCircle2 className="h-4 w-4" />
            <span className="text-sm font-medium">
              Cliente recorrente
              {classificationData?.daysSinceLastOrder !== null && (
                <span className="text-muted-foreground font-normal ml-1">
                  (último pedido há {classificationData.daysSinceLastOrder} dias)
                </span>
              )}
            </span>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Precisa classificar - mostrar opções
  const isNewClient = classificationData.classificationType === 'new_client';
  const isReactivation = classificationData.classificationType === 'reactivation';

  return (
    <Card className={cn(
      "border-2",
      !selectedClassification 
        ? "border-amber-500/50 bg-amber-500/5" 
        : "border-green-500/50 bg-green-500/5"
    )}>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-base">
          {isNewClient ? (
            <>
              <UserPlus className="h-5 w-5 text-amber-500" />
              Classificação do Cliente Novo
            </>
          ) : (
            <>
              <RotateCcw className="h-5 w-5 text-amber-500" />
              Possível Reativação de Inativo
            </>
          )}
          {!selectedClassification && (
            <Badge variant="outline" className="ml-auto border-amber-500 text-amber-600">
              <AlertCircle className="h-3 w-3 mr-1" />
              Obrigatório
            </Badge>
          )}
          {selectedClassification && (
            <Badge className="ml-auto bg-green-600">
              <CheckCircle2 className="h-3 w-3 mr-1" />
              Classificado
            </Badge>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Info contextual */}
        <div className="flex items-start gap-2 p-3 rounded-lg bg-muted/50 text-sm">
          <Info className="h-4 w-4 text-muted-foreground shrink-0 mt-0.5" />
          <div className="text-muted-foreground">
            {isNewClient ? (
              <>
                Este é o <strong>primeiro pedido</strong> deste cliente no sistema. 
                Como ele foi conquistado? (Se for cliente antigo voltando, marque Reativação)
              </>
            ) : (
              <>
                Este cliente não compra há <strong>{classificationData.daysSinceLastOrder} dias</strong>
                {classificationData.lastOrderDate && (
                  <> (último pedido em {new Date(classificationData.lastOrderDate).toLocaleDateString('pt-BR')})</>
                )}.
                É uma reativação de cliente inativo?
              </>
            )}
          </div>
        </div>

        {/* Opções de classificação */}
        <RadioGroup
          value={selectedClassification || ''}
          onValueChange={(value) => onClassificationChange(value as ClientClassificationType)}
          className="grid gap-3"
        >
          {isNewClient ? (
            <>
              {/* Opção: Conquistado */}
              <label
                htmlFor="conquistado"
                className={cn(
                  "flex items-center gap-3 p-4 rounded-lg border-2 cursor-pointer transition-all",
                  selectedClassification === 'conquistado'
                    ? "border-primary bg-primary/5"
                    : "border-muted hover:border-primary/50"
                )}
              >
                <RadioGroupItem value="conquistado" id="conquistado" />
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <UserPlus className="h-4 w-4 text-emerald-500" />
                    <span className="font-medium">Cliente Conquistado</span>
                  </div>
                  <p className="text-sm text-muted-foreground mt-0.5">
                    O vendedor prospectou e conquistou este cliente
                  </p>
                </div>
              </label>

              {/* Opção: Google */}
              <label
                htmlFor="google"
                className={cn(
                  "flex items-center gap-3 p-4 rounded-lg border-2 cursor-pointer transition-all",
                  selectedClassification === 'google'
                    ? "border-primary bg-primary/5"
                    : "border-muted hover:border-primary/50"
                )}
              >
                <RadioGroupItem value="google" id="google" />
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <Globe className="h-4 w-4 text-blue-500" />
                    <span className="font-medium">Cliente Google</span>
                  </div>
                  <p className="text-sm text-muted-foreground mt-0.5">
                    Cliente veio via Google Ads ou busca orgânica
                  </p>
                </div>
              </label>

              {/* Opção: Porta de Loja */}
              <label
                htmlFor="porta_loja"
                className={cn(
                  "flex items-center gap-3 p-4 rounded-lg border-2 cursor-pointer transition-all",
                  selectedClassification === 'porta_loja'
                    ? "border-primary bg-primary/5"
                    : "border-muted hover:border-primary/50"
                )}
              >
                <RadioGroupItem value="porta_loja" id="porta_loja" />
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <Store className="h-4 w-4 text-purple-500" />
                    <span className="font-medium">Cliente Porta de Loja</span>
                  </div>
                  <p className="text-sm text-muted-foreground mt-0.5">
                    Cliente veio até a empresa/loja espontaneamente
                  </p>
                </div>
              </label>

              {/* Opção: Reativação de Inativo */}
              <label
                htmlFor="reativacao_new"
                className={cn(
                  "flex items-center gap-3 p-4 rounded-lg border-2 cursor-pointer transition-all",
                  selectedClassification === 'reativacao'
                    ? "border-primary bg-primary/5"
                    : "border-muted hover:border-primary/50"
                )}
              >
                <RadioGroupItem value="reativacao" id="reativacao_new" />
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <RotateCcw className="h-4 w-4 text-orange-500" />
                    <span className="font-medium">Reativação de Inativo</span>
                  </div>
                  <p className="text-sm text-muted-foreground mt-0.5">
                    Cliente antigo/inativo que está voltando a comprar
                  </p>
                </div>
              </label>
            </>
          ) : (
            <>
              {/* Opção: É reativação */}
              <label
                htmlFor="reativacao"
                className={cn(
                  "flex items-center gap-3 p-4 rounded-lg border-2 cursor-pointer transition-all",
                  selectedClassification === 'reativacao'
                    ? "border-primary bg-primary/5"
                    : "border-muted hover:border-primary/50"
                )}
              >
                <RadioGroupItem value="reativacao" id="reativacao" />
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <RotateCcw className="h-4 w-4 text-orange-500" />
                    <span className="font-medium">Sim, é uma Reativação</span>
                  </div>
                  <p className="text-sm text-muted-foreground mt-0.5">
                    O vendedor reconquistou este cliente inativo
                  </p>
                </div>
              </label>

              {/* Opção: Não é reativação (cliente com janela longa) */}
              <label
                htmlFor="janela_longa"
                className={cn(
                  "flex items-center gap-3 p-4 rounded-lg border-2 cursor-pointer transition-all",
                  selectedClassification === 'janela_longa'
                    ? "border-primary bg-primary/5"
                    : "border-muted hover:border-primary/50"
                )}
              >
                <RadioGroupItem value="janela_longa" id="janela_longa" />
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-muted-foreground" />
                    <span className="font-medium text-muted-foreground">Não, cliente normal</span>
                  </div>
                  <p className="text-sm text-muted-foreground mt-0.5">
                    Este cliente tem janela de compra longa (não conta como reativação)
                  </p>
                </div>
              </label>
            </>
          )}
        </RadioGroup>
      </CardContent>
    </Card>
  );
}

// Hook para obter dados de classificação do cliente
export function useClientClassification(clientId: string, orderId: string, orderDate: string) {
  const [data, setData] = useState<ClientClassificationData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      if (!clientId) {
        setLoading(false);
        return;
      }

      try {
        // Buscar quantidade de pedidos existentes para este cliente (excluindo o atual)
        const { data: orders } = await supabase
          .from('orders')
          .select('id, order_date')
          .eq('client_id', clientId)
          .neq('id', orderId)
          .order('order_date', { ascending: false })
          .limit(1);

        const previousOrder = orders?.[0];
        const isFirstOrder = !previousOrder;

        let daysSinceLastOrder: number | null = null;
        let classificationType: 'new_client' | 'reactivation' | null = null;
        let needsClassification = false;

        if (isFirstOrder) {
          needsClassification = true;
          classificationType = 'new_client';
        } else if (previousOrder) {
          const lastOrderDate = new Date(previousOrder.order_date);
          const currentOrderDate = new Date(orderDate);
          daysSinceLastOrder = Math.floor(
            (currentOrderDate.getTime() - lastOrderDate.getTime()) / (1000 * 60 * 60 * 24)
          );

          if (daysSinceLastOrder > 90) {
            needsClassification = true;
            classificationType = 'reactivation';
          }
        }

        setData({
          needsClassification,
          classificationType,
          isFirstOrder,
          daysSinceLastOrder,
          lastOrderDate: previousOrder?.order_date || null,
          existingClientData: null
        });
      } catch (error) {
        console.error('Erro ao verificar classificação:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [clientId, orderId, orderDate]);

  return { data, loading };
}
