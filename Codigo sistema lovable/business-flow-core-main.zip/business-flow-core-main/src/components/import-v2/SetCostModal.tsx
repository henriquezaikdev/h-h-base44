import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { AlertCircle } from "lucide-react";

interface SetCostModalProps {
  product: {
    id: string;
    name: string;
    currentCost: number | null;
  };
  onClose: () => void;
  onSave: (newCost: number) => void;
}

export function SetCostModal({ product, onClose, onSave }: SetCostModalProps) {
  const [cost, setCost] = useState(product.currentCost?.toString().replace('.', ',') || '');
  const [error, setError] = useState('');

  const handleSave = () => {
    const costValue = parseFloat(cost.replace(',', '.'));
    
    if (isNaN(costValue) || costValue <= 0) {
      setError('O custo deve ser um valor maior que zero');
      return;
    }

    onSave(costValue);
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Definir Custo do Produto</DialogTitle>
          <DialogDescription>
            Este custo será salvo no catálogo e usado para cálculo de margem
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="bg-muted p-3 rounded-md">
            <p className="font-medium">{product.name}</p>
            {product.currentCost && (
              <p className="text-sm text-muted-foreground">
                Custo atual: R$ {product.currentCost.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
              </p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="cost">Novo Custo Unitário (R$)</Label>
            <Input
              id="cost"
              type="text"
              value={cost}
              onChange={(e) => {
                setCost(e.target.value);
                setError('');
              }}
              placeholder="0,00"
            />
            {error && (
              <div className="flex items-center gap-1 text-destructive text-sm">
                <AlertCircle className="h-4 w-4" />
                {error}
              </div>
            )}
          </div>

          <div className="bg-amber-50 dark:bg-amber-950 p-3 rounded-md border border-amber-200 dark:border-amber-800">
            <p className="text-sm text-amber-800 dark:text-amber-200">
              <strong>Atenção:</strong> O custo será salvo permanentemente no produto.
            </p>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancelar
          </Button>
          <Button onClick={handleSave}>
            Salvar Custo
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
