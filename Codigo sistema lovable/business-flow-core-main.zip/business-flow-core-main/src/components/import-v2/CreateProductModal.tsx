import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { StagingItem } from "./types";

interface CreateProductModalProps {
  item: StagingItem;
  onSave: (data: { name: string; external_code: string; cost_price: number; category_id?: string }) => void;
  onClose: () => void;
}

export function CreateProductModal({ item, onSave, onClose }: CreateProductModalProps) {
  const { toast } = useToast();
  const [name, setName] = useState(item.extracted_description);
  const [externalCode, setExternalCode] = useState(item.extracted_external_code || '');
  const [costPrice, setCostPrice] = useState<string>('');
  const [categoryId, setCategoryId] = useState<string>('');
  const [categories, setCategories] = useState<{ id: string; name: string }[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    const fetchCategories = async () => {
      const { data } = await supabase
        .from('categories')
        .select('id, name')
        .eq('active', true)
        .order('name');
      
      setCategories(data || []);
    };
    fetchCategories();
  }, []);

  const handleSubmit = async () => {
    if (!name.trim()) {
      toast({ title: "Erro", description: "Nome é obrigatório", variant: "destructive" });
      return;
    }

    const cost = parseFloat(costPrice.replace(',', '.'));
    if (isNaN(cost) || cost <= 0) {
      toast({ title: "Erro", description: "Custo deve ser maior que zero", variant: "destructive" });
      return;
    }

    const codigoCA = externalCode.trim().toUpperCase();
    
    // Validar unicidade do codigo_conta_azul se informado
    if (codigoCA) {
      const { data: existingProduct } = await supabase
        .from('products')
        .select('id, name')
        .eq('codigo_conta_azul', codigoCA)
        .eq('active', true)
        .maybeSingle();

      if (existingProduct) {
        toast({ 
          title: "Erro", 
          description: `Código Conta Azul já está em uso pelo produto: ${existingProduct.name}`, 
          variant: "destructive" 
        });
        return;
      }
    }

    setIsLoading(true);
    try {
      await onSave({
        name: name.trim(),
        external_code: codigoCA,
        cost_price: cost,
        category_id: categoryId || undefined
      });
    } catch (error: any) {
      toast({ title: "Erro", description: error.message, variant: "destructive" });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Criar Novo Produto</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="p-3 bg-muted rounded-lg text-sm">
            <strong>Item do PDF:</strong>
            <br />
            {item.extracted_external_code && (
              <span className="font-mono">{item.extracted_external_code} - </span>
            )}
            {item.extracted_description}
          </div>

          <div className="space-y-2">
            <Label htmlFor="name">Nome do Produto *</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Nome do produto"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="external-code">Código Conta Azul *</Label>
            <Input
              id="external-code"
              value={externalCode}
              onChange={(e) => setExternalCode(e.target.value.toUpperCase())}
              placeholder="Ex: REFIL5, PAPEL1"
              className="font-mono"
            />
            <p className="text-xs text-muted-foreground">
              Este código será usado para vincular automaticamente nas próximas importações
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="cost-price">Custo Unitário (R$) *</Label>
            <Input
              id="cost-price"
              value={costPrice}
              onChange={(e) => setCostPrice(e.target.value)}
              placeholder="0,00"
              type="text"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="category">Categoria</Label>
            <Select value={categoryId} onValueChange={setCategoryId}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione uma categoria" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((cat) => (
                  <SelectItem key={cat.id} value={cat.id}>
                    {cat.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={isLoading}>
            Cancelar
          </Button>
          <Button onClick={handleSubmit} disabled={isLoading}>
            {isLoading ? 'Criando...' : 'Criar e Vincular'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
