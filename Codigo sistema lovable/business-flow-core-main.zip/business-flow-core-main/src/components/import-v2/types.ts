// Tipos compartilhados para o Importador V2

export interface StagingItemProduct {
  id: string;
  name: string;
  sku: string | null;
  cost_price: number | null;
  external_code_contaazul: string | null;
  codigo_conta_azul?: string | null;
}

export interface StagingItem {
  id: string;
  doc_type: string;
  doc_ref: string;
  order_id: string | null;
  client_id?: string | null;  // Referência ao cliente do pedido
  extracted_external_code: string | null;
  extracted_description: string;
  quantity: number;
  unit_price: number;
  subtotal: number;
  matched_product_id: string | null;
  match_method: string | null;
  match_score: number | null;
  match_suggestions: StagingItemSuggestion[];
  status: string;
  product?: StagingItemProduct | null;
}

export interface StagingItemSuggestion {
  productId: string;
  name: string;
  sku: string | null;
  external_code: string | null;
  codigo_conta_azul?: string | null;
  cost_price: number | null;
  score: number;
}

export interface ImportSession {
  orderId: string;
  orderNumber: string;
  supplier: string;          // Nome do cliente
  customerDoc: string;       // CPF/CNPJ do cliente (CHAVE ÚNICA)
  clientId?: string;         // ID do cliente para classificação
  total: number;
  items: StagingItem[];
  isUpdate?: boolean;        // Se é atualização de pedido existente
  paymentMethod?: string;    // Forma de pagamento selecionada
  paymentTermDays?: number;  // Prazo de pagamento em dias (derivado)
  orderDate?: string;        // Data do pedido para verificar reativação
  dueDates?: string[];       // Datas de vencimento extraídas do PDF (ISO format)
}
