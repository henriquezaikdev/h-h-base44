import { motion } from 'framer-motion';
import { 
  Users, 
  Sparkles, 
  RefreshCw, 
  AlertTriangle, 
  Clock, 
  AlertCircle, 
  Moon 
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';

interface ClientsCounts {
  total: number;
  novo: number;
  recorrente: number;
  '60dias': number;
  '90dias': number;
  '120dias': number;
  inativo: number;
}

interface ClientsKPICardsProps {
  counts: ClientsCounts;
  onKpiClick?: (classification: string) => void;
  activeClassification?: string;
}

interface KpiConfig {
  key: keyof ClientsCounts;
  label: string;
  emoji: string;
  icon: LucideIcon;
  gradient: string;
  bgGradient: string;
  iconBg: string;
  iconColor: string;
}

const kpiConfigs: KpiConfig[] = [
  {
    key: 'total',
    label: 'Total',
    emoji: '📊',
    icon: Users,
    gradient: 'from-slate-500 to-slate-600',
    bgGradient: 'from-slate-500/10 to-slate-600/5',
    iconBg: 'bg-slate-500/20',
    iconColor: 'text-slate-600 dark:text-slate-400',
  },
  {
    key: 'novo',
    label: 'Novos',
    emoji: '🆕',
    icon: Sparkles,
    gradient: 'from-violet-500 to-purple-600',
    bgGradient: 'from-violet-500/10 to-purple-600/5',
    iconBg: 'bg-violet-500/20',
    iconColor: 'text-violet-600 dark:text-violet-400',
  },
  {
    key: 'recorrente',
    label: 'Recorrentes',
    emoji: '🔄',
    icon: RefreshCw,
    gradient: 'from-emerald-500 to-teal-600',
    bgGradient: 'from-emerald-500/10 to-teal-600/5',
    iconBg: 'bg-emerald-500/20',
    iconColor: 'text-emerald-600 dark:text-emerald-400',
  },
  {
    key: '60dias',
    label: '60 dias',
    emoji: '⚠️',
    icon: AlertTriangle,
    gradient: 'from-amber-500 to-orange-500',
    bgGradient: 'from-amber-500/10 to-orange-500/5',
    iconBg: 'bg-amber-500/20',
    iconColor: 'text-amber-600 dark:text-amber-400',
  },
  {
    key: '90dias',
    label: '90 dias',
    emoji: '⏰',
    icon: Clock,
    gradient: 'from-orange-500 to-red-500',
    bgGradient: 'from-orange-500/10 to-red-500/5',
    iconBg: 'bg-orange-500/20',
    iconColor: 'text-orange-600 dark:text-orange-400',
  },
  {
    key: '120dias',
    label: '120 dias',
    emoji: '🔴',
    icon: AlertCircle,
    gradient: 'from-red-500 to-rose-600',
    bgGradient: 'from-red-500/10 to-rose-600/5',
    iconBg: 'bg-red-500/20',
    iconColor: 'text-red-600 dark:text-red-400',
  },
  {
    key: 'inativo',
    label: 'Inativos',
    emoji: '💤',
    icon: Moon,
    gradient: 'from-gray-400 to-slate-500',
    bgGradient: 'from-gray-400/10 to-slate-500/5',
    iconBg: 'bg-gray-400/20',
    iconColor: 'text-gray-500 dark:text-gray-400',
  },
];

export function ClientsKPICards({ 
  counts, 
  onKpiClick,
  activeClassification 
}: ClientsKPICardsProps) {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-7 gap-3">
      {kpiConfigs.map((kpi, index) => {
        const Icon = kpi.icon;
        const value = counts[kpi.key];
        const isActive = activeClassification === kpi.key || 
          (activeClassification === 'all' && kpi.key === 'total');
        
        return (
          <motion.div
            key={kpi.key}
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ 
              delay: index * 0.05, 
              duration: 0.3,
              type: 'spring',
              stiffness: 300,
              damping: 25
            }}
            whileHover={{ 
              scale: 1.03, 
              y: -2,
              transition: { duration: 0.2 } 
            }}
            whileTap={{ scale: 0.98 }}
            onClick={() => onKpiClick?.(kpi.key === 'total' ? 'all' : kpi.key)}
            className={`
              relative group cursor-pointer overflow-hidden
              rounded-xl border transition-all duration-300
              ${isActive 
                ? 'border-primary/50 shadow-lg shadow-primary/10' 
                : 'border-border/50 hover:border-primary/30 hover:shadow-md'}
              bg-gradient-to-br ${kpi.bgGradient} backdrop-blur-sm
            `}
          >
            {/* Background gradient glow on hover */}
            <div className={`
              absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300
              bg-gradient-to-br ${kpi.gradient}
            `} style={{ opacity: 0.05 }} />

            <div className="relative p-3">
              <div className="flex items-center justify-between mb-2">
                <div className={`w-8 h-8 rounded-lg ${kpi.iconBg} flex items-center justify-center`}>
                  <Icon className={`w-4 h-4 ${kpi.iconColor}`} />
                </div>
                <span className="text-lg">{kpi.emoji}</span>
              </div>
              
              <motion.p 
                className="text-2xl font-bold text-foreground"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: index * 0.05 + 0.2 }}
              >
                {value.toLocaleString('pt-BR')}
              </motion.p>
              <p className="text-xs text-muted-foreground font-medium mt-0.5">
                {kpi.label}
              </p>
            </div>

            {/* Active indicator */}
            {isActive && (
              <motion.div
                layoutId="activeKpi"
                className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-primary to-primary/50"
              />
            )}
          </motion.div>
        );
      })}
    </div>
  );
}
