import { motion } from 'framer-motion';
import { Search, X, Filter } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

interface Seller {
  id: string;
  name: string;
}

interface ClientsFilterBarProps {
  searchTerm: string;
  onSearchChange: (value: string) => void;
  statusFilter: string;
  onStatusChange: (value: string) => void;
  sellerFilter: string;
  onSellerChange: (value: string) => void;
  rankingFilter: string;
  onRankingChange: (value: string) => void;
  sellers: Seller[];
  loadingSellers: boolean;
  isAdmin: boolean;
  totalCount: number;
  hasActiveFilters: boolean;
  onResetFilters: () => void;
}

export function ClientsFilterBar({
  searchTerm,
  onSearchChange,
  statusFilter,
  onStatusChange,
  sellerFilter,
  onSellerChange,
  rankingFilter,
  onRankingChange,
  sellers,
  loadingSellers,
  isAdmin,
  totalCount,
  hasActiveFilters,
  onResetFilters,
}: ClientsFilterBarProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.2 }}
      className="sticky top-0 z-40 -mx-6 px-6 py-4 bg-background/80 backdrop-blur-xl border-b border-border/50"
    >
      <div className="flex flex-wrap items-center gap-3">
        {/* Search Input */}
        <div className="relative flex-1 min-w-[240px] max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" size={18} />
          <input
            type="text"
            placeholder="Buscar por empresa ou CNPJ..."
            className="w-full h-10 pl-10 pr-10 rounded-xl bg-muted/50 border border-border/50 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary/50 transition-all"
            value={searchTerm}
            onChange={(e) => onSearchChange(e.target.value)}
          />
          {searchTerm && (
            <button
              onClick={() => onSearchChange('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
            >
              <X size={16} />
            </button>
          )}
        </div>

        {/* Status Filter */}
        <Select value={statusFilter} onValueChange={onStatusChange}>
          <SelectTrigger className="w-[140px] h-10 rounded-xl bg-muted/30 border-border/50 text-sm">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos Status</SelectItem>
            <SelectItem value="ativo">✓ Ativos</SelectItem>
            <SelectItem value="inativo">○ Inativos</SelectItem>
          </SelectContent>
        </Select>

        {/* Seller Filter (Admin) */}
        {isAdmin && (
          <Select value={sellerFilter} onValueChange={onSellerChange} disabled={loadingSellers}>
            <SelectTrigger className="w-[180px] h-10 rounded-xl bg-muted/30 border-border/50 text-sm">
              <SelectValue placeholder={loadingSellers ? 'Carregando...' : 'Vendedor'} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos Vendedores</SelectItem>
              {sellers.map((seller) => (
                <SelectItem key={seller.id} value={seller.id}>
                  {seller.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        )}

        {/* Ranking Filter */}
        <Select value={rankingFilter} onValueChange={onRankingChange}>
          <SelectTrigger className="w-[150px] h-10 rounded-xl bg-muted/30 border-border/50 text-sm">
            <SelectValue placeholder="Ranking" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos Rankings</SelectItem>
            <SelectItem value="top20">⭐ Top 20</SelectItem>
            <SelectItem value="top100">💎 Top 100</SelectItem>
            <SelectItem value="top200">🏆 Top 200</SelectItem>
            <SelectItem value="top300">🥉 Top 300</SelectItem>
            <SelectItem value="demais">📊 Demais</SelectItem>
          </SelectContent>
        </Select>

        {/* Reset Filters */}
        {hasActiveFilters && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
          >
            <Button
              variant="ghost"
              size="sm"
              onClick={onResetFilters}
              className="h-10 px-3 text-muted-foreground hover:text-foreground rounded-xl"
            >
              <Filter size={14} className="mr-1" />
              Limpar
            </Button>
          </motion.div>
        )}

        {/* Results Count Badge */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.3 }}
          className="ml-auto"
        >
          <Badge 
            variant="secondary" 
            className="h-8 px-3 bg-gradient-to-r from-primary/10 to-accent/10 text-foreground font-medium rounded-lg"
          >
            {totalCount} clientes
          </Badge>
        </motion.div>
      </div>
    </motion.div>
  );
}
