import { motion } from 'framer-motion';
import { 
  XCircle, 
  CheckCircle, 
  Users, 
  Trash2, 
  Loader2 
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

interface ClientsBulkActionsBarProps {
  selectedCount: number;
  onClearSelection: () => void;
  onActivate: () => void;
  onDeactivate: () => void;
  onTransfer: () => void;
  onDelete: () => void;
  isStatusUpdating: boolean;
  isDeleting: boolean;
}

export function ClientsBulkActionsBar({
  selectedCount,
  onClearSelection,
  onActivate,
  onDeactivate,
  onTransfer,
  onDelete,
  isStatusUpdating,
  isDeleting,
}: ClientsBulkActionsBarProps) {
  if (selectedCount === 0) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: -20, scale: 0.98 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: -10 }}
      transition={{ type: 'spring', stiffness: 400, damping: 30 }}
      className="relative overflow-hidden rounded-xl border border-primary/30 bg-gradient-to-r from-primary/5 via-primary/10 to-accent/5 backdrop-blur-sm"
    >
      {/* Animated background */}
      <div className="absolute inset-0 bg-gradient-to-r from-primary/5 to-transparent opacity-50" />
      
      <div className="relative flex items-center justify-between p-4">
        <div className="flex items-center gap-3">
          <Badge 
            variant="secondary" 
            className="h-8 px-3 bg-primary/20 text-primary font-semibold rounded-lg"
          >
            {selectedCount} selecionado{selectedCount > 1 ? 's' : ''}
          </Badge>
          
          <Button
            size="sm"
            variant="ghost"
            onClick={onClearSelection}
            className="text-muted-foreground hover:text-foreground h-8 px-2"
          >
            <XCircle size={14} className="mr-1" />
            Limpar
          </Button>
        </div>

        <div className="flex items-center gap-2">
          <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
            <Button
              size="sm"
              variant="outline"
              onClick={onActivate}
              disabled={isStatusUpdating}
              className="h-9 rounded-lg border-emerald-500/30 hover:bg-emerald-500/10 hover:text-emerald-600 hover:border-emerald-500/50"
            >
              {isStatusUpdating ? (
                <Loader2 size={14} className="animate-spin mr-1" />
              ) : (
                <CheckCircle size={14} className="mr-1" />
              )}
              Ativar
            </Button>
          </motion.div>

          <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
            <Button
              size="sm"
              variant="outline"
              onClick={onDeactivate}
              disabled={isStatusUpdating}
              className="h-9 rounded-lg border-muted-foreground/30 hover:bg-muted/50"
            >
              {isStatusUpdating ? (
                <Loader2 size={14} className="animate-spin mr-1" />
              ) : (
                <XCircle size={14} className="mr-1" />
              )}
              Inativar
            </Button>
          </motion.div>

          <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
            <Button
              size="sm"
              variant="outline"
              onClick={onTransfer}
              className="h-9 rounded-lg hover:bg-primary/10 hover:text-primary hover:border-primary/50"
            >
              <Users size={14} className="mr-1" />
              Transferir
            </Button>
          </motion.div>

          <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
            <Button
              size="sm"
              variant="destructive"
              onClick={onDelete}
              disabled={isDeleting}
              className="h-9 rounded-lg"
            >
              {isDeleting ? (
                <Loader2 size={14} className="animate-spin mr-1" />
              ) : (
                <Trash2 size={14} className="mr-1" />
              )}
              Excluir
            </Button>
          </motion.div>
        </div>
      </div>
    </motion.div>
  );
}
