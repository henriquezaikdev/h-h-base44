import { motion } from 'framer-motion';
import { Building2, TrendingUp, LayoutList, LayoutGrid } from 'lucide-react';
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group';

interface ClientsPageHeaderProps {
  viewMode: 'table' | 'cards';
  onViewModeChange: (mode: 'table' | 'cards') => void;
  totalClients?: number;
}

export function ClientsPageHeader({ 
  viewMode, 
  onViewModeChange,
  totalClients 
}: ClientsPageHeaderProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, ease: 'easeOut' }}
      className="relative rounded-2xl overflow-hidden bg-gradient-to-br from-primary/10 via-primary/5 to-transparent border border-primary/20 p-6"
    >
      {/* Decorative blurred spheres */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute -top-12 -right-12 w-40 h-40 bg-primary/20 rounded-full blur-3xl" />
        <div className="absolute -bottom-8 -left-8 w-32 h-32 bg-accent/20 rounded-full blur-3xl" />
      </div>

      <div className="relative flex items-center justify-between flex-wrap gap-4">
        <div className="flex items-center gap-4">
          <motion.div
            initial={{ scale: 0.8, rotate: -10 }}
            animate={{ scale: 1, rotate: 0 }}
            transition={{ delay: 0.2, type: 'spring', stiffness: 200 }}
            className="w-14 h-14 rounded-2xl bg-gradient-to-br from-primary to-primary/70 flex items-center justify-center shadow-lg shadow-primary/25"
          >
            <Building2 className="w-7 h-7 text-primary-foreground" />
          </motion.div>
          
          <div>
            <motion.h1 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1 }}
              className="text-2xl font-bold text-foreground"
            >
              Carteira de Clientes
            </motion.h1>
            <motion.p 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.3 }}
              className="text-muted-foreground flex items-center gap-2"
            >
              <TrendingUp className="w-4 h-4 text-primary" />
              <span>
                Gerencie sua carteira comercial
                {totalClients !== undefined && (
                  <span className="ml-2 text-xs text-primary font-medium">
                    • {totalClients} clientes
                  </span>
                )}
              </span>
            </motion.p>
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.3 }}
        >
          <ToggleGroup
            type="single"
            value={viewMode}
            onValueChange={(value) => value && onViewModeChange(value as 'table' | 'cards')}
            className="bg-muted/50 backdrop-blur-sm border border-border/50 rounded-xl p-1"
          >
            <ToggleGroupItem 
              value="table" 
              aria-label="Visualização em tabela" 
              className="px-3 py-2 data-[state=on]:bg-background data-[state=on]:shadow-sm rounded-lg transition-all"
            >
              <LayoutList size={16} />
            </ToggleGroupItem>
            <ToggleGroupItem 
              value="cards" 
              aria-label="Visualização em cards" 
              className="px-3 py-2 data-[state=on]:bg-background data-[state=on]:shadow-sm rounded-lg transition-all"
            >
              <LayoutGrid size={16} />
            </ToggleGroupItem>
          </ToggleGroup>
        </motion.div>
      </div>
    </motion.div>
  );
}
