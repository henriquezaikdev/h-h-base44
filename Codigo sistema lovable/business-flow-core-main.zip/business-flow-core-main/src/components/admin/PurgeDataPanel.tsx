import { useMemo, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import {
  AlertTriangle,
  Trash2,
  RotateCcw,
  Calculator,
  Loader2,
  CheckCircle2,
  XCircle,
  History,
  CalendarIcon,
  X,
} from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { cn } from '@/lib/utils';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Switch } from '@/components/ui/switch';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

type DateMode = 'created_at' | 'original_created_at' | 'imported_at' | 'document_date';

type DateModeOption = {
  value: DateMode;
  label: string;
  description: string;
};

const DATE_MODE_OPTIONS: DateModeOption[] = [
  {
    value: 'original_created_at',
    label: 'Data original (recomendada)',
    description: 'Usa original_created_at (se existir e estiver preenchido).',
  },
  {
    value: 'document_date',
    label: 'Data do documento/evento',
    description: 'Pedidos: order_date, Orçamentos: quote_date, Tarefas: task_date, Interações: interaction_date.',
  },
  {
    value: 'imported_at',
    label: 'Data de importação',
    description: 'Usa imported_at (útil para limpar blocos importados).',
  },
  {
    value: 'created_at',
    label: 'Criação no sistema',
    description: 'Usa created_at (geralmente é a data de importação do sistema).',
  },
];

interface EntityCounts {
  clients: { total: number; to_purge: number };
  orders: { total: number; to_purge: number };
  tasks: { total: number; to_purge: number };
  interactions: { total: number; to_purge: number };
  quotes: { total: number; to_purge: number };
  buyers: { total: number; to_purge: number };
  products: { total: number; to_purge: number };
}

type PreviewMeta = {
  is_admin?: boolean;
  unsupported?: Partial<Record<keyof EntityCounts, string>>;
  date_field_by_entity?: Partial<Record<keyof EntityCounts, string | null>>;
  diagnostics?: Record<string, unknown>;
  samples?: Record<string, unknown>;
};

interface PurgeHistory {
  id: string;
  started_at: string;
  finished_at: string | null;
  executed_by: string;
  status: string;
  cutoff_date: string;
  summary_counts_before: EntityCounts | Record<string, unknown> | null;
  summary_counts_after: EntityCounts | Record<string, unknown> | null;
  error_log: string | null;
}

interface SelectedEntities {
  clients: boolean;
  orders: boolean;
  tasks: boolean;
  interactions: boolean;
  quotes: boolean;
  buyers: boolean;
  products: boolean;
}

const ENTITY_LABELS: Record<keyof SelectedEntities, string> = {
  clients: 'Clientes',
  orders: 'Pedidos',
  tasks: 'Tarefas',
  interactions: 'Interações',
  quotes: 'Orçamentos',
  buyers: 'Compradores',
  products: 'Produtos',
};

export function PurgeDataPanel() {
  const [loading, setLoading] = useState(false);
  const [useRangeFilter, setUseRangeFilter] = useState(false);
  const [startDate, setStartDate] = useState<Date | undefined>(undefined);
  const [endDate, setEndDate] = useState<Date>(new Date('2025-01-01'));
  const [dateMode, setDateMode] = useState<DateMode>('original_created_at');
  const [selectedEntities, setSelectedEntities] = useState<SelectedEntities>({
    clients: true,
    orders: true,
    tasks: true,
    interactions: true,
    quotes: true,
    buyers: true,
    products: false,
  });
  const [previewCounts, setPreviewCounts] = useState<EntityCounts | null>(null);
  const [previewMeta, setPreviewMeta] = useState<PreviewMeta | null>(null);
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  const [confirmText, setConfirmText] = useState('');
  const [purgeHistory, setPurgeHistory] = useState<PurgeHistory[]>([]);
  const [showHistory, setShowHistory] = useState(false);
  const [lastResult, setLastResult] = useState<{
    success: boolean;
    message: string;
    purge_batch_id?: string;
    deleted_counts?: Record<string, number>;
  } | null>(null);

  const unsupportedSelected = useMemo(() => {
    const unsupported = previewMeta?.unsupported;
    if (!unsupported) return [] as Array<keyof SelectedEntities>;
    return (Object.keys(unsupported) as Array<keyof SelectedEntities>).filter(
      (k) => selectedEntities[k] && Boolean(unsupported[k])
    );
  }, [previewMeta?.unsupported, selectedEntities]);

  const totalToPurge = previewCounts
    ? (Object.entries(previewCounts) as Array<[keyof EntityCounts, { total: number; to_purge: number }]> )
        .filter(([key]) => selectedEntities[key as keyof SelectedEntities])
        .reduce((sum, [, value]) => sum + value.to_purge, 0)
    : 0;

  const fetchPreview = async () => {
    setLoading(true);
    setPreviewCounts(null);
    setPreviewMeta(null);
    setLastResult(null);

    try {
      const {
        data: { session },
      } = await supabase.auth.getSession();
      if (!session) {
        toast.error('Sessão expirada');
        return;
      }

      const response = await supabase.functions.invoke('execute-purge', {
        body: {
          action: 'preview',
          date_mode: dateMode,
          start_date: useRangeFilter && startDate ? format(startDate, 'yyyy-MM-dd') : null,
          end_date: format(endDate, 'yyyy-MM-dd'),
          entities: Object.entries(selectedEntities)
            .filter(([, selected]) => selected)
            .map(([key]) => key),
        },
      });

      if (response.error) throw response.error;

      setPreviewCounts(response.data.counts);
      setPreviewMeta({
        is_admin: response.data.is_admin,
        unsupported: response.data.unsupported,
        date_field_by_entity: response.data.date_field_by_entity,
        diagnostics: response.data.diagnostics,
        samples: response.data.samples,
      });

      toast.success('Contagens calculadas!');
    } catch (error: unknown) {
      const errorMessage = error instanceof Error ? error.message : 'Erro ao calcular preview';
      console.error('Erro ao carregar preview:', error);
      toast.error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const fetchHistory = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('purge_audit')
        .select('*')
        .order('started_at', { ascending: false })
        .limit(20);

      if (error) throw error;
      setPurgeHistory((data || []) as PurgeHistory[]);
      setShowHistory(true);
    } catch (error: unknown) {
      console.error('Erro ao carregar histórico:', error);
      toast.error('Erro ao carregar histórico');
    } finally {
      setLoading(false);
    }
  };

  const executePurge = async () => {
    if (unsupportedSelected.length > 0) {
      toast.error('Ajuste o campo de data ou desmarque entidades sem suporte (veja os avisos do Preview).');
      return;
    }

    if (confirmText !== 'EXCLUIR') {
      toast.error('Digite "EXCLUIR" para confirmar');
      return;
    }

    setLoading(true);
    setShowConfirmDialog(false);
    setConfirmText('');

    try {
      const response = await supabase.functions.invoke('execute-purge', {
        body: {
          action: 'execute',
          date_mode: dateMode,
          start_date: useRangeFilter && startDate ? format(startDate, 'yyyy-MM-dd') : null,
          end_date: format(endDate, 'yyyy-MM-dd'),
          entities: Object.entries(selectedEntities)
            .filter(([, selected]) => selected)
            .map(([key]) => key),
          confirmation: 'EXCLUIR',
        },
      });

      if (response.error) throw response.error;

      setLastResult(response.data);
      setPreviewCounts(null);
      setPreviewMeta(null);
      toast.success('Exclusão em massa executada com sucesso!');
    } catch (error: unknown) {
      const errorMessage = error instanceof Error ? error.message : 'Erro desconhecido';
      console.error('Erro ao executar purge:', error);
      toast.error(errorMessage);
      setLastResult({
        success: false,
        message: errorMessage,
      });
    } finally {
      setLoading(false);
    }
  };

  const executeRollback = async (batchId: string) => {
    setLoading(true);
    try {
      const response = await supabase.functions.invoke('execute-purge', {
        body: { action: 'rollback', purge_batch_id: batchId },
      });

      if (response.error) throw response.error;

      toast.success('Restauração executada com sucesso!');
      fetchHistory();
    } catch (error: unknown) {
      const errorMessage = error instanceof Error ? error.message : 'Erro ao restaurar';
      console.error('Erro ao executar rollback:', error);
      toast.error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const resetPreview = () => {
    setPreviewCounts(null);
    setPreviewMeta(null);
  };

  const toggleEntity = (entity: keyof SelectedEntities) => {
    setSelectedEntities((prev) => ({ ...prev, [entity]: !prev[entity] }));
    resetPreview();
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'SUCCESS':
        return <Badge className="bg-green-500"><CheckCircle2 className="w-3 h-3 mr-1" />Sucesso</Badge>;
      case 'FAILED':
        return <Badge variant="destructive"><XCircle className="w-3 h-3 mr-1" />Falhou</Badge>;
      case 'RUNNING':
        return <Badge className="bg-yellow-500"><Loader2 className="w-3 h-3 mr-1 animate-spin" />Executando</Badge>;
      case 'ROLLED_BACK':
        return <Badge variant="secondary"><RotateCcw className="w-3 h-3 mr-1" />Restaurado</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  const selectedCount = Object.values(selectedEntities).filter(Boolean).length;
  const selectedEntityNames = Object.entries(selectedEntities)
    .filter(([, selected]) => selected)
    .map(([key]) => ENTITY_LABELS[key as keyof SelectedEntities])
    .join(', ');

  const getDateRangeDescription = () => {
    if (useRangeFilter && startDate) {
      return `entre ${format(startDate, "dd/MM/yyyy")} e ${format(endDate, "dd/MM/yyyy")}`;
    }
    return `anterior a ${format(endDate, "dd/MM/yyyy")}`;
  };

  return (
    <div className="space-y-6">
      {/* Configuração */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-destructive" />
            <CardTitle>Exclusão em Massa por Data</CardTitle>
          </div>
          <CardDescription>
            Exclua registros antigos selecionando um período, as entidades desejadas e qual campo de data deve ser usado no filtro.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Tipo de filtro */}
          <div className="flex flex-col gap-4">
            <div className="flex items-center space-x-3 p-3 bg-muted/50 rounded-lg">
              <Switch
                id="range-filter"
                checked={useRangeFilter}
                onCheckedChange={(checked) => {
                  setUseRangeFilter(checked);
                  resetPreview();
                  if (!checked) setStartDate(undefined);
                }}
              />
              <Label htmlFor="range-filter" className="cursor-pointer">
                Usar filtro por intervalo de datas
              </Label>
            </div>

            <div className="space-y-2">
              <Label className="text-base font-medium">Usar data por</Label>
              <Select
                value={dateMode}
                onValueChange={(val) => {
                  setDateMode(val as DateMode);
                  resetPreview();
                }}
              >
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Selecione o campo de data" />
                </SelectTrigger>
                <SelectContent>
                  {DATE_MODE_OPTIONS.map((opt) => (
                    <SelectItem key={opt.value} value={opt.value}>
                      {opt.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-sm text-muted-foreground">
                {DATE_MODE_OPTIONS.find((o) => o.value === dateMode)?.description}
              </p>
            </div>
          </div>

          {/* Datas */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Data Inicial (opcional) */}
            {useRangeFilter && (
              <div className="space-y-2">
                <Label className="text-base font-medium">Data Inicial (opcional)</Label>
                <p className="text-sm text-muted-foreground mb-2">
                  Se preenchida, apenas registros <strong>a partir desta data</strong> serão considerados.
                </p>
                <div className="flex gap-2">
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className={cn(
                          "flex-1 justify-start text-left font-normal",
                          !startDate && "text-muted-foreground"
                        )}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {startDate ? format(startDate, "PPP", { locale: ptBR }) : "Sem limite inicial"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={startDate}
                        onSelect={(date) => {
                          setStartDate(date);
                          resetPreview();
                        }}
                        disabled={(date) => date > new Date() || (endDate && date >= endDate)}
                        initialFocus
                        className="p-3 pointer-events-auto"
                      />
                    </PopoverContent>
                  </Popover>
                  {startDate && (
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => {
                        setStartDate(undefined);
                        resetPreview();
                      }}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              </div>
            )}

            {/* Data Final (obrigatória) */}
            <div className="space-y-2">
              <Label className="text-base font-medium">
                {useRangeFilter ? 'Data Final (obrigatória)' : 'Data de Corte'}
              </Label>
              <p className="text-sm text-muted-foreground mb-2">
                Registros com data de criação <strong>anterior</strong> a esta data serão excluídos.
              </p>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !endDate && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {endDate ? format(endDate, "PPP", { locale: ptBR }) : "Selecione uma data"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={endDate}
                    onSelect={(date) => {
                      if (date) {
                        setEndDate(date);
                        resetPreview();
                      }
                    }}
                    disabled={(date) => date > new Date() || (startDate && date <= startDate)}
                    initialFocus
                    className="p-3 pointer-events-auto"
                  />
                </PopoverContent>
              </Popover>
            </div>
          </div>

          {/* Entidades */}
          <div className="space-y-2">
            <Label className="text-base font-medium">Entidades a Excluir</Label>
            <p className="text-sm text-muted-foreground mb-3">
              Selecione quais tipos de registros deseja excluir. O filtro usa o campo escolhido em <strong>"Usar data por"</strong>.
            </p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {(Object.keys(selectedEntities) as Array<keyof SelectedEntities>).map((entity) => (
                <div key={entity} className="flex items-center space-x-2">
                  <Checkbox
                    id={entity}
                    checked={selectedEntities[entity]}
                    onCheckedChange={() => toggleEntity(entity)}
                  />
                  <Label
                    htmlFor={entity}
                    className="text-sm font-normal cursor-pointer"
                  >
                    {ENTITY_LABELS[entity]}
                  </Label>
                </div>
              ))}
            </div>
          </div>

          {/* Botões de ação - DESTACADOS */}
          <div className="flex flex-wrap gap-4 pt-6 mt-4 border-t-2 border-primary/20 bg-muted/50 -mx-6 px-6 py-4 rounded-b-lg">
            <Button
              onClick={fetchPreview}
              disabled={loading || selectedCount === 0}
              size="lg"
              className="min-w-[220px]"
            >
              {loading ? (
                <Loader2 className="w-5 h-5 mr-2 animate-spin" />
              ) : (
                <Calculator className="w-5 h-5 mr-2" />
              )}
              CALCULAR (Preview)
            </Button>
            <Button
              variant="outline"
              size="lg"
              onClick={fetchHistory}
              disabled={loading}
            >
              <History className="w-5 h-5 mr-2" />
              Ver Histórico
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Preview / Contagens */}
      {previewCounts && (
          <Card className="border-2 border-destructive/30">
            <CardHeader className="bg-destructive/5">
              <CardTitle className="text-lg flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-destructive" />
                Resultado do Cálculo
              </CardTitle>
              <CardDescription>
                Filtro {getDateRangeDescription()} usando <strong>{DATE_MODE_OPTIONS.find((o) => o.value === dateMode)?.label}</strong>.
              </CardDescription>
            </CardHeader>
          <CardContent className="space-y-4 pt-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {(Object.entries(previewCounts) as Array<[keyof EntityCounts, { total: number; to_purge: number }]>)
                .filter(([key]) => selectedEntities[key as keyof SelectedEntities])
                .map(([entity, counts]) => (
                  <div key={entity} className={cn(
                    "p-3 border rounded-lg",
                    counts.to_purge > 0 && "border-destructive/50 bg-destructive/5"
                  )}>
                    <div className="text-sm text-muted-foreground">{ENTITY_LABELS[entity as keyof SelectedEntities]}</div>
                    <div className={cn(
                      "text-2xl font-bold",
                      counts.to_purge > 0 ? "text-destructive" : "text-muted-foreground"
                    )}>
                      {counts.to_purge}
                    </div>
                    <div className="text-xs text-muted-foreground">de {counts.total} total</div>
                  </div>
                ))}
            </div>

            {/* Avisos + Resumo e botão de execução */}
            {previewMeta?.unsupported && Object.keys(previewMeta.unsupported).length > 0 && (
              <div className="p-3 border border-destructive/30 bg-destructive/5 rounded-lg text-sm">
                <div className="font-medium text-destructive mb-2">
                  Atenção: algumas entidades não suportam o campo de data selecionado
                </div>
                <ul className="list-disc pl-5 space-y-1">
                  {(Object.entries(previewMeta.unsupported) as Array<[string, string]>).map(([entity, reason]) => (
                    <li key={entity}>
                      <strong>{ENTITY_LABELS[entity as keyof SelectedEntities] ?? entity}:</strong> {reason}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            <div className="flex flex-col md:flex-row items-center justify-between gap-4 pt-4 border-t bg-destructive/5 -mx-6 px-6 py-4 -mb-6 rounded-b-lg">
              <div className="text-center md:text-left">
                <div className="text-lg font-medium">
                  Total a excluir: <span className="text-3xl font-bold text-destructive">{totalToPurge}</span> registros
                </div>
                <div className="text-sm text-muted-foreground">
                  Data: {getDateRangeDescription()}
                </div>
              </div>
              {totalToPurge > 0 && (
                <Button
                  variant="destructive"
                  onClick={() => setShowConfirmDialog(true)}
                  disabled={loading || totalToPurge === 0 || unsupportedSelected.length > 0}
                  size="lg"
                  className="min-w-[200px]"
                >
                  <Trash2 className="w-5 h-5 mr-2" />
                  EXCLUIR EM MASSA
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Resultado da última operação */}
      {lastResult && (
        <Card className={lastResult.success ? 'border-green-500/50 bg-green-500/5' : 'border-destructive/50 bg-destructive/5'}>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              {lastResult.success ? (
                <CheckCircle2 className="w-5 h-5 text-green-500" />
              ) : (
                <XCircle className="w-5 h-5 text-destructive" />
              )}
              {lastResult.success ? 'Exclusão Concluída' : 'Erro na Exclusão'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p>{lastResult.message}</p>
            {lastResult.purge_batch_id && (
              <p className="text-sm text-muted-foreground mt-2">
                ID da operação: <code className="bg-muted px-1 rounded">{lastResult.purge_batch_id}</code>
              </p>
            )}
            {lastResult.deleted_counts && (
              <div className="mt-4 grid grid-cols-2 md:grid-cols-4 gap-2">
                {Object.entries(lastResult.deleted_counts).map(([entity, count]) => (
                  <div key={entity} className="text-sm p-2 bg-muted/50 rounded">
                    <strong>{count}</strong> {ENTITY_LABELS[entity as keyof SelectedEntities] || entity}
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Histórico */}
      {showHistory && purgeHistory.length > 0 && (
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-lg">Histórico de Limpeza</CardTitle>
            <Button variant="ghost" size="sm" onClick={() => setShowHistory(false)}>
              Fechar
            </Button>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-96">
              <div className="space-y-3">
                {purgeHistory.map(record => {
                  const countsBefore = record.summary_counts_before;
                  const totalDeleted = countsBefore
                    ? Object.values(countsBefore).reduce((sum, val) => sum + (val?.to_purge || 0), 0)
                    : 0;
                  
                  return (
                    <div key={record.id} className="p-4 border rounded-lg">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-2">
                          {getStatusBadge(record.status)}
                          <span className="text-sm text-muted-foreground">
                            {new Date(record.started_at).toLocaleString('pt-BR')}
                          </span>
                        </div>
                        {record.status === 'SUCCESS' && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => executeRollback(record.id)}
                            disabled={loading}
                          >
                            <RotateCcw className="w-3 h-3 mr-1" />
                            Restaurar
                          </Button>
                        )}
                      </div>
                      <div className="text-sm space-y-1">
                        <div><strong>Executado por:</strong> {record.executed_by}</div>
                        <div><strong>Data de corte:</strong> {new Date(record.cutoff_date).toLocaleDateString('pt-BR')}</div>
                        {totalDeleted > 0 && (
                          <div><strong>Total excluído:</strong> {totalDeleted} registros</div>
                        )}
                      </div>
                      {countsBefore && (
                        <div className="mt-2 grid grid-cols-3 md:grid-cols-7 gap-1">
                          {Object.entries(countsBefore)
                            .filter(([, val]) => val?.to_purge > 0)
                            .map(([entity, val]) => (
                              <Badge key={entity} variant="secondary" className="text-xs">
                                {ENTITY_LABELS[entity as keyof SelectedEntities]}: {val.to_purge}
                              </Badge>
                            ))}
                        </div>
                      )}
                      {record.error_log && (
                        <div className="text-xs text-destructive mt-2 p-2 bg-destructive/10 rounded">
                          Erro: {record.error_log}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      )}

      {showHistory && purgeHistory.length === 0 && (
        <Card>
          <CardContent className="py-8 text-center text-muted-foreground">
            Nenhum histórico de limpeza encontrado.
          </CardContent>
        </Card>
      )}

      {/* Dialog de confirmação */}
      <AlertDialog open={showConfirmDialog} onOpenChange={setShowConfirmDialog}>
        <AlertDialogContent className="max-w-lg">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2 text-destructive">
              <AlertTriangle className="w-5 h-5" />
              Confirmar Exclusão em Massa
            </AlertDialogTitle>
            <AlertDialogDescription asChild>
              <div className="space-y-4">
                <div className="p-4 bg-destructive/10 border border-destructive/30 rounded-lg">
                  <div className="text-lg font-semibold text-foreground mb-2">
                    Você está prestes a excluir {totalToPurge} registros
                  </div>
                  <div className="text-sm space-y-1">
                    <div><strong>Período:</strong> {getDateRangeDescription()}</div>
                    <div><strong>Campo de data:</strong> {DATE_MODE_OPTIONS.find((o) => o.value === dateMode)?.label}</div>
                    <div><strong>Entidades:</strong> {selectedEntityNames}</div>
                  </div>
                </div>

                {previewCounts && (
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    {(Object.entries(previewCounts) as Array<[keyof EntityCounts, { total: number; to_purge: number }]>)
                      .filter(([key]) => selectedEntities[key as keyof SelectedEntities])
                      .filter(([, val]) => val.to_purge > 0)
                      .map(([entity, counts]) => (
                        <div key={entity} className="flex justify-between p-2 bg-muted rounded">
                          <span>{ENTITY_LABELS[entity as keyof SelectedEntities]}</span>
                          <span className="font-bold text-destructive">{counts.to_purge}</span>
                        </div>
                      ))}
                  </div>
                )}

                <p className="text-sm text-muted-foreground">
                  Os dados podem ser restaurados posteriormente via "Ver Histórico" → "Restaurar".
                  {unsupportedSelected.length > 0 && (
                    <span className="block text-destructive mt-1">
                      Ajuste o campo de data ou desmarque entidades sem suporte antes de executar.
                    </span>
                  )}
                </p>

                <div>
                  <Label className="text-sm font-medium">
                    Digite <code className="bg-muted px-1 rounded text-destructive font-bold">EXCLUIR</code> para confirmar:
                  </Label>
                  <Input
                    value={confirmText}
                    onChange={(e) => setConfirmText(e.target.value.toUpperCase())}
                    placeholder="EXCLUIR"
                    className="mt-2"
                    autoFocus
                  />
                </div>
              </div>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setConfirmText('')}>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={executePurge}
              disabled={confirmText !== 'EXCLUIR' || unsupportedSelected.length > 0}
              className="bg-destructive hover:bg-destructive/90"
            >
              <Trash2 className="w-4 h-4 mr-2" />
              Executar Exclusão
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
