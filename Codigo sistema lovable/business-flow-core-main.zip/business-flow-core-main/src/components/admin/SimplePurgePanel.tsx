import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import {
  Trash2,
  Loader2,
  CalendarIcon,
  Users,
  ShoppingCart,
  AlertTriangle,
} from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { cn } from '@/lib/utils';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

type EntityType = 'clients' | 'orders';
type DateMode = 'created_at' | 'original_created_at' | 'imported_at' | 'document_date';

interface PreviewResult {
  total: number;
  to_purge: number;
}

const ENTITY_CONFIG = {
  clients: {
    label: 'Clientes',
    icon: Users,
    color: 'text-blue-500',
    bgColor: 'bg-blue-500/10',
  },
  orders: {
    label: 'Pedidos',
    icon: ShoppingCart,
    color: 'text-green-500',
    bgColor: 'bg-green-500/10',
  },
};

const DATE_MODE_OPTIONS = [
  { value: 'document_date', label: 'Data do documento', description: 'Pedidos: order_date' },
  { value: 'original_created_at', label: 'Data original', description: 'original_created_at' },
  { value: 'imported_at', label: 'Data de importação', description: 'imported_at' },
  { value: 'created_at', label: 'Criação no sistema', description: 'created_at' },
];

export function SimplePurgePanel() {
  const [selectedEntity, setSelectedEntity] = useState<EntityType | null>(null);
  const [endDate, setEndDate] = useState<Date>(new Date('2024-12-31'));
  const [dateMode, setDateMode] = useState<DateMode>('document_date');
  const [loading, setLoading] = useState(false);
  const [previewResult, setPreviewResult] = useState<PreviewResult | null>(null);
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  const [confirmText, setConfirmText] = useState('');
  const [executing, setExecuting] = useState(false);

  const handlePreview = async (entity: EntityType) => {
    setLoading(true);
    setSelectedEntity(entity);
    setPreviewResult(null);

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        toast.error('Sessão expirada');
        return;
      }

      const entities = entity === 'clients' 
        ? ['clients', 'buyers', 'interactions'] 
        : ['orders'];

      const { data, error } = await supabase.functions.invoke('execute-purge', {
        body: {
          action: 'preview',
          start_date: null,
          end_date: format(endDate, 'yyyy-MM-dd'),
          entities,
          date_mode: dateMode,
        },
      });

      if (error) throw error;

      if (data?.counts) {
        const counts = data.counts as Record<string, { total: number; to_purge: number }>;
        if (entity === 'clients') {
          const clientCount = counts.clients?.to_purge || 0;
          const buyersCount = counts.buyers?.to_purge || 0;
          const interactionsCount = counts.interactions?.to_purge || 0;
          setPreviewResult({
            total: counts.clients?.total || 0,
            to_purge: clientCount + buyersCount + interactionsCount,
          });
        } else {
          setPreviewResult(counts.orders || { total: 0, to_purge: 0 });
        }
      }
    } catch (err) {
      console.error('Preview error:', err);
      toast.error('Erro ao calcular preview');
    } finally {
      setLoading(false);
    }
  };

  const handleExecute = async () => {
    if (!selectedEntity || confirmText !== 'EXCLUIR') return;

    setExecuting(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        toast.error('Sessão expirada');
        return;
      }

      const entities = selectedEntity === 'clients' 
        ? ['clients', 'buyers', 'interactions'] 
        : ['orders'];

      const { data, error } = await supabase.functions.invoke('execute-purge', {
        body: {
          action: 'execute',
          start_date: null,
          end_date: format(endDate, 'yyyy-MM-dd'),
          entities,
          date_mode: dateMode,
        },
      });

      if (error) throw error;

      if (data?.success) {
        toast.success(`${ENTITY_CONFIG[selectedEntity].label} excluídos com sucesso!`);
        setPreviewResult(null);
        setSelectedEntity(null);
      } else {
        toast.error(data?.error || 'Erro na execução');
      }
    } catch (err) {
      console.error('Execute error:', err);
      toast.error('Erro ao executar exclusão');
    } finally {
      setExecuting(false);
      setShowConfirmDialog(false);
      setConfirmText('');
    }
  };

  const formatDate = (date: Date) => format(date, "dd 'de' MMMM 'de' yyyy", { locale: ptBR });

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Trash2 className="h-5 w-5 text-destructive" />
            Exclusão por Data
          </CardTitle>
          <CardDescription>
            Exclua clientes ou pedidos anteriores a uma data específica
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Date Selection */}
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label>Excluir registros anteriores a:</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      'w-full justify-start text-left font-normal',
                      !endDate && 'text-muted-foreground'
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {endDate ? formatDate(endDate) : 'Selecionar data'}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={endDate}
                    onSelect={(date) => date && setEndDate(date)}
                    locale={ptBR}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>

            <div className="space-y-2">
              <Label>Usar data por:</Label>
              <Select value={dateMode} onValueChange={(v) => setDateMode(v as DateMode)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {DATE_MODE_OPTIONS.map((opt) => (
                    <SelectItem key={opt.value} value={opt.value}>
                      {opt.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Entity Buttons */}
          <div className="grid gap-4 md:grid-cols-2">
            {(Object.keys(ENTITY_CONFIG) as EntityType[]).map((entity) => {
              const config = ENTITY_CONFIG[entity];
              const Icon = config.icon;
              const isSelected = selectedEntity === entity;

              return (
                <Card
                  key={entity}
                  className={cn(
                    'cursor-pointer transition-all hover:shadow-md',
                    isSelected && 'ring-2 ring-primary'
                  )}
                  onClick={() => handlePreview(entity)}
                >
                  <CardContent className="flex items-center gap-4 p-6">
                    <div className={cn('p-3 rounded-full', config.bgColor)}>
                      <Icon className={cn('h-6 w-6', config.color)} />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold">Excluir {config.label}</h3>
                      <p className="text-sm text-muted-foreground">
                        Anteriores a {formatDate(endDate)}
                      </p>
                    </div>
                    {loading && isSelected && (
                      <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* Preview Result */}
          {previewResult && selectedEntity && (
            <Card className="border-destructive/50 bg-destructive/5">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-semibold text-destructive flex items-center gap-2">
                      <AlertTriangle className="h-5 w-5" />
                      Prévia da Exclusão
                    </h4>
                    <p className="text-sm text-muted-foreground mt-1">
                      {selectedEntity === 'clients' ? (
                        <>
                          Serão excluídos <strong>{previewResult.to_purge}</strong> registros
                          (clientes + compradores + interações)
                        </>
                      ) : (
                        <>
                          Serão excluídos <strong>{previewResult.to_purge}</strong> pedidos
                          de um total de {previewResult.total}
                        </>
                      )}
                    </p>
                  </div>
                  <Button
                    variant="destructive"
                    onClick={() => setShowConfirmDialog(true)}
                    disabled={previewResult.to_purge === 0}
                  >
                    <Trash2 className="h-4 w-4 mr-2" />
                    Excluir Agora
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </CardContent>
      </Card>

      {/* Confirmation Dialog */}
      <AlertDialog open={showConfirmDialog} onOpenChange={setShowConfirmDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2 text-destructive">
              <AlertTriangle className="h-5 w-5" />
              Confirmar Exclusão em Massa
            </AlertDialogTitle>
            <AlertDialogDescription className="space-y-3">
              <p>
                Você está prestes a excluir{' '}
                <strong>{previewResult?.to_purge || 0}</strong>{' '}
                {selectedEntity === 'clients' ? 'registros de clientes' : 'pedidos'}{' '}
                anteriores a <strong>{endDate ? formatDate(endDate) : ''}</strong>.
              </p>
              <p className="text-destructive font-medium">
                Esta ação não pode ser desfeita facilmente!
              </p>
              <div className="pt-2">
                <Label htmlFor="confirm">
                  Digite <strong>EXCLUIR</strong> para confirmar:
                </Label>
                <Input
                  id="confirm"
                  value={confirmText}
                  onChange={(e) => setConfirmText(e.target.value.toUpperCase())}
                  placeholder="EXCLUIR"
                  className="mt-2"
                />
              </div>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setConfirmText('')}>
              Cancelar
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={handleExecute}
              disabled={confirmText !== 'EXCLUIR' || executing}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {executing ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Excluindo...
                </>
              ) : (
                'Confirmar Exclusão'
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
