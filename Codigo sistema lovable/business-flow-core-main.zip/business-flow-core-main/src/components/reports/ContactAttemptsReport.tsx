import { useState, useEffect, useMemo } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Loader2, Phone, MessageCircle, CheckCircle2, XCircle, TrendingUp, Users } from 'lucide-react';

interface SellerContactStats {
  sellerId: string;
  sellerName: string;
  // Attempts without response
  whatsappAttempts: number;
  callAttempts: number;
  totalAttempts: number;
  // Effective contacts
  whatsappEffective: number;
  callEffective: number;
  totalEffective: number;
  // Totals
  totalContacts: number;
  effectiveRate: number;
}

interface ContactAttemptsReportProps {
  startDate: string;
  endDate: string;
  sellers: Array<{ id: string; name: string }>;
}

export function ContactAttemptsReport({ startDate, endDate, sellers }: ContactAttemptsReportProps) {
  const [stats, setStats] = useState<SellerContactStats[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchContactStats();
  }, [startDate, endDate, sellers]);

  const fetchContactStats = async () => {
    if (!sellers.length) {
      setStats([]);
      setLoading(false);
      return;
    }

    setLoading(true);
    try {
      // Fetch all interactions in the period
      const { data: interactions, error } = await supabase
        .from('interactions')
        .select('id, interaction_type, responsible_seller_id')
        .gte('interaction_date', startDate)
        .lte('interaction_date', endDate);

      if (error) throw error;

      // Calculate stats per seller
      const sellerStats: SellerContactStats[] = sellers.map(seller => {
        const sellerInteractions = interactions?.filter(i => i.responsible_seller_id === seller.id) || [];

        // Attempts (contains "Tentativa")
        const whatsappAttempts = sellerInteractions.filter(i => 
          i.interaction_type?.toLowerCase().includes('whatsapp') && 
          i.interaction_type?.toLowerCase().includes('tentativa')
        ).length;

        const callAttempts = sellerInteractions.filter(i => 
          (i.interaction_type?.toLowerCase().includes('ligaç') || 
           i.interaction_type?.toLowerCase().includes('ligac')) && 
          i.interaction_type?.toLowerCase().includes('tentativa')
        ).length;

        // Effective contacts (no "Tentativa")
        const whatsappEffective = sellerInteractions.filter(i => 
          i.interaction_type?.toLowerCase().includes('whatsapp') && 
          !i.interaction_type?.toLowerCase().includes('tentativa')
        ).length;

        const callEffective = sellerInteractions.filter(i => 
          (i.interaction_type?.toLowerCase().includes('ligaç') || 
           i.interaction_type?.toLowerCase().includes('ligac')) && 
          !i.interaction_type?.toLowerCase().includes('tentativa')
        ).length;

        const totalAttempts = whatsappAttempts + callAttempts;
        const totalEffective = whatsappEffective + callEffective;
        const totalContacts = totalAttempts + totalEffective;
        const effectiveRate = totalContacts > 0 ? (totalEffective / totalContacts) * 100 : 0;

        return {
          sellerId: seller.id,
          sellerName: seller.name,
          whatsappAttempts,
          callAttempts,
          totalAttempts,
          whatsappEffective,
          callEffective,
          totalEffective,
          totalContacts,
          effectiveRate,
        };
      });

      // Sort by effective rate descending
      sellerStats.sort((a, b) => b.effectiveRate - a.effectiveRate);
      setStats(sellerStats);
    } catch (error) {
      console.error('Error fetching contact stats:', error);
    } finally {
      setLoading(false);
    }
  };

  // Totals across all sellers
  const totals = useMemo(() => {
    return stats.reduce((acc, s) => ({
      whatsappAttempts: acc.whatsappAttempts + s.whatsappAttempts,
      callAttempts: acc.callAttempts + s.callAttempts,
      totalAttempts: acc.totalAttempts + s.totalAttempts,
      whatsappEffective: acc.whatsappEffective + s.whatsappEffective,
      callEffective: acc.callEffective + s.callEffective,
      totalEffective: acc.totalEffective + s.totalEffective,
      totalContacts: acc.totalContacts + s.totalContacts,
    }), {
      whatsappAttempts: 0,
      callAttempts: 0,
      totalAttempts: 0,
      whatsappEffective: 0,
      callEffective: 0,
      totalEffective: 0,
      totalContacts: 0,
    });
  }, [stats]);

  const totalEffectiveRate = totals.totalContacts > 0 
    ? (totals.totalEffective / totals.totalContacts) * 100 
    : 0;

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-green-500" />
              Contatos Efetivos
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-600">{totals.totalEffective}</div>
            <div className="text-xs text-muted-foreground mt-1">
              {totals.whatsappEffective} WhatsApp • {totals.callEffective} Ligações
            </div>
          </CardContent>
        </Card>

        <Card className="border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <XCircle className="h-4 w-4 text-amber-500" />
              Tentativas Sem Resposta
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-amber-600">{totals.totalAttempts}</div>
            <div className="text-xs text-muted-foreground mt-1">
              {totals.whatsappAttempts} WhatsApp • {totals.callAttempts} Ligações
            </div>
          </CardContent>
        </Card>

        <Card className="border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <Users className="h-4 w-4 text-primary" />
              Total de Contatos
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-foreground">{totals.totalContacts}</div>
            <div className="text-xs text-muted-foreground mt-1">
              Efetivos + Tentativas
            </div>
          </CardContent>
        </Card>

        <Card className="border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-primary" />
              Taxa de Sucesso
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-primary">{totalEffectiveRate.toFixed(1)}%</div>
            <Progress value={totalEffectiveRate} className="mt-2 h-2" />
          </CardContent>
        </Card>
      </div>

      {/* Per Seller Breakdown */}
      <Card className="border-border">
        <CardHeader>
          <CardTitle className="text-lg">Desempenho por Vendedor</CardTitle>
        </CardHeader>
        <CardContent>
          {stats.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">
              Nenhum dado de contato encontrado no período selecionado.
            </p>
          ) : (
            <div className="space-y-4">
              {stats.map((seller, index) => (
                <div
                  key={seller.sellerId}
                  className="p-4 rounded-lg border border-border bg-card hover:border-foreground/20 transition-colors"
                >
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-primary/10 border border-primary/20 flex items-center justify-center text-sm font-bold text-primary">
                        {index + 1}
                      </div>
                      <div>
                        <p className="font-semibold text-foreground">{seller.sellerName}</p>
                        <p className="text-xs text-muted-foreground">
                          {seller.totalContacts} contatos no período
                        </p>
                      </div>
                    </div>
                    <Badge
                      variant="outline"
                      className={`${
                        seller.effectiveRate >= 70
                          ? 'bg-green-500/10 text-green-600 border-green-500/20'
                          : seller.effectiveRate >= 40
                          ? 'bg-amber-500/10 text-amber-600 border-amber-500/20'
                          : 'bg-red-500/10 text-red-600 border-red-500/20'
                      }`}
                    >
                      {seller.effectiveRate.toFixed(1)}% sucesso
                    </Badge>
                  </div>

                  {/* Stats Grid */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    {/* WhatsApp Effective */}
                    <div className="flex items-center gap-2 p-2 rounded-lg bg-green-500/5 border border-green-500/10">
                      <MessageCircle className="h-4 w-4 text-green-500" />
                      <div>
                        <p className="text-xs text-muted-foreground">WhatsApp ✓</p>
                        <p className="font-semibold text-green-600">{seller.whatsappEffective}</p>
                      </div>
                    </div>

                    {/* Call Effective */}
                    <div className="flex items-center gap-2 p-2 rounded-lg bg-green-500/5 border border-green-500/10">
                      <Phone className="h-4 w-4 text-green-500" />
                      <div>
                        <p className="text-xs text-muted-foreground">Ligação ✓</p>
                        <p className="font-semibold text-green-600">{seller.callEffective}</p>
                      </div>
                    </div>

                    {/* WhatsApp Attempts */}
                    <div className="flex items-center gap-2 p-2 rounded-lg bg-amber-500/5 border border-amber-500/10">
                      <MessageCircle className="h-4 w-4 text-amber-500" />
                      <div>
                        <p className="text-xs text-muted-foreground">WhatsApp ✗</p>
                        <p className="font-semibold text-amber-600">{seller.whatsappAttempts}</p>
                      </div>
                    </div>

                    {/* Call Attempts */}
                    <div className="flex items-center gap-2 p-2 rounded-lg bg-amber-500/5 border border-amber-500/10">
                      <Phone className="h-4 w-4 text-amber-500" />
                      <div>
                        <p className="text-xs text-muted-foreground">Ligação ✗</p>
                        <p className="font-semibold text-amber-600">{seller.callAttempts}</p>
                      </div>
                    </div>
                  </div>

                  {/* Progress Bar */}
                  <div className="mt-3">
                    <div className="flex justify-between text-xs text-muted-foreground mb-1">
                      <span>Taxa de sucesso</span>
                      <span>{seller.totalEffective} de {seller.totalContacts}</span>
                    </div>
                    <Progress value={seller.effectiveRate} className="h-2" />
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
