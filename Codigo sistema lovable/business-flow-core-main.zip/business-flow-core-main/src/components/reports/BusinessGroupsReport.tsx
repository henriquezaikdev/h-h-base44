import { useState, useEffect, useMemo } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Building2, ChevronDown, ChevronRight, Loader2, Link2, Users } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { useNavigate } from 'react-router-dom';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';

interface Client {
  id: string;
  company_name: string;
  cnpj: string | null;
  total_revenue: number | null;
  status: string;
  related_client_id: string | null;
}

interface BusinessGroup {
  matrix: Client;
  branches: Client[];
  totalRevenue: number;
}

interface BusinessGroupsReportProps {
  sellerId?: string;
}

export function BusinessGroupsReport({ sellerId }: BusinessGroupsReportProps) {
  const navigate = useNavigate();
  const [clients, setClients] = useState<Client[]>([]);
  const [loading, setLoading] = useState(true);
  const [expandedGroups, setExpandedGroups] = useState<Set<string>>(new Set());

  useEffect(() => {
    fetchClients();
  }, [sellerId]);

  const fetchClients = async () => {
    setLoading(true);
    try {
      let query = supabase
        .from('clients')
        .select('id, company_name, cnpj, total_revenue, status, related_client_id, seller_id')
        .eq('is_deleted', false)
        .order('company_name');

      if (sellerId && sellerId !== 'all') {
        query = query.eq('seller_id', sellerId);
      }

      const { data, error } = await query;

      if (error) throw error;
      setClients(data || []);
    } catch (e) {
      console.error('Error fetching clients:', e);
    } finally {
      setLoading(false);
    }
  };

  // Build business groups: matrix → branches
  const businessGroups = useMemo<BusinessGroup[]>(() => {
    const clientMap = new Map<string, Client>();
    clients.forEach(c => clientMap.set(c.id, c));

    // Find all clients that have a related_client_id (branches pointing to matrix)
    const branchesByMatrix = new Map<string, Client[]>();
    const branchIds = new Set<string>();

    clients.forEach(client => {
      if (client.related_client_id) {
        const matrixId = client.related_client_id;
        if (!branchesByMatrix.has(matrixId)) {
          branchesByMatrix.set(matrixId, []);
        }
        branchesByMatrix.get(matrixId)!.push(client);
        branchIds.add(client.id);
      }
    });

    // Build groups: only include matrices that have branches
    const groups: BusinessGroup[] = [];
    
    branchesByMatrix.forEach((branches, matrixId) => {
      const matrix = clientMap.get(matrixId);
      if (matrix) {
        const totalRevenue = (matrix.total_revenue || 0) + 
          branches.reduce((sum, b) => sum + (b.total_revenue || 0), 0);
        
        groups.push({
          matrix,
          branches: branches.sort((a, b) => a.company_name.localeCompare(b.company_name)),
          totalRevenue,
        });
      }
    });

    // Sort by total revenue desc
    return groups.sort((a, b) => b.totalRevenue - a.totalRevenue);
  }, [clients]);

  // Stats
  const stats = useMemo(() => {
    const totalGroups = businessGroups.length;
    const totalBranches = businessGroups.reduce((sum, g) => sum + g.branches.length, 0);
    const totalRevenue = businessGroups.reduce((sum, g) => sum + g.totalRevenue, 0);
    const avgBranchesPerGroup = totalGroups > 0 ? totalBranches / totalGroups : 0;
    
    return { totalGroups, totalBranches, totalRevenue, avgBranchesPerGroup };
  }, [businessGroups]);

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value || 0);
  };

  const formatCNPJ = (cnpj: string | null) => {
    if (!cnpj) return '-';
    const cleaned = cnpj.replace(/\D/g, '');
    if (cleaned.length !== 14) return cnpj;
    return cleaned.replace(
      /^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})$/,
      '$1.$2.$3/$4-$5'
    );
  };

  const toggleGroup = (matrixId: string) => {
    setExpandedGroups(prev => {
      const next = new Set(prev);
      if (next.has(matrixId)) {
        next.delete(matrixId);
      } else {
        next.add(matrixId);
      }
      return next;
    });
  };

  const expandAll = () => {
    setExpandedGroups(new Set(businessGroups.map(g => g.matrix.id)));
  };

  const collapseAll = () => {
    setExpandedGroups(new Set());
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (businessGroups.length === 0) {
    return (
      <div className="card-section text-center py-12">
        <Link2 className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
        <h3 className="text-lg font-semibold text-foreground mb-2">
          Nenhum grupo empresarial encontrado
        </h3>
        <p className="text-muted-foreground">
          Para criar grupos, edite um cliente e selecione a "Empresa Relacionada" (matriz/filial).
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="card-section">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center">
              <Building2 size={24} className="text-primary" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">{stats.totalGroups}</p>
              <p className="text-sm text-muted-foreground">Grupos Empresariais</p>
            </div>
          </div>
        </div>
        
        <div className="card-section">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-status-active/10 rounded-xl flex items-center justify-center">
              <Link2 size={24} className="text-status-active" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">{stats.totalBranches}</p>
              <p className="text-sm text-muted-foreground">Filiais Vinculadas</p>
            </div>
          </div>
        </div>
        
        <div className="card-section">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-accent rounded-xl flex items-center justify-center">
              <Users size={24} className="text-accent-foreground" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">{stats.avgBranchesPerGroup.toFixed(1)}</p>
              <p className="text-sm text-muted-foreground">Média Filiais/Grupo</p>
            </div>
          </div>
        </div>
        
        <div className="card-section">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-hh-orange/10 rounded-xl flex items-center justify-center">
              <span className="text-xl font-bold text-hh-orange">R$</span>
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">{formatCurrency(stats.totalRevenue)}</p>
              <p className="text-sm text-muted-foreground">Faturamento Total</p>
            </div>
          </div>
        </div>
      </div>

      {/* Actions */}
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-foreground">
          Matrizes e Filiais
        </h3>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={expandAll}>
            Expandir Todos
          </Button>
          <Button variant="outline" size="sm" onClick={collapseAll}>
            Recolher Todos
          </Button>
        </div>
      </div>

      {/* Groups Table */}
      <div className="card-section p-0 overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-10"></TableHead>
              <TableHead>Empresa</TableHead>
              <TableHead>CNPJ</TableHead>
              <TableHead className="text-center">Filiais</TableHead>
              <TableHead className="text-right">Faturamento Grupo</TableHead>
              <TableHead>Status</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {businessGroups.map((group) => {
              const isExpanded = expandedGroups.has(group.matrix.id);
              
              return (
                <>
                  {/* Matrix Row */}
                  <TableRow 
                    key={group.matrix.id}
                    className="cursor-pointer hover:bg-muted/50"
                    onClick={() => toggleGroup(group.matrix.id)}
                  >
                    <TableCell>
                      <Button variant="ghost" size="icon" className="h-6 w-6">
                        {isExpanded ? (
                          <ChevronDown size={16} />
                        ) : (
                          <ChevronRight size={16} />
                        )}
                      </Button>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Building2 size={16} className="text-primary" />
                        <span 
                          className="font-medium text-foreground hover:text-primary cursor-pointer"
                          onClick={(e) => {
                            e.stopPropagation();
                            navigate(`/clients/${group.matrix.id}`);
                          }}
                        >
                          {group.matrix.company_name}
                        </span>
                        <Badge variant="outline" className="bg-primary/10 text-primary border-primary/30">
                          Matriz
                        </Badge>
                      </div>
                    </TableCell>
                    <TableCell className="text-muted-foreground">
                      {formatCNPJ(group.matrix.cnpj)}
                    </TableCell>
                    <TableCell className="text-center">
                      <Badge variant="secondary">{group.branches.length}</Badge>
                    </TableCell>
                    <TableCell className="text-right font-semibold text-foreground">
                      {formatCurrency(group.totalRevenue)}
                    </TableCell>
                    <TableCell>
                      <Badge 
                        variant="outline" 
                        className={cn(
                          group.matrix.status === 'ativo' 
                            ? 'bg-status-active/10 text-status-active border-status-active/30'
                            : 'bg-status-inactive/10 text-status-inactive border-status-inactive/30'
                        )}
                      >
                        {group.matrix.status === 'ativo' ? 'Ativo' : 'Inativo'}
                      </Badge>
                    </TableCell>
                  </TableRow>

                  {/* Branch Rows */}
                  {isExpanded && group.branches.map((branch) => (
                    <TableRow 
                      key={branch.id}
                      className="bg-muted/30"
                    >
                      <TableCell></TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2 pl-6">
                          <Link2 size={14} className="text-muted-foreground" />
                          <span 
                            className="text-foreground hover:text-primary cursor-pointer"
                            onClick={() => navigate(`/clients/${branch.id}`)}
                          >
                            {branch.company_name}
                          </span>
                          <Badge variant="outline" className="bg-muted text-muted-foreground">
                            Filial
                          </Badge>
                        </div>
                      </TableCell>
                      <TableCell className="text-muted-foreground">
                        {formatCNPJ(branch.cnpj)}
                      </TableCell>
                      <TableCell></TableCell>
                      <TableCell className="text-right text-muted-foreground">
                        {formatCurrency(branch.total_revenue || 0)}
                      </TableCell>
                      <TableCell>
                        <Badge 
                          variant="outline" 
                          className={cn(
                            branch.status === 'ativo' 
                              ? 'bg-status-active/10 text-status-active border-status-active/30'
                              : 'bg-status-inactive/10 text-status-inactive border-status-inactive/30'
                          )}
                        >
                          {branch.status === 'ativo' ? 'Ativo' : 'Inativo'}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </>
              );
            })}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
