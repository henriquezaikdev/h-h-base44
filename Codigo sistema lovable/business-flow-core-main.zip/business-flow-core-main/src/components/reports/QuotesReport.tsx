import { useState, useEffect, useMemo } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { 
  FileX2, Loader2, User, Building2, TrendingDown,
  DollarSign, Package, BarChart3, Lock
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow 
} from '@/components/ui/table';
import { format, parseISO, startOfMonth, endOfMonth, subMonths, startOfYear, subDays } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { usePeriodFilter } from '@/hooks/usePeriodFilter';
import { PeriodFilter } from '@/components/ui/PeriodFilter';

interface QuotesReportProps {
  sellerId?: string | null;
  isAdmin?: boolean;
  sellers?: { id: string; name: string }[];
  onSellerChange?: (sellerId: string | null) => void;
}

interface QuoteData {
  id: string;
  client_id: string;
  client_name: string;
  quote_number: string;
  quote_date: string;
  total: number;
  loss_reason: string | null;
  seller_id: string | null;
  seller_name: string | null;
  locked_at: string | null;
  items: {
    product_name: string;
    quantity: number;
    unit_price: number;
    subtotal: number;
  }[];
}

const LOSS_REASONS: Record<string, { label: string; color: string }> = {
  preco: { label: 'Preço', color: '#ef4444' },
  prazo: { label: 'Prazo', color: '#f97316' },
  concorrente: { label: 'Concorrente', color: '#eab308' },
  estoque: { label: 'Estoque', color: '#22c55e' },
  sem_retorno: { label: 'Sem Retorno', color: '#6366f1' },
  outro: { label: 'Outro', color: '#a855f7' },
};

// Period filter type removed - using usePeriodFilter hook

export function QuotesReport({ sellerId, isAdmin, sellers, onSellerChange }: QuotesReportProps) {
  const [quotes, setQuotes] = useState<QuoteData[]>([]);
  const [loading, setLoading] = useState(true);
  const periodFilterHook = usePeriodFilter('month', 'quotes-report');

  // Fetch quotes data
  useEffect(() => {
    fetchQuotes();
  }, [sellerId]);

  const fetchQuotes = async () => {
    setLoading(true);
    try {
      let query = supabase
        .from('quotes')
        .select(`
          id,
          client_id,
          quote_number,
          quote_date,
          total,
          loss_reason,
          seller_id,
          locked_at,
          clients(company_name),
          sellers:seller_id(name),
          quote_items(product_name, quantity, unit_price, subtotal)
        `)
        .eq('status', 'perdido')
        .order('quote_date', { ascending: false });

      if (sellerId) {
        query = query.eq('seller_id', sellerId);
      }

      const { data, error } = await query;

      if (error) {
        console.error('Error fetching quotes:', error);
        return;
      }

      if (data) {
        setQuotes(data.map((q: any) => ({
          id: q.id,
          client_id: q.client_id,
          client_name: q.clients?.company_name || 'Cliente não encontrado',
          quote_number: q.quote_number,
          quote_date: q.quote_date,
          total: q.total || 0,
          loss_reason: q.loss_reason,
          seller_id: q.seller_id,
          seller_name: q.sellers?.name || null,
          locked_at: q.locked_at,
          items: q.quote_items || [],
        })));
      }
    } catch (error) {
      console.error('Error fetching quotes:', error);
    } finally {
      setLoading(false);
    }
  };

  // Filter quotes by period
  const filteredQuotes = useMemo(() => {
    const startDate = new Date(periodFilterHook.startDate);
    const endDate = new Date(periodFilterHook.endDate);

    return quotes.filter(q => {
      const quoteDate = parseISO(q.quote_date);
      return quoteDate >= startDate && quoteDate <= endDate;
    });
  }, [quotes, periodFilterHook.startDate, periodFilterHook.endDate]);

  // Analytics - Visão Geral
  const overview = useMemo(() => {
    return {
      totalQuotes: filteredQuotes.length,
      totalValue: filteredQuotes.reduce((sum, q) => sum + q.total, 0),
      lostQuotes: filteredQuotes.filter(q => q.loss_reason).length,
      lostValue: filteredQuotes.reduce((sum, q) => sum + q.total, 0),
    };
  }, [filteredQuotes]);

  // Analytics - Motivos de Perda
  const lossReasonBreakdown = useMemo(() => {
    const breakdown: Record<string, { count: number; value: number }> = {};
    
    filteredQuotes.forEach(q => {
      const reason = q.loss_reason || 'sem_motivo';
      if (!breakdown[reason]) {
        breakdown[reason] = { count: 0, value: 0 };
      }
      breakdown[reason].count++;
      breakdown[reason].value += q.total;
    });

    return Object.entries(breakdown)
      .map(([reason, data]) => ({
        reason,
        label: LOSS_REASONS[reason]?.label || 'Sem Motivo',
        color: LOSS_REASONS[reason]?.color || '#94a3b8',
        ...data,
      }))
      .sort((a, b) => b.value - a.value);
  }, [filteredQuotes]);

  // Analytics - Clientes com mais perdas
  const clientsWithMostLosses = useMemo(() => {
    const clientMap: Record<string, { name: string; count: number; value: number }> = {};
    
    filteredQuotes.forEach(q => {
      if (!clientMap[q.client_id]) {
        clientMap[q.client_id] = { name: q.client_name, count: 0, value: 0 };
      }
      clientMap[q.client_id].count++;
      clientMap[q.client_id].value += q.total;
    });

    return Object.entries(clientMap)
      .map(([id, data]) => ({ id, ...data }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 10);
  }, [filteredQuotes]);

  // Analytics - Itens mais orçados
  const mostQuotedItems = useMemo(() => {
    const itemMap: Record<string, { count: number; totalValue: number; occurrences: number }> = {};
    
    filteredQuotes.forEach(q => {
      q.items.forEach(item => {
        const key = item.product_name.toLowerCase().trim();
        if (!itemMap[key]) {
          itemMap[key] = { count: 0, totalValue: 0, occurrences: 0 };
        }
        itemMap[key].count += item.quantity;
        itemMap[key].totalValue += item.subtotal;
        itemMap[key].occurrences++;
      });
    });

    return Object.entries(itemMap)
      .map(([name, data]) => ({
        name,
        timesQuoted: data.occurrences,
        avgValue: data.occurrences > 0 ? data.totalValue / data.occurrences : 0,
        totalQuantity: data.count,
      }))
      .sort((a, b) => b.timesQuoted - a.timesQuoted)
      .slice(0, 15);
  }, [filteredQuotes]);

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
  };

  if (loading) {
    return (
      <div className="flex justify-center py-12">
        <Loader2 className="animate-spin h-8 w-8 text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Aviso de somente leitura */}
      <div className="flex items-center gap-2 p-3 bg-foreground/5 border border-foreground/10 rounded-lg text-sm text-muted-foreground">
        <Lock className="h-4 w-4" />
        <span>Relatório de leitura. Os dados refletem exatamente os orçamentos salvos. Nenhuma ação é disparada.</span>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-4">
        <PeriodFilter filter={periodFilterHook} />

        {isAdmin && sellers && onSellerChange && (
          <div className="flex items-center gap-2">
            <User size={16} className="text-muted-foreground" />
            <Select 
              value={sellerId || 'all'} 
              onValueChange={(v) => onSellerChange(v === 'all' ? null : v)}
            >
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Todos vendedores" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos vendedores</SelectItem>
                {sellers.map(s => (
                  <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}
      </div>

      {/* Visão Geral */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="border-border">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-foreground/5 rounded-lg border border-foreground/10">
                <FileX2 className="h-5 w-5 text-muted-foreground" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Qtd. Orçamentos</p>
                <p className="text-2xl font-bold">{overview.totalQuotes}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-500/10 rounded-lg border border-blue-500/20">
                <DollarSign className="h-5 w-5 text-blue-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Valor Total Orçado</p>
                <p className="text-2xl font-bold text-blue-600">{formatCurrency(overview.totalValue)}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-red-500/10 rounded-lg border border-red-500/20">
                <TrendingDown className="h-5 w-5 text-red-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Qtd. Perdidos</p>
                <p className="text-2xl font-bold text-red-600">{overview.lostQuotes}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-red-500/10 rounded-lg border border-red-500/20">
                <DollarSign className="h-5 w-5 text-red-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Valor Total Perdido</p>
                <p className="text-2xl font-bold text-red-600">{formatCurrency(overview.lostValue)}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Motivos de Perda */}
      <Card className="border-border">
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <BarChart3 className="h-5 w-5 text-muted-foreground" />
            Motivos de Perda
          </CardTitle>
        </CardHeader>
        <CardContent>
          {lossReasonBreakdown.length > 0 ? (
            <div className="space-y-4">
              <div className="grid grid-cols-2 md:grid-cols-6 gap-4">
                {lossReasonBreakdown.map(item => (
                  <div 
                    key={item.reason}
                    className="p-3 rounded-lg text-center border"
                    style={{ 
                      backgroundColor: item.color + '10', 
                      borderColor: item.color + '30' 
                    }}
                  >
                    <p className="text-2xl font-bold" style={{ color: item.color }}>
                      {item.count}
                    </p>
                    <p className="text-xs text-muted-foreground">{item.label}</p>
                    <p className="text-sm font-medium mt-1" style={{ color: item.color }}>
                      {formatCurrency(item.value)}
                    </p>
                  </div>
                ))}
              </div>
              
              {/* Barra visual */}
              <div className="h-4 rounded-full overflow-hidden flex bg-muted">
                {lossReasonBreakdown.map(item => {
                  const percentage = overview.lostValue > 0 ? (item.value / overview.lostValue) * 100 : 0;
                  return (
                    <div
                      key={item.reason}
                      className="h-full transition-all"
                      style={{ 
                        width: `${percentage}%`,
                        backgroundColor: item.color 
                      }}
                      title={`${item.label}: ${percentage.toFixed(1)}%`}
                    />
                  );
                })}
              </div>
            </div>
          ) : (
            <p className="text-center text-muted-foreground py-8">Nenhum dado disponível</p>
          )}
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Clientes com mais perdas */}
        <Card className="border-border">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Building2 className="h-5 w-5 text-muted-foreground" />
              Clientes com Mais Perdas
            </CardTitle>
          </CardHeader>
          <CardContent>
            {clientsWithMostLosses.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Cliente</TableHead>
                    <TableHead className="text-center">Qtd.</TableHead>
                    <TableHead className="text-right">Valor Perdido</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {clientsWithMostLosses.map((client, idx) => (
                    <TableRow key={client.id}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <span className="w-6 h-6 bg-red-500/10 rounded-full flex items-center justify-center text-xs font-bold text-red-600">
                            {idx + 1}
                          </span>
                          <span className="font-medium truncate max-w-[180px]">{client.name}</span>
                        </div>
                      </TableCell>
                      <TableCell className="text-center">{client.count}</TableCell>
                      <TableCell className="text-right font-semibold text-red-600">
                        {formatCurrency(client.value)}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <p className="text-center text-muted-foreground py-8">Nenhum dado disponível</p>
            )}
          </CardContent>
        </Card>

        {/* Itens mais orçados */}
        <Card className="border-border">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Package className="h-5 w-5 text-muted-foreground" />
              Itens Mais Orçados
            </CardTitle>
          </CardHeader>
          <CardContent>
            {mostQuotedItems.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Descrição</TableHead>
                    <TableHead className="text-center">Vezes</TableHead>
                    <TableHead className="text-right">Valor Médio</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {mostQuotedItems.map((item, idx) => (
                    <TableRow key={idx}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <span className="w-6 h-6 bg-orange-100 dark:bg-orange-900/50 rounded-full flex items-center justify-center text-xs font-bold text-orange-600">
                            {idx + 1}
                          </span>
                          <span className="font-medium truncate max-w-[180px] capitalize">{item.name}</span>
                        </div>
                      </TableCell>
                      <TableCell className="text-center">{item.timesQuoted}x</TableCell>
                      <TableCell className="text-right font-semibold">
                        {formatCurrency(item.avgValue)}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <p className="text-center text-muted-foreground py-8">Nenhum dado disponível</p>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
