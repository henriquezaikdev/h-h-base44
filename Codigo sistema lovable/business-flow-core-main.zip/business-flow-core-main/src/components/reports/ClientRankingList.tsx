import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Building2, ChevronRight, ChevronDown, ChevronUp, 
  Search, Download, Phone, MessageSquare, ExternalLink 
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

interface Client {
  id: string;
  company_name: string;
  period_revenue: number;
  period_orders: number;
  total_revenue: number;
  status: string;
  ranking_tier: string;
}

interface ClientRankingListProps {
  clients: Client[];
  onClientClick: (clientId: string) => void;
  formatCurrency: (value: number) => string;
  filterLabel: string;
}

export function ClientRankingList({
  clients,
  onClientClick,
  formatCurrency,
  filterLabel,
}: ClientRankingListProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [sortField, setSortField] = useState<'revenue' | 'orders' | 'name'>('revenue');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const filteredClients = clients.filter(client =>
    client.company_name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const sortedClients = [...filteredClients].sort((a, b) => {
    const direction = sortDirection === 'asc' ? 1 : -1;
    if (sortField === 'revenue') return (b.period_revenue - a.period_revenue) * direction;
    if (sortField === 'orders') return (b.period_orders - a.period_orders) * direction;
    return a.company_name.localeCompare(b.company_name) * direction;
  });

  const handleSort = (field: 'revenue' | 'orders' | 'name') => {
    if (sortField === field) {
      setSortDirection(prev => prev === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('desc');
    }
  };

  const getRankBadge = (index: number) => {
    const badges = [
      { emoji: '🥇', bg: 'bg-gradient-to-br from-yellow-400 to-amber-500', text: 'text-white' },
      { emoji: '🥈', bg: 'bg-gradient-to-br from-gray-300 to-gray-400', text: 'text-white' },
      { emoji: '🥉', bg: 'bg-gradient-to-br from-orange-400 to-orange-500', text: 'text-white' },
    ];

    if (index < 3) {
      return (
        <span className={cn(
          "w-10 h-10 rounded-xl flex items-center justify-center text-lg shadow-sm",
          badges[index].bg
        )}>
          {badges[index].emoji}
        </span>
      );
    }

    return (
      <span className="w-10 h-10 bg-muted text-muted-foreground rounded-xl flex items-center justify-center text-sm font-bold">
        #{index + 1}
      </span>
    );
  };

  const getStatusBadge = (status: string) => (
    <Badge
      variant="outline"
      className={cn(
        "text-xs",
        status === 'ativo'
          ? "bg-status-success/10 text-status-success border-status-success/30"
          : "bg-muted text-muted-foreground border-muted"
      )}
    >
      {status === 'ativo' ? 'Ativo' : 'Inativo'}
    </Badge>
  );

  const handleExport = () => {
    const csvContent = [
      ['Posição', 'Empresa', 'Faturamento', 'Pedidos', 'Status'].join(','),
      ...sortedClients.map((client, index) => 
        [index + 1, `"${client.company_name}"`, client.period_revenue, client.period_orders, client.status].join(',')
      )
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `ranking-clientes-${filterLabel.toLowerCase().replace(' ', '-')}.csv`;
    link.click();
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.2 }}
      className={cn(
        "rounded-xl border bg-card overflow-hidden",
        "border-border/60 dark:border-border/40",
        "dark:bg-gradient-to-b dark:from-card dark:to-card/90"
      )}
    >
      {/* Header */}
      <div className="p-4 border-b border-border/60 dark:border-border/40 bg-muted/20 dark:bg-muted/10">
        <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold text-foreground">
              Ranking de Clientes
            </h3>
            <p className="text-sm text-muted-foreground">
              {filteredClients.length} clientes • {filterLabel}
            </p>
          </div>
          <div className="flex gap-2 w-full sm:w-auto">
            <div className="relative flex-1 sm:flex-initial">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Buscar cliente..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9 w-full sm:w-64"
              />
            </div>
            <Button variant="outline" size="icon" onClick={handleExport} title="Exportar CSV">
              <Download className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Sort buttons */}
        <div className="flex gap-2 mt-4">
          {[
            { field: 'revenue' as const, label: 'Faturamento' },
            { field: 'orders' as const, label: 'Pedidos' },
            { field: 'name' as const, label: 'Nome' },
          ].map(({ field, label }) => (
            <Button
              key={field}
              variant={sortField === field ? "default" : "outline"}
              size="sm"
              onClick={() => handleSort(field)}
              className="gap-1"
            >
              {label}
              {sortField === field && (
                sortDirection === 'desc' ? <ChevronDown className="h-3 w-3" /> : <ChevronUp className="h-3 w-3" />
              )}
            </Button>
          ))}
        </div>
      </div>

      {/* List */}
      <div className="divide-y divide-border/60 dark:divide-border/40 max-h-[600px] overflow-y-auto">
        <AnimatePresence>
          {sortedClients.map((client, index) => (
            <motion.div
              key={client.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              transition={{ delay: Math.min(index * 0.02, 0.5) }}
              className={cn(
                "group transition-colors",
                expandedId === client.id ? "bg-primary/5" : "hover:bg-muted/30"
              )}
            >
              <div
                className="flex items-center gap-4 p-4 cursor-pointer"
                onClick={() => setExpandedId(expandedId === client.id ? null : client.id)}
              >
                {getRankBadge(index)}
                
                <div className="w-10 h-10 bg-muted rounded-lg flex items-center justify-center shrink-0">
                  <Building2 className="h-5 w-5 text-muted-foreground" />
                </div>

                <div className="flex-1 min-w-0">
                  <p className="font-medium text-foreground truncate">{client.company_name}</p>
                  <p className="text-sm text-muted-foreground">
                    {client.period_orders} {client.period_orders === 1 ? 'pedido' : 'pedidos'} no período
                  </p>
                </div>

                <div className="text-right hidden sm:block">
                  <p className="font-semibold text-foreground">{formatCurrency(client.period_revenue)}</p>
                  <p className="text-xs text-muted-foreground">no período</p>
                </div>

                {getStatusBadge(client.status)}

                <ChevronRight className={cn(
                  "h-5 w-5 text-muted-foreground transition-transform",
                  expandedId === client.id && "rotate-90"
                )} />
              </div>

              {/* Expanded content */}
              <AnimatePresence>
                {expandedId === client.id && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="overflow-hidden"
                  >
                    <div className="px-4 pb-4 ml-14 flex flex-wrap gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation();
                          onClientClick(client.id);
                        }}
                        className="gap-2"
                      >
                        <ExternalLink className="h-4 w-4" />
                        Ver Detalhes
                      </Button>
                      <Button variant="outline" size="sm" className="gap-2">
                        <Phone className="h-4 w-4" />
                        Ligar
                      </Button>
                      <Button variant="outline" size="sm" className="gap-2">
                        <MessageSquare className="h-4 w-4" />
                        WhatsApp
                      </Button>
                      <div className="flex-1 text-right sm:hidden">
                        <p className="font-semibold text-foreground">{formatCurrency(client.period_revenue)}</p>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ))}
        </AnimatePresence>

        {sortedClients.length === 0 && (
          <div className="text-center py-12 text-muted-foreground">
            <Search className="h-8 w-8 mx-auto mb-2 opacity-50" />
            <p>Nenhum cliente encontrado</p>
          </div>
        )}
      </div>
    </motion.div>
  );
}
