import { useState, useEffect, useMemo } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { format, subMonths, startOfMonth, endOfMonth } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { Loader2 } from 'lucide-react';

interface MonthData {
  month: string;
  monthLabel: string;
  top20: number;
  top100: number;
  top200: number;
  outros: number;
}

interface RankingEvolutionChartProps {
  sellerId?: string;
}

export function RankingEvolutionChart({ sellerId }: RankingEvolutionChartProps) {
  const [data, setData] = useState<MonthData[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchEvolutionData();
  }, [sellerId]);

  const fetchEvolutionData = async () => {
    setLoading(true);
    try {
      const now = new Date();
      const months: MonthData[] = [];

      // Fetch last 6 months
      for (let i = 5; i >= 0; i--) {
        const monthDate = subMonths(now, i);
        const startDate = format(startOfMonth(monthDate), 'yyyy-MM-dd');
        const endDate = format(endOfMonth(monthDate), 'yyyy-MM-dd');
        const monthLabel = format(monthDate, 'MMM/yy', { locale: ptBR });

        // Fetch orders for this month
        let ordersQuery = supabase
          .from('orders')
          .select('client_id, total')
          .gte('order_date', startDate)
          .lte('order_date', endDate);

        if (sellerId && sellerId !== 'all') {
          ordersQuery = ordersQuery.eq('seller_id', sellerId);
        }

        const { data: ordersData } = await ordersQuery;

        // Fetch clients with their total revenue (for ranking)
        let clientsQuery = supabase
          .from('clients')
          .select('id, total_revenue')
          .eq('is_deleted', false);

        if (sellerId && sellerId !== 'all') {
          clientsQuery = clientsQuery.eq('seller_id', sellerId);
        }

        const { data: clientsData } = await clientsQuery.order('total_revenue', { ascending: false });

        if (ordersData && clientsData) {
          // Create client ranking map
          const clientRankMap = new Map<string, number>();
          clientsData.forEach((c, idx) => {
            clientRankMap.set(c.id, idx);
          });

          // Calculate revenue by ranking tier
          let top20Rev = 0, top100Rev = 0, top200Rev = 0, outrosRev = 0;

          ordersData.forEach(order => {
            const rank = clientRankMap.get(order.client_id);
            const total = Number(order.total || 0);

            if (rank !== undefined) {
              if (rank < 20) {
                top20Rev += total;
              } else if (rank < 100) {
                top100Rev += total;
              } else if (rank < 200) {
                top200Rev += total;
              } else {
                outrosRev += total;
              }
            } else {
              outrosRev += total;
            }
          });

          months.push({
            month: startDate,
            monthLabel,
            top20: top20Rev,
            top100: top100Rev,
            top200: top200Rev,
            outros: outrosRev,
          });
        }
      }

      setData(months);
    } catch (error) {
      console.error('Error fetching evolution data:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (value: number) => {
    if (value >= 1000000) {
      return `R$ ${(value / 1000000).toFixed(1)}M`;
    }
    if (value >= 1000) {
      return `R$ ${(value / 1000).toFixed(0)}K`;
    }
    return `R$ ${value.toFixed(0)}`;
  };

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-background border border-border rounded-lg p-3 shadow-lg">
          <p className="font-medium text-foreground mb-2">{label}</p>
          {payload.map((entry: any, index: number) => (
            <div key={index} className="flex items-center gap-2 text-sm">
              <div 
                className="w-3 h-3 rounded-full" 
                style={{ backgroundColor: entry.color }}
              />
              <span className="text-muted-foreground">{entry.name}:</span>
              <span className="font-medium text-foreground">
                {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(entry.value)}
              </span>
            </div>
          ))}
        </div>
      );
    }
    return null;
  };

  if (loading) {
    return (
      <div className="card-section">
        <div className="flex items-center justify-center py-12">
          <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
        </div>
      </div>
    );
  }

  return (
    <div className="card-section">
      <h3 className="text-lg font-semibold text-foreground mb-4">
        Evolução do Faturamento por Ranking (Últimos 6 meses)
      </h3>
      <div className="h-[300px]">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
            <defs>
              <linearGradient id="colorTop20" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3} />
                <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0} />
              </linearGradient>
              <linearGradient id="colorTop100" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#f97316" stopOpacity={0.3} />
                <stop offset="95%" stopColor="#f97316" stopOpacity={0} />
              </linearGradient>
              <linearGradient id="colorTop200" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3} />
                <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
              </linearGradient>
              <linearGradient id="colorOutros" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#6b7280" stopOpacity={0.3} />
                <stop offset="95%" stopColor="#6b7280" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
            <XAxis 
              dataKey="monthLabel" 
              tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 12 }}
              axisLine={{ stroke: 'hsl(var(--border))' }}
            />
            <YAxis 
              tickFormatter={formatCurrency}
              tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 12 }}
              axisLine={{ stroke: 'hsl(var(--border))' }}
            />
            <Tooltip content={<CustomTooltip />} />
            <Legend 
              wrapperStyle={{ paddingTop: '10px' }}
              formatter={(value) => <span className="text-sm text-foreground">{value}</span>}
            />
            <Area
              type="monotone"
              dataKey="top20"
              name="⭐ Top 20"
              stroke="hsl(var(--primary))"
              fillOpacity={1}
              fill="url(#colorTop20)"
              strokeWidth={2}
            />
            <Area
              type="monotone"
              dataKey="top100"
              name="💎 Top 21-100"
              stroke="#f97316"
              fillOpacity={1}
              fill="url(#colorTop100)"
              strokeWidth={2}
            />
            <Area
              type="monotone"
              dataKey="top200"
              name="🏆 Top 101-200"
              stroke="#3b82f6"
              fillOpacity={1}
              fill="url(#colorTop200)"
              strokeWidth={2}
            />
            <Area
              type="monotone"
              dataKey="outros"
              name="📊 Demais"
              stroke="#6b7280"
              fillOpacity={1}
              fill="url(#colorOutros)"
              strokeWidth={2}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
