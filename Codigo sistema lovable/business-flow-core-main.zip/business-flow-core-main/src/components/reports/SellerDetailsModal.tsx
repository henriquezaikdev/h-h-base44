import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Phone, MessageSquare, Mail, TrendingUp, Target, CheckCircle2, Users, BarChart3 } from 'lucide-react';

interface SellerMetrics {
  seller_id: string;
  seller_name: string;
  seller_role: string;
  ligacoes: number;
  whatsapp: number;
  emails: number;
  visitas: number;
  total_contatos: number;
  total_pedidos: number;
  faturamento_total: number;
  ticket_medio: number;
  tarefas_concluidas: number;
  tarefas_pendentes: number;
  perc_tarefas_concluidas: number;
}

interface SellerDetailsModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  seller: SellerMetrics | null;
  periodLabel: string;
}

export function SellerDetailsModal({ open, onOpenChange, seller, periodLabel }: SellerDetailsModalProps) {
  if (!seller) return null;

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
  };

  const totalTarefas = seller.tarefas_concluidas + seller.tarefas_pendentes;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-3">
            <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
              <Users className="h-5 w-5 text-primary" />
            </div>
            <div>
              <span>{seller.seller_name}</span>
              <Badge variant="outline" className="ml-2">
                {seller.seller_role === 'admin' ? 'Administrador' : 'Vendedor'}
              </Badge>
            </div>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Period Info */}
          <div className="text-center p-3 bg-muted/50 rounded-lg">
            <p className="text-sm text-muted-foreground">Período analisado</p>
            <p className="font-medium capitalize">{periodLabel}</p>
          </div>

          {/* Activity Section */}
          <div className="space-y-4">
            <h4 className="font-semibold flex items-center gap-2 text-teal-600">
              <Phone className="h-4 w-4" />
              Atividade de Contato
            </h4>
            
            <div className="grid grid-cols-2 gap-3">
              <div className="p-4 bg-blue-50 dark:bg-blue-950/30 rounded-lg border border-blue-200 dark:border-blue-800">
                <div className="flex items-center gap-2 text-blue-600">
                  <Phone className="h-4 w-4" />
                  <span className="text-sm">Ligações</span>
                </div>
                <p className="text-2xl font-bold text-blue-700 mt-1">{seller.ligacoes}</p>
              </div>

              <div className="p-4 bg-green-50 dark:bg-green-950/30 rounded-lg border border-green-200 dark:border-green-800">
                <div className="flex items-center gap-2 text-green-600">
                  <MessageSquare className="h-4 w-4" />
                  <span className="text-sm">WhatsApp</span>
                </div>
                <p className="text-2xl font-bold text-green-700 mt-1">{seller.whatsapp}</p>
              </div>

              <div className="p-4 bg-orange-50 dark:bg-orange-950/30 rounded-lg border border-orange-200 dark:border-orange-800">
                <div className="flex items-center gap-2 text-orange-600">
                  <Mail className="h-4 w-4" />
                  <span className="text-sm">E-mails</span>
                </div>
                <p className="text-2xl font-bold text-orange-700 mt-1">{seller.emails}</p>
              </div>

              <div className="p-4 bg-purple-50 dark:bg-purple-950/30 rounded-lg border border-purple-200 dark:border-purple-800">
                <div className="flex items-center gap-2 text-purple-600">
                  <BarChart3 className="h-4 w-4" />
                  <span className="text-sm">Total Contatos</span>
                </div>
                <p className="text-2xl font-bold text-purple-700 mt-1">{seller.total_contatos}</p>
              </div>
            </div>
          </div>

          {/* Sales Section */}
          <div className="space-y-4">
            <h4 className="font-semibold flex items-center gap-2 text-green-600">
              <TrendingUp className="h-4 w-4" />
              Vendas
            </h4>
            
            <div className="grid grid-cols-3 gap-3">
              <div className="p-4 bg-green-50 dark:bg-green-950/30 rounded-lg border border-green-200 dark:border-green-800 text-center">
                <p className="text-sm text-green-600">Faturamento</p>
                <p className="text-lg font-bold text-green-700">{formatCurrency(seller.faturamento_total)}</p>
              </div>

              <div className="p-4 bg-green-50 dark:bg-green-950/30 rounded-lg border border-green-200 dark:border-green-800 text-center">
                <p className="text-sm text-green-600">Pedidos</p>
                <p className="text-lg font-bold text-green-700">{seller.total_pedidos}</p>
              </div>

              <div className="p-4 bg-green-50 dark:bg-green-950/30 rounded-lg border border-green-200 dark:border-green-800 text-center">
                <p className="text-sm text-green-600">Ticket Médio</p>
                <p className="text-lg font-bold text-green-700">{formatCurrency(seller.ticket_medio)}</p>
              </div>
            </div>
          </div>

          {/* Tasks Section */}
          <div className="space-y-4">
            <h4 className="font-semibold flex items-center gap-2 text-amber-600">
              <Target className="h-4 w-4" />
              Execução de Tarefas
            </h4>

            <div className="p-4 bg-muted/50 rounded-lg space-y-3">
              <div className="flex justify-between text-sm">
                <span>Taxa de Execução</span>
                <span className="font-semibold">{seller.perc_tarefas_concluidas.toFixed(0)}%</span>
              </div>
              <Progress value={seller.perc_tarefas_concluidas} className="h-2" />
              
              <div className="flex justify-between text-sm mt-3">
                <div className="flex items-center gap-2 text-green-600">
                  <CheckCircle2 className="h-4 w-4" />
                  <span>{seller.tarefas_concluidas} concluídas</span>
                </div>
                <div className="flex items-center gap-2 text-amber-600">
                  <Target className="h-4 w-4" />
                  <span>{seller.tarefas_pendentes} pendentes</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
