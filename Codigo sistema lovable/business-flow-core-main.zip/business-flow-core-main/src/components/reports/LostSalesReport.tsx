import { useState, useEffect, useMemo, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { 
  FileX2, TrendingDown, Package, Building2, Loader2, 
  BarChart3, PieChart, ArrowDown, ArrowUp, Copy, ShoppingCart, AlertTriangle
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { usePeriodFilter } from '@/hooks/usePeriodFilter';
import { PeriodFilter as PeriodFilterComponent } from '@/components/ui/PeriodFilter';
import { toast } from 'sonner';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { ScrollArea } from '@/components/ui/scroll-area';
import { format, startOfMonth, endOfMonth, subMonths, startOfYear, subDays } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart as RechartsPieChart,
  Pie,
  Cell,
  Legend,
  LineChart,
  Line
} from 'recharts';

const LOSS_REASONS_MAP: Record<string, { label: string; color: string }> = {
  'preco': { label: 'Preço', color: '#ef4444' },
  'prazo': { label: 'Prazo de entrega', color: '#f97316' },
  'estoque': { label: 'Falta de estoque', color: '#eab308' },
  'concorrente': { label: 'Concorrente', color: '#8b5cf6' },
  'sem_retorno': { label: 'Sem retorno', color: '#6b7280' },
  'outros': { label: 'Outros', color: '#3b82f6' },
};

const CATEGORY_COLORS = ['#3B5BDB', '#ef4444', '#f97316', '#eab308', '#22c55e', '#8b5cf6', '#06b6d4', '#ec4899'];

interface Quote {
  id: string;
  quote_number: string;
  quote_date: string;
  total: number;
  loss_reason: string | null;
  competitor: string | null;
  client: {
    id: string;
    company_name: string;
  };
}

interface QuoteItem {
  id: string;
  product_name: string;
  quantity: number;
  unit_price: number;
  subtotal: number;
  codigo_ca: string | null;
  category?: string | null;
  quote: {
    id: string;
    quote_date: string;
    loss_reason: string | null;
    client: {
      company_name: string;
    };
  };
}

interface LostProductSummary {
  product_name: string;
  codigo_ca: string | null;
  total_quantity: number;
  total_value: number;
  occurrences: number;
  clients: string[];
}

interface MonthlyTrend {
  month: string;
  monthLabel: string;
  totalValue: number;
  quotesCount: number;
}

export function LostSalesReport() {
  const [loading, setLoading] = useState(true);
  const [quotes, setQuotes] = useState<Quote[]>([]);
  const [quoteItems, setQuoteItems] = useState<QuoteItem[]>([]);
  const [comparisons, setComparisons] = useState<any[]>([]);
  const periodFilter = usePeriodFilter('month', 'lost-sales');

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const startDate = periodFilter.startDate;
      const endDate = periodFilter.endDate;

      const { data: quotesData, error: quotesError } = await supabase
        .from('quotes')
        .select(`
          id,
          quote_number,
          quote_date,
          total,
          loss_reason,
          competitor,
          client:clients!inner(id, company_name)
        `)
        .eq('status', 'perdido')
        .gte('quote_date', startDate)
        .lte('quote_date', endDate)
        .order('quote_date', { ascending: false });

      if (quotesError) throw quotesError;

      const processedQuotes: Quote[] = (quotesData || []).map(q => ({
        id: q.id,
        quote_number: q.quote_number,
        quote_date: q.quote_date,
        total: q.total,
        loss_reason: q.loss_reason,
        competitor: q.competitor,
        client: Array.isArray(q.client) ? q.client[0] : q.client
      }));

      setQuotes(processedQuotes);

      const quoteIds = processedQuotes.map(q => q.id);
      
      if (quoteIds.length > 0) {
        const { data: itemsData, error: itemsError } = await supabase
          .from('quote_items')
          .select(`
            id,
            product_name,
            quantity,
            unit_price,
            subtotal,
            codigo_ca,
            quote:quotes!inner(
              id,
              quote_date,
              loss_reason,
              client:clients!inner(company_name)
            )
          `)
          .in('quote_id', quoteIds);

        if (itemsError) throw itemsError;

        const processedItems: QuoteItem[] = (itemsData || []).map(item => ({
          id: item.id,
          product_name: item.product_name,
          quantity: item.quantity,
          unit_price: item.unit_price,
          subtotal: item.subtotal,
          codigo_ca: item.codigo_ca,
          category: null,
          quote: {
            id: Array.isArray(item.quote) ? item.quote[0]?.id : item.quote?.id,
            quote_date: Array.isArray(item.quote) ? item.quote[0]?.quote_date : item.quote?.quote_date,
            loss_reason: Array.isArray(item.quote) ? item.quote[0]?.loss_reason : item.quote?.loss_reason,
            client: {
              company_name: Array.isArray(item.quote) 
                ? (Array.isArray(item.quote[0]?.client) ? item.quote[0]?.client[0]?.company_name : item.quote[0]?.client?.company_name)
                : (Array.isArray(item.quote?.client) ? item.quote?.client[0]?.company_name : item.quote?.client?.company_name)
            }
          }
        }));

        setQuoteItems(processedItems);

        // Fetch comparisons for these items
        const itemIds = processedItems.map(i => i.id);
        if (itemIds.length > 0) {
          const { data: compsData } = await supabase
            .from('quote_item_comparisons')
            .select('*')
            .in('quote_item_id', itemIds);
          setComparisons(compsData || []);
        }
      } else {
        setQuoteItems([]);
        setComparisons([]);
      }
    } catch (error) {
      console.error('Error fetching lost sales data:', error);
    } finally {
      setLoading(false);
    }
  }, [periodFilter.startDate, periodFilter.endDate]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  // KPIs
  const totalLostValue = useMemo(() => {
    return quotes.reduce((acc, q) => acc + (q.total || 0), 0);
  }, [quotes]);

  const totalQuotesCount = quotes.length;

  const avgQuoteValue = useMemo(() => {
    if (quotes.length === 0) return 0;
    return totalLostValue / quotes.length;
  }, [totalLostValue, quotes.length]);

  // Loss reasons breakdown
  const reasonsBreakdown = useMemo(() => {
    const breakdown: Record<string, { count: number; value: number }> = {};
    
    quotes.forEach(q => {
      const reason = q.loss_reason || 'sem_retorno';
      if (!breakdown[reason]) {
        breakdown[reason] = { count: 0, value: 0 };
      }
      breakdown[reason].count++;
      breakdown[reason].value += q.total || 0;
    });

    return Object.entries(breakdown)
      .map(([reason, data]) => ({
        reason,
        label: LOSS_REASONS_MAP[reason]?.label || reason,
        color: LOSS_REASONS_MAP[reason]?.color || '#6b7280',
        count: data.count,
        value: data.value,
        percentage: totalQuotesCount > 0 ? (data.count / totalQuotesCount) * 100 : 0
      }))
      .sort((a, b) => b.value - a.value);
  }, [quotes, totalQuotesCount]);

  // Top lost products
  const topLostProducts = useMemo((): LostProductSummary[] => {
    const productMap: Record<string, LostProductSummary> = {};

    quoteItems.forEach(item => {
      const key = item.product_name.toLowerCase().trim();
      
      if (!productMap[key]) {
        productMap[key] = {
          product_name: item.product_name,
          codigo_ca: item.codigo_ca,
          total_quantity: 0,
          total_value: 0,
          occurrences: 0,
          clients: []
        };
      }

      productMap[key].total_quantity += item.quantity;
      productMap[key].total_value += item.subtotal;
      productMap[key].occurrences++;
      
      const clientName = item.quote?.client?.company_name;
      if (clientName && !productMap[key].clients.includes(clientName)) {
        productMap[key].clients.push(clientName);
      }
    });

    return Object.values(productMap)
      .sort((a, b) => b.total_value - a.total_value)
      .slice(0, 15);
  }, [quoteItems]);

  // Top competitors
  const topCompetitors = useMemo(() => {
    const competitorMap: Record<string, { count: number; value: number }> = {};

    quotes.forEach(q => {
      if (q.competitor) {
        const key = q.competitor.toLowerCase().trim();
        if (!competitorMap[key]) {
          competitorMap[key] = { count: 0, value: 0 };
        }
        competitorMap[key].count++;
        competitorMap[key].value += q.total || 0;
      }
    });

    return Object.entries(competitorMap)
      .map(([name, data]) => ({
        name: name.charAt(0).toUpperCase() + name.slice(1),
        count: data.count,
        value: data.value
      }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 10);
  }, [quotes]);

  // Monthly trend
  const monthlyTrend = useMemo((): MonthlyTrend[] => {
    const monthMap: Record<string, { value: number; count: number }> = {};

    quotes.forEach(q => {
      const monthKey = format(new Date(q.quote_date), 'yyyy-MM');
      if (!monthMap[monthKey]) {
        monthMap[monthKey] = { value: 0, count: 0 };
      }
      monthMap[monthKey].value += q.total || 0;
      monthMap[monthKey].count++;
    });

    return Object.entries(monthMap)
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([month, data]) => ({
        month,
        monthLabel: format(new Date(month + '-01'), 'MMM/yy', { locale: ptBR }),
        totalValue: data.value,
        quotesCount: data.count
      }));
  }, [quotes]);

  // Losses by category
  const lossesByCategory = useMemo(() => {
    const catMap: Record<string, number> = {};

    quoteItems.forEach(item => {
      const cat = item.category || 'Sem categoria';
      catMap[cat] = (catMap[cat] || 0) + item.subtotal;
    });

    return Object.entries(catMap)
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 8);
  }, [quoteItems]);

  // Purchasing agenda: items lost by price with competitor comparison
  const purchasingAgenda = useMemo(() => {
    // Filter items from quotes lost due to price
    const priceQuoteIds = new Set(
      quotes.filter(q => q.loss_reason === 'preco').map(q => q.id)
    );

    // Group items by product
    const productMap: Record<string, {
      product_name: string;
      category: string;
      occurrences: number;
      total_value: number;
      avg_hh_price: number;
      total_hh_price: number;
      total_hh_qty: number;
      item_ids: string[];
    }> = {};

    quoteItems.forEach(item => {
      if (!priceQuoteIds.has(item.quote?.id)) return;
      const key = item.product_name.toLowerCase().trim();
      if (!productMap[key]) {
        productMap[key] = {
          product_name: item.product_name,
          category: item.category || 'Sem categoria',
          occurrences: 0,
          total_value: 0,
          avg_hh_price: 0,
          total_hh_price: 0,
          total_hh_qty: 0,
          item_ids: [],
        };
      }
      productMap[key].occurrences++;
      productMap[key].total_value += item.subtotal;
      productMap[key].total_hh_price += item.unit_price * item.quantity;
      productMap[key].total_hh_qty += item.quantity;
      productMap[key].item_ids.push(item.id);
    });

    // Attach comparison data
    return Object.values(productMap)
      .map(p => {
        const relatedComps = comparisons.filter(c => p.item_ids.includes(c.quote_item_id));
        if (relatedComps.length === 0) return null;

        const avgCompPrice = relatedComps.reduce((s: number, c: any) => s + c.preco_concorrente, 0) / relatedComps.length;
        const avgHH = p.total_hh_qty > 0 ? p.total_hh_price / p.total_hh_qty : 0;
        const gap = avgCompPrice > 0 ? ((avgHH - avgCompPrice) / avgCompPrice) * 100 : 0;

        return {
          ...p,
          avg_hh_price: avgHH,
          avg_competitor_price: avgCompPrice,
          gap_percentual: gap,
        };
      })
      .filter(Boolean)
      .sort((a: any, b: any) => b.total_value - a.total_value) as Array<{
        product_name: string;
        category: string;
        occurrences: number;
        total_value: number;
        avg_hh_price: number;
        avg_competitor_price: number;
        gap_percentual: number;
      }>;
  }, [quoteItems, quotes, comparisons]);

  // Top clients with lost sales
  const topClientsLost = useMemo(() => {
    const clientMap: Record<string, { name: string; count: number; value: number }> = {};

    quotes.forEach(q => {
      const clientId = q.client.id;
      if (!clientMap[clientId]) {
        clientMap[clientId] = { name: q.client.company_name, count: 0, value: 0 };
      }
      clientMap[clientId].count++;
      clientMap[clientId].value += q.total || 0;
    });

    return Object.values(clientMap)
      .sort((a, b) => b.value - a.value)
      .slice(0, 10);
  }, [quotes]);

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value || 0);
  };

  const handleCopyForPurchasing = (item: { product_name: string; gap_percentual: number; total_value: number; occurrences: number }) => {
    const text = `${item.product_name} — Gap: ${item.gap_percentual > 0 ? '+' : ''}${item.gap_percentual.toFixed(1)}% — Valor em risco: ${formatCurrency(item.total_value)} — Ocorrências: ${item.occurrences}`;
    navigator.clipboard.writeText(text).then(() => {
      toast.success('Copiado para a área de transferência');
    }).catch(() => {
      toast.error('Não foi possível copiar');
    });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Period Filter */}
      <div className="flex flex-wrap items-center gap-4">
        <PeriodFilterComponent filter={periodFilter} />
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="border-border">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-red-500/10 rounded-lg border border-red-500/20">
                <FileX2 className="h-6 w-6 text-red-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Perdido</p>
                <p className="text-2xl font-bold text-red-600">{formatCurrency(totalLostValue)}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-foreground/5 rounded-lg border border-foreground/10">
                <BarChart3 className="h-6 w-6 text-muted-foreground" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Orçamentos Perdidos</p>
                <p className="text-2xl font-bold">{totalQuotesCount}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-foreground/5 rounded-lg border border-foreground/10">
                <TrendingDown className="h-6 w-6 text-muted-foreground" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Ticket Médio</p>
                <p className="text-2xl font-bold">{formatCurrency(avgQuoteValue)}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-foreground/5 rounded-lg border border-foreground/10">
                <Package className="h-6 w-6 text-muted-foreground" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Itens Perdidos</p>
                <p className="text-2xl font-bold">{quoteItems.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Loss Reasons Pie Chart */}
        <Card className="border-border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <PieChart className="h-5 w-5 text-muted-foreground" />
              Motivos das Perdas
            </CardTitle>
          </CardHeader>
          <CardContent>
            {reasonsBreakdown.length > 0 ? (
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <RechartsPieChart>
                    <Pie
                      data={reasonsBreakdown}
                      dataKey="count"
                      nameKey="label"
                      cx="50%"
                      cy="50%"
                      outerRadius={80}
                      label={({ label, percentage }) => `${label}: ${percentage.toFixed(0)}%`}
                    >
                      {reasonsBreakdown.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip 
                      formatter={(value: number, name: string, props: { payload: { value: number } }) => [
                        `${value} orçamentos (${formatCurrency(props.payload?.value || 0)})`,
                        name
                      ]}
                    />
                    <Legend />
                  </RechartsPieChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="h-64 flex items-center justify-center text-muted-foreground">
                Nenhum dado disponível
              </div>
            )}
          </CardContent>
        </Card>

        {/* Monthly Trend Chart */}
        <Card className="border-border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingDown className="h-5 w-5 text-muted-foreground" />
              Tendência Mensal
            </CardTitle>
          </CardHeader>
          <CardContent>
            {monthlyTrend.length > 0 ? (
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={monthlyTrend}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                    <XAxis dataKey="monthLabel" className="text-xs" />
                    <YAxis 
                      tickFormatter={(value) => `R$ ${(value / 1000).toFixed(0)}k`}
                      className="text-xs"
                    />
                    <Tooltip 
                      formatter={(value: number) => formatCurrency(value)}
                      labelFormatter={(label) => `Mês: ${label}`}
                    />
                    <Bar dataKey="totalValue" name="Valor Perdido" fill="#ef4444" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="h-64 flex items-center justify-center text-muted-foreground">
                Nenhum dado disponível
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Losses by Category Chart */}
      <Card className="border-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5 text-primary" />
            Perdas por Categoria
          </CardTitle>
        </CardHeader>
        <CardContent>
          {lossesByCategory.length > 0 ? (
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={lossesByCategory} layout="vertical" margin={{ left: 20 }}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis 
                    type="number" 
                    tickFormatter={(value) => `R$ ${(value / 1000).toFixed(0)}k`}
                    className="text-xs"
                  />
                  <YAxis 
                    type="category" 
                    dataKey="name" 
                    width={140} 
                    className="text-xs"
                    tick={{ fontSize: 12 }}
                  />
                  <Tooltip formatter={(value: number) => formatCurrency(value)} />
                  <Bar dataKey="value" name="Valor Perdido" radius={[0, 4, 4, 0]}>
                    {lossesByCategory.map((_, index) => (
                      <Cell key={`cat-${index}`} fill={CATEGORY_COLORS[index % CATEGORY_COLORS.length]} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          ) : (
            <div className="h-48 flex items-center justify-center text-muted-foreground">
              Nenhum dado de categoria disponível
            </div>
          )}
        </CardContent>
      </Card>

      {/* Top Lost Products */}
      <Card className="border-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Package className="h-5 w-5 text-red-500" />
            Produtos Mais Perdidos
          </CardTitle>
        </CardHeader>
        <CardContent>
          {topLostProducts.length > 0 ? (
            <ScrollArea className="h-96">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-12">#</TableHead>
                    <TableHead>Produto</TableHead>
                    <TableHead className="text-center">Código CA</TableHead>
                    <TableHead className="text-right">Qtd Total</TableHead>
                    <TableHead className="text-right">Valor Total</TableHead>
                    <TableHead className="text-center">Ocorrências</TableHead>
                    <TableHead className="text-center">Clientes</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {topLostProducts.map((product, index) => (
                    <TableRow key={index}>
                      <TableCell>
                        <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-medium ${
                          index < 3 ? 'bg-red-500/10 text-red-600' : 'bg-foreground/5 text-muted-foreground'
                        }`}>
                          {index + 1}
                        </span>
                      </TableCell>
                      <TableCell className="font-medium max-w-[300px] truncate">
                        {product.product_name}
                      </TableCell>
                      <TableCell className="text-center">
                        {product.codigo_ca ? (
                          <Badge variant="outline">{product.codigo_ca}</Badge>
                        ) : (
                          <span className="text-muted-foreground">—</span>
                        )}
                      </TableCell>
                      <TableCell className="text-right">{product.total_quantity}</TableCell>
                      <TableCell className="text-right font-medium text-red-600">
                        {formatCurrency(product.total_value)}
                      </TableCell>
                      <TableCell className="text-center">{product.occurrences}x</TableCell>
                      <TableCell className="text-center">{product.clients.length}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </ScrollArea>
          ) : (
            <div className="h-32 flex items-center justify-center text-muted-foreground">
              Nenhum item perdido no período
            </div>
          )}
        </CardContent>
      </Card>

      {/* Bottom Row: Clients and Competitors */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top Clients with Lost Sales */}
        <Card className="border-border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Building2 className="h-5 w-5 text-muted-foreground" />
              Clientes com Mais Perdas
            </CardTitle>
          </CardHeader>
          <CardContent>
            {topClientsLost.length > 0 ? (
              <div className="space-y-3">
                {topClientsLost.map((client, index) => (
                  <div key={index} className="flex items-center gap-3">
                    <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-medium ${
                      index < 3 ? 'bg-red-500/10 text-red-600' : 'bg-foreground/5 text-muted-foreground'
                    }`}>
                      {index + 1}
                    </span>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium truncate">{client.name}</p>
                      <p className="text-xs text-muted-foreground">{client.count} orçamentos</p>
                    </div>
                    <span className="font-medium text-red-600">{formatCurrency(client.value)}</span>
                  </div>
                ))}
              </div>
            ) : (
              <div className="h-32 flex items-center justify-center text-muted-foreground">
                Nenhum dado disponível
              </div>
            )}
          </CardContent>
        </Card>

        {/* Top Competitors */}
        <Card className="border-border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingDown className="h-5 w-5 text-purple-500" />
              Concorrentes Citados
            </CardTitle>
          </CardHeader>
          <CardContent>
            {topCompetitors.length > 0 ? (
              <div className="space-y-3">
                {topCompetitors.map((competitor, index) => (
                  <div key={index} className="flex items-center gap-3">
                    <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-medium ${
                      index < 3 ? 'bg-purple-500/10 text-purple-600' : 'bg-foreground/5 text-muted-foreground'
                    }`}>
                      {index + 1}
                    </span>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium truncate">{competitor.name}</p>
                      <p className="text-xs text-muted-foreground">{competitor.count} vendas perdidas</p>
                    </div>
                    <span className="font-medium text-purple-600">{formatCurrency(competitor.value)}</span>
                  </div>
                ))}
              </div>
            ) : (
              <div className="h-32 flex items-center justify-center text-muted-foreground">
                Nenhum concorrente registrado
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Reasons Breakdown Table */}
      <Card className="border-border">
        <CardHeader>
          <CardTitle>Detalhamento por Motivo</CardTitle>
        </CardHeader>
        <CardContent>
          {reasonsBreakdown.length > 0 ? (
            <div className="space-y-4">
              {reasonsBreakdown.map((reason, index) => (
                <div key={index} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span 
                        className="w-3 h-3 rounded-full" 
                        style={{ backgroundColor: reason.color }}
                      />
                      <span className="font-medium">{reason.label}</span>
                      <Badge variant="secondary">{reason.count} orçamentos</Badge>
                    </div>
                    <span className="font-medium">{formatCurrency(reason.value)}</span>
                  </div>
                  <Progress 
                    value={reason.percentage} 
                    className="h-2"
                  />
                </div>
              ))}
            </div>
          ) : (
            <div className="h-32 flex items-center justify-center text-muted-foreground">
              Nenhum dado disponível
            </div>
          )}
        </CardContent>
      </Card>

      {/* Pauta de Compras — Produtos Prioritários */}
      <Card className="border-border border-l-4 border-l-primary">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ShoppingCart className="h-5 w-5 text-primary" />
            Pauta de Compras — Produtos Prioritários
          </CardTitle>
          <p className="text-xs text-muted-foreground mt-1">
            Produtos perdidos por preço com comparativo de concorrente registrado
          </p>
        </CardHeader>
        <CardContent>
          {purchasingAgenda.length === 0 ? (
            <div className="text-center py-8">
              <AlertTriangle className="h-10 w-10 text-muted-foreground/40 mx-auto mb-3" />
              <p className="text-sm text-muted-foreground">
                Registre o preço do concorrente nos itens perdidos para ativar esta análise.
              </p>
            </div>
          ) : (
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-10">#</TableHead>
                    <TableHead>Produto</TableHead>
                    <TableHead className="text-center">Categoria</TableHead>
                    <TableHead className="text-center">Ocorrências</TableHead>
                    <TableHead className="text-center">Gap Médio %</TableHead>
                    <TableHead className="text-right">Valor em Risco</TableHead>
                    <TableHead className="text-center w-[100px]">Ação</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {purchasingAgenda.map((item, idx) => (
                    <TableRow key={idx}>
                      <TableCell>
                        <span className="w-6 h-6 rounded-full bg-primary/10 text-primary flex items-center justify-center text-xs font-medium">
                          {idx + 1}
                        </span>
                      </TableCell>
                      <TableCell className="font-medium">{item.product_name}</TableCell>
                      <TableCell className="text-center">
                        <Badge variant="outline" className="text-xs">{item.category}</Badge>
                      </TableCell>
                      <TableCell className="text-center">
                        <Badge variant="secondary">{item.occurrences}x</Badge>
                      </TableCell>
                      <TableCell className="text-center">
                        {item.gap_percentual > 15 ? (
                          <Badge className="bg-red-500/10 text-red-600 border-red-500/20 text-xs">
                            +{item.gap_percentual.toFixed(1)}%
                          </Badge>
                        ) : item.gap_percentual > 5 ? (
                          <Badge className="bg-yellow-500/10 text-yellow-700 border-yellow-500/20 text-xs">
                            +{item.gap_percentual.toFixed(1)}%
                          </Badge>
                        ) : (
                          <Badge className="bg-foreground/5 text-muted-foreground border-foreground/10 text-xs">
                            {item.gap_percentual > 0 ? '+' : ''}{item.gap_percentual.toFixed(1)}%
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell className="text-right font-bold text-red-600">
                        {formatCurrency(item.total_value)}
                      </TableCell>
                      <TableCell className="text-center">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleCopyForPurchasing(item)}
                          title="Copiar para Compras"
                        >
                          <Copy className="h-4 w-4 mr-1" />
                          <span className="text-xs">Copiar</span>
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
