import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';

interface TierData {
  key: string;
  label: string;
  color: string;
  revenue: number;
  count: number;
  percentage: number;
}

interface ReportTierBreakdownProps {
  tiers: TierData[];
  totalRevenue: number;
  formatCurrency: (value: number) => string;
  onTierClick?: (tierKey: string) => void;
  activeTier?: string;
}

export function ReportTierBreakdown({
  tiers,
  totalRevenue,
  formatCurrency,
  onTierClick,
  activeTier,
}: ReportTierBreakdownProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.1 }}
      className={cn(
        "rounded-xl border bg-card p-6 transition-all",
        "border-border/60 dark:border-border/40",
        "dark:bg-gradient-to-br dark:from-card dark:to-card/80"
      )}
    >
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold text-foreground">Influência por Ranking</h3>
          <p className="text-sm text-muted-foreground">Distribuição do faturamento por tier</p>
        </div>
        <div className="text-right">
          <p className="text-sm text-muted-foreground">Total do período</p>
          <p className="text-xl font-bold text-foreground">{formatCurrency(totalRevenue)}</p>
        </div>
      </div>

      {/* Cards Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        {tiers.map((tier, index) => (
          <motion.button
            key={tier.key}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: index * 0.05 }}
            onClick={() => onTierClick?.(tier.key)}
            className={cn(
              "p-4 rounded-xl border transition-all text-left",
              "ring-1 ring-inset",
              activeTier === tier.key
                ? "border-primary bg-primary/5 shadow-md ring-primary/20 dark:bg-primary/10"
                : "border-border/60 hover:border-primary/30 hover:bg-accent/5 ring-black/5 dark:ring-white/5 dark:border-border/40"
            )}
          >
            <div className="flex items-center gap-2 mb-3">
              <div className={cn("w-3 h-3 rounded-full", tier.color)} />
              <span className="text-sm font-medium text-foreground">{tier.label}</span>
            </div>
            <p className="text-2xl font-bold text-foreground mb-1">
              {tier.percentage.toFixed(1)}%
            </p>
            <p className="text-sm font-medium text-muted-foreground">
              {formatCurrency(tier.revenue)}
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              {tier.count} {tier.count === 1 ? 'cliente' : 'clientes'}
            </p>
          </motion.button>
        ))}
      </div>

      {/* Progress Bar */}
      <div className="relative">
        <div className="h-6 rounded-full overflow-hidden flex bg-muted/50">
          {tiers.map((tier, index) => (
            <Tooltip key={tier.key}>
              <TooltipTrigger asChild>
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${tier.percentage}%` }}
                  transition={{ delay: 0.3 + index * 0.1, duration: 0.5, ease: "easeOut" }}
                  className={cn(
                    "h-full transition-opacity cursor-pointer",
                    tier.color,
                    activeTier && activeTier !== tier.key ? "opacity-40" : "opacity-100"
                  )}
                  onClick={() => onTierClick?.(tier.key)}
                />
              </TooltipTrigger>
              <TooltipContent>
                <div className="text-center">
                  <p className="font-medium">{tier.label}</p>
                  <p className="text-xs">{tier.percentage.toFixed(1)}% • {formatCurrency(tier.revenue)}</p>
                </div>
              </TooltipContent>
            </Tooltip>
          ))}
        </div>

        {/* Percentage labels below bar */}
        <div className="flex mt-2">
          {tiers.map((tier) => (
            <div
              key={tier.key}
              className="text-center text-xs text-muted-foreground"
              style={{ width: `${tier.percentage}%` }}
            >
              {tier.percentage >= 5 && `${tier.percentage.toFixed(0)}%`}
            </div>
          ))}
        </div>
      </div>
    </motion.div>
  );
}
