import { ReactNode } from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, TrendingDown, Minus } from 'lucide-react';
import { cn } from '@/lib/utils';

interface ReportKPICardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon: ReactNode;
  iconBg?: string;
  trend?: {
    value: number;
    label: string;
  };
  className?: string;
  onClick?: () => void;
}

export function ReportKPICard({
  title,
  value,
  subtitle,
  icon,
  iconBg = 'bg-primary/10',
  trend,
  className,
  onClick,
}: ReportKPICardProps) {
  const getTrendIcon = () => {
    if (!trend) return null;
    if (trend.value > 0) return <TrendingUp className="h-3 w-3" />;
    if (trend.value < 0) return <TrendingDown className="h-3 w-3" />;
    return <Minus className="h-3 w-3" />;
  };

  const getTrendColor = () => {
    if (!trend) return '';
    if (trend.value > 0) return 'text-status-success bg-status-success/10';
    if (trend.value < 0) return 'text-status-danger bg-status-danger/10';
    return 'text-muted-foreground bg-muted';
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ scale: onClick ? 1.02 : 1, y: -2 }}
      transition={{ duration: 0.25, ease: "easeOut" }}
      onClick={onClick}
      className={cn(
        "group relative overflow-hidden rounded-xl border bg-card p-5 transition-all duration-300",
        "border-border/60 dark:border-border/40",
        "shadow-sm hover:shadow-md dark:shadow-none",
        "dark:bg-gradient-to-br dark:from-card dark:to-card/80",
        onClick && "cursor-pointer hover:border-primary/40",
        className
      )}
    >
      {/* Background glow effect */}
      <div className="absolute -top-12 -right-12 w-40 h-40 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none">
        <div className={cn(
          "w-full h-full rounded-full blur-3xl",
          iconBg.replace('/10', '/20')
        )} />
      </div>

      {/* Subtle gradient overlay for dark mode */}
      <div className="absolute inset-0 bg-gradient-to-br from-white/[0.02] to-transparent dark:from-white/[0.03] pointer-events-none" />

      <div className="relative flex items-start justify-between gap-4">
        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium text-muted-foreground mb-1.5">{title}</p>
          <p className="text-[22px] font-semibold text-foreground tracking-tight truncate">{value}</p>
          {subtitle && (
            <p className="text-xs text-muted-foreground/80 mt-1.5 line-clamp-2">{subtitle}</p>
          )}
          {trend && (
            <div className={cn(
              "inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold mt-3",
              getTrendColor()
            )}>
              {getTrendIcon()}
              <span>{trend.value > 0 ? '+' : ''}{trend.value.toFixed(1)}%</span>
              <span className="text-muted-foreground/70 font-normal ml-0.5">{trend.label}</span>
            </div>
          )}
        </div>
        <div className={cn(
          "w-12 h-12 rounded-xl flex items-center justify-center shrink-0 transition-transform duration-300 group-hover:scale-110",
          "ring-1 ring-inset ring-black/5 dark:ring-white/10",
          iconBg
        )}>
          {icon}
        </div>
      </div>
    </motion.div>
  );
}
