import { motion } from 'framer-motion';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

interface FilterTab {
  key: string;
  label: string;
  emoji: string;
  percentage: number;
  count?: number;
}

interface ReportFilterTabsProps {
  tabs: FilterTab[];
  activeTab: string;
  onTabChange: (key: string) => void;
}

export function ReportFilterTabs({ tabs, activeTab, onTabChange }: ReportFilterTabsProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex flex-wrap gap-2 p-1.5 bg-muted/50 rounded-xl border border-border"
    >
      {tabs.map((tab, index) => {
        const isActive = activeTab === tab.key;
        return (
          <motion.button
            key={tab.key}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: index * 0.05 }}
            onClick={() => onTabChange(tab.key)}
            className={cn(
              "relative px-4 py-2.5 rounded-lg font-medium text-sm transition-all flex items-center gap-2",
              isActive
                ? "bg-background text-foreground shadow-sm"
                : "text-muted-foreground hover:text-foreground hover:bg-background/50"
            )}
          >
            {isActive && (
              <motion.div
                layoutId="activeTabIndicator"
                className="absolute inset-0 bg-background rounded-lg shadow-sm border border-border"
                transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
              />
            )}
            <span className="relative z-10">{tab.emoji}</span>
            <span className="relative z-10">{tab.label}</span>
            <Badge
              variant="secondary"
              className={cn(
                "relative z-10 text-xs font-medium",
                isActive ? "bg-primary/10 text-primary" : "bg-muted"
              )}
            >
              {tab.percentage.toFixed(0)}%
            </Badge>
            {tab.count !== undefined && (
              <span className="relative z-10 text-xs text-muted-foreground">
                ({tab.count})
              </span>
            )}
          </motion.button>
        );
      })}
    </motion.div>
  );
}
