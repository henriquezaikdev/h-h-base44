import { useState, useEffect, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2, UserPlus, RefreshCw, ChevronRight, Trophy, Sparkles, Heart } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';

interface SellerAcquisitionReportProps {
  sellerId?: string;
}

interface ClientItem {
  id: string;
  company_name: string;
  date: string;
  detail?: string;
  category?: string;
  indicado_por?: string | null;
}

interface SellerGroup {
  sellerId: string;
  sellerName: string;
  clients: ClientItem[];
}

export function SellerAcquisitionReport({ sellerId }: SellerAcquisitionReportProps) {
  const [loading, setLoading] = useState(true);
  const [reactivations, setReactivations] = useState<SellerGroup[]>([]);
  const [newClients, setNewClients] = useState<SellerGroup[]>([]);
  const [expandedSeller, setExpandedSeller] = useState<string | null>(null);
  const [expandedNewSeller, setExpandedNewSeller] = useState<string | null>(null);

  const now = new Date();
  const [selectedMonth, setSelectedMonth] = useState(now.getMonth() + 1);
  const [selectedYear, setSelectedYear] = useState(now.getFullYear());

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const startDate = new Date(selectedYear, selectedMonth - 1, 1).toISOString().split('T')[0];
        const endDate = new Date(selectedYear, selectedMonth, 0).toISOString().split('T')[0];

        const supabaseClient = supabase as any;

        // Fetch new clients: client_category IN ('conquistado', 'indicacao')
        let newClientsQuery = supabaseClient
          .from('clients')
          .select(`
            id,
            company_name,
            first_order_date,
            seller_id,
            client_category,
            indicado_por,
            classified_at,
            sellers!clients_seller_id_fkey(name)
          `)
          .eq('is_deleted', false)
          .in('client_category', ['conquistado', 'indicacao'])
          .gte('first_order_date', startDate)
          .lte('first_order_date', endDate + 'T23:59:59');

        if (sellerId && sellerId !== 'all') {
          newClientsQuery = newClientsQuery.eq('seller_id', sellerId);
        }

        const { data: newClientsData } = await newClientsQuery.order('first_order_date', { ascending: false });

        // Group new clients by seller
        const newClientMap: Record<string, SellerGroup> = {};
        (newClientsData || []).forEach((c: any) => {
          const sid = c.seller_id;
          const sName = (c.sellers as any)?.name || 'Sem vendedor';
          if (!newClientMap[sid]) {
            newClientMap[sid] = { sellerId: sid, sellerName: sName, clients: [] };
          }
          newClientMap[sid].clients.push({
            id: c.id,
            company_name: c.company_name,
            date: c.first_order_date,
            category: c.client_category,
            indicado_por: c.indicado_por,
          });
        });
        setNewClients(Object.values(newClientMap).sort((a, b) => b.clients.length - a.clients.length));

        // Fetch reactivated clients: client_category = 'reativacao'
        let reactivationQuery = supabaseClient
          .from('clients')
          .select(`
            id,
            company_name,
            first_order_date,
            seller_id,
            days_since_last_order,
            classified_at,
            sellers!clients_seller_id_fkey(name)
          `)
          .eq('is_deleted', false)
          .eq('client_category', 'reativacao')
          .gte('classified_at', startDate)
          .lte('classified_at', endDate + 'T23:59:59');

        if (sellerId && sellerId !== 'all') {
          reactivationQuery = reactivationQuery.eq('seller_id', sellerId);
        }

        const { data: reactivationData } = await reactivationQuery.order('classified_at', { ascending: false });

        // Also fetch from client_reactivations table for confirmed ones in period
        let reactivationTableQuery = supabase
          .from('client_reactivations')
          .select(`
            id,
            client_id,
            seller_id,
            reactivation_order_date,
            days_inactive,
            status,
            clients!client_reactivations_client_id_fkey(company_name),
            sellers!client_reactivations_seller_id_fkey(name)
          `)
          .eq('status', 'confirmed')
          .gte('reactivation_order_date', startDate)
          .lte('reactivation_order_date', endDate + 'T23:59:59');

        if (sellerId && sellerId !== 'all') {
          reactivationTableQuery = reactivationTableQuery.eq('seller_id', sellerId);
        }

        const { data: reactivationTableData } = await reactivationTableQuery.order('reactivation_order_date', { ascending: false });

        // Merge both sources, dedup by client_id
        const reactivationMap: Record<string, SellerGroup> = {};
        const seenClientIds = new Set<string>();

        // First from clients table (client_category = 'reativacao')
        (reactivationData || []).forEach((c: any) => {
          const sid = c.seller_id;
          const sName = (c.sellers as any)?.name || 'Sem vendedor';
          if (!reactivationMap[sid]) {
            reactivationMap[sid] = { sellerId: sid, sellerName: sName, clients: [] };
          }
          if (!seenClientIds.has(c.id)) {
            seenClientIds.add(c.id);
            reactivationMap[sid].clients.push({
              id: c.id,
              company_name: c.company_name,
              date: c.classified_at || c.first_order_date,
            });
          }
        });

        // Then from client_reactivations table
        (reactivationTableData || []).forEach((r: any) => {
          const sid = r.seller_id;
          const sName = r.sellers?.name || 'Sem vendedor';
          if (!reactivationMap[sid]) {
            reactivationMap[sid] = { sellerId: sid, sellerName: sName, clients: [] };
          }
          if (!seenClientIds.has(r.client_id)) {
            seenClientIds.add(r.client_id);
            reactivationMap[sid].clients.push({
              id: r.client_id,
              company_name: r.clients?.company_name || 'Cliente',
              date: r.reactivation_order_date,
              detail: `${r.days_inactive} dias inativo`,
            });
          }
        });

        setReactivations(Object.values(reactivationMap).sort((a, b) => b.clients.length - a.clients.length));
      } catch (error) {
        console.error('Error fetching acquisition data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [sellerId, selectedMonth, selectedYear]);

  const totalReactivated = useMemo(() => reactivations.reduce((s, r) => s + r.clients.length, 0), [reactivations]);
  const totalNew = useMemo(() => newClients.reduce((s, r) => s + r.clients.length, 0), [newClients]);
  const totalConquistados = useMemo(() => newClients.reduce((s, r) => s + r.clients.filter(c => c.category === 'conquistado').length, 0), [newClients]);
  const totalIndicacoes = useMemo(() => newClients.reduce((s, r) => s + r.clients.filter(c => c.category === 'indicacao').length, 0), [newClients]);

  const months = [
    { value: 1, label: 'Janeiro' }, { value: 2, label: 'Fevereiro' },
    { value: 3, label: 'Março' }, { value: 4, label: 'Abril' },
    { value: 5, label: 'Maio' }, { value: 6, label: 'Junho' },
    { value: 7, label: 'Julho' }, { value: 8, label: 'Agosto' },
    { value: 9, label: 'Setembro' }, { value: 10, label: 'Outubro' },
    { value: 11, label: 'Novembro' }, { value: 12, label: 'Dezembro' },
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Month/Year selector */}
      <div className="flex items-center gap-3">
        <Select value={String(selectedMonth)} onValueChange={(v) => setSelectedMonth(Number(v))}>
          <SelectTrigger className="w-[150px]"><SelectValue /></SelectTrigger>
          <SelectContent>
            {months.map((m) => (
              <SelectItem key={m.value} value={String(m.value)}>{m.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={String(selectedYear)} onValueChange={(v) => setSelectedYear(Number(v))}>
          <SelectTrigger className="w-[100px]"><SelectValue /></SelectTrigger>
          <SelectContent>
            {[2024, 2025, 2026].map((y) => (
              <SelectItem key={y} value={String(y)}>{y}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Summary KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <Sparkles className="h-8 w-8 text-emerald-500 mx-auto mb-1" />
            <p className="text-2xl font-bold">{totalNew}</p>
            <p className="text-xs text-muted-foreground">Total Novos</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <UserPlus className="h-8 w-8 text-primary mx-auto mb-1" />
            <p className="text-2xl font-bold">{totalConquistados}</p>
            <p className="text-xs text-muted-foreground">Conquistados</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <Heart className="h-8 w-8 text-pink-500 mx-auto mb-1" />
            <p className="text-2xl font-bold">{totalIndicacoes}</p>
            <p className="text-xs text-muted-foreground">Por Indicação</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <RefreshCw className="h-8 w-8 text-blue-500 mx-auto mb-1" />
            <p className="text-2xl font-bold">{totalReactivated}</p>
            <p className="text-xs text-muted-foreground">Reativados</p>
          </CardContent>
        </Card>
      </div>

      {/* New Clients by Seller */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <UserPlus className="h-5 w-5 text-emerald-500" />
            Novos Clientes (Conquistados + Indicações)
            <Badge variant="outline" className="ml-auto">{totalNew}</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {newClients.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-4">Nenhum novo cliente neste período</p>
          ) : (
            newClients.map((group, idx) => {
              const isExpanded = expandedNewSeller === group.sellerId;
              return (
                <div key={group.sellerId} className="space-y-1">
                  <button
                    onClick={() => setExpandedNewSeller(isExpanded ? null : group.sellerId)}
                    className={cn(
                      'w-full flex items-center justify-between p-3 rounded-lg border transition-all hover:shadow-sm',
                      idx === 0 && 'border-emerald-500/30 bg-emerald-500/5'
                    )}
                  >
                    <div className="flex items-center gap-3">
                      {idx === 0 && <Trophy className="h-4 w-4 text-emerald-500" />}
                      <span className="font-medium text-sm">{group.sellerName}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="secondary" className="font-bold">{group.clients.length}</Badge>
                      <ChevronRight className={cn('h-4 w-4 transition-transform', isExpanded && 'rotate-90')} />
                    </div>
                  </button>
                  {isExpanded && (
                    <ScrollArea className="h-[200px] rounded-lg border bg-muted/30 p-2">
                      <div className="space-y-1">
                        {group.clients.map((client) => (
                          <Link
                            key={client.id}
                            to={`/clients/${client.id}`}
                            className="flex items-center justify-between p-2 rounded-md hover:bg-muted transition-colors"
                          >
                            <div className="min-w-0 flex-1">
                              <div className="flex items-center gap-2">
                                <p className="text-sm font-medium truncate">{client.company_name}</p>
                                <Badge variant="outline" className={cn("text-[10px] px-1.5 py-0",
                                  client.category === 'indicacao' 
                                    ? 'border-pink-500/30 text-pink-600 bg-pink-500/5' 
                                    : 'border-emerald-500/30 text-emerald-600 bg-emerald-500/5'
                                )}>
                                  {client.category === 'indicacao' ? 'Indicação' : 'Conquistado'}
                                </Badge>
                              </div>
                              <p className="text-xs text-muted-foreground">
                                1º pedido: {format(new Date(client.date), 'dd/MM/yyyy')}
                                {client.indicado_por && (
                                  <span className="ml-2 text-pink-500">• Indicado por: {client.indicado_por}</span>
                                )}
                              </p>
                            </div>
                            <ChevronRight className="h-4 w-4 text-muted-foreground shrink-0" />
                          </Link>
                        ))}
                      </div>
                    </ScrollArea>
                  )}
                </div>
              );
            })
          )}
        </CardContent>
      </Card>

      {/* Reactivated Clients by Seller */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <RefreshCw className="h-5 w-5 text-blue-500" />
            Inativos Reativados por Vendedor
            <Badge variant="outline" className="ml-auto">{totalReactivated}</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {reactivations.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-4">Nenhuma reativação neste período</p>
          ) : (
            reactivations.map((group, idx) => {
              const isExpanded = expandedSeller === group.sellerId;
              return (
                <div key={group.sellerId} className="space-y-1">
                  <button
                    onClick={() => setExpandedSeller(isExpanded ? null : group.sellerId)}
                    className={cn(
                      'w-full flex items-center justify-between p-3 rounded-lg border transition-all hover:shadow-sm',
                      idx === 0 && 'border-blue-500/30 bg-blue-500/5'
                    )}
                  >
                    <div className="flex items-center gap-3">
                      {idx === 0 && <Trophy className="h-4 w-4 text-blue-500" />}
                      <span className="font-medium text-sm">{group.sellerName}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="secondary" className="font-bold">{group.clients.length}</Badge>
                      <ChevronRight className={cn('h-4 w-4 transition-transform', isExpanded && 'rotate-90')} />
                    </div>
                  </button>
                  {isExpanded && (
                    <ScrollArea className="h-[180px] rounded-lg border bg-muted/30 p-2">
                      <div className="space-y-1">
                        {group.clients.map((client) => (
                          <Link
                            key={client.id}
                            to={`/clients/${client.id}`}
                            className="flex items-center justify-between p-2 rounded-md hover:bg-muted transition-colors"
                          >
                            <div className="min-w-0 flex-1">
                              <p className="text-sm font-medium truncate">{client.company_name}</p>
                              <p className="text-xs text-muted-foreground">
                                {format(new Date(client.date), 'dd/MM/yyyy')}{client.detail ? ` • ${client.detail}` : ''}
                              </p>
                            </div>
                            <ChevronRight className="h-4 w-4 text-muted-foreground shrink-0" />
                          </Link>
                        ))}
                      </div>
                    </ScrollArea>
                  )}
                </div>
              );
            })
          )}
        </CardContent>
      </Card>
    </div>
  );
}
