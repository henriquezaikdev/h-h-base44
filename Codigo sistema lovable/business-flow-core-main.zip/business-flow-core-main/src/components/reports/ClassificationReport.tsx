import { useState, useEffect, useMemo } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { 
  Loader2, Users, AlertTriangle, Tag,
  UserPlus, RefreshCw, Chrome, Building2, Clock, Store
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import { useAuth } from '@/hooks/useAuth';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { 
  ChartContainer, ChartTooltip, ChartTooltipContent 
} from "@/components/ui/chart";
import { BarChart, Bar, XAxis, YAxis, Cell, PieChart, Pie, Legend, ResponsiveContainer } from 'recharts';

const CATEGORY_CONFIG: Record<string, { label: string; color: string; icon: any }> = {
  conquistado: { label: 'Conquistado', color: 'hsl(142, 76%, 36%)', icon: UserPlus },
  indicacao: { label: 'Indicação', color: 'hsl(330, 80%, 60%)', icon: Users },
  google: { label: 'Google', color: 'hsl(217, 91%, 60%)', icon: Chrome },
  reativacao: { label: 'Reativação', color: 'hsl(199, 89%, 48%)', icon: RefreshCw },
  filial: { label: 'Filial', color: 'hsl(262, 52%, 47%)', icon: Building2 },
  janela_longa: { label: 'Janela Longa', color: 'hsl(38, 92%, 50%)', icon: Clock },
  porta_da_loja: { label: 'Porta da Loja', color: 'hsl(25, 95%, 53%)', icon: Store },
  sem_categoria: { label: 'Sem Categoria', color: 'hsl(var(--muted-foreground))', icon: Tag },
};

interface ClassificationReportProps {
  sellerId?: string;
}

export function ClassificationReport({ sellerId }: ClassificationReportProps) {
  const { isAdmin } = useAuth();
  const [loading, setLoading] = useState(true);
  const [categoryData, setCategoryData] = useState<Array<{ key: string; count: number }>>([]);
  const [pendingCount, setPendingCount] = useState(0);
  const [totalClients, setTotalClients] = useState(0);
  const [sellerBreakdown, setSellerBreakdown] = useState<Array<{ sellerName: string; categories: Record<string, number>; total: number }>>([]);

  const fetchData = async () => {
    setLoading(true);
    try {
      const supabaseClient = supabase as any;

      // Fetch all non-deleted clients with relevant fields
      let query = supabaseClient
        .from('clients')
        .select('id, client_category, client_category_sub, classification_status, seller_id, classified_at, first_order_date')
        .eq('is_deleted', false);

      if (sellerId && sellerId !== 'all') {
        query = query.eq('seller_id', sellerId);
      }

      const { data: clients, error } = await query;
      if (error) throw error;

      const allClients = clients || [];

      // Count pending
      const pending = allClients.filter((c: any) => c.classification_status === 'PENDENTE').length;
      setPendingCount(pending);
      setTotalClients(allClients.length);

      // Aggregate by category
      const catCounts: Record<string, number> = {};
      allClients.forEach((c: any) => {
        let cat = c.client_category || 'sem_categoria';
        // Count porta_da_loja as separate category for display
        if (cat === 'google' && c.client_category_sub === 'porta_da_loja') {
          cat = 'porta_da_loja';
        }
        catCounts[cat] = (catCounts[cat] || 0) + 1;
      });

      const catArray = Object.entries(catCounts)
        .map(([key, count]) => ({ key, count }))
        .sort((a, b) => b.count - a.count);
      setCategoryData(catArray);

      // Seller breakdown
      const sellerIds = [...new Set(allClients.map((c: any) => c.seller_id).filter(Boolean))] as string[];
      const sellersMap: Record<string, string> = {};
      if (sellerIds.length > 0) {
        const { data: sellers } = await supabase
          .from('sellers')
          .select('id, name')
          .or('status.eq.ATIVO,status.is.null') as { data: any[] | null };
        (sellers || []).forEach((s: any) => sellersMap[s.id] = s.name);
      }

      const sellerStats: Record<string, { categories: Record<string, number>; total: number }> = {};
      allClients.forEach((c: any) => {
        const sid = c.seller_id || 'sem_vendedor';
        if (!sellerStats[sid]) sellerStats[sid] = { categories: {}, total: 0 };
        let cat = c.client_category || 'sem_categoria';
        if (cat === 'google' && c.client_category_sub === 'porta_da_loja') cat = 'porta_da_loja';
        sellerStats[sid].categories[cat] = (sellerStats[sid].categories[cat] || 0) + 1;
        sellerStats[sid].total += 1;
      });

      const breakdown = Object.entries(sellerStats)
        .map(([sid, data]) => ({
          sellerName: sid === 'sem_vendedor' ? 'Sem Vendedor' : (sellersMap[sid] || 'Desconhecido'),
          categories: data.categories,
          total: data.total,
        }))
        .filter(s => s.sellerName !== 'Desconhecido') // filter out inactive sellers without name
        .sort((a, b) => b.total - a.total);
      setSellerBreakdown(breakdown);

    } catch (e) {
      console.error('Error fetching classification data:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [sellerId]);

  const pieData = useMemo(() => 
    categoryData.map(({ key, count }) => ({
      name: CATEGORY_CONFIG[key]?.label || key,
      value: count,
      fill: CATEGORY_CONFIG[key]?.color || 'hsl(var(--muted-foreground))',
    })),
  [categoryData]);

  const barChartData = useMemo(() =>
    sellerBreakdown.slice(0, 10).map(s => {
      const row: any = { 
        name: s.sellerName.length > 12 ? s.sellerName.substring(0, 12) + '...' : s.sellerName,
        fullName: s.sellerName,
      };
      Object.keys(CATEGORY_CONFIG).forEach(cat => {
        row[cat] = s.categories[cat] || 0;
      });
      return row;
    }),
  [sellerBreakdown]);

  const chartConfig = useMemo(() => {
    const config: Record<string, { label: string; color: string }> = {};
    Object.entries(CATEGORY_CONFIG).forEach(([key, cfg]) => {
      config[key] = { label: cfg.label, color: cfg.color };
    });
    return config;
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Pending Classification Alert */}
      {pendingCount > 0 && (
        <div className="flex items-center gap-3 rounded-lg border border-amber-500/30 bg-amber-500/5 px-4 py-3">
          <div className="flex-shrink-0 w-9 h-9 rounded-lg bg-amber-500/10 flex items-center justify-center">
            <AlertTriangle className="h-4 w-4 text-amber-600 dark:text-amber-400" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-foreground">
              {pendingCount} cliente{pendingCount !== 1 ? 's' : ''} aguardando classificação
            </p>
            <p className="text-xs text-muted-foreground">
              Classifique para contabilizar corretamente nas metas
            </p>
          </div>
          <Badge variant="outline" className="border-amber-500/30 text-amber-600">
            PENDENTE
          </Badge>
        </div>
      )}

      {/* Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="card-section">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center">
              <Users size={24} className="text-primary" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">{totalClients}</p>
              <p className="text-sm text-muted-foreground">Total de Clientes</p>
            </div>
          </div>
        </div>
        {categoryData.slice(0, 3).map(({ key, count }) => {
          const cfg = CATEGORY_CONFIG[key] || CATEGORY_CONFIG.sem_categoria;
          const Icon = cfg.icon;
          return (
            <div key={key} className="card-section">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl flex items-center justify-center" style={{ backgroundColor: `${cfg.color}15` }}>
                  <Icon size={24} style={{ color: cfg.color }} />
                </div>
                <div>
                  <p className="text-2xl font-bold text-foreground">{count}</p>
                  <p className="text-sm text-muted-foreground">{cfg.label}</p>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Pie Chart */}
        <div className="card-section">
          <h3 className="text-lg font-semibold text-foreground mb-4">Distribuição por Categoria</h3>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  paddingAngle={2}
                  dataKey="value"
                  label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Pie>
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Bar Chart by Seller */}
        <div className="card-section">
          <h3 className="text-lg font-semibold text-foreground mb-4">Por Vendedor (Top 10)</h3>
          <div className="h-[300px]">
            <ChartContainer config={chartConfig}>
              <BarChart data={barChartData} layout="vertical">
                <XAxis type="number" />
                <YAxis dataKey="name" type="category" width={100} tick={{ fontSize: 12 }} />
                <ChartTooltip content={<ChartTooltipContent />} />
                {Object.keys(CATEGORY_CONFIG).map((cat, i) => (
                  <Bar key={cat} dataKey={cat} stackId="a" fill={CATEGORY_CONFIG[cat].color} radius={i === Object.keys(CATEGORY_CONFIG).length - 1 ? [0, 4, 4, 0] : [0, 0, 0, 0]} />
                ))}
              </BarChart>
            </ChartContainer>
          </div>
        </div>
      </div>

      {/* Distribution Table */}
      <div className="card-section">
        <h3 className="text-lg font-semibold text-foreground mb-4">Detalhamento por Categoria</h3>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Categoria</TableHead>
                <TableHead className="text-center">Quantidade</TableHead>
                <TableHead className="text-center">Percentual</TableHead>
                <TableHead className="w-[200px]">Distribuição</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {categoryData.map(({ key, count }) => {
                const cfg = CATEGORY_CONFIG[key] || CATEGORY_CONFIG.sem_categoria;
                const Icon = cfg.icon;
                const pct = totalClients > 0 ? (count / totalClients) * 100 : 0;
                return (
                  <TableRow key={key}>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Icon size={16} style={{ color: cfg.color }} />
                        <span className="font-medium">{cfg.label}</span>
                      </div>
                    </TableCell>
                    <TableCell className="text-center">
                      <Badge variant="outline">{count}</Badge>
                    </TableCell>
                    <TableCell className="text-center">
                      <span className="font-semibold">{pct.toFixed(1)}%</span>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <div className="flex-1 h-3 bg-muted rounded-full overflow-hidden">
                          <div 
                            className="h-full transition-all rounded-full"
                            style={{ width: `${pct}%`, backgroundColor: cfg.color }}
                          />
                        </div>
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })}
              {categoryData.length === 0 && (
                <TableRow>
                  <TableCell colSpan={4} className="text-center py-8 text-muted-foreground">
                    Nenhum dado encontrado
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </div>

      {/* Seller Breakdown Table */}
      {sellerBreakdown.length > 0 && (
        <div className="card-section">
          <h3 className="text-lg font-semibold text-foreground mb-4">Detalhamento por Vendedor</h3>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Vendedor</TableHead>
                  <TableHead className="text-center">Total</TableHead>
                  {Object.entries(CATEGORY_CONFIG).filter(([key]) => key !== 'sem_categoria').map(([key, cfg]) => (
                    <TableHead key={key} className="text-center">
                      <span className="flex items-center justify-center gap-1 text-xs">
                        <cfg.icon size={12} style={{ color: cfg.color }} />
                        {cfg.label}
                      </span>
                    </TableHead>
                  ))}
                </TableRow>
              </TableHeader>
              <TableBody>
                {sellerBreakdown.map((seller) => (
                  <TableRow key={seller.sellerName}>
                    <TableCell className="font-medium">{seller.sellerName}</TableCell>
                    <TableCell className="text-center">
                      <Badge variant="outline">{seller.total}</Badge>
                    </TableCell>
                    {Object.keys(CATEGORY_CONFIG).filter(key => key !== 'sem_categoria').map(cat => (
                      <TableCell key={cat} className="text-center">
                        {seller.categories[cat] ? (
                          <Badge variant="secondary" className="text-xs">
                            {seller.categories[cat]}
                          </Badge>
                        ) : (
                          <span className="text-muted-foreground text-xs">-</span>
                        )}
                      </TableCell>
                    ))}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </div>
      )}
    </div>
  );
}
