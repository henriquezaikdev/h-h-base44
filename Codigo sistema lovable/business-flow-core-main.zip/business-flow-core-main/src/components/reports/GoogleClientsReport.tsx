import { useState, useEffect, useMemo } from 'react';
import { motion } from 'framer-motion';
import { Chrome, Calendar, TrendingUp, Users, Building2, ChevronDown, ChevronUp, Percent, DollarSign, Store } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { ReportKPICard } from './ReportKPICard';
import { cn } from '@/lib/utils';

interface GoogleClient {
  id: string;
  companyName: string;
  sellerName: string;
  firstOrderDate: string;
  verifiedAt: string;
  totalRevenue: number;
  orderCount: number;
  totalProfit: number;
  marginPercent: number;
  subCategory: string | null; // 'porta_da_loja' or null
}

interface MonthlyData {
  month: number;
  year: number;
  label: string;
  count: number;
  clients: GoogleClient[];
  expanded: boolean;
}

const MONTH_NAMES = [
  'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
  'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
];

function formatCurrency(value: number): string {
  return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
}

interface GoogleClientsReportProps {
  sellerId?: string;
}

export function GoogleClientsReport({ sellerId }: GoogleClientsReportProps) {
  const { isAdmin } = useAuth();
  const [loading, setLoading] = useState(true);
  const [clients, setClients] = useState<GoogleClient[]>([]);
  const [expandedMonths, setExpandedMonths] = useState<Set<string>>(new Set());

  useEffect(() => {
    fetchGoogleClients();
  }, [sellerId]);

  async function fetchGoogleClients() {
    setLoading(true);
    try {
      const supabaseClient = supabase as any;
      
      let query = supabaseClient
        .from('clients')
        .select('id, company_name, first_order_date, new_client_verified_at, seller_id, client_category_sub')
        .eq('client_category', 'google')
        .eq('is_deleted', false);

      if (sellerId && sellerId !== 'all') {
        query = query.eq('seller_id', sellerId);
      }

      const response = await query.order('new_client_verified_at', { ascending: false });
        
      const clientsData: any[] = response.data || [];
      const clientsError = response.error;

      if (clientsError) throw clientsError;

      // Fetch sellers
      const sellerIds = [...new Set((clientsData || []).map((c: any) => c.seller_id).filter(Boolean))] as string[];
      const sellersMap: Record<string, string> = {};
      
      if (sellerIds.length > 0) {
        const { data: sellersData } = await supabase
          .from('sellers')
          .select('id, name')
          .in('id', sellerIds) as { data: any[] | null };
        
        (sellersData || []).forEach((s: any) => {
          sellersMap[s.id] = s.name;
        });
      }

      // Fetch orders for each client to calculate profit
      const clientIds = clientsData.map((c: any) => c.id);
      
      const { data: ordersRaw } = await supabaseClient
        .from('orders')
        .select('id, client_id, total')
        .in('client_id', clientIds)
        .eq('is_deleted', false);
      
      const orders = ordersRaw || [];
      const orderIds = orders.map((o: any) => o.id);
      
      let itemsData: any[] = [];
      if (orderIds.length > 0) {
        const { data: items } = await supabaseClient
          .from('order_items')
          .select('order_id, subtotal, cost_subtotal')
          .in('order_id', orderIds)
          .eq('is_deleted', false);
        
        itemsData = items || [];
      }

      const orderProfitMap = new Map<string, { revenue: number; profit: number }>();
      orders.forEach((o: any) => {
        orderProfitMap.set(o.id, { revenue: o.total || 0, profit: 0 });
      });

      itemsData.forEach((item: any) => {
        const current = orderProfitMap.get(item.order_id);
        if (current) {
          const profit = (item.subtotal || 0) - (item.cost_subtotal || 0);
          current.profit += profit;
        }
      });

      const clientStatsMap = new Map<string, { revenue: number; profit: number; count: number }>();
      orders.forEach((o: any) => {
        const current = clientStatsMap.get(o.client_id) || { revenue: 0, profit: 0, count: 0 };
        const orderData = orderProfitMap.get(o.id);
        if (orderData) {
          current.revenue += orderData.revenue;
          current.profit += orderData.profit;
          current.count += 1;
        }
        clientStatsMap.set(o.client_id, current);
      });

      const mapped: GoogleClient[] = (clientsData || []).map((c: any) => {
        const stats = clientStatsMap.get(c.id) || { revenue: 0, profit: 0, count: 0 };
        const marginPercent = stats.revenue > 0 ? (stats.profit / stats.revenue) * 100 : 0;
        
        return {
          id: c.id,
          companyName: c.company_name,
          sellerName: c.seller_id ? sellersMap[c.seller_id] || 'Sem vendedor' : 'Sem vendedor',
          firstOrderDate: c.first_order_date || '',
          verifiedAt: c.new_client_verified_at || '',
          totalRevenue: stats.revenue,
          orderCount: stats.count,
          totalProfit: stats.profit,
          marginPercent,
          subCategory: c.client_category_sub || null,
        };
      });

      setClients(mapped);
    } catch (err) {
      console.error('Error fetching Google clients:', err);
    } finally {
      setLoading(false);
    }
  }

  const googleOnly = useMemo(() => clients.filter(c => !c.subCategory), [clients]);
  const portaDaLoja = useMemo(() => clients.filter(c => c.subCategory === 'porta_da_loja'), [clients]);

  const buildMonthlyData = (list: GoogleClient[]) => {
    const grouped: Record<string, MonthlyData> = {};
    list.forEach(client => {
      const date = new Date(client.firstOrderDate || client.verifiedAt);
      const month = date.getMonth() + 1;
      const year = date.getFullYear();
      const key = `${year}-${month}`;
      if (!grouped[key]) {
        grouped[key] = { month, year, label: `${MONTH_NAMES[month - 1]} ${year}`, count: 0, clients: [], expanded: false };
      }
      grouped[key].count++;
      grouped[key].clients.push(client);
    });
    return Object.values(grouped).sort((a, b) => a.year !== b.year ? b.year - a.year : b.month - a.month);
  };

  const monthlyGoogle = useMemo(() => buildMonthlyData(googleOnly), [googleOnly]);
  const monthlyPorta = useMemo(() => buildMonthlyData(portaDaLoja), [portaDaLoja]);

  const stats = useMemo(() => {
    const totalClients = clients.length;
    const totalRevenue = clients.reduce((sum, c) => sum + c.totalRevenue, 0);
    const totalProfit = clients.reduce((sum, c) => sum + c.totalProfit, 0);
    const avgTicket = totalClients > 0 ? totalRevenue / totalClients : 0;
    const avgMargin = totalRevenue > 0 ? (totalProfit / totalRevenue) * 100 : 0;
    
    const now = new Date();
    const thisMonth = clients.filter(c => {
      const date = new Date(c.firstOrderDate || c.verifiedAt);
      return date.getMonth() === now.getMonth() && date.getFullYear() === now.getFullYear();
    }).length;

    return { totalClients, totalRevenue, totalProfit, avgTicket, avgMargin, thisMonth, googleCount: googleOnly.length, portaCount: portaDaLoja.length };
  }, [clients, googleOnly, portaDaLoja]);

  const toggleMonth = (key: string) => {
    setExpandedMonths(prev => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key); else next.add(key);
      return next;
    });
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => (
            <Skeleton key={i} className="h-32 rounded-xl" />
          ))}
        </div>
        <Skeleton className="h-96 rounded-xl" />
      </div>
    );
  }

  const renderMonthlySection = (title: string, icon: React.ReactNode, data: MonthlyData[], emptyText: string, colorClass: string) => (
    <Card className="border-border/60">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          {icon}
          {title}
          <Badge variant="outline" className="ml-auto">{data.reduce((s, m) => s + m.count, 0)}</Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {data.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            <p>{emptyText}</p>
          </div>
        ) : (
          data.map((monthData) => {
            const key = `${title}-${monthData.year}-${monthData.month}`;
            const isExpanded = expandedMonths.has(key);
            return (
              <motion.div key={key} initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="border border-border/50 rounded-lg overflow-hidden">
                <button onClick={() => toggleMonth(key)} className="w-full flex items-center justify-between p-4 hover:bg-muted/30 transition-colors">
                  <div className="flex items-center gap-3">
                    <div className={cn("w-10 h-10 rounded-lg flex items-center justify-center", colorClass)}>
                      {icon}
                    </div>
                    <div className="text-left">
                      <p className="font-semibold text-foreground">{monthData.label}</p>
                      <p className="text-sm text-muted-foreground">{monthData.count} cliente{monthData.count !== 1 ? 's' : ''}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <Badge variant="secondary" className={cn("border", colorClass)}>{monthData.count}</Badge>
                    {isExpanded ? <ChevronUp className="h-5 w-5 text-muted-foreground" /> : <ChevronDown className="h-5 w-5 text-muted-foreground" />}
                  </div>
                </button>
                {isExpanded && (
                  <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} className="border-t border-border/50 bg-muted/20">
                    <div className="p-4 space-y-2">
                      {monthData.clients.map((client) => (
                        <div key={client.id} className="flex items-center justify-between p-3 bg-background/50 rounded-lg border border-border/30">
                          <div className="flex items-center gap-3">
                            <Building2 className="h-4 w-4 text-muted-foreground" />
                            <div>
                              <p className="font-medium text-foreground text-sm">{client.companyName}</p>
                              <p className="text-xs text-muted-foreground">Vendedor: {client.sellerName}</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-4">
                            <div className="text-right">
                              <p className="text-sm font-semibold text-foreground">{formatCurrency(client.totalRevenue)}</p>
                              <p className="text-xs text-muted-foreground">{client.orderCount} pedido{client.orderCount !== 1 ? 's' : ''}</p>
                            </div>
                            <Badge variant="outline" className={cn("min-w-[60px] justify-center", client.marginPercent >= 50 ? "border-emerald-300 text-emerald-600 bg-emerald-50 dark:bg-emerald-950/30" : client.marginPercent >= 30 ? "border-blue-300 text-blue-600 bg-blue-50 dark:bg-blue-950/30" : "border-amber-300 text-amber-600 bg-amber-50 dark:bg-amber-950/30")}>
                              {client.marginPercent.toFixed(1)}%
                            </Badge>
                          </div>
                        </div>
                      ))}
                    </div>
                  </motion.div>
                )}
              </motion.div>
            );
          })
        )}
      </CardContent>
    </Card>
  );

  return (
    <div className="space-y-6">
      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        <ReportKPICard
          title="Total Clientes Google"
          value={stats.totalClients}
          subtitle={`Google: ${stats.googleCount} · Porta: ${stats.portaCount}`}
          icon={<Chrome className="h-6 w-6 text-blue-500" />}
          iconBg="bg-blue-500/10"
        />
        <ReportKPICard
          title="Este Mês"
          value={stats.thisMonth}
          subtitle={`${MONTH_NAMES[new Date().getMonth()]} ${new Date().getFullYear()}`}
          icon={<Calendar className="h-6 w-6 text-primary" />}
          iconBg="bg-primary/10"
        />
        <ReportKPICard
          title="Faturamento Gerado"
          value={formatCurrency(stats.totalRevenue)}
          subtitle="Receita total"
          icon={<TrendingUp className="h-6 w-6 text-blue-500" />}
          iconBg="bg-blue-500/10"
        />
        <ReportKPICard
          title="Lucro Bruto"
          value={formatCurrency(stats.totalProfit)}
          subtitle="Total dos clientes Google"
          icon={<DollarSign className="h-6 w-6 text-status-success" />}
          iconBg="bg-status-success/10"
        />
        <ReportKPICard
          title="Margem Média"
          value={`${stats.avgMargin.toFixed(1)}%`}
          subtitle="Lucro / Faturamento"
          icon={<Percent className="h-6 w-6 text-emerald-500" />}
          iconBg="bg-emerald-500/10"
        />
        <ReportKPICard
          title="Ticket Médio"
          value={formatCurrency(stats.avgTicket)}
          subtitle="Por cliente Google"
          icon={<Users className="h-6 w-6 text-hh-orange" />}
          iconBg="bg-hh-orange/10"
        />
      </div>

      {/* Info Banner */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="rounded-xl border border-blue-500/20 bg-gradient-to-br from-blue-500/5 via-background to-blue-500/10 p-5"
      >
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-blue-500/10 rounded-xl flex items-center justify-center">
            <Chrome className="h-6 w-6 text-blue-500" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-foreground">Clientes via Google</h3>
            <p className="text-sm text-muted-foreground">
              Clientes adquiridos através de campanhas Google Ads, busca orgânica ou porta da loja. 
              Estes clientes <span className="text-blue-400 font-medium">não contam</span> na métrica de novos clientes conquistados pelos vendedores.
            </p>
          </div>
        </div>
      </motion.div>

      {/* Google Clients Section */}
      {renderMonthlySection(
        'Clientes Google',
        <Chrome className="h-5 w-5 text-blue-500" />,
        monthlyGoogle,
        'Nenhum cliente via Google registrado',
        'bg-blue-500/10'
      )}

      {/* Porta da Loja Section */}
      {renderMonthlySection(
        'Clientes Porta da Loja',
        <Store className="h-5 w-5 text-amber-500" />,
        monthlyPorta,
        'Nenhum cliente porta da loja registrado',
        'bg-amber-500/10'
      )}
    </div>
  );
}
