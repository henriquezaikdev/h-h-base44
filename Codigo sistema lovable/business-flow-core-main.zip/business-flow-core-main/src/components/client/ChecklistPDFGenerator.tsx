import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { FileText } from 'lucide-react';
import { ChecklistPreviewModal } from './ChecklistPreviewModal';

interface ChecklistPDFGeneratorProps {
  clientId: string;
  clientName: string;
  sellerName?: string;
}

export function ChecklistPDFGenerator({ clientId, clientName, sellerName }: ChecklistPDFGeneratorProps) {
  const [isModalOpen, setIsModalOpen] = useState(false);

  return (
    <>
      <Button
        onClick={() => setIsModalOpen(true)}
        variant="outline"
        className="gap-2"
        title="Gerar checklist de reposição inteligente"
      >
        <FileText className="h-4 w-4" />
        Checklist Inteligente
      </Button>

      <ChecklistPreviewModal
        open={isModalOpen}
        onOpenChange={setIsModalOpen}
        clientId={clientId}
        clientName={clientName}
        sellerName={sellerName}
      />
    </>
  );
}
