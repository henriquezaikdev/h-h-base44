import { useState, useEffect, useMemo, useLayoutEffect, useRef, useCallback } from 'react';
import { Loader2, Save, Pencil, Bot, RefreshCw, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { useAuth } from '@/hooks/useAuth';
import { useEditStore } from '@/store/useEditStore';

interface ClientNotesSectionProps {
  clientId: string;
  manualNotes: string | null;
  aiAnalysis: string | null;
  aiAnalysisUpdatedAt: string | null;
  onSaved: () => void;
}

export function ClientNotesSection({
  clientId,
  manualNotes,
  aiAnalysis,
  aiAnalysisUpdatedAt,
  onSaved,
}: ClientNotesSectionProps) {
  const { user } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [refreshingAI, setRefreshingAI] = useState(false);

  // GLOBAL STORE: State survives remounts
  const { getClientNotes, setClientNotes: saveToStore, clearClientNotes } = useEditStore();
  
  // Track dirty state to prevent server data overwrite
  const isDirtyRef = useRef(false);

  // Controlled + restore síncrono from GLOBAL STORE
  const [notes, setNotes] = useState(() => {
    const stored = getClientNotes(clientId);
    if (stored?.notes && typeof stored.notes === 'string') {
      isDirtyRef.current = true;
      return stored.notes;
    }
    return manualNotes || '';
  });

  const latestNotesRef = useRef(notes);
  useEffect(() => {
    latestNotesRef.current = notes;
  }, [notes]);

  // If server data changes and NOT dirty and NO store data, sync
  useEffect(() => {
    if (isEditing) return;
    if (isDirtyRef.current) return;
    const stored = getClientNotes(clientId);
    if (stored?.notes) return;
    setNotes(manualNotes || '');
  }, [manualNotes, isEditing, clientId, getClientNotes]);

  // Re-hidratar from store when entering edit mode or clientId changes
  useLayoutEffect(() => {
    const stored = getClientNotes(clientId);
    if (stored?.notes && typeof stored.notes === 'string') {
      setNotes(stored.notes);
    }
  }, [clientId, isEditing, getClientNotes]);

  // Autosave to GLOBAL STORE (debounced)
  useEffect(() => {
    if (!isEditing) return;
    const t = setTimeout(() => {
      saveToStore(clientId, latestNotesRef.current);
    }, 200);
    return () => clearTimeout(t);
  }, [isEditing, notes, clientId, saveToStore]);

  // Flush to store on visibility change
  useEffect(() => {
    if (!isEditing) return;

    const onVisibilityChange = () => {
      if (document.hidden) {
        saveToStore(clientId, latestNotesRef.current);
      }
    };

    const onPageHide = () => {
      saveToStore(clientId, latestNotesRef.current);
    };

    document.addEventListener('visibilitychange', onVisibilityChange);
    window.addEventListener('pagehide', onPageHide);

    return () => {
      document.removeEventListener('visibilitychange', onVisibilityChange);
      window.removeEventListener('pagehide', onPageHide);
    };
  }, [isEditing, clientId, saveToStore]);

  const handleSave = async () => {
    // Flush to store before saving
    saveToStore(clientId, notes);

    setSaving(true);
    try {
      const { error } = await supabase
        .from('clients')
        .update({ manual_notes: notes || null })
        .eq('id', clientId);

      if (error) throw error;
      toast.success('Anotações salvas!');
      clearClientNotes(clientId);
      isDirtyRef.current = false;
      setIsEditing(false);
      onSaved();
    } catch (error) {
      console.error('Error saving notes:', error);
      toast.error('Erro ao salvar anotações');
    } finally {
      setSaving(false);
    }
  };

  const handleRefreshAI = async () => {
    setRefreshingAI(true);
    try {
      // This would trigger the AI analysis - for now we show a placeholder
      toast.info('Funcionalidade de atualização automática da IA em desenvolvimento');
    } catch (error) {
      toast.error('Erro ao atualizar análise');
    } finally {
      setRefreshingAI(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Manual Notes */}
      <div className="card-section">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Pencil className="h-5 w-5 text-primary" />
            <h3 className="font-semibold">Anotações Manuais</h3>
          </div>
          {!isEditing ? (
            <Button variant="outline" size="sm" onClick={() => setIsEditing(true)}>
              <Pencil className="h-4 w-4 mr-1" />
              Editar
            </Button>
          ) : (
            <div className="flex gap-2">
              {getClientNotes(clientId)?.notes && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => clearClientNotes(clientId)}
                  className="text-muted-foreground"
                >
                  Limpar rascunho
                </Button>
              )}
              <Button variant="outline" size="sm" onClick={() => {
                setNotes(manualNotes || '');
                setIsEditing(false);
              }}>
                Cancelar
              </Button>
              <Button size="sm" onClick={handleSave} disabled={saving}>
                {saving && <Loader2 className="h-4 w-4 mr-1 animate-spin" />}
                <Save className="h-4 w-4 mr-1" />
                Salvar
              </Button>
            </div>

          )}
        </div>

        {isEditing ? (
          <Textarea
            value={notes}
            onChange={(e) => {
              const v = e.target.value;
              isDirtyRef.current = true; // Mark as dirty on change
              latestNotesRef.current = v;
              setNotes(v);
            }}
            onBlur={() => saveToStore(clientId, latestNotesRef.current)}
            placeholder="Adicione anotações sobre este cliente...&#10;Ex: Prefere WhatsApp, Orçamento liberado em Jan"
            rows={4}
            className="resize-none"
          />
        ) : (
          <div className="p-3 bg-muted/30 rounded-lg min-h-[80px]">
            {notes ? (
              <p className="text-sm whitespace-pre-wrap">{notes}</p>
            ) : (
              <p className="text-sm text-muted-foreground italic">
                Nenhuma anotação adicionada
              </p>
            )}
          </div>
        )}
      </div>

      {/* AI Analysis - Read Only */}
      <div className="card-section">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Bot className="h-5 w-5 text-teal-600" />
            <h3 className="font-semibold">Análise IA</h3>
            <Badge variant="outline" className="text-xs bg-teal-50 text-teal-600 border-teal-200">
              Automática
            </Badge>
          </div>
          <div className="flex items-center gap-2">
            {aiAnalysisUpdatedAt && (
              <span className="text-xs text-muted-foreground flex items-center gap-1">
                <Clock className="h-3 w-3" />
                Atualizado em {format(new Date(aiAnalysisUpdatedAt), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}
              </span>
            )}
            <Button 
              variant="outline" 
              size="sm" 
              onClick={handleRefreshAI}
              disabled={refreshingAI}
            >
              {refreshingAI ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <RefreshCw className="h-4 w-4" />
              )}
            </Button>
          </div>
        </div>

        <ScrollArea className="max-h-[300px]">
          <div className="p-4 bg-gradient-to-br from-teal-50/50 to-purple-50/50 dark:from-teal-950/20 dark:to-purple-950/20 rounded-lg border border-teal-200/50 dark:border-teal-800/50">
            {aiAnalysis ? (
              <div className="text-sm whitespace-pre-wrap">{aiAnalysis}</div>
            ) : (
              <div className="text-center py-6">
                <Bot className="h-10 w-10 text-muted-foreground/50 mx-auto mb-2" />
                <p className="text-sm text-muted-foreground">
                  A análise automática será gerada quando houver interações ou pedidos registrados.
                </p>
              </div>
            )}
          </div>
        </ScrollArea>
      </div>
    </div>
  );
}
