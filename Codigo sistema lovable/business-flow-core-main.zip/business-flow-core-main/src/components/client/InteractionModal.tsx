import { useState, useEffect } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { format } from 'date-fns';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { DatePickerWithConfirm } from '@/components/ui/date-range-picker';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { CONTACT_REASON_OPTIONS, ContactReason } from '@/lib/contactReasons';
import { SELLER_METRICS_QUERY_KEY } from '@/hooks/useSellerMetrics';

interface Interaction {
  id: string;
  interaction_type: string;
  interaction_notes: string;
  interaction_date: string;
  interaction_time: string;
  responsible_seller_id: string | null;
  contact_reason?: string;
  created_at: string;
}

interface InteractionModalProps {
  isOpen: boolean;
  onClose: () => void;
  clientId?: string | null;
  prospectId?: string | null;
  interaction?: Interaction | null;
  currentSellerId: string | null;
  onSaved: () => void;
}

const INTERACTION_TYPES = [
  { value: 'phone_call', label: 'Ligação' },
  { value: 'email', label: 'Email' },
  { value: 'visit', label: 'Visita' },
  { value: 'meeting', label: 'Reunião' },
  { value: 'message', label: 'Mensagem' },
];

export function InteractionModal({ 
  isOpen, 
  onClose, 
  clientId, 
  prospectId,
  interaction, 
  currentSellerId,
  onSaved 
}: InteractionModalProps) {
  const queryClient = useQueryClient();
  const [saving, setSaving] = useState(false);
  const [formData, setFormData] = useState({
    interaction_type: 'phone_call',
    interaction_notes: '',
    interaction_date: new Date(),
    interaction_time: format(new Date(), 'HH:mm'),
    contact_reason: 'RETORNO' as ContactReason,
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (interaction) {
      setFormData({
        interaction_type: interaction.interaction_type || 'phone_call',
        interaction_notes: interaction.interaction_notes || '',
        interaction_date: interaction.interaction_date ? new Date(interaction.interaction_date) : new Date(),
        interaction_time: interaction.interaction_time || format(new Date(), 'HH:mm'),
        contact_reason: (interaction.contact_reason as ContactReason) || 'RETORNO',
      });
    } else {
      setFormData({
        interaction_type: 'phone_call',
        interaction_notes: '',
        interaction_date: new Date(),
        interaction_time: format(new Date(), 'HH:mm'),
        contact_reason: 'RETORNO',
      });
    }
    setErrors({});
  }, [interaction, isOpen]);

  const validate = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.interaction_type) {
      newErrors.interaction_type = 'Tipo é obrigatório';
    }
    
    if (!formData.interaction_notes.trim()) {
      newErrors.interaction_notes = 'Observações são obrigatórias';
    }
    
    if (!formData.interaction_date) {
      newErrors.interaction_date = 'Data é obrigatória';
    }
    
    if (!formData.interaction_time) {
      newErrors.interaction_time = 'Horário é obrigatório';
    } else if (!/^([01]?[0-9]|2[0-3]):[0-5][0-9]$/.test(formData.interaction_time)) {
      newErrors.interaction_time = 'Formato inválido (HH:MM)';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async () => {
    if (!validate()) return;

    setSaving(true);
    try {
      const interactionData: Record<string, any> = {
        interaction_type: formData.interaction_type,
        interaction_notes: formData.interaction_notes.trim(),
        interaction_date: format(formData.interaction_date, 'yyyy-MM-dd'),
        interaction_time: formData.interaction_time,
        responsible_seller_id: currentSellerId,
        contact_reason: formData.contact_reason,
      };
      
      // Suporta client_id OU prospect_id (polimórfico)
      if (clientId) {
        interactionData.client_id = clientId;
      } else if (prospectId) {
        interactionData.prospect_id = prospectId;
      }

      if (interaction) {
        const { error } = await supabase
          .from('interactions')
          .update(interactionData as any)
          .eq('id', interaction.id);
        if (error) throw error;
        toast.success('Interação atualizada com sucesso!');
      } else {
        const { error } = await supabase
          .from('interactions')
          .insert(interactionData as any);
        if (error) throw error;
        toast.success('Interação registrada com sucesso!');
      }

      // INVALIDAR CACHE DE MÉTRICAS PARA ATUALIZAÇÃO IMEDIATA
      queryClient.invalidateQueries({ queryKey: [SELLER_METRICS_QUERY_KEY] });

      onSaved();
      onClose();
    } catch (error: any) {
      console.error('Error saving interaction:', error);
      toast.error(error.message || 'Erro ao salvar interação');
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>{interaction ? 'Editar Interação' : 'Registrar Interação'}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label>Tipo de Interação *</Label>
            <Select
              value={formData.interaction_type}
              onValueChange={(value) => setFormData({ ...formData, interaction_type: value })}
            >
              <SelectTrigger className={errors.interaction_type ? 'border-destructive' : ''}>
                <SelectValue placeholder="Selecione o tipo" />
              </SelectTrigger>
              <SelectContent>
                {INTERACTION_TYPES.map((type) => (
                  <SelectItem key={type.value} value={type.value}>
                    {type.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {errors.interaction_type && <p className="text-sm text-destructive">{errors.interaction_type}</p>}
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Data *</Label>
              <DatePickerWithConfirm
                date={formData.interaction_date}
                onApply={(date) => date && setFormData({ ...formData, interaction_date: date })}
                placeholder="Selecione"
                className={cn(
                  errors.interaction_date && "border-destructive"
                )}
              />
              {errors.interaction_date && <p className="text-sm text-destructive">{errors.interaction_date}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="time">Horário (HH:MM) *</Label>
              <Input
                id="time"
                type="time"
                value={formData.interaction_time}
                onChange={(e) => setFormData({ ...formData, interaction_time: e.target.value })}
                className={errors.interaction_time ? 'border-destructive' : ''}
              />
              {errors.interaction_time && <p className="text-sm text-destructive">{errors.interaction_time}</p>}
            </div>
          </div>

          <div className="space-y-2">
            <Label>Motivo do Contato *</Label>
            <Select
              value={formData.contact_reason}
              onValueChange={(value) => setFormData({ ...formData, contact_reason: value as ContactReason })}
            >
              <SelectTrigger>
                <SelectValue placeholder="Selecione o motivo" />
              </SelectTrigger>
              <SelectContent>
                {CONTACT_REASON_OPTIONS.map((opt) => (
                  <SelectItem key={opt.value} value={opt.value}>
                    {opt.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">Observações *</Label>
            <Textarea
              id="notes"
              value={formData.interaction_notes}
              onChange={(e) => setFormData({ ...formData, interaction_notes: e.target.value })}
              placeholder="Descreva os detalhes da interação..."
              rows={4}
              className={errors.interaction_notes ? 'border-destructive' : ''}
            />
            {errors.interaction_notes && <p className="text-sm text-destructive">{errors.interaction_notes}</p>}
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <Button variant="outline" onClick={onClose} disabled={saving}>
              Cancelar
            </Button>
            <Button onClick={handleSubmit} disabled={saving}>
              {saving ? 'Salvando...' : interaction ? 'Atualizar' : 'Registrar'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
