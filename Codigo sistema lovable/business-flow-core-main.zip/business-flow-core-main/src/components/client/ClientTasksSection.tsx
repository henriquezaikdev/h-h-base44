import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/hooks/useAuth';
import { useSellersData } from '@/hooks/useSellersData';
import { useTasksData, TaskData } from '@/hooks/useTasksData';
import { TaskUnifiedModal } from '@/components/tasks/TaskUnifiedModal';
import { TaskCockpitModal } from '@/components/tasks/TaskCockpitModal';
import { EditTaskModal } from '@/components/tasks/EditTaskModal';
import { DeleteTaskModal } from '@/components/tasks/DeleteTaskModal';
import { Phone, MessageCircle, Plus, Check, Clock, AlertTriangle, FileText, Pencil, Trash2 } from 'lucide-react';
import { format, isToday, isPast, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface ClientTasksSectionProps {
  clientId: string;
  clientName: string;
  onTaskCompleted?: () => void;
}

export function ClientTasksSection({ clientId, clientName, onTaskCompleted }: ClientTasksSectionProps) {
  const [showModal, setShowModal] = useState(false);
  const [completingTask, setCompletingTask] = useState<TaskData | null>(null);
  const [editingTask, setEditingTask] = useState<TaskData | null>(null);
  const [deletingTask, setDeletingTask] = useState<TaskData | null>(null);
  
  const { tasks, loading, refetch } = useTasksData(clientId);
  const { seller, isAdminOrOwner } = useAuth();
  const { sellers } = useSellersData();

  const pendingTasks = tasks.filter((t) => t.status === 'pendente');

  const getTaskStatus = (task: TaskData) => {
    const taskDate = parseISO(task.taskDate);
    if (isPast(taskDate) && !isToday(taskDate)) {
      return 'atrasada';
    }
    if (isToday(taskDate)) {
      return 'hoje';
    }
    return 'futura';
  };

  const handleCompleteClick = (task: TaskData) => {
    setCompletingTask(task);
  };

  const handleTaskCompleted = () => {
    refetch();
    onTaskCompleted?.();
  };

  // Check if user can manage a task
  const canManageTask = (task: TaskData) => {
    // Admin/Owner can manage any task
    if (isAdminOrOwner) return true;
    // Regular user can only manage their own tasks
    return task.createdBySellerId === seller?.id;
  };

  const renderTask = (task: TaskData) => {
    const status = getTaskStatus(task);
    const isLigacao = task.contactType === 'ligacao';
    const showActions = canManageTask(task);

    return (
      <div
        key={task.id}
        className={`p-3 rounded-lg border group ${
          status === 'atrasada'
            ? 'border-destructive/30 bg-destructive/5'
            : status === 'hoje'
            ? 'border-amber-500/30 bg-amber-50 dark:bg-amber-950/20'
            : 'border-border bg-muted/30'
        }`}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div
              className={`w-9 h-9 rounded-lg flex items-center justify-center ${
                isLigacao ? 'bg-primary/10' : 'bg-green-500/10'
              }`}
            >
              {isLigacao ? (
                <Phone className="h-4 w-4 text-primary" />
              ) : (
                <MessageCircle className="h-4 w-4 text-green-500" />
              )}
            </div>
            <div>
              <p className="font-medium text-sm">
                {isLigacao ? 'Ligação' : 'WhatsApp'}
              </p>
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <span>{format(parseISO(task.taskDate), "dd/MM/yyyy", { locale: ptBR })}</span>
                {task.taskTime && <span>{task.taskTime.slice(0, 5)}</span>}
                {status === 'atrasada' && (
                  <span className="flex items-center gap-1 text-destructive">
                    <AlertTriangle className="h-3 w-3" />
                    Atrasada
                  </span>
                )}
                {status === 'hoje' && (
                  <span className="flex items-center gap-1 text-amber-600 dark:text-amber-400">
                    <Clock className="h-3 w-3" />
                    Hoje
                  </span>
                )}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-1">
            {/* Edit/Cancel buttons */}
            {showActions && (
              <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity mr-2">
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8"
                  onClick={() => setEditingTask(task)}
                  title="Editar tarefa"
                >
                  <Pencil size={14} />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 text-destructive hover:text-destructive"
                  onClick={() => setDeletingTask(task)}
                  title="Excluir tarefa"
                >
                  <Trash2 size={14} />
                </Button>
              </div>
            )}
            
            <Button
              size="sm"
              variant="outline"
              onClick={() => handleCompleteClick(task)}
              className="text-green-600 hover:bg-green-50 hover:text-green-700"
            >
              <Check className="h-4 w-4 mr-1" />
              Concluir
            </Button>
          </div>
        </div>

        {/* Show notes if present */}
        {task.notes && (
          <div className="mt-2 pt-2 border-t border-border/50">
            <p className="text-xs text-muted-foreground flex items-start gap-1.5">
              <FileText className="h-3 w-3 mt-0.5 shrink-0" />
              <span className="line-clamp-2">{task.notes}</span>
            </p>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="card-section">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-foreground">Tarefas Pendentes</h3>
        <Button size="sm" onClick={() => setShowModal(true)}>
          <Plus className="h-4 w-4 mr-1" />
          Nova Tarefa
        </Button>
      </div>

      {loading ? (
        <div className="flex justify-center py-6">
          <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary" />
        </div>
      ) : (
        <div className="space-y-4">
          {/* Pending Tasks */}
          {pendingTasks.length > 0 ? (
            <div className="space-y-2">
              {pendingTasks.map((task) => renderTask(task))}
            </div>
          ) : (
            <p className="text-sm text-muted-foreground text-center py-4">
              Nenhuma tarefa pendente
            </p>
          )}
        </div>
      )}

      <TaskUnifiedModal
        open={showModal}
        onOpenChange={setShowModal}
        mode="create"
        clientId={clientId}
        clientName={clientName}
        sellers={sellers}
        onCompleted={() => {
          refetch();
        }}
      />

      {/* Cockpit Modal para concluir tarefa */}
      {completingTask && (
        <TaskCockpitModal
          open={!!completingTask}
          onOpenChange={(open) => !open && setCompletingTask(null)}
          task={completingTask}
          sellers={sellers}
          onCompleted={handleTaskCompleted}
        />
      )}

      {/* Edit Task Modal */}
      {editingTask && (
        <EditTaskModal
          open={!!editingTask}
          onOpenChange={(open) => !open && setEditingTask(null)}
          task={editingTask}
          sellers={sellers}
          onUpdated={() => {
            refetch();
            onTaskCompleted?.();
          }}
        />
      )}

      {/* Delete Task Modal */}
      {deletingTask && (
        <DeleteTaskModal
          open={!!deletingTask}
          onOpenChange={(open) => !open && setDeletingTask(null)}
          taskId={deletingTask.id}
          isCompleted={deletingTask.status === 'concluida'}
          onDeleted={() => {
            refetch();
            onTaskCompleted?.();
          }}
        />
      )}
    </div>
  );
}
