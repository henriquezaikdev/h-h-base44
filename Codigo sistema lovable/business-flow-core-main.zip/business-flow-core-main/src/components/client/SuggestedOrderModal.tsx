import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import { jsPDF } from 'jspdf';
import { 
  ShoppingCart, 
  Loader2, 
  Copy, 
  Download,
  AlertTriangle,
  Clock,
  Trash2,
  Plus,
  Minus,
  Package,
  Maximize2,
  Minimize2,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogDescription,
} from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { ScrollArea } from '@/components/ui/scroll-area';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { useClientReplenishment, ReplenishmentItem } from '@/hooks/useClientReplenishment';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import logoHH from '@/assets/logo-hh.png';

interface SuggestedOrderModalProps {
  clientId: string;
  clientName: string;
}

interface OrderItem extends ReplenishmentItem {
  selected: boolean;
}

export function SuggestedOrderModal({ clientId, clientName }: SuggestedOrderModalProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const [orderItems, setOrderItems] = useState<OrderItem[]>([]);
  const [observations, setObservations] = useState('');
  const [expandedSections, setExpandedSections] = useState({ atraso: true, proximo: true });
  const { items, loading, overdueCount, nearbyCount, refetch } = useClientReplenishment(clientId, isOpen);

  // Quando abrir o modal, filtrar apenas itens em atraso e próximos
  useEffect(() => {
    if (isOpen && items.length > 0) {
      const filteredItems = items
        .filter(item => item.status === 'atraso' || item.status === 'proximo')
        .map(item => ({
          ...item,
          selected: true,
        }));
      setOrderItems(filteredItems);
    }
  }, [isOpen, items]);

  useEffect(() => {
    if (isOpen) {
      refetch();
    }
  }, [isOpen]);

  const toggleItem = (id: string) => {
    setOrderItems(prev => prev.map(item => 
      item.id === id ? { ...item, selected: !item.selected } : item
    ));
  };

  const updateQuantity = (id: string, delta: number) => {
    setOrderItems(prev => prev.map(item => {
      if (item.id === id) {
        const newQty = Math.max(1, item.suggestedQuantity + delta);
        return { ...item, suggestedQuantity: newQty };
      }
      return item;
    }));
  };

  const setQuantity = (id: string, value: number) => {
    setOrderItems(prev => prev.map(item => 
      item.id === id ? { ...item, suggestedQuantity: Math.max(1, value) } : item
    ));
  };

  const removeItem = (id: string) => {
    setOrderItems(prev => prev.filter(item => item.id !== id));
  };

  const selectedItems = orderItems.filter(i => i.selected);

  const calculateTotal = () => {
    return selectedItems.reduce((sum, item) => {
      return sum + (item.suggestedQuantity * item.avgUnitPrice);
    }, 0);
  };

  const generateOrderText = () => {
    if (selectedItems.length === 0) return '';

    const groupedByCategory = selectedItems.reduce((acc, item) => {
      if (!acc[item.category]) acc[item.category] = [];
      acc[item.category].push(item);
      return acc;
    }, {} as Record<string, OrderItem[]>);

    let text = `PEDIDO SUGERIDO - ${clientName}\n`;
    text += `Data: ${format(new Date(), "dd/MM/yyyy", { locale: ptBR })}\n`;
    text += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n`;

    Object.entries(groupedByCategory).forEach(([category, items]) => {
      text += `${category.toUpperCase()}\n`;
      items.forEach(item => {
        const priceStr = item.avgUnitPrice > 0 ? ` (R$ ${item.avgUnitPrice.toFixed(2)})` : '';
        text += `- ${item.suggestedQuantity}x ${item.productName}${priceStr}\n`;
      });
      text += '\n';
    });

    text += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
    text += `RESUMO:\n`;
    text += `• ${selectedItems.filter(i => i.status === 'atraso').length} itens em atraso\n`;
    text += `• ${selectedItems.filter(i => i.status === 'proximo').length} itens próximos de reposição\n`;
    text += `• Total: ${selectedItems.length} itens\n`;
    text += `• Valor estimado: R$ ${calculateTotal().toFixed(2)}\n`;

    if (observations.trim()) {
      text += `\nOBSERVAÇÕES:\n${observations}\n`;
    }

    text += `\n⚠️ Este é um rascunho de pedido baseado no histórico de compras.`;

    return text;
  };

  const handleCopy = async () => {
    const text = generateOrderText();
    if (!text) {
      toast.error('Selecione pelo menos um item');
      return;
    }

    try {
      await navigator.clipboard.writeText(text);
      toast.success('Pedido copiado para a área de transferência!');
    } catch (error) {
      toast.error('Erro ao copiar');
    }
  };

  const handleExportPDF = () => {
    if (selectedItems.length === 0) {
      toast.error('Selecione pelo menos um item');
      return;
    }

    const doc = new jsPDF();
    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();
    const margin = 15;
    const contentWidth = pageWidth - (margin * 2);

    // Header preto
    doc.setFillColor(0, 0, 0);
    doc.rect(0, 0, pageWidth, 45, 'F');

    // Logo
    try {
      doc.addImage(logoHH, 'PNG', margin, 8, 28, 24);
    } catch {
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(20);
      doc.setFont('helvetica', 'bold');
      doc.text('H&H', margin + 6, 24);
    }

    // Título
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(16);
    doc.setFont('helvetica', 'bold');
    doc.text('PEDIDO SUGERIDO', 50, 18);
    
    doc.setFontSize(9);
    doc.setFont('helvetica', 'normal');
    doc.text('Baseado no histórico de compras', 50, 26);

    // Barra laranja
    doc.setFillColor(249, 115, 22);
    doc.rect(0, 45, pageWidth, 3, 'F');

    // Info do cliente
    let yPos = 58;
    doc.setTextColor(0, 0, 0);
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text(clientName, margin, yPos);

    yPos += 8;
    doc.setTextColor(107, 114, 128);
    doc.setFontSize(9);
    doc.setFont('helvetica', 'normal');
    doc.text(`Data: ${format(new Date(), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}`, margin, yPos);

    yPos += 12;

    // Agrupar por categoria
    const groupedByCategory = selectedItems.reduce((acc, item) => {
      if (!acc[item.category]) acc[item.category] = [];
      acc[item.category].push(item);
      return acc;
    }, {} as Record<string, OrderItem[]>);

    // Tabela de itens
    Object.entries(groupedByCategory).forEach(([category, categoryItems]) => {
      // Verificar nova página
      if (yPos + 30 > pageHeight - 40) {
        doc.addPage();
        yPos = 20;
      }

      // Header da categoria
      doc.setFillColor(40, 40, 40);
      doc.roundedRect(margin, yPos - 4, contentWidth, 8, 1, 1, 'F');
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(9);
      doc.setFont('helvetica', 'bold');
      doc.text(category.toUpperCase(), margin + 4, yPos + 1);

      yPos += 10;

      // Itens
      categoryItems.forEach((item, index) => {
        if (yPos + 12 > pageHeight - 40) {
          doc.addPage();
          yPos = 20;
        }

        // Fundo alternado
        if (index % 2 === 0) {
          doc.setFillColor(248, 250, 252);
          doc.rect(margin, yPos - 4, contentWidth, 12, 'F');
        }

        // Status indicator
        const statusColors = item.status === 'atraso' ? [239, 68, 68] : [234, 179, 8];
        doc.setFillColor(statusColors[0], statusColors[1], statusColors[2]);
        doc.circle(margin + 4, yPos + 1, 2, 'F');

        // Quantidade
        doc.setTextColor(0, 0, 0);
        doc.setFontSize(9);
        doc.setFont('helvetica', 'bold');
        doc.text(`${item.suggestedQuantity}x`, margin + 10, yPos + 2);

        // Nome do produto (truncado)
        doc.setFont('helvetica', 'normal');
        let productName = item.productName;
        if (productName.length > 45) {
          productName = productName.substring(0, 42) + '...';
        }
        doc.text(productName, margin + 22, yPos + 2);

        // Preço unitário e subtotal
        if (item.avgUnitPrice > 0) {
          const subtotal = item.suggestedQuantity * item.avgUnitPrice;
          doc.setTextColor(107, 114, 128);
          doc.setFontSize(8);
          doc.text(`R$ ${item.avgUnitPrice.toFixed(2)}`, pageWidth - margin - 50, yPos + 2);
          doc.setTextColor(0, 0, 0);
          doc.setFont('helvetica', 'bold');
          doc.text(`R$ ${subtotal.toFixed(2)}`, pageWidth - margin - 22, yPos + 2, { align: 'right' });
        }

        yPos += 12;
      });

      yPos += 4;
    });

    // Resumo
    yPos += 6;
    if (yPos + 40 > pageHeight - 25) {
      doc.addPage();
      yPos = 20;
    }

    doc.setFillColor(249, 115, 22);
    doc.roundedRect(margin, yPos - 4, contentWidth, 8, 1, 1, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(9);
    doc.setFont('helvetica', 'bold');
    doc.text('RESUMO', margin + 4, yPos + 1);

    yPos += 12;

    doc.setFontSize(9);
    doc.setFont('helvetica', 'normal');
    
    // Indicadores
    let xPos = margin;
    doc.setFillColor(239, 68, 68);
    doc.circle(xPos + 2, yPos - 1.5, 2, 'F');
    doc.setTextColor(220, 38, 38);
    doc.text(`Em atraso: ${selectedItems.filter(i => i.status === 'atraso').length}`, xPos + 6, yPos);

    xPos = margin + 50;
    doc.setFillColor(234, 179, 8);
    doc.circle(xPos + 2, yPos - 1.5, 2, 'F');
    doc.setTextColor(180, 140, 0);
    doc.text(`Próximos: ${selectedItems.filter(i => i.status === 'proximo').length}`, xPos + 6, yPos);

    xPos = margin + 100;
    doc.setTextColor(60, 60, 60);
    doc.text(`Total: ${selectedItems.length} itens`, xPos, yPos);

    yPos += 8;
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.setTextColor(0, 0, 0);
    doc.text(`Valor Estimado: R$ ${calculateTotal().toFixed(2)}`, margin, yPos);

    // Observações
    if (observations.trim()) {
      yPos += 12;
      doc.setFillColor(245, 245, 245);
      doc.roundedRect(margin, yPos - 4, contentWidth, 16, 2, 2, 'F');
      doc.setFontSize(8);
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(60, 60, 60);
      doc.text('OBSERVAÇÕES:', margin + 4, yPos + 2);
      doc.setFont('helvetica', 'normal');
      doc.text(observations.substring(0, 120), margin + 4, yPos + 9);
    }

    // Rodapé
    const footerY = pageHeight - 12;
    doc.setDrawColor(249, 115, 22);
    doc.setLineWidth(0.8);
    doc.line(margin, footerY - 8, pageWidth - margin, footerY - 8);

    doc.setTextColor(107, 114, 128);
    doc.setFontSize(7);
    doc.setFont('helvetica', 'italic');
    doc.text('Este é um rascunho de pedido baseado no histórico de compras do cliente. Valores podem variar.', margin, footerY - 3);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.text('H&H Suprimentos Corporativos', margin, footerY + 2);
    doc.text(`Gerado em ${format(new Date(), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}`, pageWidth - margin - 55, footerY + 2);

    // Salvar
    const fileName = `pedido-sugerido-${clientName.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '')}.pdf`;
    doc.save(fileName);
    toast.success('PDF exportado com sucesso!');
  };

  const overdueItems = orderItems.filter(i => i.status === 'atraso');
  const nearbyItems = orderItems.filter(i => i.status === 'proximo');

  const toggleSection = (section: 'atraso' | 'proximo') => {
    setExpandedSections(prev => ({ ...prev, [section]: !prev[section] }));
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button 
          variant="default" 
          size="sm" 
          className="gap-2 bg-primary hover:bg-primary/90"
        >
          <ShoppingCart size={16} />
          Gerar Pedido
          {(overdueCount > 0 || nearbyCount > 0) && (
            <Badge variant="secondary" className="ml-1 bg-white/20 text-white">
              {overdueCount + nearbyCount}
            </Badge>
          )}
        </Button>
      </DialogTrigger>
      <DialogContent className={`flex flex-col transition-all duration-300 ${isExpanded ? 'max-w-6xl max-h-[95vh]' : 'max-w-3xl max-h-[90vh]'}`}>
        <DialogHeader className="flex flex-row items-center justify-between">
          <div>
            <DialogTitle className="flex items-center gap-2">
              <ShoppingCart className="text-primary" size={20} />
              Pedido Sugerido - {clientName}
            </DialogTitle>
            <DialogDescription>
              Baseado no histórico de compras e ciclo de reposição do cliente
            </DialogDescription>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsExpanded(!isExpanded)}
            className="h-8 w-8"
          >
            {isExpanded ? <Minimize2 size={16} /> : <Maximize2 size={16} />}
          </Button>
        </DialogHeader>

        {loading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : orderItems.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <Package className="h-12 w-12 text-muted-foreground mb-4" />
            <p className="text-lg font-medium">Nenhum item para repor</p>
            <p className="text-sm text-muted-foreground mt-2">
              Todos os produtos estão dentro do ciclo normal de consumo
            </p>
          </div>
        ) : (
          <>
            {/* Summary badges */}
            <div className="flex gap-2 flex-wrap items-center">
              <Badge variant="destructive" className="gap-1">
                <AlertTriangle size={12} />
                {overdueItems.length} em atraso
              </Badge>
              <Badge variant="outline" className="gap-1 border-amber-500 text-amber-600">
                <Clock size={12} />
                {nearbyItems.length} próximos
              </Badge>
              <Badge variant="secondary" className="gap-1">
                {selectedItems.length} selecionados
              </Badge>
              {calculateTotal() > 0 && (
                <Badge variant="outline" className="gap-1 border-green-500 text-green-600">
                  Valor: R$ {calculateTotal().toFixed(2)}
                </Badge>
              )}
            </div>

            {/* Items list with scroll */}
            <ScrollArea className={`flex-1 border rounded-lg overflow-auto ${isExpanded ? 'h-[60vh]' : 'h-[400px]'}`}>
              <div className="p-4 space-y-2">
                {/* Overdue items - Collapsible */}
                {overdueItems.length > 0 && (
                  <Collapsible open={expandedSections.atraso} onOpenChange={() => toggleSection('atraso')}>
                    <CollapsibleTrigger asChild>
                      <Button variant="ghost" className="w-full justify-between p-2 h-auto hover:bg-destructive/10">
                        <span className="text-sm font-medium text-destructive flex items-center gap-2">
                          <AlertTriangle size={14} />
                          Reposição em Atraso ({overdueItems.length})
                        </span>
                        {expandedSections.atraso ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
                      </Button>
                    </CollapsibleTrigger>
                    <CollapsibleContent>
                      <div className="space-y-2 mt-2">
                        {overdueItems.map(item => (
                          <ItemRow 
                            key={item.id} 
                            item={item} 
                            onToggle={toggleItem}
                            onUpdateQuantity={updateQuantity}
                            onSetQuantity={setQuantity}
                            onRemove={removeItem}
                          />
                        ))}
                      </div>
                    </CollapsibleContent>
                  </Collapsible>
                )}

                {/* Nearby items - Collapsible */}
                {nearbyItems.length > 0 && (
                  <Collapsible open={expandedSections.proximo} onOpenChange={() => toggleSection('proximo')}>
                    <CollapsibleTrigger asChild>
                      <Button variant="ghost" className="w-full justify-between p-2 h-auto hover:bg-amber-500/10">
                        <span className="text-sm font-medium text-amber-600 flex items-center gap-2">
                          <Clock size={14} />
                          Reposição Próxima ({nearbyItems.length})
                        </span>
                        {expandedSections.proximo ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
                      </Button>
                    </CollapsibleTrigger>
                    <CollapsibleContent>
                      <div className="space-y-2 mt-2">
                        {nearbyItems.map(item => (
                          <ItemRow 
                            key={item.id} 
                            item={item} 
                            onToggle={toggleItem}
                            onUpdateQuantity={updateQuantity}
                            onSetQuantity={setQuantity}
                            onRemove={removeItem}
                          />
                        ))}
                      </div>
                    </CollapsibleContent>
                  </Collapsible>
                )}
              </div>
            </ScrollArea>

            {/* Observations */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Observações (opcional)</label>
              <Textarea
                value={observations}
                onChange={(e) => setObservations(e.target.value)}
                placeholder="Adicione observações para o pedido..."
                rows={2}
              />
            </div>

            {/* Actions */}
            <div className="flex justify-between items-center pt-2 border-t">
              <p className="text-sm text-muted-foreground">
                ⚠️ Este é um rascunho - revise antes de enviar
              </p>
              <div className="flex gap-2">
                <Button variant="outline" onClick={handleExportPDF} className="gap-2">
                  <Download size={16} />
                  PDF
                </Button>
                <Button onClick={handleCopy} className="gap-2">
                  <Copy size={16} />
                  Copiar Pedido
                </Button>
              </div>
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}

// Component for each item row
function ItemRow({ 
  item, 
  onToggle, 
  onUpdateQuantity, 
  onSetQuantity,
  onRemove,
}: { 
  item: OrderItem;
  onToggle: (id: string) => void;
  onUpdateQuantity: (id: string, delta: number) => void;
  onSetQuantity: (id: string, value: number) => void;
  onRemove: (id: string) => void;
}) {
  const statusColor = item.status === 'atraso' 
    ? 'border-l-destructive bg-destructive/5' 
    : 'border-l-amber-500 bg-amber-50/50 dark:bg-amber-950/20';

  const subtotal = item.suggestedQuantity * item.avgUnitPrice;

  return (
    <div className={`flex items-center gap-3 p-3 rounded-lg border-l-4 ${statusColor}`}>
      <Checkbox 
        checked={item.selected}
        onCheckedChange={() => onToggle(item.id)}
      />
      
      <div className="flex-1 min-w-0">
        <p className="font-medium text-sm truncate">{item.productName}</p>
        <p className="text-xs text-muted-foreground">
          {item.category} • Última compra: {item.lastPurchaseDate 
            ? format(item.lastPurchaseDate, 'dd/MM/yy') 
            : '-'} ({item.daysSinceLastPurchase} dias)
        </p>
        {item.avgUnitPrice > 0 && (
          <p className="text-xs text-green-600 font-medium">
            R$ {item.avgUnitPrice.toFixed(2)} un • Subtotal: R$ {subtotal.toFixed(2)}
          </p>
        )}
      </div>

      {/* Quantity controls */}
      <div className="flex items-center gap-1">
        <Button
          variant="ghost"
          size="icon"
          className="h-7 w-7"
          onClick={() => onUpdateQuantity(item.id, -1)}
          disabled={item.suggestedQuantity <= 1}
        >
          <Minus size={14} />
        </Button>
        <Input
          type="number"
          value={item.suggestedQuantity}
          onChange={(e) => onSetQuantity(item.id, parseInt(e.target.value) || 1)}
          className="w-14 h-7 text-center p-1"
          min={1}
        />
        <Button
          variant="ghost"
          size="icon"
          className="h-7 w-7"
          onClick={() => onUpdateQuantity(item.id, 1)}
        >
          <Plus size={14} />
        </Button>
      </div>

      <Button
        variant="ghost"
        size="icon"
        className="h-7 w-7 text-muted-foreground hover:text-destructive"
        onClick={() => onRemove(item.id)}
      >
        <Trash2 size={14} />
      </Button>
    </div>
  );
}
