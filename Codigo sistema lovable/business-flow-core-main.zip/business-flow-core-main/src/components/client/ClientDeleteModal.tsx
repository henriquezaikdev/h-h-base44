import { useState } from 'react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/useAuth';
import { AlertTriangle, Trash2, Archive, ShieldAlert } from 'lucide-react';

interface ClientDeleteModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  client: {
    id: string;
    company_name: string;
    total_revenue: number;
  };
  ordersCount: number;
  buyersCount: number;
  interactionsCount: number;
  isAdmin: boolean;
  onDeleted: () => void;
}

export function ClientDeleteModal({
  open,
  onOpenChange,
  client,
  ordersCount,
  buyersCount,
  interactionsCount,
  isAdmin,
  onDeleted,
}: ClientDeleteModalProps) {
  const [step, setStep] = useState<'warning' | 'confirm'>('warning');
  const [deletionType, setDeletionType] = useState<'logical' | 'definitive'>('logical');
  const [reason, setReason] = useState('');
  const [confirmText, setConfirmText] = useState('');
  const [understood, setUnderstood] = useState(false);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();
  const { user, seller } = useAuth();

  const hasHistory = ordersCount > 0 || buyersCount > 0 || interactionsCount > 0;
  const canProceed = understood && (deletionType === 'logical' || confirmText === 'CONFIRMAR');

  const resetState = () => {
    setStep('warning');
    setDeletionType('logical');
    setReason('');
    setConfirmText('');
    setUnderstood(false);
  };

  const handleClose = () => {
    resetState();
    onOpenChange(false);
  };

  const handleProceedToConfirm = () => {
    setStep('confirm');
  };

  const handleDelete = async () => {
    if (!user) {
      toast({
        title: 'Erro',
        description: 'Você precisa estar autenticado para excluir clientes.',
        variant: 'destructive',
      });
      return;
    }

    setLoading(true);

    try {
      // 1. Log the deletion first
      const { error: logError } = await supabase.from('client_deletion_logs').insert({
        client_id: client.id,
        client_name: client.company_name,
        deletion_type: deletionType,
        reason: reason || null,
        deleted_by_user_id: user.id,
        deleted_by_seller_id: seller?.id || null,
        deleted_by_name: seller?.name || user.email || 'Usuário desconhecido',
        orders_count: ordersCount,
        interactions_count: interactionsCount,
        buyers_count: buyersCount,
        total_revenue: client.total_revenue || 0,
      });

      if (logError) {
        console.error('Error logging deletion:', logError);
        throw new Error('Erro ao registrar log de exclusão');
      }

      if (deletionType === 'logical') {
        // Logical deletion: mark as deleted
        const { error: updateError } = await supabase
          .from('clients')
          .update({
            is_deleted: true,
            deleted_at: new Date().toISOString(),
            status: 'inativo',
          })
          .eq('id', client.id);

        if (updateError) {
          throw updateError;
        }

        toast({
          title: 'Cliente desativado',
          description: `${client.company_name} foi desativado e removido das listas operacionais.`,
        });
      } else {
        // Definitive deletion: delete related records first, then client
        // Delete buyers
        await supabase.from('buyers').delete().eq('client_id', client.id);
        
        // Delete interactions
        await supabase.from('interactions').delete().eq('client_id', client.id);
        
        // Delete checklists
        await supabase.from('client_checklists').delete().eq('client_id', client.id);
        
        // Delete monthly goals for this client
        await supabase.from('monthly_goals').delete().eq('client_id', client.id);
        
        // Delete actions for this client
        await supabase.from('actions').delete().eq('client_id', client.id);

        // Note: Orders are kept for integrity (or can be handled separately)
        // If you want to delete orders too, uncomment:
        // await supabase.from('order_items').delete().in('order_id', 
        //   supabase.from('orders').select('id').eq('client_id', client.id)
        // );
        // await supabase.from('orders').delete().eq('client_id', client.id);

        // Finally delete the client
        const { error: deleteError } = await supabase
          .from('clients')
          .delete()
          .eq('id', client.id);

        if (deleteError) {
          throw deleteError;
        }

        toast({
          title: 'Cliente excluído permanentemente',
          description: `${client.company_name} foi removido definitivamente do sistema.`,
        });
      }

      handleClose();
      onDeleted();
    } catch (error: any) {
      console.error('Error deleting client:', error);
      toast({
        title: 'Erro ao excluir cliente',
        description: error.message || 'Ocorreu um erro ao processar a exclusão.',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <AlertDialog open={open} onOpenChange={handleClose}>
      <AlertDialogContent className="max-w-lg">
        {step === 'warning' && (
          <>
            <AlertDialogHeader>
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-destructive/10 flex items-center justify-center">
                  <AlertTriangle className="h-6 w-6 text-destructive" />
                </div>
                <AlertDialogTitle className="text-xl">
                  Excluir cliente
                </AlertDialogTitle>
              </div>
              <AlertDialogDescription className="text-left pt-4 space-y-4">
                <p>
                  Você está prestes a excluir o cliente{' '}
                  <strong>{client.company_name}</strong>.
                </p>

                {hasHistory && (
                  <div className="bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 rounded-lg p-4 space-y-2">
                    <p className="font-medium text-amber-800 dark:text-amber-200 flex items-center gap-2">
                      <ShieldAlert className="h-4 w-4" />
                      Este cliente possui histórico no sistema:
                    </p>
                    <ul className="text-sm text-amber-700 dark:text-amber-300 space-y-1 ml-6 list-disc">
                      {ordersCount > 0 && <li>{ordersCount} pedido(s) registrado(s)</li>}
                      {buyersCount > 0 && <li>{buyersCount} comprador(es) cadastrado(s)</li>}
                      {interactionsCount > 0 && <li>{interactionsCount} interação(ões)</li>}
                    </ul>
                    <p className="text-sm text-amber-700 dark:text-amber-300 mt-2">
                      A exclusão pode afetar relatórios e rastreabilidade.
                    </p>
                  </div>
                )}

                <div className="space-y-4 pt-2">
                  <Label className="text-foreground font-medium">Tipo de exclusão:</Label>
                  <RadioGroup
                    value={deletionType}
                    onValueChange={(value) => setDeletionType(value as 'logical' | 'definitive')}
                    className="space-y-3"
                  >
                    <div className="flex items-start gap-3 p-3 rounded-lg border border-border hover:bg-muted/50 cursor-pointer">
                      <RadioGroupItem value="logical" id="logical" className="mt-1" />
                      <div className="flex-1">
                        <Label htmlFor="logical" className="flex items-center gap-2 cursor-pointer font-medium">
                          <Archive className="h-4 w-4 text-primary" />
                          Exclusão Lógica (Recomendado)
                        </Label>
                        <p className="text-sm text-muted-foreground mt-1">
                          O cliente fica inativo e some das listas operacionais, mas o histórico permanece salvo. 
                          Pode ser reativado no futuro.
                        </p>
                      </div>
                    </div>

                    {isAdmin && (
                      <div className="flex items-start gap-3 p-3 rounded-lg border border-destructive/30 hover:bg-destructive/5 cursor-pointer">
                        <RadioGroupItem value="definitive" id="definitive" className="mt-1" />
                        <div className="flex-1">
                          <Label htmlFor="definitive" className="flex items-center gap-2 cursor-pointer font-medium text-destructive">
                            <Trash2 className="h-4 w-4" />
                            Exclusão Definitiva
                          </Label>
                          <p className="text-sm text-muted-foreground mt-1">
                            Remove o cadastro permanentemente. Esta ação não pode ser desfeita.
                            Os pedidos são mantidos para integridade.
                          </p>
                        </div>
                      </div>
                    )}
                  </RadioGroup>

                  <div className="space-y-2">
                    <Label htmlFor="reason">Motivo da exclusão (opcional)</Label>
                    <Textarea
                      id="reason"
                      placeholder="Ex: Cadastro duplicado, empresa fechou, etc."
                      value={reason}
                      onChange={(e) => setReason(e.target.value)}
                      className="resize-none"
                      rows={2}
                    />
                  </div>

                  <div className="flex items-start gap-2 pt-2">
                    <Checkbox
                      id="understood"
                      checked={understood}
                      onCheckedChange={(checked) => setUnderstood(checked as boolean)}
                    />
                    <Label htmlFor="understood" className="text-sm cursor-pointer leading-relaxed">
                      Entendo que {deletionType === 'logical' 
                        ? 'o cliente será desativado e não aparecerá mais nas listas operacionais' 
                        : 'esta ação é permanente e não pode ser desfeita'}
                    </Label>
                  </div>
                </div>
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter className="gap-2">
              <AlertDialogCancel>Cancelar</AlertDialogCancel>
              <Button
                variant="destructive"
                onClick={handleProceedToConfirm}
                disabled={!understood}
              >
                Continuar
              </Button>
            </AlertDialogFooter>
          </>
        )}

        {step === 'confirm' && (
          <>
            <AlertDialogHeader>
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-destructive/10 flex items-center justify-center">
                  {deletionType === 'logical' ? (
                    <Archive className="h-6 w-6 text-destructive" />
                  ) : (
                    <Trash2 className="h-6 w-6 text-destructive" />
                  )}
                </div>
                <AlertDialogTitle className="text-xl">
                  Confirmar {deletionType === 'logical' ? 'desativação' : 'exclusão'}
                </AlertDialogTitle>
              </div>
              <AlertDialogDescription className="text-left pt-4 space-y-4">
                <p>
                  Você está prestes a{' '}
                  {deletionType === 'logical' ? 'desativar' : 'excluir permanentemente'} o cliente:
                </p>
                <div className="bg-muted p-4 rounded-lg">
                  <p className="font-bold text-foreground text-lg">{client.company_name}</p>
                  {reason && (
                    <p className="text-sm text-muted-foreground mt-1">
                      Motivo: {reason}
                    </p>
                  )}
                </div>

                {deletionType === 'definitive' && (
                  <div className="space-y-2">
                    <Label htmlFor="confirmText" className="text-destructive font-medium">
                      Digite CONFIRMAR para prosseguir:
                    </Label>
                    <Input
                      id="confirmText"
                      value={confirmText}
                      onChange={(e) => setConfirmText(e.target.value.toUpperCase())}
                      placeholder="CONFIRMAR"
                      className="border-destructive/50 focus:border-destructive"
                    />
                  </div>
                )}
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter className="gap-2">
              <Button variant="outline" onClick={() => setStep('warning')} disabled={loading}>
                Voltar
              </Button>
              <Button
                variant="destructive"
                onClick={handleDelete}
                disabled={!canProceed || loading}
              >
                {loading ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                    Processando...
                  </>
                ) : (
                  <>
                    {deletionType === 'logical' ? (
                      <>
                        <Archive className="h-4 w-4 mr-2" />
                        Desativar Cliente
                      </>
                    ) : (
                      <>
                        <Trash2 className="h-4 w-4 mr-2" />
                        Excluir Permanentemente
                      </>
                    )}
                  </>
                )}
              </Button>
            </AlertDialogFooter>
          </>
        )}
      </AlertDialogContent>
    </AlertDialog>
  );
}
