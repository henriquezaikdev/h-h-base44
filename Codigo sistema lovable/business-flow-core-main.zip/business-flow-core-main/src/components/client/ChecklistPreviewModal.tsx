import { useState, useEffect, useMemo } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { toast } from 'sonner';
import { jsPDF } from 'jspdf';
import { FileText, Loader2, X, Maximize2, Minimize2, ChevronDown, ChevronUp, AlertTriangle, Clock, CheckCircle } from 'lucide-react';
import logoHH from '@/assets/logo-hh.png';

interface ChecklistPreviewModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  clientId: string;
  clientName: string;
  sellerName?: string;
}

interface ProductStat {
  id: string;
  name: string;
  category: string;
  lastPurchaseDate: Date | null;
  avgQtyPerMonth: number;
  avgIntervalDays: number;
  daysSinceLastPurchase: number;
  status: 'normal' | 'proximo' | 'atraso';
  purchaseDates: Date[];
}

// Calcular status de reposição baseado no intervalo médio
function calculateReplenishmentStatus(
  lastPurchaseDate: Date | null,
  avgIntervalDays: number
): 'normal' | 'proximo' | 'atraso' {
  if (!lastPurchaseDate || avgIntervalDays <= 0) return 'normal';
  
  const today = new Date();
  const daysSince = Math.floor((today.getTime() - lastPurchaseDate.getTime()) / (1000 * 60 * 60 * 24));
  
  const proximityThreshold = avgIntervalDays * 0.8;
  
  if (daysSince > avgIntervalDays) {
    return 'atraso';
  } else if (daysSince >= proximityThreshold) {
    return 'proximo';
  }
  return 'normal';
}

// Calcular intervalo médio entre compras (em dias)
function calculateAverageInterval(purchaseDates: Date[]): number {
  if (purchaseDates.length < 2) return 30;
  
  const sorted = [...purchaseDates].sort((a, b) => a.getTime() - b.getTime());
  let totalInterval = 0;
  
  for (let i = 1; i < sorted.length; i++) {
    const diff = Math.floor((sorted[i].getTime() - sorted[i-1].getTime()) / (1000 * 60 * 60 * 24));
    totalInterval += diff;
  }
  
  return Math.round(totalInterval / (sorted.length - 1));
}

// Calcular média de consumo por mês
function calculateAvgQtyPerMonth(totalQty: number, purchaseDates: Date[]): number {
  if (purchaseDates.length === 0) return 0;
  
  const sorted = [...purchaseDates].sort((a, b) => a.getTime() - b.getTime());
  const firstDate = sorted[0];
  const lastDate = sorted[sorted.length - 1];
  
  const monthsDiff = Math.max(1, 
    (lastDate.getFullYear() - firstDate.getFullYear()) * 12 + 
    (lastDate.getMonth() - firstDate.getMonth()) + 1
  );
  
  return Math.round((totalQty / monthsDiff) * 10) / 10;
}

export function ChecklistPreviewModal({ 
  open, 
  onOpenChange, 
  clientId, 
  clientName, 
  sellerName 
}: ChecklistPreviewModalProps) {
  const [loading, setLoading] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [products, setProducts] = useState<ProductStat[]>([]);
  const [selectedProducts, setSelectedProducts] = useState<Set<string>>(new Set());
  const [observations, setObservations] = useState('');
  const [isExpanded, setIsExpanded] = useState(false);
  const [overdueOpen, setOverdueOpen] = useState(true);
  const [nearbyOpen, setNearbyOpen] = useState(true);
  const [normalOpen, setNormalOpen] = useState(false);

  // Carregar dados quando o modal abrir
  useEffect(() => {
    if (open && clientId) {
      loadProducts();
    }
  }, [open, clientId]);

  const loadProducts = async () => {
    setLoading(true);
    try {
      // Buscar pedidos do cliente
      const { data: orders } = await supabase
        .from('orders')
        .select('id, order_date')
        .eq('client_id', clientId)
        .order('order_date', { ascending: false });

      if (!orders || orders.length === 0) {
        toast.error('Cliente não possui histórico de compras.');
        setProducts([]);
        setLoading(false);
        return;
      }

      const orderIds = orders.map(o => o.id);

      // Buscar itens dos pedidos
      const { data: orderItems } = await supabase
        .from('order_items')
        .select('product_name, quantity, order_id, product_id')
        .in('order_id', orderIds);

      if (!orderItems || orderItems.length === 0) {
        toast.error('Não foram encontrados itens nos pedidos.');
        setProducts([]);
        setLoading(false);
        return;
      }

      // Buscar categorias dos produtos
      const productIds = orderItems.filter(i => i.product_id).map(i => i.product_id) as string[];
      const { data: productsData } = await supabase
        .from('products')
        .select('id, category')
        .in('id', productIds);

      const productCategoryMap = new Map<string, string>();
      productsData?.forEach(p => {
        productCategoryMap.set(p.id, p.category || 'Outros');
      });

      // Mapear datas dos pedidos
      const orderDateMap = new Map<string, Date>();
      orders.forEach(o => {
        if (o.order_date) {
          orderDateMap.set(o.id, new Date(o.order_date));
        }
      });

      // Agregar produtos
      const productMap = new Map<string, {
        name: string;
        category: string;
        totalQty: number;
        purchaseDates: Date[];
      }>();

      orderItems.forEach(item => {
        const key = item.product_name.toLowerCase().trim();
        const orderDate = orderDateMap.get(item.order_id);
        const category = item.product_id ? (productCategoryMap.get(item.product_id) || 'Outros') : 'Outros';

        const existing = productMap.get(key);
        if (existing) {
          existing.totalQty += Number(item.quantity) || 0;
          if (orderDate) {
            existing.purchaseDates.push(orderDate);
          }
        } else {
          productMap.set(key, {
            name: item.product_name,
            category,
            totalQty: Number(item.quantity) || 0,
            purchaseDates: orderDate ? [orderDate] : [],
          });
        }
      });

      // Converter para ProductStat
      const today = new Date();
      const allProducts: ProductStat[] = Array.from(productMap.entries())
        .filter(([_, p]) => {
          if (p.purchaseDates.length < 1) return false;
          const sortedDates = [...p.purchaseDates].sort((a, b) => b.getTime() - a.getTime());
          const lastPurchase = sortedDates[0];
          const daysSince = Math.floor((today.getTime() - lastPurchase.getTime()) / (1000 * 60 * 60 * 24));
          return daysSince <= 361;
        })
        .map(([key, p]) => {
          const sortedDates = [...p.purchaseDates].sort((a, b) => b.getTime() - a.getTime());
          const lastPurchaseDate = sortedDates[0];
          const avgIntervalDays = calculateAverageInterval(p.purchaseDates);
          const daysSinceLastPurchase = Math.floor((today.getTime() - lastPurchaseDate.getTime()) / (1000 * 60 * 60 * 24));
          const avgQtyPerMonth = calculateAvgQtyPerMonth(p.totalQty, p.purchaseDates);
          const status = calculateReplenishmentStatus(lastPurchaseDate, avgIntervalDays);

          return {
            id: key,
            name: p.name,
            category: p.category,
            lastPurchaseDate,
            avgQtyPerMonth,
            avgIntervalDays,
            daysSinceLastPurchase,
            status,
            purchaseDates: p.purchaseDates,
          };
        })
        .sort((a, b) => {
          const statusOrder = { atraso: 0, proximo: 1, normal: 2 };
          if (statusOrder[a.status] !== statusOrder[b.status]) {
            return statusOrder[a.status] - statusOrder[b.status];
          }
          return b.daysSinceLastPurchase - a.daysSinceLastPurchase;
        });

      setProducts(allProducts);
      // Selecionar todos por padrão
      setSelectedProducts(new Set(allProducts.map(p => p.id)));
    } catch (error) {
      console.error('Erro ao carregar produtos:', error);
      toast.error('Erro ao carregar dados do checklist.');
    } finally {
      setLoading(false);
    }
  };

  // Filtrar produtos por status
  const overdueItems = useMemo(() => products.filter(p => p.status === 'atraso'), [products]);
  const nearbyItems = useMemo(() => products.filter(p => p.status === 'proximo'), [products]);
  const normalItems = useMemo(() => products.filter(p => p.status === 'normal'), [products]);

  // Contagem de selecionados
  const selectedCount = selectedProducts.size;

  const toggleProduct = (id: string) => {
    const newSelected = new Set(selectedProducts);
    if (newSelected.has(id)) {
      newSelected.delete(id);
    } else {
      newSelected.add(id);
    }
    setSelectedProducts(newSelected);
  };

  const toggleAll = (items: ProductStat[], select: boolean) => {
    const newSelected = new Set(selectedProducts);
    items.forEach(item => {
      if (select) {
        newSelected.add(item.id);
      } else {
        newSelected.delete(item.id);
      }
    });
    setSelectedProducts(newSelected);
  };

  const generatePDF = async () => {
    if (selectedProducts.size === 0) {
      toast.error('Selecione ao menos um produto para gerar o checklist.');
      return;
    }

    setGenerating(true);
    try {
      const selectedList = products.filter(p => selectedProducts.has(p.id));
      
      const doc = new jsPDF();
      const pageWidth = doc.internal.pageSize.getWidth();
      const pageHeight = doc.internal.pageSize.getHeight();
      const margin = 15;
      const contentWidth = pageWidth - (margin * 2);

      // ========== CAPA ==========
      doc.setFillColor(0, 0, 0);
      doc.rect(0, 0, pageWidth, 50, 'F');

      try {
        doc.addImage(logoHH, 'PNG', margin, 10, 30, 26);
      } catch {
        doc.setTextColor(255, 255, 255);
        doc.setFontSize(24);
        doc.setFont('helvetica', 'bold');
        doc.text('H&H', margin + 8, 28);
      }

      doc.setTextColor(255, 255, 255);
      doc.setFontSize(18);
      doc.setFont('helvetica', 'bold');
      doc.text('CHECKLIST DE REPOSIÇÃO', 55, 22);
      
      doc.setFontSize(10);
      doc.setFont('helvetica', 'normal');
      doc.text('Baseado no histórico real de consumo', 55, 32);

      doc.setFillColor(249, 115, 22);
      doc.rect(0, 50, pageWidth, 4, 'F');

      let yPos = 68;

      doc.setTextColor(0, 0, 0);
      doc.setFontSize(16);
      doc.setFont('helvetica', 'bold');
      doc.text(clientName, margin, yPos);

      yPos += 10;

      doc.setTextColor(107, 114, 128);
      doc.setFontSize(10);
      doc.setFont('helvetica', 'normal');
      doc.text(`Data de geração: ${new Date().toLocaleDateString('pt-BR')}`, margin, yPos);
      if (sellerName) {
        doc.text(`Vendedor: ${sellerName}`, margin + 80, yPos);
      }

      yPos += 12;

      // Legenda
      doc.setFillColor(245, 245, 245);
      doc.roundedRect(margin, yPos - 4, contentWidth, 16, 2, 2, 'F');
      
      doc.setFontSize(9);
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(60, 60, 60);
      doc.text('LEGENDA:', margin + 5, yPos + 3);
      
      const legendY = yPos + 3;
      
      doc.setFont('helvetica', 'normal');
      doc.setFillColor(34, 197, 94);
      doc.circle(margin + 45, legendY - 1, 2, 'F');
      doc.setTextColor(34, 197, 94);
      doc.text('Consumo normal', margin + 49, legendY);
      
      doc.setFillColor(234, 179, 8);
      doc.circle(margin + 95, legendY - 1, 2, 'F');
      doc.setTextColor(180, 140, 0);
      doc.text('Reposição próxima', margin + 99, legendY);
      
      doc.setFillColor(239, 68, 68);
      doc.circle(margin + 152, legendY - 1, 2, 'F');
      doc.setTextColor(220, 38, 38);
      doc.text('Reposição em atraso', margin + 156, legendY);

      yPos += 22;

      // Agrupar por categoria
      const productsByCategory = new Map<string, ProductStat[]>();
      selectedList.forEach(product => {
        const cat = product.category || 'Outros';
        if (!productsByCategory.has(cat)) {
          productsByCategory.set(cat, []);
        }
        productsByCategory.get(cat)!.push(product);
      });

      const categories = Array.from(productsByCategory.entries())
        .map(([name, items]) => ({ name, items }))
        .filter(cat => cat.items.length > 0)
        .sort((a, b) => {
          const aUrgent = a.items.filter(i => i.status === 'atraso').length;
          const bUrgent = b.items.filter(i => i.status === 'atraso').length;
          return bUrgent - aUrgent;
        });

      // Renderizar cada categoria
      categories.forEach(category => {
        const estimatedHeight = 20 + (category.items.length * 22);
        if (yPos + Math.min(estimatedHeight, 60) > pageHeight - 30) {
          doc.addPage();
          yPos = 20;
        }

        doc.setFillColor(40, 40, 40);
        doc.roundedRect(margin, yPos - 4, contentWidth, 8, 1, 1, 'F');
        doc.setTextColor(255, 255, 255);
        doc.setFontSize(10);
        doc.setFont('helvetica', 'bold');
        doc.text(category.name.toUpperCase(), margin + 4, yPos + 1);

        yPos += 12;

        category.items.forEach((product, index) => {
          if (yPos + 20 > pageHeight - 25) {
            doc.addPage();
            yPos = 20;
          }

          if (index % 2 === 0) {
            doc.setFillColor(248, 250, 252);
            doc.rect(margin, yPos - 4, contentWidth, 18, 'F');
          }

          let cleanName = product.name
            .replace(/^[\w\-\.]+\s*[-–]\s*/i, '')
            .replace(/^\d+\s+/, '')
            .trim();
          
          if (cleanName.length > 50) {
            cleanName = cleanName.substring(0, 47) + '...';
          }

          const statusColors = {
            normal: [34, 197, 94],
            proximo: [234, 179, 8],
            atraso: [239, 68, 68],
          };
          const color = statusColors[product.status];
          doc.setFillColor(color[0], color[1], color[2]);
          doc.circle(margin + 4, yPos, 2.5, 'F');

          doc.setTextColor(0, 0, 0);
          doc.setFontSize(9);
          doc.setFont('helvetica', 'bold');
          doc.text(cleanName, margin + 10, yPos + 1);

          yPos += 5;

          doc.setFontSize(8);
          doc.setFont('helvetica', 'normal');
          doc.setTextColor(107, 114, 128);

          const lastPurchaseStr = product.lastPurchaseDate 
            ? product.lastPurchaseDate.toLocaleDateString('pt-BR')
            : 'N/A';
          
          const details = `Última compra: ${lastPurchaseStr}  |  Média: ${product.avgQtyPerMonth} un/mês  |  Intervalo: ${product.avgIntervalDays} dias`;
          doc.text(details, margin + 10, yPos + 1);

          yPos += 5;

          const statusTextColors = {
            normal: [34, 150, 74],
            proximo: [180, 140, 0],
            atraso: [200, 38, 38],
          };
          const textColor = statusTextColors[product.status];
          doc.setTextColor(textColor[0], textColor[1], textColor[2]);
          doc.setFont('helvetica', 'bold');
          
          let statusText = '';
          if (product.status === 'normal') {
            statusText = 'Normal';
          } else if (product.status === 'proximo') {
            statusText = `Próximo - ${product.daysSinceLastPurchase} dias`;
          } else {
            statusText = `Atraso - ${product.daysSinceLastPurchase} dias`;
          }
          doc.text(statusText, margin + 10, yPos + 1);

          yPos += 10;

          doc.setDrawColor(230, 230, 230);
          doc.setLineWidth(0.2);
          doc.line(margin + 10, yPos - 3, pageWidth - margin, yPos - 3);
        });

        yPos += 6;
      });

      // Observações
      if (observations.trim()) {
        if (yPos + 30 > pageHeight - 30) {
          doc.addPage();
          yPos = 20;
        }

        doc.setFillColor(254, 243, 199);
        doc.roundedRect(margin, yPos - 4, contentWidth, 8, 1, 1, 'F');
        doc.setTextColor(146, 64, 14);
        doc.setFontSize(10);
        doc.setFont('helvetica', 'bold');
        doc.text('OBSERVAÇÕES', margin + 4, yPos + 1);

        yPos += 12;

        doc.setTextColor(60, 60, 60);
        doc.setFontSize(9);
        doc.setFont('helvetica', 'normal');
        
        const lines = doc.splitTextToSize(observations, contentWidth - 10);
        lines.forEach((line: string) => {
          if (yPos > pageHeight - 20) {
            doc.addPage();
            yPos = 20;
          }
          doc.text(line, margin + 5, yPos);
          yPos += 5;
        });

        yPos += 8;
      }

      // Resumo
      if (yPos + 35 > pageHeight - 25) {
        doc.addPage();
        yPos = 20;
      }

      const atrasados = selectedList.filter(p => p.status === 'atraso').length;
      const proximos = selectedList.filter(p => p.status === 'proximo').length;
      const normais = selectedList.filter(p => p.status === 'normal').length;

      doc.setFillColor(249, 115, 22);
      doc.roundedRect(margin, yPos - 4, contentWidth, 8, 1, 1, 'F');
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(10);
      doc.setFont('helvetica', 'bold');
      doc.text('RESUMO', margin + 4, yPos + 1);

      yPos += 12;

      doc.setTextColor(60, 60, 60);
      doc.setFontSize(9);
      doc.setFont('helvetica', 'normal');
      doc.text(`Total de itens: ${selectedList.length}`, margin, yPos);
      yPos += 6;
      
      let xPos = margin;
      
      doc.setFillColor(239, 68, 68);
      doc.circle(xPos + 2, yPos - 1.5, 2, 'F');
      doc.setTextColor(220, 38, 38);
      doc.text(`Em atraso: ${atrasados}`, xPos + 6, yPos);
      
      xPos = margin + 50;
      doc.setFillColor(234, 179, 8);
      doc.circle(xPos + 2, yPos - 1.5, 2, 'F');
      doc.setTextColor(180, 140, 0);
      doc.text(`Próxima: ${proximos}`, xPos + 6, yPos);
      
      xPos = margin + 95;
      doc.setFillColor(34, 197, 94);
      doc.circle(xPos + 2, yPos - 1.5, 2, 'F');
      doc.setTextColor(34, 150, 74);
      doc.text(`Normal: ${normais}`, xPos + 6, yPos);

      // Rodapé
      const footerY = pageHeight - 12;
      doc.setDrawColor(249, 115, 22);
      doc.setLineWidth(0.8);
      doc.line(margin, footerY - 8, pageWidth - margin, footerY - 8);

      doc.setTextColor(107, 114, 128);
      doc.setFontSize(7);
      doc.setFont('helvetica', 'italic');
      doc.text('Checklist gerado automaticamente com base no histórico de compras do cliente.', margin, footerY - 3);
      
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8);
      doc.text('H&H Suprimentos Corporativos', margin, footerY + 2);
      doc.text(`Gerado em ${new Date().toLocaleString('pt-BR')}`, pageWidth - margin - 55, footerY + 2);

      // Salvar
      const fileName = `checklist-reposicao-${clientName.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '')}.pdf`;
      doc.save(fileName);

      toast.success(`Checklist gerado com ${selectedList.length} itens!`);
      onOpenChange(false);
    } catch (error) {
      console.error('Erro ao gerar PDF:', error);
      toast.error('Erro ao gerar o PDF.');
    } finally {
      setGenerating(false);
    }
  };

  // Renderizar item do produto
  const renderProductItem = (product: ProductStat) => {
    const isSelected = selectedProducts.has(product.id);
    const statusColors = {
      atraso: 'border-l-red-500 bg-red-50/50',
      proximo: 'border-l-yellow-500 bg-yellow-50/50',
      normal: 'border-l-green-500 bg-green-50/50',
    };

    const lastPurchaseStr = product.lastPurchaseDate 
      ? product.lastPurchaseDate.toLocaleDateString('pt-BR')
      : 'N/A';

    return (
      <div 
        key={product.id}
        className={`border-l-4 rounded-lg p-3 transition-all ${statusColors[product.status]} ${isSelected ? 'ring-1 ring-primary/30' : 'opacity-60'}`}
      >
        <div className="flex items-start gap-3">
          <Checkbox 
            checked={isSelected}
            onCheckedChange={() => toggleProduct(product.id)}
            className="mt-1"
          />
          <div className="flex-1 min-w-0">
            <p className="font-medium text-sm truncate">{product.name}</p>
            <p className="text-xs text-muted-foreground">
              {product.category} • Última compra: {lastPurchaseStr} ({product.daysSinceLastPurchase} dias)
            </p>
            <p className="text-xs text-muted-foreground">
              Média: {product.avgQtyPerMonth} un/mês • Intervalo: {product.avgIntervalDays} dias
            </p>
          </div>
        </div>
      </div>
    );
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className={`${isExpanded ? 'max-w-4xl h-[90vh]' : 'max-w-2xl max-h-[85vh]'} flex flex-col p-0 gap-0 transition-all duration-200`}>
        <DialogHeader className="p-4 pb-2 border-b flex-shrink-0">
          <div className="flex items-center justify-between">
            <div>
              <DialogTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Checklist de Reposição - {clientName}
              </DialogTitle>
              <DialogDescription>
                Baseado no histórico de compras e ciclo de reposição do cliente
              </DialogDescription>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setIsExpanded(!isExpanded)}
                title={isExpanded ? 'Reduzir' : 'Expandir'}
              >
                {isExpanded ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => onOpenChange(false)}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </DialogHeader>

        {loading ? (
          <div className="flex-1 flex items-center justify-center">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : products.length === 0 ? (
          <div className="flex-1 flex items-center justify-center text-muted-foreground">
            Nenhum produto encontrado no histórico do cliente.
          </div>
        ) : (
          <>
            {/* Badges de resumo */}
            <div className="flex flex-wrap gap-2 p-4 pb-2 border-b">
              <Badge variant="destructive" className="gap-1">
                <AlertTriangle className="h-3 w-3" />
                {overdueItems.length} em atraso
              </Badge>
              <Badge variant="outline" className="gap-1 border-yellow-500 text-yellow-700">
                <Clock className="h-3 w-3" />
                {nearbyItems.length} próximos
              </Badge>
              <Badge variant="outline" className="gap-1 border-green-500 text-green-700">
                <CheckCircle className="h-3 w-3" />
                {normalItems.length} normais
              </Badge>
              <Badge variant="secondary" className="gap-1">
                {selectedCount} selecionados
              </Badge>
            </div>

            {/* Lista de produtos com scroll */}
            <ScrollArea className={`flex-1 overflow-auto ${isExpanded ? 'h-[60vh]' : 'h-[400px]'}`}>
              <div className="p-4 space-y-4">
                {/* Em atraso */}
                {overdueItems.length > 0 && (
                  <Collapsible open={overdueOpen} onOpenChange={setOverdueOpen}>
                    <CollapsibleTrigger asChild>
                      <Button variant="ghost" className="w-full justify-between p-2 h-auto">
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 rounded-full bg-red-500" />
                          <span className="font-medium">Reposição em Atraso ({overdueItems.length})</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              const allSelected = overdueItems.every(i => selectedProducts.has(i.id));
                              toggleAll(overdueItems, !allSelected);
                            }}
                          >
                            {overdueItems.every(i => selectedProducts.has(i.id)) ? 'Desmarcar todos' : 'Selecionar todos'}
                          </Button>
                          {overdueOpen ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                        </div>
                      </Button>
                    </CollapsibleTrigger>
                    <CollapsibleContent className="space-y-2 mt-2">
                      {overdueItems.map(renderProductItem)}
                    </CollapsibleContent>
                  </Collapsible>
                )}

                {/* Próximos */}
                {nearbyItems.length > 0 && (
                  <Collapsible open={nearbyOpen} onOpenChange={setNearbyOpen}>
                    <CollapsibleTrigger asChild>
                      <Button variant="ghost" className="w-full justify-between p-2 h-auto">
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 rounded-full bg-yellow-500" />
                          <span className="font-medium">Reposição Próxima ({nearbyItems.length})</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              const allSelected = nearbyItems.every(i => selectedProducts.has(i.id));
                              toggleAll(nearbyItems, !allSelected);
                            }}
                          >
                            {nearbyItems.every(i => selectedProducts.has(i.id)) ? 'Desmarcar todos' : 'Selecionar todos'}
                          </Button>
                          {nearbyOpen ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                        </div>
                      </Button>
                    </CollapsibleTrigger>
                    <CollapsibleContent className="space-y-2 mt-2">
                      {nearbyItems.map(renderProductItem)}
                    </CollapsibleContent>
                  </Collapsible>
                )}

                {/* Normais */}
                {normalItems.length > 0 && (
                  <Collapsible open={normalOpen} onOpenChange={setNormalOpen}>
                    <CollapsibleTrigger asChild>
                      <Button variant="ghost" className="w-full justify-between p-2 h-auto">
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 rounded-full bg-green-500" />
                          <span className="font-medium">Consumo Normal ({normalItems.length})</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              const allSelected = normalItems.every(i => selectedProducts.has(i.id));
                              toggleAll(normalItems, !allSelected);
                            }}
                          >
                            {normalItems.every(i => selectedProducts.has(i.id)) ? 'Desmarcar todos' : 'Selecionar todos'}
                          </Button>
                          {normalOpen ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                        </div>
                      </Button>
                    </CollapsibleTrigger>
                    <CollapsibleContent className="space-y-2 mt-2">
                      {normalItems.map(renderProductItem)}
                    </CollapsibleContent>
                  </Collapsible>
                )}
              </div>
            </ScrollArea>

            {/* Observações */}
            <div className="p-4 pt-2 border-t">
              <label className="text-sm font-medium text-muted-foreground">Observações (opcional)</label>
              <Textarea
                placeholder="Adicione observações para o checklist..."
                value={observations}
                onChange={(e) => setObservations(e.target.value)}
                className="mt-1 resize-none"
                rows={2}
              />
            </div>

            {/* Footer */}
            <div className="p-4 pt-0 flex items-center justify-between border-t bg-muted/30">
              <p className="text-xs text-muted-foreground flex items-center gap-1">
                <AlertTriangle className="h-3 w-3 text-amber-500" />
                Revise os itens antes de gerar o PDF
              </p>
              <Button 
                onClick={generatePDF}
                disabled={generating || selectedCount === 0}
                className="gap-2"
              >
                {generating ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Gerando...
                  </>
                ) : (
                  <>
                    <FileText className="h-4 w-4" />
                    Gerar PDF ({selectedCount} itens)
                  </>
                )}
              </Button>
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
