import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Package, ExternalLink, ChevronDown, ChevronUp, Loader2 } from 'lucide-react';
import { format, startOfMonth, endOfMonth } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';

const now = new Date();
const MONTH_START = format(startOfMonth(now), 'yyyy-MM-dd');
const MONTH_END = format(endOfMonth(now), 'yyyy-MM-dd');
const MONTH_LABEL = format(now, 'MMMM/yyyy', { locale: ptBR });

interface ClientDeliverySectionProps {
  clientId: string;
}

interface EntregaEO {
  id: string;
  data_baixa: string | null;
  destinatario: string | null;
  entregador: string | null;
  status: string | null;
  link: string | null;
  controle_pedido: string | null;
}

const STATUS_CONFIG: Record<string, { className: string; label: string }> = {
  ENTREGUE: { className: 'bg-emerald-500/15 text-emerald-600 border-emerald-500/30', label: 'Entregue' },
  COLETADO: { className: 'bg-accent/50 text-accent-foreground border-accent', label: 'Coletado' },
  CANCELADA: { className: 'bg-destructive/15 text-destructive border-destructive/30', label: 'Cancelada' },
};

const PAGE_SIZE = 10;

export function ClientDeliverySection({ clientId }: ClientDeliverySectionProps) {
  const [totalCount, setTotalCount] = useState<number | null>(null);
  const [entregas, setEntregas] = useState<EntregaEO[]>([]);
  const [loading, setLoading] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const [hasMore, setHasMore] = useState(false);
  const [countLoading, setCountLoading] = useState(true);

  // Fetch only the count on mount
  useEffect(() => {
    fetchCount();
  }, [clientId]);

  const fetchCount = async () => {
    setCountLoading(true);
    try {
      // Get order IDs and numbers for this client
      const { data: orders } = await supabase
        .from('orders')
        .select('id, order_number')
        .eq('client_id', clientId)
        .or('is_deleted.is.null,is_deleted.eq.false');

      if (!orders || orders.length === 0) {
        setTotalCount(0);
        setCountLoading(false);
        return;
      }

      const orderIds = orders.map(o => o.id);
      const orderNumbers = orders.map(o => String(o.order_number)).filter(n => n && n !== 'null');

      // Primary match by pedido_id (current month only)
      const { count: primaryCount } = await supabase
        .from('entregas_eo')
        .select('id', { count: 'exact', head: true })
        .in('pedido_id', orderIds)
        .gte('data_baixa', MONTH_START)
        .lte('data_baixa', MONTH_END);

      // Fallback match by controle_pedido (current month only)
      let fallbackCount = 0;
      if (orderNumbers.length > 0) {
        const { count } = await supabase
          .from('entregas_eo')
          .select('id', { count: 'exact', head: true })
          .in('controle_pedido', orderNumbers)
          .not('pedido_id', 'in', `(${orderIds.join(',')})`)
          .gte('data_baixa', MONTH_START)
          .lte('data_baixa', MONTH_END);
        fallbackCount = count || 0;
      }

      setTotalCount((primaryCount || 0) + fallbackCount);
    } catch (err) {
      console.error('Error fetching delivery count:', err);
      setTotalCount(0);
    } finally {
      setCountLoading(false);
    }
  };

  const fetchEntregas = useCallback(async (offset: number) => {
    setLoading(true);
    try {
      const { data: orders } = await supabase
        .from('orders')
        .select('id, order_number')
        .eq('client_id', clientId)
        .or('is_deleted.is.null,is_deleted.eq.false');

      if (!orders || orders.length === 0) {
        setEntregas([]);
        setHasMore(false);
        setLoading(false);
        return;
      }

      const orderIds = orders.map(o => o.id);
      const orderNumbers = orders.map(o => String(o.order_number)).filter(n => n && n !== 'null');

      // Build combined results: primary first, then fallback
      // Primary match (current month only)
      const { data: primaryData } = await supabase
        .from('entregas_eo')
        .select('id, data_baixa, destinatario, entregador, status, link, controle_pedido')
        .in('pedido_id', orderIds)
        .gte('data_baixa', MONTH_START)
        .lte('data_baixa', MONTH_END)
        .order('data_baixa', { ascending: false, nullsFirst: false });

      // Fallback match (current month only)
      let fallbackData: EntregaEO[] = [];
      if (orderNumbers.length > 0) {
        const { data } = await supabase
          .from('entregas_eo')
          .select('id, data_baixa, destinatario, entregador, status, link, controle_pedido')
          .in('controle_pedido', orderNumbers)
          .not('pedido_id', 'in', `(${orderIds.join(',')})`)
          .gte('data_baixa', MONTH_START)
          .lte('data_baixa', MONTH_END)
          .order('data_baixa', { ascending: false, nullsFirst: false });
        fallbackData = (data as EntregaEO[]) || [];
      }

      const allEntregas = [...(primaryData || []), ...fallbackData] as EntregaEO[];
      const paged = allEntregas.slice(0, offset + PAGE_SIZE);

      setEntregas(paged);
      setHasMore(paged.length < allEntregas.length);
    } catch (err) {
      console.error('Error fetching entregas:', err);
    } finally {
      setLoading(false);
    }
  }, [clientId]);

  const handleToggle = () => {
    const next = !isOpen;
    setIsOpen(next);
    if (next && entregas.length === 0) {
      fetchEntregas(0);
    }
  };

  const handleLoadMore = () => {
    fetchEntregas(entregas.length);
  };

  const getStatusBadge = (status: string | null) => {
    const normalized = (status || '').toUpperCase().trim();
    const cfg = STATUS_CONFIG[normalized];
    if (cfg) {
      return <span className={`text-xs px-2 py-0.5 rounded-md border font-medium whitespace-nowrap ${cfg.className}`}>{cfg.label}</span>;
    }
    return <Badge variant="outline" className="text-xs">{status || 'Desconhecido'}</Badge>;
  };

  return (
    <div className="bg-card rounded-xl border border-border shadow-sm">
      <button
        onClick={handleToggle}
        className="w-full flex items-center justify-between p-4 hover:bg-muted/30 transition-colors rounded-t-xl"
      >
        <h3 className="font-semibold text-foreground flex items-center gap-2">
          <Package size={18} />
          📦 Entregas
          {!countLoading && totalCount !== null && (
            <span className="text-sm font-normal text-muted-foreground">({totalCount} em {MONTH_LABEL})</span>
          )}
        </h3>
        {isOpen ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
      </button>

      {isOpen && (
        <div className="px-4 pb-4 space-y-2">
          {loading && entregas.length === 0 ? (
            <div className="flex justify-center py-8">
              <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
          ) : entregas.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-4">
              Nenhuma entrega vinculada a este cliente.
            </p>
          ) : (
            <>
              <div className="space-y-2">
                {entregas.map((e) => (
                  <div key={e.id} className="flex items-center gap-3 p-3 rounded-lg bg-muted/20 border border-border">
                    {getStatusBadge(e.status)}
                    <div className="flex-1 min-w-0 space-y-0.5">
                      <div className="flex flex-wrap gap-x-4 text-sm">
                        {e.data_baixa && (
                          <span className="font-medium text-foreground">
                            {format(new Date(e.data_baixa), 'dd/MM/yyyy', { locale: ptBR })}
                          </span>
                        )}
                        {e.destinatario && (
                          <span className="text-muted-foreground truncate">🏷️ {e.destinatario}</span>
                        )}
                      </div>
                      {e.entregador && (
                        <p className="text-xs text-muted-foreground">🚚 {e.entregador}</p>
                      )}
                    </div>
                    {e.link && (
                      <a
                        href={e.link}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-primary hover:text-primary/80 shrink-0"
                        title="Abrir rastreamento"
                      >
                        <ExternalLink size={14} />
                      </a>
                    )}
                  </div>
                ))}
              </div>

              {hasMore && (
                <div className="flex justify-center pt-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleLoadMore}
                    disabled={loading}
                    className="text-xs"
                  >
                    {loading ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : null}
                    Ver mais
                  </Button>
                </div>
              )}
            </>
          )}
        </div>
      )}
    </div>
  );
}
