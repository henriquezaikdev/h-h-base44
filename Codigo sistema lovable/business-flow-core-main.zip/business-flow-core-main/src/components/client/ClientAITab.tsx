import { useState } from 'react';
import { Loader2, Send, Bot, Lightbulb, Target, Clock, AlertTriangle, CheckCircle, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { useAuth } from '@/hooks/useAuth';
import { calculateDaysSinceDate } from '@/lib/utils';

interface ClientAITabProps {
  clientId: string;
  clientName: string;
  clientData: any;
}

const EXAMPLE_QUESTIONS = [
  "Qual é o melhor approach para este cliente?",
  "Que produtos sugerir baseado no histórico?",
  "Melhor horário para ligar?",
  "Como recuperar este cliente inativo?",
  "Qual estratégia de negociação usar?",
];

export function ClientAITab({ clientId, clientName, clientData }: ClientAITabProps) {
  const { seller } = useAuth();
  const [question, setQuestion] = useState('');
  const [loading, setLoading] = useState(false);
  const [response, setResponse] = useState<string | null>(null);

  const handleAsk = async () => {
    if (!question.trim() || !seller?.id) {
      toast.error('Digite sua pergunta');
      return;
    }

    setLoading(true);
    try {
      // Gather client context
      const [
        { data: orders },
        { data: interactions },
        { data: buyers },
        { data: completedTasks },
      ] = await Promise.all([
        supabase.from('orders').select('*').eq('client_id', clientId).order('order_date', { ascending: false }).limit(30),
        supabase.from('interactions').select('*').eq('client_id', clientId).order('interaction_date', { ascending: false }).limit(50),
        supabase.from('buyers').select('*').eq('client_id', clientId),
        // Also fetch completed tasks as they represent interactions
        supabase.from('tasks').select('*').eq('client_id', clientId).eq('status', 'concluida').order('completed_at', { ascending: false }).limit(50),
      ]);

      // Calculate days dynamically for accurate AI context
      const dynamicDaysSinceOrder = calculateDaysSinceDate(clientData.last_order_date) ?? clientData.days_since_last_order;
      
      const contextData = {
        cliente: {
          nome: clientName,
          status: clientData.status,
          classificacao: clientData.classification,
          ranking: clientData.ranking_tier,
          faturamento_total: clientData.total_revenue,
          dias_sem_pedido: dynamicDaysSinceOrder,
          observacoes: clientData.observations,
          anotacoes_manuais: clientData.manual_notes,
        },
        compradores: buyers?.map(b => ({
          nome: b.name,
          whatsapp: b.whatsapp,
          email: b.email,
        })) || [],
        ultimos_pedidos: orders?.slice(0, 20).map(o => ({
          data: o.order_date,
          valor: o.total,
          numero: o.order_number,
        })) || [],
        ultimas_interacoes: interactions?.slice(0, 30).map(i => ({
          tipo: i.interaction_type,
          data: i.interaction_date,
          notas: i.interaction_notes,
        })) || [],
        tarefas_concluidas: completedTasks?.slice(0, 30).map((t: any) => ({
          tipo: t.contact_type,
          data: t.completed_at || t.task_date,
          notas: t.completion_notes || t.notes,
          motivo_contato: t.contact_reason,
          contato_efetivo: t.contact_successful,
        })) || [],
        total_pedidos: orders?.length || 0,
        total_interacoes: (interactions?.length || 0) + (completedTasks?.length || 0),
      };

      const { data, error } = await supabase.functions.invoke('perplexity-assistant', {
        body: {
          mode: 'ask',
          sellerId: seller.id,
          contextText: JSON.stringify(contextData, null, 2),
          userQuestion: question,
          copyForWhatsApp: false,
        },
      });

      if (error) throw error;
      setResponse(data.answer);
    } catch (error) {
      console.error('Error calling AI:', error);
      toast.error('Erro ao consultar IA');
    } finally {
      setLoading(false);
    }
  };

  const handleExampleClick = (example: string) => {
    setQuestion(example);
  };

  const parseResponse = (text: string) => {
    // Simple parsing to add structure
    const sections: { icon: any; title: string; content: string; color: string }[] = [];
    const lines = text.split('\n');
    let currentSection = { icon: Lightbulb, title: 'Resposta', content: '', color: 'teal' };
    
    lines.forEach(line => {
      const cleanLine = line.trim();
      
      if (cleanLine.toLowerCase().includes('## diagnóstico') || cleanLine.toLowerCase().includes('diagnóstico')) {
        if (currentSection.content) sections.push({ ...currentSection });
        currentSection = { icon: Target, title: 'Diagnóstico', content: '', color: 'blue' };
      } else if (cleanLine.toLowerCase().includes('## ações') || cleanLine.toLowerCase().includes('ações recomendadas')) {
        if (currentSection.content) sections.push({ ...currentSection });
        currentSection = { icon: CheckCircle, title: 'Ações Recomendadas', content: '', color: 'green' };
      } else if (cleanLine.toLowerCase().includes('## pontos') || cleanLine.toLowerCase().includes('pontos de atenção')) {
        if (currentSection.content) sections.push({ ...currentSection });
        currentSection = { icon: AlertTriangle, title: 'Pontos de Atenção', content: '', color: 'amber' };
      } else if (cleanLine.toLowerCase().includes('## próximo') || cleanLine.toLowerCase().includes('próximo passo')) {
        if (currentSection.content) sections.push({ ...currentSection });
        currentSection = { icon: Clock, title: 'Próximo Passo', content: '', color: 'purple' };
      } else if (cleanLine && !cleanLine.startsWith('##')) {
        currentSection.content += (currentSection.content ? '\n' : '') + cleanLine;
      }
    });
    
    if (currentSection.content) sections.push(currentSection);
    
    return sections.length > 0 ? sections : [{ icon: Lightbulb, title: 'Resposta', content: text, color: 'teal' }];
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3 pb-4 border-b border-border">
        <div className="p-2 bg-gradient-to-br from-teal-500/20 to-purple-500/20 rounded-xl">
          <Sparkles className="h-6 w-6 text-teal-600" />
        </div>
        <div>
          <h3 className="font-semibold text-lg">Assistente IA - {clientName}</h3>
          <p className="text-sm text-muted-foreground">Faça perguntas sobre este cliente</p>
        </div>
      </div>

      {/* Example Questions */}
      {!response && (
        <div className="space-y-2">
          <p className="text-sm text-muted-foreground">Sugestões de perguntas:</p>
          <div className="flex flex-wrap gap-2">
            {EXAMPLE_QUESTIONS.map((example, i) => (
              <Button
                key={i}
                variant="outline"
                size="sm"
                className="text-xs"
                onClick={() => handleExampleClick(example)}
              >
                {example}
              </Button>
            ))}
          </div>
        </div>
      )}

      {/* Question Input */}
      <div className="space-y-3">
        <Textarea
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          placeholder="Digite sua pergunta sobre este cliente..."
          rows={3}
          className="resize-none"
        />
        <div className="flex justify-end">
          <Button onClick={handleAsk} disabled={loading || !question.trim()}>
            {loading ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Consultando...
              </>
            ) : (
              <>
                <Send className="h-4 w-4 mr-2" />
                Perguntar
              </>
            )}
          </Button>
        </div>
      </div>

      {/* Response */}
      {response && (
        <ScrollArea className="h-[400px]">
          <div className="space-y-4">
            {parseResponse(response).map((section, idx) => {
              const Icon = section.icon;
              const colorClasses: Record<string, string> = {
                teal: 'bg-teal-50 dark:bg-teal-950/30 border-teal-200 dark:border-teal-800',
                blue: 'bg-blue-50 dark:bg-blue-950/30 border-blue-200 dark:border-blue-800',
                green: 'bg-green-50 dark:bg-green-950/30 border-green-200 dark:border-green-800',
                amber: 'bg-amber-50 dark:bg-amber-950/30 border-amber-200 dark:border-amber-800',
                purple: 'bg-purple-50 dark:bg-purple-950/30 border-purple-200 dark:border-purple-800',
              };
              const iconColorClasses: Record<string, string> = {
                teal: 'text-teal-600',
                blue: 'text-blue-600',
                green: 'text-green-600',
                amber: 'text-amber-600',
                purple: 'text-purple-600',
              };
              
              return (
                <div key={idx} className={`p-4 rounded-lg border ${colorClasses[section.color]}`}>
                  <div className={`flex items-center gap-2 mb-2 ${iconColorClasses[section.color]} font-semibold`}>
                    <Icon className="h-4 w-4" />
                    {section.title}
                  </div>
                  <div className="text-sm whitespace-pre-wrap">{section.content}</div>
                </div>
              );
            })}
          </div>
        </ScrollArea>
      )}
    </div>
  );
}
