import { useState } from 'react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { MessageSquare, Phone, MessageCircle, Check, Clock, Pencil, Trash2, CheckCircle, XCircle } from 'lucide-react';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';
import { ChevronDown, ChevronUp } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { EditTaskModal } from '@/components/tasks/EditTaskModal';
import { DeleteTaskModal } from '@/components/tasks/DeleteTaskModal';
import { useAuth } from '@/hooks/useAuth';
import { useSellersData } from '@/hooks/useSellersData';
import { TaskData } from '@/hooks/useTasksData';

interface Task {
  id: string;
  contact_type: string;
  contact_reason?: string;
  task_date: string;
  task_time: string | null;
  notes: string | null;
  status: string;
  completed_at: string | null;
  created_at: string;
  seller_name?: string;
  created_by_seller_id?: string | null;
  priority?: string;
  completion_notes?: string | null;
  contact_successful?: boolean | null;
  is_attempt?: boolean | null;
}

interface InteractionsSectionProps {
  clientId: string;
  clientName: string;
  tasks?: Task[];
  currentSellerId: string | null;
  onRefresh: () => void;
  maxVisible?: number;
  pageSize?: number;
}

const CONTACT_TYPE_LABELS: Record<string, { label: string; icon: typeof Phone }> = {
  ligacao: { label: 'Ligação', icon: Phone },
  whatsapp: { label: 'WhatsApp', icon: MessageCircle },
};

interface HistoryItem {
  id: string;
  originalId: string;
  contactType: string;
  notes: string;
  date: string;
  time: string;
  sellerName?: string;
  sellerId?: string | null;
  status: string;
  createdAt: string;
  completedAt: string | null;
  completionNotes?: string | null;
  contactSuccessful?: boolean | null;
  isAttempt?: boolean | null;
  originalTask: Task;
}

export function InteractionsSection({ 
  clientId,
  clientName,
  tasks = [],
  currentSellerId,
  onRefresh,
  maxVisible = 5,
  pageSize = 10
}: InteractionsSectionProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [showAll, setShowAll] = useState(false);
  const [visibleCount, setVisibleCount] = useState(maxVisible);
  const [editingTask, setEditingTask] = useState<TaskData | null>(null);
  const [deletingTask, setDeletingTask] = useState<{ id: string; isCompleted: boolean } | null>(null);
  
  const { seller, isAdminOrOwner } = useAuth();
  const { sellers } = useSellersData();

  // Only show completed tasks as history items (tasks are the single source of truth)
  const completedTasks = tasks.filter(t => t.status === 'concluida');
  
  const historyItems: HistoryItem[] = completedTasks.map(t => ({
    id: t.id,
    originalId: t.id,
    contactType: t.contact_type,
    notes: t.completion_notes || t.notes || `Tarefa de ${t.contact_type === 'ligacao' ? 'ligação' : 'WhatsApp'}`,
    date: t.completed_at ? t.completed_at.split('T')[0] : t.task_date,
    time: t.task_time || '',
    sellerName: t.seller_name,
    sellerId: t.created_by_seller_id || null,
    status: t.status,
    createdAt: t.created_at,
    completedAt: t.completed_at,
    completionNotes: t.completion_notes,
    contactSuccessful: t.contact_successful,
    isAttempt: t.is_attempt,
    originalTask: t,
  })).sort((a, b) => {
    // Sort by completed date descending
    const dateA = a.completedAt ? new Date(a.completedAt).getTime() : new Date(a.createdAt).getTime();
    const dateB = b.completedAt ? new Date(b.completedAt).getTime() : new Date(b.createdAt).getTime();
    return dateB - dateA;
  });

  // Limit visible items with progressive loading
  const visibleItems = historyItems.slice(0, visibleCount);
  const hasMore = historyItems.length > visibleCount;
  const remainingCount = historyItems.length - visibleCount;

  const handleLoadMore = () => {
    setVisibleCount(prev => Math.min(prev + pageSize, historyItems.length));
  };

  const handleCollapse = () => {
    setVisibleCount(maxVisible);
  };

  // Check if user can edit/delete an item
  const canManageItem = (item: HistoryItem) => {
    if (isAdminOrOwner) return true;
    return item.sellerId === seller?.id;
  };

  const handleEditTask = (item: HistoryItem) => {
    const task = item.originalTask;
    const taskData: TaskData = {
      id: task.id,
      clientId: clientId,
      clientName: clientName,
      clientRankingTier: 'eventual',
      clientSellerId: null,
      contactType: task.contact_type as 'ligacao' | 'whatsapp',
      contactReason: (task.contact_reason as 'RETORNO' | 'ACOMPANHAMENTO' | 'VENDA' | 'POS_VENDA') || 'RETORNO',
      taskDate: task.task_date,
      taskTime: task.task_time,
      notes: task.notes,
      status: task.status as 'pendente' | 'concluida',
      createdAt: task.created_at,
      completedAt: task.completed_at,
      createdBySellerId: task.created_by_seller_id || null,
      priority: (task.priority as 'alta' | 'media' | 'baixa') || 'media',
      // Campos de orçamento em aberto
      temOrcamentoAberto: false,
      orcamentoCaCodigo: null,
      orcamentoValor: null,
      orcamentoAbertoEm: null,
    };
    setEditingTask(taskData);
  };

  const handleDeleteTask = (item: HistoryItem) => {
    setDeletingTask({
      id: item.originalId,
      isCompleted: item.status === 'concluida',
    });
  };

  return (
    <>
      <Collapsible open={isOpen} onOpenChange={setIsOpen} className="card-section">
        <CollapsibleTrigger className="flex items-center justify-between w-full">
          <h3 className="font-semibold text-foreground flex items-center gap-2">
            <MessageSquare size={18} />
            Histórico de Contatos ({historyItems.length})
          </h3>
          {isOpen ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
        </CollapsibleTrigger>
        
        <CollapsibleContent className="pt-4">
          <p className="text-xs text-muted-foreground mb-4">
            O histórico é preenchido automaticamente a partir das tarefas concluídas.
          </p>
          
          <div className="space-y-3">
            {visibleItems.length > 0 ? (
              <>
              {visibleItems.map((item) => {
                const typeInfo = CONTACT_TYPE_LABELS[item.contactType] || { 
                  label: item.contactType, 
                  icon: MessageCircle 
                };
                const Icon = typeInfo.icon;
                const isSuccessful = item.contactSuccessful === true;
                const isAttempt = item.isAttempt === true;
                const showActions = canManageItem(item);
                
                return (
                  <div key={item.id} className="p-4 bg-muted/30 rounded-lg group">
                    <div className="flex items-start gap-3">
                      <div className={`w-10 h-10 rounded-lg flex items-center justify-center shrink-0 ${
                        isSuccessful ? 'bg-green-500/10' : isAttempt ? 'bg-amber-500/10' : 'bg-primary/10'
                      }`}>
                        <Icon size={18} className={
                          isSuccessful ? 'text-green-600' : isAttempt ? 'text-amber-600' : 'text-primary'
                        } />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-2">
                          <div className="flex items-center gap-2">
                            <span className="font-medium text-foreground">{typeInfo.label}</span>
                            <Badge 
                              variant="outline"
                              className={`text-xs ${
                                isSuccessful 
                                  ? 'bg-green-500/10 text-green-600 border-green-500/20' 
                                  : isAttempt 
                                    ? 'bg-amber-500/10 text-amber-600 border-amber-500/20' 
                                    : 'bg-muted text-muted-foreground'
                              }`}
                            >
                              {isSuccessful ? (
                                <><CheckCircle size={12} className="mr-1" />Contato efetivo</>
                              ) : isAttempt ? (
                                <><XCircle size={12} className="mr-1" />Tentativa</>
                              ) : (
                                <><Check size={12} className="mr-1" />Concluída</>
                              )}
                            </Badge>
                          </div>
                          {/* Edit/Delete buttons */}
                          {showActions && (
                            <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-8 w-8"
                                onClick={() => handleEditTask(item)}
                                title="Editar tarefa"
                              >
                                <Pencil size={14} />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-8 w-8 text-destructive hover:text-destructive"
                                onClick={() => handleDeleteTask(item)}
                                title="Excluir tarefa"
                              >
                                <Trash2 size={14} />
                              </Button>
                            </div>
                          )}
                        </div>
                        <div className="text-sm text-muted-foreground mt-1">
                          {item.completedAt 
                            ? format(new Date(item.completedAt), "dd 'de' MMMM 'de' yyyy 'às' HH:mm", { locale: ptBR })
                            : format(new Date(item.date), "dd 'de' MMMM 'de' yyyy", { locale: ptBR })
                          }
                        </div>
                        {item.sellerName && (
                          <div className="text-sm text-muted-foreground">
                            Por: {item.sellerName}
                          </div>
                        )}
                        <p className="text-sm text-foreground mt-2 p-2 bg-background rounded whitespace-pre-wrap">
                          {item.notes}
                        </p>
                      </div>
                    </div>
                  </div>
                );
              })}
              {hasMore && (
                <button
                  onClick={handleLoadMore}
                  className="w-full py-2 text-sm text-primary hover:text-primary/80 font-medium transition-colors"
                >
                  Carregar mais ({remainingCount} restantes)
                </button>
              )}
              {visibleCount > maxVisible && (
                <button
                  onClick={handleCollapse}
                  className="w-full py-2 text-sm text-muted-foreground hover:text-foreground font-medium transition-colors"
                >
                  Ver menos
                </button>
              )}
              </>
            ) : (
              <p className="text-sm text-muted-foreground text-center py-4">
                Nenhum contato registrado. Complete tarefas para gerar histórico automaticamente.
              </p>
            )}
          </div>
        </CollapsibleContent>
      </Collapsible>

      {/* Edit Task Modal */}
      {editingTask && (
        <EditTaskModal
          open={!!editingTask}
          onOpenChange={(open) => !open && setEditingTask(null)}
          task={editingTask}
          sellers={sellers}
          onUpdated={onRefresh}
        />
      )}

      {/* Delete Task Modal */}
      {deletingTask && (
        <DeleteTaskModal
          open={!!deletingTask}
          onOpenChange={(open) => !open && setDeletingTask(null)}
          taskId={deletingTask.id}
          isCompleted={deletingTask.isCompleted}
          onDeleted={onRefresh}
        />
      )}
    </>
  );
}