import { motion } from 'framer-motion';
import { Building2, Phone, MessageCircle, Trash2, CheckCircle, AlertTriangle, TrendingDown, Calendar, DollarSign, ShoppingCart, ChevronRight, Link } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Card, CardContent } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import { CLASSIFICATION_CONFIG, ClientClassificationType } from '@/hooks/useClientsData';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

interface ClientCardProps {
  client: {
    id: string;
    companyName: string;
    cnpj: string | null;
    status: string;
    classification: string;
    rankingTier: string;
    totalRevenue: number;
    ordersCount: number;
    lastOrderDate: string | null;
    daysSinceLastOrder: number | null;
    sellerId: string | null;
    // Branch inheritance fields
    isLinkedBranch?: boolean;
    matrixId?: string | null;
    matrixName?: string;
    inheritedFromMatrix?: boolean;
  };
  sellerName?: string;
  isSelected?: boolean;
  isAdmin?: boolean;
  onSelect?: (id: string) => void;
  onClick?: (id: string) => void;
  onDelete?: (client: any, e: React.MouseEvent) => void;
}

const formatCurrency = (value: number) => {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  }).format(value);
};

const getHealthIndicator = (daysSinceLastOrder: number | null) => {
  if (daysSinceLastOrder === null) {
    return { icon: AlertTriangle, color: 'text-muted-foreground', bgColor: 'bg-muted', label: 'Sem compras', ring: 'ring-muted' };
  }
  if (daysSinceLastOrder <= 30) {
    return { icon: CheckCircle, color: 'text-status-active', bgColor: 'bg-status-active/10', label: 'Ativo', ring: 'ring-status-active/30' };
  }
  if (daysSinceLastOrder <= 60) {
    return { icon: AlertTriangle, color: 'text-status-pending', bgColor: 'bg-status-pending/10', label: 'Atenção', ring: 'ring-status-pending/30' };
  }
  return { icon: TrendingDown, color: 'text-status-canceled', bgColor: 'bg-status-canceled/10', label: 'Inativo', ring: 'ring-status-canceled/30' };
};

const getRankingStyle = (tier: string) => {
  const styles: Record<string, { bg: string; text: string; label: string; emoji: string }> = {
    top20: { bg: 'bg-primary/10', text: 'text-primary', label: 'Top 20', emoji: '⭐' },
    top100: { bg: 'bg-accent', text: 'text-accent-foreground', label: 'Top 100', emoji: '💎' },
    top200: { bg: 'bg-secondary', text: 'text-secondary-foreground', label: 'Top 200', emoji: '🏆' },
    geral: { bg: 'bg-muted', text: 'text-muted-foreground', label: 'Geral', emoji: '📊' },
  };
  return styles[tier] || styles.geral;
};

export function ClientCard({
  client,
  sellerName,
  isSelected = false,
  isAdmin = false,
  onSelect,
  onClick,
  onDelete,
  index = 0,
}: ClientCardProps & { index?: number }) {
  const health = getHealthIndicator(client.daysSinceLastOrder);
  const HealthIcon = health.icon;
  const ranking = getRankingStyle(client.rankingTier);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20, scale: 0.98 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ 
        delay: index * 0.03,
        duration: 0.3,
        type: 'spring',
        stiffness: 300,
        damping: 25
      }}
      whileHover={{ y: -4, transition: { duration: 0.2 } }}
    >
      <Card
        className={cn(
          'group relative overflow-hidden transition-all duration-300 cursor-pointer',
          'border-border hover:border-primary/40 hover:shadow-xl hover:shadow-primary/5',
          isSelected && 'ring-2 ring-primary border-primary shadow-lg shadow-primary/10'
        )}
        onClick={() => onClick?.(client.id)}
      >
        {/* Health Status Ribbon with gradient */}
        <div className={cn(
          'absolute top-0 left-0 right-0 h-1.5',
          health.bgColor,
          'bg-gradient-to-r',
          client.daysSinceLastOrder === null ? 'from-muted to-muted/50' :
          client.daysSinceLastOrder <= 30 ? 'from-emerald-500 to-teal-400' :
          client.daysSinceLastOrder <= 60 ? 'from-amber-500 to-orange-400' :
          'from-red-500 to-rose-400'
        )} />

      <CardContent className="p-4 pt-5">
        {/* Header with checkbox and ranking */}
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center gap-3">
            {isAdmin && onSelect && (
              <div onClick={(e) => e.stopPropagation()}>
                <Checkbox
                  checked={isSelected}
                  onCheckedChange={() => onSelect(client.id)}
                />
              </div>
            )}
            <div className={cn('w-12 h-12 rounded-xl flex items-center justify-center', health.bgColor, 'ring-2', health.ring)}>
              <Building2 size={22} className={health.color} />
            </div>
          </div>
          <Badge variant="secondary" className={cn('text-xs', ranking.bg, ranking.text)}>
            {ranking.emoji} {ranking.label}
          </Badge>
        </div>

        {/* Company Info */}
        <div className="mb-4">
          <div className="flex items-center gap-2">
            <h3 className="font-semibold text-foreground line-clamp-1 group-hover:text-primary transition-colors">
              {client.companyName}
            </h3>
            {client.isLinkedBranch && (
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Badge variant="outline" className="text-xs px-1.5 py-0.5 bg-muted/50 text-muted-foreground border-muted-foreground/30 flex items-center gap-1">
                      <Link size={10} />
                      Filial
                    </Badge>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Vinculada à matriz: {client.matrixName || 'N/A'}</p>
                    {client.inheritedFromMatrix && (
                      <p className="text-xs text-muted-foreground">Status e classificação herdados da matriz</p>
                    )}
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            )}
          </div>
          <p className="text-xs text-muted-foreground">{client.cnpj || 'CNPJ não informado'}</p>
          {sellerName && (
            <p className="text-xs text-muted-foreground mt-1">👤 {sellerName}</p>
          )}
          {client.isLinkedBranch && client.matrixName && (
            <p className="text-xs text-muted-foreground mt-1 flex items-center gap-1">
              <Link size={10} />
              {client.matrixName}
            </p>
          )}
        </div>

        {/* Status Badges */}
        <div className="flex flex-wrap gap-1.5 mb-4">
          <Badge 
            variant={client.status === 'ativo' ? 'default' : 'secondary'}
            className={cn(
              'text-xs',
              client.status === 'ativo' 
                ? 'bg-status-active/10 text-status-active hover:bg-status-active/20' 
                : 'bg-muted text-muted-foreground'
            )}
          >
            {client.status === 'ativo' ? '✓ Ativo' : '○ Inativo'}
          </Badge>
          {(() => {
            const classConfig = CLASSIFICATION_CONFIG[client.classification as ClientClassificationType];
            if (!classConfig) return null;
            return (
              <Badge 
                variant="outline"
                className={cn('text-xs', classConfig.bgColor, classConfig.color, 'border', classConfig.borderColor)}
              >
                {classConfig.emoji} {classConfig.label}
              </Badge>
            );
          })()}
        </div>

        {/* Metrics Grid */}
        <div className="grid grid-cols-2 gap-3 mb-4">
          <div className="bg-muted/50 rounded-lg p-2.5">
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground mb-1">
              <DollarSign size={12} />
              Faturamento
            </div>
            <p className="font-semibold text-sm text-foreground">{formatCurrency(client.totalRevenue)}</p>
          </div>
          <div className="bg-muted/50 rounded-lg p-2.5">
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground mb-1">
              <ShoppingCart size={12} />
              Pedidos
            </div>
            <p className="font-semibold text-sm text-foreground">{client.ordersCount}</p>
          </div>
        </div>

        {/* Last Order & Health */}
        <div className={cn('rounded-lg p-3 flex items-center justify-between', health.bgColor)}>
          <div className="flex items-center gap-2">
            <HealthIcon size={16} className={health.color} />
            <div>
              <p className={cn('text-xs font-medium', health.color)}>{health.label}</p>
              {client.lastOrderDate ? (
                <p className="text-xs text-muted-foreground flex items-center gap-1">
                  <Calendar size={10} />
                  {new Date(client.lastOrderDate).toLocaleDateString('pt-BR')} ({client.daysSinceLastOrder}d)
                </p>
              ) : (
                <p className="text-xs text-muted-foreground">Sem pedidos registrados</p>
              )}
            </div>
          </div>
        </div>

        {/* Actions Footer */}
        <div className="flex items-center justify-between mt-4 pt-3 border-t border-border">
          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="sm"
              className="h-8 w-8 p-0"
              title="Ligar"
              onClick={(e) => e.stopPropagation()}
            >
              <Phone size={14} className="text-muted-foreground" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="h-8 w-8 p-0"
              title="WhatsApp"
              onClick={(e) => e.stopPropagation()}
            >
              <MessageCircle size={14} className="text-muted-foreground" />
            </Button>
            {onDelete && (
              <Button
                variant="ghost"
                size="sm"
                className="h-8 w-8 p-0 hover:bg-destructive/10"
                title="Excluir"
                onClick={(e) => onDelete(client, e)}
              >
                <Trash2 size={14} className="text-destructive" />
              </Button>
            )}
          </div>
          <Button
            variant="ghost"
            size="sm"
            className="text-xs text-muted-foreground hover:text-primary"
          >
            Ver detalhes
            <ChevronRight size={14} className="ml-1" />
          </Button>
        </div>
      </CardContent>
    </Card>
    </motion.div>
  );
}
