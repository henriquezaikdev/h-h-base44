import { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { BirthdayInput, getDaysUntilBirthday } from './BirthdayInput';

interface Buyer {
  id: string;
  name: string;
  whatsapp: string | null;
  email: string | null;
  birth_month: number | null;
  birth_date: string | null;
  birthday_day: number | null;
}

interface BuyerModalProps {
  isOpen: boolean;
  onClose: () => void;
  clientId: string;
  buyer?: Buyer | null;
  onSaved: () => void;
}

export function BuyerModal({ isOpen, onClose, clientId, buyer, onSaved }: BuyerModalProps) {
  const [saving, setSaving] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    birthday_day: null as number | null,
    birthday_month: null as number | null,
    whatsapp: '',
    email: '',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (buyer) {
      setFormData({
        name: buyer.name || '',
        birthday_day: buyer.birthday_day || null,
        birthday_month: buyer.birth_month || null,
        whatsapp: buyer.whatsapp || '',
        email: buyer.email || '',
      });
    } else {
      setFormData({
        name: '',
        birthday_day: null,
        birthday_month: null,
        whatsapp: '',
        email: '',
      });
    }
    setErrors({});
  }, [buyer, isOpen]);

  const validate = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.name.trim()) {
      newErrors.name = 'Nome é obrigatório';
    }

    if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Email inválido';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleBirthdayChange = (day: number | null, month: number | null) => {
    setFormData(prev => ({
      ...prev,
      birthday_day: day,
      birthday_month: month,
    }));
  };

  const handleSubmit = async () => {
    if (!validate()) return;

    setSaving(true);
    try {
      const buyerData = {
        client_id: clientId,
        name: formData.name.trim(),
        birthday_day: formData.birthday_day,
        birth_month: formData.birthday_month,
        whatsapp: formData.whatsapp.trim() || null,
        email: formData.email.trim() || null,
      };

      if (buyer) {
        const { error } = await supabase
          .from('buyers')
          .update(buyerData)
          .eq('id', buyer.id);
        if (error) throw error;
        toast.success('Comprador atualizado com sucesso!');
      } else {
        const { error } = await supabase
          .from('buyers')
          .insert(buyerData);
        if (error) throw error;
        toast.success('Comprador cadastrado com sucesso!');
      }

      onSaved();
      onClose();
    } catch (error: any) {
      console.error('Error saving buyer:', error);
      toast.error(error.message || 'Erro ao salvar comprador');
    } finally {
      setSaving(false);
    }
  };

  const daysUntilBirthday = getDaysUntilBirthday(formData.birthday_day, formData.birthday_month);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{buyer ? 'Editar Comprador' : 'Novo Comprador'}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="name">Nome *</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              placeholder="Nome do comprador"
              className={errors.name ? 'border-destructive' : ''}
            />
            {errors.name && <p className="text-sm text-destructive">{errors.name}</p>}
          </div>

          <BirthdayInput
            day={formData.birthday_day}
            month={formData.birthday_month}
            onChange={handleBirthdayChange}
            showAlert={daysUntilBirthday !== null && daysUntilBirthday >= 0 && daysUntilBirthday <= 2}
            daysUntilBirthday={daysUntilBirthday}
          />

          <div className="space-y-2">
            <Label htmlFor="whatsapp">WhatsApp</Label>
            <Input
              id="whatsapp"
              value={formData.whatsapp}
              onChange={(e) => setFormData({ ...formData, whatsapp: e.target.value })}
              placeholder="(11) 99999-9999"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              placeholder="email@exemplo.com"
              className={errors.email ? 'border-destructive' : ''}
            />
            {errors.email && <p className="text-sm text-destructive">{errors.email}</p>}
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <Button variant="outline" onClick={onClose} disabled={saving}>
              Cancelar
            </Button>
            <Button onClick={handleSubmit} disabled={saving}>
              {saving ? 'Salvando...' : buyer ? 'Atualizar' : 'Cadastrar'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
