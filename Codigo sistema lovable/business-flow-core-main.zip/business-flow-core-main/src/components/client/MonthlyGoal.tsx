import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Target, TrendingUp, AlertCircle } from 'lucide-react';

// Helper to get date in São Paulo timezone (YYYY-MM-DD)
function saoPauloDayKey(date: Date): string {
  return new Intl.DateTimeFormat('sv-SE', {
    timeZone: 'America/Sao_Paulo',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(date);
}

interface MonthlyGoalProps {
  clientId: string;
  classification: string;
}

const CLASSIFICATION_GOALS: Record<string, number> = {
  top20: 1500,
  top100: 1000,
  top200: 700,
  eventual: 500,
  geral: 500,
};

export function MonthlyGoal({ clientId, classification }: MonthlyGoalProps) {
  const [monthlyTotal, setMonthlyTotal] = useState(0);
  const [loading, setLoading] = useState(true);

  const goal = CLASSIFICATION_GOALS[classification] || 250;

  useEffect(() => {
    fetchMonthlyTotal();
  }, [clientId]);

  const fetchMonthlyTotal = async () => {
    try {
      const now = new Date();
      const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
      const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0);
      
      // Use São Paulo timezone for date comparisons
      const firstDayStr = saoPauloDayKey(firstDay);
      const lastDayStr = saoPauloDayKey(lastDay);

      const { data } = await supabase
        .from('orders')
        .select('total')
        .eq('client_id', clientId)
        .gte('order_date', firstDayStr)
        .lte('order_date', lastDayStr);

      if (data) {
        const total = data.reduce((sum, order) => sum + Number(order.total), 0);
        setMonthlyTotal(total);
      }
    } catch (error) {
      console.error('Error fetching monthly total:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);
  };

  const remaining = Math.max(0, goal - monthlyTotal);
  const percentage = Math.min(100, (monthlyTotal / goal) * 100);
  const isAchieved = monthlyTotal >= goal;

  const getProgressColor = () => {
    if (percentage >= 100) return 'bg-green-500';
    if (percentage >= 70) return 'bg-yellow-500';
    return 'bg-primary';
  };

  if (loading) {
    return (
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-2 text-base">
            <Target size={18} />
            Meta Mensal
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse space-y-2">
            <div className="h-4 bg-muted rounded w-3/4" />
            <div className="h-2 bg-muted rounded" />
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={isAchieved ? 'border-green-500/50 bg-green-500/5' : ''}>
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center gap-2 text-base">
          <Target size={18} className={isAchieved ? 'text-green-500' : ''} />
          Meta Mensal do Cliente
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between text-sm">
          <span className="text-muted-foreground">Meta baseada na classificação</span>
          <span className="font-semibold">{formatCurrency(goal)}</span>
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="flex items-center gap-1">
              <TrendingUp size={14} className="text-primary" />
              Vendido este mês
            </span>
            <span className="font-semibold text-foreground">{formatCurrency(monthlyTotal)}</span>
          </div>
          
          <Progress 
            value={percentage} 
            className="h-3"
          />
          
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>{percentage.toFixed(0)}% atingido</span>
            {!isAchieved && (
              <span className="flex items-center gap-1">
                <AlertCircle size={12} />
                Falta {formatCurrency(remaining)}
              </span>
            )}
            {isAchieved && (
              <span className="text-green-600 font-medium">🎉 Meta atingida!</span>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}