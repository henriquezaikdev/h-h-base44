import { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { Loader2, Users } from 'lucide-react';

interface Seller {
  id: string;
  name: string;
}

interface TransferClientsModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  selectedClientIds: string[];
  onTransferComplete: () => void;
}

export function TransferClientsModal({
  open,
  onOpenChange,
  selectedClientIds,
  onTransferComplete,
}: TransferClientsModalProps) {
  const [sellers, setSellers] = useState<Seller[]>([]);
  const [selectedSellerId, setSelectedSellerId] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [loadingSellers, setLoadingSellers] = useState(true);

  useEffect(() => {
    if (open) {
      fetchSellers();
      setSelectedSellerId('');
    }
  }, [open]);

  const fetchSellers = async () => {
    setLoadingSellers(true);
    // Apenas vendedores ATIVOS para transferência
    const { data, error } = await supabase
      .from('sellers')
      .select('id, name')
      .or('status.eq.ATIVO,status.is.null')
      .order('name');

    if (error) {
      console.error('Error fetching sellers:', error);
      toast.error('Erro ao carregar vendedores');
    } else {
      setSellers(data || []);
    }
    setLoadingSellers(false);
  };

  const handleTransfer = async () => {
    if (!selectedSellerId) {
      toast.error('Selecione o vendedor de destino');
      return;
    }

    if (selectedClientIds.length === 0) {
      toast.error('Nenhum cliente selecionado');
      return;
    }

    setLoading(true);

    try {
      const { error } = await supabase
        .from('clients')
        .update({ seller_id: selectedSellerId })
        .in('id', selectedClientIds);

      if (error) throw error;

      const sellerName = sellers.find((s) => s.id === selectedSellerId)?.name || 'vendedor';
      toast.success(
        `${selectedClientIds.length} cliente(s) transferido(s) para ${sellerName}`
      );

      onTransferComplete();
      onOpenChange(false);
    } catch (error: any) {
      console.error('Error transferring clients:', error);
      toast.error(`Erro ao transferir clientes: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Users size={20} />
            Transferir Clientes
          </DialogTitle>
          <DialogDescription>
            Transfira {selectedClientIds.length} cliente(s) selecionado(s) para outro
            vendedor.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="target-seller">Novo vendedor responsável</Label>
            <Select
              value={selectedSellerId}
              onValueChange={setSelectedSellerId}
              disabled={loadingSellers || loading}
            >
              <SelectTrigger id="target-seller">
                <SelectValue
                  placeholder={
                    loadingSellers ? 'Carregando...' : 'Selecione o vendedor'
                  }
                />
              </SelectTrigger>
              <SelectContent>
                {sellers.map((seller) => (
                  <SelectItem key={seller.id} value={seller.id}>
                    {seller.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="rounded-lg bg-muted/50 p-3">
            <p className="text-sm text-muted-foreground">
              <strong>{selectedClientIds.length}</strong> cliente(s) serão
              transferidos. Esta ação não altera o histórico de pedidos.
            </p>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={loading}>
            Cancelar
          </Button>
          <Button onClick={handleTransfer} disabled={loading || !selectedSellerId}>
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Transferindo...
              </>
            ) : (
              'Confirmar Transferência'
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
