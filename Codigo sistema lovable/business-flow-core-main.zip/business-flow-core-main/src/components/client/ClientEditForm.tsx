import { useState, useEffect, useMemo, useRef } from 'react';
import { Building2, Save, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { RelatedClientSelect } from './RelatedClientSelect';
import { BranchesManager } from './BranchesManager';
import { BirthdayInput, getDaysUntilBirthday } from './BirthdayInput';
import { useAuth } from '@/hooks/useAuth';
import { useEditStore } from '@/store/useEditStore';
import { CLASSIFICATION_CONFIG, ClientClassificationType } from '@/hooks/useClientsData';

interface Client {
  id: string;
  company_name: string;
  cnpj: string | null;
  phone: string | null;
  email: string | null;
  status: string;
  classification: string;
  category: string;
  ranking_tier: string;
  total_revenue: number;
  days_since_last_order: number | null;
  observations: string | null;
  tags: string[];
  seller_id: string | null;
  related_company?: string | null;
  related_client_id?: string | null;
  origem?: string | null;
  unit_type?: string | null;
  birthday_day?: number | null;
  birthday_month?: number | null;
}

const ORIGEM_OPTIONS = [
  { value: 'ligacao', label: 'Ligação' },
  { value: 'indicacao', label: 'Indicação' },
  { value: 'google', label: 'Google' },
];

interface Seller {
  id: string;
  name: string;
  role: string;
}

interface ClientEditFormProps {
  client: Client;
  sellers: Seller[];
  onSaved: () => void;
}


export function ClientEditForm({ client, sellers, onSaved }: ClientEditFormProps) {
  const [saving, setSaving] = useState(false);
  const { user } = useAuth();

  // GLOBAL STORE: State survives remounts

  const { getClientForm, setClientForm: saveToStore, clearClientForm } = useEditStore();
  
  // Track dirty state to prevent server data overwrite
  const isDirtyRef = useRef(false);
  const initializedClientIdRef = useRef<string | null>(null);

  const [formData, setFormData] = useState(() => {
    // Try to restore from store first
    const stored = getClientForm(client.id);
    if (stored) {
      isDirtyRef.current = true;
      initializedClientIdRef.current = client.id;
      return {
        company_name: stored.company_name,
        email: stored.email,
        phone: stored.phone,
        cnpj: stored.cnpj,
        observations: stored.observations,
        seller_id: stored.seller_id,
        status: stored.status,
        related_client_id: stored.related_client_id,
        origem: stored.origem,
        unit_type: stored.unit_type,
        birthday_day: stored.birthday_day,
        birthday_month: stored.birthday_month,
      };
    }
    return {
      company_name: '',
      email: '',
      phone: '',
      cnpj: '',
      observations: '',
      seller_id: '',
      status: 'ativo',
      related_client_id: null as string | null,
      origem: '',
      unit_type: '',
      birthday_day: null as number | null,
      birthday_month: null as number | null,
    };
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  // Hydrate from db - ONLY once per client and if not dirty
  useEffect(() => {
    if (!client) return;
    
    // Skip if already initialized for this client and dirty
    if (initializedClientIdRef.current === client.id && isDirtyRef.current) return;
    
    // Check if store has data for this client
    const stored = getClientForm(client.id);
    if (stored) {
      isDirtyRef.current = true;
      initializedClientIdRef.current = client.id;
      return; // Already initialized from store in useState
    }
    
    // Mark as initialized for this client
    initializedClientIdRef.current = client.id;

    setFormData({
      company_name: client.company_name || '',
      email: client.email || '',
      phone: client.phone || '',
      cnpj: client.cnpj || '',
      observations: client.observations || '',
      seller_id: client.seller_id || '',
      status: client.status || 'ativo',
      related_client_id: client.related_client_id || null,
      origem: client.origem || '',
      unit_type: client.unit_type || '',
      birthday_day: client.birthday_day ?? null,
      birthday_month: client.birthday_month ?? null,
    });
  }, [client, getClientForm]);

  // Autosave to GLOBAL STORE (debounce)
  useEffect(() => {
    const t = setTimeout(() => {
      saveToStore(client.id, formData);
    }, 500);
    return () => clearTimeout(t);
  }, [client.id, formData, saveToStore]);
  
  // Mark as dirty on form changes
  const updateFormData = (updates: Partial<typeof formData>) => {
    isDirtyRef.current = true;
    setFormData(prev => ({ ...prev, ...updates }));
  };


  const validate = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.company_name.trim()) {
      newErrors.company_name = 'Nome do cliente é obrigatório';
    }
    
    if (!formData.seller_id) {
      newErrors.seller_id = 'Vendedor responsável é obrigatório';
    }

    if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Email inválido';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async () => {
    if (!validate()) {
      toast.error('Corrija os erros antes de salvar');
      return;
    }

    setSaving(true);
    try {
      const updateData = {
        company_name: formData.company_name.trim(),
        email: formData.email.trim() || null,
        phone: formData.phone.trim() || null,
        cnpj: formData.cnpj.trim() || null,
        observations: formData.observations.trim() || null,
        seller_id: formData.seller_id || null,
        status: formData.status,
        related_client_id: formData.related_client_id,
        origem: formData.origem || null,
        unit_type: formData.unit_type || null,
        birthday_day: formData.birthday_day,
        birthday_month: formData.birthday_month,
        updated_at: new Date().toISOString(),
      };

      const { error } = await supabase
        .from('clients')
        .update(updateData)
        .eq('id', client.id);

      if (error) throw error;

      toast.success('Cliente atualizado com sucesso!');
      clearClientForm(client.id); // Clear store on successful save
      isDirtyRef.current = false;
      onSaved();
    } catch (error: any) {
      console.error('Error saving client:', error);
      toast.error(error.message || 'Erro ao salvar cliente');
    } finally {
      setSaving(false);
    }
  };

  const sellersList = sellers.filter(s => s.role === 'vendedor');
  
  // Calculate days until birthday for alert
  const daysUntilBirthday = getDaysUntilBirthday(formData.birthday_day, formData.birthday_month);
  const showBirthdayAlert = daysUntilBirthday !== null && daysUntilBirthday >= 0 && daysUntilBirthday <= 2;

  return (
    <div className="card-section">
      <h3 className="font-semibold text-foreground mb-4 flex items-center gap-2">
        <Building2 size={18} />
        Informações do Cliente
      </h3>
      
      <div className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="company_name">Nome do Cliente *</Label>
            <Input
              id="company_name"
              value={formData.company_name}
              onChange={(e) => updateFormData({ company_name: e.target.value })}
              placeholder="Nome da empresa"
              className={errors.company_name ? 'border-destructive' : ''}
            />
            {errors.company_name && <p className="text-sm text-destructive">{errors.company_name}</p>}
          </div>

          <div className="space-y-2">
            <Label htmlFor="seller_id">Vendedor Responsável *</Label>
            <Select
              value={formData.seller_id}
              onValueChange={(value) => updateFormData({ seller_id: value })}
            >
              <SelectTrigger className={errors.seller_id ? 'border-destructive' : ''}>
                <SelectValue placeholder="Selecione o vendedor" />
              </SelectTrigger>
              <SelectContent>
                {sellersList.map((seller) => (
                  <SelectItem key={seller.id} value={seller.id}>
                    {seller.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {errors.seller_id && <p className="text-sm text-destructive">{errors.seller_id}</p>}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              value={formData.email}
              onChange={(e) => updateFormData({ email: e.target.value })}
              placeholder="email@empresa.com"
              className={errors.email ? 'border-destructive' : ''}
            />
            {errors.email && <p className="text-sm text-destructive">{errors.email}</p>}
          </div>

          <div className="space-y-2">
            <Label htmlFor="phone">Telefone</Label>
            <Input
              id="phone"
              value={formData.phone}
              onChange={(e) => updateFormData({ phone: e.target.value })}
              placeholder="(11) 99999-9999"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <BirthdayInput
            day={formData.birthday_day}
            month={formData.birthday_month}
            onChange={(day, month) => updateFormData({ birthday_day: day, birthday_month: month })}
            showAlert={showBirthdayAlert}
            daysUntilBirthday={daysUntilBirthday}
          />

          <div className="space-y-2">
            <Label htmlFor="cnpj">CNPJ(s)</Label>
            <Textarea
              id="cnpj"
              value={formData.cnpj}
              onChange={(e) => updateFormData({ cnpj: e.target.value })}
              placeholder="Digite um ou mais CNPJs (um por linha)"
              rows={2}
            />
          </div>
        </div>

        {/* Empresa Relacionada (para filiais) ou Gerenciamento de Filiais (para matrizes) */}
        <div className="space-y-4">
          {/* Se é uma filial, mostra seletor de matriz */}
          {formData.unit_type !== 'matriz' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="related_client">Empresa Matriz</Label>
                <RelatedClientSelect
                  value={formData.related_client_id}
                  onChange={(clientId) => updateFormData({ related_client_id: clientId })}
                  excludeClientId={client.id}
                />
                <p className="text-xs text-muted-foreground">
                  Selecione a matriz deste cliente (se for uma filial)
                </p>
              </div>
            </div>
          )}
          
          {/* Se é uma matriz, mostra gerenciador de filiais */}
          {formData.unit_type === 'matriz' && (
            <div className="p-4 border rounded-lg bg-muted/20">
              <BranchesManager
                matrixClientId={client.id}
                onBranchesUpdated={onSaved}
              />
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>Status *</Label>
            <Select
              value={formData.status}
              onValueChange={(value) => updateFormData({ status: value })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ativo">Ativo</SelectItem>
                <SelectItem value="inativo">Inativo</SelectItem>
              </SelectContent>
            </Select>
            {client.days_since_last_order && client.days_since_last_order > 90 && formData.status === 'ativo' && (
              <p className="text-xs text-amber-600">
                ⚠️ Cliente sem compras há {client.days_since_last_order} dias (status manual ativo)
              </p>
            )}
          </div>

          <div className="space-y-2">
            <Label>Tipo de Unidade</Label>
            <Select
              value={formData.unit_type}
              onValueChange={(value) => updateFormData({ unit_type: value })}
            >
              <SelectTrigger>
                <SelectValue placeholder="Selecione (opcional)" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="matriz">Matriz</SelectItem>
                <SelectItem value="filial">Filial</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-xs text-muted-foreground">
              Indica se é matriz ou filial (opcional)
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>Classificação</Label>
            <div className="flex items-center gap-2 h-10 px-3 rounded-md border bg-muted/50">
              {(() => {
                const classConfig = CLASSIFICATION_CONFIG[client.classification as ClientClassificationType];
                if (classConfig) {
                  return (
                    <span className={`font-medium ${classConfig.color}`}>
                      {classConfig.emoji} {classConfig.label}
                    </span>
                  );
                }
                return <span className="text-muted-foreground">—</span>;
              })()}
            </div>
            <p className="text-xs text-muted-foreground">
              Calculado automaticamente: ≤45 dias = Recorrente, 46-60 = 60 dias, 61-90 = 90 dias, 91-120 = 120 dias, &gt;120 = Inativo
            </p>
          </div>

          <div className="space-y-2">
            <Label>Origem</Label>
            <Select
              value={formData.origem}
              onValueChange={(value) => updateFormData({ origem: value })}
            >
              <SelectTrigger>
                <SelectValue placeholder="Selecione a origem" />
              </SelectTrigger>
              <SelectContent>
                {ORIGEM_OPTIONS.map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="observations">Observações / Notas</Label>
          <Textarea
            id="observations"
            value={formData.observations}
            onChange={(e) => updateFormData({ observations: e.target.value })}
            placeholder="Informações importantes sobre o cliente para análise futura..."
            rows={4}
          />
          <p className="text-xs text-muted-foreground">
            Essas notas serão usadas para análise de IA no futuro.
          </p>
        </div>

        <div className="flex justify-end pt-4 gap-2">
          {getClientForm(client.id) && (
            <Button
              variant="ghost"
              onClick={() => clearClientForm(client.id)}
              className="text-muted-foreground"
            >
              Limpar rascunho
            </Button>
          )}
          <Button onClick={handleSubmit} disabled={saving}>
            {saving ? (
              <>
                <Loader2 size={16} className="mr-2 animate-spin" />
                Salvando...
              </>
            ) : (
              <>
                <Save size={16} className="mr-2" />
                Salvar Cliente
              </>
            )}
          </Button>
        </div>

      </div>
    </div>
  );
}
