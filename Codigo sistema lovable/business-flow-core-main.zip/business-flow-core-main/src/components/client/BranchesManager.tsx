import { useState, useEffect } from 'react';
import { X, Search, Loader2, Building2, Plus, Link2, Unlink } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

interface LinkedBranch {
  id: string;
  company_name: string;
  cnpj: string | null;
}

interface BranchesManagerProps {
  matrixClientId: string;
  className?: string;
  onBranchesUpdated?: () => void;
}

export function BranchesManager({ 
  matrixClientId, 
  className,
  onBranchesUpdated
}: BranchesManagerProps) {
  const [branches, setBranches] = useState<LinkedBranch[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchOpen, setSearchOpen] = useState(false);
  const [search, setSearch] = useState('');
  const [searchLoading, setSearchLoading] = useState(false);
  const [searchResults, setSearchResults] = useState<LinkedBranch[]>([]);
  const [unlinking, setUnlinking] = useState<string | null>(null);

  // Load existing branches
  useEffect(() => {
    loadBranches();
  }, [matrixClientId]);

  const loadBranches = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('clients')
        .select('id, company_name, cnpj')
        .eq('related_client_id', matrixClientId)
        .eq('is_deleted', false)
        .order('company_name');

      if (error) throw error;
      setBranches(data || []);
    } catch (error) {
      console.error('Error loading branches:', error);
    } finally {
      setLoading(false);
    }
  };

  // Search for clients to add as branches
  useEffect(() => {
    const timer = setTimeout(async () => {
      if (search.length < 2) {
        setSearchResults([]);
        return;
      }

      setSearchLoading(true);
      try {
        const { data, error } = await supabase
          .from('clients')
          .select('id, company_name, cnpj')
          .neq('id', matrixClientId)
          .is('related_client_id', null) // Only clients without a parent
          .eq('is_deleted', false)
          .or(`company_name.ilike.%${search}%,cnpj.ilike.%${search}%`)
          .order('company_name')
          .limit(15);

        if (error) throw error;
        
        // Filter out already linked branches
        const branchIds = branches.map(b => b.id);
        setSearchResults((data || []).filter(c => !branchIds.includes(c.id)));
      } catch (error) {
        console.error('Error searching clients:', error);
        setSearchResults([]);
      } finally {
        setSearchLoading(false);
      }
    }, 300);

    return () => clearTimeout(timer);
  }, [search, matrixClientId, branches]);

  const handleLinkBranch = async (client: LinkedBranch) => {
    try {
      const { error } = await supabase
        .from('clients')
        .update({ 
          related_client_id: matrixClientId,
          is_branch: true,
          unit_type: 'filial'
        })
        .eq('id', client.id);

      if (error) throw error;

      toast.success(`${client.company_name} vinculada como filial`);
      setBranches(prev => [...prev, client]);
      setSearchResults(prev => prev.filter(c => c.id !== client.id));
      setSearch('');
      setSearchOpen(false);
      onBranchesUpdated?.();
    } catch (error: any) {
      console.error('Error linking branch:', error);
      toast.error(error.message || 'Erro ao vincular filial');
    }
  };

  const handleUnlinkBranch = async (branchId: string) => {
    setUnlinking(branchId);
    try {
      const { error } = await supabase
        .from('clients')
        .update({ 
          related_client_id: null,
          is_branch: false,
          unit_type: null
        })
        .eq('id', branchId);

      if (error) throw error;

      const branch = branches.find(b => b.id === branchId);
      toast.success(`${branch?.company_name} desvinculada`);
      setBranches(prev => prev.filter(b => b.id !== branchId));
      onBranchesUpdated?.();
    } catch (error: any) {
      console.error('Error unlinking branch:', error);
      toast.error(error.message || 'Erro ao desvincular filial');
    } finally {
      setUnlinking(null);
    }
  };

  const formatCnpj = (cnpj: string | null) => {
    if (!cnpj) return '';
    const firstCnpj = cnpj.split('\n')[0].trim();
    if (firstCnpj.length <= 18) return firstCnpj;
    return firstCnpj.substring(0, 18) + '...';
  };

  if (loading) {
    return (
      <div className={cn("flex items-center gap-2 text-muted-foreground", className)}>
        <Loader2 className="h-4 w-4 animate-spin" />
        <span className="text-sm">Carregando filiais...</span>
      </div>
    );
  }

  return (
    <div className={cn("space-y-3", className)}>
      {/* Header with count */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Link2 className="h-4 w-4 text-muted-foreground" />
          <span className="text-sm font-medium">
            Filiais Vinculadas
          </span>
          <Badge variant="secondary" className="text-xs">
            {branches.length}
          </Badge>
        </div>
        
        <Button
          variant="outline"
          size="sm"
          onClick={() => setSearchOpen(!searchOpen)}
          className="h-8"
        >
          <Plus className="h-3.5 w-3.5 mr-1" />
          Adicionar Filial
        </Button>
      </div>

      {/* Search input for adding branches */}
      {searchOpen && (
        <div className="relative">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Buscar cliente para vincular como filial..."
              className="pl-9"
              autoFocus
            />
            {searchLoading && (
              <Loader2 className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 animate-spin text-muted-foreground" />
            )}
          </div>

          {search.length >= 2 && (
            <div className="absolute z-50 w-full mt-1 bg-popover border rounded-md shadow-lg max-h-60 overflow-auto">
              {searchLoading ? (
                <div className="p-3 text-center text-sm text-muted-foreground">
                  Buscando...
                </div>
              ) : searchResults.length === 0 ? (
                <div className="p-3 text-center text-sm text-muted-foreground">
                  {search.length >= 2 ? 'Nenhum cliente disponível encontrado' : 'Digite para buscar'}
                </div>
              ) : (
                searchResults.map((client) => (
                  <button
                    key={client.id}
                    type="button"
                    className="w-full px-3 py-2 text-left hover:bg-accent transition-colors flex items-center gap-2"
                    onClick={() => handleLinkBranch(client)}
                  >
                    <Building2 className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium truncate">
                        {client.company_name}
                      </div>
                      {client.cnpj && (
                        <div className="text-xs text-muted-foreground truncate">
                          {formatCnpj(client.cnpj)}
                        </div>
                      )}
                    </div>
                    <Plus className="h-4 w-4 text-primary" />
                  </button>
                ))
              )}
            </div>
          )}
        </div>
      )}

      {/* List of linked branches */}
      {branches.length === 0 ? (
        <div className="text-sm text-muted-foreground py-2 px-3 bg-muted/30 rounded-md">
          Nenhuma filial vinculada a esta matriz.
        </div>
      ) : (
        <div className="space-y-2">
          {branches.map((branch) => (
            <div
              key={branch.id}
              className="flex items-center gap-2 px-3 py-2 rounded-md border bg-background hover:bg-accent/50 transition-colors"
            >
              <Building2 className="h-4 w-4 text-muted-foreground flex-shrink-0" />
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium truncate">
                  {branch.company_name}
                </div>
                {branch.cnpj && (
                  <div className="text-xs text-muted-foreground truncate">
                    {formatCnpj(branch.cnpj)}
                  </div>
                )}
              </div>
              <Button
                variant="ghost"
                size="icon"
                className="h-7 w-7 text-muted-foreground hover:text-destructive"
                onClick={() => handleUnlinkBranch(branch.id)}
                disabled={unlinking === branch.id}
                title="Desvincular filial"
              >
                {unlinking === branch.id ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Unlink className="h-4 w-4" />
                )}
              </Button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
