import { useState } from 'react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Loader2 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface DeleteInteractionModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  interactionId: string;
  onDeleted: () => void;
}

export function DeleteInteractionModal({
  open,
  onOpenChange,
  interactionId,
  onDeleted,
}: DeleteInteractionModalProps) {
  const [loading, setLoading] = useState(false);

  const handleDelete = async () => {
    setLoading(true);
    try {
      const { error } = await supabase
        .from('interactions')
        .delete()
        .eq('id', interactionId);

      if (error) throw error;

      toast.success('Interação excluída com sucesso!');
      onOpenChange(false);
      onDeleted();
    } catch (error) {
      console.error('Error deleting interaction:', error);
      toast.error('Erro ao excluir interação');
    } finally {
      setLoading(false);
    }
  };

  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Excluir Interação</AlertDialogTitle>
          <AlertDialogDescription>
            Esta interação será excluída permanentemente. Isso irá:
            <ul className="list-disc list-inside mt-2 space-y-1">
              <li>Remover a interação do histórico do cliente</li>
              <li>Atualizar os relatórios de atividades</li>
              <li>Subtrair dos indicadores de produtividade</li>
            </ul>
            <p className="mt-3 font-medium text-destructive">
              Esta ação não pode ser desfeita.
            </p>
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel disabled={loading}>Cancelar</AlertDialogCancel>
          <AlertDialogAction
            onClick={handleDelete}
            disabled={loading}
            className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
          >
            {loading && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
            Excluir
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}
