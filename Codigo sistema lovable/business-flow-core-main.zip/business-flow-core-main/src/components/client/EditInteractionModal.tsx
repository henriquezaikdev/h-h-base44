import { useState, useEffect, useMemo } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2, Phone, MessageCircle, Mail, MapPin, MoreHorizontal, CheckCircle, UserCheck, PhoneOff, Calendar } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { useAuth } from '@/hooks/useAuth';
import { buildDraftKey, readDraft, writeDraft, clearDraft } from '@/lib/drafts';

// Helper to get date in São Paulo timezone (YYYY-MM-DD)
function saoPauloDayKey(date: Date): string {
  return new Intl.DateTimeFormat('sv-SE', {
    timeZone: 'America/Sao_Paulo',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(date);
}

interface Seller {
  id: string;
  name: string;
}

interface Interaction {
  id: string;
  interaction_type: string;
  interaction_notes: string;
  interaction_date: string;
  interaction_time: string;
  responsible_seller_id: string | null;
}

interface EditInteractionModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  interaction: Interaction;
  clientId: string;
  clientName: string;
  sellers: Seller[];
  onUpdated: () => void;
}

const INTERACTION_TYPES = [
  { value: 'Ligação', label: 'Ligação', icon: Phone, color: 'text-blue-500' },
  { value: 'WhatsApp', label: 'WhatsApp', icon: MessageCircle, color: 'text-green-500' },
  { value: 'E-mail', label: 'E-mail', icon: Mail, color: 'text-purple-500' },
  { value: 'Visita', label: 'Visita', icon: MapPin, color: 'text-orange-500' },
  { value: 'Outro', label: 'Outro', icon: MoreHorizontal, color: 'text-muted-foreground' },
];

const RESULT_OPTIONS = [
  { value: 'falou_decisor', label: 'Falou com decisor', icon: UserCheck },
  { value: 'sem_resposta', label: 'Sem resposta', icon: PhoneOff },
  { value: 'pedido_confirmado', label: 'Pedido confirmado', icon: CheckCircle },
  { value: 'followup_necessario', label: 'Follow-up necessário', icon: Calendar },
  { value: 'outro', label: 'Outro resultado', icon: MoreHorizontal },
];

// Parse result from notes like "[Falou com decisor] some text"
function parseResultFromNotes(notes: string): { result: string; cleanNotes: string } {
  const match = notes.match(/^\[([^\]]+)\]\s*/);
  if (match) {
    const resultLabel = match[1];
    const cleanNotes = notes.slice(match[0].length);
    const resultOption = RESULT_OPTIONS.find(r => r.label === resultLabel);
    return {
      result: resultOption?.value || 'outro',
      cleanNotes: cleanNotes,
    };
  }
  return { result: 'outro', cleanNotes: notes };
}

export function EditInteractionModal({
  open,
  onOpenChange,
  interaction,
  clientId,
  clientName,
  sellers,
  onUpdated,
}: EditInteractionModalProps) {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [interactionType, setInteractionType] = useState<string>('');
  const [executionDate, setExecutionDate] = useState('');
  const [responsibleSellerId, setResponsibleSellerId] = useState<string>('');
  const [result, setResult] = useState<string>('');
  const [notes, setNotes] = useState('');

  const draftKey = useMemo(() => {
    return buildDraftKey([
      'clientes',
      'draft',
      user?.id || 'unknown',
      clientId,
      `editInteraction:${interaction.id}`,
    ]);
  }, [user?.id, clientId, interaction.id]);

  // Initialize form with interaction data (but prefer draft if present)
  useEffect(() => {
    if (open && interaction) {
      const stored = readDraft<{ value: any }>(draftKey, 'session');
      if (stored?.value) {
        if (typeof stored.value.interactionType === 'string') setInteractionType(stored.value.interactionType);
        if (typeof stored.value.executionDate === 'string') setExecutionDate(stored.value.executionDate);
        if (typeof stored.value.responsibleSellerId === 'string') setResponsibleSellerId(stored.value.responsibleSellerId);
        if (typeof stored.value.result === 'string') setResult(stored.value.result);
        if (typeof stored.value.notes === 'string') setNotes(stored.value.notes);
        return;
      }

      setInteractionType(interaction.interaction_type);
      setExecutionDate(interaction.interaction_date);
      setResponsibleSellerId(interaction.responsible_seller_id || '');

      const { result: parsedResult, cleanNotes } = parseResultFromNotes(interaction.interaction_notes);
      setResult(parsedResult);
      setNotes(cleanNotes);
    }
  }, [open, interaction, draftKey]);

  // Autosave draft (debounce)
  useEffect(() => {
    if (!open) return;
    const t = setTimeout(() => {
      writeDraft(
        draftKey,
        { value: { interactionType, executionDate, responsibleSellerId, result, notes }, savedAt: Date.now() },
        'session'
      );
    }, 500);
    return () => clearTimeout(t);
  }, [open, draftKey, interactionType, executionDate, responsibleSellerId, result, notes]);

  const handleSave = async () => {
    // Validations
    if (!interactionType) {
      toast.error('Selecione o tipo de interação');
      return;
    }

    if (!executionDate) {
      toast.error('Informe a data da execução');
      return;
    }

    if (!result) {
      toast.error('Selecione o resultado da interação');
      return;
    }

    if (!responsibleSellerId) {
      toast.error('Selecione o responsável');
      return;
    }

    // Prevent future dates
    const selectedDate = new Date(executionDate);
    const today = new Date();
    today.setHours(23, 59, 59, 999);
    if (selectedDate > today) {
      toast.error('A data não pode ser futura.');
      return;
    }

    setLoading(true);
    try {
      const resultLabel = RESULT_OPTIONS.find(r => r.value === result)?.label || result;
      
      // Build notes with result
      const fullNotes = notes.trim() 
        ? `[${resultLabel}] ${notes.trim()}`
        : `[${resultLabel}]`;

      // Update interaction
      const { error } = await supabase
        .from('interactions')
        .update({
          interaction_type: interactionType,
          interaction_date: executionDate,
          interaction_notes: fullNotes,
          responsible_seller_id: responsibleSellerId,
        })
        .eq('id', interaction.id);

      if (error) throw error;

      // limpar rascunho ao salvar com sucesso
      clearDraft(draftKey, 'session');

      toast.success('Interação atualizada com sucesso!');
      onOpenChange(false);
      onUpdated();
    } catch (error) {
      console.error('Error updating interaction:', error);
      toast.error('Erro ao atualizar interação');
    } finally {
      setLoading(false);
    }
  };

  const handleClose = () => {
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-[500px] max-h-[90vh] flex flex-col overflow-hidden">
        <DialogHeader className="flex-shrink-0">
          <DialogTitle className="text-lg">
            Editar Interação
          </DialogTitle>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto space-y-5 py-4 pr-2">
          {/* Client Info */}
          <div className="p-3 bg-muted/50 rounded-lg">
            <p className="font-medium">{clientName}</p>
          </div>

          {/* Interaction Type */}
          <div className="space-y-3">
            <Label className="text-base">Tipo de Interação *</Label>
            <div className="grid grid-cols-5 gap-2">
              {INTERACTION_TYPES.map((type) => (
                <Button
                  key={type.value}
                  type="button"
                  variant="outline"
                  className={`h-auto py-3 flex flex-col gap-1.5 ${
                    interactionType === type.value
                      ? 'border-primary bg-primary/5'
                      : 'hover:bg-muted/50'
                  }`}
                  onClick={() => setInteractionType(type.value)}
                >
                  <type.icon className={`h-5 w-5 ${
                    interactionType === type.value ? 'text-primary' : type.color
                  }`} />
                  <span className="text-xs font-medium">{type.label}</span>
                </Button>
              ))}
            </div>
          </div>

          {/* Execution Date */}
          <div className="space-y-2">
            <Label htmlFor="executionDate" className="text-base">Data da Execução *</Label>
            <Input
              id="executionDate"
              type="date"
              value={executionDate}
              onChange={(e) => setExecutionDate(e.target.value)}
              max={saoPauloDayKey(new Date())}
            />
          </div>

          {/* Responsible Seller */}
          <div className="space-y-2">
            <Label htmlFor="responsibleSeller" className="text-base">Responsável *</Label>
            <Select value={responsibleSellerId} onValueChange={setResponsibleSellerId}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione o responsável" />
              </SelectTrigger>
              <SelectContent>
                {sellers.map((seller) => (
                  <SelectItem key={seller.id} value={seller.id}>
                    {seller.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-xs text-muted-foreground">
              Alterar o responsável atualizará os relatórios de produtividade.
            </p>
          </div>

          {/* Result Selection */}
          <div className="space-y-3">
            <Label className="text-base">Resultado da Interação *</Label>
            <RadioGroup value={result} onValueChange={setResult} className="space-y-2">
              {RESULT_OPTIONS.map((option) => (
                <div
                  key={option.value}
                  className={`flex items-center space-x-3 p-3 rounded-lg border cursor-pointer transition-colors ${
                    result === option.value
                      ? 'border-primary bg-primary/5'
                      : 'border-border hover:bg-muted/50'
                  }`}
                  onClick={() => setResult(option.value)}
                >
                  <RadioGroupItem value={option.value} id={`edit-${option.value}`} />
                  <option.icon className={`h-5 w-5 ${
                    result === option.value ? 'text-primary' : 'text-muted-foreground'
                  }`} />
                  <Label htmlFor={`edit-${option.value}`} className="flex-1 cursor-pointer font-medium">
                    {option.label}
                  </Label>
                </div>
              ))}
            </RadioGroup>
          </div>

          {/* Notes */}
          <div className="space-y-2">
            <Label htmlFor="notes" className="text-base">Observações</Label>
            <Textarea
              id="notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Detalhes adicionais sobre a interação..."
              rows={3}
              className="resize-none"
            />
          </div>
        </div>

        <DialogFooter className="flex-shrink-0 gap-2 pt-4 border-t">
          <Button variant="outline" onClick={handleClose} disabled={loading}>
            Cancelar
          </Button>
          <Button 
            onClick={handleSave} 
            disabled={loading || !interactionType || !result || !responsibleSellerId}
          >
            {loading && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
            Salvar Alterações
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
