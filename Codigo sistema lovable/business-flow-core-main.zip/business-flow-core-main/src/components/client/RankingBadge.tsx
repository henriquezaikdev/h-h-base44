import { cn } from '@/lib/utils';

interface RankingBadgeProps {
  tier: string;
  size?: 'sm' | 'md' | 'lg';
}

const TIER_CONFIG: Record<string, { medal: string; label: string; bgClass: string; textClass: string }> = {
  top20: {
    medal: '🥇',
    label: 'Top 20',
    bgClass: 'bg-amber-100 dark:bg-amber-900/30 border-amber-400',
    textClass: 'text-amber-700 dark:text-amber-300',
  },
  top100: {
    medal: '🥈',
    label: 'Top 100',
    bgClass: 'bg-slate-100 dark:bg-slate-800/50 border-slate-400',
    textClass: 'text-slate-700 dark:text-slate-300',
  },
  top200: {
    medal: '🥉',
    label: 'Top 200',
    bgClass: 'bg-orange-100 dark:bg-orange-900/30 border-orange-400',
    textClass: 'text-orange-700 dark:text-orange-300',
  },
  eventual: {
    medal: '',
    label: 'Eventual',
    bgClass: 'bg-muted',
    textClass: 'text-muted-foreground',
  },
  geral: {
    medal: '',
    label: 'Geral',
    bgClass: 'bg-muted',
    textClass: 'text-muted-foreground',
  },
};

const sizeClasses = {
  sm: 'text-xs px-2 py-0.5',
  md: 'text-sm px-3 py-1',
  lg: 'text-base px-4 py-1.5',
};

export function RankingBadge({ tier, size = 'md' }: RankingBadgeProps) {
  const config = TIER_CONFIG[tier] || TIER_CONFIG.geral;
  const hasMedal = !!config.medal;

  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 rounded-full font-medium border',
        config.bgClass,
        config.textClass,
        sizeClasses[size],
        hasMedal && 'shadow-sm'
      )}
    >
      {config.medal && <span className="text-lg">{config.medal}</span>}
      {config.label}
    </span>
  );
}