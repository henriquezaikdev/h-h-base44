import { useEffect, useState, useRef } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Package, TrendingUp, ShoppingCart, Calendar } from 'lucide-react';

interface ProductStat {
  product_name: string;
  product_id: string | null;
  total_quantity: number;
  order_count: number;
  last_purchase: string;
  avg_days_between: number | null;
}

interface ProductHistoryProps {
  clientId: string;
}

export function ProductHistory({ clientId }: ProductHistoryProps) {
  const [products, setProducts] = useState<ProductStat[]>([]);
  const [loading, setLoading] = useState(true);
  const [isVisible, setIsVisible] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  // Lazy load: only fetch when the component enters the viewport
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) { setIsVisible(true); observer.disconnect(); } },
      { rootMargin: '200px' }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (isVisible && clientId) fetchProductHistory();
  }, [clientId, isVisible]);

  const fetchProductHistory = async () => {
    setLoading(true);
    try {
      const { data: orders } = await supabase
        .from('orders')
        .select('id, order_date')
        .eq('client_id', clientId)
        .eq('is_deleted', false)
        .order('order_date', { ascending: false });

      if (!orders || orders.length === 0) {
        setProducts([]);
        setLoading(false);
        return;
      }

      const orderIds = orders.map(o => o.id);

      const { data: items } = await supabase
        .from('order_items')
        .select(`
          product_id, 
          product_name, 
          quantity, 
          order_id
        `)
        .in('order_id', orderIds)
        .eq('is_deleted', false);

      if (!items) {
        setProducts([]);
        setLoading(false);
        return;
      }

      // Aggregate by product
      const productMap = new Map<string, {
        product_id: string | null;
        total_quantity: number;
        order_ids: Set<string>;
        last_order_date: string;
        order_dates: string[];
      }>();

      items.forEach(item => {
        const order = orders.find(o => o.id === item.order_id);
        if (!order) return;

        const key = item.product_name.toLowerCase();
        const existing = productMap.get(key);
        
        if (existing) {
          existing.total_quantity += Number(item.quantity);
          existing.order_ids.add(item.order_id);
          if (order.order_date > existing.last_order_date) {
            existing.last_order_date = order.order_date;
          }
          if (!existing.order_dates.includes(order.order_date)) {
            existing.order_dates.push(order.order_date);
          }
        } else {
          productMap.set(key, {
            product_id: item.product_id,
            total_quantity: Number(item.quantity),
            order_ids: new Set([item.order_id]),
            last_order_date: order.order_date,
            order_dates: [order.order_date],
          });
        }
      });

      const productStats: ProductStat[] = Array.from(productMap.entries()).map(([name, data]) => {
        let avgDays: number | null = null;
        
        if (data.order_dates.length > 1) {
          const sortedDates = data.order_dates.sort();
          let totalDays = 0;
          
          for (let i = 1; i < sortedDates.length; i++) {
            const diff = new Date(sortedDates[i]).getTime() - new Date(sortedDates[i - 1]).getTime();
            totalDays += diff / (1000 * 60 * 60 * 24);
          }
          
          avgDays = Math.round(totalDays / (sortedDates.length - 1));
        }

        const originalName = items.find(i => i.product_name.toLowerCase() === name)?.product_name || name;

        return {
          product_name: originalName,
          product_id: data.product_id,
          total_quantity: data.total_quantity,
          order_count: data.order_ids.size,
          last_purchase: data.last_order_date,
          avg_days_between: avgDays,
        };
      });
      productStats.sort((a, b) => b.total_quantity - a.total_quantity);
      const top = productStats.slice(0, 10);

      setProducts(top);
    } catch (error) {
      console.error('Error fetching product history:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString('pt-BR');
  };

  if (loading || !isVisible) {
    return (
      <Card ref={containerRef}>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Package size={18} />
            Produtos Mais Comprados
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse space-y-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-10 bg-muted rounded" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  if (products.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Package size={18} />
            Produtos Mais Comprados
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground text-center py-4">
            Nenhum produto encontrado
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center gap-2 text-base">
          <Package size={18} />
          Top 10 Itens Mais Comprados
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Produto</TableHead>
              <TableHead className="text-center">
                <div className="flex items-center justify-center gap-1">
                  <ShoppingCart size={14} />
                  Qtd Total
                </div>
              </TableHead>
              <TableHead className="text-center">
                <div className="flex items-center justify-center gap-1">
                  <TrendingUp size={14} />
                  Pedidos
                </div>
              </TableHead>
              <TableHead className="text-center">
                <div className="flex items-center justify-center gap-1">
                  <Calendar size={14} />
                  Última
                </div>
              </TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {products.map((product, i) => (
              <TableRow key={i}>
                <TableCell>
                  <span className="font-medium">{product.product_name}</span>
                </TableCell>
                <TableCell className="text-center font-medium">{product.total_quantity}</TableCell>
                <TableCell className="text-center">{product.order_count}</TableCell>
                <TableCell className="text-center text-muted-foreground">{formatDate(product.last_purchase)}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
