import { useState, useEffect } from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Cake } from 'lucide-react';
import { cn } from '@/lib/utils';

interface BirthdayInputProps {
  day: number | null;
  month: number | null;
  onChange: (day: number | null, month: number | null) => void;
  showAlert?: boolean;
  daysUntilBirthday?: number | null;
}

export function BirthdayInput({ day, month, onChange, showAlert, daysUntilBirthday }: BirthdayInputProps) {
  const [inputValue, setInputValue] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [animate, setAnimate] = useState(false);

  // Initialize input value from day/month
  useEffect(() => {
    if (day && month) {
      setInputValue(`${String(day).padStart(2, '0')}/${String(month).padStart(2, '0')}`);
    } else {
      setInputValue('');
    }
  }, [day, month]);

  // Trigger animation when alert is active (runs once on mount when showAlert is true)
  useEffect(() => {
    if (showAlert) {
      setAnimate(true);
      const timer = setTimeout(() => setAnimate(false), 2000);
      return () => clearTimeout(timer);
    } else {
      setAnimate(false);
    }
  }, [showAlert]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value.replace(/\D/g, '');
    
    // Auto-format with slash
    if (value.length >= 2) {
      value = value.slice(0, 2) + '/' + value.slice(2, 4);
    }
    
    setInputValue(value);
    setError(null);

    // Parse when complete
    if (value.length === 5) {
      const [dayStr, monthStr] = value.split('/');
      const parsedDay = parseInt(dayStr, 10);
      const parsedMonth = parseInt(monthStr, 10);

      // Validate month
      if (parsedMonth < 1 || parsedMonth > 12) {
        setError('Mês inválido (01-12)');
        onChange(null, null);
        return;
      }

      // Validate day based on month
      const maxDays = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
      if (parsedDay < 1 || parsedDay > maxDays[parsedMonth - 1]) {
        setError(`Dia inválido para este mês (01-${maxDays[parsedMonth - 1]})`);
        onChange(null, null);
        return;
      }

      onChange(parsedDay, parsedMonth);
    } else if (value.length === 0) {
      onChange(null, null);
    }
  };

  const getAlertLabel = () => {
    if (daysUntilBirthday === 0) return 'Hoje! 🎂';
    if (daysUntilBirthday === 1) return 'Amanhã!';
    if (daysUntilBirthday === 2) return 'Em 2 dias';
    return null;
  };

  const alertLabel = getAlertLabel();

  return (
    <div className="space-y-2">
      <Label htmlFor="birthday" className="flex items-center gap-2">
        <Cake size={16} />
        Aniversário (DD/MM)
        {showAlert && alertLabel && (
          <span className="ml-2 text-xs font-semibold text-amber-700 bg-amber-100 px-2 py-0.5 rounded-full">
            🎉 {alertLabel}
          </span>
        )}
      </Label>
      <div className="relative">
        <Input
          id="birthday"
          value={inputValue}
          onChange={handleChange}
          placeholder="DD/MM"
          maxLength={5}
          className={cn(
            "transition-all duration-300 pr-12",
            showAlert && "birthday-highlight",
            animate && "animate-birthday-pulse"
          )}
        />
        {showAlert && (
          <span className="absolute right-3 top-1/2 -translate-y-1/2 text-lg">
            🎉🥳
          </span>
        )}
      </div>
      {error && <p className="text-sm text-destructive">{error}</p>}
    </div>
  );
}

// Helper function to calculate days until birthday
export function getDaysUntilBirthday(day: number | null, month: number | null): number | null {
  if (!day || !month) return null;

  // Get today in São Paulo timezone
  const now = new Date();
  const spFormatter = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'America/Sao_Paulo',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  });
  const todayStr = spFormatter.format(now);
  const [yearStr, monthStr, dayStr] = todayStr.split('-');
  const todayYear = parseInt(yearStr, 10);
  const todayMonth = parseInt(monthStr, 10);
  const todayDay = parseInt(dayStr, 10);

  // Create today as Date object (midnight)
  const today = new Date(todayYear, todayMonth - 1, todayDay);
  
  // Create birthday this year
  let birthdayYear = todayYear;
  
  // Handle Feb 29 in non-leap years -> use Feb 28
  let adjustedDay = day;
  if (month === 2 && day === 29) {
    const isLeapYear = (year: number) => (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
    if (!isLeapYear(birthdayYear)) {
      adjustedDay = 28;
    }
  }
  
  let birthdayThisYear = new Date(birthdayYear, month - 1, adjustedDay);
  
  // If birthday already passed this year, use next year
  if (birthdayThisYear < today) {
    birthdayYear = todayYear + 1;
    // Re-check leap year for next year
    if (month === 2 && day === 29) {
      const isLeapYear = (year: number) => (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
      adjustedDay = isLeapYear(birthdayYear) ? 29 : 28;
    }
    birthdayThisYear = new Date(birthdayYear, month - 1, adjustedDay);
  }
  
  // Calculate difference in days
  const diffTime = birthdayThisYear.getTime() - today.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  
  return diffDays;
}
