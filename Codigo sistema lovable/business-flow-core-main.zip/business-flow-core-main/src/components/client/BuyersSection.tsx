import { useState, useEffect } from 'react';
import { User, Plus, Pencil, Trash2, Calendar, MessageCircle, Mail } from 'lucide-react';
import { getDaysUntilBirthday } from './BirthdayInput';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';
import { ChevronDown, ChevronUp } from 'lucide-react';
import { BuyerModal } from './BuyerModal';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';

interface Buyer {
  id: string;
  name: string;
  whatsapp: string | null;
  email: string | null;
  birth_month: number | null;
  birth_date: string | null;
  birthday_day: number | null;
}

interface BuyersSectionProps {
  clientId: string;
  buyers: Buyer[];
  onRefresh: () => void;
}

const MONTH_NAMES = [
  '', 'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
  'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
];

export function BuyersSection({ clientId, buyers, onRefresh }: BuyersSectionProps) {
  const [isOpen, setIsOpen] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingBuyer, setEditingBuyer] = useState<Buyer | null>(null);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [buyerToDelete, setBuyerToDelete] = useState<Buyer | null>(null);
  const [animatingBuyers, setAnimatingBuyers] = useState<Set<string>>(new Set());

  // Calculate which buyers have birthdays within 2 days and trigger animation on mount
  useEffect(() => {
    const buyersWithUpcomingBirthdays = buyers.filter(buyer => {
      const days = getDaysUntilBirthday(buyer.birthday_day, buyer.birth_month);
      return days !== null && days >= 0 && days <= 2;
    });

    if (buyersWithUpcomingBirthdays.length > 0) {
      const ids = new Set(buyersWithUpcomingBirthdays.map(b => b.id));
      setAnimatingBuyers(ids);
      
      // Stop animation after 2 seconds
      const timer = setTimeout(() => {
        setAnimatingBuyers(new Set());
      }, 2000);
      
      return () => clearTimeout(timer);
    }
  }, [buyers]);

  const getBirthdayInfo = (buyer: Buyer) => {
    const days = getDaysUntilBirthday(buyer.birthday_day, buyer.birth_month);
    if (days === null || days < 0 || days > 2) return null;
    
    return {
      days,
      label: days === 0 ? 'Hoje 🎉' : days === 1 ? 'Amanhã' : 'Em 2 dias',
      shouldHighlight: true,
    };
  };

  const handleEdit = (buyer: Buyer) => {
    setEditingBuyer(buyer);
    setIsModalOpen(true);
  };

  const handleNew = () => {
    setEditingBuyer(null);
    setIsModalOpen(true);
  };

  const handleDelete = async () => {
    if (!buyerToDelete) return;

    try {
      const { error } = await supabase
        .from('buyers')
        .delete()
        .eq('id', buyerToDelete.id);

      if (error) throw error;

      toast.success('Comprador excluído com sucesso!');
      setDeleteConfirmOpen(false);
      setBuyerToDelete(null);
      onRefresh();
    } catch (error: any) {
      console.error('Error deleting buyer:', error);
      toast.error(error.message || 'Erro ao excluir comprador');
    }
  };

  return (
    <>
      <Collapsible open={isOpen} onOpenChange={setIsOpen} className="card-section">
        <CollapsibleTrigger className="flex items-center justify-between w-full">
          <h3 className="font-semibold text-foreground flex items-center gap-2">
            <User size={18} />
            Compradores ({buyers.length})
          </h3>
          {isOpen ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
        </CollapsibleTrigger>
        
        <CollapsibleContent className="pt-4">
          <div className="space-y-3">
            <Button variant="outline" size="sm" onClick={handleNew} className="w-full">
              <Plus size={16} className="mr-2" />
              Novo Comprador
            </Button>

            {buyers.length > 0 ? (
              buyers.map((buyer) => {
                const birthdayInfo = getBirthdayInfo(buyer);
                const isAnimating = animatingBuyers.has(buyer.id);
                
                return (
                  <div 
                    key={buyer.id} 
                    className={cn(
                      "p-3 rounded-lg transition-all duration-300",
                      birthdayInfo?.shouldHighlight 
                        ? "birthday-highlight" 
                        : "bg-muted/50",
                      isAnimating && "animate-birthday-pulse"
                    )}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <p className="font-medium text-foreground">{buyer.name}</p>
                          {birthdayInfo && (
                            <span className="text-xs font-semibold text-amber-700 bg-amber-100 px-2 py-0.5 rounded-full">
                              🎉 {birthdayInfo.label}
                            </span>
                          )}
                        </div>
                        {(buyer.birthday_day || buyer.birth_month) && (
                          <div className={cn(
                            "flex items-center gap-2 text-sm mt-1",
                            birthdayInfo?.shouldHighlight 
                              ? "text-amber-700 font-medium" 
                              : "text-muted-foreground"
                          )}>
                            <Calendar size={14} />
                            Aniversário: {buyer.birthday_day ? String(buyer.birthday_day).padStart(2, '0') : '--'}/{buyer.birth_month ? String(buyer.birth_month).padStart(2, '0') : '--'}
                            {birthdayInfo && " 🥳"}
                          </div>
                        )}
                        {buyer.whatsapp && (
                          <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
                            <MessageCircle size={14} />
                            {buyer.whatsapp}
                          </div>
                        )}
                        {buyer.email && (
                          <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
                            <Mail size={14} />
                            {buyer.email}
                          </div>
                        )}
                      </div>
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => handleEdit(buyer)}
                          className="p-1.5 hover:bg-muted rounded transition-colors"
                          title="Editar"
                        >
                          <Pencil size={14} className="text-muted-foreground" />
                        </button>
                        <button
                          onClick={() => {
                            setBuyerToDelete(buyer);
                            setDeleteConfirmOpen(true);
                          }}
                          className="p-1.5 hover:bg-destructive/10 rounded transition-colors"
                          title="Excluir"
                        >
                          <Trash2 size={14} className="text-destructive" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })
            ) : (
              <p className="text-sm text-muted-foreground text-center py-4">
                Nenhum comprador cadastrado
              </p>
            )}
          </div>
        </CollapsibleContent>
      </Collapsible>

      <BuyerModal
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setEditingBuyer(null);
        }}
        clientId={clientId}
        buyer={editingBuyer}
        onSaved={onRefresh}
      />

      <AlertDialog open={deleteConfirmOpen} onOpenChange={setDeleteConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmar exclusão</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja excluir o comprador "{buyerToDelete?.name}"? 
              Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground">
              Excluir
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
