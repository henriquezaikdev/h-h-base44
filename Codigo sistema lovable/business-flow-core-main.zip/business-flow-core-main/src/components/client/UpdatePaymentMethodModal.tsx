import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { usePaymentMethods } from '@/hooks/usePaymentMethods';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { Loader2, CreditCard, AlertCircle, CheckCircle2 } from 'lucide-react';

interface Order {
  id: string;
  order_number: string;
  order_date: string;
  total: number;
  payment_term_days: number | null;
  payment_method: string | null;
}

interface UpdatePaymentMethodModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  clientId: string;
  clientName: string;
  onUpdated?: () => void;
}

export function UpdatePaymentMethodModal({
  open,
  onOpenChange,
  clientId,
  clientName,
  onUpdated,
}: UpdatePaymentMethodModalProps) {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [selectedOrders, setSelectedOrders] = useState<Set<string>>(new Set());
  const [paymentMethod, setPaymentMethod] = useState<string>('');
  const [paymentTermDays, setPaymentTermDays] = useState<number>(0);
  const { methods, loading: loadingMethods, getTermDaysFromName } = usePaymentMethods();

  useEffect(() => {
    if (open && clientId) {
      fetchOrders();
    }
  }, [open, clientId]);

  const fetchOrders = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('orders')
        .select('id, order_number, order_date, total, payment_term_days, payment_method')
        .eq('client_id', clientId)
        .eq('is_deleted', false)
        .order('order_date', { ascending: false });

      if (error) throw error;
      setOrders(data || []);
      
      // Auto-select orders without payment info
      const ordersWithoutPayment = (data || [])
        .filter(o => o.payment_term_days === null)
        .map(o => o.id);
      setSelectedOrders(new Set(ordersWithoutPayment));
    } catch (error) {
      console.error('Error fetching orders:', error);
      toast.error('Erro ao carregar pedidos');
    } finally {
      setLoading(false);
    }
  };

  const handlePaymentMethodChange = (value: string) => {
    setPaymentMethod(value);
    const termDays = getTermDaysFromName(value);
    setPaymentTermDays(termDays);
  };

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedOrders(new Set(orders.map(o => o.id)));
    } else {
      setSelectedOrders(new Set());
    }
  };

  const handleSelectOrder = (orderId: string, checked: boolean) => {
    const newSet = new Set(selectedOrders);
    if (checked) {
      newSet.add(orderId);
    } else {
      newSet.delete(orderId);
    }
    setSelectedOrders(newSet);
  };

  const handleSave = async () => {
    if (selectedOrders.size === 0) {
      toast.error('Selecione pelo menos um pedido');
      return;
    }
    if (!paymentMethod) {
      toast.error('Selecione uma forma de pagamento');
      return;
    }

    setSaving(true);
    try {
      const { error } = await supabase
        .from('orders')
        .update({
          payment_method: paymentMethod,
          payment_term_days: paymentTermDays,
        })
        .in('id', Array.from(selectedOrders));

      if (error) throw error;

      toast.success(`${selectedOrders.size} pedido(s) atualizado(s) com sucesso!`);
      onUpdated?.();
      onOpenChange(false);
    } catch (error) {
      console.error('Error updating orders:', error);
      toast.error('Erro ao atualizar pedidos');
    } finally {
      setSaving(false);
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);
  };

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString('pt-BR');
  };

  const ordersWithoutPayment = orders.filter(o => o.payment_term_days === null).length;
  const ordersWithPayment = orders.filter(o => o.payment_term_days !== null).length;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[85vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <CreditCard size={20} />
            Atualizar Forma de Pagamento
          </DialogTitle>
          <DialogDescription>
            Atualize a forma de pagamento dos pedidos antigos de <strong>{clientName}</strong>
          </DialogDescription>
        </DialogHeader>

        {/* Stats Summary */}
        <div className="flex gap-4 py-2">
          <div className="flex items-center gap-2 text-sm">
            <AlertCircle size={16} className="text-amber-500" />
            <span className="text-muted-foreground">Sem forma de pagamento:</span>
            <Badge variant="secondary">{ordersWithoutPayment}</Badge>
          </div>
          <div className="flex items-center gap-2 text-sm">
            <CheckCircle2 size={16} className="text-green-500" />
            <span className="text-muted-foreground">Com forma de pagamento:</span>
            <Badge variant="secondary">{ordersWithPayment}</Badge>
          </div>
        </div>

        {/* Payment Method Selector */}
        <div className="flex items-end gap-4 py-3 border-y">
          <div className="flex-1 space-y-1.5">
            <label className="text-sm font-medium">Nova forma de pagamento</label>
            <Select value={paymentMethod} onValueChange={handlePaymentMethodChange} disabled={loadingMethods}>
              <SelectTrigger className="w-full max-w-xs">
                <SelectValue placeholder="Selecione a forma de pagamento" />
              </SelectTrigger>
              <SelectContent>
                {methods.map((method) => (
                  <SelectItem key={method.id} value={method.name}>
                    {method.name}
                    {method.payment_term_days > 0 && (
                      <span className="text-muted-foreground ml-2 text-xs">
                        ({method.payment_term_days}d)
                      </span>
                    )}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {paymentMethod && (
              <p className="text-xs text-muted-foreground">
                Prazo: {paymentTermDays} dias
              </p>
            )}
          </div>
          <Button
            onClick={handleSave}
            disabled={saving || selectedOrders.size === 0 || !paymentMethod}
          >
            {saving ? (
              <>
                <Loader2 size={16} className="animate-spin mr-2" />
                Salvando...
              </>
            ) : (
              <>Aplicar a {selectedOrders.size} pedido(s)</>
            )}
          </Button>
        </div>

        {/* Orders Table */}
        <div className="flex-1 overflow-auto min-h-0">
          {loading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 size={24} className="animate-spin text-muted-foreground" />
            </div>
          ) : orders.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              Nenhum pedido encontrado para este cliente.
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-12">
                    <Checkbox
                      checked={selectedOrders.size === orders.length && orders.length > 0}
                      onCheckedChange={handleSelectAll}
                    />
                  </TableHead>
                  <TableHead>Nº Pedido</TableHead>
                  <TableHead>Data</TableHead>
                  <TableHead className="text-right">Total</TableHead>
                  <TableHead>Forma Atual</TableHead>
                  <TableHead className="text-center">Prazo (dias)</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {orders.map((order) => (
                  <TableRow
                    key={order.id}
                    className={order.payment_term_days === null ? 'bg-amber-50/50 dark:bg-amber-950/20' : ''}
                  >
                    <TableCell>
                      <Checkbox
                        checked={selectedOrders.has(order.id)}
                        onCheckedChange={(checked) => handleSelectOrder(order.id, !!checked)}
                      />
                    </TableCell>
                    <TableCell className="font-medium">{order.order_number}</TableCell>
                    <TableCell>{formatDate(order.order_date)}</TableCell>
                    <TableCell className="text-right">{formatCurrency(order.total)}</TableCell>
                    <TableCell>
                      {order.payment_method ? (
                        <Badge variant="outline">{order.payment_method}</Badge>
                      ) : (
                        <span className="text-amber-600 text-sm">Não definida</span>
                      )}
                    </TableCell>
                    <TableCell className="text-center">
                      {order.payment_term_days !== null ? (
                        <Badge>{order.payment_term_days}d</Badge>
                      ) : (
                        <span className="text-muted-foreground">—</span>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
