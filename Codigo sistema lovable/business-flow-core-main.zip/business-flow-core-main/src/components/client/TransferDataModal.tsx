import { useState, useEffect, useRef } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { AlertTriangle, ArrowRight, Search, Loader2 } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';

interface TransferDataModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  sourceClient: {
    id: string;
    company_name: string;
  };
  dataCounts: {
    orders: number;
    interactions: number;
    buyers: number;
    tasks: number;
    quotes: number;
  };
  onTransferred: () => void;
}

interface TargetClient {
  id: string;
  company_name: string;
  cnpj: string | null;
  total_revenue: number;
}

export function TransferDataModal({
  open,
  onOpenChange,
  sourceClient,
  dataCounts,
  onTransferred,
}: TransferDataModalProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [clients, setClients] = useState<TargetClient[]>([]);
  const [selectedClient, setSelectedClient] = useState<TargetClient | null>(null);
  const [loading, setLoading] = useState(false);
  const [transferring, setTransferring] = useState(false);
  const [step, setStep] = useState<'select' | 'confirm'>('select');
  const initialFocusRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (open && searchTerm.length >= 2) {
      searchClients();
    }
  }, [searchTerm, open]);

  useEffect(() => {
    if (!open) {
      setSearchTerm('');
      setClients([]);
      setSelectedClient(null);
      setStep('select');
    }
  }, [open]);

  useEffect(() => {
    if (!open) return;

    closeBackgroundOverlays();

    // Garante foco preso no modal
    requestAnimationFrame(() => initialFocusRef.current?.focus());
  }, [open]);

  const searchClients = async () => {
    setLoading(true);
    try {
      const normalizedSearch = searchTerm.trim().replace(/\s+/g, '%');
      const { data } = await supabase
        .from('clients')
        .select('id, company_name, cnpj, total_revenue')
        .eq('is_deleted', false)
        .neq('id', sourceClient.id)
        .or(`company_name.ilike.%${normalizedSearch}%,cnpj.ilike.%${normalizedSearch}%`)
        .order('company_name')
        .limit(20);

      if (data) {
        setClients(data);
      }
    } catch (error) {
      console.error('Error searching clients:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleTransfer = async () => {
    if (!selectedClient) return;

    setTransferring(true);
    try {
      const targetId = selectedClient.id;
      const sourceId = sourceClient.id;

      // Transfer orders
      if (dataCounts.orders > 0) {
        const { error: ordersError } = await supabase
          .from('orders')
          .update({ client_id: targetId })
          .eq('client_id', sourceId);
        if (ordersError) throw ordersError;
      }

      // Transfer interactions
      if (dataCounts.interactions > 0) {
        const { error: interactionsError } = await supabase
          .from('interactions')
          .update({ client_id: targetId })
          .eq('client_id', sourceId);
        if (interactionsError) throw interactionsError;
      }

      // Transfer buyers
      if (dataCounts.buyers > 0) {
        const { error: buyersError } = await supabase
          .from('buyers')
          .update({ client_id: targetId })
          .eq('client_id', sourceId);
        if (buyersError) throw buyersError;
      }

      // Transfer tasks
      if (dataCounts.tasks > 0) {
        const { error: tasksError } = await supabase
          .from('tasks')
          .update({ client_id: targetId })
          .eq('client_id', sourceId);
        if (tasksError) throw tasksError;
      }

      // Transfer quotes
      if (dataCounts.quotes > 0) {
        const { error: quotesError } = await supabase
          .from('quotes')
          .update({ client_id: targetId })
          .eq('client_id', sourceId);
        if (quotesError) throw quotesError;
      }

      // Transfer checklists
      const { error: checklistsError } = await supabase
        .from('client_checklists')
        .update({ client_id: targetId })
        .eq('client_id', sourceId);
      if (checklistsError) throw checklistsError;

      // Soft delete the source client
      const { error: deleteError } = await supabase
        .from('clients')
        .update({
          is_deleted: true,
          deleted_at: new Date().toISOString(),
          status: 'inativo',
        })
        .eq('id', sourceId);
      if (deleteError) throw deleteError;

      toast.success(`Dados transferidos para ${selectedClient.company_name}. Cliente original marcado como excluído.`);
      onOpenChange(false);
      onTransferred();
    } catch (error) {
      console.error('Error transferring data:', error);
      toast.error('Erro ao transferir dados. Tente novamente.');
    } finally {
      setTransferring(false);
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);
  };

  const totalItems = dataCounts.orders + dataCounts.interactions + dataCounts.buyers + dataCounts.tasks + dataCounts.quotes;

  function closeBackgroundOverlays() {
    // Fecha dropdowns/popovers do fundo (Radix responde bem a ESC e a pointerdown fora)
    (document.activeElement as HTMLElement | null)?.blur?.();

    const esc = new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', bubbles: true });
    document.dispatchEvent(esc);

    const pointerDown = new PointerEvent('pointerdown', { bubbles: true, cancelable: true });
    document.body.dispatchEvent(pointerDown);

    const mouseDown = new MouseEvent('mousedown', { bubbles: true, cancelable: true });
    document.body.dispatchEvent(mouseDown);

    const click = new MouseEvent('click', { bubbles: true, cancelable: true });
    document.body.dispatchEvent(click);
  }

  return (
    <Dialog
      open={open}
      modal={true}
      onOpenChange={(next) => {
        if (next) closeBackgroundOverlays();
        onOpenChange(next);
      }}
    >
      <DialogContent
        className="max-w-lg sm:max-w-xl bg-background border shadow-lg"
        onOpenAutoFocus={(e) => {
          e.preventDefault();
          requestAnimationFrame(() => initialFocusRef.current?.focus());
        }}
      >
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-amber-500" />
            Transferir Dados do Cliente
          </DialogTitle>
          <DialogDescription>
            Transfere todos os dados para outro cliente e marca este como excluído.
          </DialogDescription>
        </DialogHeader>

        {step === 'select' && (
          <div className="space-y-4">
            <div className="p-3 bg-muted rounded-lg">
              <p className="text-sm font-medium">Origem: {sourceClient.company_name}</p>
              <p className="text-xs text-muted-foreground mt-1">
                {dataCounts.orders} pedidos • {dataCounts.interactions} interações • {dataCounts.buyers} compradores • {dataCounts.tasks} tarefas • {dataCounts.quotes} orçamentos
              </p>
            </div>

            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                ref={initialFocusRef}
                placeholder="Buscar cliente destino..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9"
              />
            </div>

            {searchTerm.length < 2 && (
              <p className="text-sm text-muted-foreground text-center py-4">
                Digite pelo menos 2 caracteres para buscar
              </p>
            )}

            {loading && (
              <div className="flex justify-center py-4">
                <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
              </div>
            )}

            {!loading && searchTerm.length >= 2 && clients.length === 0 && (
              <p className="text-sm text-muted-foreground text-center py-4">
                Nenhum cliente encontrado
              </p>
            )}

            {!loading && clients.length > 0 && (
              <ScrollArea className="h-[200px]">
                <div className="space-y-2">
                  {clients.map((client) => (
                    <button
                      key={client.id}
                      type="button"
                      onClick={() => setSelectedClient(client)}
                      className={
                        `w-full p-3 rounded-lg text-left transition-colors border bg-background ` +
                        `outline-none focus:outline-none focus-visible:outline-none focus-visible:ring-0 focus-visible:ring-offset-0 ` +
                        (selectedClient?.id === client.id
                          ? 'border-2 border-primary bg-primary/5'
                          : 'border-input bg-muted/50 hover:bg-muted focus-visible:border-primary')
                      }
                    >
                      <p className="font-medium text-sm">{client.company_name}</p>
                      <p className="text-xs text-muted-foreground">
                        {client.cnpj || 'Sem CNPJ'} • {formatCurrency(client.total_revenue || 0)}
                      </p>
                    </button>
                  ))}
                </div>
              </ScrollArea>
            )}

            <div className="flex flex-col-reverse gap-2 pt-2 sm:flex-row sm:justify-end">
              <Button className="w-full sm:w-auto" variant="outline" onClick={() => onOpenChange(false)}>
                Cancelar
              </Button>
              <Button
                className="w-full sm:w-auto whitespace-normal text-center leading-tight"
                onClick={() => setStep('confirm')}
                disabled={!selectedClient}
              >
                Continuar
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </div>
        )}

        {step === 'confirm' && selectedClient && (
          <div className="space-y-4">
            <div className="p-4 bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 rounded-lg">
              <div className="flex items-center gap-2 text-amber-700 dark:text-amber-400 mb-2">
                <AlertTriangle className="h-4 w-4" />
                <span className="font-medium text-sm">Atenção: Esta ação é irreversível!</span>
              </div>
              <p className="text-sm text-amber-600 dark:text-amber-500">
                Todos os {totalItems} registros serão movidos permanentemente.
              </p>
            </div>

            <div className="flex items-center justify-center gap-4 py-4">
              <div className="text-center p-3 bg-muted rounded-lg flex-1">
                <p className="text-xs text-muted-foreground">De</p>
                <p className="font-medium text-sm truncate">{sourceClient.company_name}</p>
              </div>
              <ArrowRight className="h-5 w-5 text-muted-foreground flex-shrink-0" />
              <div className="text-center p-3 bg-primary/10 rounded-lg flex-1 border border-primary">
                <p className="text-xs text-primary">Para</p>
                <p className="font-medium text-sm truncate">{selectedClient.company_name}</p>
              </div>
            </div>

            <div className="text-sm text-muted-foreground">
              <p className="font-medium mb-2">Será transferido:</p>
              <ul className="space-y-1 text-xs">
                {dataCounts.orders > 0 && <li>• {dataCounts.orders} pedido(s)</li>}
                {dataCounts.interactions > 0 && <li>• {dataCounts.interactions} interação(ões)</li>}
                {dataCounts.buyers > 0 && <li>• {dataCounts.buyers} comprador(es)</li>}
                {dataCounts.tasks > 0 && <li>• {dataCounts.tasks} tarefa(s)</li>}
                {dataCounts.quotes > 0 && <li>• {dataCounts.quotes} orçamento(s)</li>}
                <li>• Checklists existentes</li>
              </ul>
            </div>

            <div className="flex flex-col-reverse gap-2 pt-2 sm:flex-row sm:justify-end">
              <Button className="w-full sm:w-auto" variant="outline" onClick={() => setStep('select')}>
                Voltar
              </Button>
              <Button
                className="w-full sm:w-auto whitespace-normal text-center leading-tight"
                variant="destructive"
                onClick={handleTransfer}
                disabled={transferring}
              >
                {transferring ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Transferindo...
                  </>
                ) : (
                  'Confirmar Transferência'
                )}
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
