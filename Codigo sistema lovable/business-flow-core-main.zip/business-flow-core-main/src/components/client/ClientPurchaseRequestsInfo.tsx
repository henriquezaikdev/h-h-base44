import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { ShoppingCart, Package } from 'lucide-react';
import { format } from 'date-fns';

const statusColors: Record<string, string> = {
  NOVA: 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400',
  EM_COTACAO: 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400',
  COTADA: 'bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400',
  APROVADA: 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400',
  COMPRADA: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400',
  EM_TRANSITO: 'bg-cyan-100 text-cyan-700 dark:bg-cyan-900/30 dark:text-cyan-400',
  PARCIAL: 'bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-400',
  RASCUNHO: 'bg-muted text-muted-foreground',
};

const statusLabels: Record<string, string> = {
  NOVA: 'Nova',
  EM_COTACAO: 'Em Cotação',
  COTADA: 'Cotada',
  APROVADA: 'Aprovada',
  COMPRADA: 'Comprada',
  EM_TRANSITO: 'Em Trânsito',
  PARCIAL: 'Parcial',
  RASCUNHO: 'Rascunho',
};

interface Props {
  clientId: string;
}

export function ClientPurchaseRequestsInfo({ clientId }: Props) {
  const { data: requests, isLoading } = useQuery({
    queryKey: ['client_purchase_requests', clientId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('solicitacoes_compra' as any)
        .select('id, titulo, status, created_at')
        .eq('cliente_id', clientId)
        .not('status', 'in', '(ENTREGUE,CANCELADO)')
        .order('created_at', { ascending: false });
      if (error) throw error;
      return data as any[];
    },
  });

  if (isLoading) return null;

  const count = requests?.length || 0;

  return (
    <div className="card-section">
      <div className="flex items-center gap-2 mb-3">
        <ShoppingCart className="h-4 w-4 text-primary" />
        <h3 className="font-semibold text-sm">Solicitações de Compra</h3>
        {count > 0 && (
          <span className="ml-auto text-xs font-bold bg-primary/10 text-primary rounded-full px-2 py-0.5">
            {count} aberta{count > 1 ? 's' : ''}
          </span>
        )}
      </div>

      {count === 0 ? (
        <p className="text-xs text-muted-foreground">Nenhuma solicitação aberta</p>
      ) : (
        <div className="space-y-2">
          {requests!.map((r: any) => (
            <div key={r.id} className="flex items-center justify-between gap-2 text-xs border rounded-md p-2 bg-muted/30">
              <div className="flex items-center gap-2 min-w-0">
                <Package className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
                <span className="truncate font-medium">{r.titulo || 'Sem título'}</span>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <span className={`px-1.5 py-0.5 rounded text-[10px] font-semibold ${statusColors[r.status] || 'bg-muted text-muted-foreground'}`}>
                  {statusLabels[r.status] || r.status}
                </span>
                <span className="text-muted-foreground">
                  {format(new Date(r.created_at), 'dd/MM')}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
