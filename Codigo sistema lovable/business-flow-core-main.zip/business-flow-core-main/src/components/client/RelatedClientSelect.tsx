import { useState, useEffect, useCallback } from 'react';
import { X, Search, Loader2, Building2 } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { cn } from '@/lib/utils';

interface RelatedClient {
  id: string;
  company_name: string;
  cnpj: string | null;
}

interface RelatedClientSelectProps {
  value: string | null;
  onChange: (clientId: string | null) => void;
  excludeClientId: string; // Prevent selecting self
  className?: string;
}

export function RelatedClientSelect({ 
  value, 
  onChange, 
  excludeClientId,
  className 
}: RelatedClientSelectProps) {
  const [search, setSearch] = useState('');
  const [isOpen, setIsOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<RelatedClient[]>([]);
  const [selectedClient, setSelectedClient] = useState<RelatedClient | null>(null);

  // Load selected client on mount if value exists
  useEffect(() => {
    if (value && !selectedClient) {
      loadSelectedClient(value);
    }
  }, [value]);

  const loadSelectedClient = async (clientId: string) => {
    const { data } = await supabase
      .from('clients')
      .select('id, company_name, cnpj')
      .eq('id', clientId)
      .single();
    
    if (data) {
      setSelectedClient(data);
    }
  };

  // Debounced search
  const searchClients = useCallback(async (term: string) => {
    if (term.length < 2) {
      setResults([]);
      return;
    }

    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('clients')
        .select('id, company_name, cnpj')
        .neq('id', excludeClientId)
        .or(`company_name.ilike.%${term}%,cnpj.ilike.%${term}%`)
        .order('company_name', { ascending: true })
        .limit(20);

      if (error) throw error;
      setResults(data || []);
    } catch (error) {
      console.error('Error searching clients:', error);
      setResults([]);
    } finally {
      setLoading(false);
    }
  }, [excludeClientId]);

  useEffect(() => {
    const timer = setTimeout(() => {
      if (search.length >= 2) {
        searchClients(search);
      } else {
        setResults([]);
      }
    }, 300);

    return () => clearTimeout(timer);
  }, [search, searchClients]);

  const handleSelect = (client: RelatedClient) => {
    setSelectedClient(client);
    onChange(client.id);
    setSearch('');
    setIsOpen(false);
    setResults([]);
  };

  const handleClear = () => {
    setSelectedClient(null);
    onChange(null);
    setSearch('');
    setResults([]);
  };

  const formatCnpj = (cnpj: string | null) => {
    if (!cnpj) return '';
    // Get first CNPJ if multiple
    const firstCnpj = cnpj.split('\n')[0].trim();
    if (firstCnpj.length <= 18) return firstCnpj;
    return firstCnpj.substring(0, 18) + '...';
  };

  // If a client is selected, show the selected state
  if (selectedClient) {
    return (
      <div className={cn(
        "flex items-center gap-2 h-10 px-3 rounded-md border bg-background",
        className
      )}>
        <Building2 className="h-4 w-4 text-muted-foreground flex-shrink-0" />
        <span className="flex-1 truncate text-sm">
          {selectedClient.company_name}
        </span>
        <Button
          type="button"
          variant="ghost"
          size="icon"
          className="h-6 w-6 flex-shrink-0"
          onClick={handleClear}
        >
          <X className="h-4 w-4" />
        </Button>
      </div>
    );
  }

  // Search input with dropdown
  return (
    <div className={cn("relative", className)}>
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          value={search}
          onChange={(e) => {
            setSearch(e.target.value);
            setIsOpen(true);
          }}
          onFocus={() => setIsOpen(true)}
          onBlur={() => {
            // Delay to allow click on result
            setTimeout(() => setIsOpen(false), 200);
          }}
          placeholder="Buscar empresa matriz ou filial..."
          className="pl-9 pr-9"
        />
        {loading && (
          <Loader2 className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 animate-spin text-muted-foreground" />
        )}
      </div>

      {isOpen && search.length >= 2 && (
        <div className="absolute z-50 w-full mt-1 bg-popover border rounded-md shadow-lg max-h-60 overflow-auto">
          {loading ? (
            <div className="p-3 text-center text-sm text-muted-foreground">
              Buscando...
            </div>
          ) : results.length === 0 ? (
            <div className="p-3 text-center text-sm text-muted-foreground">
              Nenhum cliente encontrado
            </div>
          ) : (
            results.map((client) => (
              <button
                key={client.id}
                type="button"
                className="w-full px-3 py-2 text-left hover:bg-accent transition-colors flex items-center gap-2"
                onClick={() => handleSelect(client)}
              >
                <Building2 className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium truncate">
                    {client.company_name}
                  </div>
                  {client.cnpj && (
                    <div className="text-xs text-muted-foreground truncate">
                      {formatCnpj(client.cnpj)}
                    </div>
                  )}
                </div>
              </button>
            ))
          )}
        </div>
      )}
    </div>
  );
}