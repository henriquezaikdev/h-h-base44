import { useState, useRef, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { Loader2, Bot, User, Sparkles, Trash2, Maximize2, Minimize2, X, Copy, Send, FileText, Link2, Check, ArrowRight, MessageSquare, BarChart3, AlertTriangle, TrendingUp, Target, Brain, ShoppingCart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogTitle } from '@/components/ui/dialog';
import { ChatGPTPromptInput } from '@/components/ui/chatgpt-prompt-input';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { useAuth } from '@/hooks/useAuth';
import { cn } from '@/lib/utils';
import ReactMarkdown from 'react-markdown';
import jsPDF from 'jspdf';

interface DiagnosticoCliente {
  nome: string;
  status: string;
  classificacao: string;
  ranking: string;
  ultimo_pedido: string | null;
  total_pedidos: number;
  ticket_medio: number;
  faturamento_total: number;
  dias_sem_pedido: number | null;
  total_produtos_distintos: number;
  perfil_preco: string | null;
  perfil_prazo: string | null;
  familias_equivalencia?: number;
}

interface ItemRelevante {
  nome: string;
  dias_sem_compra: number | null;
  ultima_compra: string | null;
  intervalo_medio_dias: number | null;
  receita_total: number;
  num_pedidos: number;
  tipo: 'critico' | 'alerta' | 'atencao';
  equivalencia_info?: string | null;
  equivalentes?: string[];
}

interface FamiliaEquivalencia {
  nome_familia: string;
  produtos: { nome: string; dias_sem_compra: number | null; ultima_compra: string | null; receita_total: number }[];
  dias_sem_compra_grupo: number | null;
}

interface PrevisaoRecompra {
  nome: string;
  intervalo_medio_dias: number;
  dias_sem_compra: number;
  desvio_pct: number;
  status_ciclo: 'dentro_do_ciclo' | 'proximo_recompra' | 'atraso_leve' | 'atraso_critico' | 'coberto_por_equivalente';
  num_pedidos: number;
  receita_total: number;
  equivalente_ativo?: string | null;
}

interface OportunidadeComercial {
  tipo: string;
  produto: string;
  descricao: string;
  prioridade: 'alta' | 'media' | 'baixa';
  receita_historica?: number;
  dias_atraso?: number;
  dias_restantes?: number;
}

interface ResumoExecutivo {
  status: string;
  nivel_atividade: string;
  principal_oportunidade: string;
  principal_risco: string;
  melhor_acao: string;
}

interface SugestaoAcao {
  tipo: string;
  descricao: string;
  urgencia: 'alta' | 'media' | 'baixa';
}

interface Etapas {
  diagnostico_cliente?: DiagnosticoCliente;
  itens_relevantes?: ItemRelevante[];
  possiveis_equivalencias?: { produto_a: string; produto_b: string; produto_id_a?: string | null; produto_id_b?: string | null }[];
  familias_equivalencia?: FamiliaEquivalencia[];
  previsoes_recompra?: PrevisaoRecompra[];
  oportunidades_comerciais?: OportunidadeComercial[];
  resumo_executivo?: ResumoExecutivo;
  sugestoes_acao?: SugestaoAcao[];
}

interface SugestaoCompra {
  origem: string;
  cliente_id: string;
  cliente_nome: string;
  motivo: string;
  observacao_comercial: string;
  itens_sugeridos: { produto_nome: string; produto_id: string | null; quantidade_sugerida: number; observacao: string }[];
}

interface MemoriaSugerida {
  tipo: string;
  conteudo: string;
  messageId: string;
}

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  equivalencias?: { produto_a: string; produto_b: string; produto_id_a?: string | null; produto_id_b?: string | null }[];
  etapas?: Etapas;
  memoriaSugerida?: MemoriaSugerida;
  sugestaoCompra?: SugestaoCompra;
}

interface ClientAIChatProps {
  clientId: string;
  clientName: string;
  clientData: any;
}

const QUICK_SUGGESTIONS = [
  { label: '📦 Produtos parados', text: 'Quais produtos esse cliente não compra há mais de 90 dias?' },
  { label: '🔄 Oportunidades de recompra', text: 'Quais itens têm potencial de recompra com base no intervalo médio de compra?' },
  { label: '💬 Gerar WhatsApp', text: 'Gere uma mensagem de WhatsApp profissional para abordar esse cliente com base no histórico de compras.' },
  { label: '📋 Resumir cliente', text: 'Faça um resumo executivo desse cliente para eu ligar agora: histórico, produtos, oportunidades.' },
  { label: '📄 Gerar relatório', text: 'Gere um relatório estruturado completo deste cliente com seções: perfil, histórico, análise de recompra, oportunidades e recomendações.' },
  { label: '🧠 Ver memórias', text: 'Quais memórias comerciais estão registradas para este cliente? Liste as preferências, restrições e observações conhecidas.' },
];

export function ClientAIChat({ clientId, clientName, clientData }: ClientAIChatProps) {
  const { seller } = useAuth();
  const navigate = useNavigate();
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(false);
  const [fullscreenOpen, setFullscreenOpen] = useState(false);
  const [savingEquiv, setSavingEquiv] = useState<string | null>(null);
  const [savingMemory, setSavingMemory] = useState<string | null>(null);
  const [savedMemories, setSavedMemories] = useState<Set<string>>(new Set());
  const [sendingToCompras, setSendingToCompras] = useState(false);
  const scrollEndRef = useRef<HTMLDivElement>(null);
  const fullscreenScrollEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom on new messages
  useEffect(() => {
    const ref = fullscreenOpen ? fullscreenScrollEndRef : scrollEndRef;
    ref.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading, fullscreenOpen]);

  // Action logging utility (fire-and-forget)
  const logAction = useCallback((acao: string, payload?: Record<string, any>) => {
    if (!seller?.id) return;
    supabase.from('ai_assistant_action_logs').insert({
      client_id: clientId,
      seller_id: seller.id,
      acao,
      payload: payload || null,
    }).then(({ error }) => {
      if (error) console.error('[ActionLog] Failed:', error);
    });
  }, [clientId, seller?.id]);

  const handleSend = useCallback(async (customMessage?: string) => {
    const messageText = customMessage?.trim();
    if (!messageText) {
      toast.error('Digite sua pergunta');
      return;
    }

    // Dedup guard
    if (loading) return;

    const userMessage: Message = {
      id: crypto.randomUUID(),
      role: 'user',
      content: messageText,
      timestamp: new Date(),
    };
    setMessages(prev => [...prev, userMessage]);
    setLoading(true);

    try {
      const conversationHistory = messages.slice(-8).map(m =>
        `${m.role === 'user' ? 'Vendedor' : 'Assistente'}: ${m.content}`
      ).join('\n');

      const { data, error } = await supabase.functions.invoke('assistente-comercial-cliente', {
        body: {
          clientId,
          sellerId: seller?.id,
          pergunta: messageText,
          historico_conversa: conversationHistory,
        },
      });

      if (error) throw error;
      if (data?.error) {
        const errorType = data.error_type || 'unknown';
        const friendlyMessages: Record<string, string> = {
          rate_limit: 'Muitas requisições simultâneas. Aguarde alguns segundos.',
          credits: 'Créditos de IA insuficientes no momento.',
          timeout: 'A IA demorou demais para responder. Tente novamente.',
          ai_gateway: 'Erro temporário na IA. Tente novamente em instantes.',
          equivalencia: 'Erro ao processar equivalências de produtos.',
          database: 'Erro de conexão com o banco de dados.',
          config: 'Configuração do assistente incompleta. Contate o administrador.',
        };
        throw new Error(friendlyMessages[errorType] || data.error);
      }

      // Parse memory suggestion from response
      const rawContent = data?.resposta || 'Sem resposta da IA.';
      const memoryMatch = rawContent.match(/\[MEMORIA_SUGERIDA\]\s*\n?\s*tipo:\s*(.+?)\s*\n\s*conteudo:\s*(.+?)\s*\n?\s*\[\/MEMORIA_SUGERIDA\]/s);
      const cleanContent = rawContent.replace(/\[MEMORIA_SUGERIDA\][\s\S]*?\[\/MEMORIA_SUGERIDA\]/g, '').trim();

      const msgId = crypto.randomUUID();
      const assistantMessage: Message = {
        id: msgId,
        role: 'assistant',
        content: cleanContent,
        timestamp: new Date(),
        equivalencias: data?.equivalencias_detectadas,
        etapas: data?.etapas,
        sugestaoCompra: data?.sugestao_compra || undefined,
        memoriaSugerida: memoryMatch ? {
          tipo: memoryMatch[1].trim(),
          conteudo: memoryMatch[2].trim(),
          messageId: msgId,
        } : undefined,
      };
      setMessages(prev => [...prev, assistantMessage]);

      // Log the analysis action
      logAction('analise_comercial', {
        tempo_ms: data?.tempo_resposta_ms,
        log_id: data?.log_id,
      });
    } catch (error: any) {
      console.error('[AI Assistant] Error:', error);
      const errorMsg = error.message || 'Erro ao consultar IA';
      toast.error(errorMsg);

      const errorMessage: Message = {
        id: crypto.randomUUID(),
        role: 'assistant',
        content: `⚠️ ${errorMsg}\n\nTente novamente em alguns instantes.`,
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setLoading(false);
    }
  }, [clientId, seller?.id, messages, loading, logAction]);

  const handleClear = () => { setMessages([]); setSavedMemories(new Set()); };

  const handleSendToCompras = useCallback(async (sugestao: SugestaoCompra) => {
    if (!seller?.id || sendingToCompras) return;
    setSendingToCompras(true);
    try {
      const { error } = await supabase.from('hh_compra_sugestao_ia' as any).insert({
        created_by: seller.id,
        cliente_id: sugestao.cliente_id,
        cliente_nome: sugestao.cliente_nome,
        origem: sugestao.origem,
        motivo: sugestao.motivo,
        observacao_comercial: sugestao.observacao_comercial,
        payload: sugestao.itens_sugeridos,
        status: 'pendente',
      });
      if (error) throw error;
      toast.success(`Sugestão enviada para Compras com ${sugestao.itens_sugeridos.length} item(ns)`);
      logAction('enviar_para_compras', { motivo: sugestao.motivo, itens: sugestao.itens_sugeridos.length });
      navigate('/gestao-compras', { state: { fromIA: true } });
    } catch (err) {
      console.error('[Compras] Error saving suggestion:', err);
      toast.error('Erro ao enviar sugestão para Compras');
    } finally {
      setSendingToCompras(false);
    }
  }, [seller?.id, sendingToCompras, logAction, navigate]);

  const handleSaveMemory = async (memoria: MemoriaSugerida) => {
    if (!seller?.id || savingMemory === memoria.messageId || savedMemories.has(memoria.messageId)) return;
    setSavingMemory(memoria.messageId);
    try {
      // Check for duplicate
      const { data: existing } = await supabase
        .from('client_commercial_memory')
        .select('id')
        .eq('client_id', clientId)
        .eq('tipo_memoria', memoria.tipo)
        .eq('conteudo', memoria.conteudo)
        .eq('ativo', true)
        .limit(1);

      if (existing && existing.length > 0) {
        toast.info('Esta memória já está registrada.');
        setSavedMemories(prev => new Set(prev).add(memoria.messageId));
        return;
      }

      const { error } = await supabase.from('client_commercial_memory').insert({
        client_id: clientId,
        seller_id: seller.id,
        tipo_memoria: memoria.tipo,
        conteudo: memoria.conteudo,
        created_by: seller.id,
        updated_by: seller.id,
      });
      if (error) throw error;
      toast.success('Memória comercial registrada!');
      setSavedMemories(prev => new Set(prev).add(memoria.messageId));
      logAction('registrar_memoria', { tipo: memoria.tipo, conteudo: memoria.conteudo });
    } catch (err) {
      console.error('[Memory] Save error:', err);
      toast.error('Erro ao salvar memória');
    } finally {
      setSavingMemory(null);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success('Copiado!');
    logAction('copiar_resposta');
  };

  const resolveProductId = async (name: string): Promise<string | null> => {
    // 1. Exact case-insensitive match
    const { data: exact } = await supabase
      .from('products')
      .select('id')
      .ilike('name', name)
      .eq('active', true)
      .limit(1);
    if (exact?.[0]?.id) return exact[0].id;

    // 2. Contains match
    const { data: contains } = await supabase
      .from('products')
      .select('id')
      .ilike('name', `%${name}%`)
      .eq('active', true)
      .limit(1);
    if (contains?.[0]?.id) return contains[0].id;

    // 3. Key words match (first 3 significant words)
    const words = name.split(/\s+/).filter(w => w.length > 2).slice(0, 3);
    if (words.length >= 2) {
      const pattern = `%${words.join('%')}%`;
      const { data: wordMatch } = await supabase
        .from('products')
        .select('id')
        .ilike('name', pattern)
        .eq('active', true)
        .limit(1);
      if (wordMatch?.[0]?.id) return wordMatch[0].id;
    }

    return null;
  };

  const handleSaveEquivalence = async (prodNameA: string, prodNameB: string, prodIdA?: string | null, prodIdB?: string | null) => {
    const key = `${prodNameA}-${prodNameB}`;
    setSavingEquiv(key);

    if (!seller?.id) {
      toast.error('Usuário não autenticado');
      setSavingEquiv(null);
      return;
    }

    try {
      let idA = prodIdA || null;
      let idB = prodIdB || null;

      // Only resolve by name if IDs not provided — use fuzzy matching
      if (!idA) {
        idA = await resolveProductId(prodNameA.trim());
      }

      if (!idB) {
        idB = await resolveProductId(prodNameB.trim());
      }

      if (!idA || !idB) {
        const missingNames = [!idA ? prodNameA : null, !idB ? prodNameB : null].filter(Boolean).join(', ');
        console.error('[Equivalência] Produto(s) não encontrado(s) no banco:', { prodNameA, idA, prodNameB, idB });
        toast.error(`Não foi possível localizar os dois produtos necessários para a união.`, {
          description: `Produto(s) não encontrado(s): ${missingNames}`,
          duration: 5000,
        });
        return;
      }

      if (idA === idB) {
        toast.info('Os dois produtos são o mesmo registro.');
        return;
      }

      // Stabilize order to prevent A/B and B/A duplicates
      const [stableA, stableB] = idA < idB ? [idA, idB] : [idB, idA];

      console.log('[Equivalência] Salvando:', { stableA, stableB, confirmado_por: seller.id });

      // Check if already exists (either direction)
      const { data: existing } = await supabase
        .from('hh_produto_equivalencia')
        .select('id')
        .eq('produto_id_a', stableA)
        .eq('produto_id_b', stableB)
        .limit(1);

      if (existing && existing.length > 0) {
        toast.info('Equivalência já registrada.');
        return;
      }

      const { error } = await supabase.from('hh_produto_equivalencia').insert({
        produto_id_a: stableA,
        produto_id_b: stableB,
        confirmado_por: seller.id,
      });

      if (error) throw error;
      toast.success('Equivalência salva! Será considerada nas próximas análises.');
      logAction('unir_equivalencia', { produto_a: prodNameA, produto_b: prodNameB, id_a: stableA, id_b: stableB });
    } catch (e: any) {
      if (e.code === '23505') {
        toast.info('Equivalência já registrada.');
      } else {
        console.error('[Equivalência] Erro detalhado:', JSON.stringify(e, null, 2));
        toast.error('Erro ao salvar equivalência. Verifique os logs.');
      }
    } finally {
      setSavingEquiv(null);
    }
  };

  const generatePDF = useCallback((message: Message) => {
    const doc = new jsPDF();
    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();
    const margin = 18;
    const maxWidth = pageWidth - margin * 2;
    const indigo = [59, 91, 219] as const;
    const stone600 = [87, 83, 78] as const;
    const stone400 = [168, 162, 158] as const;
    const stone200 = [231, 229, 228] as const;
    const green = [22, 163, 74] as const;
    const amber = [217, 119, 6] as const;
    const red = [220, 38, 38] as const;

    let y = 0;

    const checkPage = (needed: number) => {
      if (y + needed > pageHeight - 25) {
        // Footer on current page
        drawFooter();
        doc.addPage();
        y = 20;
      }
    };

    const drawFooter = () => {
      const fy = pageHeight - 12;
      doc.setDrawColor(...stone200);
      doc.setLineWidth(0.3);
      doc.line(margin, fy - 4, pageWidth - margin, fy - 4);
      doc.setFontSize(7);
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(...stone400);
      doc.text('H&H Suprimentos Corporativos — Documento gerado automaticamente', margin, fy);
      doc.text(new Date().toLocaleDateString('pt-BR'), pageWidth - margin, fy, { align: 'right' });
      doc.setFillColor(...indigo);
      doc.rect(0, pageHeight - 3, pageWidth, 3, 'F');
    };

    const drawSectionTitle = (title: string) => {
      checkPage(16);
      y += 6;
      doc.setFillColor(245, 245, 252);
      doc.roundedRect(margin, y - 4.5, maxWidth, 11, 1.5, 1.5, 'F');
      doc.setFontSize(10);
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(...indigo);
      doc.text(title, margin + 4, y + 2.5);
      y += 12;
    };

    // ─── HEADER ───
    doc.setFillColor(...indigo);
    doc.rect(0, 0, pageWidth, 4, 'F');

    y = 20;
    doc.setFontSize(20);
    doc.setTextColor(...indigo);
    doc.setFont('helvetica', 'bold');
    doc.text('H&H', margin, y);
    const hhW = doc.getTextWidth('H&H');
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(...stone400);
    doc.text(' Suprimentos Corporativos', margin + hhW, y);

    y += 14;
    doc.setFontSize(16);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(33, 33, 33);
    doc.text('Relatório Comercial', margin, y);

    y += 5;
    doc.setDrawColor(...stone200);
    doc.setLineWidth(0.5);
    doc.line(margin, y, pageWidth - margin, y);

    // ─── CLIENT INFO ───
    y += 10;
    const etapas = message.etapas;
    const diag = etapas?.diagnostico_cliente;
    const diagName = diag?.nome || clientName;

    doc.setFontSize(9);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(...stone600);

    const infoLeft = [
      `Cliente: ${diagName}`,
      diag?.classificacao && diag.classificacao !== 'N/A' ? `Classificação: ${diag.classificacao}` : null,
      diag?.ranking && diag.ranking !== 'N/A' ? `Ranking: ${diag.ranking}` : null,
    ].filter(Boolean);

    const infoRight = [
      `Data: ${new Date().toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' })}`,
      seller?.name ? `Consultor: ${seller.name}` : null,
    ].filter(Boolean);

    infoLeft.forEach(line => { doc.text(line!, margin, y); y += 5; });
    let yRight = y - infoLeft.length * 5;
    infoRight.forEach(line => { doc.text(line!, pageWidth - margin, yRight, { align: 'right' }); yRight += 5; });
    y = Math.max(y, yRight) + 2;

    // ─── EXECUTIVE SUMMARY ───
    const resumo = etapas?.resumo_executivo;
    if (resumo) {
      drawSectionTitle('Resumo Executivo');

      const nivelLabels: Record<string, string> = {
        muito_ativo: 'Muito Ativo', ativo: 'Ativo', esfriando: 'Esfriando', inativo: 'Inativo', desconhecido: 'Sem dados',
      };

      const summaryItems = [
        { label: 'Nível de atividade', value: nivelLabels[resumo.nivel_atividade] || resumo.nivel_atividade },
        { label: 'Principal oportunidade', value: resumo.principal_oportunidade },
        { label: 'Principal risco', value: resumo.principal_risco },
        { label: 'Melhor próxima ação', value: resumo.melhor_acao },
      ];

      summaryItems.forEach(item => {
        checkPage(12);
        doc.setFontSize(7.5);
        doc.setFont('helvetica', 'bold');
        doc.setTextColor(...stone400);
        doc.text(item.label.toUpperCase(), margin + 2, y);
        y += 4;
        doc.setFontSize(9);
        doc.setFont('helvetica', 'normal');
        doc.setTextColor(33, 33, 33);
        const lines = doc.splitTextToSize(item.value, maxWidth - 4);
        doc.text(lines, margin + 2, y);
        y += lines.length * 4 + 3;
      });
    }

    // ─── KPIs ROW ───
    if (diag) {
      checkPage(20);
      y += 2;
      const kpis = [
        { label: 'Pedidos', value: String(diag.total_pedidos) },
        { label: 'Ticket médio', value: `R$ ${diag.ticket_medio.toFixed(0)}` },
        { label: 'Faturamento', value: `R$ ${diag.faturamento_total.toFixed(0)}` },
        { label: 'Dias s/ pedido', value: diag.dias_sem_pedido != null ? `${diag.dias_sem_pedido}d` : 'N/A' },
      ];
      const kpiW = maxWidth / kpis.length;
      kpis.forEach((kpi, i) => {
        const x = margin + i * kpiW;
        doc.setFillColor(250, 250, 249);
        doc.roundedRect(x + 1, y - 2, kpiW - 2, 14, 1.5, 1.5, 'F');
        doc.setFontSize(7);
        doc.setFont('helvetica', 'normal');
        doc.setTextColor(...stone400);
        doc.text(kpi.label.toUpperCase(), x + kpiW / 2, y + 2, { align: 'center' });
        doc.setFontSize(11);
        doc.setFont('helvetica', 'bold');
        doc.setTextColor(33, 33, 33);
        doc.text(kpi.value, x + kpiW / 2, y + 9, { align: 'center' });
      });
      y += 18;
    }

    // ─── RECOMPRA PREDICTIONS ───
    if (etapas?.previsoes_recompra && etapas.previsoes_recompra.length > 0) {
      drawSectionTitle('Previsão de Recompra');

      // Table header
      checkPage(10);
      doc.setFillColor(248, 248, 247);
      doc.rect(margin, y - 4, maxWidth, 8, 'F');
      doc.setFontSize(7);
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(...stone400);
      doc.text('PRODUTO', margin + 2, y);
      doc.text('CICLO', margin + maxWidth * 0.55, y);
      doc.text('DIAS', margin + maxWidth * 0.72, y);
      doc.text('STATUS', margin + maxWidth * 0.84, y);
      y += 7;

      const statusColors: Record<string, readonly [number, number, number]> = {
        atraso_critico: red,
        atraso_leve: amber,
        proximo_recompra: [37, 99, 235],
        dentro_do_ciclo: green,
        coberto_por_equivalente: stone400,
      };
      const statusLabels: Record<string, string> = {
        atraso_critico: 'Crítico',
        atraso_leve: 'Atraso',
        proximo_recompra: 'Próximo',
        dentro_do_ciclo: 'No ciclo',
        coberto_por_equivalente: 'Coberto',
      };

      etapas.previsoes_recompra.forEach((p, idx) => {
        checkPage(8);
        if (idx % 2 === 0) {
          doc.setFillColor(252, 252, 251);
          doc.rect(margin, y - 3.5, maxWidth, 7, 'F');
        }
        doc.setFontSize(8);
        doc.setFont('helvetica', 'normal');
        doc.setTextColor(33, 33, 33);
        const nameLines = doc.splitTextToSize(p.nome, maxWidth * 0.52);
        doc.text(nameLines[0], margin + 2, y);

        doc.setTextColor(...stone600);
        doc.text(`${p.intervalo_medio_dias}d`, margin + maxWidth * 0.55, y);
        doc.text(`${p.dias_sem_compra}d`, margin + maxWidth * 0.72, y);

        const sc = statusColors[p.status_ciclo] || stone400;
        doc.setTextColor(...sc);
        doc.setFont('helvetica', 'bold');
        doc.text(statusLabels[p.status_ciclo] || p.status_ciclo, margin + maxWidth * 0.84, y);

        y += 7;
      });
    }

    // ─── OPPORTUNITIES ───
    if (etapas?.oportunidades_comerciais && etapas.oportunidades_comerciais.length > 0) {
      drawSectionTitle('Oportunidades Comerciais');

      etapas.oportunidades_comerciais.forEach(opp => {
        checkPage(14);
        const prioColor: [number, number, number] = opp.prioridade === 'alta' ? [...red] : opp.prioridade === 'media' ? [...amber] : [...green];
        doc.setFillColor(prioColor[0], prioColor[1], prioColor[2]);
        doc.rect(margin, y - 3, 2, 9, 'F');

        doc.setFontSize(8.5);
        doc.setFont('helvetica', 'normal');
        doc.setTextColor(33, 33, 33);
        const descLines = doc.splitTextToSize(opp.descricao, maxWidth - 10);
        doc.text(descLines, margin + 6, y);

        doc.setFontSize(7);
        doc.setTextColor(...stone400);
        const meta = [opp.tipo.replace(/_/g, ' ')];
        if (opp.receita_historica) meta.push(`R$ ${opp.receita_historica.toFixed(0)}`);
        doc.text(meta.join(' — '), margin + 6, y + descLines.length * 4);

        y += descLines.length * 4 + 6;
      });
    }

    // ─── CHECKLIST ───
    interface ChecklistItem { nome: string; obs: string; }
    const checklistItems: ChecklistItem[] = [];

    if (etapas?.itens_relevantes && etapas.itens_relevantes.length > 0) {
      etapas.itens_relevantes.forEach(item => {
        let obs = '';
        if (item.dias_sem_compra != null) obs = `última compra há ${item.dias_sem_compra} dias`;
        else if (item.intervalo_medio_dias) obs = `intervalo acima do normal (${item.intervalo_medio_dias}d)`;
        else obs = 'item com potencial de reposição';
        if (item.equivalencia_info) obs += ` — ${item.equivalencia_info}`;
        checklistItems.push({ nome: item.nome, obs });
      });
    }

    // Also extract from AI text
    const contentLines = message.content.split('\n');
    contentLines.forEach(line => {
      const clean = line.replace(/^[\s\-*•]+/, '').trim();
      if (!clean || clean.startsWith('#') || clean.length < 5) return;
      const dayMatch = clean.match(/(.+?)[\s\-–—:]+.*?(\d+)\s*d(ia)?s?\b/i);
      if (dayMatch && dayMatch[1].length > 3 && dayMatch[1].length < 80) {
        const prodName = dayMatch[1].replace(/\*\*/g, '').trim();
        if (!checklistItems.some(ci => ci.nome.toLowerCase() === prodName.toLowerCase())) {
          checklistItems.push({ nome: prodName, obs: 'potencial de reposição' });
        }
      }
    });

    if (checklistItems.length === 0) {
      const cleanContent = message.content.replace(/#{1,3}\s/g, '').replace(/\*\*(.*?)\*\*/g, '$1');
      cleanContent.split('\n').filter(l => l.trim().startsWith('-') || l.trim().startsWith('•')).slice(0, 20).forEach(line => {
        const clean = line.replace(/^[\s\-*•]+/, '').trim();
        if (clean.length > 5 && clean.length < 120) checklistItems.push({ nome: clean, obs: '' });
      });
    }

    if (checklistItems.length > 0) {
      drawSectionTitle('Itens para Conferência');

      doc.setFontSize(8);
      doc.setFont('helvetica', 'italic');
      doc.setTextColor(...stone400);
      doc.text('Com base no histórico, identificamos itens com potencial de reposição.', margin + 2, y);
      y += 7;

      // Table header
      checkPage(10);
      doc.setFillColor(248, 248, 247);
      doc.rect(margin, y - 4, maxWidth, 8, 'F');
      doc.setFontSize(7);
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(...stone400);
      doc.text('☐', margin + 2, y);
      doc.text('PRODUTO', margin + 10, y);
      doc.text('OBSERVAÇÃO', margin + maxWidth * 0.55, y);
      y += 8;

      checklistItems.forEach((item, idx) => {
        checkPage(10);
        if (idx % 2 === 0) {
          doc.setFillColor(252, 252, 251);
          doc.rect(margin, y - 4, maxWidth, 8, 'F');
        }
        doc.setDrawColor(...stone200);
        doc.setLineWidth(0.3);
        doc.rect(margin + 1.5, y - 3, 3.5, 3.5);

        doc.setFontSize(8.5);
        doc.setFont('helvetica', 'normal');
        doc.setTextColor(33, 33, 33);
        const nameLines = doc.splitTextToSize(item.nome, maxWidth * 0.5);
        doc.text(nameLines[0], margin + 10, y);

        if (item.obs) {
          doc.setFontSize(7.5);
          doc.setTextColor(...stone400);
          const obsLines = doc.splitTextToSize(item.obs, maxWidth * 0.4);
          doc.text(obsLines[0], margin + maxWidth * 0.55, y);
        }

        doc.setDrawColor(240, 240, 238);
        doc.setLineWidth(0.2);
        doc.line(margin, y + 3, pageWidth - margin, y + 3);
        y += nameLines.length > 1 ? 10 : 7;
      });
    }

    // ─── EQUIVALENCE FAMILIES ───
    if (etapas?.familias_equivalencia && etapas.familias_equivalencia.length > 0) {
      drawSectionTitle('Famílias de Produtos Equivalentes');

      doc.setFontSize(7.5);
      doc.setFont('helvetica', 'italic');
      doc.setTextColor(...stone400);
      doc.text('Produtos intercambiáveis agrupados na análise.', margin + 2, y);
      y += 7;

      etapas.familias_equivalencia.forEach(fam => {
        checkPage(12);
        doc.setFontSize(8.5);
        doc.setFont('helvetica', 'normal');
        doc.setTextColor(...stone600);
        const famText = fam.produtos.map(p => p.nome).join('  ↔  ');
        const famLines = doc.splitTextToSize(`• ${famText}`, maxWidth - 4);
        doc.text(famLines, margin + 2, y);
        y += famLines.length * 4 + 3;
      });
    }

    // ─── SUGGESTED ACTIONS ───
    if (etapas?.sugestoes_acao && etapas.sugestoes_acao.length > 0) {
      drawSectionTitle('Ações Recomendadas');

      const urgEmoji: Record<string, string> = { alta: '●', media: '◐', baixa: '○' };
      const urgColor: Record<string, readonly [number, number, number]> = { alta: red, media: amber, baixa: green };

      etapas.sugestoes_acao.forEach(s => {
        checkPage(10);
        const uc = urgColor[s.urgencia] || stone400;
        doc.setFontSize(8);
        doc.setFont('helvetica', 'bold');
        doc.setTextColor(...uc);
        doc.text(urgEmoji[s.urgencia] || '○', margin + 2, y);
        doc.setFont('helvetica', 'normal');
        doc.setTextColor(33, 33, 33);
        const lines = doc.splitTextToSize(s.descricao, maxWidth - 12);
        doc.text(lines, margin + 8, y);
        y += lines.length * 4 + 3;
      });
    }

    // ─── FOOTER ───
    drawFooter();

    doc.save(`relatorio-comercial-${clientName.replace(/\s+/g, '-').toLowerCase()}.pdf`);
    toast.success('PDF comercial gerado!');
    logAction('gerar_pdf', { client_name: clientName });
  }, [clientName, seller?.name, logAction]);

  // --- Shared sub-renderers ---

  const renderEquivalenceBlock = (equivs: { produto_a: string; produto_b: string; produto_id_a?: string | null; produto_id_b?: string | null }[]) => (
    <div className="mt-4 space-y-2.5">
      <div className="flex items-center gap-2 mb-1">
        <div className="h-px flex-1 bg-border/60" />
        <span className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground/70 flex items-center gap-1.5">
          <Link2 className="h-3 w-3" /> Equivalências detectadas
        </span>
        <div className="h-px flex-1 bg-border/60" />
      </div>
      {equivs.map((eq, i) => {
        const key = `${eq.produto_a}-${eq.produto_b}`;
        const hasValidIds = !!(eq.produto_id_a && eq.produto_id_b && eq.produto_id_a !== eq.produto_id_b);
        return (
          <div key={i} className="rounded-lg border border-border/70 bg-card p-3 space-y-2.5">
            <div className="flex items-start gap-3">
              <div className="flex-1 min-w-0 space-y-1.5">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground/60">Produto A</span>
                </div>
                <p className="text-xs font-medium text-foreground leading-snug break-words">{eq.produto_a}</p>
              </div>
              <div className="flex-shrink-0 mt-3">
                <ArrowRight className="h-3.5 w-3.5 text-muted-foreground/40" />
              </div>
              <div className="flex-1 min-w-0 space-y-1.5">
                <span className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground/60">Produto B</span>
                <p className="text-xs font-medium text-foreground leading-snug break-words">{eq.produto_b}</p>
              </div>
            </div>
            <div className="flex items-center justify-between pt-2 border-t border-border/40">
              <span className={`inline-flex items-center gap-1 text-[10px] font-medium px-2 py-0.5 rounded-full ${
                hasValidIds
                  ? 'text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-900/20'
                  : 'text-muted-foreground bg-muted/50'
              }`}>
                {hasValidIds ? 'Possível equivalência' : 'Sugestão — produtos não localizados'}
              </span>
              <div className="flex items-center gap-1.5">
                <Button
                  variant="outline"
                  size="sm"
                  className="h-7 text-[11px] px-3 gap-1.5 font-medium text-muted-foreground hover:text-foreground"
                  disabled={savingEquiv === key}
                  onClick={() => {
                    toast.info('Sugestão ignorada.');
                  }}
                >
                  {hasValidIds ? 'Manter separado' : 'Ignorar sugestão'}
                </Button>
                {hasValidIds && (
                  <Button
                    size="sm"
                    className="h-7 text-[11px] px-3 gap-1.5 font-medium"
                    disabled={savingEquiv === key}
                    onClick={() => handleSaveEquivalence(eq.produto_a, eq.produto_b, eq.produto_id_a, eq.produto_id_b)}
                  >
                    {savingEquiv === key ? <Loader2 className="h-3 w-3 animate-spin" /> : <Check className="h-3 w-3" />}
                    Unir produtos
                  </Button>
                )}
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );

  // --- Stage card renderers ---

  const StageCard = ({ icon: Icon, title, stepNumber, children }: { icon: any; title: string; stepNumber: number; children: React.ReactNode }) => (
    <div className="rounded-lg border border-border/60 bg-card overflow-hidden">
      <div className="flex items-center gap-2.5 px-3.5 py-2.5 bg-muted/30 border-b border-border/40">
        <div className="w-5 h-5 rounded-md bg-primary/[0.08] flex items-center justify-center flex-shrink-0">
          <Icon className="h-3 w-3 text-primary" />
        </div>
        <div className="flex items-center gap-2 min-w-0">
          <span className="text-[9px] font-bold uppercase tracking-widest text-muted-foreground/50">Etapa {stepNumber}</span>
          <span className="text-xs font-semibold text-foreground tracking-tight">{title}</span>
        </div>
      </div>
      <div className="px-3.5 py-3">{children}</div>
    </div>
  );

  const renderDiagnosticoCard = (diag: DiagnosticoCliente) => (
    <StageCard icon={BarChart3} title="Diagnóstico do Cliente" stepNumber={1}>
      <div className="grid grid-cols-2 gap-x-4 gap-y-2">
        {[
          { label: 'Último pedido', value: diag.ultimo_pedido ? new Date(diag.ultimo_pedido).toLocaleDateString('pt-BR') : 'N/A' },
          { label: 'Total de pedidos', value: String(diag.total_pedidos) },
          { label: 'Ticket médio', value: `R$ ${diag.ticket_medio.toFixed(2)}` },
          { label: 'Faturamento total', value: `R$ ${diag.faturamento_total.toFixed(2)}` },
          { label: 'Dias sem pedido', value: diag.dias_sem_pedido != null ? `${diag.dias_sem_pedido}d` : 'N/A' },
          { label: 'Produtos distintos', value: String(diag.total_produtos_distintos) },
          { label: 'Classificação', value: diag.classificacao },
          { label: 'Ranking', value: diag.ranking },
        ].map((item, i) => (
          <div key={i} className="flex justify-between items-baseline py-1 border-b border-border/20 last:border-0">
            <span className="text-[10px] font-medium text-muted-foreground/70 uppercase tracking-wider">{item.label}</span>
            <span className="text-xs font-semibold text-foreground tabular-nums">{item.value}</span>
          </div>
        ))}
      </div>
    </StageCard>
  );

  const renderItensRelevantesCard = (itens: ItemRelevante[]) => (
    <StageCard icon={AlertTriangle} title="Itens que merecem atenção" stepNumber={2}>
      <div className="space-y-2">
        {itens.map((item, i) => {
          const tipoStyles: Record<string, string> = {
            critico: 'border-l-destructive/60 bg-destructive/[0.03]',
            alerta: 'border-l-amber-500/60 bg-amber-50/30 dark:bg-amber-900/10',
            atencao: 'border-l-primary/40 bg-primary/[0.02]',
          };
          const tipoBadge: Record<string, { label: string; cls: string }> = {
            critico: { label: 'Crítico', cls: 'text-destructive bg-destructive/10' },
            alerta: { label: 'Alerta', cls: 'text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-900/20' },
            atencao: { label: 'Atenção', cls: 'text-primary bg-primary/10' },
          };
          const badge = tipoBadge[item.tipo] || tipoBadge.atencao;

          return (
            <div key={i} className={cn("rounded-md border-l-2 p-2.5 space-y-1", tipoStyles[item.tipo] || tipoStyles.atencao)}>
              <div className="flex items-start justify-between gap-2">
                <p className="text-xs font-medium text-foreground leading-snug break-words flex-1">{item.nome}</p>
                <span className={cn("text-[9px] font-semibold uppercase tracking-wider px-1.5 py-0.5 rounded-full flex-shrink-0", badge.cls)}>
                  {badge.label}
                </span>
              </div>
              <div className="flex flex-wrap gap-x-3 gap-y-0.5 text-[10px] text-muted-foreground/70">
                {item.dias_sem_compra != null && <span>Sem compra: <strong className="text-foreground/80">{item.dias_sem_compra}d</strong></span>}
                {item.ultima_compra && <span>Última: <strong className="text-foreground/80">{new Date(item.ultima_compra).toLocaleDateString('pt-BR')}</strong></span>}
                {item.intervalo_medio_dias && <span>Intervalo: <strong className="text-foreground/80">{item.intervalo_medio_dias}d</strong></span>}
                <span>Receita: <strong className="text-foreground/80">R$ {item.receita_total.toFixed(2)}</strong></span>
              </div>
              {item.equivalencia_info && (
                <div className="flex items-center gap-1.5 mt-1 text-[10px] text-primary/80">
                  <Link2 className="h-3 w-3 flex-shrink-0" />
                  <span>{item.equivalencia_info}</span>
                </div>
              )}
              {item.equivalentes && item.equivalentes.length > 0 && !item.equivalencia_info && (
                <div className="flex items-center gap-1.5 mt-1 text-[10px] text-muted-foreground/60">
                  <Link2 className="h-3 w-3 flex-shrink-0" />
                  <span>Equivalentes: {item.equivalentes.join(', ')}</span>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </StageCard>
  );

  const renderFamiliasCard = (familias: FamiliaEquivalencia[]) => (
    <StageCard icon={Link2} title="Famílias de equivalência confirmadas" stepNumber={3}>
      <div className="space-y-2">
        {familias.map((fam, i) => (
          <div key={i} className="rounded-md border border-border/30 bg-card p-2.5 space-y-1.5">
            <div className="flex items-center gap-2">
              <span className="text-[9px] font-semibold uppercase tracking-wider px-1.5 py-0.5 rounded-full bg-primary/10 text-primary">Família</span>
              {fam.dias_sem_compra_grupo != null && (
                <span className="text-[10px] text-muted-foreground/70">Última compra do grupo: <strong className="text-foreground/80">{fam.dias_sem_compra_grupo}d atrás</strong></span>
              )}
            </div>
            <div className="flex flex-wrap gap-1.5">
              {fam.produtos.map((prod, j) => (
                <div key={j} className="text-[10px] bg-muted/40 rounded px-2 py-1 border border-border/20">
                  <span className="font-medium text-foreground/90">{prod.nome}</span>
                  {prod.dias_sem_compra != null && <span className="text-muted-foreground/60 ml-1">({prod.dias_sem_compra}d)</span>}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </StageCard>
  );

  const renderResumoExecutivoCard = (resumo: ResumoExecutivo) => {
    const nivelLabels: Record<string, { label: string; cls: string }> = {
      muito_ativo: { label: 'Muito Ativo', cls: 'text-green-700 dark:text-green-400 bg-green-50 dark:bg-green-900/20' },
      ativo: { label: 'Ativo', cls: 'text-green-600 dark:text-green-400 bg-green-50 dark:bg-green-900/20' },
      esfriando: { label: 'Esfriando', cls: 'text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-900/20' },
      inativo: { label: 'Inativo', cls: 'text-destructive bg-destructive/10' },
      desconhecido: { label: 'Sem dados', cls: 'text-muted-foreground bg-muted/50' },
    };
    const nivel = nivelLabels[resumo.nivel_atividade] || nivelLabels.desconhecido;

    return (
      <StageCard icon={Target} title="Resumo Executivo" stepNumber={0}>
        <div className="space-y-2.5">
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-medium text-muted-foreground/70 uppercase tracking-wider">Atividade:</span>
            <span className={cn("text-[10px] font-semibold px-2 py-0.5 rounded-full", nivel.cls)}>{nivel.label}</span>
          </div>
          {[
            { label: 'Principal oportunidade', value: resumo.principal_oportunidade },
            { label: 'Principal risco', value: resumo.principal_risco },
            { label: 'Melhor próxima ação', value: resumo.melhor_acao },
          ].map((item, i) => (
            <div key={i} className="space-y-0.5">
              <span className="text-[9px] font-semibold uppercase tracking-wider text-muted-foreground/60">{item.label}</span>
              <p className="text-xs text-foreground/90 leading-snug">{item.value}</p>
            </div>
          ))}
        </div>
      </StageCard>
    );
  };

  const renderPrevisoesCard = (previsoes: PrevisaoRecompra[]) => {
    const statusLabels: Record<string, { label: string; cls: string }> = {
      dentro_do_ciclo: { label: 'No ciclo', cls: 'text-green-600 dark:text-green-400 bg-green-50 dark:bg-green-900/20' },
      proximo_recompra: { label: 'Próximo', cls: 'text-primary bg-primary/10' },
      atraso_leve: { label: 'Atraso leve', cls: 'text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-900/20' },
      atraso_critico: { label: 'Crítico', cls: 'text-destructive bg-destructive/10' },
      coberto_por_equivalente: { label: 'Coberto', cls: 'text-muted-foreground bg-muted/50' },
    };

    return (
      <StageCard icon={TrendingUp} title="Previsão de Recompra" stepNumber={4}>
        <div className="space-y-1.5">
          {previsoes.map((p, i) => {
            const st = statusLabels[p.status_ciclo] || statusLabels.dentro_do_ciclo;
            return (
              <div key={i} className="flex items-start justify-between gap-2 py-1.5 border-b border-border/15 last:border-0">
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium text-foreground truncate">{p.nome}</p>
                  <div className="flex flex-wrap gap-x-3 text-[10px] text-muted-foreground/60 mt-0.5">
                    <span>{p.dias_sem_compra}d sem compra</span>
                    <span>Ciclo: {p.intervalo_medio_dias}d</span>
                    {p.desvio_pct > 0 && <span>Desvio: {p.desvio_pct}%</span>}
                  </div>
                  {p.equivalente_ativo && (
                    <div className="flex items-center gap-1 mt-0.5 text-[10px] text-primary/70">
                      <Link2 className="h-2.5 w-2.5" />
                      <span>Coberto por: {p.equivalente_ativo}</span>
                    </div>
                  )}
                </div>
                <span className={cn("text-[9px] font-semibold uppercase tracking-wider px-1.5 py-0.5 rounded-full flex-shrink-0 mt-0.5", st.cls)}>
                  {st.label}
                </span>
              </div>
            );
          })}
        </div>
      </StageCard>
    );
  };

  const renderOportunidadesCard = (opps: OportunidadeComercial[]) => {
    const prioStyles: Record<string, { cls: string; label: string }> = {
      alta: { cls: 'border-l-destructive/50 bg-destructive/[0.03]', label: 'Alta' },
      media: { cls: 'border-l-amber-500/50 bg-amber-50/20 dark:bg-amber-900/5', label: 'Média' },
      baixa: { cls: 'border-l-primary/30 bg-primary/[0.02]', label: 'Baixa' },
    };
    const prioBadge: Record<string, string> = {
      alta: 'text-destructive bg-destructive/10',
      media: 'text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-900/20',
      baixa: 'text-muted-foreground bg-muted/50',
    };

    return (
      <StageCard icon={Sparkles} title="Oportunidades Comerciais" stepNumber={5}>
        <div className="space-y-2">
          {opps.map((opp, i) => {
            const ps = prioStyles[opp.prioridade] || prioStyles.baixa;
            return (
              <div key={i} className={cn("rounded-md border-l-2 p-2.5 space-y-1", ps.cls)}>
                <div className="flex items-start justify-between gap-2">
                  <p className="text-xs font-medium text-foreground leading-snug flex-1">{opp.descricao}</p>
                  <span className={cn("text-[9px] font-semibold uppercase tracking-wider px-1.5 py-0.5 rounded-full flex-shrink-0", prioBadge[opp.prioridade])}>
                    {prioStyles[opp.prioridade]?.label}
                  </span>
                </div>
                <div className="flex flex-wrap gap-x-3 text-[10px] text-muted-foreground/60">
                  <span className="capitalize">{opp.tipo.replace(/_/g, ' ')}</span>
                  {opp.receita_historica != null && <span>Receita: R$ {opp.receita_historica.toFixed(0)}</span>}
                </div>
              </div>
            );
          })}
        </div>
      </StageCard>
    );
  };

  const renderSugestoesAcaoCard = (sugestoes: SugestaoAcao[]) => {
    const urgIcons: Record<string, string> = { alta: '🔴', media: '🟡', baixa: '🟢' };
    return (
      <StageCard icon={ArrowRight} title="Ações Sugeridas" stepNumber={6}>
        <div className="space-y-1.5">
          {sugestoes.map((s, i) => (
            <div key={i} className="flex items-start gap-2 py-1.5 border-b border-border/15 last:border-0">
              <span className="text-xs mt-0.5">{urgIcons[s.urgencia] || '⚪'}</span>
              <div className="flex-1">
                <p className="text-xs text-foreground/90 leading-snug">{s.descricao}</p>
              </div>
            </div>
          ))}
        </div>
      </StageCard>
    );
  };

  const renderMessageContent = (message: Message, isFullscreen: boolean) => {
    if (message.role === 'user') {
      return <p className="whitespace-pre-wrap break-words leading-relaxed">{message.content}</p>;
    }

    const etapas = message.etapas;

    return (
      <div className="space-y-3">
        {/* Resumo Executivo (top) */}
        {etapas?.resumo_executivo && renderResumoExecutivoCard(etapas.resumo_executivo)}

        {/* Stage 1: Diagnostico */}
        {etapas?.diagnostico_cliente && renderDiagnosticoCard(etapas.diagnostico_cliente)}

        {/* Stage 2: Itens relevantes */}
        {etapas?.itens_relevantes && etapas.itens_relevantes.length > 0 && renderItensRelevantesCard(etapas.itens_relevantes)}

        {/* Previsões de recompra */}
        {etapas?.previsoes_recompra && etapas.previsoes_recompra.length > 0 && renderPrevisoesCard(etapas.previsoes_recompra)}

        {/* Oportunidades comerciais */}
        {etapas?.oportunidades_comerciais && etapas.oportunidades_comerciais.length > 0 && renderOportunidadesCard(etapas.oportunidades_comerciais)}

        {/* Stage 3a: Confirmed equivalence families */}
        {etapas?.familias_equivalencia && etapas.familias_equivalencia.length > 0 && renderFamiliasCard(etapas.familias_equivalencia)}

        {/* Stage 3b: New potential equivalences */}
        {etapas?.possiveis_equivalencias && etapas.possiveis_equivalencias.length > 0 && renderEquivalenceBlock(etapas.possiveis_equivalencias)}

        {/* Stage 4 & 5: AI analysis + approach (markdown) */}
        <div className={cn(
          "prose prose-sm dark:prose-invert max-w-none",
          "prose-headings:text-foreground prose-headings:font-semibold prose-headings:tracking-tight",
          "prose-p:text-foreground/90 prose-li:text-foreground/90 prose-strong:text-foreground",
          "prose-p:my-2 prose-headings:my-3 prose-ul:my-2 prose-ol:my-2 prose-li:my-0.5",
          "prose-p:leading-relaxed prose-li:leading-relaxed",
          "[&_table]:w-full [&_table]:text-xs [&_table]:border [&_table]:border-border/50 [&_table]:rounded-lg",
          "[&_th]:p-2 [&_td]:p-2 [&_th]:text-left [&_th]:bg-muted/50 [&_th]:font-semibold [&_th]:text-[11px] [&_th]:uppercase [&_th]:tracking-wider",
          "[&_th]:border-b [&_th]:border-border [&_td]:border-b [&_td]:border-border/30",
          "[&_blockquote]:border-l-primary/30 [&_blockquote]:bg-primary/[0.03] [&_blockquote]:rounded-r-lg [&_blockquote]:py-1 [&_blockquote]:px-3",
          "[&_code]:bg-muted/70 [&_code]:px-1.5 [&_code]:py-0.5 [&_code]:rounded [&_code]:text-xs [&_code]:font-mono"
        )}>
          <ReactMarkdown>{message.content}</ReactMarkdown>
        </div>

        {/* Legacy equivalence fallback (non-structured) */}
        {!etapas?.possiveis_equivalencias && message.equivalencias && message.equivalencias.length > 0 && renderEquivalenceBlock(message.equivalencias)}

        {/* Ações sugeridas */}
        {etapas?.sugestoes_acao && etapas.sugestoes_acao.length > 0 && renderSugestoesAcaoCard(etapas.sugestoes_acao)}

        {/* Memory suggestion card */}
        {message.memoriaSugerida && !savedMemories.has(message.memoriaSugerida.messageId) && (
          <div className="rounded-lg border border-primary/30 bg-primary/[0.04] p-3 space-y-2">
            <div className="flex items-center gap-2">
              <Brain className="h-4 w-4 text-primary" />
              <span className="text-xs font-semibold text-foreground">Registrar memória comercial?</span>
            </div>
            <div className="text-[11px] text-muted-foreground space-y-0.5">
              <p><span className="font-medium text-foreground">Tipo:</span> {message.memoriaSugerida.tipo.replace(/_/g, ' ')}</p>
              <p><span className="font-medium text-foreground">Info:</span> {message.memoriaSugerida.conteudo}</p>
            </div>
            <div className="flex gap-2">
              <Button
                size="sm"
                className="h-7 text-[11px] px-3 gap-1.5"
                disabled={savingMemory === message.memoriaSugerida.messageId}
                onClick={() => handleSaveMemory(message.memoriaSugerida!)}
              >
                {savingMemory === message.memoriaSugerida.messageId ? <Loader2 className="h-3 w-3 animate-spin" /> : <Check className="h-3 w-3" />}
                Registrar
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="h-7 text-[11px] px-3"
                onClick={() => setSavedMemories(prev => new Set(prev).add(message.memoriaSugerida!.messageId))}
              >
                Ignorar
              </Button>
            </div>
          </div>
        )}
        {message.memoriaSugerida && savedMemories.has(message.memoriaSugerida.messageId) && (
          <div className="flex items-center gap-2 text-[11px] text-muted-foreground py-1">
            <Check className="h-3 w-3 text-primary" />
            <span>Memória registrada</span>
          </div>
        )}

        {/* Enviar para Compras card */}
        {message.sugestaoCompra && message.sugestaoCompra.itens_sugeridos.length > 0 && (
          <div className="rounded-lg border border-emerald-500/30 bg-emerald-500/[0.04] p-3 space-y-2">
            <div className="flex items-center gap-2">
              <ShoppingCart className="h-4 w-4 text-emerald-600" />
              <span className="text-xs font-semibold text-foreground">Sugestão de compra identificada</span>
            </div>
            <div className="text-[11px] text-muted-foreground space-y-0.5">
              <p><span className="font-medium text-foreground">Motivo:</span> {message.sugestaoCompra.motivo.replace(/_/g, ' ')}</p>
              <p><span className="font-medium text-foreground">Itens:</span> {message.sugestaoCompra.itens_sugeridos.length} produto(s) sugerido(s)</p>
              {message.sugestaoCompra.observacao_comercial && (
                <p><span className="font-medium text-foreground">Ação:</span> {message.sugestaoCompra.observacao_comercial}</p>
              )}
            </div>
            <Button
              size="sm"
              className="h-7 text-[11px] px-3 gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white"
              disabled={sendingToCompras}
              onClick={() => handleSendToCompras(message.sugestaoCompra!)}
            >
              {sendingToCompras ? <Loader2 className="h-3 w-3 animate-spin" /> : <ShoppingCart className="h-3 w-3" />}
              Enviar para Compras
            </Button>
          </div>
        )}

        {/* Quick Actions */}
        <div className="flex flex-wrap items-center gap-1 pt-2.5 border-t border-border/20">
          <button
            type="button"
            onClick={() => copyToClipboard(message.content)}
            className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[11px] font-medium text-muted-foreground/70 hover:text-foreground hover:bg-muted/60 transition-all"
          >
            <Copy className="h-3 w-3" /> Copiar
          </button>
          <button
            type="button"
            onClick={() => generatePDF(message)}
            className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[11px] font-medium text-muted-foreground/70 hover:text-foreground hover:bg-muted/60 transition-all"
          >
            <FileText className="h-3 w-3" /> PDF
          </button>
          {message.content.length > 50 && (
            <button
              type="button"
              onClick={() => {
                const text = encodeURIComponent(message.content.slice(0, 1000));
                window.open(`https://wa.me/?text=${text}`, '_blank');
                logAction('gerar_whatsapp', { client_name: clientName });
              }}
              className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[11px] font-medium text-muted-foreground/70 hover:text-foreground hover:bg-muted/60 transition-all"
            >
              <Send className="h-3 w-3" /> WhatsApp
            </button>
          )}
        </div>
      </div>
    );
  };



  const renderEmptyState = (isFullscreen: boolean) => (
    <div className="flex flex-col items-center justify-center h-full text-center px-6">
      <div className={cn(
        "rounded-2xl bg-primary/[0.06] flex items-center justify-center mb-5",
        isFullscreen ? "w-16 h-16" : "w-12 h-12"
      )}>
        <MessageSquare className={cn("text-primary", isFullscreen ? "h-7 w-7" : "h-5 w-5")} />
      </div>
      <h4 className={cn("font-semibold text-foreground tracking-tight mb-1.5", isFullscreen ? "text-lg" : "text-[15px]")}>
        Assistente Comercial
      </h4>
      <p className={cn("text-muted-foreground mb-6 max-w-sm leading-relaxed", isFullscreen ? "text-sm" : "text-xs")}>
        Pergunte sobre <span className="font-medium text-foreground">{clientName}</span>. Histórico de pedidos, produtos e dados comerciais já disponíveis.
      </p>
      <div className="flex flex-wrap gap-2 justify-center max-w-lg">
        {QUICK_SUGGESTIONS.map((s, i) => (
          <button
            key={i}
            type="button"
            onClick={() => handleSend(s.text)}
            disabled={loading}
            className={cn(
              "px-3.5 py-2 rounded-lg border border-border/60 bg-card text-muted-foreground",
              "hover:border-primary/30 hover:text-foreground hover:shadow-sm",
              "transition-all duration-150 disabled:opacity-40 font-medium",
              isFullscreen ? "text-[13px]" : "text-[11px]"
            )}
          >
            {s.label}
          </button>
        ))}
      </div>
    </div>
  );

  const renderMessageList = (isFullscreen: boolean) => (
    <div className={cn("space-y-5", isFullscreen ? "max-w-4xl mx-auto" : "")}>
      {messages.map((message) => (
        <div key={message.id} className={cn("flex gap-3", message.role === 'user' ? "justify-end" : "justify-start")}>
          {message.role === 'assistant' && (
            <div className={cn(
              "flex-shrink-0 rounded-xl bg-primary/[0.08] flex items-center justify-center mt-0.5",
              isFullscreen ? "w-8 h-8" : "w-7 h-7"
            )}>
              <Bot className={cn("text-primary", isFullscreen ? "h-4 w-4" : "h-3.5 w-3.5")} />
            </div>
          )}
          <div className={cn(
            "min-w-0 rounded-xl",
            isFullscreen ? "text-sm" : "text-[13px]",
            message.role === 'user'
              ? "max-w-[75%] bg-primary text-primary-foreground px-4 py-2.5 rounded-br-sm shadow-sm"
              : "max-w-[88%] bg-card border border-border/50 px-4 py-3 rounded-bl-sm shadow-[0_1px_3px_0_hsl(var(--foreground)/0.04)]"
          )}>
            {renderMessageContent(message, isFullscreen)}
            <p className={cn(
              "text-[10px] mt-2 font-medium",
              message.role === 'user' ? "text-primary-foreground/50" : "text-muted-foreground/50"
            )}>
              {message.timestamp.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
            </p>
          </div>
          {message.role === 'user' && (
            <div className={cn(
              "flex-shrink-0 rounded-xl bg-primary/[0.08] flex items-center justify-center mt-0.5",
              isFullscreen ? "w-8 h-8" : "w-7 h-7"
            )}>
              <User className={cn("text-primary", isFullscreen ? "h-4 w-4" : "h-3.5 w-3.5")} />
            </div>
          )}
        </div>
      ))}
      {loading && (
        <div className="flex gap-3 justify-start">
          <div className={cn(
            "flex-shrink-0 rounded-xl bg-primary/[0.08] flex items-center justify-center",
            isFullscreen ? "w-8 h-8" : "w-7 h-7"
          )}>
            <Bot className={cn("text-primary", isFullscreen ? "h-4 w-4" : "h-3.5 w-3.5")} />
          </div>
          <div className="bg-card border border-border/50 rounded-xl rounded-bl-sm px-4 py-3 shadow-[0_1px_3px_0_hsl(var(--foreground)/0.04)]">
            <div className="flex items-center gap-2">
              <span className="text-xs text-muted-foreground/60 font-medium">Analisando</span>
              <span className="flex items-center gap-1">
                <span className="w-1.5 h-1.5 bg-primary/60 rounded-full animate-[bounce_1s_ease-in-out_infinite]" style={{ animationDelay: '0ms' }} />
                <span className="w-1.5 h-1.5 bg-primary/60 rounded-full animate-[bounce_1s_ease-in-out_infinite]" style={{ animationDelay: '150ms' }} />
                <span className="w-1.5 h-1.5 bg-primary/60 rounded-full animate-[bounce_1s_ease-in-out_infinite]" style={{ animationDelay: '300ms' }} />
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );

  const renderQuickSuggestions = (isFullscreen: boolean) => (
    messages.length > 0 ? (
      <div className="flex flex-wrap gap-1.5 mb-2.5">
        {QUICK_SUGGESTIONS.slice(0, 3).map((s, i) => (
          <button
            key={i}
            type="button"
            onClick={() => handleSend(s.text)}
            disabled={loading}
            className={cn(
              "px-2.5 py-1 rounded-md border border-border/50 bg-card font-medium text-muted-foreground/70",
              "hover:border-primary/30 hover:text-foreground transition-all disabled:opacity-40",
              isFullscreen ? "text-[11px]" : "text-[10px]"
            )}
          >
            {s.label}
          </button>
        ))}
      </div>
    ) : null
  );

  // ============================================================
  // Shared HEADER renderer
  // ============================================================
  const renderHeader = (isFullscreen: boolean) => (
    <div className={cn(
      "flex items-center justify-between border-b border-border/60 flex-shrink-0 bg-card",
      isFullscreen ? "px-6 py-4" : "px-5 py-3.5"
    )}>
      <div className="flex items-center gap-3">
        <div className={cn(
          "rounded-xl bg-primary/[0.08] flex items-center justify-center",
          isFullscreen ? "w-10 h-10" : "w-8 h-8"
        )}>
          <Sparkles className={cn("text-primary", isFullscreen ? "h-5 w-5" : "h-4 w-4")} />
        </div>
        <div className="space-y-0.5">
          <h3 className={cn("font-semibold text-foreground tracking-tight", isFullscreen ? "text-[15px]" : "text-sm")}>
            Assistente Comercial
          </h3>
          <div className="flex items-center gap-2">
            <p className={cn("text-muted-foreground truncate font-medium", isFullscreen ? "text-xs max-w-[400px]" : "text-[11px] max-w-[180px]")}>
              {clientName}
            </p>
            <span className="inline-flex items-center gap-1 text-[9px] font-semibold uppercase tracking-wider text-emerald-600 dark:text-emerald-400">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              Contexto ativo
            </span>
          </div>
        </div>
      </div>
      <div className="flex items-center gap-1">
        {messages.length > 0 && (
          <Button
            variant="ghost"
            size={isFullscreen ? "sm" : "icon"}
            className={cn(
              "text-muted-foreground/60 hover:text-foreground",
              isFullscreen ? "gap-1.5 h-8 text-xs" : "h-7 w-7"
            )}
            onClick={handleClear}
            title="Limpar conversa"
          >
            <Trash2 className="h-3.5 w-3.5" />
            {isFullscreen && <span>Limpar</span>}
          </Button>
        )}
        <Button
          variant="ghost"
          size="icon"
          className={cn("text-muted-foreground/60 hover:text-foreground", isFullscreen ? "h-8 w-8" : "h-7 w-7")}
          onClick={() => setFullscreenOpen(!fullscreenOpen)}
          title={isFullscreen ? "Recolher" : "Expandir"}
        >
          {isFullscreen ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-3.5 w-3.5" />}
        </Button>
      </div>
    </div>
  );

  // ============================================================
  // Shared BODY renderer
  // ============================================================
  const renderBody = (isFullscreen: boolean) => (
    <div className={cn(
      "flex-1 min-h-0 overflow-y-auto bg-muted/20",
      isFullscreen ? "px-6 py-5" : "px-4 py-4"
    )}>
      {messages.length === 0 ? renderEmptyState(isFullscreen) : renderMessageList(isFullscreen)}
      <div ref={isFullscreen ? fullscreenScrollEndRef : scrollEndRef} />
    </div>
  );

  // ============================================================
  // Shared FOOTER renderer
  // ============================================================
  const renderFooter = (isFullscreen: boolean) => (
    <div className={cn(
      "flex-shrink-0 border-t border-border/60 bg-card",
      isFullscreen
        ? "px-6 pb-5 pt-3.5 shadow-[0_-4px_16px_-4px_hsl(var(--foreground)/0.06)]"
        : "px-5 pb-3.5 pt-3 shadow-[0_-2px_8px_-3px_hsl(var(--foreground)/0.05)]"
    )}>
      {renderQuickSuggestions(isFullscreen)}
      <div className={cn(isFullscreen && "max-w-4xl mx-auto")}>
        <ChatGPTPromptInput
          placeholder="Pergunte sobre este cliente..."
          onSend={(msg) => handleSend(msg)}
          loading={loading}
          showTools={false}
          showImageUpload={false}
          showVoice={false}
          className={cn(isFullscreen && "text-sm")}
        />
      </div>
    </div>
  );

  // ============================================================
  // INLINE (normal) mode
  // ============================================================
  const renderInline = () => (
    <div className="rounded-xl border border-border/60 bg-card flex flex-col h-[580px] overflow-hidden shadow-[0_1px_4px_0_hsl(var(--foreground)/0.04)]">
      {renderHeader(false)}
      {renderBody(false)}
      {renderFooter(false)}
    </div>
  );

  // ============================================================
  // FULLSCREEN mode (Dialog)
  // ============================================================
  const renderFullscreen = () => (
    <Dialog open={fullscreenOpen} onOpenChange={setFullscreenOpen}>
      <DialogContent className="max-w-[95vw] w-full h-[90vh] flex flex-col p-0 gap-0 overflow-hidden rounded-2xl border-border/60 shadow-2xl">
        <DialogTitle className="sr-only">Assistente Comercial IA - {clientName}</DialogTitle>
        <DialogDescription className="sr-only">Chat contextual com IA sobre o cliente {clientName}</DialogDescription>
        {renderHeader(true)}
        {renderBody(true)}
        {renderFooter(true)}
      </DialogContent>
    </Dialog>
  );

  return (
    <>
      {fullscreenOpen ? (
        <div className="rounded-xl border border-border/60 bg-card flex items-center justify-center h-[580px] text-muted-foreground shadow-[0_1px_4px_0_hsl(var(--foreground)/0.04)]">
          <div className="text-center space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-primary/[0.06] flex items-center justify-center mx-auto">
              <MessageSquare className="h-5 w-5 text-primary/60" />
            </div>
            <p className="text-sm font-medium text-muted-foreground/70">Chat expandido em tela cheia</p>
            <Button variant="outline" size="sm" onClick={() => setFullscreenOpen(false)} className="gap-1.5 text-xs font-medium">
              <Minimize2 className="h-3.5 w-3.5" /> Recolher
            </Button>
          </div>
        </div>
      ) : (
        renderInline()
      )}
      {renderFullscreen()}
    </>
  );
}
