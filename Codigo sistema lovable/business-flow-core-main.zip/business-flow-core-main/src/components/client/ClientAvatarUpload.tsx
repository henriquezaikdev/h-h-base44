import { useRef, useState } from 'react';
import { Camera, Loader2 } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

interface ClientAvatarUploadProps {
  clientId: string;
  clientName: string;
  avatarUrl: string | null;
  onAvatarUpdated: (url: string) => void;
  size?: 'sm' | 'md' | 'lg';
}

export function ClientAvatarUpload({
  clientId,
  clientName,
  avatarUrl,
  onAvatarUpdated,
  size = 'md',
}: ClientAvatarUploadProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [preview, setPreview] = useState<string | null>(null);

  const sizeClasses = {
    sm: 'h-10 w-10',
    md: 'h-14 w-14',
    lg: 'h-20 w-20',
  };

  const initials = clientName
    .split(' ')
    .map((w) => w[0])
    .slice(0, 2)
    .join('')
    .toUpperCase();

  const handleClick = () => {
    if (!uploading) fileInputRef.current?.click();
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Show preview immediately
    const localUrl = URL.createObjectURL(file);
    setPreview(localUrl);
    setUploading(true);

    try {
      const ext = file.name.split('.').pop() || 'jpg';
      const filePath = `${clientId}/${Date.now()}.${ext}`;

      const { error: uploadError } = await supabase.storage
        .from('client_avatars')
        .upload(filePath, file, { upsert: true });

      if (uploadError) throw uploadError;

      const { data: publicUrlData } = supabase.storage
        .from('client_avatars')
        .getPublicUrl(filePath);

      const publicUrl = publicUrlData.publicUrl;

      const { error: updateError } = await supabase
        .from('clients')
        .update({ avatar_url: publicUrl } as any)
        .eq('id', clientId);

      if (updateError) throw updateError;

      onAvatarUpdated(publicUrl);
      toast({ title: 'Foto atualizada com sucesso!' });
    } catch (err: any) {
      console.error('Avatar upload error:', err);
      setPreview(null);
      toast({
        title: 'Erro ao fazer upload da foto',
        description: 'Tente novamente.',
        variant: 'destructive',
      });
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const displayUrl = preview || avatarUrl;

  return (
    <div className="relative group cursor-pointer" onClick={handleClick}>
      <Avatar className={cn(sizeClasses[size], 'ring-2 ring-border transition-all group-hover:ring-primary/40')}>
        <AvatarImage src={displayUrl || undefined} className="object-cover" />
        <AvatarFallback className="bg-primary/10 text-primary font-semibold text-sm">
          {initials}
        </AvatarFallback>
      </Avatar>

      {/* Camera badge */}
      {!uploading && (
        <div className="absolute -bottom-0.5 -right-0.5 h-5 w-5 rounded-full bg-primary text-primary-foreground flex items-center justify-center shadow-sm opacity-0 group-hover:opacity-100 transition-opacity md:opacity-70 pointer-events-none">
          <Camera size={10} />
        </div>
      )}

      {/* Loading overlay */}
      {uploading && (
        <div className="absolute inset-0 rounded-full bg-background/60 flex items-center justify-center">
          <Loader2 size={18} className="animate-spin text-primary" />
        </div>
      )}

      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        capture="user"
        className="hidden"
        onChange={handleFileChange}
      />
    </div>
  );
}
