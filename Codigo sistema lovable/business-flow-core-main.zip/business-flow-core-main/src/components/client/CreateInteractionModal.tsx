import { useState, useEffect, useMemo } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Loader2, Phone, MessageCircle, Mail, MapPin, MoreHorizontal, CheckCircle, UserCheck, PhoneOff, MessageSquareOff, Calendar } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { useAuth } from '@/hooks/useAuth';
import { buildDraftKey, readDraft, writeDraft, clearDraft } from '@/lib/drafts';
import { CONTACT_REASON_OPTIONS, ContactReason, getReasonConfig } from '@/lib/contactReasons';
import { SELLER_METRICS_QUERY_KEY } from '@/hooks/useSellerMetrics';
import { cn } from '@/lib/utils';

// Helper to get date in São Paulo timezone (YYYY-MM-DD)
function saoPauloDayKey(date: Date): string {
  return new Intl.DateTimeFormat('sv-SE', {
    timeZone: 'America/Sao_Paulo',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(date);
}

// Helper to get time in São Paulo timezone (HH:mm:ss)
function saoPauloTimeKey(date: Date): string {
  return new Intl.DateTimeFormat('en-GB', {
    timeZone: 'America/Sao_Paulo',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false,
  }).format(date);
}

interface CreateInteractionModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  clientId: string;
  clientName: string;
  sellerId: string | null;
  sellerName?: string;
  onCreated: () => void;
}

const INTERACTION_TYPES = [
  { value: 'Ligação', label: 'Ligação', icon: Phone, color: 'text-blue-500' },
  { value: 'WhatsApp', label: 'WhatsApp', icon: MessageCircle, color: 'text-green-500' },
  { value: 'E-mail', label: 'E-mail', icon: Mail, color: 'text-purple-500' },
  { value: 'Visita', label: 'Visita', icon: MapPin, color: 'text-orange-500' },
  { value: 'Outro', label: 'Outro', icon: MoreHorizontal, color: 'text-muted-foreground' },
];

const RESULT_OPTIONS = [
  { value: 'falou_decisor', label: 'Falou com decisor', icon: UserCheck },
  { value: 'sem_resposta', label: 'Sem resposta', icon: PhoneOff },
  { value: 'pedido_confirmado', label: 'Pedido confirmado', icon: CheckCircle },
  { value: 'followup_necessario', label: 'Follow-up necessário', icon: Calendar },
  { value: 'outro', label: 'Outro resultado', icon: MoreHorizontal },
];

export function CreateInteractionModal({
  open,
  onOpenChange,
  clientId,
  clientName,
  sellerId,
  sellerName,
  onCreated,
}: CreateInteractionModalProps) {
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [interactionType, setInteractionType] = useState<string>('');
  const [executionDate, setExecutionDate] = useState(saoPauloDayKey(new Date()));
  const [contactReason, setContactReason] = useState<ContactReason>('RETORNO');
  const [result, setResult] = useState<string>('');
  const [notes, setNotes] = useState('');

  const resetForm = () => {
    setInteractionType('');
    setExecutionDate(saoPauloDayKey(new Date()));
    setContactReason('RETORNO');
    setResult('');
    setNotes('');
  };

  const draftKey = useMemo(() => {
    return buildDraftKey(['clientes', 'draft', user?.id || 'unknown', clientId, 'createInteraction']);
  }, [user?.id, clientId]);

  useEffect(() => {
    if (!open) return;
    const stored = readDraft<{ value: any }>(draftKey, 'session');
    if (stored?.value) {
      if (typeof stored.value.interactionType === 'string') setInteractionType(stored.value.interactionType);
      if (typeof stored.value.executionDate === 'string') setExecutionDate(stored.value.executionDate);
      if (typeof stored.value.contactReason === 'string') setContactReason(stored.value.contactReason as ContactReason);
      if (typeof stored.value.result === 'string') setResult(stored.value.result);
      if (typeof stored.value.notes === 'string') setNotes(stored.value.notes);
    }
  }, [open, draftKey]);

  useEffect(() => {
    if (!open) return;
    const t = setTimeout(() => {
      writeDraft(
        draftKey,
        { value: { interactionType, executionDate, contactReason, result, notes }, savedAt: Date.now() },
        'session'
      );
    }, 500);
    return () => clearTimeout(t);
  }, [open, draftKey, interactionType, executionDate, contactReason, result, notes]);

  const handleSave = async () => {
    if (!sellerId) {
      toast.error('Vendedor não identificado');
      return;
    }

    // Validations
    if (!interactionType) {
      toast.error('Selecione o tipo de interação');
      return;
    }

    if (!executionDate) {
      toast.error('Informe a data da execução');
      return;
    }

    if (!result) {
      toast.error('Selecione o resultado da interação');
      return;
    }

    // Prevent future dates
    const selectedDate = new Date(executionDate);
    const today = new Date();
    today.setHours(23, 59, 59, 999);
    if (selectedDate > today) {
      toast.error('A data não pode ser futura. Interações são para registrar ações já executadas.');
      return;
    }

    setLoading(true);
    try {
      const now = new Date();
      const resultLabel = RESULT_OPTIONS.find(r => r.value === result)?.label || result;
      
      // Build notes with result
      const fullNotes = notes.trim() 
        ? `[${resultLabel}] ${notes.trim()}`
        : `[${resultLabel}]`;

      // Create interaction record - already completed (no pending status)
      const { error: interactionError } = await supabase.from('interactions').insert({
        client_id: clientId,
        interaction_type: interactionType,
        interaction_date: executionDate,
        interaction_time: saoPauloTimeKey(now),
        interaction_notes: fullNotes,
        responsible_seller_id: sellerId,
        contact_reason: contactReason,
      });

      if (interactionError) throw interactionError;

      // Update client last_contact_at only for successful contacts
      const isSuccessfulContact = result === 'falou_decisor' || result === 'pedido_confirmado';
      if (isSuccessfulContact) {
        await supabase
          .from('clients')
          .update({ last_contact_at: new Date(executionDate).toISOString() })
          .eq('id', clientId);
      }

      toast.success('Interação registrada com sucesso!');

      // INVALIDAR CACHE DE MÉTRICAS PARA ATUALIZAÇÃO IMEDIATA
      queryClient.invalidateQueries({ queryKey: [SELLER_METRICS_QUERY_KEY] });

      // limpar rascunho ao salvar de verdade
      clearDraft(draftKey, 'session');

      // Reset form
      resetForm();
      onOpenChange(false);
      onCreated();
    } catch (error) {
      console.error('Error creating interaction:', error);
      toast.error('Erro ao registrar interação');
    } finally {
      setLoading(false);
    }
  };


  const handleClose = () => {
    resetForm();
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="text-lg">
            Criar Interação
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-5 py-4">
          {/* Client Info */}
          <div className="p-3 bg-muted/50 rounded-lg">
            <p className="font-medium">{clientName}</p>
            {sellerName && (
              <p className="text-sm text-muted-foreground">Responsável: {sellerName}</p>
            )}
          </div>

          {/* Interaction Type */}
          <div className="space-y-3">
            <Label className="text-base">Tipo de Interação *</Label>
            <div className="grid grid-cols-5 gap-2">
              {INTERACTION_TYPES.map((type) => (
                <Button
                  key={type.value}
                  type="button"
                  variant="outline"
                  className={`h-auto py-3 flex flex-col gap-1.5 ${
                    interactionType === type.value
                      ? 'border-primary bg-primary/5'
                      : 'hover:bg-muted/50'
                  }`}
                  onClick={() => setInteractionType(type.value)}
                >
                  <type.icon className={`h-5 w-5 ${
                    interactionType === type.value ? 'text-primary' : type.color
                  }`} />
                  <span className="text-xs font-medium">{type.label}</span>
                </Button>
              ))}
            </div>
          </div>

          {/* Execution Date */}
          <div className="space-y-2">
            <Label htmlFor="executionDate" className="text-base">Data da Execução *</Label>
            <Input
              id="executionDate"
              type="date"
              value={executionDate}
              onChange={(e) => setExecutionDate(e.target.value)}
              max={saoPauloDayKey(new Date())}
            />
            <p className="text-xs text-muted-foreground">
              Quando a interação foi realizada. Não pode ser data futura.
            </p>
          </div>

          {/* Contact Reason Selection */}
          <div className="space-y-3">
            <Label className="text-base">Motivo do Contato *</Label>
            <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
              {CONTACT_REASON_OPTIONS.map((opt) => {
                const Icon = opt.icon;
                return (
                  <button
                    key={opt.value}
                    type="button"
                    onClick={() => setContactReason(opt.value)}
                    className={cn(
                      "p-2 rounded-lg border text-center transition-all flex flex-col items-center gap-1",
                      contactReason === opt.value
                        ? "border-primary bg-primary/5"
                        : `${opt.bgColor} hover:opacity-80`
                    )}
                  >
                    <Icon className={cn("h-4 w-4", contactReason === opt.value ? "text-primary" : opt.color)} />
                    <span className="text-xs font-medium">{opt.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Result Selection */}
          <div className="space-y-3">
            <Label className="text-base">Resultado da Interação *</Label>
            <RadioGroup value={result} onValueChange={setResult} className="space-y-2">
              {RESULT_OPTIONS.map((option) => (
                <div
                  key={option.value}
                  className={`flex items-center space-x-3 p-3 rounded-lg border cursor-pointer transition-colors ${
                    result === option.value
                      ? 'border-primary bg-primary/5'
                      : 'border-border hover:bg-muted/50'
                  }`}
                  onClick={() => setResult(option.value)}
                >
                  <RadioGroupItem value={option.value} id={option.value} />
                  <option.icon className={`h-5 w-5 ${
                    result === option.value ? 'text-primary' : 'text-muted-foreground'
                  }`} />
                  <Label htmlFor={option.value} className="flex-1 cursor-pointer font-medium">
                    {option.label}
                  </Label>
                </div>
              ))}
            </RadioGroup>
          </div>

          {/* Notes */}
          <div className="space-y-2">
            <Label htmlFor="notes" className="text-base">Observações</Label>
            <Textarea
              id="notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Detalhes adicionais sobre a interação..."
              rows={3}
              className="resize-none"
            />
            <p className="text-xs text-muted-foreground">
              Opcional. Esta anotação será salva no histórico do cliente.
            </p>
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={handleClose} disabled={loading}>
            Cancelar
          </Button>
          <Button 
            onClick={handleSave} 
            disabled={loading || !interactionType || !result}
          >
            {loading && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
            Salvar Interação
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
