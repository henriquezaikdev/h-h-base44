import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import { jsPDF } from 'jspdf';
import { ClipboardList, Download, Loader2 } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface ChecklistItem {
  id: string;
  name: string;
  quantity: number;
  lastPurchaseDate: string | null;
  purchaseCount: number;
  category: string;
  observation: string;
}

interface ClientChecklistProps {
  clientId: string;
  clientName: string;
  logoUrl?: string;
}

// Categorization function based on product name
const categorizeProduct = (productName: string): string => {
  const name = productName.toLowerCase();
  
  // Papelaria
  if (name.includes('papel') || name.includes('caneta') || name.includes('lápis') || 
      name.includes('caderno') || name.includes('envelope') || name.includes('grampo') ||
      name.includes('clip') || name.includes('régua') || name.includes('tesoura') ||
      name.includes('cola') || name.includes('fita adesiva') || name.includes('post-it') ||
      name.includes('borracha') || name.includes('apontador') || name.includes('pasta') ||
      name.includes('arquivo') || name.includes('etiqueta')) {
    return 'Papelaria';
  }
  
  // Limpeza
  if (name.includes('limpa') || name.includes('detergente') || name.includes('desinfetante') ||
      name.includes('alvejante') || name.includes('sabão') || name.includes('esponja') ||
      name.includes('pano') || name.includes('vassoura') || name.includes('rodo') ||
      name.includes('balde') || name.includes('luva') || name.includes('saco de lixo') ||
      name.includes('água sanitária') || name.includes('multiuso') || name.includes('limpador')) {
    return 'Limpeza';
  }
  
  // Copa & Cozinha
  if (name.includes('café') || name.includes('açúcar') || name.includes('adoçante') ||
      name.includes('copo') || name.includes('guardanapo') || name.includes('mexedor') ||
      name.includes('filtro') || name.includes('chá') || name.includes('leite') ||
      name.includes('biscoito') || name.includes('água mineral') || name.includes('garfo') ||
      name.includes('faca') || name.includes('colher') || name.includes('prato')) {
    return 'Copa & Cozinha';
  }
  
  // Informática / Toner
  if (name.includes('toner') || name.includes('cartucho') || name.includes('ribbon') ||
      name.includes('mouse') || name.includes('teclado') || name.includes('cabo') ||
      name.includes('pendrive') || name.includes('pilha') || name.includes('bateria') ||
      name.includes('impressora') || name.includes('refil')) {
    return 'Informática / Toner';
  }
  
  // Descartáveis / Embalagens
  if (name.includes('descartável') || name.includes('embalagem') || name.includes('sacola') ||
      name.includes('bobina') || name.includes('filme') || name.includes('alumínio') ||
      name.includes('marmita') || name.includes('isopor') || name.includes('canudo')) {
    return 'Descartáveis / Embalagens';
  }
  
  // Higiene
  if (name.includes('papel higiênico') || name.includes('papel toalha') || name.includes('sabonete') ||
      name.includes('álcool') || name.includes('dispenser') || name.includes('higiene')) {
    return 'Higiene';
  }
  
  return 'Outros';
};

// Calculate recurrence observation
const getRecurrenceText = (purchaseCount: number, lastPurchaseDate: string | null): string => {
  if (!lastPurchaseDate) return '';
  
  if (purchaseCount >= 6) return 'Consumo mensal';
  if (purchaseCount >= 3) return 'Consumo bimestral';
  if (purchaseCount >= 2) return 'Consumo trimestral';
  return 'Eventual';
};

export function ClientChecklist({ clientId, clientName, logoUrl }: ClientChecklistProps) {
  const [items, setItems] = useState<ChecklistItem[]>([]);
  const [observations, setObservations] = useState('');
  const [isOpen, setIsOpen] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (isOpen) {
      generateSuggestions();
    }
  }, [isOpen, clientId]);

  const generateSuggestions = async () => {
    setLoading(true);
    
    try {
      // Get client's orders with dates
      const { data: orders } = await supabase
        .from('orders')
        .select('id, order_date')
        .eq('client_id', clientId)
        .order('order_date', { ascending: false });

      if (!orders || orders.length === 0) {
        setItems([]);
        setLoading(false);
        return;
      }

      const orderIds = orders.map(o => o.id);

      // Get all items from orders with product info
      const { data: orderItems } = await supabase
        .from('order_items')
        .select(`
          product_name,
          quantity,
          order_id,
          product_id,
          products (
            category,
            category_id,
            categories (name)
          )
        `)
        .in('order_id', orderIds);

      if (!orderItems) {
        setItems([]);
        setLoading(false);
        return;
      }

      // Create order date map
      const orderDateMap = new Map<string, string>();
      orders.forEach(o => {
        if (o.order_date) {
          orderDateMap.set(o.id, o.order_date);
        }
      });

      // Aggregate products by name with last purchase date
      const productMap = new Map<string, {
        count: number;
        totalQty: number;
        avgQty: number;
        lastPurchaseDate: string | null;
        category: string;
        originalName: string;
      }>();

      orderItems.forEach(item => {
        const key = item.product_name.toLowerCase();
        const orderDate = orderDateMap.get(item.order_id);
        const existing = productMap.get(key);
        
        // Get category from product or categorize by name
        let category = 'Outros';
        if (item.products?.categories?.name) {
          category = item.products.categories.name;
        } else if (item.products?.category) {
          category = item.products.category;
        } else {
          category = categorizeProduct(item.product_name);
        }
        
        if (existing) {
          existing.count += 1;
          existing.totalQty += Number(item.quantity);
          existing.avgQty = Math.round(existing.totalQty / existing.count);
          // Keep most recent date
          if (orderDate && (!existing.lastPurchaseDate || orderDate > existing.lastPurchaseDate)) {
            existing.lastPurchaseDate = orderDate;
          }
        } else {
          productMap.set(key, {
            count: 1,
            totalQty: Number(item.quantity),
            avgQty: Number(item.quantity),
            lastPurchaseDate: orderDate || null,
            category,
            originalName: item.product_name,
          });
        }
      });

      // Convert to array and sort by frequency
      const suggestions: ChecklistItem[] = Array.from(productMap.entries())
        .sort((a, b) => b[1].count - a[1].count)
        .map(([_, data]) => ({
          id: crypto.randomUUID(),
          name: data.originalName,
          quantity: data.avgQty,
          lastPurchaseDate: data.lastPurchaseDate,
          purchaseCount: data.count,
          category: data.category,
          observation: '',
        }));

      setItems(suggestions);
    } catch (error) {
      console.error('Error generating suggestions:', error);
      toast.error('Erro ao gerar sugestões');
    } finally {
      setLoading(false);
    }
  };

  const handleExportPDF = () => {
    const doc = new jsPDF();
    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();
    const marginLeft = 20;
    const marginRight = 20;
    const contentWidth = pageWidth - marginLeft - marginRight;

    // Group items by category
    const groupedItems = items.reduce((acc, item) => {
      if (!acc[item.category]) {
        acc[item.category] = [];
      }
      acc[item.category].push(item);
      return acc;
    }, {} as Record<string, ChecklistItem[]>);

    // Sort categories
    const categoryOrder = [
      'Papelaria',
      'Limpeza', 
      'Copa & Cozinha',
      'Informática / Toner',
      'Descartáveis / Embalagens',
      'Higiene',
      'Outros'
    ];
    
    const sortedCategories = Object.keys(groupedItems).sort((a, b) => {
      const indexA = categoryOrder.indexOf(a);
      const indexB = categoryOrder.indexOf(b);
      if (indexA === -1 && indexB === -1) return a.localeCompare(b);
      if (indexA === -1) return 1;
      if (indexB === -1) return -1;
      return indexA - indexB;
    });

    // ===== COVER PAGE =====
    // Black header
    doc.setFillColor(0, 0, 0);
    doc.rect(0, 0, pageWidth, 50, 'F');
    
    // H&H Logo
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(32);
    doc.setFont('helvetica', 'bold');
    doc.text('H&H', marginLeft, 32);
    
    doc.setFontSize(11);
    doc.setFont('helvetica', 'normal');
    doc.text('Suprimentos Corporativos', 55, 28);
    doc.text('www.hhsuprimentos.com.br', 55, 38);

    // Orange accent
    doc.setFillColor(249, 115, 22);
    doc.rect(0, 50, pageWidth, 4, 'F');

    // Title section
    let yPos = 85;
    doc.setTextColor(0, 0, 0);
    doc.setFontSize(28);
    doc.setFont('helvetica', 'bold');
    doc.text('Checklist de Reposição', marginLeft, yPos);
    
    yPos += 15;
    doc.setFontSize(18);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(107, 114, 128);
    doc.text('Baseado no histórico de compras', marginLeft, yPos);

    // Client name
    yPos += 35;
    doc.setFillColor(249, 249, 249);
    doc.rect(marginLeft - 5, yPos - 12, contentWidth + 10, 35, 'F');
    
    doc.setTextColor(0, 0, 0);
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text('CLIENTE', marginLeft, yPos);
    
    yPos += 12;
    doc.setFontSize(20);
    doc.text(clientName, marginLeft, yPos);

    // Generation date
    yPos += 40;
    doc.setFontSize(11);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(107, 114, 128);
    const generationDate = format(new Date(), "dd 'de' MMMM 'de' yyyy", { locale: ptBR });
    doc.text(`Gerado em ${generationDate}`, marginLeft, yPos);

    // Summary
    yPos += 25;
    doc.setTextColor(0, 0, 0);
    doc.setFontSize(12);
    doc.setFont('helvetica', 'bold');
    doc.text('RESUMO', marginLeft, yPos);
    
    yPos += 12;
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(11);
    doc.text(`• ${items.length} itens no histórico de compras`, marginLeft + 5, yPos);
    yPos += 8;
    doc.text(`• ${sortedCategories.length} categorias identificadas`, marginLeft + 5, yPos);

    // Categories list
    yPos += 15;
    sortedCategories.forEach(cat => {
      doc.text(`• ${cat}: ${groupedItems[cat].length} itens`, marginLeft + 10, yPos);
      yPos += 7;
    });

    // ===== CHECKLIST PAGES =====
    doc.addPage();
    yPos = 30;

    // Page header function
    const addPageHeader = () => {
      doc.setFillColor(0, 0, 0);
      doc.rect(0, 0, pageWidth, 25, 'F');
      
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(14);
      doc.setFont('helvetica', 'bold');
      doc.text('H&H', marginLeft, 16);
      
      doc.setFontSize(10);
      doc.setFont('helvetica', 'normal');
      doc.text(`Checklist - ${clientName}`, 45, 16);
      
      doc.setFillColor(249, 115, 22);
      doc.rect(0, 25, pageWidth, 2, 'F');
    };

    addPageHeader();
    yPos = 40;

    // Add each category
    sortedCategories.forEach((category, catIndex) => {
      const categoryItems = groupedItems[category];
      
      // Check if we need a new page for category header
      if (yPos > pageHeight - 60) {
        doc.addPage();
        addPageHeader();
        yPos = 40;
      }

      // Category header
      doc.setFillColor(249, 115, 22);
      doc.rect(marginLeft - 5, yPos - 5, contentWidth + 10, 12, 'F');
      
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(12);
      doc.setFont('helvetica', 'bold');
      doc.text(category.toUpperCase(), marginLeft, yPos + 3);
      doc.text(`(${categoryItems.length})`, pageWidth - marginRight - 20, yPos + 3);

      yPos += 18;

      // Column headers
      doc.setTextColor(107, 114, 128);
      doc.setFontSize(8);
      doc.setFont('helvetica', 'bold');
      doc.text('ITEM', marginLeft + 8, yPos);
      doc.text('QTD', pageWidth - 85, yPos);
      doc.text('ÚLTIMA COMPRA', pageWidth - 60, yPos);

      yPos += 8;

      // Items
      categoryItems.forEach((item, itemIndex) => {
        // Check for page break
        if (yPos > pageHeight - 30) {
          doc.addPage();
          addPageHeader();
          yPos = 40;
          
          // Repeat category header on new page
          doc.setFillColor(240, 240, 240);
          doc.rect(marginLeft - 5, yPos - 5, contentWidth + 10, 10, 'F');
          doc.setTextColor(107, 114, 128);
          doc.setFontSize(10);
          doc.setFont('helvetica', 'italic');
          doc.text(`${category} (continuação)`, marginLeft, yPos + 2);
          yPos += 15;
        }

        // Alternating background
        if (itemIndex % 2 === 0) {
          doc.setFillColor(250, 250, 250);
          doc.rect(marginLeft - 5, yPos - 5, contentWidth + 10, 14, 'F');
        }

        // Checkbox
        doc.setDrawColor(200, 200, 200);
        doc.setLineWidth(0.5);
        doc.rect(marginLeft, yPos - 3, 5, 5);

        // Product name (truncate if too long)
        doc.setTextColor(0, 0, 0);
        doc.setFontSize(10);
        doc.setFont('helvetica', 'normal');
        
        let displayName = item.name;
        const maxNameWidth = 90;
        while (doc.getTextWidth(displayName) > maxNameWidth && displayName.length > 10) {
          displayName = displayName.slice(0, -4) + '...';
        }
        doc.text(displayName, marginLeft + 8, yPos);

        // Quantity
        doc.setFont('helvetica', 'bold');
        doc.text(`${item.quantity}x`, pageWidth - 85, yPos);

        // Last purchase date
        doc.setFont('helvetica', 'normal');
        doc.setTextColor(107, 114, 128);
        if (item.lastPurchaseDate) {
          const formattedDate = format(new Date(item.lastPurchaseDate), 'dd/MM/yyyy');
          doc.text(formattedDate, pageWidth - 60, yPos);
        } else {
          doc.text('-', pageWidth - 60, yPos);
        }

        // Recurrence indicator (if applicable)
        const recurrence = getRecurrenceText(item.purchaseCount, item.lastPurchaseDate);
        if (recurrence && item.purchaseCount >= 2) {
          doc.setFontSize(7);
          doc.setTextColor(249, 115, 22);
          doc.text(recurrence, marginLeft + 8, yPos + 5);
          yPos += 4;
        }

        // Product observation (if any)
        if (item.observation && item.observation.trim()) {
          doc.setFontSize(8);
          doc.setTextColor(100, 100, 100);
          doc.setFont('helvetica', 'italic');
          const obsText = `Obs: ${item.observation}`;
          const obsLines = doc.splitTextToSize(obsText, maxNameWidth + 30);
          doc.text(obsLines, marginLeft + 8, yPos + 5);
          yPos += obsLines.length * 4 + 2;
          doc.setFont('helvetica', 'normal');
        }

        yPos += 14;
      });

      yPos += 10; // Space between categories
    });

    // ===== OBSERVATIONS PAGE =====
    if (observations.trim()) {
      if (yPos > pageHeight - 80) {
        doc.addPage();
        addPageHeader();
        yPos = 40;
      }

      yPos += 10;
      doc.setFillColor(255, 251, 235);
      doc.rect(marginLeft - 5, yPos - 5, contentWidth + 10, 50, 'F');
      
      doc.setTextColor(180, 83, 9);
      doc.setFontSize(10);
      doc.setFont('helvetica', 'bold');
      doc.text('OBSERVAÇÕES', marginLeft, yPos + 5);
      
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(0, 0, 0);
      doc.setFontSize(10);
      const obsLines = doc.splitTextToSize(observations, contentWidth - 10);
      doc.text(obsLines, marginLeft, yPos + 18);
    }

    // ===== FOOTER on all pages =====
    const totalPages = doc.getNumberOfPages();
    for (let i = 1; i <= totalPages; i++) {
      doc.setPage(i);
      
      const footerY = pageHeight - 12;
      doc.setDrawColor(230, 230, 230);
      doc.setLineWidth(0.5);
      doc.line(marginLeft, footerY - 8, pageWidth - marginRight, footerY - 8);
      
      doc.setTextColor(150, 150, 150);
      doc.setFontSize(8);
      doc.setFont('helvetica', 'normal');
      doc.text('Checklist gerado automaticamente com base no histórico do cliente.', marginLeft, footerY);
      doc.text(`Página ${i} de ${totalPages}`, pageWidth - marginRight - 25, footerY);
    }

    // Save
    const fileName = `checklist-reposicao-${clientName.toLowerCase().replace(/\s+/g, '-')}-${format(new Date(), 'yyyy-MM-dd')}.pdf`;
    doc.save(fileName);
    toast.success('Checklist exportado com sucesso!');
  };

  // Group items by category for preview
  const groupedItems = items.reduce((acc, item) => {
    if (!acc[item.category]) {
      acc[item.category] = [];
    }
    acc[item.category].push(item);
    return acc;
  }, {} as Record<string, ChecklistItem[]>);

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="gap-2">
          <ClipboardList size={18} />
          Gerar Checklist
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-3xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ClipboardList size={20} />
            Checklist de Reposição - {clientName}
          </DialogTitle>
        </DialogHeader>

        {loading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="animate-spin mr-2" size={24} />
            <span>Analisando histórico de compras...</span>
          </div>
        ) : items.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            <ClipboardList size={48} className="mx-auto mb-4 opacity-50" />
            <p>Nenhum histórico de compras encontrado.</p>
            <p className="text-sm">Importe pedidos para gerar o checklist.</p>
          </div>
        ) : (
          <div className="space-y-6">
            {/* Summary */}
            <div className="bg-muted/30 rounded-lg p-4">
              <p className="text-sm text-muted-foreground">
                <strong className="text-foreground">{items.length} itens</strong> encontrados em{' '}
                <strong className="text-foreground">{Object.keys(groupedItems).length} categorias</strong>
              </p>
            </div>

            {/* Preview by category */}
            <div className="space-y-4">
              {Object.entries(groupedItems).map(([category, categoryItems]) => (
                <div key={category} className="border rounded-lg overflow-hidden">
                  <div className="bg-primary text-primary-foreground px-4 py-2 flex justify-between items-center">
                    <span className="font-medium">{category}</span>
                    <span className="text-sm opacity-80">{categoryItems.length} itens</span>
                  </div>
                  <div className="divide-y">
                    {categoryItems.map((item) => (
                      <div key={item.id} className="px-4 py-3 space-y-2">
                        <div className="flex items-center justify-between text-sm">
                          <div className="flex-1">
                            <span>{item.name}</span>
                            {item.purchaseCount >= 2 && (
                              <span className="ml-2 text-xs text-primary">
                                ({getRecurrenceText(item.purchaseCount, item.lastPurchaseDate)})
                              </span>
                            )}
                          </div>
                          <div className="flex items-center gap-4 text-muted-foreground">
                            <span className="font-medium text-foreground">{item.quantity}x</span>
                            <span className="text-xs w-24 text-right">
                              {item.lastPurchaseDate 
                                ? format(new Date(item.lastPurchaseDate), 'dd/MM/yyyy')
                                : '-'
                              }
                            </span>
                          </div>
                        </div>
                        <input
                          type="text"
                          placeholder="Observação do produto..."
                          value={item.observation}
                          onChange={(e) => {
                            setItems(prev => prev.map(i => 
                              i.id === item.id ? { ...i, observation: e.target.value } : i
                            ));
                          }}
                          className="w-full text-xs px-2 py-1 border rounded bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary"
                        />
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            {/* Observations */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Observações (opcional)</label>
              <Textarea
                placeholder="Adicione observações para incluir no checklist..."
                value={observations}
                onChange={(e) => setObservations(e.target.value)}
                rows={3}
              />
            </div>

            {/* Actions */}
            <div className="flex justify-end gap-3 pt-4 border-t">
              <Button variant="outline" onClick={() => setIsOpen(false)}>
                Cancelar
              </Button>
              <Button onClick={handleExportPDF} className="gap-2">
                <Download size={18} />
                Baixar PDF
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
