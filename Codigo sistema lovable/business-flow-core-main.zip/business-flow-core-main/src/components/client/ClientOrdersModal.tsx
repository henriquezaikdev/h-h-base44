import { useState, useEffect } from 'react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import {
  ShoppingCart,
  Loader2,
  Package,
  Calendar,
  FileText,
  ChevronRight,
} from 'lucide-react';
import { formatCurrency } from '@/lib/utils';

interface OrderData {
  id: string;
  order_date: string;
  total: number;
  order_number: string;
  payment_method: string | null;
}

interface OrderItemData {
  id: string;
  product_name: string;
  quantity: number;
  unit_price: number;
  subtotal: number;
}

interface ClientOrdersModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  clientName: string;
  clientId: string | null;
}

export function ClientOrdersModal({
  open,
  onOpenChange,
  clientName,
  clientId,
}: ClientOrdersModalProps) {
  const [orders, setOrders] = useState<OrderData[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedOrderId, setSelectedOrderId] = useState<string | null>(null);
  const [orderItems, setOrderItems] = useState<OrderItemData[]>([]);
  const [loadingItems, setLoadingItems] = useState(false);

  useEffect(() => {
    if (clientId && open) {
      fetchOrders();
    } else {
      setOrders([]);
      setSelectedOrderId(null);
      setOrderItems([]);
    }
  }, [clientId, open]);

  const fetchOrders = async () => {
    if (!clientId) return;
    
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('orders')
        .select('id, order_date, total, order_number, payment_method')
        .eq('client_id', clientId)
        .eq('is_deleted', false)
        .order('order_date', { ascending: false });

      if (error) throw error;
      setOrders(data || []);
    } catch (error) {
      console.error('Error fetching orders:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchOrderItems = async (orderId: string) => {
    if (selectedOrderId === orderId) {
      setSelectedOrderId(null);
      setOrderItems([]);
      return;
    }

    setSelectedOrderId(orderId);
    setLoadingItems(true);
    try {
      const { data, error } = await supabase
        .from('order_items')
        .select('id, product_name, quantity, unit_price, subtotal')
        .eq('order_id', orderId)
        .order('product_name');

      if (error) throw error;
      setOrderItems(data || []);
    } catch (error) {
      console.error('Error fetching order items:', error);
    } finally {
      setLoadingItems(false);
    }
  };

  const totalGeral = orders.reduce((sum, o) => sum + (o.total || 0), 0);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[750px] max-h-[85vh]">
        <DialogHeader className="pb-4 border-b">
          <DialogTitle className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <ShoppingCart size={20} className="text-primary" />
            </div>
            <div>
              <h2 className="text-lg font-semibold">Pedidos</h2>
              <p className="text-sm text-muted-foreground font-normal">
                {clientName}
              </p>
            </div>
          </DialogTitle>
        </DialogHeader>

        {/* Resumo */}
        <div className="flex gap-3 py-3">
          <div className="flex-1 bg-muted/50 rounded-lg p-3 text-center">
            <p className="text-xs text-muted-foreground mb-1">Total Pedidos</p>
            <p className="text-xl font-bold">{orders.length}</p>
          </div>
          <div className="flex-1 bg-emerald-500/10 rounded-lg p-3 text-center">
            <p className="text-xs text-muted-foreground mb-1">Valor Total</p>
            <p className="text-xl font-bold text-emerald-600 dark:text-emerald-400">
              {formatCurrency(totalGeral)}
            </p>
          </div>
        </div>

        <ScrollArea className="h-[400px] pr-2">
          {loading ? (
            <div className="flex flex-col items-center justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-muted-foreground mb-3" />
              <p className="text-sm text-muted-foreground">Carregando pedidos...</p>
            </div>
          ) : orders.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <div className="w-12 h-12 rounded-full bg-muted flex items-center justify-center mb-3">
                <FileText size={24} className="text-muted-foreground" />
              </div>
              <p className="text-muted-foreground">Nenhum pedido encontrado</p>
            </div>
          ) : (
            <div className="space-y-2">
              {orders.map((order) => (
                <div key={order.id}>
                  <button
                    onClick={() => fetchOrderItems(order.id)}
                    className={`w-full text-left bg-card border rounded-lg p-4 transition-all hover:border-foreground/20 ${
                      selectedOrderId === order.id ? 'border-primary/50 bg-primary/5' : 'border-border'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-muted flex items-center justify-center">
                          <Package size={18} className="text-muted-foreground" />
                        </div>
                        <div>
                          <p className="font-medium">
                            #{order.order_number || order.id.slice(0, 8)}
                          </p>
                          <div className="flex items-center gap-2 text-xs text-muted-foreground">
                            <Calendar size={10} />
                            {order.order_date
                              ? format(new Date(order.order_date), "dd 'de' MMMM 'de' yyyy", { locale: ptBR })
                              : 'Data não informada'}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <div className="text-right">
                          <p className="font-semibold text-emerald-600 dark:text-emerald-400">
                            {formatCurrency(order.total || 0)}
                          </p>
                          {order.payment_method && (
                            <Badge variant="outline" className="text-xs mt-1">
                              {order.payment_method}
                            </Badge>
                          )}
                        </div>
                        <ChevronRight
                          size={18}
                          className={`text-muted-foreground transition-transform ${
                            selectedOrderId === order.id ? 'rotate-90' : ''
                          }`}
                        />
                      </div>
                    </div>
                  </button>

                  {/* Order Items */}
                  {selectedOrderId === order.id && (
                    <div className="mt-1 ml-6 border-l-2 border-muted pl-4 py-2 space-y-2">
                      {loadingItems ? (
                        <div className="flex items-center gap-2 py-2 text-muted-foreground text-sm">
                          <Loader2 size={14} className="animate-spin" />
                          Carregando itens...
                        </div>
                      ) : orderItems.length === 0 ? (
                        <p className="text-sm text-muted-foreground py-2">
                          Nenhum item encontrado
                        </p>
                      ) : (
                        orderItems.map((item) => (
                          <div
                            key={item.id}
                            className="flex items-center justify-between bg-muted/50 rounded-md p-2 text-sm"
                          >
                            <div className="flex-1 min-w-0">
                              <p className="font-medium truncate">{item.product_name}</p>
                              <p className="text-xs text-muted-foreground">
                                {item.quantity} x {formatCurrency(item.unit_price)}
                              </p>
                            </div>
                            <p className="font-medium text-foreground ml-3">
                              {formatCurrency(item.subtotal)}
                            </p>
                          </div>
                        ))
                      )}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}
