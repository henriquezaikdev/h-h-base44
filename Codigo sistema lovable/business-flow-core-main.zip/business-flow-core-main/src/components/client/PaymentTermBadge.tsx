import { useClientPaymentTerm } from '@/hooks/useClientPaymentTerm';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Calendar, Loader2 } from 'lucide-react';

interface PaymentTermBadgeProps {
  clientId: string;
  variant?: 'card' | 'inline' | 'compact';
  className?: string;
}

export function PaymentTermBadge({ clientId, variant = 'inline', className = '' }: PaymentTermBadgeProps) {
  const { avgPaymentDays, loading, totalOrders } = useClientPaymentTerm(clientId);

  if (loading) {
    return (
      <div className={`flex items-center gap-2 text-muted-foreground ${className}`}>
        <Loader2 className="h-4 w-4 animate-spin" />
        {variant !== 'compact' && <span className="text-sm">Carregando...</span>}
      </div>
    );
  }

  if (avgPaymentDays === null || totalOrders === 0) {
    if (variant === 'compact') return null;
    return (
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <div className={`flex items-center gap-2 text-muted-foreground ${className}`}>
              <Calendar className="h-4 w-4" />
              <span className="text-sm">Sem histórico</span>
            </div>
          </TooltipTrigger>
          <TooltipContent>
            <p>Nenhum pedido com prazo de pagamento registrado</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    );
  }

  const tooltipText = `Baseado em ${totalOrders} pedido${totalOrders > 1 ? 's' : ''} com prazo registrado`;

  if (variant === 'card') {
    return (
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <div className={`card-section cursor-help ${className}`}>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-blue-500/10 rounded-lg flex items-center justify-center">
                  <Calendar className="h-5 w-5 text-blue-600" />
                </div>
                <div>
                  <p className="text-xl font-bold text-foreground">{avgPaymentDays} dias</p>
                  <p className="text-sm text-muted-foreground">Prazo Médio Pgto</p>
                </div>
              </div>
            </div>
          </TooltipTrigger>
          <TooltipContent>
            <p>{tooltipText}</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    );
  }

  if (variant === 'compact') {
    return (
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <span className={`inline-flex items-center gap-1.5 text-sm text-muted-foreground cursor-help ${className}`}>
              <Calendar className="h-3.5 w-3.5" />
              <span className="font-medium">{avgPaymentDays}d</span>
            </span>
          </TooltipTrigger>
          <TooltipContent>
            <p>Prazo médio de pagamento: {avgPaymentDays} dias</p>
            <p className="text-xs text-muted-foreground">{tooltipText}</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    );
  }

  // variant === 'inline'
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <div className={`flex items-center gap-2 cursor-help ${className}`}>
            <Calendar className="h-4 w-4 text-blue-600" />
            <span className="text-sm">
              <span className="font-semibold text-foreground">{avgPaymentDays} dias</span>
              <span className="text-muted-foreground ml-1">prazo médio</span>
            </span>
          </div>
        </TooltipTrigger>
        <TooltipContent>
          <p>{tooltipText}</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}
