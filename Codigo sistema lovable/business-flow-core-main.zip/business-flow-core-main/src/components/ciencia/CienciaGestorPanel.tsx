import { useCienciaMetas, CienciaMetaInfo } from '@/hooks/useCienciaMetas';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { FileText, Send, RefreshCw, CheckCircle, Clock, AlertTriangle } from 'lucide-react';
import { format, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { toast } from 'sonner';

const STATUS_CONFIG: Record<string, { label: string; color: string; icon: any }> = {
  RASCUNHO: { label: 'Rascunho', color: 'bg-gray-100 text-gray-600 border-gray-200', icon: FileText },
  AGUARDANDO_CIENCIA: { label: 'Aguardando', color: 'bg-amber-100 text-amber-700 border-amber-200', icon: Clock },
  CIENTE: { label: 'Ciente', color: 'bg-emerald-100 text-emerald-700 border-emerald-200', icon: CheckCircle },
  EXPIRADA: { label: 'Expirada', color: 'bg-red-100 text-red-700 border-red-200', icon: AlertTriangle },
};

export function CienciaGestorPanel() {
  const { allCiencias, enviarParaCiencia, reenviarParaCiencia, loading } = useCienciaMetas();

  if (loading) {
    return <div className="py-4 text-center text-sm text-muted-foreground animate-pulse">Carregando...</div>;
  }

  const handleEnviar = async (sl: CienciaMetaInfo) => {
    const isResend = sl.status_ciencia !== 'RASCUNHO';
    if (isResend) {
      await reenviarParaCiencia(sl.seller_level_id);
    } else {
      await enviarParaCiencia(sl.seller_level_id);
    }
  };

  return (
    <Card className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-sm border border-white/60">
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2 text-[#121216]">
          <FileText className="h-4 w-4 text-[#FF6A00]" /> Ciência de Metas
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <div className="divide-y divide-gray-100">
          {allCiencias.map((ci) => {
            const statusConf = STATUS_CONFIG[ci.status_ciencia] || STATUS_CONFIG.RASCUNHO;
            const StatusIcon = statusConf.icon;
            const isResend = ci.status_ciencia !== 'RASCUNHO';

            return (
              <div key={ci.seller_level_id} className="flex items-center gap-3 px-4 py-3">
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-[#121216] truncate">{ci.seller_name}</p>
                  <div className="flex items-center gap-2 mt-0.5">
                    <Badge variant="outline" className={`text-[10px] ${statusConf.color} gap-0.5 rounded-lg`}>
                      <StatusIcon className="h-3 w-3" /> {statusConf.label}
                    </Badge>
                    {ci.ciente_em && (
                      <span className="text-[10px] text-gray-400">
                        Ciente em {format(parseISO(ci.ciente_em), 'dd/MM HH:mm', { locale: ptBR })}
                      </span>
                    )}
                    {ci.pdf_metas_url && (
                      <button
                        onClick={() => window.open(ci.pdf_metas_url!, '_blank')}
                        className="text-[10px] text-[#FF6A00] hover:underline flex items-center gap-0.5"
                      >
                        <FileText className="h-3 w-3" /> v{ci.versao_documento}
                      </button>
                    )}
                  </div>
                </div>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleEnviar(ci)}
                  className="rounded-xl text-xs gap-1 shrink-0"
                >
                  {isResend ? <RefreshCw className="h-3 w-3" /> : <Send className="h-3 w-3" />}
                  {isResend ? 'Reenviar' : 'Enviar'}
                </Button>
              </div>
            );
          })}
          {allCiencias.length === 0 && (
            <p className="text-sm text-gray-400 text-center py-6">Nenhum vendedor configurado</p>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
