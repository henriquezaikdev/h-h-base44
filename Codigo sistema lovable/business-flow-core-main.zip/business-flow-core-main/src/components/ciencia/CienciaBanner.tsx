import { useState } from 'react';
import { useCienciaMetas } from '@/hooks/useCienciaMetas';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { AlertTriangle, FileText, CheckCircle } from 'lucide-react';
import { format, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export function CienciaBanner() {
  const { pendingCiencia, darCiencia } = useCienciaMetas();
  const [showModal, setShowModal] = useState(false);
  const [confirming, setConfirming] = useState(false);

  if (!pendingCiencia) return null;

  const prazoLabel = pendingCiencia.prazo_ciencia
    ? format(parseISO(pendingCiencia.prazo_ciencia), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })
    : '';

  const handleCiencia = async () => {
    setConfirming(true);
    await darCiencia();
    setConfirming(false);
    setShowModal(false);
  };

  return (
    <>
      {/* Banner */}
      <Card className="bg-amber-50 border-amber-300 rounded-2xl shadow-sm animate-in fade-in slide-in-from-top-2">
        <CardContent className="p-4 flex items-center gap-3">
          <div className="h-10 w-10 rounded-xl bg-amber-100 flex items-center justify-center shrink-0">
            <AlertTriangle className="h-5 w-5 text-amber-600" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold text-amber-800">Metas do mês aguardando ciência</p>
            <p className="text-xs text-amber-600">Prazo: {prazoLabel}</p>
          </div>
          <Button
            size="sm"
            variant="outline"
            onClick={() => setShowModal(true)}
            className="rounded-xl border-amber-400 text-amber-700 hover:bg-amber-100 gap-1.5"
          >
            <FileText className="h-3.5 w-3.5" /> Revisar
          </Button>
        </CardContent>
      </Card>

      {/* Modal */}
      <Dialog open={showModal} onOpenChange={setShowModal}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5 text-[#FF6A00]" />
              Ciência de Metas
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="bg-[#fef9f0] border border-[#fde5c5] rounded-xl p-4 space-y-2">
              <p className="text-sm font-medium text-amber-800">Suas metas foram definidas para este mês.</p>
              <p className="text-xs text-amber-600">Revise o documento e confirme a ciência até {prazoLabel}.</p>
            </div>

            <div className="grid grid-cols-2 gap-3 text-sm">
              <div className="bg-gray-50 rounded-xl p-3">
                <p className="text-[10px] text-gray-500 uppercase">Meta de Vendas</p>
                <p className="font-bold text-[#FF6A00]">
                  {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(pendingCiencia.monthly_sales_target)}
                </p>
              </div>
              <div className="bg-gray-50 rounded-xl p-3">
                <p className="text-[10px] text-gray-500 uppercase">Ligações/dia</p>
                <p className="font-bold">{pendingCiencia.base_daily_calls}</p>
              </div>
              <div className="bg-gray-50 rounded-xl p-3">
                <p className="text-[10px] text-gray-500 uppercase">WhatsApp/dia</p>
                <p className="font-bold">{pendingCiencia.base_daily_whatsapp}</p>
              </div>
              <div className="bg-gray-50 rounded-xl p-3">
                <p className="text-[10px] text-gray-500 uppercase">Versão</p>
                <p className="font-bold">v{pendingCiencia.versao_documento}</p>
              </div>
            </div>

            {pendingCiencia.pdf_metas_url && (
              <Button
                variant="outline"
                className="w-full rounded-xl gap-2"
                onClick={() => window.open(pendingCiencia.pdf_metas_url!, '_blank')}
              >
                <FileText className="h-4 w-4" /> Abrir Documento Completo
              </Button>
            )}

            <Button
              onClick={handleCiencia}
              disabled={confirming}
              className="w-full rounded-xl bg-[#FF6A00] hover:bg-[#FF6A00]/90 text-white gap-2"
            >
              <CheckCircle className="h-4 w-4" />
              {confirming ? 'Registrando...' : 'Estou Ciente'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
