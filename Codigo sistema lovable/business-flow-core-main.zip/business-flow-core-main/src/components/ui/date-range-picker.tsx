import * as React from "react";
import { format, parse, isValid, isAfter, isBefore } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Calendar as CalendarIcon, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

// ─── Mask helper ───────────────────────────────────────────
// Automatically formats typed digits into DD/MM/AAAA

function applyDateMask(raw: string): string {
  const digits = raw.replace(/\D/g, "").slice(0, 8);
  if (digits.length <= 2) return digits;
  if (digits.length <= 4) return `${digits.slice(0, 2)}/${digits.slice(2)}`;
  return `${digits.slice(0, 2)}/${digits.slice(2, 4)}/${digits.slice(4)}`;
}

function parseDateString(value: string): Date | undefined {
  if (value.length !== 10) return undefined;
  const d = parse(value, "dd/MM/yyyy", new Date());
  return isValid(d) ? d : undefined;
}

function formatDateToInput(date: Date | undefined): string {
  if (!date || !isValid(date)) return "";
  return format(date, "dd/MM/yyyy");
}

// ─── Single date input ─────────────────────────────────────

interface DateInputProps {
  value: string;
  onChange: (value: string) => void;
  onDateChange: (date: Date | undefined) => void;
  placeholder?: string;
  label?: string;
  className?: string;
  minDate?: Date;
  maxDate?: Date;
}

function DateInput({
  value,
  onChange,
  onDateChange,
  placeholder = "DD/MM/AAAA",
  label,
  className,
  minDate,
  maxDate,
}: DateInputProps) {
  const inputRef = React.useRef<HTMLInputElement>(null);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const masked = applyDateMask(e.target.value);
    onChange(masked);

    const parsed = parseDateString(masked);
    if (parsed) {
      if (minDate && isBefore(parsed, minDate)) return;
      if (maxDate && isAfter(parsed, maxDate)) return;
      onDateChange(parsed);
    } else if (masked === "") {
      onDateChange(undefined);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    // Allow: backspace, delete, tab, escape, enter, arrows
    const allowed = ["Backspace", "Delete", "Tab", "Escape", "Enter", "ArrowLeft", "ArrowRight", "Home", "End"];
    if (allowed.includes(e.key)) return;
    // Allow ctrl/cmd shortcuts
    if (e.ctrlKey || e.metaKey) return;
    // Block non-digit keys
    if (!/^\d$/.test(e.key)) {
      e.preventDefault();
    }
  };

  return (
    <div className={cn("flex items-center gap-1.5", className)}>
      {label && (
        <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground shrink-0">
          {label}
        </span>
      )}
      <div className="relative">
        <CalendarIcon className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground pointer-events-none" />
        <input
          ref={inputRef}
          type="text"
          inputMode="numeric"
          value={value}
          onChange={handleChange}
          onKeyDown={handleKeyDown}
          placeholder={placeholder}
          className={cn(
            "h-9 w-[140px] rounded-md border border-input bg-background pl-8 pr-3 py-2",
            "text-sm font-normal text-foreground placeholder:text-muted-foreground",
            "focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-1",
            "transition-colors",
            // Validate visual state
            value.length === 10 && !parseDateString(value) && "border-destructive focus:ring-destructive/30",
          )}
          maxLength={10}
          autoComplete="off"
        />
      </div>
    </div>
  );
}

// ─── DateRangePicker (Conta Azul style) ────────────────────

interface DateRangePickerProps {
  startDate: Date | undefined;
  endDate: Date | undefined;
  onApply: (startDate: Date | undefined, endDate: Date | undefined) => void;
  onClear?: () => void;
  fromYear?: number;
  toYear?: number;
  className?: string;
  startLabel?: string;
  endLabel?: string;
  showClearButton?: boolean;
}

export function DateRangePicker({
  startDate,
  endDate,
  onApply,
  onClear,
  className,
  startLabel = "De",
  endLabel = "Até",
  showClearButton = true,
}: DateRangePickerProps) {
  const [startText, setStartText] = React.useState(formatDateToInput(startDate));
  const [endText, setEndText] = React.useState(formatDateToInput(endDate));
  const debounceRef = React.useRef<ReturnType<typeof setTimeout>>();

  // Sync text when props change externally
  React.useEffect(() => {
    setStartText(formatDateToInput(startDate));
  }, [startDate]);

  React.useEffect(() => {
    setEndText(formatDateToInput(endDate));
  }, [endDate]);

  const debouncedApply = React.useCallback(
    (start: Date | undefined, end: Date | undefined) => {
      if (debounceRef.current) clearTimeout(debounceRef.current);
      debounceRef.current = setTimeout(() => {
        onApply(start, end);
      }, 400);
    },
    [onApply]
  );

  const handleStartDateChange = React.useCallback(
    (date: Date | undefined) => {
      debouncedApply(date, endDate);
    },
    [debouncedApply, endDate]
  );

  const handleEndDateChange = React.useCallback(
    (date: Date | undefined) => {
      debouncedApply(startDate, date);
    },
    [debouncedApply, startDate]
  );

  const handleClear = () => {
    setStartText("");
    setEndText("");
    onClear?.();
  };

  const hasFilter = startDate || endDate;

  return (
    <div className={cn("flex flex-wrap items-center gap-3", className)}>
      <DateInput
        label={startLabel}
        value={startText}
        onChange={setStartText}
        onDateChange={handleStartDateChange}
      />
      <DateInput
        label={endLabel}
        value={endText}
        onChange={setEndText}
        onDateChange={handleEndDateChange}
        minDate={startDate}
      />
      {showClearButton && hasFilter && (
        <Button variant="ghost" size="sm" onClick={handleClear} className="h-9 text-xs gap-1">
          <X size={14} />
          Limpar
        </Button>
      )}
    </div>
  );
}

// ─── DatePickerWithConfirm (single date, same style) ──────

interface DatePickerWithConfirmProps {
  date: Date | undefined;
  onApply: (date: Date | undefined) => void;
  label?: string;
  placeholder?: string;
  fromYear?: number;
  toYear?: number;
  className?: string;
  disabled?: (date: Date) => boolean;
}

export function DatePickerWithConfirm({
  date,
  onApply,
  label,
  placeholder = "DD/MM/AAAA",
  className,
}: DatePickerWithConfirmProps) {
  const [text, setText] = React.useState(formatDateToInput(date));

  React.useEffect(() => {
    setText(formatDateToInput(date));
  }, [date]);

  const handleDateChange = React.useCallback(
    (d: Date | undefined) => {
      onApply(d);
    },
    [onApply]
  );

  return (
    <DateInput
      label={label ?? undefined}
      value={text}
      onChange={setText}
      onDateChange={handleDateChange}
      placeholder={placeholder}
      className={className}
    />
  );
}
