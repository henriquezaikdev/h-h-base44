import { ChevronDown, Loader2 } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface CollapsibleDataSectionProps {
  title: string;
  count: number | null;
  loadingCount?: boolean;
  expanded: boolean;
  onToggle: () => void;
  children: React.ReactNode;
  hasMore?: boolean;
  onLoadMore?: () => void;
  loadingMore?: boolean;
}

export function CollapsibleDataSection({
  title,
  count,
  loadingCount,
  expanded,
  onToggle,
  children,
  hasMore,
  onLoadMore,
  loadingMore,
}: CollapsibleDataSectionProps) {
  return (
    <div className="rounded-xl border border-border/50 bg-card overflow-hidden shadow-sm">
      <button
        onClick={onToggle}
        className="w-full flex items-center justify-between px-4 py-3 hover:bg-muted/30 transition-colors text-left"
      >
        <div className="flex items-center gap-2">
          <span className="font-semibold text-sm text-foreground">{title}</span>
          {loadingCount ? (
            <Skeleton className="h-5 w-12 rounded-full" />
          ) : count !== null ? (
            <Badge variant="secondary" className="text-xs font-medium">
              {count.toLocaleString('pt-BR')}
            </Badge>
          ) : null}
        </div>
        <ChevronDown
          className={cn(
            'h-4 w-4 text-muted-foreground transition-transform duration-200',
            expanded && 'rotate-180'
          )}
        />
      </button>

      {expanded && (
        <div className="border-t border-border/50">
          {children}

          {hasMore && (
            <div className="px-4 py-3 border-t border-border/30 flex justify-center">
              <Button
                variant="ghost"
                size="sm"
                onClick={onLoadMore}
                disabled={loadingMore}
                className="text-xs text-muted-foreground hover:text-foreground gap-1.5"
              >
                {loadingMore ? (
                  <>
                    <Loader2 className="h-3 w-3 animate-spin" />
                    Carregando...
                  </>
                ) : (
                  'Ver mais 10'
                )}
              </Button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export function DataSkeleton({ rows = 3 }: { rows?: number }) {
  return (
    <div className="p-4 space-y-3">
      {Array.from({ length: rows }).map((_, i) => (
        <Skeleton key={i} className="h-10 w-full rounded" />
      ))}
    </div>
  );
}
