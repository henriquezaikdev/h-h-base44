"use client";

import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Card, CardContent } from '@/components/ui/card';
import { Marquee } from '@/components/ui/marquee';
import { cn } from '@/lib/utils';

const testimonials = [
  { name: 'Vendedor A', username: '@vendedorA', body: 'Sistema facilitou muito minha rotina diária!', img: 'https://randomuser.me/api/portraits/men/32.jpg', country: '🏆 Top 20' },
  { name: 'Vendedor B', username: '@vendedorB', body: 'Metas mais claras, resultados melhores.', img: 'https://randomuser.me/api/portraits/women/68.jpg', country: '⭐ Destaque' },
  { name: 'Vendedor C', username: '@vendedorC', body: 'Acompanhamento de clientes nunca foi tão fácil!', img: 'https://randomuser.me/api/portraits/men/51.jpg', country: '📈 Crescimento' },
  { name: 'Vendedor D', username: '@vendedorD', body: 'IA me ajuda a priorizar o dia.', img: 'https://randomuser.me/api/portraits/women/53.jpg', country: '🎯 Foco' },
  { name: 'Vendedor E', username: '@vendedorE', body: 'Ferramenta essencial para vendas B2B.', img: 'https://randomuser.me/api/portraits/men/33.jpg', country: '💼 Negócios' },
  { name: 'Vendedor F', username: '@vendedorF', body: 'Produtividade aumentou significativamente!', img: 'https://randomuser.me/api/portraits/men/22.jpg', country: '🚀 Performance' },
];

function TestimonialCard({ img, name, username, body, country }: (typeof testimonials)[number]) {
  return (
    <Card className={cn(
      "w-56 shrink-0 cursor-pointer overflow-hidden rounded-xl border",
      "border-border/50 bg-card/80 backdrop-blur-sm",
      "transition-all duration-300 hover:scale-[1.02] hover:shadow-lg hover:shadow-primary/5"
    )}>
      <CardContent className="p-4">
        <div className="flex items-center gap-3">
          <Avatar className="h-10 w-10 border border-border/50">
            <AvatarImage src={img} alt={name} />
            <AvatarFallback className="bg-primary/10 text-primary text-sm font-medium">
              {name[0]}
            </AvatarFallback>
          </Avatar>
          <div className="flex flex-col overflow-hidden">
            <span className="text-sm font-medium text-foreground truncate">
              {name} {country}
            </span>
            <span className="text-xs text-muted-foreground truncate">
              {username}
            </span>
          </div>
        </div>
        <p className="mt-3 text-sm text-muted-foreground leading-relaxed line-clamp-2">
          {body}
        </p>
      </CardContent>
    </Card>
  );
}

interface TestimonialsMarqueeProps {
  className?: string;
}

export function TestimonialsMarquee({ className }: TestimonialsMarqueeProps) {
  return (
    <div className={cn("relative w-full overflow-hidden", className)}>
      <Marquee pauseOnHover className="[--duration:35s]">
        {testimonials.map((review) => (
          <TestimonialCard key={review.username} {...review} />
        ))}
      </Marquee>
      
      {/* Fade edges */}
      <div className="pointer-events-none absolute inset-y-0 left-0 w-16 bg-gradient-to-r from-background to-transparent" />
      <div className="pointer-events-none absolute inset-y-0 right-0 w-16 bg-gradient-to-l from-background to-transparent" />
    </div>
  );
}

export default TestimonialsMarquee;
