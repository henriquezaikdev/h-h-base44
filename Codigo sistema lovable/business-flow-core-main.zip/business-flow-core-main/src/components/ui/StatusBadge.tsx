import { ClientStatus, ClientCategory, ClientClassification } from '@/types/crm';

type StatusType = ClientStatus | ClientCategory | ClientClassification;

interface StatusBadgeProps {
  status: StatusType;
}

const statusConfig: Record<StatusType, { label: string; className: string }> = {
  // Client statuses
  ativo: { label: 'Ativo', className: 'status-active' },
  inativo: { label: 'Inativo', className: 'status-inactive' },
  
  // Client categories
  regular: { label: 'Regular', className: 'status-badge bg-foreground/5 text-foreground/70 border border-foreground/10' },
  
  // Classifications (based on days since last order)
  novo: { label: '🆕 Novo', className: 'status-badge bg-blue-500/10 text-blue-600 border border-blue-500/30' },
  recorrente: { label: '🔄 Recorrente', className: 'status-active' },
  '60dias': { label: '⚠️ 60 dias', className: 'status-badge bg-amber-500/10 text-amber-600 border border-amber-500/30' },
  '90dias': { label: '⏰ 90 dias', className: 'status-badge bg-orange-500/10 text-orange-600 border border-orange-500/30' },
  '120dias': { label: '🔴 120 dias', className: 'status-badge bg-red-500/10 text-red-500 border border-red-500/30' },
};

export function StatusBadge({ status }: StatusBadgeProps) {
  const config = statusConfig[status];
  
  if (!config) return null;
  
  return (
    <span className={`status-badge ${config.className}`}>
      {config.label}
    </span>
  );
}
