"use client";

import React, { useState, ReactNode } from "react";
import { motion, AnimatePresence, PanInfo } from "framer-motion";
import { cn } from "@/lib/utils";
import { LayoutGrid, Layers, List } from "lucide-react";

type ViewMode = "stack" | "grid" | "list";

interface CardData {
  id: string;
  title: string;
  description: string;
  icon: ReactNode;
  count?: number;
  variant?: "destructive" | "warning" | "primary" | "muted";
  onClick?: () => void;
}

interface MorphingCardStackProps {
  cards: CardData[];
  className?: string;
  showViewToggle?: boolean;
  defaultView?: ViewMode;
}

const cardVariants = {
  stack: {
    initial: (i: number) => ({
      scale: 1 - i * 0.05,
      y: i * -8,
      zIndex: 10 - i,
      opacity: 1 - i * 0.15,
    }),
    hover: (i: number) => ({
      scale: 1 - i * 0.03,
      y: i * -12,
      zIndex: 10 - i,
    }),
  },
  grid: {
    initial: { scale: 1, opacity: 1 },
    hover: { scale: 1.02, y: -4 },
  },
  list: {
    initial: { scale: 1, opacity: 1, x: 0 },
    hover: { x: 8 },
  },
};

const variantStyles = {
  destructive: "border-destructive/30 bg-destructive/5 hover:bg-destructive/10",
  warning: "border-amber-500/30 bg-amber-500/5 hover:bg-amber-500/10",
  primary: "border-primary/30 bg-primary/5 hover:bg-primary/10",
  muted: "border-border bg-muted/30 hover:bg-muted/50",
};

const variantIconStyles = {
  destructive: "text-destructive",
  warning: "text-amber-500",
  primary: "text-primary",
  muted: "text-muted-foreground",
};

export function MorphingCardStack({
  cards,
  className,
  showViewToggle = true,
  defaultView = "grid",
}: MorphingCardStackProps) {
  const [viewMode, setViewMode] = useState<ViewMode>(defaultView);
  const [stackCards, setStackCards] = useState(cards);
  const [isDragging, setIsDragging] = useState(false);

  const handleDragEnd = (info: PanInfo) => {
    const threshold = 100;
    if (Math.abs(info.offset.x) > threshold || Math.abs(info.offset.y) > threshold) {
      const [first, ...rest] = stackCards;
      setStackCards([...rest, first]);
    }
    setIsDragging(false);
  };

  const containerStyles = {
    stack: "relative h-52 w-full flex items-center justify-center",
    grid: "grid grid-cols-2 md:grid-cols-4 gap-3",
    list: "flex flex-col gap-2",
  };

  const renderCard = (card: CardData, index: number) => {
    const variant = card.variant || "muted";
    
    if (viewMode === "stack") {
      const isTop = index === 0;
      return (
        <motion.div
          key={card.id}
          className={cn(
            "absolute w-full max-w-xs h-44 rounded-xl border-2 p-4 cursor-grab active:cursor-grabbing backdrop-blur-sm",
            variantStyles[variant],
            isTop && "shadow-lg"
          )}
          custom={index}
          initial="initial"
          animate="initial"
          whileHover={isTop ? "hover" : undefined}
          variants={cardVariants.stack}
          drag={isTop}
          dragConstraints={{ left: 0, right: 0, top: 0, bottom: 0 }}
          dragElastic={0.7}
          onDragStart={() => setIsDragging(true)}
          onDragEnd={(_, info) => handleDragEnd(info)}
          onClick={() => !isDragging && card.onClick?.()}
          style={{ zIndex: cards.length - index }}
        >
          <div className="flex flex-col h-full">
            <div className="flex items-start justify-between mb-2">
              <div className={cn("p-2 rounded-lg bg-background/50", variantIconStyles[variant])}>
                {card.icon}
              </div>
              {card.count !== undefined && (
                <span className={cn(
                  "text-2xl font-bold",
                  variant === "destructive" && "text-destructive",
                  variant === "warning" && "text-amber-500",
                  variant === "primary" && "text-primary"
                )}>
                  {card.count}
                </span>
              )}
            </div>
            <h3 className="font-semibold text-foreground text-sm">{card.title}</h3>
            <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{card.description}</p>
            {isTop && (
              <p className="text-[10px] text-muted-foreground/60 mt-auto pt-2">
                Arraste para ver próximo
              </p>
            )}
          </div>
        </motion.div>
      );
    }

    if (viewMode === "grid") {
      return (
        <motion.div
          key={card.id}
          className={cn(
            "rounded-xl border p-4 cursor-pointer transition-colors",
            variantStyles[variant]
          )}
          initial="initial"
          whileHover="hover"
          variants={cardVariants.grid}
          onClick={() => card.onClick?.()}
          layout
        >
          <div className="flex items-start justify-between mb-2">
            <div className={cn("p-2 rounded-lg bg-background/50", variantIconStyles[variant])}>
              {card.icon}
            </div>
            {card.count !== undefined && (
              <span className={cn(
                "text-xl font-bold",
                variant === "destructive" && "text-destructive",
                variant === "warning" && "text-amber-500",
                variant === "primary" && "text-primary"
              )}>
                {card.count}
              </span>
            )}
          </div>
          <h3 className="font-semibold text-foreground text-sm">{card.title}</h3>
          <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{card.description}</p>
        </motion.div>
      );
    }

    // List view
    return (
      <motion.div
        key={card.id}
        className={cn(
          "flex items-center gap-4 rounded-lg border p-3 cursor-pointer transition-colors",
          variantStyles[variant]
        )}
        initial="initial"
        whileHover="hover"
        variants={cardVariants.list}
        onClick={() => card.onClick?.()}
        layout
      >
        <div className={cn("p-2 rounded-lg bg-background/50 shrink-0", variantIconStyles[variant])}>
          {card.icon}
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="font-semibold text-foreground text-sm">{card.title}</h3>
          <p className="text-xs text-muted-foreground truncate">{card.description}</p>
        </div>
        {card.count !== undefined && (
          <span className={cn(
            "text-lg font-bold shrink-0",
            variant === "destructive" && "text-destructive",
            variant === "warning" && "text-amber-500",
            variant === "primary" && "text-primary"
          )}>
            {card.count}
          </span>
        )}
      </motion.div>
    );
  };

  return (
    <div className={cn("w-full", className)}>
      {showViewToggle && (
        <div className="flex justify-end mb-3">
          <div className="flex items-center gap-1 p-1 rounded-lg bg-muted/50 border">
            <button
              onClick={() => setViewMode("stack")}
              className={cn(
                "p-1.5 rounded-md transition-colors",
                viewMode === "stack" ? "bg-background shadow-sm text-foreground" : "text-muted-foreground hover:text-foreground"
              )}
              title="Pilha"
            >
              <Layers className="h-4 w-4" />
            </button>
            <button
              onClick={() => setViewMode("grid")}
              className={cn(
                "p-1.5 rounded-md transition-colors",
                viewMode === "grid" ? "bg-background shadow-sm text-foreground" : "text-muted-foreground hover:text-foreground"
              )}
              title="Grade"
            >
              <LayoutGrid className="h-4 w-4" />
            </button>
            <button
              onClick={() => setViewMode("list")}
              className={cn(
                "p-1.5 rounded-md transition-colors",
                viewMode === "list" ? "bg-background shadow-sm text-foreground" : "text-muted-foreground hover:text-foreground"
              )}
              title="Lista"
            >
              <List className="h-4 w-4" />
            </button>
          </div>
        </div>
      )}

      <AnimatePresence mode="wait">
        <motion.div
          key={viewMode}
          className={containerStyles[viewMode]}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.2 }}
        >
          {viewMode === "stack"
            ? stackCards.map((card, i) => renderCard(card, i))
            : cards.map((card, i) => renderCard(card, i))}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
