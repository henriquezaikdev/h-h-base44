import React from 'react';
import './toggle-switch.css';

export interface ToggleSwitchProps {
  checked?: boolean;
  onChange?: (checked: boolean) => void;
  id?: string;
}

const ToggleSwitch = React.forwardRef<HTMLInputElement, ToggleSwitchProps>(
  ({ checked, onChange, id = 'toggle-switch' }, ref) => {
    return (
      <div className="ts-switch">
        <input
          ref={ref}
          type="checkbox"
          className="ts-switch-check"
          id={id}
          checked={checked}
          onChange={(e) => onChange?.(e.target.checked)}
        />
        <label className="ts-switch-label" htmlFor={id}>
          Check
          <span />
        </label>
      </div>
    );
  }
);

ToggleSwitch.displayName = 'ToggleSwitch';

export default ToggleSwitch;
