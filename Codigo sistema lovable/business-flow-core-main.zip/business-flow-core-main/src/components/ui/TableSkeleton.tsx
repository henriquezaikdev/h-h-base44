import { Skeleton } from '@/components/ui/skeleton';

interface TableSkeletonProps {
  rows?: number;
  columns?: number;
  showHeader?: boolean;
}

export function TableSkeleton({ rows = 5, columns = 6, showHeader = true }: TableSkeletonProps) {
  return (
    <div className="bg-card border border-border/50 rounded-xl overflow-hidden shadow-sm">
      {showHeader && (
        <div className="bg-muted/30 border-b border-border/50 px-4 py-3 flex gap-4">
          {Array.from({ length: columns }).map((_, i) => (
            <Skeleton key={i} className="h-3 rounded" style={{ width: `${60 + Math.random() * 60}px` }} />
          ))}
        </div>
      )}
      <div className="divide-y divide-border/30">
        {Array.from({ length: rows }).map((_, rowIdx) => (
          <div key={rowIdx} className="px-4 py-4 flex items-center gap-4">
            {Array.from({ length: columns }).map((_, colIdx) => (
              <Skeleton
                key={colIdx}
                className="h-4 rounded"
                style={{ width: `${50 + Math.random() * 80}px` }}
              />
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}

export function MetricCardsSkeleton({ count = 4 }: { count?: number }) {
  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
      {Array.from({ length: count }).map((_, i) => (
        <div key={i} className="h-[72px] flex flex-col justify-between p-4 rounded-xl bg-card border border-border shadow-sm">
          <Skeleton className="h-3 w-20 rounded" />
          <Skeleton className="h-7 w-16 rounded" />
        </div>
      ))}
    </div>
  );
}

export function CardSkeleton() {
  return (
    <div className="p-5 rounded-xl bg-card border border-border shadow-sm space-y-3">
      <Skeleton className="h-4 w-32 rounded" />
      <Skeleton className="h-3 w-48 rounded" />
      <Skeleton className="h-3 w-40 rounded" />
    </div>
  );
}

export function PageSkeleton() {
  return (
    <div className="space-y-6 px-6 pb-8">
      <div className="flex items-center justify-between">
        <div className="space-y-2">
          <Skeleton className="h-6 w-48 rounded" />
          <Skeleton className="h-4 w-32 rounded" />
        </div>
      </div>
      <MetricCardsSkeleton />
      <TableSkeleton />
    </div>
  );
}
