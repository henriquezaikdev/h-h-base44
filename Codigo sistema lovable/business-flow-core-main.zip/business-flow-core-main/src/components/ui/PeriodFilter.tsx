import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { UsePeriodFilterReturn, PERIOD_OPTIONS, PeriodType } from '@/hooks/usePeriodFilter';
import { cn } from '@/lib/utils';

interface PeriodFilterProps {
  filter: UsePeriodFilterReturn;
  className?: string;
}

export function PeriodFilter({ filter, className }: PeriodFilterProps) {
  const { label, goBack, goForward, setType, canGoForward, state } = filter;
  const isFixedPeriod = state.type === 'last30' || state.type === 'last12months' || state.type === 'all';

  return (
    <div className={cn("flex items-center gap-1", className)}>
      {!isFixedPeriod && (
        <Button
          variant="ghost"
          size="icon"
          onClick={goBack}
          className="h-8 w-8"
          aria-label="Período anterior"
        >
          <ChevronLeft className="h-4 w-4" />
        </Button>
      )}

      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button 
            variant="outline" 
            className="min-w-[180px] justify-center font-medium capitalize"
          >
            {label}
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="center" className="bg-background z-50">
          {PERIOD_OPTIONS.map((option) => (
            <DropdownMenuItem
              key={option.value}
              onClick={() => setType(option.value)}
              className={cn(
                "cursor-pointer",
                state.type === option.value && "bg-accent font-medium"
              )}
            >
              {option.label}
            </DropdownMenuItem>
          ))}
        </DropdownMenuContent>
      </DropdownMenu>

      {!isFixedPeriod && (
        <Button
          variant="ghost"
          size="icon"
          onClick={goForward}
          disabled={!canGoForward}
          className="h-8 w-8"
          aria-label="Próximo período"
        >
          <ChevronRight className="h-4 w-4" />
        </Button>
      )}
    </div>
  );
}
