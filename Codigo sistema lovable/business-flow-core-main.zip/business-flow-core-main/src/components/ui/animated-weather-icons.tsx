"use client";

import { cn } from "@/lib/utils";
import { motion } from "framer-motion";

interface WeatherIconProps {
  size?: number;
  className?: string;
}

/* ─── SUN ─── */
export function SunIcon({ size = 48, className }: WeatherIconProps) {
  return (
    <motion.svg width={size} height={size} viewBox="0 0 48 48" fill="none" className={cn("text-amber-400", className)}>
      <motion.g animate={{ rotate: 360 }} transition={{ duration: 20, repeat: Infinity, ease: "linear" }}>
        {[0, 45, 90, 135, 180, 225, 270, 315].map((deg) => (
          <motion.line key={deg} x1="24" y1="4" x2="24" y2="10" stroke="currentColor" strokeWidth="2" strokeLinecap="round" transform={`rotate(${deg} 24 24)`} />
        ))}
      </motion.g>
      <motion.circle cx="24" cy="24" r="8" fill="currentColor" animate={{ scale: [1, 1.08, 1] }} transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }} />
      <circle cx="24" cy="24" r="8" fill="currentColor" opacity="0.3" filter="url(#sunGlow)" />
    </motion.svg>
  );
}

/* ─── MOON ─── */
export function MoonIcon({ size = 48, className }: WeatherIconProps) {
  const stars = [
    { cx: 34, cy: 10, d: 0 }, { cx: 38, cy: 18, d: 0.5 },
    { cx: 30, cy: 6, d: 1 }, { cx: 40, cy: 12, d: 1.5 },
  ];
  return (
    <motion.svg width={size} height={size} viewBox="0 0 48 48" fill="none" className={cn("text-indigo-300", className)}>
      <motion.path d="M28 8a14 14 0 1 0 0 28A14 14 0 0 1 28 8z" fill="currentColor" animate={{ scale: [1, 1.05, 1] }} transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }} />
      <motion.path d="M28 8a14 14 0 1 0 0 28A14 14 0 0 1 28 8z" fill="currentColor" opacity="0.2" filter="url(#moonGlow)" />
      {stars.map((s) => (
        <motion.circle key={`${s.cx}-${s.cy}`} cx={s.cx} cy={s.cy} r="1" fill="currentColor" animate={{ opacity: [0.3, 1, 0.3], scale: [0.8, 1.2, 0.8] }} transition={{ duration: 2, repeat: Infinity, delay: s.d }} />
      ))}
    </motion.svg>
  );
}

/* ─── CLOUD ─── */
export function CloudIcon({ size = 48, className }: WeatherIconProps) {
  return (
    <motion.svg width={size} height={size} viewBox="0 0 48 48" fill="none" className={cn("text-gray-400", className)} animate={{ x: [0, 3, 0] }} transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}>
      <g>
        <ellipse cx="24" cy="26" rx="14" ry="8" fill="currentColor" opacity="0.85" />
        <circle cx="18" cy="22" r="7" fill="currentColor" />
        <circle cx="28" cy="20" r="9" fill="currentColor" />
      </g>
    </motion.svg>
  );
}

/* ─── SUNRISE ─── */
export function SunriseIcon({ size = 48, className }: WeatherIconProps) {
  return (
    <motion.svg width={size} height={size} viewBox="0 0 48 48" fill="none" className={cn("text-orange-400", className)}>
      <line x1="6" y1="38" x2="42" y2="38" stroke="currentColor" strokeWidth="2" strokeLinecap="round" opacity="0.4" />
      <motion.g animate={{ y: [4, 0, 4] }} transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}>
        <circle cx="24" cy="30" r="8" fill="currentColor" />
        <motion.g animate={{ rotate: 360 }} transition={{ duration: 20, repeat: Infinity, ease: "linear" }} style={{ transformOrigin: "24px 30px" }}>
          {[0, 30, 60, 90, 120, 150, 180].map((deg) => (
            <line key={deg} x1="24" y1="16" x2="24" y2="20" stroke="currentColor" strokeWidth="2" strokeLinecap="round" transform={`rotate(${deg} 24 30)`} />
          ))}
        </motion.g>
      </motion.g>
      <motion.path d="M18 42 L24 36 L30 42" stroke="currentColor" strokeWidth="2" fill="none" strokeLinecap="round" animate={{ y: [0, -2, 0] }} transition={{ duration: 2, repeat: Infinity }} />
    </motion.svg>
  );
}

export function getGreetingIcon(hour: number, size = 28) {
  if (hour >= 6 && hour < 12) return <SunriseIcon size={size} />;
  if (hour >= 12 && hour < 18) return <SunIcon size={size} />;
  return <MoonIcon size={size} />;
}
