"use client";
import React, { useState, useEffect } from "react";

const ICONS = [
  "https://pub-940ccf6255b54fa799a9b01050e6c227.r2.dev/gatsby-icon.svg",
  "https://pub-940ccf6255b54fa799a9b01050e6c227.r2.dev/github-icon.svg",
  "https://pub-940ccf6255b54fa799a9b01050e6c227.r2.dev/google-icon.svg",
  "https://pub-940ccf6255b54fa799a9b01050e6c227.r2.dev/sketch-icon.svg",
  "https://pub-940ccf6255b54fa799a9b01050e6c227.r2.dev/slack-icon.svg",
  "https://pub-940ccf6255b54fa799a9b01050e6c227.r2.dev/spotify-icon.svg",
];

function SemiCircleOrbit({ radius, centerX, centerY, count, iconSize }: {
  radius: number;
  centerX: number;
  centerY: number;
  count: number;
  iconSize: number;
}) {
  return (
    <>
      {/* Semi-circle glow background */}
      <div
        className="absolute rounded-full border border-white/10"
        style={{
          width: radius * 2,
          height: radius * 2,
          left: centerX - radius,
          top: centerY - radius,
          background: "radial-gradient(circle, rgba(255,255,255,0.03) 0%, transparent 70%)",
        }}
      />

      {/* Orbit icons */}
      {Array.from({ length: count }).map((_, index) => {
        const angle = (index / (count - 1)) * 180;
        const x = radius * Math.cos((angle * Math.PI) / 180);
        const y = radius * Math.sin((angle * Math.PI) / 180);
        const icon = ICONS[index % ICONS.length];

        const tooltipAbove = angle > 90;

        return (
          <div
            key={index}
            className="absolute group"
            style={{
              left: centerX + x - iconSize / 2,
              top: centerY - y - iconSize / 2,
            }}
          >
            <img
              src={icon}
              alt={`App ${index + 1}`}
              className="rounded-full bg-white/10 p-1.5 shadow-lg backdrop-blur-sm transition-transform duration-300 hover:scale-125 hover:shadow-xl"
              style={{ width: iconSize, height: iconSize }}
            />
            {/* Tooltip */}
            <div
              className={`pointer-events-none absolute left-1/2 -translate-x-1/2 whitespace-nowrap rounded-md bg-black/80 px-2 py-1 text-xs text-white opacity-0 transition-opacity group-hover:opacity-100 ${
                tooltipAbove ? "bottom-full mb-2" : "top-full mt-2"
              }`}
            >
              App {index + 1}
              <div
                className={`absolute left-1/2 -translate-x-1/2 border-4 border-transparent ${
                  tooltipAbove
                    ? "top-full border-t-black/80"
                    : "bottom-full border-b-black/80"
                }`}
              />
            </div>
          </div>
        );
      })}
    </>
  );
}

export default function MultiOrbitSemiCircle() {
  const [size, setSize] = useState({ width: 0, height: 0 });

  useEffect(() => {
    const updateSize = () => setSize({ width: window.innerWidth, height: window.innerHeight });
    updateSize();
    window.addEventListener("resize", updateSize);
    return () => window.removeEventListener("resize", updateSize);
  }, []);

  const baseWidth = Math.min(size.width * 0.8, 700);
  const centerX = baseWidth / 2;
  const centerY = baseWidth * 0.5;

  const iconSize =
    size.width < 480
      ? Math.max(24, baseWidth * 0.05)
      : size.width < 768
        ? Math.max(28, baseWidth * 0.06)
        : Math.max(32, baseWidth * 0.07);

  return (
    <div className="flex min-h-[50vh] items-center justify-center bg-background p-4">
      <div className="flex flex-col items-center">
        <h2 className="mb-2 text-center text-3xl font-bold text-foreground">
          Integrações
        </h2>
        <p className="mb-8 text-center text-muted-foreground">
          Conecte seus apps favoritos ao seu fluxo de trabalho.
        </p>

        <div className="relative" style={{ width: baseWidth, height: baseWidth * 0.55 }}>
          <SemiCircleOrbit radius={baseWidth * 0.22} centerX={centerX} centerY={centerY} count={3} iconSize={iconSize} />
          <SemiCircleOrbit radius={baseWidth * 0.35} centerX={centerX} centerY={centerY} count={5} iconSize={iconSize} />
          <SemiCircleOrbit radius={baseWidth * 0.48} centerX={centerX} centerY={centerY} count={6} iconSize={iconSize} />
        </div>
      </div>
    </div>
  );
}
