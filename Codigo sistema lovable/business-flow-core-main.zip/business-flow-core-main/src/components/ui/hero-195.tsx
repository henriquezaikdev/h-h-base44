"use client";

import React from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { 
  LayoutDashboard, 
  TrendingUp, 
  Users, 
  Calendar,
  ArrowRight
} from "lucide-react";
import { cn } from "@/lib/utils";
import { getGreetingIcon } from "@/components/ui/animated-weather-icons";
import { BorderBeam } from "@/components/ui/border-beam";

interface QuickLinkProps {
  icon: React.ReactNode;
  label: string;
  href: string;
}

const QuickLink: React.FC<QuickLinkProps> = ({ icon, label, href }) => {
  const navigate = useNavigate();
  
  return (
    <motion.button
      type="button"
      whileHover={{ scale: 1.02, y: -2 }}
      whileTap={{ scale: 0.98 }}
      onClick={() => navigate(href)}
      className={cn(
        "group flex items-center gap-3 px-4 py-3 rounded-xl cursor-pointer",
        "bg-card/50 hover:bg-card border border-border/50 hover:border-primary/30",
        "transition-all duration-300 backdrop-blur-sm",
        "hover:shadow-lg hover:shadow-primary/5",
        "relative z-20"
      )}
    >
      <div className="p-2 rounded-lg bg-primary/10 text-primary group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
        {icon}
      </div>
      <span className="text-sm font-medium text-foreground">{label}</span>
      <ArrowRight className="w-4 h-4 ml-auto text-muted-foreground group-hover:text-primary transition-colors" />
    </motion.button>
  );
};

interface Hero195Props {
  userName?: string;
  currentDate?: Date;
  className?: string;
}

export function Hero195({ 
  userName = "Gestor", 
  currentDate = new Date(),
  className 
}: Hero195Props) {
  const greeting = React.useMemo(() => {
    const hour = currentDate.getHours();
    if (hour < 12) return "Bom dia";
    if (hour < 18) return "Boa tarde";
    return "Boa noite";
  }, [currentDate]);

  const formattedDate = currentDate.toLocaleDateString('pt-BR', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  });

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { type: "spring" as const, stiffness: 100, damping: 15 }
    }
  };

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className={cn(
        "relative w-full overflow-hidden rounded-2xl",
        "bg-gradient-to-br from-card via-card/95 to-card/90",
        "border border-border/50",
        className
      )}
    >
      {/* Background Pattern - pointer-events-none to allow clicks through */}
      <div className="absolute inset-0 opacity-[0.03] pointer-events-none -z-10">
        <div 
          className="absolute inset-0"
          style={{
            backgroundImage: `radial-gradient(circle at 1px 1px, currentColor 1px, transparent 0)`,
            backgroundSize: '24px 24px'
          }}
        />
      </div>

      {/* Gradient Orbs - pointer-events-none to allow clicks through */}
      <div className="absolute -top-24 -right-24 w-48 h-48 bg-primary/20 rounded-full blur-3xl pointer-events-none -z-10" />
      <div className="absolute -bottom-24 -left-24 w-48 h-48 bg-hh-orange/20 rounded-full blur-3xl pointer-events-none -z-10" />

      {/* Content */}
      <div className="relative z-10 p-6 md:p-8">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
          {/* Left: Greeting & Title */}
          <motion.div variants={itemVariants} className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              {getGreetingIcon(currentDate.getHours(), 24)}
              <span className="text-sm font-medium text-hh-orange">
                {greeting}, {userName}
              </span>
            </div>
            <h1 className="text-xl font-semibold text-foreground mb-2">
              Visão Geral
            </h1>
            <p className="text-sm text-muted-foreground capitalize">
              {formattedDate}
            </p>
          </motion.div>

          {/* Right: Quick Links */}
          <motion.div 
            variants={itemVariants}
            className="grid grid-cols-2 gap-3 lg:flex lg:gap-3 relative z-20"
          >
            <QuickLink 
              icon={<LayoutDashboard className="w-4 h-4" />}
              label="Dashboard"
              href="/dashboard"
            />
            <QuickLink 
              icon={<TrendingUp className="w-4 h-4" />}
              label="Evolução"
              href="/evolucao-vendedor"
            />
            <QuickLink 
              icon={<Users className="w-4 h-4" />}
              label="Clientes"
              href="/clients"
            />
            <QuickLink 
              icon={<Calendar className="w-4 h-4" />}
              label="Agenda"
              href="/"
            />
          </motion.div>
        </div>
      </div>

      {/* Border Beam Effect */}
      <BorderBeam 
        size={300} 
        duration={12} 
        colorFrom="hsl(var(--hh-orange))" 
        colorTo="hsl(var(--primary))"
        borderWidth={1.5}
      />
    </motion.div>
  );
}

export default Hero195;
