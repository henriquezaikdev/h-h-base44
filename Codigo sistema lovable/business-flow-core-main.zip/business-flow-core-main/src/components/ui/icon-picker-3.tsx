import { useState, useEffect, useRef, useCallback, lazy, Suspense } from 'react'
import { icons, type LucideIcon } from 'lucide-react'
import { ScrollArea, ScrollBar } from '@/components/ui/scroll-area'
import { cn } from '@/lib/utils'

export type IconName = keyof typeof icons

const allIconNames = Object.keys(icons) as IconName[]

const ICON_INITIAL_CHARGE = 20 * 5
const ICONS_BY_CHARGE = 6 * 3
const SCROLL_THRESHOLD = 100

interface IconPickerProps {
  icons?: IconName[]
  onIconSelect: (iconName: IconName) => void
  selectedIcon?: IconName
  heightClassName?: string
}

export function IconPicker({
  icons: iconList,
  onIconSelect,
  selectedIcon,
  heightClassName = 'h-[280px]',
}: IconPickerProps) {
  const iconNames = iconList ?? allIconNames
  const [visibleCount, setVisibleCount] = useState(ICON_INITIAL_CHARGE)
  const rootScrollAreaRef = useRef<HTMLDivElement>(null)
  const viewportScrollElementRef = useRef<HTMLElement | null>(null)

  const iconesAtuais = iconNames.slice(0, visibleCount)

  useEffect(() => {
    setVisibleCount(ICON_INITIAL_CHARGE)
    if (viewportScrollElementRef.current) {
      viewportScrollElementRef.current.scrollTop = 0
    }
  }, [iconNames])

  const loadMoreIcons = useCallback(() => {
    setVisibleCount((prevCount) => {
      if (prevCount >= iconNames.length) return prevCount
      return Math.min(prevCount + ICONS_BY_CHARGE, iconNames.length)
    })
  }, [iconNames.length])

  useEffect(() => {
    const rootElement = rootScrollAreaRef.current
    if (rootElement && !viewportScrollElementRef.current) {
      const viewport = rootElement.querySelector('[data-radix-scroll-area-viewport]')
      viewportScrollElementRef.current = viewport as HTMLElement | null
    }

    const currentViewport = viewportScrollElementRef.current
    if (!currentViewport) return

    const handleScroll = () => {
      const { scrollTop, scrollHeight, clientHeight } = currentViewport
      if (scrollHeight - scrollTop - clientHeight < SCROLL_THRESHOLD) {
        if (visibleCount < iconNames.length) {
          loadMoreIcons()
        }
      }
    }

    currentViewport.addEventListener('scroll', handleScroll)
    return () => {
      currentViewport.removeEventListener('scroll', handleScroll)
    }
  }, [loadMoreIcons, visibleCount, iconNames.length])

  return (
    <ScrollArea ref={rootScrollAreaRef} className={cn('w-full', heightClassName)}>
      <div className="grid grid-cols-6 gap-1 p-1">
        {iconesAtuais.map((iconName) => {
          const Icon = icons[iconName]
          return (
            <div
              key={iconName}
              className={cn(
                'flex cursor-pointer items-center justify-center rounded-md p-2 transition-colors hover:bg-accent',
                selectedIcon === iconName && 'bg-accent ring-2 ring-primary',
              )}
              onClick={() => onIconSelect(iconName)}
              role="button"
              tabIndex={0}
              title={iconName}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') onIconSelect(iconName)
              }}
            >
              <Icon size={20} />
            </div>
          )
        })}
      </div>
      <ScrollBar orientation="vertical" />
    </ScrollArea>
  )
}

export { allIconNames }
