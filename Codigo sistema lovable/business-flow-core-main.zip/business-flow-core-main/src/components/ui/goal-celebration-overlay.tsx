import { useEffect, useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { createPortal } from 'react-dom';
import confetti from 'canvas-confetti';

const BALLOON_COLORS = ['#FF4444', '#4488FF', '#FFDD44', '#44CC44', '#FF66AA', '#AA66FF', '#FF8C00', '#00CED1'];

function BalloonSVG({ color }: { color: string }) {
  return (
    <svg width="40" height="56" viewBox="0 0 40 56" fill="none">
      <ellipse cx="20" cy="20" rx="18" ry="22" fill={color} />
      <ellipse cx="20" cy="20" rx="18" ry="22" fill="white" fillOpacity="0.15" />
      <ellipse cx="14" cy="14" rx="5" ry="7" fill="white" fillOpacity="0.3" />
      <polygon points="16,40 20,44 24,40" fill={color} />
      <line x1="20" y1="44" x2="20" y2="56" stroke={color} strokeWidth="1" opacity="0.6" />
    </svg>
  );
}

interface GoalCelebrationOverlayProps {
  show: boolean;
  onClose: () => void;
  lovedOnePhotoUrl?: string | null;
  lovedOneName?: string | null;
}

export function GoalCelebrationOverlay({ show, onClose, lovedOnePhotoUrl, lovedOneName }: GoalCelebrationOverlayProps) {
  const [balloons] = useState(() =>
    Array.from({ length: 18 }, (_, i) => ({
      id: i,
      x: Math.random() * 90 + 5,
      delay: Math.random() * 2,
      duration: 4 + Math.random() * 3,
      sway: (Math.random() - 0.5) * 60,
      color: BALLOON_COLORS[i % BALLOON_COLORS.length],
      scale: 0.7 + Math.random() * 0.6,
    }))
  );

  const fireConfetti = useCallback(() => {
    const duration = 4000;
    const end = Date.now() + duration;
    const frame = () => {
      confetti({ particleCount: 3, angle: 60, spread: 55, origin: { x: 0 }, colors: ['#FF6A00', '#FFD700', '#FF4444'] });
      confetti({ particleCount: 3, angle: 120, spread: 55, origin: { x: 1 }, colors: ['#FF6A00', '#FFD700', '#4488FF'] });
      if (Date.now() < end) requestAnimationFrame(frame);
    };
    frame();
  }, []);

  useEffect(() => {
    if (!show) return;
    fireConfetti();
    const timer = setTimeout(onClose, 6000);
    return () => clearTimeout(timer);
  }, [show, fireConfetti, onClose]);

  const overlay = (
    <AnimatePresence>
      {show && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.4 }}
          className="fixed inset-0 z-[9999] flex items-center justify-center cursor-pointer"
          onClick={onClose}
          style={{ background: 'radial-gradient(ellipse at center, rgba(0,0,0,0.7) 0%, rgba(0,0,0,0.85) 100%)' }}
        >
          {/* Balloons */}
          {balloons.map((b) => (
            <motion.div
              key={b.id}
              initial={{ y: '110vh', x: `${b.x}vw`, opacity: 0.8 }}
              animate={{
                y: '-20vh',
                x: [`${b.x}vw`, `${b.x + b.sway / 2}vw`, `${b.x}vw`],
                opacity: [0.8, 1, 0.6],
              }}
              transition={{
                duration: b.duration,
                delay: b.delay,
                ease: 'easeOut',
                x: { duration: b.duration, repeat: Infinity, repeatType: 'mirror' },
              }}
              className="absolute"
              style={{ transform: `scale(${b.scale})` }}
            >
              <BalloonSVG color={b.color} />
            </motion.div>
          ))}

          {/* Center content */}
          <motion.div
            initial={{ scale: 0.5, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.3, type: 'spring', stiffness: 200, damping: 15 }}
            className="relative z-10 flex flex-col items-center gap-4 text-center px-6"
          >
            {lovedOnePhotoUrl ? (
              <div className="relative">
                <div className="absolute -inset-2 rounded-full bg-gradient-to-r from-yellow-400 via-amber-500 to-yellow-400 animate-spin" style={{ animationDuration: '3s' }} />
                <img
                  src={lovedOnePhotoUrl}
                  alt={lovedOneName || 'Ente querido'}
                  className="relative w-32 h-32 rounded-full object-cover border-4 border-white shadow-2xl"
                />
              </div>
            ) : (
              <motion.div
                animate={{ scale: [1, 1.1, 1] }}
                transition={{ repeat: Infinity, duration: 1.5 }}
                className="text-6xl"
              >
                🏆
              </motion.div>
            )}

            {lovedOneName && (
              <p className="text-white/90 text-lg font-medium">{lovedOneName}</p>
            )}

            <motion.h2
              animate={{ scale: [1, 1.05, 1] }}
              transition={{ repeat: Infinity, duration: 2 }}
              className="text-2xl md:text-3xl font-bold text-white"
              style={{ textShadow: '0 2px 10px rgba(255,106,0,0.5)' }}
            >
              🎉 Você bateu a meta! 🎉
            </motion.h2>

            {lovedOnePhotoUrl && (
              <p className="text-amber-300 text-base font-medium">
                Faça isso por quem você ama. ❤️
              </p>
            )}

            <p className="text-white/50 text-xs mt-4">Toque para fechar</p>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );

  return createPortal(overlay, document.body);
}
