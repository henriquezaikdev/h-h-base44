"use client";

import * as React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";
import { ChevronLeft, ChevronRight } from "lucide-react";

interface CardData {
  id: string;
  title: string;
  subtitle?: string;
  image: string;
  gradient?: string;
}

interface AnimatedCardStackProps {
  cards?: CardData[];
  autoPlay?: boolean;
  autoPlayInterval?: number;
  className?: string;
}

const defaultCards: CardData[] = [
  {
    id: "1",
    title: "Foco no Cliente",
    subtitle: "Priorize relacionamentos de alto valor",
    image: "https://images.unsplash.com/photo-1556761175-5973dc0f32e7?w=600&h=400&fit=crop",
    gradient: "from-blue-500/20 to-cyan-500/20",
  },
  {
    id: "2",
    title: "Metas Diárias",
    subtitle: "Acompanhe sua evolução em tempo real",
    image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=600&h=400&fit=crop",
    gradient: "from-emerald-500/20 to-teal-500/20",
  },
  {
    id: "3",
    title: "Produtividade",
    subtitle: "Otimize seu tempo e resultados",
    image: "https://images.unsplash.com/photo-1553877522-43269d4ea984?w=600&h=400&fit=crop",
    gradient: "from-violet-500/20 to-purple-500/20",
  },
  {
    id: "4",
    title: "Performance",
    subtitle: "Alcance novos patamares",
    image: "https://images.unsplash.com/photo-1552664730-d307ca884978?w=600&h=400&fit=crop",
    gradient: "from-orange-500/20 to-amber-500/20",
  },
];

export default function AnimatedCardStack({
  cards = defaultCards,
  autoPlay = false,
  autoPlayInterval = 6000,
  className,
}: AnimatedCardStackProps) {
  const [currentIndex, setCurrentIndex] = React.useState(0);
  const [direction, setDirection] = React.useState(0);

  const slideVariants = {
    enter: (direction: number) => ({
      x: direction > 0 ? 300 : -300,
      opacity: 0,
      scale: 0.9,
      rotateY: direction > 0 ? 15 : -15,
    }),
    center: {
      zIndex: 1,
      x: 0,
      opacity: 1,
      scale: 1,
      rotateY: 0,
    },
    exit: (direction: number) => ({
      zIndex: 0,
      x: direction < 0 ? 300 : -300,
      opacity: 0,
      scale: 0.9,
      rotateY: direction < 0 ? 15 : -15,
    }),
  };

  const swipeConfidenceThreshold = 10000;
  const swipePower = (offset: number, velocity: number) => {
    return Math.abs(offset) * velocity;
  };

  const paginate = (newDirection: number) => {
    setDirection(newDirection);
    setCurrentIndex((prevIndex) => {
      let nextIndex = prevIndex + newDirection;
      if (nextIndex < 0) nextIndex = cards.length - 1;
      if (nextIndex >= cards.length) nextIndex = 0;
      return nextIndex;
    });
  };

  // Autoplay
  React.useEffect(() => {
    if (!autoPlay) return;
    const interval = setInterval(() => {
      paginate(1);
    }, autoPlayInterval);
    return () => clearInterval(interval);
  }, [autoPlay, autoPlayInterval, currentIndex]);

  const currentCard = cards[currentIndex];

  return (
    <div className={cn("relative w-full", className)}>
      {/* Main Card Container */}
      <div className="relative h-[180px] sm:h-[200px] w-full perspective-1000">
        {/* Background stacked cards effect */}
        <div className="absolute inset-0 flex items-center justify-center">
          {/* Card -2 (furthest back) */}
          <div className="absolute w-[85%] h-[85%] rounded-2xl bg-card/30 border border-border/30 -translate-y-3 scale-[0.88] blur-[1px]" />
          {/* Card -1 */}
          <div className="absolute w-[92%] h-[92%] rounded-2xl bg-card/50 border border-border/50 -translate-y-1.5 scale-[0.94]" />
        </div>

        {/* Main animated card */}
        <AnimatePresence initial={false} custom={direction} mode="wait">
          <motion.div
            key={currentIndex}
            custom={direction}
            variants={slideVariants}
            initial="enter"
            animate="center"
            exit="exit"
            transition={{
              x: { type: "spring", stiffness: 200, damping: 35 },
              opacity: { duration: 0.4 },
              scale: { duration: 0.5 },
              rotateY: { duration: 0.5 },
            }}
            drag="x"
            dragConstraints={{ left: 0, right: 0 }}
            dragElastic={1}
            onDragEnd={(e, { offset, velocity }) => {
              const swipe = swipePower(offset.x, velocity.x);

              if (swipe < -swipeConfidenceThreshold) {
                paginate(1);
              } else if (swipe > swipeConfidenceThreshold) {
                paginate(-1);
              }
            }}
            className="absolute inset-0 cursor-grab active:cursor-grabbing"
          >
            <div
              className={cn(
                "relative h-full w-full rounded-2xl overflow-hidden",
                "bg-gradient-to-br border border-border/50",
                "shadow-lg shadow-black/5 dark:shadow-black/20",
                currentCard.gradient
              )}
            >
              {/* Background image with overlay */}
              <div className="absolute inset-0">
                <img
                  src={currentCard.image}
                  alt={currentCard.title}
                  className="w-full h-full object-cover opacity-20"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-background/50 to-transparent" />
              </div>

              {/* Content */}
              <div className="relative z-10 h-full flex flex-col justify-end p-5 sm:p-6">
                <motion.h3
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 }}
                  className="text-lg sm:text-xl font-semibold text-foreground"
                >
                  {currentCard.title}
                </motion.h3>
                {currentCard.subtitle && (
                  <motion.p
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.2 }}
                    className="text-sm text-muted-foreground mt-1"
                  >
                    {currentCard.subtitle}
                  </motion.p>
                )}
              </div>

              {/* Decorative gradient orb */}
              <div className="absolute top-4 right-4 w-20 h-20 rounded-full bg-gradient-to-br from-primary/30 to-primary/5 blur-2xl pointer-events-none" />
            </div>
          </motion.div>
        </AnimatePresence>

        {/* Navigation arrows */}
        <button
          onClick={() => paginate(-1)}
          className="absolute left-2 top-1/2 -translate-y-1/2 z-20 p-1.5 rounded-full bg-background/80 backdrop-blur-sm border border-border/50 shadow-sm hover:bg-accent transition-colors"
          aria-label="Previous card"
        >
          <ChevronLeft className="h-4 w-4 text-foreground" />
        </button>
        <button
          onClick={() => paginate(1)}
          className="absolute right-2 top-1/2 -translate-y-1/2 z-20 p-1.5 rounded-full bg-background/80 backdrop-blur-sm border border-border/50 shadow-sm hover:bg-accent transition-colors"
          aria-label="Next card"
        >
          <ChevronRight className="h-4 w-4 text-foreground" />
        </button>
      </div>

      {/* Pagination dots */}
      <div className="flex justify-center gap-1.5 mt-3">
        {cards.map((_, index) => (
          <button
            key={index}
            onClick={() => {
              setDirection(index > currentIndex ? 1 : -1);
              setCurrentIndex(index);
            }}
            className={cn(
              "w-1.5 h-1.5 rounded-full transition-all duration-300",
              index === currentIndex
                ? "w-4 bg-primary"
                : "bg-muted-foreground/30 hover:bg-muted-foreground/50"
            )}
            aria-label={`Go to card ${index + 1}`}
          />
        ))}
      </div>
    </div>
  );
}

export { AnimatedCardStack };
export type { CardData, AnimatedCardStackProps };
