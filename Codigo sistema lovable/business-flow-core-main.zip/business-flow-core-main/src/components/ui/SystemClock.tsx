import { useState, useEffect } from 'react';
import { Clock } from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export function SystemClock() {
  const [now, setNow] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-muted/50 border border-border/50">
      <Clock className="h-3.5 w-3.5 text-violet-500" />
      <span className="text-xs font-medium text-muted-foreground">
        {format(now, "dd/MM/yyyy HH:mm:ss", { locale: ptBR })}
      </span>
    </div>
  );
}
