import { useState, useEffect, memo, useRef } from "react";
import { Outlet } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { Navigate } from "react-router-dom";
import { Layout } from "./Layout";
import { ErrorBoundary } from "@/components/ErrorBoundary";
import { ChangePasswordModal } from "@/components/auth/ChangePasswordModal";
import { PermissionGuard } from "@/components/PermissionGuard";
import { AcknowledgementModal } from "@/components/hr/AcknowledgementModal";
import { useHRActions } from "@/hooks/useHRActions";
import { useSellerDepartment } from "@/hooks/useSellerDepartment";
import { supabase } from "@/integrations/supabase/client";

// Memoized inner content to prevent re-renders from parent state changes
const ProtectedContent = memo(function ProtectedContent() {
  return (
    <ErrorBoundary>
      <PermissionGuard>
        <Outlet />
      </PermissionGuard>
    </ErrorBoundary>
  );
});

// Memoized layout wrapper - prevents remount on minor App.tsx state updates
export const ProtectedLayout = memo(function ProtectedLayout() {
  const { user, loading } = useAuth();
  const [mustChangePassword, setMustChangePassword] = useState(false);
  const [checkingPassword, setCheckingPassword] = useState(true);
  const { pendingAck, acknowledgeAction } = useHRActions();
  const { department } = useSellerDepartment();
  const isEntregador = department === 'entregas';
  
  // HOTFIX CRÍTICO: Rastrear se o layout já foi renderizado uma vez
  // Após primeira renderização bem-sucedida, NUNCA mais mostrar spinner que desmonta UI
  const hasRenderedOnceRef = useRef(false);

  useEffect(() => {
    const checkPasswordChange = async () => {
      if (!user) {
        setCheckingPassword(false);
        return;
      }

      // Verificar se o usuário precisa trocar a senha
      const mustChange = user.user_metadata?.must_change_password === true;
      setMustChangePassword(mustChange);
      setCheckingPassword(false);
    };

    checkPasswordChange();
  }, [user]);

  const handlePasswordChanged = async () => {
    // Recarregar dados do usuário para atualizar o metadata
    const { data } = await supabase.auth.refreshSession();
    if (data.user) {
      setMustChangePassword(data.user.user_metadata?.must_change_password === true);
    } else {
      setMustChangePassword(false);
    }
  };

  // HOTFIX CRÍTICO: Só mostrar spinner no bootstrap INICIAL
  // Se já renderizou uma vez E tem user, NUNCA desmontar a UI por loading/checkingPassword
  const isInitialBootstrap = !hasRenderedOnceRef.current;
  const shouldShowInitialSpinner = isInitialBootstrap && (loading || checkingPassword);
  
  // Marcar que já renderizou quando temos user e não está mais loading
  useEffect(() => {
    if (user && !loading && !checkingPassword && !hasRenderedOnceRef.current) {
      hasRenderedOnceRef.current = true;
    }
  }, [user, loading, checkingPassword]);

  // Spinner APENAS no bootstrap inicial (primeira vez carregando o app)
  if (shouldShowInitialSpinner) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </div>
    );
  }

  // Redirect para auth APENAS se não tem user E não está no bootstrap inicial
  // Isso evita redirect falso durante eventos transientes de foco
  if (!user && !loading) {
    return <Navigate to="/auth" replace />;
  }

  // LAYOUT LOCK ABSOLUTO: Após bootstrap, SEMPRE renderizar Layout
  // Mesmo se loading/checkingPassword mudar por eventos de foco, UI permanece estável
  // Isso elimina o remount que estava destruindo formulários
  // Entregador gets a chromeless layout (no topbar/sidebar)
  if (isEntregador) {
    return (
      <div className="min-h-screen bg-background">
        <ProtectedContent />
        <ChangePasswordModal open={mustChangePassword} onSuccess={handlePasswordChanged} />
      </div>
    );
  }

  return (
    <Layout>
      <ProtectedContent />
      
      <ChangePasswordModal 
        open={mustChangePassword} 
        onSuccess={handlePasswordChanged}
      />

      <AcknowledgementModal
        pendingActions={pendingAck}
        onAcknowledge={acknowledgeAction}
      />
    </Layout>
  );
});
