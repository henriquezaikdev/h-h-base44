import { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useSidebarContext } from '@/contexts/SidebarContext';
import {
  Zap,
  LayoutDashboard,
  Users,
  BarChart3,
  Settings,
  ChevronLeft,
  ChevronRight,
  ChevronDown,
  LogOut,
  User,
  ShoppingCart,
  Package,
  Crown,
  Landmark,
  ShoppingBag,
  RefreshCw,
  Briefcase,
  Truck,
  UserCog,
  MessageSquare,
  Rss,
} from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { usePermissions } from '@/hooks/usePermissions';
import { useSellerDepartment } from '@/hooks/useSellerDepartment';
import logoHH from '@/assets/logo-hh.png';
import { cn, OWNER_EMAIL } from '@/lib/utils';

const ROUTE_TO_RESOURCE: Record<string, string> = {
  '/': 'actionCenter.page',
  '/dashboard': 'dashboard.page',
  '/clients': 'clients.page',
  '/orders': 'orders.page',
  '/products': 'products.page',
  '/evolucao-vendedor': 'sellerEvolution.page',
  '/orcamentos': 'quotes.page',
  '/relatorios': 'reports.page',
  '/settings': 'settings.page',
  '/import': 'import.page',
  '/import-quote': 'importQuote.page',
  '/gestor': 'gestor.page',
};

// IDs da Anna Cristina (admin com acesso a RH)
const ANNA_SELLER_IDS = ['2be02843-4f03-46be-bd64-0f02bc53f2a0', '53280181-1118-4e9a-9e00-9d807d070f9c'];

type MenuItem = {
  path: string;
  icon: typeof Zap;
  label: string;
  highlight?: boolean;
  ownerOnly?: boolean;
  rhOnly?: boolean;
};

type MenuCategory = {
  key: string;
  icon: typeof Zap;
  label: string;
  items: MenuItem[];
};

export function Sidebar() {
  const { collapsed, setCollapsed } = useSidebarContext();
  const location = useLocation();
  const navigate = useNavigate();
  const { user, seller, signOut, isOwner, isAdmin, loading: authLoading } = useAuth();
  const { hasPermission, loading: permissionsLoading, isVendedor } = usePermissions();
  const { department } = useSellerDepartment();
  const isAdministrativo = department === 'financeiro_gestora' || department === 'logistica';

  const handleLogout = async () => {
    await signOut();
    navigate('/auth');
  };

  const isExclusiveOwner = user?.email === OWNER_EMAIL;
  const isAnna = seller?.id ? ANNA_SELLER_IDS.includes(seller.id) : false;
  const canSeeRH = isExclusiveOwner || isOwner || isAnna;

  // Rotas que SEMPRE devem ser visíveis para todos os usuários
  const ALWAYS_VISIBLE_PATHS = ['/', '/regras-xp', '/mural'];

  const canSeeItem = (item: MenuItem) => {
    if (ALWAYS_VISIBLE_PATHS.includes(item.path)) return true;
    if (item.rhOnly) return canSeeRH;
    if (item.ownerOnly) return isExclusiveOwner || isOwner;
    if (isOwner) return true;
    if (authLoading || permissionsLoading) return true;
    const resourceKey = ROUTE_TO_RESOURCE[item.path];
    if (!resourceKey) return true;
    return hasPermission(resourceKey, 'view');
  };

  // ── Main nav items ──
  const mainItems: MenuItem[] = [
    { path: '/', icon: Zap, label: 'Meu Dia' },
    { path: '/dashboard', icon: LayoutDashboard, label: 'Visão Geral' },
    ...(!isAdministrativo ? [{ path: '/clients', icon: Users, label: 'Clientes' }] : []),
    { path: '/orders', icon: ShoppingCart, label: 'Pedidos' },
    { path: '/products', icon: Package, label: 'Produtos' },
    { path: '/relatorios', icon: BarChart3, label: 'Relatórios' },
    { path: '/mural', icon: MessageSquare, label: 'Mural' },
  ];

  // ── Category groups ──
  const adminCategory: MenuCategory = {
    key: 'administrativo',
    icon: Briefcase,
    label: 'Administrativo',
    items: [
      { path: '/gestor', icon: Crown, label: 'Gestor', ownerOnly: true },
      { path: '/financeiro', icon: Landmark, label: 'Financeiro' },
      { path: '/rh', icon: UserCog, label: 'RH', rhOnly: true },
    ],
  };

  const logisticaCategory: MenuCategory = {
    key: 'logistica',
    icon: Truck,
    label: 'Logística',
    items: [
      { path: '/gestao-compras', icon: ShoppingBag, label: 'Compras' },
      { path: '/entregas', icon: Truck, label: 'Entregas' },
    ],
  };

  // ── "Mais" group ──
  const maisItems: MenuItem[] = [
    { path: '/sincronizacoes', icon: RefreshCw, label: 'Sincronizações' },
    { path: '/settings', icon: Settings, label: 'Configurações' },
  ];

  const filteredMain = mainItems.filter(canSeeItem);

  const filterCategory = (cat: MenuCategory) => {
    const filtered = cat.items.filter(canSeeItem);
    return filtered.length > 0 ? { ...cat, items: filtered } : null;
  };

  const adminCat = filterCategory(adminCategory);
  const logisticaCat = filterCategory(logisticaCategory);
  const filteredMais = maisItems.filter(canSeeItem);
  const showMais = filteredMais.length > 0;

  // Category open states
  const [adminOpen, setAdminOpen] = useState(() =>
    adminCategory.items.some(i => location.pathname.startsWith(i.path))
  );
  const [logisticaOpen, setLogisticaOpen] = useState(() =>
    logisticaCategory.items.some(i => location.pathname.startsWith(i.path))
  );

  const maisPaths = filteredMais.map(i => i.path);
  const [maisOpen, setMaisOpen] = useState(() => maisPaths.some(p => location.pathname.startsWith(p)));
  const isMaisActive = maisPaths.some(p => p === '/' ? location.pathname === '/' : location.pathname.startsWith(p));

  const isLoading = authLoading || permissionsLoading;

  const isCategoryActive = (cat: MenuCategory) =>
    cat.items.some(i => location.pathname.startsWith(i.path));

  const renderMenuItem = (item: MenuItem, isSubItem = false) => {
    const isActive = location.pathname === item.path;
    const isHighlight = item.highlight;
    const isOwnerItem = item.ownerOnly;
    
    return (
      <Link
        key={item.path}
        to={item.path}
        className={cn(
          'sidebar-item',
          isActive && 'active',
          collapsed && 'justify-center px-0',
          isSubItem && !collapsed && 'pl-10 text-sm',
          isHighlight && !isActive && 'bg-amber-600/20 text-amber-400 hover:bg-amber-600/30 hover:text-amber-300 border border-amber-500/30',
          isOwnerItem && !isActive && 'bg-gradient-to-r from-amber-500/10 to-orange-500/10 text-amber-300 hover:from-amber-500/20 hover:to-orange-500/20 border border-amber-500/20'
        )}
        title={collapsed ? item.label : undefined}
      >
        <item.icon size={isSubItem ? 16 : 20} className={cn(
          isHighlight && !isActive && 'text-amber-400',
          isOwnerItem && !isActive && 'text-amber-300'
        )} />
        {!collapsed && <span>{item.label}</span>}
      </Link>
    );
  };

  const renderCategoryGroup = (cat: MenuCategory, isOpen: boolean, toggle: () => void) => {
    const hasActive = isCategoryActive(cat);
    const Icon = cat.icon;
    return (
      <div key={cat.key}>
        <button
          onClick={toggle}
          className={cn(
            'sidebar-item w-full',
            hasActive && 'text-primary',
            collapsed && 'justify-center px-0',
          )}
          title={collapsed ? cat.label : undefined}
        >
          <Icon size={20} />
          {!collapsed && (
            <>
              <span className="flex-1 text-left">{cat.label}</span>
              <ChevronDown size={14} className={cn('transition-transform', isOpen && 'rotate-180')} />
            </>
          )}
        </button>
        {(isOpen || collapsed) && (
          <div className={cn('space-y-0.5', !collapsed && 'mt-0.5')}>
            {cat.items.map(item => renderMenuItem(item, !collapsed))}
          </div>
        )}
      </div>
    );
  };

  const renderGroupToggle = (label: string, icon: React.ElementType, isOpen: boolean, toggle: () => void, hasActive: boolean) => {
    const Icon = icon;
    return (
      <button
        onClick={toggle}
        className={cn(
          'sidebar-item w-full',
          hasActive && 'text-primary',
          collapsed && 'justify-center px-0',
        )}
        title={collapsed ? label : undefined}
      >
        <Icon size={20} />
        {!collapsed && (
          <>
            <span className="flex-1 text-left">{label}</span>
            <ChevronDown size={14} className={cn('transition-transform', isOpen && 'rotate-180')} />
          </>
        )}
      </button>
    );
  };

  return (
    <aside
      className={`fixed left-0 top-0 h-screen bg-sidebar flex flex-col transition-all duration-300 z-50 ${
        collapsed ? 'w-20' : 'w-64'
      }`}
    >
      {/* Logo Area */}
      <div className="h-20 flex items-center justify-center border-b border-sidebar-border px-4">
        {collapsed ? (
          <img src={logoHH} alt="H&H" className="w-10 h-10 object-contain rounded-lg" />
        ) : (
          <img src={logoHH} alt="H&H Suprimentos Corporativos" className="h-14 object-contain rounded-lg" />
        )}
      </div>

      {/* Navigation */}
      <nav className="flex-1 py-6 px-3 space-y-1 overflow-y-auto">
        {isLoading ? (
          Array.from({ length: 8 }).map((_, i) => (
            <div 
              key={i} 
              className={`h-10 rounded-lg bg-sidebar-accent/30 animate-pulse ${
                collapsed ? 'w-12 mx-auto' : 'w-full'
              }`} 
            />
          ))
        ) : (
          <>
            {filteredMain.map((item) => renderMenuItem(item))}

            {/* Categoria: Administrativo */}
            {adminCat && renderCategoryGroup(adminCat, adminOpen, () => setAdminOpen(!adminOpen))}

            {/* Categoria: Logística */}
            {logisticaCat && renderCategoryGroup(logisticaCat, logisticaOpen, () => setLogisticaOpen(!logisticaOpen))}

            {/* Grupo Mais */}
            {showMais && (
              <div>
                {renderGroupToggle('Mais', Settings, maisOpen, () => setMaisOpen(!maisOpen), isMaisActive)}
                {(maisOpen || collapsed) && (
                  <div className={cn('space-y-0.5', !collapsed && 'mt-0.5')}>
                    {filteredMais.map(item => renderMenuItem(item, !collapsed))}
                  </div>
                )}
              </div>
            )}
          </>
        )}
      </nav>

      {/* User Info & Logout */}
      <div className="p-3 border-t border-sidebar-border space-y-2">
        {seller && !collapsed && (
          <div className="flex items-center gap-3 px-3 py-2">
            <div className="w-8 h-8 bg-primary/20 rounded-full flex items-center justify-center">
              <User size={16} className="text-primary" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-sidebar-foreground truncate">
                {seller.name}
              </p>
              <p className="text-xs text-sidebar-foreground/60 truncate">
                {seller.role === 'admin' ? 'Administrador' : 'Vendedor'}
              </p>
            </div>
          </div>
        )}

        <button
          onClick={handleLogout}
          className={`w-full flex items-center gap-3 px-4 py-2.5 text-sidebar-foreground/70 hover:bg-destructive/10 hover:text-destructive rounded-lg transition-colors ${
            collapsed ? 'justify-center px-0' : ''
          }`}
          title={collapsed ? 'Sair' : undefined}
        >
          <LogOut size={18} />
          {!collapsed && <span className="text-sm">Sair</span>}
        </button>

        <button
          onClick={() => setCollapsed(!collapsed)}
          className={`w-full flex items-center gap-2 py-2 text-sidebar-foreground/50 hover:text-sidebar-foreground transition-colors ${
            collapsed ? 'justify-center' : 'justify-center'
          }`}
        >
          {collapsed ? <ChevronRight size={18} /> : <ChevronLeft size={18} />}
          {!collapsed && <span className="text-xs">Recolher</span>}
        </button>
      </div>
    </aside>
  );
}
