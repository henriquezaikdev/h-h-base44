import { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { usePermissions } from '@/hooks/usePermissions';
import { useSellerDepartment } from '@/hooks/useSellerDepartment';
import { ThemeToggle } from '@/components/ThemeToggle';
import { cn, OWNER_EMAIL } from '@/lib/utils';
import logoHH from '@/assets/logo-hh.png';
import {
  Zap, User, LayoutDashboard, Users, ShoppingCart,
  Package, FileText, Crown, MoreHorizontal,
  FileUp, Settings, LogOut, Menu, X, ShoppingBag,
  Landmark, RefreshCw, ChevronDown, Truck, BarChart3, Rss,
} from 'lucide-react';
import {
  DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuLabel,
} from '@/components/ui/dropdown-menu';
import {
  Drawer, DrawerTrigger, DrawerContent, DrawerHeader, DrawerTitle, DrawerClose,
} from '@/components/ui/drawer';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';

const ROUTE_TO_RESOURCE: Record<string, string> = {
  '/': 'actionCenter.page',
  '/dashboard': 'dashboard.page',
  '/clients': 'clients.page',
  '/orders': 'orders.page',
  '/products': 'products.page',
  '/evolucao-vendedor': 'sellerEvolution.page',
  '/orcamentos': 'quotes.page',
  '/relatorios': 'reports.page',
  '/settings': 'settings.page',
  '/import': 'import.page',
  '/import-quote': 'importQuote.page',
  '/gestor': 'gestor.page',
  
};

type NavItem = {
  path: string;
  icon: typeof Zap;
  label: string;
  ownerOnly?: boolean;
};

const pillBase = 'flex items-center gap-1.5 px-3.5 py-2 text-[13px] font-medium rounded-md transition-all duration-200 whitespace-nowrap';
const pillActive = 'bg-primary/10 text-primary border border-primary/20';
const pillInactive = 'text-muted-foreground hover:text-foreground hover:bg-muted border border-transparent';

export function Topbar() {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, seller, signOut, isOwner, isAdmin, loading: authLoading } = useAuth();
  const { hasPermission, loading: permissionsLoading } = usePermissions();
  const [mobileOpen, setMobileOpen] = useState(false);
  const { department } = useSellerDepartment();
  const isAdministrativo = department === 'financeiro_gestora' || department === 'logistica';

  const isExclusiveOwner = user?.email === OWNER_EMAIL;

  // Rotas que SEMPRE devem ser visíveis para todos os usuários
  const ALWAYS_VISIBLE_PATHS = ['/', '/regras-xp', '/mural'];

  const canSee = (path: string, ownerOnly?: boolean) => {
    if (ALWAYS_VISIBLE_PATHS.includes(path)) return true;
    if (ownerOnly) return isExclusiveOwner || isOwner;
    if (isOwner) return true;
    if (authLoading || permissionsLoading) return true;
    const resourceKey = ROUTE_TO_RESOURCE[path];
    if (!resourceKey) return true;
    return hasPermission(resourceKey, 'view');
  };

  const handleLogout = async () => {
    await signOut();
    navigate('/auth');
  };

  const initials = seller?.name?.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase() || 'U';

  // ── 5 Main Items (always visible as pills) ──
  const mainItems: NavItem[] = [
    { path: '/', icon: Zap, label: 'Meu Dia' },
    { path: '/dashboard', icon: LayoutDashboard, label: 'Visão Geral' },
    ...(!isAdministrativo ? [{ path: '/clients', icon: Users, label: 'Clientes' }] : []),
    
    // Pedidos is now rendered as a dropdown separately
  ];

  // ── Pedidos dropdown items ──
  const pedidosItems: NavItem[] = [
    { path: '/orders', icon: ShoppingCart, label: 'Pedidos' },
    { path: '/products', icon: Package, label: 'Produtos' },
    { path: '/orcamentos', icon: FileText, label: 'Orçamentos' },
  ];

  // ── "... Mais" Dropdown (everything else) ──
  const maisItems: NavItem[] = [
    { path: '/estoque-compras', icon: Package, label: 'Estoque & Reposição' },
    { path: '/relatorios', icon: BarChart3, label: 'Relatórios' },
    { path: '/rh', icon: Users, label: 'RH', ownerOnly: true },
    { path: '/sincronizacoes', icon: RefreshCw, label: 'Sincronizações' },
    { path: '/financeiro', icon: Landmark, label: 'Financeiro', ownerOnly: true },
    { path: '/gestor', icon: Crown, label: 'Gestor', ownerOnly: true },
    
    { path: '/settings', icon: Settings, label: 'Configurações' },
  ];

  const renderPill = (item: NavItem) => {
    if (!canSee(item.path, item.ownerOnly)) return null;
    const active = item.path === '/' ? location.pathname === '/' : location.pathname.startsWith(item.path);
    return (
      <Link
        key={item.path}
        to={item.path}
        className={cn(pillBase, active ? pillActive : pillInactive)}
      >
        <item.icon size={15} />
        <span className="hidden lg:inline">{item.label}</span>
      </Link>
    );
  };

  const filteredPedidos = pedidosItems.filter(i => canSee(i.path, i.ownerOnly));
  const pedidosActive = filteredPedidos.some(i => location.pathname.startsWith(i.path));

  const filteredMais = maisItems.filter(i => canSee(i.path, i.ownerOnly));
  const maisActive = filteredMais.some(i => i.path === '/' ? location.pathname === '/' : location.pathname.startsWith(i.path));

  const allMobileItems: { section: string; items: NavItem[] }[] = [
    { section: 'Principal', items: [...mainItems, { path: '/gestao-compras', icon: ShoppingBag, label: 'Compras' }, { path: '/entregas', icon: Truck, label: 'Entregas' }] },
    { section: 'Pedidos & Produtos', items: pedidosItems },
    { section: 'Mais', items: maisItems },
  ];

  return (
    <header className="fixed top-0 left-0 right-0 z-50 h-14 bg-card border-b border-border flex items-center px-3 md:px-5 gap-3 shadow-hh-sm">
      <div className="flex items-center shrink-0">
        <img src={logoHH} alt="H&H" className="w-8 h-8 object-contain rounded-md" />
      </div>

      <nav className="hidden md:flex items-center gap-1 flex-1 justify-center overflow-x-auto scrollbar-hide">
        {mainItems.filter(i => canSee(i.path, i.ownerOnly)).map(renderPill)}

        {/* Pedidos dropdown */}
        {filteredPedidos.length > 0 && (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className={cn(pillBase, pedidosActive ? pillActive : pillInactive, 'cursor-pointer')}>
                <ShoppingCart size={15} />
                <span className="hidden lg:inline">Pedidos</span>
                <ChevronDown size={12} className="ml-0.5 opacity-60" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="min-w-[200px]">
              {filteredPedidos.map(item => (
                <DropdownMenuItem key={item.path} onClick={() => navigate(item.path)} className="cursor-pointer gap-2">
                  <item.icon size={15} />
                  {item.label}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
        )}

        {/* Compras pill */}
        {canSee('/gestao-compras') && renderPill({ path: '/gestao-compras', icon: ShoppingBag, label: 'Compras' })}

        {/* Entregas pill */}
        {canSee('/entregas') && renderPill({ path: '/entregas', icon: Truck, label: 'Entregas' })}

        {/* ... Mais dropdown */}
        {filteredMais.length > 0 && (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className={cn(pillBase, maisActive ? pillActive : pillInactive, 'cursor-pointer')}>
                <MoreHorizontal size={15} />
                <span className="hidden lg:inline">Mais</span>
                <ChevronDown size={12} className="ml-0.5 opacity-60" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="min-w-[200px]">
              {filteredMais.map(item => (
                <DropdownMenuItem key={item.path} onClick={() => navigate(item.path)} className="cursor-pointer gap-2">
                  <item.icon size={15} />
                  {item.label}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
        )}
      </nav>

      <div className="flex items-center gap-2 shrink-0 ml-auto">
        <ThemeToggle />

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="hidden md:flex items-center gap-2 px-2 py-1.5 rounded-md hover:bg-muted transition-colors">
              <Avatar className="h-7 w-7">
                <AvatarFallback className="text-xs bg-primary/10 text-primary font-semibold">
                  {initials}
                </AvatarFallback>
              </Avatar>
              {seller && (
                <span className="hidden xl:block text-xs font-medium text-foreground truncate max-w-[100px]">
                  {seller.name?.split(' ')[0]}
                </span>
              )}
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="min-w-[180px]">
            {seller && (
              <>
                <DropdownMenuLabel className="font-normal">
                  <div className="flex flex-col gap-0.5">
                    <p className="text-sm font-medium">{seller.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {seller.role === 'admin' ? 'Administrador' : 'Vendedor'}
                    </p>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
              </>
            )}
            <DropdownMenuItem onClick={() => navigate('/perfil')} className="cursor-pointer gap-2">
              <User size={15} /> Perfil
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={handleLogout} className="cursor-pointer gap-2 text-destructive focus:text-destructive">
              <LogOut size={15} /> Sair
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        <Drawer direction="right" open={mobileOpen} onOpenChange={setMobileOpen}>
          <DrawerTrigger asChild>
            <button className="md:hidden p-2 rounded-md hover:bg-muted transition-colors">
              <Menu size={22} />
            </button>
          </DrawerTrigger>
          <DrawerContent className="fixed inset-y-0 right-0 left-auto w-72 rounded-none rounded-l-xl">
            <DrawerHeader className="border-b border-border pb-3">
              <div className="flex items-center justify-between">
                <DrawerTitle className="text-base">Menu</DrawerTitle>
                <DrawerClose asChild>
                  <button className="p-1.5 rounded-md hover:bg-muted">
                    <X size={18} />
                  </button>
                </DrawerClose>
              </div>
              {seller && (
                <div className="flex items-center gap-3 mt-3">
                  <Avatar className="h-9 w-9">
                    <AvatarFallback className="text-xs bg-primary/10 text-primary font-semibold">
                      {initials}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="text-sm font-medium">{seller.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {seller.role === 'admin' ? 'Administrador' : 'Vendedor'}
                    </p>
                  </div>
                </div>
              )}
            </DrawerHeader>
            <div className="flex-1 overflow-y-auto py-3 px-2">
              {allMobileItems.map((section) => {
                const visible = section.items.filter(i => canSee(i.path, i.ownerOnly));
                if (visible.length === 0) return null;
                return (
                  <div key={section.section} className="mb-4">
                    <p className="px-3 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground/70 mb-1.5">
                      {section.section}
                    </p>
                    <div className="space-y-0.5">
                      {visible.map(item => {
                        const active = item.path === '/' ? location.pathname === '/' : location.pathname.startsWith(item.path);
                        return (
                          <Link
                            key={item.path}
                            to={item.path}
                            onClick={() => setMobileOpen(false)}
                            className={cn(
                              'flex items-center gap-3 px-3 py-2.5 rounded-md text-sm transition-colors',
                              active ? 'bg-primary/10 text-primary font-semibold' : 'text-foreground hover:bg-muted'
                            )}
                          >
                            <item.icon size={18} />
                            {item.label}
                          </Link>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
            <div className="p-3 border-t border-border">
              <button
                onClick={() => { handleLogout(); setMobileOpen(false); }}
                className="w-full flex items-center gap-3 px-3 py-2.5 rounded-md text-sm text-destructive hover:bg-destructive/10 transition-colors"
              >
                <LogOut size={18} /> Sair
              </button>
            </div>
          </DrawerContent>
        </Drawer>
      </div>
    </header>
  );
}
