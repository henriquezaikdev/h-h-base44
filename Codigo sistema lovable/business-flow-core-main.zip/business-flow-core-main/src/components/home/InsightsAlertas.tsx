import { AlertCircle, TrendingDown, Users, ArrowDown, Gift, Calculator, ChevronRight, Bell, Sparkles, AlertTriangle, Lightbulb } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';
import type { Alerta } from '@/hooks/useHomeData';

interface Props {
  alertas: Alerta[];
}

function getAlertIcon(tipo: Alerta['tipo']) {
  switch (tipo) {
    case 'erro':
      return <AlertCircle className="w-4 h-4" />;
    case 'margem':
      return <TrendingDown className="w-4 h-4" />;
    case 'cliente':
      return <Users className="w-4 h-4" />;
    case 'regressao':
      return <ArrowDown className="w-4 h-4" />;
    case 'premiacao':
      return <Gift className="w-4 h-4" />;
    case 'custo':
      return <Calculator className="w-4 h-4" />;
    default:
      return <AlertCircle className="w-4 h-4" />;
  }
}

function getUrgenciaStyles(urgencia: Alerta['urgencia']) {
  switch (urgencia) {
    case 'alta':
      return {
        bg: 'bg-red-500/10 hover:bg-red-500/15',
        border: 'border-red-500/30 hover:border-red-500/50',
        text: 'text-red-600',
        icon: 'text-red-500'
      };
    case 'media':
      return {
        bg: 'bg-amber-500/10 hover:bg-amber-500/15',
        border: 'border-amber-500/30 hover:border-amber-500/50',
        text: 'text-amber-600',
        icon: 'text-amber-500'
      };
    case 'baixa':
      return {
        bg: 'bg-blue-500/10 hover:bg-blue-500/15',
        border: 'border-blue-500/30 hover:border-blue-500/50',
        text: 'text-blue-600',
        icon: 'text-blue-500'
      };
    default:
      return {
        bg: 'bg-muted/50 hover:bg-muted',
        border: 'border-border/50 hover:border-border',
        text: 'text-muted-foreground',
        icon: 'text-muted-foreground'
      };
  }
}

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.05, delayChildren: 0.5 }
  }
};

const itemVariants = {
  hidden: { opacity: 0, x: -10 },
  visible: { 
    opacity: 1, 
    x: 0,
    transition: { type: "spring" as const, stiffness: 300, damping: 25 }
  }
};

export function InsightsAlertas({ alertas }: Props) {
  if (alertas.length === 0) {
    return (
      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <Lightbulb className="w-5 h-5 text-primary" />
          <h2 className="text-lg font-semibold text-foreground tracking-tight">Insights & Alertas</h2>
        </div>
        <Card className="border border-border/50">
          <CardContent className="p-8">
            <div className="flex flex-col items-center justify-center text-center">
              <div className="p-4 rounded-full bg-emerald-500/10 mb-3">
                <Sparkles className="w-6 h-6 text-emerald-500" />
              </div>
              <p className="text-sm font-medium text-foreground">Tudo em ordem!</p>
              <p className="text-xs text-muted-foreground mt-1">Nenhum alerta no momento</p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <div className="relative">
          <Bell className="w-5 h-5 text-primary" />
          {alertas.some(a => a.urgencia === 'alta') && (
            <motion.div
              className="absolute -top-1 -right-1 w-2 h-2 bg-red-500 rounded-full"
              animate={{ scale: [1, 1.2, 1] }}
              transition={{ duration: 1, repeat: Infinity }}
            />
          )}
        </div>
        <h2 className="text-lg font-semibold text-foreground tracking-tight">Insights & Alertas</h2>
        <span className="text-xs font-medium text-muted-foreground bg-muted px-2 py-0.5 rounded-full">
          {alertas.length}
        </span>
      </div>
      
      <Card className="border border-border/50 overflow-hidden">
        <CardContent className="p-4">
          <motion.div 
            className="space-y-2"
            variants={containerVariants}
            initial="hidden"
            animate="visible"
          >
            {alertas.map((alerta, index) => {
              const styles = getUrgenciaStyles(alerta.urgencia);
              
              const content = (
                <motion.div
                  variants={itemVariants}
                  className={cn(
                    "flex items-start gap-3 p-3 rounded-xl border transition-all duration-200 cursor-pointer group",
                    styles.bg,
                    styles.border
                  )}
                  whileHover={{ scale: 1.01, x: 4 }}
                  transition={{ type: "spring" as const, stiffness: 400 }}
                >
                  <motion.div 
                    className={cn("mt-0.5 p-1.5 rounded-lg", styles.bg)}
                    whileHover={{ rotate: 10 }}
                  >
                    <span className={styles.icon}>
                      {getAlertIcon(alerta.tipo)}
                    </span>
                  </motion.div>
                  <p className={cn("text-sm font-medium flex-1", styles.text)}>
                    {alerta.mensagem}
                  </p>
                  {alerta.link && (
                    <ChevronRight className={cn("w-4 h-4 mt-0.5 flex-shrink-0 transition-transform group-hover:translate-x-1", styles.icon)} />
                  )}
                </motion.div>
              );

              if (alerta.link) {
                return (
                  <Link key={alerta.id} to={alerta.link}>
                    {content}
                  </Link>
                );
              }

              return <div key={alerta.id}>{content}</div>;
            })}
          </motion.div>
        </CardContent>
      </Card>
    </div>
  );
}
