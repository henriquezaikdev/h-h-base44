import { Cake, ChevronRight, PartyPopper, User, Sparkles } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

export interface ClienteBirthday {
  id: string;
  company_name: string;
  birthday_day: number;
  birthday_month: number;
  daysUntil: number;
  seller_name?: string;
  type: 'client' | 'buyer';
  client_id?: string;
}

interface Props {
  clientes: ClienteBirthday[];
}

function getBadgeText(days: number): string {
  if (days === 0) return 'Hoje! 🎂';
  if (days === 1) return 'Amanhã';
  return `Em ${days} dias`;
}

function getBadgeStyle(days: number): string {
  if (days === 0) return 'bg-gradient-to-r from-amber-500 to-orange-500 text-white shadow-lg shadow-amber-500/30';
  if (days === 1) return 'bg-amber-500/20 text-amber-600 border border-amber-500/30';
  return 'bg-muted text-muted-foreground';
}

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.05, delayChildren: 0.4 }
  }
};

const itemVariants = {
  hidden: { opacity: 0, y: 10 },
  visible: { 
    opacity: 1, 
    y: 0,
    transition: { type: "spring" as const, stiffness: 300, damping: 25 }
  }
};

export function AniversariosProximos({ clientes }: Props) {
  if (clientes.length === 0) {
    return null;
  }

  const hasToday = clientes.some(c => c.daysUntil === 0);

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <div className="relative">
          <PartyPopper className="w-5 h-5 text-amber-500" />
          {hasToday && (
            <motion.div
              className="absolute inset-0 bg-amber-500/30 blur-md rounded-full"
              animate={{ scale: [1, 1.3, 1], opacity: [0.5, 0.8, 0.5] }}
              transition={{ duration: 1.5, repeat: Infinity }}
            />
          )}
        </div>
        <h2 className="text-lg font-semibold text-foreground tracking-tight">Aniversários Próximos</h2>
        <span className="text-xs font-medium text-amber-600 bg-amber-500/10 px-2 py-0.5 rounded-full border border-amber-500/20">
          {clientes.length}
        </span>
      </div>
      
      <Card className="relative overflow-hidden border-2 border-amber-500/20 hover:border-amber-500/30 transition-colors">
        <div className="absolute inset-0 bg-gradient-to-br from-amber-500/10 via-orange-500/5 to-pink-500/5" />
        <div className="absolute top-0 right-0 w-40 h-40 bg-amber-500/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
        <CardContent className="relative p-4">
          <motion.div 
            className="space-y-2"
            variants={containerVariants}
            initial="hidden"
            animate="visible"
          >
            {clientes.map((cliente) => {
              const linkTo = cliente.type === 'buyer' && cliente.client_id 
                ? `/clients/${cliente.client_id}` 
                : `/clients/${cliente.id}`;
              
              return (
                <motion.div key={`${cliente.type}-${cliente.id}`} variants={itemVariants}>
                  <Link
                    to={linkTo}
                    className="flex items-center gap-3 p-3 rounded-xl bg-card/80 backdrop-blur-sm border border-amber-500/10 hover:border-amber-500/30 hover:bg-amber-50/50 dark:hover:bg-amber-500/5 transition-all cursor-pointer group"
                  >
                    <motion.div 
                      className={cn(
                        "w-10 h-10 rounded-xl flex items-center justify-center text-white flex-shrink-0 shadow-lg",
                        cliente.type === 'buyer' 
                          ? 'bg-gradient-to-br from-purple-400 to-pink-500 shadow-purple-500/20' 
                          : 'bg-gradient-to-br from-amber-400 to-orange-500 shadow-amber-500/20'
                      )}
                      whileHover={{ scale: 1.1, rotate: 5 }}
                      transition={{ type: "spring" as const, stiffness: 400 }}
                    >
                      {cliente.type === 'buyer' ? <User className="w-5 h-5" /> : <Cake className="w-5 h-5" />}
                    </motion.div>
                    
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-foreground truncate group-hover:text-amber-700 dark:group-hover:text-amber-400 transition-colors">
                        {cliente.company_name}
                      </p>
                      <div className="flex items-center gap-1 text-xs text-muted-foreground">
                        <span>{String(cliente.birthday_day).padStart(2, '0')}/{String(cliente.birthday_month).padStart(2, '0')}</span>
                        {cliente.type === 'buyer' && (
                          <span className="text-purple-500 flex items-center gap-0.5">
                            <Sparkles className="w-3 h-3" /> Comprador
                          </span>
                        )}
                        {cliente.seller_name && <span>• {cliente.seller_name}</span>}
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <motion.span 
                        className={cn("text-xs font-semibold px-3 py-1.5 rounded-full", getBadgeStyle(cliente.daysUntil))}
                        whileHover={{ scale: 1.05 }}
                      >
                        {getBadgeText(cliente.daysUntil)}
                      </motion.span>
                      <ChevronRight className="w-4 h-4 text-muted-foreground group-hover:text-amber-500 group-hover:translate-x-1 transition-all" />
                    </div>
                  </Link>
                </motion.div>
              );
            })}
          </motion.div>
        </CardContent>
      </Card>
    </div>
  );
}
