import { DollarSign, Phone, MessageSquare, Users, CheckCircle, AlertTriangle, XCircle, Sparkles, TrendingUp, Zap } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';
import type { PulsoDoDia as PulsoDoDiaType } from '@/hooks/useHomeData';

interface Props {
  data: PulsoDoDiaType;
}

function formatCurrency(value: number): string {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value);
}

function getStatusColor(percent: number): string {
  if (percent >= 100) return 'text-emerald-500';
  if (percent >= 70) return 'text-amber-500';
  return 'text-red-500';
}

function getStatusGradient(percent: number): string {
  if (percent >= 100) return 'from-emerald-500/20 via-emerald-500/10 to-transparent';
  if (percent >= 70) return 'from-amber-500/20 via-amber-500/10 to-transparent';
  return 'from-red-500/20 via-red-500/10 to-transparent';
}

function getStatusBorder(percent: number): string {
  if (percent >= 100) return 'border-emerald-500/30 hover:border-emerald-500/50';
  if (percent >= 70) return 'border-amber-500/30 hover:border-amber-500/50';
  return 'border-red-500/30 hover:border-red-500/50';
}

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 }
  }
};

const cardVariants = {
  hidden: { opacity: 0, y: 20, scale: 0.95 },
  visible: { 
    opacity: 1, 
    y: 0, 
    scale: 1,
    transition: { type: "spring" as const, stiffness: 300, damping: 25 }
  }
};

export function PulsoDoDia({ data }: Props) {
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <div className="relative">
          <Zap className="w-5 h-5 text-primary" />
          <motion.div
            className="absolute inset-0 bg-primary/30 blur-md rounded-full"
            animate={{ scale: [1, 1.2, 1], opacity: [0.5, 0.8, 0.5] }}
            transition={{ duration: 2, repeat: Infinity }}
          />
        </div>
        <h2 className="text-lg font-semibold text-foreground tracking-tight">Pulso do Dia</h2>
      </div>
      
      <motion.div 
        className="grid grid-cols-1 md:grid-cols-3 gap-4"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        {/* Card 1 - Faturamento do Dia */}
        <motion.div variants={cardVariants}>
          <Card className={cn(
            "relative overflow-hidden border-2 transition-all duration-300 group",
            getStatusBorder(data.percentualMeta)
          )}>
            <div className={cn(
              "absolute inset-0 bg-gradient-to-br opacity-50 group-hover:opacity-70 transition-opacity",
              getStatusGradient(data.percentualMeta)
            )} />
            <CardContent className="relative p-5">
              <div className="flex items-start justify-between">
                <div className="space-y-1">
                  <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider flex items-center gap-1.5">
                    <Sparkles className="w-3 h-3" />
                    Faturamento Hoje
                  </p>
                  <motion.p 
                    className="text-[22px] font-semibold text-foreground"
                    initial={{ scale: 0.5, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ delay: 0.2, type: "spring" as const, stiffness: 200 }}
                  >
                    {formatCurrency(data.faturamentoHoje)}
                  </motion.p>
                  <div className="flex items-center gap-2 mt-2">
                    <div className={cn(
                      "h-2 rounded-full bg-muted overflow-hidden flex-1 max-w-24"
                    )}>
                      <motion.div
                        className={cn(
                          "h-full rounded-full",
                          data.percentualMeta >= 100 ? "bg-emerald-500" : 
                          data.percentualMeta >= 70 ? "bg-amber-500" : "bg-red-500"
                        )}
                        initial={{ width: 0 }}
                        animate={{ width: `${Math.min(data.percentualMeta, 100)}%` }}
                        transition={{ delay: 0.5, duration: 0.8, ease: "easeOut" }}
                      />
                    </div>
                    <span className={cn("text-sm font-semibold", getStatusColor(data.percentualMeta))}>
                      {data.percentualMeta.toFixed(0)}%
                    </span>
                  </div>
                </div>
                <motion.div 
                  className={cn(
                    "p-3 rounded-xl",
                    data.percentualMeta >= 100 ? "bg-emerald-500/20" :
                    data.percentualMeta >= 70 ? "bg-amber-500/20" : "bg-red-500/20"
                  )}
                  whileHover={{ scale: 1.1, rotate: 5 }}
                  transition={{ type: "spring" as const, stiffness: 400 }}
                >
                  <DollarSign className={cn("w-6 h-6", getStatusColor(data.percentualMeta))} />
                </motion.div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Card 2 - Atividade Comercial */}
        <motion.div variants={cardVariants}>
          <Card className="relative overflow-hidden border border-border/50 hover:border-primary/30 transition-all duration-300 group">
            <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
            <CardContent className="relative p-5">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Atividade Comercial
                  </p>
                  <div className="mt-3 space-y-3">
                    <motion.div 
                      className="flex items-center gap-3 p-2 rounded-lg bg-muted/50"
                      whileHover={{ x: 4 }}
                      transition={{ type: "spring" as const, stiffness: 400 }}
                    >
                      <div className="p-1.5 rounded-md bg-blue-500/20">
                        <Phone className="w-4 h-4 text-blue-500" />
                      </div>
                      <div>
                        <span className="text-lg font-bold text-foreground">{data.ligacoesHoje}</span>
                        <span className="text-xs text-muted-foreground ml-1.5">ligações</span>
                      </div>
                    </motion.div>
                    <motion.div 
                      className="flex items-center gap-3 p-2 rounded-lg bg-muted/50"
                      whileHover={{ x: 4 }}
                      transition={{ type: "spring" as const, stiffness: 400 }}
                    >
                      <div className="p-1.5 rounded-md bg-emerald-500/20">
                        <MessageSquare className="w-4 h-4 text-emerald-500" />
                      </div>
                      <div>
                        <span className="text-lg font-bold text-foreground">{data.whatsappHoje}</span>
                        <span className="text-xs text-muted-foreground ml-1.5">WhatsApp</span>
                      </div>
                    </motion.div>
                  </div>
                </div>
                <motion.div 
                  className="p-3 rounded-xl bg-muted/50"
                  whileHover={{ scale: 1.1, rotate: -5 }}
                  transition={{ type: "spring" as const, stiffness: 400 }}
                >
                  <Users className="w-6 h-6 text-muted-foreground" />
                </motion.div>
              </div>
              <div className="mt-3 pt-3 border-t border-border/50">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                  <p className="text-xs text-muted-foreground">
                    <span className="font-semibold text-foreground">{data.percentualVendedoresAtivos.toFixed(0)}%</span> do time ativo
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Card 3 - Placar do Dia */}
        <motion.div variants={cardVariants}>
          <Card className="relative overflow-hidden border border-border/50 hover:border-primary/30 transition-all duration-300 group">
            <div className="absolute inset-0 bg-gradient-to-br from-violet-500/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
            <CardContent className="relative p-5">
              <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-4 flex items-center gap-1.5">
                <TrendingUp className="w-3 h-3" />
                Placar do Dia
              </p>
              <div className="space-y-3">
                <motion.div 
                  className="flex items-center justify-between p-2 rounded-lg bg-emerald-500/10 border border-emerald-500/20"
                  whileHover={{ scale: 1.02 }}
                  transition={{ type: "spring" as const, stiffness: 400 }}
                >
                  <div className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-emerald-500" />
                    <span className="text-sm font-medium text-foreground">Em dia</span>
                  </div>
                  <span className="text-lg font-bold text-emerald-500">{data.vendedoresEmDia}</span>
                </motion.div>
                <motion.div 
                  className="flex items-center justify-between p-2 rounded-lg bg-amber-500/10 border border-amber-500/20"
                  whileHover={{ scale: 1.02 }}
                  transition={{ type: "spring" as const, stiffness: 400 }}
                >
                  <div className="flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-amber-500" />
                    <span className="text-sm font-medium text-foreground">Em risco</span>
                  </div>
                  <span className="text-lg font-bold text-amber-500">{data.vendedoresEmRisco}</span>
                </motion.div>
                <motion.div 
                  className="flex items-center justify-between p-2 rounded-lg bg-red-500/10 border border-red-500/20"
                  whileHover={{ scale: 1.02 }}
                  transition={{ type: "spring" as const, stiffness: 400 }}
                >
                  <div className="flex items-center gap-2">
                    <XCircle className="w-4 h-4 text-red-500" />
                    <span className="text-sm font-medium text-foreground">Parados</span>
                  </div>
                  <span className="text-lg font-bold text-red-500">{data.vendedoresParados}</span>
                </motion.div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>
    </div>
  );
}
