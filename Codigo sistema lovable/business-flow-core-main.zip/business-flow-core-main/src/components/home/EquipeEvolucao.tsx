import { Egg, Feather, Bird, Star, Award, Sparkles, Crown, TrendingUp } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';
import type { EquipeEvolucao as EquipeEvolucaoType } from '@/hooks/useHomeData';

interface Props {
  data: EquipeEvolucaoType;
}

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1, delayChildren: 0.3 }
  }
};

const cardVariants = {
  hidden: { opacity: 0, y: 20, scale: 0.95 },
  visible: { 
    opacity: 1, 
    y: 0, 
    scale: 1,
    transition: { type: "spring" as const, stiffness: 300, damping: 25 }
  }
};

const levelConfigs = {
  ovo: {
    icon: Egg,
    gradient: 'from-amber-500/20 via-amber-400/10 to-transparent',
    border: 'border-amber-500/30 hover:border-amber-500/50',
    iconBg: 'bg-gradient-to-br from-amber-400 to-amber-600',
    textColor: 'text-amber-600',
    glow: 'bg-amber-500/20'
  },
  pena: {
    icon: Feather,
    gradient: 'from-blue-500/20 via-blue-400/10 to-transparent',
    border: 'border-blue-500/30 hover:border-blue-500/50',
    iconBg: 'bg-gradient-to-br from-blue-400 to-blue-600',
    textColor: 'text-blue-600',
    glow: 'bg-blue-500/20'
  },
  aguia: {
    icon: Bird,
    gradient: 'from-primary/20 via-primary/10 to-transparent',
    border: 'border-primary/30 hover:border-primary/50',
    iconBg: 'bg-gradient-to-br from-primary to-primary/80',
    textColor: 'text-primary',
    glow: 'bg-primary/20'
  }
};

export function EquipeEvolucao({ data }: Props) {
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <div className="relative">
          <TrendingUp className="w-5 h-5 text-primary" />
          <motion.div
            className="absolute inset-0 bg-primary/30 blur-md rounded-full"
            animate={{ scale: [1, 1.2, 1], opacity: [0.5, 0.8, 0.5] }}
            transition={{ duration: 2, repeat: Infinity, delay: 1 }}
          />
        </div>
        <h2 className="text-lg font-semibold text-foreground tracking-tight">Evolução & Disciplina da Equipe</h2>
      </div>
      
      <motion.div 
        className="grid grid-cols-1 md:grid-cols-3 gap-4"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        {/* Card - Nível Ovo */}
        <motion.div variants={cardVariants}>
          <Card className={cn(
            "relative overflow-hidden border-2 transition-all duration-300 group",
            levelConfigs.ovo.border
          )}>
            <div className={cn(
              "absolute inset-0 bg-gradient-to-br opacity-50 group-hover:opacity-70 transition-opacity",
              levelConfigs.ovo.gradient
            )} />
            <CardContent className="relative p-5">
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <motion.div 
                      className={cn("p-2 rounded-lg", levelConfigs.ovo.iconBg)}
                      whileHover={{ scale: 1.1, rotate: 10 }}
                      transition={{ type: "spring" as const, stiffness: 400 }}
                    >
                      <Egg className="w-4 h-4 text-white" />
                    </motion.div>
                    <p className="text-sm font-semibold text-foreground">Nível Ovo</p>
                  </div>
                  <motion.p 
                    className="text-4xl font-bold text-foreground mt-3"
                    initial={{ scale: 0.5, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ delay: 0.4, type: "spring" as const, stiffness: 200 }}
                  >
                    {data.ovoCount}
                  </motion.p>
                  <p className="text-sm text-muted-foreground">vendedores</p>
                </div>
              </div>
              <div className="mt-4 pt-4 border-t border-amber-500/20">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-emerald-500" />
                  <p className="text-xs text-muted-foreground">
                    <span className="font-bold text-emerald-600">{data.ovoDisciplinaAlta}</span> com disciplina alta
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Card - Nível Pena */}
        <motion.div variants={cardVariants}>
          <Card className={cn(
            "relative overflow-hidden border-2 transition-all duration-300 group",
            levelConfigs.pena.border
          )}>
            <div className={cn(
              "absolute inset-0 bg-gradient-to-br opacity-50 group-hover:opacity-70 transition-opacity",
              levelConfigs.pena.gradient
            )} />
            <CardContent className="relative p-5">
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <motion.div 
                      className={cn("p-2 rounded-lg", levelConfigs.pena.iconBg)}
                      whileHover={{ scale: 1.1, rotate: 10 }}
                      transition={{ type: "spring" as const, stiffness: 400 }}
                    >
                      <Feather className="w-4 h-4 text-white" />
                    </motion.div>
                    <p className="text-sm font-semibold text-foreground">Nível Pena</p>
                  </div>
                  <motion.p 
                    className="text-4xl font-bold text-foreground mt-3"
                    initial={{ scale: 0.5, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ delay: 0.5, type: "spring" as const, stiffness: 200 }}
                  >
                    {data.penaCount}
                  </motion.p>
                  <p className="text-sm text-muted-foreground">vendedores</p>
                </div>
              </div>
              <div className="mt-4 pt-4 border-t border-blue-500/20">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-emerald-500" />
                  <p className="text-xs text-muted-foreground">
                    <span className="font-bold text-emerald-600">{data.penaSequenciaPositiva}</span> em sequência positiva
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Card - Nível Águia */}
        <motion.div variants={cardVariants}>
          <Card className={cn(
            "relative overflow-hidden border-2 transition-all duration-300 group",
            levelConfigs.aguia.border
          )}>
            <div className={cn(
              "absolute inset-0 bg-gradient-to-br opacity-60 group-hover:opacity-80 transition-opacity",
              levelConfigs.aguia.gradient
            )} />
            <div className="absolute top-0 right-0 w-24 h-24 bg-primary/10 rounded-full blur-2xl -translate-y-1/2 translate-x-1/2" />
            <CardContent className="relative p-5">
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <motion.div 
                      className={cn("p-2 rounded-lg", levelConfigs.aguia.iconBg)}
                      whileHover={{ scale: 1.1, rotate: 10 }}
                      transition={{ type: "spring" as const, stiffness: 400 }}
                    >
                      <Bird className="w-4 h-4 text-white" />
                    </motion.div>
                    <p className="text-sm font-semibold text-foreground">Nível Águia</p>
                    <Crown className="w-4 h-4 text-primary" />
                  </div>
                  <motion.p 
                    className="text-4xl font-bold text-foreground mt-3"
                    initial={{ scale: 0.5, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ delay: 0.6, type: "spring" as const, stiffness: 200 }}
                  >
                    {data.aguiaCount}
                  </motion.p>
                  <p className="text-sm text-muted-foreground">vendedores</p>
                </div>
              </div>
              <div className="mt-4 pt-4 border-t border-primary/20">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-3 h-3 text-primary" />
                  <p className="text-xs text-muted-foreground">
                    <span className="font-bold text-primary">{data.aguiaPercentualFaturamento.toFixed(0)}%</span> do faturamento
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>

      {/* Sub-bloco - Sistema de Estrelas */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6, type: "spring" as const, stiffness: 200 }}
      >
        <Card className="relative overflow-hidden border border-border/50 bg-gradient-to-r from-amber-500/5 via-gray-500/5 to-yellow-500/5">
          <CardContent className="p-5">
            <div className="flex items-center justify-between flex-wrap gap-4">
              <div className="flex items-center gap-6">
                {/* Bronze */}
                <motion.div 
                  className="flex items-center gap-2 px-3 py-2 rounded-lg bg-amber-500/10 border border-amber-500/20"
                  whileHover={{ scale: 1.05, y: -2 }}
                  transition={{ type: "spring" as const, stiffness: 400 }}
                >
                  <Star className="w-5 h-5 text-amber-700" fill="currentColor" />
                  <span className="text-lg font-bold text-foreground">{data.totalBronze}</span>
                  <span className="text-xs text-muted-foreground font-medium">Bronze</span>
                </motion.div>
                
                {/* Prata */}
                <motion.div 
                  className="flex items-center gap-2 px-3 py-2 rounded-lg bg-gray-400/10 border border-gray-400/20"
                  whileHover={{ scale: 1.05, y: -2 }}
                  transition={{ type: "spring" as const, stiffness: 400 }}
                >
                  <Star className="w-5 h-5 text-gray-400" fill="currentColor" />
                  <span className="text-lg font-bold text-foreground">{data.totalPrata}</span>
                  <span className="text-xs text-muted-foreground font-medium">Prata</span>
                </motion.div>
                
                {/* Ouro */}
                <motion.div 
                  className="flex items-center gap-2 px-3 py-2 rounded-lg bg-yellow-500/10 border border-yellow-500/20"
                  whileHover={{ scale: 1.05, y: -2 }}
                  transition={{ type: "spring" as const, stiffness: 400 }}
                >
                  <Star className="w-5 h-5 text-yellow-500" fill="currentColor" />
                  <span className="text-lg font-bold text-foreground">{data.totalOuro}</span>
                  <span className="text-xs text-muted-foreground font-medium">Ouro</span>
                </motion.div>
              </div>
              
              {data.vendedorDestaque && (
                <motion.div 
                  className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-primary/10 to-primary/5 border border-primary/20"
                  whileHover={{ scale: 1.02 }}
                  transition={{ type: "spring" as const, stiffness: 400 }}
                >
                  <Award className="w-5 h-5 text-primary" />
                  <span className="text-sm font-semibold text-foreground">{data.vendedorDestaque}</span>
                  <span className="text-xs text-primary font-medium">destaque</span>
                </motion.div>
              )}
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
