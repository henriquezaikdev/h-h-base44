import { TrendingUp, TrendingDown, Minus, Target, Percent, Wallet, Sparkles, ArrowUpRight, BarChart3, Calendar } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';
import type { PerformanceMes as PerformanceMesType } from '@/hooks/useHomeData';

interface Props {
  data: PerformanceMesType;
}

function formatCurrency(value: number): string {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value);
}

function getTendenciaIcon(tendencia: 'subindo' | 'estavel' | 'caindo') {
  switch (tendencia) {
    case 'subindo':
      return <TrendingUp className="w-4 h-4 text-emerald-500" />;
    case 'caindo':
      return <TrendingDown className="w-4 h-4 text-red-500" />;
    default:
      return <Minus className="w-4 h-4 text-muted-foreground" />;
  }
}

function getTendenciaText(tendencia: 'subindo' | 'estavel' | 'caindo') {
  switch (tendencia) {
    case 'subindo':
      return 'Subindo';
    case 'caindo':
      return 'Caindo';
    default:
      return 'Estável';
  }
}

function getTendenciaBg(tendencia: 'subindo' | 'estavel' | 'caindo') {
  switch (tendencia) {
    case 'subindo':
      return 'bg-emerald-500/10 border-emerald-500/20';
    case 'caindo':
      return 'bg-red-500/10 border-red-500/20';
    default:
      return 'bg-muted/50 border-border/50';
  }
}

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1, delayChildren: 0.2 }
  }
};

const cardVariants = {
  hidden: { opacity: 0, y: 20, scale: 0.95 },
  visible: { 
    opacity: 1, 
    y: 0, 
    scale: 1,
    transition: { type: "spring" as const, stiffness: 300, damping: 25 }
  }
};

export function PerformanceMes({ data }: Props) {
  const percentColor = data.percentualMeta >= 80 ? 'text-emerald-500' : 
                       data.percentualMeta >= 50 ? 'text-amber-500' : 'text-red-500';
  
  const percentBg = data.percentualMeta >= 80 ? 'bg-emerald-500' : 
                    data.percentualMeta >= 50 ? 'bg-amber-500' : 'bg-red-500';

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <div className="relative">
          <BarChart3 className="w-5 h-5 text-primary" />
          <motion.div
            className="absolute inset-0 bg-primary/30 blur-md rounded-full"
            animate={{ scale: [1, 1.2, 1], opacity: [0.5, 0.8, 0.5] }}
            transition={{ duration: 2, repeat: Infinity, delay: 0.5 }}
          />
        </div>
        <h2 className="text-lg font-semibold text-foreground tracking-tight">Performance do Mês</h2>
      </div>
      
      <motion.div 
        className="grid grid-cols-1 md:grid-cols-3 gap-4"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        {/* Card - Faturamento do Mês */}
        <motion.div variants={cardVariants}>
          <Card className="relative overflow-hidden border border-primary/20 hover:border-primary/40 transition-all duration-300 group">
            <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-primary/5 to-transparent" />
            <div className="absolute top-0 right-0 w-32 h-32 bg-primary/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
            <CardContent className="relative p-5">
              <div className="flex items-start justify-between">
                <div className="space-y-1">
                  <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider flex items-center gap-1.5">
                    <Sparkles className="w-3 h-3 text-primary" />
                    Faturamento do Mês
                  </p>
                  <motion.p 
                    className="text-[22px] font-semibold text-foreground"
                    initial={{ scale: 0.5, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ delay: 0.3, type: "spring" as const, stiffness: 200 }}
                  >
                    {formatCurrency(data.faturamentoMes)}
                  </motion.p>
                  <div className="flex items-center gap-3 mt-2">
                    <div className="flex items-center gap-2">
                      <div className="h-2 rounded-full bg-muted overflow-hidden w-20">
                        <motion.div
                          className={cn("h-full rounded-full", percentBg)}
                          initial={{ width: 0 }}
                          animate={{ width: `${Math.min(data.percentualMeta, 100)}%` }}
                          transition={{ delay: 0.5, duration: 0.8, ease: "easeOut" }}
                        />
                      </div>
                      <span className={cn("text-sm font-bold", percentColor)}>
                        {data.percentualMeta.toFixed(0)}%
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5 mt-2 text-xs text-muted-foreground">
                    <ArrowUpRight className="w-3 h-3 text-primary" />
                    <span>Projeção: <span className="font-semibold text-foreground">{formatCurrency(data.projecaoFimMes)}</span></span>
                  </div>
                  <div className="flex items-center gap-1.5 mt-1.5 text-xs text-muted-foreground">
                    <Calendar className="w-3 h-3 text-primary/70" />
                    <span>
                      Dia <span className="font-semibold text-foreground">{data.diasUteisPassados}</span> de{' '}
                      <span className="font-semibold text-foreground">{data.diasUteis}</span> úteis
                    </span>
                  </div>
                </div>
                <motion.div 
                  className="p-3 rounded-xl bg-primary/10 border border-primary/20"
                  whileHover={{ scale: 1.1, rotate: 5 }}
                  transition={{ type: "spring" as const, stiffness: 400 }}
                >
                  <Target className="w-6 h-6 text-primary" />
                </motion.div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Card - Margem Bruta Média */}
        <motion.div variants={cardVariants}>
          <Card className="relative overflow-hidden border border-border/50 hover:border-primary/30 transition-all duration-300 group">
            <div className="absolute inset-0 bg-gradient-to-br from-violet-500/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
            <CardContent className="relative p-5">
              <div className="flex items-start justify-between">
                <div className="space-y-1">
                  <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Margem Bruta Média
                  </p>
                  <motion.p 
                    className="text-[22px] font-semibold text-foreground"
                    initial={{ scale: 0.5, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ delay: 0.4, type: "spring" as const, stiffness: 200 }}
                  >
                    {data.margemBrutaMedia.toFixed(1)}%
                  </motion.p>
                  <motion.div 
                    className={cn(
                      "inline-flex items-center gap-1.5 px-2 py-1 rounded-full border mt-2",
                      getTendenciaBg(data.tendenciaMargemtext)
                    )}
                    whileHover={{ scale: 1.05 }}
                  >
                    {getTendenciaIcon(data.tendenciaMargemtext)}
                    <span className={cn(
                      "text-xs font-medium",
                      data.tendenciaMargemtext === 'subindo' ? 'text-emerald-600' :
                      data.tendenciaMargemtext === 'caindo' ? 'text-red-600' : 'text-muted-foreground'
                    )}>
                      {getTendenciaText(data.tendenciaMargemtext)}
                    </span>
                  </motion.div>
                </div>
                <motion.div 
                  className="p-3 rounded-xl bg-muted/50"
                  whileHover={{ scale: 1.1, rotate: -5 }}
                  transition={{ type: "spring" as const, stiffness: 400 }}
                >
                  <Percent className="w-6 h-6 text-muted-foreground" />
                </motion.div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Card - Comissão Projetada */}
        <motion.div variants={cardVariants}>
          <Card className="relative overflow-hidden border border-emerald-500/20 hover:border-emerald-500/40 transition-all duration-300 group">
            <div className="absolute inset-0 bg-gradient-to-br from-emerald-500/10 via-emerald-500/5 to-transparent" />
            <div className="absolute bottom-0 right-0 w-32 h-32 bg-emerald-500/10 rounded-full blur-3xl translate-y-1/2 translate-x-1/2" />
            <CardContent className="relative p-5">
              <div className="flex items-start justify-between">
                <div className="space-y-1">
                  <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Comissão Projetada
                  </p>
                  <motion.p 
                    className="text-[22px] font-semibold text-emerald-600"
                    initial={{ scale: 0.5, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ delay: 0.5, type: "spring" as const, stiffness: 200 }}
                  >
                    {formatCurrency(data.comissaoProjetada)}
                  </motion.p>
                  <p className="text-xs text-muted-foreground mt-2 flex items-center gap-1">
                    <Sparkles className="w-3 h-3 text-emerald-500" />
                    Baseado nas regras de margem
                  </p>
                </div>
                <motion.div 
                  className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20"
                  whileHover={{ scale: 1.1, rotate: 5 }}
                  transition={{ type: "spring" as const, stiffness: 400 }}
                >
                  <Wallet className="w-6 h-6 text-emerald-500" />
                </motion.div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>
    </div>
  );
}
