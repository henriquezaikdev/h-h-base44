import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { fetchAllPaginated } from '@/lib/paginatedQuery';
import { CollapsibleDataSection, DataSkeleton } from '@/components/ui/CollapsibleDataSection';
import { cn } from '@/lib/utils';

interface Props {
  startDate: string;
  endDate: string;
}

interface DreValues {
  receitaBruta: number;
  totalReceber: number;
  totalDespesas: number;
  resultado: number;
  margem: number | null;
}

export function FinDreTab({ startDate, endDate }: Props) {
  const [expanded, setExpanded] = useState(false);
  const [data, setData] = useState<DreValues | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setData(null);
    setExpanded(false);
  }, [startDate, endDate]);

  useEffect(() => {
    if (expanded && !data) fetchDre();
  }, [expanded]);

  async function fetchDre() {
    setLoading(true);

    // Use fetchAllPaginated to handle >1000 rows
    const [allOrders, allReceber, allPagar] = await Promise.all([
      fetchAllPaginated<{ total: number }>(() =>
        supabase.from('orders').select('total')
          .eq('is_accountable', true)
          .gte('created_at', startDate)
          .lte('created_at', endDate + 'T23:59:59')
      ),
      fetchAllPaginated<{ valor: number }>(() =>
        supabase.from('fin_contas_receber').select('valor')
          .gte('data_vencimento', startDate)
          .lte('data_vencimento', endDate)
          .eq('origem', 'conta_azul')
      ),
      fetchAllPaginated<{ valor: number }>(() =>
        supabase.from('fin_contas_pagar').select('valor')
          .gte('data_vencimento', startDate)
          .lte('data_vencimento', endDate)
          .eq('origem', 'conta_azul')
      ),
    ]);

    const receitaBruta = allOrders.reduce((s, r) => s + (Number(r.total) || 0), 0);
    const totalReceber = allReceber.reduce((s, r) => s + (Number(r.valor) || 0), 0);
    const totalDespesas = allPagar.reduce((s, r) => s + (Number(r.valor) || 0), 0);
    const resultado = totalReceber - totalDespesas;
    const margem = totalReceber > 0 ? (resultado / totalReceber) * 100 : null;

    setData({ receitaBruta, totalReceber, totalDespesas, resultado, margem });
    setLoading(false);
  }

  const formatCurrency = (v: number) =>
    v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

  const rows: {
    label: string;
    value: string;
    highlight?: boolean;
    danger?: boolean;
    success?: boolean;
    dividerAbove?: boolean;
  }[] = data ? [
    { label: 'Receita Bruta (Pedidos)', value: formatCurrency(data.receitaBruta) },
    { label: 'Total Recebido / A Receber', value: formatCurrency(data.totalReceber) },
    { label: '(−) Total Despesas', value: formatCurrency(data.totalDespesas), danger: true },
    { label: '(=) Resultado do Período', value: formatCurrency(data.resultado), highlight: true, success: data.resultado >= 0, danger: data.resultado < 0, dividerAbove: true },
    { label: 'Margem Líquida', value: data.margem !== null ? data.margem.toFixed(1) + '%' : '—', highlight: true, success: data.margem !== null && data.margem >= 0, danger: data.margem !== null && data.margem < 0 },
  ] : [];

  return (
    <div className="space-y-4">
      <CollapsibleDataSection
        title="DRE Simplificado"
        count={null}
        expanded={expanded}
        onToggle={() => setExpanded(v => !v)}
      >
        {loading ? (
          <DataSkeleton />
        ) : !data ? (
          <div className="text-center py-12 text-muted-foreground text-sm">Sem dados.</div>
        ) : (
          <div className="divide-y divide-border">
            {rows.map((row, i) => (
              <div key={i}>
                {row.dividerAbove && <div className="border-t-2 border-border" />}
                <div className={cn('flex items-center justify-between px-5 py-3.5', row.highlight && 'bg-muted/50')}>
                  <span className={cn(row.highlight ? 'text-[14px] font-semibold text-foreground' : 'text-[14px] text-muted-foreground')}>
                    {row.label}
                  </span>
                  <span className={cn(
                    'text-[14px] font-medium',
                    row.highlight && 'font-bold',
                    row.danger && 'text-[hsl(var(--status-danger))]',
                    row.success && 'text-[hsl(var(--status-success))]',
                    !row.danger && !row.success && 'text-foreground'
                  )}>
                    {row.value}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </CollapsibleDataSection>
    </div>
  );
}
