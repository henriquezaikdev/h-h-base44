import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { fetchAllPaginated } from '@/lib/paginatedQuery';
import { Input } from '@/components/ui/input';
import {
  Table, TableHeader, TableHead, TableBody, TableRow, TableCell,
} from '@/components/ui/table';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { CollapsibleDataSection, DataSkeleton } from '@/components/ui/CollapsibleDataSection';
import { format } from 'date-fns';
import { Search } from 'lucide-react';

interface Props {
  startDate: string;
  endDate: string;
}

const BATCH_SIZE = 10;

const STATUS_BADGE: Record<string, string> = {
  pendente: 'hh-badge-warning',
  pago: 'hh-badge-success',
  atrasado: 'hh-badge-danger',
  cancelado: 'hh-badge-neutral',
};

const ORIGEM_BADGE: Record<string, string> = {
  conta_azul: 'hh-badge-accent',
  manual: 'hh-badge-neutral',
};

export function FinPagarTab({ startDate, endDate }: Props) {
  const [expanded, setExpanded] = useState(false);
  const [count, setCount] = useState<number | null>(null);
  const [totalValor, setTotalValor] = useState<number>(0);
  const [loadingCount, setLoadingCount] = useState(true);
  const [data, setData] = useState<any[]>([]);
  const [loadingData, setLoadingData] = useState(false);
  const [hasMore, setHasMore] = useState(false);
  const [statusFilter, setStatusFilter] = useState('todos');
  const [search, setSearch] = useState('');

  const applyFilters = useCallback((q: any) => {
    q = q.gte('data_vencimento', startDate).lte('data_vencimento', endDate);
    if (statusFilter !== 'todos') q = q.eq('status', statusFilter);
    if (search.trim()) q = q.ilike('fornecedor', `%${search.trim()}%`);
    return q;
  }, [startDate, endDate, statusFilter, search]);

  useEffect(() => {
    fetchCount();
    setData([]);
    setExpanded(false);
  }, [startDate, endDate, statusFilter, search]);

  useEffect(() => {
    if (expanded && data.length === 0) loadData(0);
  }, [expanded]);

  async function fetchCount() {
    setLoadingCount(true);
    const q = applyFilters(supabase.from('fin_contas_pagar').select('*', { count: 'exact', head: true }));
    const { count: c } = await q;
    setCount(c || 0);

    // Sum total from ALL records (paginated)
    const allValues = await fetchAllPaginated<{ valor: number }>(() =>
      applyFilters(supabase.from('fin_contas_pagar').select('valor'))
    );
    setTotalValor(allValues.reduce((s, r) => s + (r.valor || 0), 0));
    setLoadingCount(false);
  }

  async function loadData(offset: number) {
    setLoadingData(true);
    const q = applyFilters(
      supabase.from('fin_contas_pagar').select('*')
    ).order('data_vencimento', { ascending: true }).range(offset, offset + BATCH_SIZE - 1);
    const { data: rows } = await q;
    setData(prev => offset === 0 ? (rows || []) : [...prev, ...(rows || [])]);
    setHasMore((rows || []).length === BATCH_SIZE);
    setLoadingData(false);
  }

  const formatCurrency = (v: number) => v?.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }) || 'R$ 0,00';

  return (
    <div className="space-y-4">
      {/* Totalizer card */}
      {!loadingCount && count !== null && count > 0 && (
        <div className="rounded-xl border border-border bg-card p-4 flex items-center gap-6">
          <div>
            <span className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">TOTAL A PAGAR</span>
            <p className="text-lg font-semibold text-[hsl(var(--status-danger))]">{formatCurrency(totalValor)}</p>
          </div>
          <div>
            <span className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">REGISTROS</span>
            <p className="text-lg font-semibold text-foreground">{count}</p>
          </div>
        </div>
      )}

      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1 max-w-xs">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Buscar por fornecedor..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[160px]"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="todos">Todos</SelectItem>
            <SelectItem value="pendente">Pendente</SelectItem>
            <SelectItem value="pago">Pago</SelectItem>
            <SelectItem value="atrasado">Atrasado</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <CollapsibleDataSection
        title="Contas a Pagar"
        count={count}
        loadingCount={loadingCount}
        expanded={expanded}
        onToggle={() => setExpanded(v => !v)}
        hasMore={hasMore}
        onLoadMore={() => loadData(data.length)}
        loadingMore={loadingData && data.length > 0}
      >
        {loadingData && data.length === 0 ? (
          <DataSkeleton />
        ) : data.length === 0 && !loadingData ? (
          <div className="text-center py-12 text-muted-foreground text-sm">
            Nenhuma conta a pagar encontrada. Sincronize com o Conta Azul para importar dados.
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="text-[11px] uppercase font-semibold">Descrição</TableHead>
                <TableHead className="text-[11px] uppercase font-semibold">Fornecedor</TableHead>
                <TableHead className="text-[11px] uppercase font-semibold">Categoria</TableHead>
                <TableHead className="text-[11px] uppercase font-semibold">Centro de Custo</TableHead>
                <TableHead className="text-[11px] uppercase font-semibold">Vencimento</TableHead>
                <TableHead className="text-[11px] uppercase font-semibold text-right">Valor</TableHead>
                <TableHead className="text-[11px] uppercase font-semibold">Status</TableHead>
                <TableHead className="text-[11px] uppercase font-semibold">Origem</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {data.map(row => (
                <TableRow key={row.id}>
                  <TableCell className="text-[13px]">{row.descricao}</TableCell>
                  <TableCell className="text-[13px]">{row.fornecedor || '—'}</TableCell>
                  <TableCell className="text-[13px]">{row.categoria || '—'}</TableCell>
                  <TableCell className="text-[13px]">{row.centro_custo || '—'}</TableCell>
                  <TableCell className="text-[13px]">
                    {row.data_vencimento ? format(new Date(row.data_vencimento + 'T00:00:00'), 'dd/MM/yyyy') : '—'}
                  </TableCell>
                  <TableCell className="text-[13px] text-right font-medium">{formatCurrency(row.valor)}</TableCell>
                  <TableCell><span className={STATUS_BADGE[row.status] || 'hh-badge-neutral'}>{row.status}</span></TableCell>
                  <TableCell><span className={ORIGEM_BADGE[row.origem] || 'hh-badge-neutral'}>{row.origem}</span></TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CollapsibleDataSection>
    </div>
  );
}
