import { useEffect, useState, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Save, Wallet, Plus, Trash2 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';
import { format } from 'date-fns';

interface AccountBalance {
  account_name: string;
  balance_amount: string;
  id?: string;
}

export function FinSaldosDiarios() {
  const [date, setDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [accounts, setAccounts] = useState<{ id: string; account_name: string; account_type: string }[]>([]);
  const [balances, setBalances] = useState<AccountBalance[]>([]);
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();
  const { toast } = useToast();

  const loadAccounts = useCallback(async () => {
    const { data } = await supabase
      .from('fin_accounts')
      .select('id, account_name, account_type')
      .eq('is_active', true)
      .order('display_order');
    if (data) setAccounts(data);
  }, []);

  const loadBalances = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase
      .from('fin_daily_balances')
      .select('*')
      .eq('reference_date', date);

    if (data && accounts.length > 0) {
      const balanceMap = new Map(data.map(b => [b.account_name, b]));
      const merged = accounts.map(acc => ({
        account_name: acc.account_name,
        balance_amount: balanceMap.has(acc.account_name)
          ? String(balanceMap.get(acc.account_name)!.balance_amount)
          : '',
        id: balanceMap.get(acc.account_name)?.id,
      }));
      setBalances(merged);
    } else {
      setBalances(accounts.map(acc => ({
        account_name: acc.account_name,
        balance_amount: '',
      })));
    }
    setLoading(false);
  }, [date, accounts]);

  useEffect(() => { loadAccounts(); }, [loadAccounts]);
  useEffect(() => { if (accounts.length > 0) loadBalances(); }, [accounts, loadBalances]);

  const handleValueChange = (index: number, value: string) => {
    // Allow comma or dot as decimal
    const cleaned = value.replace(/[^\d,.\-]/g, '');
    setBalances(prev => prev.map((b, i) => i === index ? { ...b, balance_amount: cleaned } : b));
  };

  const parseValue = (v: string): number => {
    if (!v || v.trim() === '') return 0;
    // Handle Brazilian format: 1.234,56 -> 1234.56
    let clean = v.replace(/\s/g, '');
    if (clean.includes(',') && clean.includes('.')) {
      clean = clean.replace(/\./g, '').replace(',', '.');
    } else if (clean.includes(',')) {
      clean = clean.replace(',', '.');
    }
    return parseFloat(clean) || 0;
  };

  const handleSave = async () => {
    if (!user) return;
    setSaving(true);

    try {
      const toUpsert = balances
        .filter(b => b.balance_amount.trim() !== '')
        .map(b => ({
          balance_hash_key: `${b.account_name}|${date}`,
          reference_date: date,
          account_name: b.account_name,
          balance_amount: parseValue(b.balance_amount),
          created_by_user_id: user.id,
          source: 'MANUAL_SALDO' as const,
        }));

      if (toUpsert.length === 0) {
        toast({ title: 'Nada para salvar', description: 'Preencha ao menos uma conta.' });
        setSaving(false);
        return;
      }

      const { error } = await supabase
        .from('fin_daily_balances')
        .upsert(toUpsert, { onConflict: 'balance_hash_key' });

      if (error) throw error;

      toast({ title: '✅ Saldos salvos', description: `${toUpsert.length} contas registradas para ${format(new Date(date + 'T12:00:00'), 'dd/MM/yyyy')}` });
      loadBalances();
    } catch (err: any) {
      toast({ title: 'Erro', description: err.message, variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  const total = balances.reduce((sum, b) => sum + parseValue(b.balance_amount), 0);

  return (
    <div className="space-y-6 mt-4">
      <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
        <div className="space-y-1">
          <Label htmlFor="balance-date" className="text-xs font-medium text-muted-foreground">
            Data do Saldo
          </Label>
          <Input
            id="balance-date"
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            className="w-44"
          />
        </div>
        <div className="flex-1" />
        <Button onClick={handleSave} disabled={saving} className="gap-2">
          <Save className="h-4 w-4" />
          {saving ? 'Salvando...' : 'Salvar Saldos do Dia'}
        </Button>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <Wallet className="h-4 w-4 text-primary" />
            Saldos por Conta
          </CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="space-y-3">
              {Array.from({ length: 5 }).map((_, i) => (
                <div key={i} className="h-12 bg-muted/30 rounded-lg animate-pulse" />
              ))}
            </div>
          ) : (
            <div className="space-y-2">
              {balances.map((balance, index) => (
                <div
                  key={balance.account_name}
                  className="flex items-center gap-3 p-3 rounded-lg bg-muted/20 hover:bg-muted/40 transition-colors"
                >
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{balance.account_name}</p>
                  </div>
                  <div className="w-44">
                    <Input
                      type="text"
                      inputMode="decimal"
                      placeholder="0,00"
                      value={balance.balance_amount}
                      onChange={(e) => handleValueChange(index, e.target.value)}
                      className="text-right font-mono"
                    />
                  </div>
                </div>
              ))}

              {/* Total */}
              <div className="flex items-center gap-3 p-3 rounded-lg bg-primary/5 border border-primary/20 mt-4">
                <div className="flex-1">
                  <p className="text-sm font-bold text-primary">TOTAL CONSOLIDADO</p>
                </div>
                <div className="w-44 text-right">
                  <span className="text-lg font-bold text-primary font-mono">
                    {total.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                  </span>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
