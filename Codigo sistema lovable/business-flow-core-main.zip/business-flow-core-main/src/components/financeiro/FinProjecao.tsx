import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, AlertTriangle } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { format, addDays, startOfDay, endOfDay, startOfWeek, endOfWeek, isSameWeek } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { cn } from '@/lib/utils';

interface ProjectionDay {
  date: string;
  openingBalance: number;
  inflows: number;
  outflows: number;
  closingBalance: number;
}

export function FinProjecao() {
  const [projection, setProjection] = useState<ProjectionDay[]>([]);
  const [loading, setLoading] = useState(true);
  const [horizon, setHorizon] = useState(90);

  useEffect(() => { loadProjection(); }, [horizon]);

  async function loadProjection() {
    setLoading(true);
    try {
      const today = new Date();
      const todayStr = format(today, 'yyyy-MM-dd');
      const endDate = format(addDays(today, horizon), 'yyyy-MM-dd');

      // Get latest balance
      const { data: balances } = await supabase
        .from('fin_daily_balances')
        .select('balance_amount, reference_date')
        .order('reference_date', { ascending: false })
        .limit(50);

      let baseBalance = 0;
      if (balances && balances.length > 0) {
        const dateMap = new Map<string, number>();
        for (const b of balances) {
          dateMap.set(b.reference_date, (dateMap.get(b.reference_date) || 0) + Number(b.balance_amount));
        }
        const latest = [...dateMap.entries()].sort((a, b) => b[0].localeCompare(a[0]));
        if (latest.length > 0) baseBalance = latest[0][1];
      }

      // Get open receivables in horizon
      const { data: receivables } = await supabase
        .from('fin_entries')
        .select('due_date, expected_date, amount_open')
        .eq('entry_type', 'RECEBER')
        .eq('is_active', true)
        .in('status_norm', ['ABERTO', 'ATRASADO'])
        .gte('due_date', todayStr)
        .lte('due_date', endDate);

      // Get open payables in horizon
      const { data: payables } = await supabase
        .from('fin_entries')
        .select('due_date, expected_date, amount_open')
        .eq('entry_type', 'PAGAR')
        .eq('is_active', true)
        .in('status_norm', ['ABERTO', 'ATRASADO'])
        .gte('due_date', todayStr)
        .lte('due_date', endDate);

      // Build daily projection
      const inflowsByDate = new Map<string, number>();
      const outflowsByDate = new Map<string, number>();

      for (const r of receivables || []) {
        const d = r.expected_date || r.due_date;
        if (d) inflowsByDate.set(d, (inflowsByDate.get(d) || 0) + Number(r.amount_open));
      }
      for (const p of payables || []) {
        const d = p.expected_date || p.due_date;
        if (d) outflowsByDate.set(d, (outflowsByDate.get(d) || 0) + Number(p.amount_open));
      }

      const days: ProjectionDay[] = [];
      let runningBalance = baseBalance;

      for (let i = 0; i <= horizon; i++) {
        const date = format(addDays(today, i), 'yyyy-MM-dd');
        const inflows = inflowsByDate.get(date) || 0;
        const outflows = outflowsByDate.get(date) || 0;
        const opening = runningBalance;
        const closing = opening + inflows - outflows;

        days.push({ date, openingBalance: opening, inflows, outflows, closingBalance: closing });
        runningBalance = closing;
      }

      setProjection(days);
    } catch (err) {
      console.error('Projection error:', err);
    } finally {
      setLoading(false);
    }
  }

  const fmt = (v: number) => v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  const minBalance = Math.min(...projection.map(d => d.closingBalance));
  const hasRisk = minBalance < 0;

  // Group by week
  const weeks: { label: string; days: ProjectionDay[] }[] = [];
  let currentWeek: ProjectionDay[] = [];
  let currentWeekLabel = '';

  for (const day of projection) {
    const date = new Date(day.date + 'T12:00:00');
    const weekLabel = `${format(startOfWeek(date, { weekStartsOn: 1 }), 'dd/MM')} - ${format(endOfWeek(date, { weekStartsOn: 1 }), 'dd/MM')}`;
    if (weekLabel !== currentWeekLabel) {
      if (currentWeek.length > 0) {
        weeks.push({ label: currentWeekLabel, days: currentWeek });
      }
      currentWeek = [day];
      currentWeekLabel = weekLabel;
    } else {
      currentWeek.push(day);
    }
  }
  if (currentWeek.length > 0) weeks.push({ label: currentWeekLabel, days: currentWeek });

  return (
    <div className="space-y-6 mt-4">
      {/* Horizon selector */}
      <div className="flex gap-2">
        {[30, 60, 90].map((h) => (
          <Button
            key={h}
            variant={horizon === h ? 'default' : 'outline'}
            size="sm"
            onClick={() => setHorizon(h)}
          >
            {h} dias
          </Button>
        ))}
      </div>

      {hasRisk && (
        <Card className="border-destructive/50 bg-destructive/5">
          <CardContent className="p-4 flex items-center gap-3">
            <AlertTriangle className="h-5 w-5 text-destructive shrink-0" />
            <div>
              <p className="text-sm font-semibold text-destructive">Alerta de Risco</p>
              <p className="text-xs text-destructive/80">
                Saldo projetado fica negativo ({fmt(minBalance)}) dentro do horizonte de {horizon} dias.
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      {loading ? (
        <div className="space-y-3">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="h-20 bg-muted/30 rounded-lg animate-pulse" />
          ))}
        </div>
      ) : (
        <div className="space-y-4">
          {weeks.map((week) => {
            const weekInflows = week.days.reduce((s, d) => s + d.inflows, 0);
            const weekOutflows = week.days.reduce((s, d) => s + d.outflows, 0);
            const weekEnd = week.days[week.days.length - 1]?.closingBalance || 0;

            return (
              <Card key={week.label}>
                <CardHeader className="pb-2">
                  <CardTitle className="text-xs flex items-center justify-between">
                    <span>Semana {week.label}</span>
                    <div className="flex gap-3 text-[10px]">
                      <span className="text-emerald-600">+{fmt(weekInflows)}</span>
                      <span className="text-red-600">-{fmt(weekOutflows)}</span>
                      <Badge variant="outline" className={cn(weekEnd < 0 ? 'text-destructive border-destructive/30' : 'text-primary border-primary/30')}>
                        Saldo: {fmt(weekEnd)}
                      </Badge>
                    </div>
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                  <div className="overflow-x-auto">
                    <table className="w-full text-xs">
                      <tbody>
                        {week.days.filter(d => d.inflows > 0 || d.outflows > 0).map((day) => (
                          <tr key={day.date} className="border-t hover:bg-muted/20">
                            <td className="p-2 pl-4 text-muted-foreground w-28">
                              {format(new Date(day.date + 'T12:00:00'), 'EEE dd/MM', { locale: ptBR })}
                            </td>
                            <td className="p-2 text-right text-emerald-600 font-mono w-28">
                              {day.inflows > 0 ? `+${fmt(day.inflows)}` : ''}
                            </td>
                            <td className="p-2 text-right text-red-600 font-mono w-28">
                              {day.outflows > 0 ? `-${fmt(day.outflows)}` : ''}
                            </td>
                            <td className={cn('p-2 pr-4 text-right font-mono w-32 font-medium', day.closingBalance < 0 ? 'text-destructive' : 'text-foreground')}>
                              {fmt(day.closingBalance)}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}

function Button({ children, variant = 'default', size = 'default', onClick, disabled, className }: any) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={cn(
        'inline-flex items-center justify-center rounded-md font-medium transition-colors',
        size === 'sm' ? 'h-8 px-3 text-xs' : 'h-10 px-4 text-sm',
        variant === 'default' ? 'bg-primary text-primary-foreground hover:bg-primary/90' : 'border border-input bg-background hover:bg-accent hover:text-accent-foreground',
        disabled && 'opacity-50 pointer-events-none',
        className
      )}
    >
      {children}
    </button>
  );
}
