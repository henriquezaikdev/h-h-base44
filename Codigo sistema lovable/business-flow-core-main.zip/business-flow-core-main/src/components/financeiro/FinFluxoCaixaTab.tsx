import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { fetchAllPaginated } from '@/lib/paginatedQuery';
import {
  Table, TableHeader, TableHead, TableBody, TableRow, TableCell,
} from '@/components/ui/table';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { startOfWeek, endOfWeek, addWeeks, format, parseISO, isBefore, isAfter } from 'date-fns';
import { CollapsibleDataSection, DataSkeleton } from '@/components/ui/CollapsibleDataSection';
import { cn } from '@/lib/utils';

interface Props {
  startDate: string;
  endDate: string;
}

interface WeekRow {
  label: string;
  entradas: number;
  saidas: number;
  saldo: number;
  acumulado: number;
}

export function FinFluxoCaixaTab({ startDate, endDate }: Props) {
  const [expanded, setExpanded] = useState(false);
  const [weeks, setWeeks] = useState<WeekRow[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setWeeks([]);
    setExpanded(false);
  }, [startDate, endDate]);

  useEffect(() => {
    if (expanded && weeks.length === 0) fetchFluxo();
  }, [expanded]);

  async function fetchFluxo() {
    setLoading(true);

    // Fetch ALL records using pagination to avoid 1000-row limit
    const [receberData, pagarData] = await Promise.all([
      fetchAllPaginated<{ data_vencimento: string; valor: number }>(() =>
        supabase.from('fin_contas_receber').select('data_vencimento, valor')
          .gte('data_vencimento', startDate)
          .lte('data_vencimento', endDate)
      ),
      fetchAllPaginated<{ data_vencimento: string; valor: number }>(() =>
        supabase.from('fin_contas_pagar').select('data_vencimento, valor')
          .gte('data_vencimento', startDate)
          .lte('data_vencimento', endDate)
      ),
    ]);

    const start = parseISO(startDate);
    const end = parseISO(endDate);
    const weekBuckets: { start: Date; end: Date; entradas: number; saidas: number }[] = [];

    let ws = startOfWeek(start, { weekStartsOn: 1 });
    while (isBefore(ws, end) || format(ws, 'yyyy-MM-dd') === format(end, 'yyyy-MM-dd')) {
      const we = endOfWeek(ws, { weekStartsOn: 1 });
      weekBuckets.push({ start: ws, end: we, entradas: 0, saidas: 0 });
      ws = addWeeks(ws, 1);
    }

    const addToBucket = (items: any[], field: 'entradas' | 'saidas') => {
      items.forEach(item => {
        const d = parseISO(item.data_vencimento);
        const bucket = weekBuckets.find(
          b => !isBefore(d, b.start) && !isAfter(d, b.end)
        );
        if (bucket) bucket[field] += item.valor || 0;
      });
    };

    addToBucket(receberData, 'entradas');
    addToBucket(pagarData, 'saidas');

    let acumulado = 0;
    const rows: WeekRow[] = weekBuckets.map(b => {
      const saldo = b.entradas - b.saidas;
      acumulado += saldo;
      return {
        label: `${format(b.start, 'dd/MM')} - ${format(b.end, 'dd/MM')}`,
        entradas: b.entradas,
        saidas: b.saidas,
        saldo,
        acumulado,
      };
    });

    setWeeks(rows);
    setLoading(false);
  }

  const formatCurrency = (v: number) => v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

  return (
    <div className="space-y-4">
      <CollapsibleDataSection
        title="Fluxo de Caixa Semanal"
        count={null}
        expanded={expanded}
        onToggle={() => setExpanded(v => !v)}
      >
        {loading ? (
          <DataSkeleton />
        ) : weeks.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground text-sm">Sem dados para o período selecionado.</div>
        ) : (
          <div className="space-y-6">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-[11px] uppercase font-semibold">Semana</TableHead>
                  <TableHead className="text-[11px] uppercase font-semibold text-right">Entradas Previstas</TableHead>
                  <TableHead className="text-[11px] uppercase font-semibold text-right">Saídas Previstas</TableHead>
                  <TableHead className="text-[11px] uppercase font-semibold text-right">Saldo da Semana</TableHead>
                  <TableHead className="text-[11px] uppercase font-semibold text-right">Saldo Acumulado</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {weeks.map((w, i) => (
                  <TableRow key={i}>
                    <TableCell className="text-[13px] font-medium">{w.label}</TableCell>
                    <TableCell className="text-[13px] text-right text-[hsl(var(--status-success))]">{formatCurrency(w.entradas)}</TableCell>
                    <TableCell className="text-[13px] text-right text-[hsl(var(--status-danger))]">{formatCurrency(w.saidas)}</TableCell>
                    <TableCell className={cn('text-[13px] text-right font-medium', w.saldo >= 0 ? 'text-[hsl(var(--status-success))]' : 'text-[hsl(var(--status-danger))]')}>
                      {formatCurrency(w.saldo)}
                    </TableCell>
                    <TableCell className={cn('text-[13px] text-right font-medium', w.acumulado >= 0 ? 'text-[hsl(var(--status-success))]' : 'text-[hsl(var(--status-danger))]')}>
                      {formatCurrency(w.acumulado)}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>

            <div className="rounded-xl border border-border bg-card p-4">
              <span className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground mb-3 block">
                Entradas vs Saídas por Semana
              </span>
              <ResponsiveContainer width="100%" height={280}>
                <BarChart data={weeks} margin={{ top: 5, right: 10, left: 10, bottom: 5 }}>
                  <XAxis dataKey="label" tick={{ fontSize: 11 }} />
                  <YAxis tick={{ fontSize: 11 }} tickFormatter={v => `${(v / 1000).toFixed(0)}k`} />
                  <Tooltip formatter={(value: number) => formatCurrency(value)} contentStyle={{ fontSize: 12, borderRadius: 8 }} />
                  <Legend wrapperStyle={{ fontSize: 12 }} />
                  <Bar dataKey="entradas" name="Entradas" fill="hsl(142, 76%, 36%)" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="saidas" name="Saídas" fill="hsl(0, 84%, 60%)" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}
      </CollapsibleDataSection>
    </div>
  );
}
