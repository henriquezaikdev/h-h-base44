import { useState, useMemo, useCallback } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { fetchAllPaginated } from '@/lib/paginatedQuery';
import { toast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  Table, TableHeader, TableHead, TableBody, TableRow, TableCell,
} from '@/components/ui/table';
import { Loader2, Plus, Search, Power, Pencil, CheckCircle2, CircleDot, AlertCircle, Edit3 } from 'lucide-react';
import { format, subMonths, startOfMonth, endOfMonth } from 'date-fns';
import { cn } from '@/lib/utils';

const formatCurrency = (v: number) =>
  new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(v);

type Confidence = 'confirmed' | 'likely' | 'occasional';
type Frequency = 'monthly' | 'biweekly' | 'weekly';
type FilterMode = 'all' | 'auto' | 'manual' | 'active' | 'inactive';

interface FixedExpense {
  id: string;
  description: string;
  supplier: string | null;
  category: string | null;
  amount: number;
  frequency: Frequency;
  day_of_month: number | null;
  auto_detected: boolean;
  confidence: Confidence | null;
  active: boolean;
  created_at: string;
  updated_at: string;
  // runtime: match status
  match_status?: 'realizado' | 'previsto' | null;
  match_amount?: number;
}

interface FormData {
  description: string;
  supplier: string;
  category: string;
  amount: string;
  frequency: Frequency;
  day_of_month: string;
}

const emptyForm: FormData = { description: '', supplier: '', category: '', amount: '', frequency: 'monthly', day_of_month: '' };

const confidenceIcon: Record<string, React.ReactNode> = {
  confirmed: <CheckCircle2 className="h-4 w-4 text-emerald-500" />,
  likely: <CircleDot className="h-4 w-4 text-blue-500" />,
  occasional: <AlertCircle className="h-4 w-4 text-amber-500" />,
};

const frequencyLabel: Record<Frequency, string> = {
  monthly: 'Mensal',
  biweekly: 'Quinzenal',
  weekly: 'Semanal',
};

export function FinDespesasFixasTab() {
  const queryClient = useQueryClient();
  const [filter, setFilter] = useState<FilterMode>('all');
  const [detecting, setDetecting] = useState(false);
  const [modalOpen, setModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState<FormData>(emptyForm);
  const [saving, setSaving] = useState(false);

  const now = new Date();
  const currentMonthStart = format(startOfMonth(now), 'yyyy-MM-dd');
  const currentMonthEnd = format(endOfMonth(now), 'yyyy-MM-dd');

  // Fetch fixed expenses
  const { data: expenses = [], isLoading } = useQuery({
    queryKey: ['fixed-expenses'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('fixed_expenses')
        .select('*')
        .order('amount', { ascending: false });
      if (error) throw error;
      return (data || []) as FixedExpense[];
    },
  });

  // Fetch current month fin_contas_pagar to check matches
  const { data: currentMonthPagar = [] } = useQuery({
    queryKey: ['fixed-expenses-match', currentMonthStart],
    queryFn: async () => {
      return fetchAllPaginated<{ fornecedor: string | null; valor: number; fixed_expense_id: string | null }>(() =>
        supabase.from('fin_contas_pagar')
          .select('fornecedor, valor, fixed_expense_id')
          .gte('data_vencimento', currentMonthStart)
          .lte('data_vencimento', currentMonthEnd)
      );
    },
  });

  // Enrich expenses with match status
  const enrichedExpenses = useMemo(() => {
    return expenses.map(exp => {
      const matched = currentMonthPagar.find(p => p.fixed_expense_id === exp.id);
      if (matched) {
        return { ...exp, match_status: 'realizado' as const, match_amount: matched.valor };
      }
      // Try supplier match
      const supplierMatch = exp.supplier
        ? currentMonthPagar.find(p =>
            p.fornecedor && p.fornecedor.toLowerCase() === exp.supplier!.toLowerCase() && !p.fixed_expense_id
          )
        : null;
      if (supplierMatch) {
        return { ...exp, match_status: 'realizado' as const, match_amount: supplierMatch.valor };
      }
      return { ...exp, match_status: exp.active ? 'previsto' as const : null, match_amount: exp.amount };
    });
  }, [expenses, currentMonthPagar]);

  // Filter
  const filtered = useMemo(() => {
    switch (filter) {
      case 'auto': return enrichedExpenses.filter(e => e.auto_detected);
      case 'manual': return enrichedExpenses.filter(e => !e.auto_detected);
      case 'active': return enrichedExpenses.filter(e => e.active);
      case 'inactive': return enrichedExpenses.filter(e => !e.active);
      default: return enrichedExpenses;
    }
  }, [enrichedExpenses, filter]);

  // Summaries
  const summaries = useMemo(() => {
    const active = enrichedExpenses.filter(e => e.active);
    const monthly = active.filter(e => e.frequency === 'monthly').reduce((s, e) => s + e.amount, 0);
    const biweekly = active.filter(e => e.frequency === 'biweekly').reduce((s, e) => s + e.amount, 0);
    const weekly = active.filter(e => e.frequency === 'weekly').reduce((s, e) => s + e.amount, 0);
    const annual = monthly * 12 + biweekly * 24 + weekly * 52;
    return { monthly, biweekly, weekly, annual };
  }, [enrichedExpenses]);

  // Auto-detect
  const handleDetect = useCallback(async () => {
    setDetecting(true);
    try {
      const sixMonthsAgo = format(startOfMonth(subMonths(now, 6)), 'yyyy-MM-dd');
      const today = format(now, 'yyyy-MM-dd');

      const rows = await fetchAllPaginated<{
        fornecedor: string | null;
        descricao: string;
        valor: number;
        data_vencimento: string;
        categoria: string | null;
      }>(() =>
        supabase.from('fin_contas_pagar')
          .select('fornecedor, descricao, valor, data_vencimento, categoria')
          .gte('data_vencimento', sixMonthsAgo)
          .lte('data_vencimento', today)
          .eq('origem', 'conta_azul')
      );

      // Group by supplier+description → months
      const groups = new Map<string, {
        supplier: string;
        description: string;
        category: string | null;
        months: Set<string>;
        amounts: number[];
        days: number[];
      }>();

      for (const r of rows) {
        const key = `${(r.fornecedor || '').toLowerCase()}::${r.descricao.toLowerCase()}`;
        const month = r.data_vencimento.substring(0, 7);
        const day = parseInt(r.data_vencimento.substring(8, 10), 10);
        let g = groups.get(key);
        if (!g) {
          g = { supplier: r.fornecedor || '', description: r.descricao, category: r.categoria, months: new Set(), amounts: [], days: [] };
          groups.set(key, g);
        }
        g.months.add(month);
        g.amounts.push(Number(r.valor) || 0);
        g.days.push(day);
      }

      // Filter: must appear at least 2 distinct months
      let detected = 0;
      for (const [, g] of groups) {
        if (g.months.size < 2) continue;

        const confidence: Confidence =
          g.months.size >= 5 ? 'confirmed' : g.months.size >= 3 ? 'likely' : 'occasional';

        const avgAmount = g.amounts.reduce((a, b) => a + b, 0) / g.amounts.length;
        const avgDay = Math.round(g.days.reduce((a, b) => a + b, 0) / g.days.length);

        // Upsert only auto_detected ones (don't overwrite manual)
        const { error } = await supabase
          .from('fixed_expenses')
          .upsert({
            description: g.description,
            supplier: g.supplier || null,
            category: g.category,
            amount: Math.round(avgAmount * 100) / 100,
            frequency: 'monthly' as Frequency,
            day_of_month: avgDay,
            auto_detected: true,
            confidence,
            active: true,
            updated_at: new Date().toISOString(),
          }, {
            onConflict: 'id',
            ignoreDuplicates: false,
          });

        if (!error) detected++;
      }

      queryClient.invalidateQueries({ queryKey: ['fixed-expenses'] });
      toast({ title: 'Detecção concluída', description: `${detected} despesas fixas detectadas.` });
    } catch (err: any) {
      toast({ title: 'Erro', description: err.message, variant: 'destructive' });
    } finally {
      setDetecting(false);
    }
  }, [queryClient]);

  // Save (create/edit)
  const handleSave = async () => {
    if (!form.description || !form.amount) return;
    setSaving(true);
    try {
      const payload = {
        description: form.description,
        supplier: form.supplier || null,
        category: form.category || null,
        amount: parseFloat(form.amount),
        frequency: form.frequency,
        day_of_month: form.day_of_month ? parseInt(form.day_of_month, 10) : null,
        auto_detected: false,
        confidence: null as string | null,
        updated_at: new Date().toISOString(),
      };

      if (editingId) {
        const { error } = await supabase.from('fixed_expenses').update(payload).eq('id', editingId);
        if (error) throw error;
      } else {
        const { error } = await supabase.from('fixed_expenses').insert(payload);
        if (error) throw error;
      }

      queryClient.invalidateQueries({ queryKey: ['fixed-expenses'] });
      setModalOpen(false);
      setEditingId(null);
      setForm(emptyForm);
      toast({ title: editingId ? 'Despesa atualizada' : 'Despesa adicionada' });
    } catch (err: any) {
      toast({ title: 'Erro', description: err.message, variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  const handleEdit = (exp: FixedExpense) => {
    setEditingId(exp.id);
    setForm({
      description: exp.description,
      supplier: exp.supplier || '',
      category: exp.category || '',
      amount: String(exp.amount),
      frequency: exp.frequency,
      day_of_month: exp.day_of_month ? String(exp.day_of_month) : '',
    });
    setModalOpen(true);
  };

  const handleToggleActive = async (exp: FixedExpense) => {
    await supabase.from('fixed_expenses').update({ active: !exp.active, updated_at: new Date().toISOString() }).eq('id', exp.id);
    queryClient.invalidateQueries({ queryKey: ['fixed-expenses'] });
  };

  const handleNewClick = () => {
    setEditingId(null);
    setForm(emptyForm);
    setModalOpen(true);
  };

  const filters: { value: FilterMode; label: string }[] = [
    { value: 'all', label: 'Todas' },
    { value: 'auto', label: 'Detectadas' },
    { value: 'manual', label: 'Manuais' },
    { value: 'active', label: 'Ativas' },
    { value: 'inactive', label: 'Inativas' },
  ];

  return (
    <section className="space-y-6 font-['DM_Sans']">
      {/* Summary cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { label: 'TOTAL MENSAL', value: summaries.monthly, color: 'text-[hsl(var(--status-danger))]' },
          { label: 'TOTAL QUINZENAL', value: summaries.biweekly, color: 'text-[hsl(var(--status-danger))]' },
          { label: 'TOTAL SEMANAL', value: summaries.weekly, color: 'text-[hsl(var(--status-danger))]' },
          { label: 'PROJEÇÃO ANUAL', value: summaries.annual, color: 'text-[#3B5BDB]' },
        ].map(c => (
          <div key={c.label} className="rounded-xl border border-border bg-card shadow-sm p-4 flex flex-col justify-center">
            <span className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">{c.label}</span>
            <span className={cn('text-[18px] font-semibold leading-tight', c.color)}>{formatCurrency(c.value)}</span>
          </div>
        ))}
      </div>

      {/* Actions bar */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div className="flex gap-1 overflow-x-auto">
          {filters.map(f => (
            <button
              key={f.value}
              onClick={() => setFilter(f.value)}
              className={cn(
                'px-3 py-1.5 text-[12px] font-medium rounded-full border transition-colors whitespace-nowrap',
                filter === f.value
                  ? 'bg-primary text-primary-foreground border-primary'
                  : 'bg-card text-muted-foreground border-border hover:text-foreground'
              )}
            >
              {f.label}
            </button>
          ))}
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={handleDetect} disabled={detecting} className="gap-1.5">
            {detecting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
            Detectar Despesas Fixas
          </Button>
          <Button size="sm" onClick={handleNewClick} className="gap-1.5">
            <Plus className="h-4 w-4" />
            Adicionar
          </Button>
        </div>
      </div>

      {/* Table */}
      {isLoading ? (
        <div className="space-y-2">{Array.from({ length: 6 }).map((_, i) => <div key={i} className="h-10 w-full bg-muted animate-pulse rounded" />)}</div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground text-sm">Nenhuma despesa fixa encontrada.</div>
      ) : (
        <div className="rounded-xl border border-border bg-card overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="text-[10px] uppercase font-semibold w-8"></TableHead>
                <TableHead className="text-[10px] uppercase font-semibold">Descrição</TableHead>
                <TableHead className="text-[10px] uppercase font-semibold">Fornecedor</TableHead>
                <TableHead className="text-[10px] uppercase font-semibold">Categoria</TableHead>
                <TableHead className="text-[10px] uppercase font-semibold text-right">Valor</TableHead>
                <TableHead className="text-[10px] uppercase font-semibold text-center">Frequência</TableHead>
                <TableHead className="text-[10px] uppercase font-semibold text-center">Dia</TableHead>
                <TableHead className="text-[10px] uppercase font-semibold text-center">Mês Atual</TableHead>
                <TableHead className="text-[10px] uppercase font-semibold text-center">Status</TableHead>
                <TableHead className="text-[10px] uppercase font-semibold text-center">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map(exp => (
                <TableRow key={exp.id} className={cn(!exp.active && 'opacity-50')}>
                  <TableCell className="text-center">
                    {exp.auto_detected
                      ? (confidenceIcon[exp.confidence || ''] || <CircleDot className="h-4 w-4 text-muted-foreground" />)
                      : <Edit3 className="h-4 w-4 text-muted-foreground" />
                    }
                  </TableCell>
                  <TableCell className="text-[13px] font-medium max-w-[200px] truncate">{exp.description}</TableCell>
                  <TableCell className="text-[12px] text-muted-foreground max-w-[150px] truncate">{exp.supplier || '—'}</TableCell>
                  <TableCell className="text-[12px] text-muted-foreground">{exp.category || '—'}</TableCell>
                  <TableCell className="text-[13px] text-right font-medium text-[hsl(var(--status-danger))]">{formatCurrency(exp.amount)}</TableCell>
                  <TableCell className="text-[12px] text-center">{frequencyLabel[exp.frequency] || exp.frequency}</TableCell>
                  <TableCell className="text-[12px] text-center">{exp.day_of_month || '—'}</TableCell>
                  <TableCell className="text-center">
                    {exp.match_status === 'realizado' ? (
                      <Badge variant="outline" className="text-[9px] bg-emerald-50 text-emerald-700 border-emerald-300">
                        Realizado {formatCurrency(exp.match_amount || 0)}
                      </Badge>
                    ) : exp.match_status === 'previsto' ? (
                      <Badge variant="outline" className="text-[9px] bg-amber-50 text-amber-700 border-amber-300">
                        Previsto {formatCurrency(exp.match_amount || 0)}
                      </Badge>
                    ) : (
                      <span className="text-[11px] text-muted-foreground">—</span>
                    )}
                  </TableCell>
                  <TableCell className="text-center">
                    <Badge variant={exp.active ? 'default' : 'secondary'} className="text-[9px]">
                      {exp.active ? 'Ativa' : 'Inativa'}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-center">
                    <div className="flex items-center justify-center gap-1">
                      <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => handleEdit(exp)}>
                        <Pencil className="h-3.5 w-3.5" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => handleToggleActive(exp)}>
                        <Power className={cn('h-3.5 w-3.5', exp.active ? 'text-emerald-500' : 'text-muted-foreground')} />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      {/* Add/Edit Modal */}
      <Dialog open={modalOpen} onOpenChange={setModalOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{editingId ? 'Editar Despesa Fixa' : 'Adicionar Despesa Fixa'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div>
              <label className="text-[12px] font-medium text-muted-foreground">Descrição *</label>
              <Input value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} placeholder="Ex: Aluguel escritório" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-[12px] font-medium text-muted-foreground">Fornecedor</label>
                <Input value={form.supplier} onChange={e => setForm(f => ({ ...f, supplier: e.target.value }))} />
              </div>
              <div>
                <label className="text-[12px] font-medium text-muted-foreground">Categoria</label>
                <Input value={form.category} onChange={e => setForm(f => ({ ...f, category: e.target.value }))} />
              </div>
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="text-[12px] font-medium text-muted-foreground">Valor *</label>
                <Input type="number" step="0.01" value={form.amount} onChange={e => setForm(f => ({ ...f, amount: e.target.value }))} />
              </div>
              <div>
                <label className="text-[12px] font-medium text-muted-foreground">Frequência</label>
                <Select value={form.frequency} onValueChange={v => setForm(f => ({ ...f, frequency: v as Frequency }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="monthly">Mensal</SelectItem>
                    <SelectItem value="biweekly">Quinzenal</SelectItem>
                    <SelectItem value="weekly">Semanal</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-[12px] font-medium text-muted-foreground">Dia do mês</label>
                <Input type="number" min="1" max="31" value={form.day_of_month} onChange={e => setForm(f => ({ ...f, day_of_month: e.target.value }))} />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setModalOpen(false)}>Cancelar</Button>
            <Button onClick={handleSave} disabled={saving || !form.description || !form.amount}>
              {saving ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : null}
              {editingId ? 'Salvar' : 'Adicionar'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </section>
  );
}
