import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Lock, Loader2 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';
import { format, subMonths, startOfMonth, endOfMonth } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface MonthSnapshot {
  id: string;
  reference_month: string;
  total_received: number;
  total_paid: number;
  total_open_receivable: number;
  total_open_payable: number;
  total_overdue: number;
  closing_balance: number;
  delta_accumulated: number;
  closed_at: string;
  is_locked: boolean;
}

export function FinFechamentoMensal() {
  const [snapshots, setSnapshots] = useState<MonthSnapshot[]>([]);
  const [loading, setLoading] = useState(true);
  const [closing, setClosing] = useState(false);
  const { user } = useAuth();
  const { toast } = useToast();

  useEffect(() => { loadSnapshots(); }, []);

  async function loadSnapshots() {
    setLoading(true);
    const { data } = await supabase
      .from('fin_month_snapshots')
      .select('*')
      .order('reference_month', { ascending: false })
      .limit(12);
    setSnapshots((data as MonthSnapshot[]) || []);
    setLoading(false);
  }

  async function closeMonth() {
    if (!user) return;
    setClosing(true);

    try {
      const lastMonth = subMonths(new Date(), 1);
      const refMonth = format(lastMonth, 'yyyy-MM');
      const monthStart = format(startOfMonth(lastMonth), 'yyyy-MM-dd');
      const monthEnd = format(endOfMonth(lastMonth), 'yyyy-MM-dd');

      // Check if already closed
      const existing = snapshots.find(s => s.reference_month === refMonth);
      if (existing) {
        toast({ title: 'Mês já fechado', description: `${refMonth} já possui snapshot.`, variant: 'destructive' });
        setClosing(false);
        return;
      }

      // Total received in the month
      const { data: received } = await supabase
        .from('fin_entries')
        .select('amount_paid')
        .eq('entry_type', 'RECEBER')
        .eq('status_norm', 'PAGO')
        .gte('paid_date', monthStart)
        .lte('paid_date', monthEnd);

      const totalReceived = (received || []).reduce((s, e) => s + Number(e.amount_paid), 0);

      // Total paid in the month
      const { data: paid } = await supabase
        .from('fin_entries')
        .select('amount_paid')
        .eq('entry_type', 'PAGAR')
        .eq('status_norm', 'PAGO')
        .gte('paid_date', monthStart)
        .lte('paid_date', monthEnd);

      const totalPaid = (paid || []).reduce((s, e) => s + Number(e.amount_paid), 0);

      // Open at end of month
      const { data: openRec } = await supabase
        .from('fin_entries')
        .select('amount_open')
        .eq('entry_type', 'RECEBER')
        .eq('is_active', true)
        .in('status_norm', ['ABERTO', 'ATRASADO']);

      const totalOpenReceivable = (openRec || []).reduce((s, e) => s + Number(e.amount_open), 0);

      const { data: openPay } = await supabase
        .from('fin_entries')
        .select('amount_open')
        .eq('entry_type', 'PAGAR')
        .eq('is_active', true)
        .in('status_norm', ['ABERTO', 'ATRASADO']);

      const totalOpenPayable = (openPay || []).reduce((s, e) => s + Number(e.amount_open), 0);

      // Last balance of the month
      const { data: lastBal } = await supabase
        .from('fin_daily_balances')
        .select('balance_amount')
        .lte('reference_date', monthEnd)
        .gte('reference_date', monthStart)
        .order('reference_date', { ascending: false });

      // Get last day balances
      let closingBalance = 0;
      if (lastBal && lastBal.length > 0) {
        closingBalance = lastBal.reduce((s, b) => s + Number(b.balance_amount), 0);
      }

      // Delta from reconciliations
      const { data: recs } = await supabase
        .from('fin_reconciliations')
        .select('delta')
        .gte('reference_date', monthStart)
        .lte('reference_date', monthEnd);

      const deltaAccumulated = (recs || []).reduce((s, r) => s + Number(r.delta), 0);

      // Overdue
      const { data: overdue } = await supabase
        .from('fin_entries')
        .select('amount_open')
        .eq('is_active', true)
        .eq('status_norm', 'ATRASADO');

      const totalOverdue = (overdue || []).reduce((s, e) => s + Number(e.amount_open), 0);

      const { error } = await supabase.from('fin_month_snapshots').insert({
        reference_month: refMonth,
        total_received: totalReceived,
        total_paid: totalPaid,
        total_open_receivable: totalOpenReceivable,
        total_open_payable: totalOpenPayable,
        total_overdue: totalOverdue,
        closing_balance: closingBalance,
        delta_accumulated: deltaAccumulated,
        closed_by_user_id: user.id,
        is_locked: true,
      });

      if (error) throw error;

      toast({ title: '✅ Mês fechado', description: `Snapshot de ${refMonth} criado com sucesso.` });
      loadSnapshots();
    } catch (err: any) {
      toast({ title: 'Erro', description: err.message, variant: 'destructive' });
    } finally {
      setClosing(false);
    }
  }

  const fmt = (v: number) => (v || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

  return (
    <div className="space-y-6 mt-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-sm font-semibold">Fechamento Mensal</h3>
          <p className="text-xs text-muted-foreground">Snapshot financeiro do mês anterior</p>
        </div>
        <Button onClick={closeMonth} disabled={closing} className="gap-2">
          {closing ? <Loader2 className="h-4 w-4 animate-spin" /> : <Lock className="h-4 w-4" />}
          {closing ? 'Fechando...' : 'Fechar Mês Anterior'}
        </Button>
      </div>

      {loading ? (
        <div className="space-y-3">
          {Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="h-24 bg-muted/30 rounded-lg animate-pulse" />
          ))}
        </div>
      ) : snapshots.length === 0 ? (
        <Card>
          <CardContent className="p-10 text-center text-muted-foreground text-sm">
            Nenhum fechamento mensal realizado ainda.
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {snapshots.map((snap) => (
            <Card key={snap.id}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <h4 className="text-sm font-bold">{snap.reference_month}</h4>
                    {snap.is_locked && (
                      <Badge variant="outline" className="text-[10px] gap-1">
                        <Lock className="h-3 w-3" />
                        Fechado
                      </Badge>
                    )}
                  </div>
                  <span className="text-xs text-muted-foreground">
                    {format(new Date(snap.closed_at), 'dd/MM/yyyy HH:mm')}
                  </span>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
                  <div>
                    <p className="text-muted-foreground">Recebido</p>
                    <p className="font-mono font-medium text-emerald-600">{fmt(snap.total_received)}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Pago</p>
                    <p className="font-mono font-medium text-red-600">{fmt(snap.total_paid)}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Saldo Final</p>
                    <p className="font-mono font-medium">{fmt(snap.closing_balance)}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Δ Acumulado</p>
                    <p className={`font-mono font-medium ${snap.delta_accumulated !== 0 ? 'text-amber-600' : ''}`}>
                      {fmt(snap.delta_accumulated)}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
