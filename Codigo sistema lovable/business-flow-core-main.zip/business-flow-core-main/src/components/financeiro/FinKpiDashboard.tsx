import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Skeleton } from '@/components/ui/skeleton';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';

interface Props {
  startDate: string;
  endDate: string;
}

interface KpiData {
  aReceber: number;
  aPagar: number;
  vencendoHoje: number;
  emAtraso: number;
  saldoProjetado: number;
}

export function FinKpiDashboard({ startDate, endDate }: Props) {
  const [data, setData] = useState<KpiData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchKpis();
  }, [startDate, endDate]);

  async function fetchKpis() {
    setLoading(true);
    const today = format(new Date(), 'yyyy-MM-dd');

    const [receber, pagar, vencHojeReceber, vencHojePagar, atrasoReceber, atrasoPagar] = await Promise.all([
      supabase
        .from('fin_contas_receber')
        .select('valor')
        .in('status', ['pendente', 'atrasado'])
        .gte('data_vencimento', startDate)
        .lte('data_vencimento', endDate),
      supabase
        .from('fin_contas_pagar')
        .select('valor')
        .in('status', ['pendente', 'atrasado'])
        .gte('data_vencimento', startDate)
        .lte('data_vencimento', endDate),
      supabase
        .from('fin_contas_receber')
        .select('id', { count: 'exact', head: true })
        .eq('data_vencimento', today)
        .eq('status', 'pendente'),
      supabase
        .from('fin_contas_pagar')
        .select('id', { count: 'exact', head: true })
        .eq('data_vencimento', today)
        .eq('status', 'pendente'),
      supabase
        .from('fin_contas_receber')
        .select('id', { count: 'exact', head: true })
        .lt('data_vencimento', today)
        .eq('status', 'atrasado'),
      supabase
        .from('fin_contas_pagar')
        .select('id', { count: 'exact', head: true })
        .lt('data_vencimento', today)
        .eq('status', 'atrasado'),
    ]);

    const totalReceber = (receber.data || []).reduce((s, r) => s + (r.valor || 0), 0);
    const totalPagar = (pagar.data || []).reduce((s, r) => s + (r.valor || 0), 0);

    setData({
      aReceber: totalReceber,
      aPagar: totalPagar,
      vencendoHoje: (vencHojeReceber.count || 0) + (vencHojePagar.count || 0),
      emAtraso: (atrasoReceber.count || 0) + (atrasoPagar.count || 0),
      saldoProjetado: totalReceber - totalPagar,
    });
    setLoading(false);
  }

  const formatCurrency = (v: number) =>
    v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

  const cards = data
    ? [
        { label: 'A RECEBER', value: formatCurrency(data.aReceber), color: 'text-primary' },
        { label: 'A PAGAR', value: formatCurrency(data.aPagar), color: 'text-[hsl(var(--status-danger))]' },
        { label: 'VENCENDO HOJE', value: String(data.vencendoHoje), color: 'text-[hsl(var(--status-warning))]' },
        { label: 'EM ATRASO', value: String(data.emAtraso), color: 'text-[hsl(var(--status-danger))]' },
        {
          label: 'SALDO PROJETADO',
          value: formatCurrency(data.saldoProjetado),
          color: data.saldoProjetado >= 0 ? 'text-[hsl(var(--status-success))]' : 'text-[hsl(var(--status-danger))]',
        },
      ]
    : [];

  if (loading) {
    return (
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
        {Array.from({ length: 5 }).map((_, i) => (
          <div key={i} className="h-[72px] rounded-xl border bg-card p-3">
            <Skeleton className="h-3 w-20 mb-2" />
            <Skeleton className="h-6 w-24" />
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
      {cards.map(card => (
        <div
          key={card.label}
          className="h-[72px] rounded-xl border border-border bg-card shadow-sm p-3 flex flex-col justify-center"
        >
          <span className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
            {card.label}
          </span>
          <span className={cn('text-[22px] font-semibold leading-tight', card.color)}>
            {card.value}
          </span>
        </div>
      ))}
    </div>
  );
}
