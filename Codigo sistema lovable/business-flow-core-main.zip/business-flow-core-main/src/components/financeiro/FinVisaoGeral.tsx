import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Wallet, ArrowDownCircle, ArrowUpCircle, AlertTriangle, TrendingUp, TrendingDown } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { format, subDays } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { cn } from '@/lib/utils';

interface OverviewData {
  lastBalance: number;
  lastBalanceDate: string | null;
  totalOpenReceivable: number;
  totalOpenPayable: number;
  overdueReceivable: number;
  overduePayable: number;
  lastReconciliationStatus: string | null;
  lastReconciliationDelta: number;
}

export function FinVisaoGeral() {
  const [data, setData] = useState<OverviewData>({
    lastBalance: 0,
    lastBalanceDate: null,
    totalOpenReceivable: 0,
    totalOpenPayable: 0,
    overdueReceivable: 0,
    overduePayable: 0,
    lastReconciliationStatus: null,
    lastReconciliationDelta: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadOverview();
  }, []);

  async function loadOverview() {
    setLoading(true);
    try {
      const today = format(new Date(), 'yyyy-MM-dd');

      // Last balance
      const { data: balances } = await supabase
        .from('fin_daily_balances')
        .select('reference_date, balance_amount')
        .order('reference_date', { ascending: false })
        .limit(50);

      let lastBalance = 0;
      let lastBalanceDate: string | null = null;
      if (balances && balances.length > 0) {
        // Group by date, sum
        const dateMap = new Map<string, number>();
        for (const b of balances) {
          const d = b.reference_date;
          dateMap.set(d, (dateMap.get(d) || 0) + Number(b.balance_amount));
        }
        const sorted = [...dateMap.entries()].sort((a, b) => b[0].localeCompare(a[0]));
        if (sorted.length > 0) {
          lastBalance = sorted[0][1];
          lastBalanceDate = sorted[0][0];
        }
      }

      // Open receivables
      const { data: recEntries } = await supabase
        .from('fin_entries')
        .select('amount_open, status_norm, due_date')
        .eq('entry_type', 'RECEBER')
        .eq('is_active', true)
        .in('status_norm', ['ABERTO', 'ATRASADO']);

      let totalOpenReceivable = 0;
      let overdueReceivable = 0;
      for (const e of recEntries || []) {
        const amt = Number(e.amount_open) || 0;
        totalOpenReceivable += amt;
        if (e.status_norm === 'ATRASADO' || (e.due_date && e.due_date < today)) {
          overdueReceivable += amt;
        }
      }

      // Open payables
      const { data: pagEntries } = await supabase
        .from('fin_entries')
        .select('amount_open, status_norm, due_date')
        .eq('entry_type', 'PAGAR')
        .eq('is_active', true)
        .in('status_norm', ['ABERTO', 'ATRASADO']);

      let totalOpenPayable = 0;
      let overduePayable = 0;
      for (const e of pagEntries || []) {
        const amt = Number(e.amount_open) || 0;
        totalOpenPayable += amt;
        if (e.status_norm === 'ATRASADO' || (e.due_date && e.due_date < today)) {
          overduePayable += amt;
        }
      }

      // Last reconciliation
      const { data: lastRec } = await supabase
        .from('fin_reconciliations')
        .select('status, delta')
        .order('reference_date', { ascending: false })
        .limit(1)
        .maybeSingle();

      setData({
        lastBalance,
        lastBalanceDate,
        totalOpenReceivable,
        totalOpenPayable,
        overdueReceivable,
        overduePayable,
        lastReconciliationStatus: lastRec?.status || null,
        lastReconciliationDelta: Number(lastRec?.delta) || 0,
      });
    } catch (err) {
      console.error('Error loading overview:', err);
    } finally {
      setLoading(false);
    }
  }

  const fmt = (v: number) =>
    v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mt-4">
        {Array.from({ length: 4 }).map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardContent className="p-6 h-28" />
          </Card>
        ))}
      </div>
    );
  }

  const cards = [
    {
      title: 'Saldo Atual',
      value: fmt(data.lastBalance),
      subtitle: data.lastBalanceDate
        ? `Ref: ${format(new Date(data.lastBalanceDate + 'T12:00:00'), 'dd/MM/yyyy')}`
        : 'Nenhum saldo registrado',
      icon: Wallet,
      color: 'text-blue-500',
      bg: 'bg-blue-500/10',
    },
    {
      title: 'A Receber (Aberto)',
      value: fmt(data.totalOpenReceivable),
      subtitle: data.overdueReceivable > 0 ? `${fmt(data.overdueReceivable)} vencido` : 'Nenhum vencido',
      icon: ArrowDownCircle,
      color: 'text-emerald-500',
      bg: 'bg-emerald-500/10',
      alert: data.overdueReceivable > 0,
    },
    {
      title: 'A Pagar (Aberto)',
      value: fmt(data.totalOpenPayable),
      subtitle: data.overduePayable > 0 ? `${fmt(data.overduePayable)} vencido` : 'Nenhum vencido',
      icon: ArrowUpCircle,
      color: 'text-red-500',
      bg: 'bg-red-500/10',
      alert: data.overduePayable > 0,
    },
    {
      title: 'Última Conferência',
      value: data.lastReconciliationStatus === 'BATEU'
        ? '✅ Bateu'
        : data.lastReconciliationStatus === 'NAO_BATEU'
          ? `⚠️ Δ ${fmt(data.lastReconciliationDelta)}`
          : '— Sem dados',
      subtitle: data.lastReconciliationStatus ? 'Conferência registrada' : 'Nenhuma conferência',
      icon: data.lastReconciliationStatus === 'BATEU' ? TrendingUp : AlertTriangle,
      color: data.lastReconciliationStatus === 'BATEU' ? 'text-emerald-500' : 'text-amber-500',
      bg: data.lastReconciliationStatus === 'BATEU' ? 'bg-emerald-500/10' : 'bg-amber-500/10',
    },
  ];

  return (
    <div className="space-y-6 mt-4">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {cards.map((card) => (
          <Card key={card.title} className="relative overflow-hidden">
            <CardContent className="p-5">
              <div className="flex items-start justify-between">
                <div className="space-y-1">
                  <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    {card.title}
                  </p>
                  <p className={cn('text-xl font-bold', card.color)}>{card.value}</p>
                  <p className={cn('text-xs', card.alert ? 'text-destructive font-medium' : 'text-muted-foreground')}>
                    {card.subtitle}
                  </p>
                </div>
                <div className={cn('p-2.5 rounded-xl', card.bg)}>
                  <card.icon className={cn('h-5 w-5', card.color)} />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Fluxo de Trabalho Diário</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {[
              { step: '1', title: 'Registrar Saldos', desc: 'Informe o saldo de cada conta bancária' },
              { step: '2', title: 'Importar Pagar/Receber', desc: 'Suba os arquivos XLS/CSV atualizados' },
              { step: '3', title: 'Conferir Caixa', desc: 'Rode a conferência com IA para verificar' },
              { step: '4', title: 'Analisar Projeção', desc: 'Veja o caixa futuro e identifique riscos' },
            ].map((item) => (
              <div key={item.step} className="flex gap-3 p-3 rounded-lg bg-muted/30">
                <div className="w-8 h-8 rounded-full bg-primary/10 text-primary font-bold flex items-center justify-center text-sm shrink-0">
                  {item.step}
                </div>
                <div>
                  <p className="text-sm font-medium">{item.title}</p>
                  <p className="text-xs text-muted-foreground">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
