import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Bot, CheckCircle2, AlertTriangle, Loader2 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';
import { format, subDays } from 'date-fns';
import { cn } from '@/lib/utils';

interface ReconciliationResult {
  status: string;
  openingBalance: number;
  reportedBalance: number;
  expectedBalance: number;
  delta: number;
  summary: string;
  suspects: any[];
}

export function FinConferenciaCaixa() {
  const [date, setDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [running, setRunning] = useState(false);
  const [result, setResult] = useState<ReconciliationResult | null>(null);
  const { user } = useAuth();
  const { toast } = useToast();

  async function runReconciliation() {
    if (!user) return;
    setRunning(true);
    setResult(null);

    try {
      const yesterday = format(subDays(new Date(date + 'T12:00:00'), 1), 'yyyy-MM-dd');

      // 1) Get yesterday's balance (opening)
      const { data: yesterdayBalances } = await supabase
        .from('fin_daily_balances')
        .select('balance_amount')
        .eq('reference_date', yesterday);

      const rawOpeningBalance = (yesterdayBalances || []).reduce((s, b) => s + Number(b.balance_amount), 0);
      const hasYesterdayBalance = yesterdayBalances && yesterdayBalances.length > 0;

      // 2) Get today's reported balance
      const { data: todayBalances } = await supabase
        .from('fin_daily_balances')
        .select('balance_amount')
        .eq('reference_date', date);

      const reportedBalance = (todayBalances || []).reduce((s, b) => s + Number(b.balance_amount), 0);

      if (!todayBalances || todayBalances.length === 0) {
        setResult({
          status: 'SEM_BASE',
          openingBalance: rawOpeningBalance,
          reportedBalance: 0,
          expectedBalance: 0,
          delta: 0,
          summary: 'Nenhum saldo informado para esta data. Registre os saldos na aba "Saldos" primeiro.',
          suspects: [],
        });
        setRunning(false);
        return;
      }

      // If no yesterday balance, use today's reported balance as initial/opening balance
      const openingBalance = hasYesterdayBalance ? rawOpeningBalance : reportedBalance;

      // 3) Get inflows (entries paid today)
      const { data: inflows } = await supabase
        .from('fin_entries')
        .select('party_name, amount_paid, amount_original, status_norm, description')
        .eq('entry_type', 'RECEBER')
        .eq('is_active', true)
        .eq('status_norm', 'PAGO')
        .eq('paid_date', date);

      const totalInflows = (inflows || []).reduce((s, e) => s + Number(e.amount_paid || e.amount_original), 0);

      // 4) Get outflows (entries paid today)
      const { data: outflows } = await supabase
        .from('fin_entries')
        .select('party_name, amount_paid, amount_original, status_norm, description')
        .eq('entry_type', 'PAGAR')
        .eq('is_active', true)
        .eq('status_norm', 'PAGO')
        .eq('paid_date', date);

      const totalOutflows = (outflows || []).reduce((s, e) => s + Number(e.amount_paid || e.amount_original), 0);

      // 5) Calculate expected
      const expectedBalance = openingBalance + totalInflows - totalOutflows;
      const delta = reportedBalance - expectedBalance;
      const threshold = Math.max(Math.abs(reportedBalance) * 0.005, 50); // 0.5% or R$50
      const status = Math.abs(delta) <= threshold ? 'BATEU' : 'NAO_BATEU';

      // 6) Build suspects
      const suspects: any[] = [];

      // Overdue receivables that should be paid
      const { data: overdueRec } = await supabase
        .from('fin_entries')
        .select('party_name, amount_open, due_date')
        .eq('entry_type', 'RECEBER')
        .eq('is_active', true)
        .eq('status_norm', 'ABERTO')
        .lt('due_date', date)
        .limit(5);

      if (overdueRec && overdueRec.length > 0) {
        suspects.push({
          type: 'overdue_receivable',
          label: 'Recebíveis vencidos não baixados',
          items: overdueRec.map(r => `${r.party_name}: ${fmt(Number(r.amount_open))} (venc: ${r.due_date})`),
        });
      }

      // Overdue payables
      const { data: overduePay } = await supabase
        .from('fin_entries')
        .select('party_name, amount_open, due_date')
        .eq('entry_type', 'PAGAR')
        .eq('is_active', true)
        .eq('status_norm', 'ABERTO')
        .lt('due_date', date)
        .limit(5);

      if (overduePay && overduePay.length > 0) {
        suspects.push({
          type: 'overdue_payable',
          label: 'Pagamentos vencidos não baixados',
          items: overduePay.map(r => `${r.party_name}: ${fmt(Number(r.amount_open))} (venc: ${r.due_date})`),
        });
      }

      // Missing accounts
      const { data: allAccounts } = await supabase
        .from('fin_accounts')
        .select('account_name')
        .eq('is_active', true);

      const reportedAccounts = new Set((todayBalances || []).map((b: any) => b.account_name));
      // We need to fetch account_name from balances
      const { data: todayBalancesDetail } = await supabase
        .from('fin_daily_balances')
        .select('account_name')
        .eq('reference_date', date);

      const reportedAccountNames = new Set((todayBalancesDetail || []).map(b => b.account_name));
      const missingAccounts = (allAccounts || [])
        .filter(a => !reportedAccountNames.has(a.account_name))
        .map(a => a.account_name);

      if (missingAccounts.length > 0) {
        suspects.push({
          type: 'missing_accounts',
          label: 'Contas sem saldo informado hoje',
          items: missingAccounts,
        });
      }

      // Build summary
      let summary = '';
      if (status === 'BATEU') {
        summary = `✅ Caixa conferido. Saldo informado (${fmt(reportedBalance)}) está alinhado com o esperado (${fmt(expectedBalance)}). Diferença: ${fmt(delta)}.`;
      } else {
        const direction = delta > 0 ? 'a mais' : 'a menos';
        summary = `⚠️ Diferença de ${fmt(Math.abs(delta))} (${direction}) entre o saldo informado (${fmt(reportedBalance)}) e o esperado (${fmt(expectedBalance)}).`;
        if (suspects.length > 0) {
          summary += ` Possíveis causas: ${suspects.map(s => s.label).join('; ')}.`;
        }
      }

      const reconcResult = {
        status,
        openingBalance,
        reportedBalance,
        expectedBalance,
        delta,
        summary,
        suspects,
      };

      // Save to database
      await supabase.from('fin_reconciliations').insert({
        reference_date: date,
        scope: 'PJ_ONLY',
        opening_balance_total: openingBalance,
        today_reported_balance_total: reportedBalance,
        expected_balance_total: expectedBalance,
        delta,
        status,
        summary_ai: summary,
        suspects_json: suspects,
        created_by_user_id: user.id,
      });

      setResult(reconcResult);
    } catch (err: any) {
      toast({ title: 'Erro', description: err.message, variant: 'destructive' });
    } finally {
      setRunning(false);
    }
  }

  const fmt = (v: number) => v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

  return (
    <div className="space-y-6 mt-4">
      <Card>
        <CardContent className="p-5">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
            <div className="space-y-1">
              <Label className="text-xs font-medium text-muted-foreground">Data de Referência</Label>
              <Input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-44"
              />
            </div>
            <div className="flex-1" />
            <Button onClick={runReconciliation} disabled={running} className="gap-2">
              {running ? <Loader2 className="h-4 w-4 animate-spin" /> : <Bot className="h-4 w-4" />}
              {running ? 'Rodando...' : 'Rodar Conferência'}
            </Button>
          </div>
        </CardContent>
      </Card>

      {result && (
        <div className="space-y-4">
          {/* Status Card */}
          <Card className={cn(
            'border-2',
            result.status === 'BATEU' ? 'border-emerald-500/50 bg-emerald-500/5' :
            result.status === 'NAO_BATEU' ? 'border-amber-500/50 bg-amber-500/5' :
            'border-muted'
          )}>
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                {result.status === 'BATEU' ? (
                  <CheckCircle2 className="h-10 w-10 text-emerald-500" />
                ) : result.status === 'NAO_BATEU' ? (
                  <AlertTriangle className="h-10 w-10 text-amber-500" />
                ) : (
                  <Bot className="h-10 w-10 text-muted-foreground" />
                )}
                <div className="flex-1">
                  <h3 className="text-lg font-bold">
                    {result.status === 'BATEU' ? 'BATEU ✅' : result.status === 'NAO_BATEU' ? 'NÃO BATEU ⚠️' : 'SEM BASE'}
                  </h3>
                  <p className="text-2xl font-bold font-mono mt-1">
                    Δ {fmt(result.delta)}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Breakdown */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardContent className="p-4 text-center">
                <p className="text-xs text-muted-foreground">Saldo Ontem (Abertura)</p>
                <p className="text-lg font-bold font-mono mt-1">{fmt(result.openingBalance)}</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 text-center">
                <p className="text-xs text-muted-foreground">Saldo Real Informado</p>
                <p className="text-lg font-bold font-mono mt-1 text-blue-500">{fmt(result.reportedBalance)}</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 text-center">
                <p className="text-xs text-muted-foreground">Saldo Esperado (Calculado)</p>
                <p className="text-lg font-bold font-mono mt-1 text-primary">{fmt(result.expectedBalance)}</p>
              </CardContent>
            </Card>
          </div>

          {/* Summary */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2">
                <Bot className="h-4 w-4 text-primary" />
                Resumo
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm">{result.summary}</p>
            </CardContent>
          </Card>

          {/* Suspects */}
          {result.suspects.length > 0 && (
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">🔍 Suspeitas Identificadas</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {result.suspects.map((s, i) => (
                  <div key={i}>
                    <p className="text-sm font-medium mb-1">{s.label}</p>
                    <ul className="space-y-1">
                      {s.items.map((item: string, j: number) => (
                        <li key={j} className="text-xs text-muted-foreground pl-3 border-l-2 border-amber-500/30">
                          {item}
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}
        </div>
      )}
    </div>
  );
}
