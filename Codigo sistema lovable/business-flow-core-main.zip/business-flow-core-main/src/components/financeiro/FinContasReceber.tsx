import { FinImportPanel } from './FinImportPanel';

export function FinContasReceber() {
  return <FinImportPanel entryType="RECEBER" />;
}
