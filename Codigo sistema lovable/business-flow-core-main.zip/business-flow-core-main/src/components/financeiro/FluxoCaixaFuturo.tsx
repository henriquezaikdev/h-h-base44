import { useState, useMemo, useCallback } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import {
  Table, TableHeader, TableHead, TableBody, TableRow, TableCell,
} from '@/components/ui/table';
import { AlertTriangle, TrendingUp, TrendingDown, Loader2, Search, X } from 'lucide-react';
import { format, addMonths, startOfMonth, endOfMonth, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { cn } from '@/lib/utils';
import { fetchAllPaginated } from '@/lib/paginatedQuery';

const formatCurrency = (v: number) =>
  new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(v);

interface FinEntry {
  id: string;
  descricao: string;
  valor: number;
  data_vencimento: string;
  status: string;
  counterpart: string;
  categoria: string | null;
  type: 'income' | 'expense';
}

interface MonthSummary {
  offset: number;
  label: string;
  startDate: string;
  endDate: string;
  income: number;
  expense: number;
  balance: number;
  entries: FinEntry[];
}

export function FluxoCaixaFuturo() {
  const queryClient = useQueryClient();
  const [syncing, setSyncing] = useState(false);
  const [selectedMonth, setSelectedMonth] = useState<number | null>(null);
  const [drillDownOpen, setDrillDownOpen] = useState(false);

  const now = new Date();

  // Calculate 3 future month ranges
  const monthRanges = useMemo(() => {
    return [1, 2, 3].map((offset) => {
      const start = startOfMonth(addMonths(now, offset));
      const end = endOfMonth(addMonths(now, offset));
      return {
        offset,
        label: format(start, 'MMM yyyy', { locale: ptBR }),
        startDate: format(start, 'yyyy-MM-dd'),
        endDate: format(end, 'yyyy-MM-dd'),
      };
    });
  }, []);

  // Fetch fixed expenses to merge into projections
  const { data: fixedExpenses = [] } = useQuery({
    queryKey: ['fixed-expenses-projection'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('fixed_expenses')
        .select('id, description, supplier, amount, frequency, day_of_month')
        .eq('active', true);
      if (error) throw error;
      return data || [];
    },
  });

  // Fetch entradas (fin_contas_receber) for all 3 months
  const { data: receberData = [], isLoading: loadingReceber } = useQuery({
    queryKey: ['projecao-receber', monthRanges[0].startDate, monthRanges[2].endDate],
    queryFn: async () => {
      return fetchAllPaginated<{
        id: string; descricao: string; valor: number;
        data_vencimento: string; status: string; cliente_nome: string | null; categoria: string | null;
      }>(() =>
        supabase.from('fin_contas_receber')
          .select('id, descricao, valor, data_vencimento, status, cliente_nome, categoria')
          .gte('data_vencimento', monthRanges[0].startDate)
          .lte('data_vencimento', monthRanges[2].endDate)
      );
    },
  });

  // Fetch saídas (fin_contas_pagar) for all 3 months
  const { data: pagarData = [], isLoading: loadingPagar } = useQuery({
    queryKey: ['projecao-pagar', monthRanges[0].startDate, monthRanges[2].endDate],
    queryFn: async () => {
      return fetchAllPaginated<{
        id: string; descricao: string; valor: number;
        data_vencimento: string; status: string; fornecedor: string | null; categoria: string | null;
        fixed_expense_id: string | null;
      }>(() =>
        supabase.from('fin_contas_pagar')
          .select('id, descricao, valor, data_vencimento, status, fornecedor, categoria, fixed_expense_id')
          .gte('data_vencimento', monthRanges[0].startDate)
          .lte('data_vencimento', monthRanges[2].endDate)
      );
    },
  });

  const isLoading = loadingReceber || loadingPagar;

  // Build entries and summaries, including fixed expenses as projected entries
  const monthlySummaries: MonthSummary[] = useMemo(() => {
    const allEntries: FinEntry[] = [
      ...receberData.map((r) => ({
        id: r.id,
        descricao: r.descricao,
        valor: r.valor,
        data_vencimento: r.data_vencimento,
        status: r.status,
        counterpart: r.cliente_nome || '-',
        categoria: r.categoria,
        type: 'income' as const,
      })),
      ...pagarData.map((r) => ({
        id: r.id,
        descricao: r.descricao,
        valor: r.valor,
        data_vencimento: r.data_vencimento,
        status: r.status,
        counterpart: r.fornecedor || '-',
        categoria: r.categoria,
        type: 'expense' as const,
      })),
    ];

    // Track which fixed_expense_ids already have real entries
    const coveredFixedIds = new Set(
      pagarData.filter(p => p.fixed_expense_id).map(p => p.fixed_expense_id!)
    );
    // Also match by supplier name
    const pagarSuppliers = new Map<string, Set<string>>();
    for (const p of pagarData) {
      if (p.fornecedor) {
        const monthKey = p.data_vencimento.substring(0, 7);
        const key = p.fornecedor.toLowerCase();
        if (!pagarSuppliers.has(key)) pagarSuppliers.set(key, new Set());
        pagarSuppliers.get(key)!.add(monthKey);
      }
    }

    return monthRanges.map((m) => {
      const entries = allEntries.filter(
        (e) => e.data_vencimento >= m.startDate && e.data_vencimento <= m.endDate
      );
      const monthKey = m.startDate.substring(0, 7);

      // Add fixed expenses not covered by real entries for this month
      for (const fe of fixedExpenses) {
        if (coveredFixedIds.has(fe.id)) continue;
        // Check supplier match for this month
        if (fe.supplier && pagarSuppliers.get(fe.supplier.toLowerCase())?.has(monthKey)) continue;

        const day = fe.day_of_month ? String(fe.day_of_month).padStart(2, '0') : '15';
        entries.push({
          id: `fe-${fe.id}-${monthKey}`,
          descricao: `[Fixa] ${fe.description}`,
          valor: Number(fe.amount),
          data_vencimento: `${monthKey}-${day}`,
          status: 'projetado',
          counterpart: fe.supplier || '-',
          categoria: null,
          type: 'expense',
        });
      }

      const income = entries.filter((e) => e.type === 'income').reduce((s, e) => s + e.valor, 0);
      const expense = entries.filter((e) => e.type === 'expense').reduce((s, e) => s + e.valor, 0);
      return {
        ...m,
        income,
        expense,
        balance: income - expense,
        entries,
      };
    });
  }, [receberData, pagarData, fixedExpenses, monthRanges]);

  // Drill-down data
  const drillDownData = useMemo(() => {
    if (selectedMonth === null) return null;
    const summary = monthlySummaries.find((m) => m.offset === selectedMonth);
    if (!summary) return null;

    // Group entries by day
    const byDay: Record<string, FinEntry[]> = {};
    for (const entry of summary.entries) {
      const day = entry.data_vencimento;
      if (!byDay[day]) byDay[day] = [];
      byDay[day].push(entry);
    }

    const sortedDays = Object.keys(byDay).sort();
    return { summary, days: sortedDays.map((day) => ({ day, entries: byDay[day] })) };
  }, [selectedMonth, monthlySummaries]);

  // Detect recurrences handler
  const handleDetectRecurrences = useCallback(async () => {
    setSyncing(true);
    try {
      const { data, error } = await supabase.functions.invoke('hh-sync-cash-flow');
      if (error) throw error;
      toast({
        title: 'Recorrências detectadas',
        description: `${data.recurrences} recorrências identificadas, ${data.projections} projeções geradas.`,
      });
      queryClient.invalidateQueries({ queryKey: ['projecao-receber'] });
      queryClient.invalidateQueries({ queryKey: ['projecao-pagar'] });
    } catch (err: any) {
      toast({ title: 'Erro', description: err.message, variant: 'destructive' });
    } finally {
      setSyncing(false);
    }
  }, [queryClient]);

  const handleCardClick = (offset: number) => {
    setSelectedMonth(offset);
    setDrillDownOpen(true);
  };

  return (
    <section className="space-y-6 font-['DM_Sans']">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold tracking-tight">Projeção Futura</h2>
        <Button
          variant="outline"
          size="sm"
          onClick={handleDetectRecurrences}
          disabled={syncing}
          className="gap-2"
        >
          {syncing ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
          Detectar Recorrências
        </Button>
      </div>

      {/* 3-month cards */}
      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-32 bg-muted animate-pulse rounded-xl" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {monthlySummaries.map((m) => (
            <Card
              key={m.offset}
              className={cn(
                'border bg-card shadow-sm cursor-pointer transition-all hover:shadow-md',
                m.balance < 0 && 'border-red-400 ring-1 ring-red-200'
              )}
              onClick={() => handleCardClick(m.offset)}
            >
              <CardContent className="p-5">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-sm font-semibold capitalize text-foreground">{m.label}</span>
                  <div className="flex items-center gap-1">
                    {m.balance < 0 && <AlertTriangle className="h-4 w-4 text-red-500" />}
                    <Badge variant="secondary" className="text-[10px]">
                      {m.entries.length} lançamentos
                    </Badge>
                  </div>
                </div>
                <div className="space-y-1.5">
                  <div className="flex justify-between text-[13px]">
                    <span className="text-muted-foreground flex items-center gap-1">
                      <TrendingUp className="h-3 w-3 text-emerald-500" /> Entradas
                    </span>
                    <span className="font-medium text-emerald-600">{formatCurrency(m.income)}</span>
                  </div>
                  <div className="flex justify-between text-[13px]">
                    <span className="text-muted-foreground flex items-center gap-1">
                      <TrendingDown className="h-3 w-3 text-red-500" /> Saídas
                    </span>
                    <span className="font-medium text-red-500">{formatCurrency(m.expense)}</span>
                  </div>
                  <div className="border-t border-border/40 pt-1.5 flex justify-between text-[13px]">
                    <span className="font-semibold">Saldo Projetado</span>
                    <span className={cn('font-bold', m.balance >= 0 ? 'text-[#3B5BDB]' : 'text-red-600')}>
                      {formatCurrency(m.balance)}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Summary row */}
      {!isLoading && (
        <div className="flex items-center gap-6 px-4 py-3 rounded-xl border border-border/50 bg-card text-[13px]">
          <span className="text-muted-foreground">Total 3 meses:</span>
          <span className="flex items-center gap-1 text-emerald-600 font-medium">
            <TrendingUp className="h-3 w-3" />
            {formatCurrency(monthlySummaries.reduce((s, m) => s + m.income, 0))}
          </span>
          <span className="flex items-center gap-1 text-red-500 font-medium">
            <TrendingDown className="h-3 w-3" />
            {formatCurrency(monthlySummaries.reduce((s, m) => s + m.expense, 0))}
          </span>
          <span className={cn(
            'font-bold',
            monthlySummaries.reduce((s, m) => s + m.balance, 0) >= 0 ? 'text-[#3B5BDB]' : 'text-red-600'
          )}>
            Saldo: {formatCurrency(monthlySummaries.reduce((s, m) => s + m.balance, 0))}
          </span>
        </div>
      )}

      {/* Drill-down dialog */}
      <Dialog open={drillDownOpen} onOpenChange={setDrillDownOpen}>
        <DialogContent className="sm:max-w-4xl max-h-[85vh] overflow-y-auto">
          {drillDownData && (
            <>
              <DialogHeader>
                <DialogTitle className="capitalize flex items-center gap-2">
                  Lançamentos — {drillDownData.summary.label}
                  <Badge variant="secondary" className="text-[10px]">
                    {drillDownData.summary.entries.length} registros
                  </Badge>
                </DialogTitle>
              </DialogHeader>

              {/* Summary cards inside dialog */}
              <div className="grid grid-cols-3 gap-3 my-4">
                <div className="rounded-lg border border-border/40 p-3 bg-emerald-50/50">
                  <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Entradas</p>
                  <p className="text-lg font-bold text-emerald-600">{formatCurrency(drillDownData.summary.income)}</p>
                </div>
                <div className="rounded-lg border border-border/40 p-3 bg-red-50/50">
                  <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Saídas</p>
                  <p className="text-lg font-bold text-red-500">{formatCurrency(drillDownData.summary.expense)}</p>
                </div>
                <div className={cn(
                  'rounded-lg border border-border/40 p-3',
                  drillDownData.summary.balance >= 0 ? 'bg-blue-50/50' : 'bg-red-50/50'
                )}>
                  <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Saldo</p>
                  <p className={cn('text-lg font-bold', drillDownData.summary.balance >= 0 ? 'text-[#3B5BDB]' : 'text-red-600')}>
                    {formatCurrency(drillDownData.summary.balance)}
                  </p>
                </div>
              </div>

              {/* Day-by-day tables */}
              <div className="space-y-4">
                {drillDownData.days.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-8">Nenhum lançamento neste mês.</p>
                ) : (
                  drillDownData.days.map(({ day, entries }) => {
                    const dayTotal = entries.reduce((s, e) => s + (e.type === 'income' ? e.valor : -e.valor), 0);
                    return (
                      <div key={day} className="rounded-lg border border-border/40 overflow-hidden">
                        <div className="flex items-center justify-between px-4 py-2 bg-muted/30">
                          <span className="text-[13px] font-semibold">
                            {format(parseISO(day), "dd 'de' MMMM", { locale: ptBR })}
                          </span>
                          <span className={cn(
                            'text-[12px] font-semibold',
                            dayTotal >= 0 ? 'text-emerald-600' : 'text-red-500'
                          )}>
                            Saldo: {formatCurrency(dayTotal)}
                          </span>
                        </div>
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead className="text-[10px] uppercase font-semibold">Tipo</TableHead>
                              <TableHead className="text-[10px] uppercase font-semibold">Descrição</TableHead>
                              <TableHead className="text-[10px] uppercase font-semibold">Cliente/Fornecedor</TableHead>
                              <TableHead className="text-[10px] uppercase font-semibold">Categoria</TableHead>
                              <TableHead className="text-[10px] uppercase font-semibold">Status</TableHead>
                              <TableHead className="text-[10px] uppercase font-semibold text-right">Valor</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {entries.map((e) => (
                              <TableRow key={e.id}>
                                <TableCell>
                                  {e.type === 'income' ? (
                                    <Badge variant="outline" className="text-[9px] bg-emerald-50 text-emerald-700 border-emerald-300">Entrada</Badge>
                                  ) : (
                                    <Badge variant="outline" className="text-[9px] bg-red-50 text-red-700 border-red-300">Saída</Badge>
                                  )}
                                </TableCell>
                                <TableCell className="text-[12px] max-w-[200px] truncate">{e.descricao}</TableCell>
                                <TableCell className="text-[12px] text-muted-foreground max-w-[150px] truncate">{e.counterpart}</TableCell>
                                <TableCell className="text-[12px] text-muted-foreground">{e.categoria || '-'}</TableCell>
                                <TableCell>
                                  <Badge variant="outline" className={cn(
                                    'text-[9px]',
                                    e.status === 'recebido' || e.status === 'pago'
                                      ? 'bg-emerald-50 text-emerald-700 border-emerald-300'
                                      : e.status === 'atrasado'
                                        ? 'bg-red-50 text-red-700 border-red-300'
                                        : 'bg-amber-50 text-amber-700 border-amber-300'
                                  )}>
                                    {e.status}
                                  </Badge>
                                </TableCell>
                                <TableCell className={cn(
                                  'text-[12px] text-right font-medium',
                                  e.type === 'income' ? 'text-emerald-600' : 'text-red-500'
                                )}>
                                  {formatCurrency(e.valor)}
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    );
                  })
                )}
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </section>
  );
}
