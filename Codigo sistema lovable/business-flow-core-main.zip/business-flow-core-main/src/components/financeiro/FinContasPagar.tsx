import { FinImportPanel } from './FinImportPanel';

export function FinContasPagar() {
  return <FinImportPanel entryType="PAGAR" />;
}
