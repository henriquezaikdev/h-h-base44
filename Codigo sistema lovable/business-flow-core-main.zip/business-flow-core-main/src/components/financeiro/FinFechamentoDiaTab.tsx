import { useState, useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Table, TableHeader, TableHead, TableBody, TableRow, TableCell,
} from '@/components/ui/table';
import { CalendarIcon, TrendingUp, TrendingDown, Wallet, Loader2, CheckCircle2, Clock } from 'lucide-react';
import { cn } from '@/lib/utils';

const formatCurrency = (v: number) =>
  new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(v);

const FORMAS = ['Boleto', 'Cartão', 'PIX', 'Transferência', 'Outros'] as const;

function inferFormaPagamento(descricao: string, categoria: string | null): string {
  const text = `${descricao} ${categoria || ''}`.toLowerCase();
  if (text.includes('pix')) return 'PIX';
  if (text.includes('boleto')) return 'Boleto';
  if (text.includes('cartão') || text.includes('cartao') || text.includes('card')) return 'Cartão';
  if (text.includes('transferência') || text.includes('transferencia') || text.includes('ted') || text.includes('doc')) return 'Transferência';
  return 'Outros';
}

interface EntryRow {
  id: string;
  descricao: string;
  counterpart: string;
  forma: string;
  valor: number;
  statusLabel: 'realizado' | 'previsto';
}

export function FinFechamentoDiaTab() {
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const dateStr = format(selectedDate, 'yyyy-MM-dd');

  // Fetch entradas: paid on date OR due on date (pending)
  const { data: receber = [], isLoading: loadingReceber } = useQuery({
    queryKey: ['fechamento-receber', dateStr],
    queryFn: async () => {
      // Realizados: data_recebimento = date
      const { data: pagos, error: e1 } = await supabase
        .from('fin_contas_receber')
        .select('id, descricao, cliente_nome, categoria, valor, data_recebimento, data_vencimento, status')
        .eq('data_recebimento', dateStr)
        .eq('status', 'recebido');
      if (e1) throw e1;

      // Previstos: data_vencimento = date AND not yet paid
      const { data: pendentes, error: e2 } = await supabase
        .from('fin_contas_receber')
        .select('id, descricao, cliente_nome, categoria, valor, data_recebimento, data_vencimento, status')
        .eq('data_vencimento', dateStr)
        .neq('status', 'recebido');
      if (e2) throw e2;

      const seen = new Set<string>();
      const result: EntryRow[] = [];

      for (const r of (pagos || [])) {
        seen.add(r.id);
        result.push({
          id: r.id,
          descricao: r.descricao,
          counterpart: r.cliente_nome || '-',
          forma: inferFormaPagamento(r.descricao, r.categoria),
          valor: r.valor,
          statusLabel: 'realizado',
        });
      }
      for (const r of (pendentes || [])) {
        if (seen.has(r.id)) continue;
        result.push({
          id: r.id,
          descricao: r.descricao,
          counterpart: r.cliente_nome || '-',
          forma: inferFormaPagamento(r.descricao, r.categoria),
          valor: r.valor,
          statusLabel: 'previsto',
        });
      }
      return result;
    },
  });

  // Fetch saídas: paid on date OR due on date (pending)
  const { data: pagar = [], isLoading: loadingPagar } = useQuery({
    queryKey: ['fechamento-pagar', dateStr],
    queryFn: async () => {
      const { data: pagos, error: e1 } = await supabase
        .from('fin_contas_pagar')
        .select('id, descricao, fornecedor, categoria, valor, data_pagamento, data_vencimento, status')
        .eq('data_pagamento', dateStr)
        .eq('status', 'pago');
      if (e1) throw e1;

      const { data: pendentes, error: e2 } = await supabase
        .from('fin_contas_pagar')
        .select('id, descricao, fornecedor, categoria, valor, data_pagamento, data_vencimento, status')
        .eq('data_vencimento', dateStr)
        .neq('status', 'pago');
      if (e2) throw e2;

      const seen = new Set<string>();
      const result: EntryRow[] = [];

      for (const r of (pagos || [])) {
        seen.add(r.id);
        result.push({
          id: r.id,
          descricao: r.descricao,
          counterpart: r.fornecedor || '-',
          forma: inferFormaPagamento(r.descricao, r.categoria),
          valor: r.valor,
          statusLabel: 'realizado',
        });
      }
      for (const r of (pendentes || [])) {
        if (seen.has(r.id)) continue;
        result.push({
          id: r.id,
          descricao: r.descricao,
          counterpart: r.fornecedor || '-',
          forma: inferFormaPagamento(r.descricao, r.categoria),
          valor: r.valor,
          statusLabel: 'previsto',
        });
      }
      return result;
    },
  });

  const loading = loadingReceber || loadingPagar;

  // Separate by status
  const entradasRealizadas = useMemo(() => receber.filter(r => r.statusLabel === 'realizado'), [receber]);
  const entradasPrevistas = useMemo(() => receber.filter(r => r.statusLabel === 'previsto'), [receber]);
  const saidasRealizadas = useMemo(() => pagar.filter(r => r.statusLabel === 'realizado'), [pagar]);
  const saidasPrevistas = useMemo(() => pagar.filter(r => r.statusLabel === 'previsto'), [pagar]);

  const totalEntradas = useMemo(() => receber.reduce((s, r) => s + r.valor, 0), [receber]);
  const totalSaidas = useMemo(() => pagar.reduce((s, r) => s + r.valor, 0), [pagar]);
  const saldo = totalEntradas - totalSaidas;

  // Group by forma
  const groupByForma = (items: EntryRow[]) => {
    const groups: Record<string, EntryRow[]> = {};
    for (const item of items) {
      if (!groups[item.forma]) groups[item.forma] = [];
      groups[item.forma].push(item);
    }
    return groups;
  };

  // All items for footer totals
  const allItems = useMemo(() => [...receber, ...pagar], [receber, pagar]);
  const totaisByForma = useMemo(() => {
    const totals: Record<string, number> = {};
    for (const forma of FORMAS) {
      const total = allItems.filter(i => i.forma === forma).reduce((s, r) => s + r.valor, 0);
      if (total > 0) totals[forma] = total;
    }
    return totals;
  }, [allItems]);

  function GroupedTable({ items, emptyLabel }: { items: EntryRow[]; emptyLabel: string }) {
    const groups = groupByForma(items);
    const formas = Object.keys(groups).sort();
    if (formas.length === 0) {
      return <p className="text-xs text-muted-foreground py-4 text-center">{emptyLabel}</p>;
    }
    return (
      <div className="space-y-3">
        {formas.map(forma => {
          const fItems = groups[forma];
          const subtotal = fItems.reduce((s, r) => s + r.valor, 0);
          return (
            <div key={forma}>
              <div className="flex items-center justify-between mb-1">
                <span className="text-[11px] uppercase tracking-wider font-semibold text-muted-foreground">{forma}</span>
                <span className="text-[11px] font-semibold text-foreground">{formatCurrency(subtotal)}</span>
              </div>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-[10px] uppercase font-semibold">Descrição</TableHead>
                    <TableHead className="text-[10px] uppercase font-semibold">Cliente/Fornecedor</TableHead>
                    <TableHead className="text-[10px] uppercase font-semibold text-right">Valor</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {fItems.map(item => (
                    <TableRow key={item.id}>
                      <TableCell className="text-[13px]">{item.descricao}</TableCell>
                      <TableCell className="text-[13px] text-muted-foreground">{item.counterpart}</TableCell>
                      <TableCell className="text-[13px] text-right font-medium">{formatCurrency(item.valor)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          );
        })}
      </div>
    );
  }

  function SectionBlock({ title, icon, iconColor, realizados, previstos, type }: {
    title: string;
    icon: React.ReactNode;
    iconColor: string;
    realizados: EntryRow[];
    previstos: EntryRow[];
    type: 'income' | 'expense';
  }) {
    const total = [...realizados, ...previstos].reduce((s, r) => s + r.valor, 0);
    return (
      <div className="bg-card border border-border/50 rounded-xl p-5 shadow-sm">
        <h3 className="text-sm font-semibold mb-4 flex items-center gap-2">
          {icon}
          {title}
          <Badge variant="secondary" className="text-[10px]">{realizados.length + previstos.length}</Badge>
          <span className="ml-auto text-[13px] font-bold">
            {formatCurrency(total)}
          </span>
        </h3>

        {/* Realizados */}
        {(realizados.length > 0 || previstos.length === 0) && (
          <div className="mb-4">
            <div className="flex items-center gap-1.5 mb-2">
              <CheckCircle2 className="h-3.5 w-3.5 text-emerald-500" />
              <span className="text-[11px] uppercase tracking-wider font-semibold text-emerald-700">
                Realizados
              </span>
              <Badge variant="secondary" className="text-[9px] ml-1">{realizados.length}</Badge>
            </div>
            <GroupedTable items={realizados} emptyLabel="Nenhum lançamento realizado" />
          </div>
        )}

        {/* Previstos */}
        {(previstos.length > 0 || realizados.length === 0) && (
          <div>
            <div className="flex items-center gap-1.5 mb-2">
              <Clock className="h-3.5 w-3.5 text-amber-500" />
              <span className="text-[11px] uppercase tracking-wider font-semibold text-amber-700">
                Previstos
              </span>
              <Badge variant="secondary" className="text-[9px] ml-1">{previstos.length}</Badge>
            </div>
            <GroupedTable items={previstos} emptyLabel="Nenhum lançamento previsto" />
          </div>
        )}
      </div>
    );
  }

  return (
    <section className="space-y-6 font-['DM_Sans']">
      {/* Date selector */}
      <div className="flex items-center gap-3">
        <Popover>
          <PopoverTrigger asChild>
            <Button variant="outline" className="gap-2 text-sm">
              <CalendarIcon className="h-4 w-4" />
              {format(selectedDate, "dd 'de' MMMM 'de' yyyy", { locale: ptBR })}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0" align="start">
            <Calendar
              mode="single"
              selected={selectedDate}
              onSelect={(d) => d && setSelectedDate(d)}
              initialFocus
              className={cn("p-3 pointer-events-auto")}
            />
          </PopoverContent>
        </Popover>
        {loading && <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />}
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-card border border-border/50 rounded-xl p-5 shadow-sm">
          <div className="flex items-center gap-2 mb-2">
            <TrendingUp className="h-4 w-4 text-emerald-500" />
            <span className="text-[11px] uppercase tracking-widest text-muted-foreground font-semibold">Total Entradas</span>
          </div>
          <p className="text-2xl font-bold text-emerald-600">{formatCurrency(totalEntradas)}</p>
          <p className="text-[11px] text-muted-foreground mt-1">
            {entradasRealizadas.length} realizado(s) · {entradasPrevistas.length} previsto(s)
          </p>
        </div>
        <div className="bg-card border border-border/50 rounded-xl p-5 shadow-sm">
          <div className="flex items-center gap-2 mb-2">
            <TrendingDown className="h-4 w-4 text-red-500" />
            <span className="text-[11px] uppercase tracking-widest text-muted-foreground font-semibold">Total Saídas</span>
          </div>
          <p className="text-2xl font-bold text-red-500">{formatCurrency(totalSaidas)}</p>
          <p className="text-[11px] text-muted-foreground mt-1">
            {saidasRealizadas.length} realizado(s) · {saidasPrevistas.length} previsto(s)
          </p>
        </div>
        <div className={cn(
          "bg-card border rounded-xl p-5 shadow-sm",
          saldo >= 0 ? 'border-border/50' : 'border-red-400 ring-1 ring-red-200'
        )}>
          <div className="flex items-center gap-2 mb-2">
            <Wallet className="h-4 w-4 text-[#3B5BDB]" />
            <span className="text-[11px] uppercase tracking-widest text-muted-foreground font-semibold">Saldo do Dia</span>
          </div>
          <p className={cn("text-2xl font-bold", saldo >= 0 ? 'text-[#3B5BDB]' : 'text-red-600')}>
            {formatCurrency(saldo)}
          </p>
        </div>
      </div>

      {/* Entradas section */}
      <SectionBlock
        title="Entradas"
        icon={<TrendingUp className="h-4 w-4 text-emerald-500" />}
        iconColor="emerald"
        realizados={entradasRealizadas}
        previstos={entradasPrevistas}
        type="income"
      />

      {/* Saídas section */}
      <SectionBlock
        title="Saídas"
        icon={<TrendingDown className="h-4 w-4 text-red-500" />}
        iconColor="red"
        realizados={saidasRealizadas}
        previstos={saidasPrevistas}
        type="expense"
      />

      {/* Footer: totals by forma */}
      {Object.keys(totaisByForma).length > 0 && (
        <div className="bg-card border border-border/50 rounded-xl p-4 shadow-sm">
          <p className="text-[11px] uppercase tracking-widest text-muted-foreground font-semibold mb-3">
            Movimentação por Forma de Pagamento
          </p>
          <div className="flex flex-wrap gap-4">
            {Object.entries(totaisByForma).map(([forma, total]) => (
              <div key={forma} className="flex items-center gap-2 text-[13px]">
                <span className="font-medium text-foreground">{forma}:</span>
                <span className="font-semibold text-[#3B5BDB]">{formatCurrency(total)}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </section>
  );
}
