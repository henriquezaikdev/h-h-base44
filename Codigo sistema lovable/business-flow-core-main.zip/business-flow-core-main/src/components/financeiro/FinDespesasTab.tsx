import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { fetchAllPaginated } from '@/lib/paginatedQuery';
import {
  Table, TableHeader, TableHead, TableBody, TableRow, TableCell, TableFooter,
} from '@/components/ui/table';
import { CollapsibleDataSection, DataSkeleton } from '@/components/ui/CollapsibleDataSection';

interface Props {
  startDate: string;
  endDate: string;
}

interface CategoriaRow {
  categoria: string;
  quantidade: number;
  total: number;
}

export function FinDespesasTab({ startDate, endDate }: Props) {
  const [expanded, setExpanded] = useState(false);
  const [count, setCount] = useState<number | null>(null);
  const [loadingCount, setLoadingCount] = useState(true);
  const [data, setData] = useState<CategoriaRow[]>([]);
  const [loadingData, setLoadingData] = useState(false);

  useEffect(() => {
    fetchCount();
    setData([]);
    setExpanded(false);
  }, [startDate, endDate]);

  useEffect(() => {
    if (expanded && data.length === 0) fetchData();
  }, [expanded]);

  async function fetchCount() {
    setLoadingCount(true);
    const { count: c } = await supabase
      .from('fin_contas_pagar')
      .select('*', { count: 'exact', head: true })
      .gte('data_vencimento', startDate)
      .lte('data_vencimento', endDate)
      .eq('origem', 'conta_azul');
    setCount(c || 0);
    setLoadingCount(false);
  }

  async function fetchData() {
    setLoadingData(true);
    // Fetch ALL records using pagination to avoid 1000-row limit
    const rows = await fetchAllPaginated<{ categoria: string | null; valor: number }>(() =>
      supabase.from('fin_contas_pagar')
        .select('categoria, valor')
        .gte('data_vencimento', startDate)
        .lte('data_vencimento', endDate)
        .eq('origem', 'conta_azul')
    );

    const map = new Map<string, { total: number; count: number }>();
    for (const r of rows) {
      const cat = r.categoria || 'Sem categoria';
      const existing = map.get(cat) || { total: 0, count: 0 };
      existing.total += Number(r.valor) || 0;
      existing.count += 1;
      map.set(cat, existing);
    }

    const grouped: CategoriaRow[] = [...map.entries()]
      .map(([categoria, { total, count }]) => ({ categoria, quantidade: count, total }))
      .sort((a, b) => b.total - a.total);

    setData(grouped);
    setLoadingData(false);
  }

  const formatCurrency = (v: number) =>
    v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

  const grandTotal = data.reduce((s, r) => s + r.total, 0);
  const grandCount = data.reduce((s, r) => s + r.quantidade, 0);

  return (
    <div className="space-y-4">
      <CollapsibleDataSection
        title="Despesas por Categoria"
        count={count}
        loadingCount={loadingCount}
        expanded={expanded}
        onToggle={() => setExpanded(v => !v)}
      >
        {loadingData ? (
          <DataSkeleton />
        ) : data.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground text-sm">
            Nenhuma despesa encontrada para este período.
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="text-[11px] uppercase font-semibold">Categoria</TableHead>
                <TableHead className="text-[11px] uppercase font-semibold text-center">Quantidade</TableHead>
                <TableHead className="text-[11px] uppercase font-semibold text-right">Total</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {data.map(row => (
                <TableRow key={row.categoria}>
                  <TableCell className="text-[13px]">{row.categoria}</TableCell>
                  <TableCell className="text-[13px] text-center">{row.quantidade}</TableCell>
                  <TableCell className="text-[13px] text-right font-medium">{formatCurrency(row.total)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
            <TableFooter>
              <TableRow className="bg-muted/50 font-semibold">
                <TableCell className="text-[13px]">TOTAL DESPESAS</TableCell>
                <TableCell className="text-[13px] text-center">{grandCount}</TableCell>
                <TableCell className="text-[13px] text-right">{formatCurrency(grandTotal)}</TableCell>
              </TableRow>
            </TableFooter>
          </Table>
        )}
      </CollapsibleDataSection>
    </div>
  );
}
