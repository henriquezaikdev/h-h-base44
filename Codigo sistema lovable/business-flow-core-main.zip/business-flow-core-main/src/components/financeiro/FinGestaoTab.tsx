import { useState, useEffect, useCallback } from 'react';
import { 
  TrendingUp, 
  Building2,
  Users,
  Eye,
  ChevronRight,
  Loader2,
  RefreshCw,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import { GestorHistoryChart } from '@/components/gestor/GestorHistoryChart';
import { CostWaterfallChart } from '@/components/gestor/CostWaterfallChart';
import { BreakEvenCard } from '@/components/gestor/BreakEvenCard';
import { Phase2CompanyCosts } from '@/components/gestor/Phase2CompanyCosts';
import { Phase1CostPanel } from '@/components/gestor/Phase1CostPanel';
import { SellerResultCard } from '@/components/gestor/SellerResultCard';
import { GestorKPICards } from '@/components/gestor/GestorKPICards';
import { SimuladorContratacao } from '@/components/gestor/SimuladorContratacao';
import { useCEEDinamico } from '@/hooks/useCEEDinamico';
import { useGestorData, GestorFilters } from '@/hooks/useGestorData';
import { useGestorConfig } from '@/hooks/useGestorConfig';
import { supabase } from '@/integrations/supabase/client';
import { startOfMonth, endOfMonth, format } from 'date-fns';
import { useAuth } from '@/hooks/useAuth';

export function FinGestaoTab() {
  const { isOwner } = useAuth();
  const [companyCostsOpen, setCompanyCostsOpen] = useState(false);
  const [costSheetOpen, setCostSheetOpen] = useState(false);
  const [selectedSeller, setSelectedSeller] = useState<{
    id: string;
    name: string;
    revenue: number;
    marginBruta: number;
    comissaoReal: number;
    comissaoPercentual: number;
  } | null>(null);
  const [detailsExpanded, setDetailsExpanded] = useState(false);
  const [selectedSellerId, setSelectedSellerId] = useState<string | null>(null);

  const filters: GestorFilters = {
    startDate: startOfMonth(new Date()),
    endDate: endOfMonth(new Date()),
    sellerId: null,
    includesPending: false,
  };

  const { kpis, sellersResult, loading, activeSellersCount } = useGestorData(filters);
  const { config: gestorConfig } = useGestorConfig();
  const cee = useCEEDinamico();

  const handleEditCost = (seller: { id: string; name: string; revenue: number; marginBruta: number; comissaoReal: number; comissaoPercentual: number }) => {
    setSelectedSeller(seller);
    setCostSheetOpen(true);
  };

  const handleSelectSeller = (sellerId: string) => {
    setSelectedSellerId(prev => prev === sellerId ? null : sellerId);
  };

  const fmt = (v: number) =>
    v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

  if (loading || !kpis) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6 mt-4">
      {/* CEE DINÂMICO - RESUMO EXECUTIVO */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-5">
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Receita do Mês</p>
            <p className="text-xl font-bold text-emerald-600 dark:text-emerald-400 mt-1">
              {fmt(kpis.revenue)}
            </p>
            <p className="text-xs text-muted-foreground mt-1">{kpis.ordersCount} pedidos</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-5">
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">CMV</p>
            <p className="text-xl font-bold text-foreground mt-1">
              {fmt(kpis.revenue - kpis.profit)}
            </p>
            <p className="text-xs text-muted-foreground mt-1">Margem Bruta: {fmt(kpis.profit)}</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-5">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
                  CEE Executado
                  {cee.loading && <Loader2 className="h-3 w-3 inline ml-1 animate-spin" />}
                </p>
                <p className="text-xl font-bold text-orange-600 dark:text-orange-400 mt-1">
                  {fmt(cee.ceeExecutado)}
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  Despesas empresariais pagas
                </p>
              </div>
              <Button variant="ghost" size="icon" className="h-7 w-7" onClick={cee.refresh}>
                <RefreshCw className="h-3.5 w-3.5" />
              </Button>
            </div>
            {cee.despesasPessoais > 0 && (
              <p className="text-xs text-muted-foreground mt-1">
                Pessoais (excl.): {fmt(cee.despesasPessoais)}
              </p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-5">
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Resultado Real</p>
            <p className={cn(
              'text-xl font-bold mt-1',
              kpis.lucroRealTotal >= 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-destructive'
            )}>
              {fmt(kpis.lucroRealTotal)}
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              Receita − CMV − CDV − CEE
            </p>
          </CardContent>
        </Card>
      </div>

      {/* PONTO DE EQUILÍBRIO */}
      <BreakEvenCard
        receita={kpis.revenue}
        lucroBruto={kpis.profit || 0}
        ceeLimpo={gestorConfig?.despesas_fixas_base || 24026.49}
        prolaboreTotal={gestorConfig?.prolabore_total || 14956.45}
        emprestimosTotal={gestorConfig?.emprestimos_total || 7000.00}
        impostosVendas={kpis.totalImpostosVendas || 0}
        custoHumanoTotal={kpis.totalCustoHumano || 0}
        cdvTotal={kpis.totalCDV || 0}
      />

      {/* GRÁFICO HISTÓRICO */}
      <section>
        <div className="flex items-center gap-2 mb-4">
          <TrendingUp className="h-5 w-5 text-primary" />
          <h2 className="text-lg font-semibold">Histórico de Margem</h2>
        </div>
        <GestorHistoryChart />
      </section>

      {/* WATERFALL - COMPOSIÇÃO DO RESULTADO */}
      <CostWaterfallChart
        lucroBruto={kpis.profit || 0}
        cdvTotal={kpis.totalCDV || 0}
        custoHumano={kpis.totalCustoHumano || 0}
        ceeTotal={cee.ceeExecutado || kpis.totalCEE || 0}
        resultadoReal={kpis.lucroRealTotal || 0}
      />

      {/* BOTÃO PARA CONFIGURAR CEE */}
      <div className="flex justify-center">
        <Button 
          variant="outline" 
          onClick={() => setCompanyCostsOpen(true)}
          className="gap-2"
        >
          <Building2 className="h-4 w-4" />
          Configurar CEE (Custo Estrutural da Empresa)
        </Button>
      </div>

      {/* DRILL-DOWN - Análises Detalhadas */}
      <section>
        <Collapsible open={detailsExpanded} onOpenChange={setDetailsExpanded}>
          <CollapsibleTrigger asChild>
            <Button variant="outline" className="w-full gap-2">
              <Eye className="h-4 w-4" />
              {detailsExpanded ? 'Ocultar' : 'Ver'} Análises Detalhadas
              <ChevronRight className={cn(
                'h-4 w-4 transition-transform',
                detailsExpanded && 'rotate-90'
              )} />
            </Button>
          </CollapsibleTrigger>
          <CollapsibleContent className="mt-4 space-y-6">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <TrendingUp className="h-5 w-5 text-primary" />
                <h3 className="text-md font-semibold">KPIs Executivos Detalhados</h3>
              </div>
              <GestorKPICards kpis={kpis} />
            </div>

            <div>
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <Users className="h-5 w-5 text-primary" />
                  <h3 className="text-md font-semibold">Cards de Vendedores (Configurar Custos)</h3>
                </div>
                <span className="text-xs text-muted-foreground">
                  Clique em ⚙️ para configurar custos
                </span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                {sellersResult.map((seller, index) => (
                  <SellerResultCard
                    key={seller.id}
                    seller={seller}
                    rank={index + 1}
                    isSelected={selectedSellerId === seller.id}
                    onSelect={() => handleSelectSeller(seller.id)}
                    onEditCost={() => handleEditCost({
                      id: seller.id,
                      name: seller.name,
                      revenue: seller.revenue,
                      marginBruta: seller.marginBruta,
                      comissaoReal: seller.comissaoReal,
                      comissaoPercentual: seller.comissaoPercentual,
                    })}
                  />
                ))}
              </div>
            </div>
          </CollapsibleContent>
        </Collapsible>
      </section>

      {/* SIMULADOR DE CONTRATAÇÃO - Owner only */}
      {isOwner && (
        <SimuladorContratacao
          kpis={kpis}
          sellersResult={sellersResult}
          activeSellersCount={activeSellersCount}
        />
      )}

      {/* Sheet para Custo do Vendedor (Fase 1) */}
      <Sheet open={costSheetOpen} onOpenChange={setCostSheetOpen}>
        <SheetContent className="w-full sm:max-w-xl overflow-y-auto">
          <SheetHeader>
            <SheetTitle className="flex items-center gap-2">
              <Users className="h-5 w-5 text-primary" />
              FASE 1 — Custo Direto do Vendedor
            </SheetTitle>
            <p className="text-sm text-muted-foreground">
              {selectedSeller?.name}
            </p>
          </SheetHeader>
          
          {selectedSeller && (
            <div className="mt-6">
              <Phase1CostPanel
                sellerId={selectedSeller.id}
                sellerName={selectedSeller.name}
                sellerRevenue={selectedSeller.revenue}
                marginBruta={selectedSeller.marginBruta}
                comissaoReal={selectedSeller.comissaoReal || 0}
                comissaoPercentual={selectedSeller.comissaoPercentual || 0}
                onCostCalculated={() => {}}
              />
            </div>
          )}
        </SheetContent>
      </Sheet>

      {/* Sheet para Custos da Empresa (Fase 2) */}
      <Sheet open={companyCostsOpen} onOpenChange={setCompanyCostsOpen}>
        <SheetContent className="w-full sm:max-w-xl overflow-y-auto">
          <SheetHeader>
            <SheetTitle className="flex items-center gap-2">
              <Building2 className="h-5 w-5 text-primary" />
              FASE 2 — Custo Estrutural da Empresa (CEE)
            </SheetTitle>
            <p className="text-sm text-muted-foreground">
              Rateado entre {activeSellersCount} vendedores ativos
            </p>
          </SheetHeader>
          
          <div className="mt-6">
            <Phase2CompanyCosts
              activeSellersCount={activeSellersCount}
              onCostCalculated={() => {}}
            />
          </div>
        </SheetContent>
      </Sheet>
    </div>
  );
}
