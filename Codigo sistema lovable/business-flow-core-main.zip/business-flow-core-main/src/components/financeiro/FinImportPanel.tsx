import { useState, useEffect, useRef, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Upload, FileSpreadsheet, Search, Filter, Loader2 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';
import { format } from 'date-fns';
import * as XLSX from 'xlsx';
import { cn } from '@/lib/utils';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

interface FinImportPanelProps {
  entryType: 'RECEBER' | 'PAGAR';
}

/* ─── Normalization helpers ─── */

function normalizeStatus(raw: string): string {
  if (!raw) return 'ABERTO';
  const l = raw.toLowerCase().trim();
  if (['pago', 'recebido', 'liquidado', 'quitado', 'baixado'].some(s => l.includes(s))) return 'PAGO';
  if (['aberto', 'a receber', 'a pagar', 'pendente', 'em aberto'].some(s => l.includes(s))) return 'ABERTO';
  if (['vencido', 'atraso', 'atrasado'].some(s => l.includes(s))) return 'ATRASADO';
  if (['cancelado', 'estornado', 'estorno'].some(s => l.includes(s))) return 'CANCELADO';
  return 'OUTRO';
}

function normalizeText(s: string): string {
  return (s || '').toLowerCase().trim().replace(/\s+/g, ' ');
}

function normalizeDecimal(v: any): number {
  if (typeof v === 'number') return v;
  if (!v) return 0;
  let s = String(v).replace(/\s/g, '').replace(/R\$\s*/gi, '').replace(/["']/g, '').trim();
  if (/^\d{1,3}(\.\d{3})*(,\d+)?$/.test(s) || /^\d+(,\d+)$/.test(s)) {
    s = s.replace(/\./g, '').replace(',', '.');
  } else if (s.includes(',') && s.includes('.')) {
    s = s.replace(/\./g, '').replace(',', '.');
  } else if (s.includes(',')) {
    s = s.replace(',', '.');
  }
  const n = parseFloat(s);
  return Number.isFinite(n) ? Math.abs(n) : 0;
}

function normalizeDate(v: any): string | null {
  if (!v) return null;
  const s = String(v).trim();
  const brMatch = s.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})$/);
  if (brMatch) return `${brMatch[3]}-${brMatch[2].padStart(2, '0')}-${brMatch[1].padStart(2, '0')}`;
  const isoMatch = s.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (isoMatch) return `${isoMatch[1]}-${isoMatch[2]}-${isoMatch[3]}`;
  if (/^\d{5}$/.test(s)) {
    const date = new Date((parseInt(s) - 25569) * 86400000);
    if (!isNaN(date.getTime())) return format(date, 'yyyy-MM-dd');
  }
  return null;
}

function generateHashKey(row: any): string {
  return [
    normalizeText(row.party_name || ''),
    normalizeDate(row.due_date) || '',
    String(normalizeDecimal(row.amount_original)),
    normalizeText(row.description || ''),
    normalizeText(row.external_ref || ''),
  ].join('|');
}

/* ─── Column auto-mapping (matches real ERP headers) ─── */

function autoMapColumns(headers: string[]): Record<string, number> {
  const mapping: Record<string, number> = {};
  const lower = headers.map(h => (h || '').toLowerCase().trim());

  const patterns: Record<string, string[]> = {
    party_name: ['nome do cliente', 'nome do fornecedor', 'cliente', 'fornecedor', 'razão social', 'razao social', 'nome', 'sacado', 'cedente', 'pagador', 'beneficiário', 'beneficiario'],
    description: ['descrição', 'descricao', 'historico', 'histórico', 'obs', 'observação', 'observacao', 'referência', 'referencia', 'detalhe'],
    due_date: ['data de vencimento', 'vencimento', 'data venc', 'dt vencimento', 'data vencto', 'venc'],
    paid_date: ['data do último pagamento', 'data do ultimo pagamento', 'pagamento', 'data pgto', 'dt pagamento', 'data pago', 'pago em', 'data baixa'],
    amount_original: ['valor original da parcela', 'valor original da parcela (r$)', 'valor', 'valor original', 'vl original', 'valor bruto', 'vlr original', 'total'],
    amount_paid: ['valor total recebido da parcela', 'valor total recebido da parcela (r$)', 'valor total pago da parcela', 'valor total pago da parcela (r$)', 'valor pago da parcela', 'valor pago da parcela (r$)', 'valor recebido da parcela', 'valor recebido da parcela (r$)', 'valor pago', 'vl pago', 'vlr pago', 'pago'],
    amount_open: ['valor da parcela em aberto', 'valor da parcela em aberto (r$)', 'valor total da parcela em aberto', 'valor total da parcela em aberto (r$)', 'saldo', 'valor aberto', 'em aberto', 'a receber', 'a pagar'],
    status_raw: ['situação', 'situacao', 'status', 'estado'],
    external_ref: ['código de referência', 'codigo de referencia', 'nº', 'numero', 'número', 'cod', 'código', 'ref', 'documento', 'doc'],
    nf: ['nota fiscal', 'nf', 'nota', 'nfe'],
    account_name: ['conta bancária', 'conta bancaria', 'conta', 'banco', 'carteira'],
    competence_date: ['data de competência', 'data de competencia', 'competência', 'competencia', 'dt competencia'],
    category_1: ['categoria 1', 'categoria', 'plano de contas', 'classificação', 'classificacao', 'centro de custo'],
    interest: ['juros realizado', 'juros realizado (r$)', 'juros'],
    penalty: ['multa realizado', 'multa realizado (r$)', 'multa'],
    discount: ['desconto realizado', 'desconto realizado (r$)', 'desconto'],
    expected_date: ['data prevista'],
    origin: ['origem do lançamento', 'origem do lancamento', 'origem'],
    party_id: ['identificador do cliente', 'identificador do fornecedor', 'cnpj', 'cpf'],
  };

  // Two-pass matching: exact first, then includes (avoids "identificador do fornecedor" matching "fornecedor")
  for (const [field, keywords] of Object.entries(patterns)) {
    if (mapping[field] !== undefined) continue;
    const idx = lower.findIndex((h, i) => {
      // Skip columns already mapped to another field
      if (Object.values(mapping).includes(i)) return false;
      return keywords.some(k => h === k);
    });
    if (idx >= 0) mapping[field] = idx;
  }
  // Second pass: includes matching for remaining unmapped fields
  for (const [field, keywords] of Object.entries(patterns)) {
    if (mapping[field] !== undefined) continue;
    const idx = lower.findIndex((h, i) => {
      if (Object.values(mapping).includes(i)) return false;
      return keywords.some(k => h.includes(k));
    });
    if (idx >= 0) mapping[field] = idx;
  }

  return mapping;
}

/* ─── Build entry from row ─── */

function buildEntry(row: any[], mapping: Record<string, number>, entryType: string, importId: string) {
  const get = (field: string) => mapping[field] !== undefined ? row[mapping[field]] : null;

  let partyName = String(get('party_name') || '').trim();
  const description = String(get('description') || '').trim() || null;
  if (!partyName && description) {
    partyName = description.substring(0, 100);
  }
  if (!partyName) return null;

  const amountOriginal = normalizeDecimal(get('amount_original'));
  const amountPaid = normalizeDecimal(get('amount_paid'));
  const amountOpen = normalizeDecimal(get('amount_open')) || (amountOriginal - amountPaid);

  const entry: any = {
    entry_type: entryType,
    party_name: partyName,
    description: description,
    due_date: normalizeDate(get('due_date')),
    paid_date: normalizeDate(get('paid_date')),
    competence_date: normalizeDate(get('competence_date')),
    amount_original: amountOriginal,
    amount_paid: amountPaid,
    amount_open: amountOpen,
    status_raw: String(get('status_raw') || '').trim(),
    status_norm: normalizeStatus(String(get('status_raw') || '')),
    external_ref: String(get('external_ref') || '').trim() || null,
    nf: String(get('nf') || '').trim() || null,
    account_name: String(get('account_name') || '').trim() || null,
    category_1: String(get('category_1') || '').trim() || null,
    last_seen_import_id: importId,
  };

  entry.hash_key = generateHashKey(entry);
  return entry;
}

/* ─── Component ─── */

export function FinImportPanel({ entryType }: FinImportPanelProps) {
  const [entries, setEntries] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [importing, setImporting] = useState(false);
  const [progress, setProgress] = useState({ current: 0, total: 0, phase: '' });
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [lastImport, setLastImport] = useState<any>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const { user } = useAuth();
  const { toast } = useToast();

  useEffect(() => { loadEntries(); }, [entryType]);

  async function loadEntries() {
    setLoading(true);
    const { data } = await supabase
      .from('fin_entries')
      .select('*')
      .eq('entry_type', entryType)
      .eq('is_active', true)
      .order('due_date', { ascending: true })
      .limit(500);
    setEntries(data || []);
    setLoading(false);
  }

  const handleFileUpload = useCallback(async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;

    setImporting(true);
    setProgress({ current: 0, total: 0, phase: 'Lendo arquivo...' });

    try {
      const ext = file.name.split('.').pop()?.toLowerCase();
      if (!['xlsx', 'xls', 'csv'].includes(ext || '')) {
        toast({ title: 'Formato inválido', description: 'Use XLS, XLSX ou CSV.', variant: 'destructive' });
        return;
      }

      // Parse file
      const buffer = await file.arrayBuffer();
      const wb = XLSX.read(buffer, { type: 'array', cellDates: true, cellNF: false, WTF: false });
      const ws = wb.Sheets[wb.SheetNames[0]];
      const rawData: any[][] = XLSX.utils.sheet_to_json(ws, { header: 1, defval: '', raw: false });

      if (rawData.length < 2) {
        toast({ title: 'Arquivo vazio', description: 'Nenhuma linha de dados encontrada.', variant: 'destructive' });
        return;
      }

      const headers = rawData[0].map(String);
      const mapping = autoMapColumns(headers);
      const rows = rawData.slice(1).filter(r => r.some(c => c !== ''));
      const totalRows = rows.length;

      setProgress({ current: 0, total: totalRows, phase: `Preparando ${totalRows} linhas...` });

      // Create import log
      const { data: importLog, error: importErr } = await supabase
        .from('fin_imports')
        .insert({
          created_by_user_id: user.id,
          source_type: entryType,
          file_name: file.name,
          file_mime: file.type || `application/${ext}`,
          row_count: totalRows,
          parse_status: 'OK',
        })
        .select('id')
        .single();

      if (importErr) throw importErr;
      const importId = importLog.id;

      // Build all entries in memory first (fast)
      setProgress({ current: 0, total: totalRows, phase: 'Processando linhas...' });
      const newEntries: any[] = [];
      const parseNotes: string[] = [];
      let skippedParse = 0;

      for (let i = 0; i < rows.length; i++) {
        try {
          const entry = buildEntry(rows[i], mapping, entryType, importId);
          if (entry) {
            newEntries.push(entry);
          } else {
            skippedParse++;
          }
        } catch (err: any) {
          skippedParse++;
          parseNotes.push(`Linha ${i + 2}: ${err.message}`);
        }
      }

      // Deduplicate entries by hash_key (add suffix for collisions)
      const hashCount = new Map<string, number>();
      for (const entry of newEntries) {
        const count = hashCount.get(entry.hash_key) || 0;
        if (count > 0) {
          entry.hash_key = `${entry.hash_key}|#${count + 1}`;
        }
        hashCount.set(entry.hash_key.split('|#')[0], count + 1);
      }

      // Fetch ALL existing hash_keys for this entry_type (avoids huge .in() URLs)
      setProgress({ current: 0, total: newEntries.length, phase: 'Verificando duplicatas...' });
      const existingMap = new Map<string, any>();
      let fetchOffset = 0;
      const FETCH_PAGE = 1000;
      while (true) {
        const { data: existing } = await supabase
          .from('fin_entries')
          .select('id, hash_key, status_norm, amount_paid, amount_open')
          .eq('entry_type', entryType)
          .eq('is_active', true)
          .range(fetchOffset, fetchOffset + FETCH_PAGE - 1);
        if (!existing || existing.length === 0) break;
        for (const ex of existing) {
          existingMap.set(ex.hash_key, ex);
        }
        if (existing.length < FETCH_PAGE) break;
        fetchOffset += FETCH_PAGE;
      }

      // Split into inserts vs updates
      const toInsert: any[] = [];
      const toUpdate: { id: string; data: any; diff: any; changedFields: string[] }[] = [];
      let unchanged = 0;

      for (const entry of newEntries) {
        const ex = existingMap.get(entry.hash_key);
        if (ex) {
          const changedFields: string[] = [];
          const diff: Record<string, any> = {};
          if (ex.status_norm !== entry.status_norm) { diff.status_norm = { old: ex.status_norm, new: entry.status_norm }; changedFields.push('status_norm'); }
          if (Number(ex.amount_paid) !== entry.amount_paid) { diff.amount_paid = { old: ex.amount_paid, new: entry.amount_paid }; changedFields.push('amount_paid'); }
          if (Number(ex.amount_open) !== entry.amount_open) { diff.amount_open = { old: ex.amount_open, new: entry.amount_open }; changedFields.push('amount_open'); }

          if (changedFields.length > 0) {
            toUpdate.push({ id: ex.id, data: { ...entry, is_active: true }, diff, changedFields });
          } else {
            unchanged++;
          }
        } else {
          toInsert.push(entry);
        }
      }

      // Batch INSERT (chunks of 200)
      let created = 0;
      const INSERT_BATCH = 200;
      const historyInserts: any[] = [];

      for (let i = 0; i < toInsert.length; i += INSERT_BATCH) {
        const batch = toInsert.slice(i, i + INSERT_BATCH);
        const { data: inserted, error } = await supabase
          .from('fin_entries')
          .insert(batch)
          .select('id');

        if (error) {
          // Fallback: insert one by one
          for (const single of batch) {
            const { data: singleIns, error: singleErr } = await supabase
              .from('fin_entries')
              .insert(single)
              .select('id');
            if (singleIns && singleIns.length > 0) {
              created++;
              historyInserts.push({
                entry_id: singleIns[0].id,
                import_id: importId,
                diff_json: { action: 'created' },
                changed_fields: ['*'],
              });
            } else if (singleErr) {
              parseNotes.push(`Linha: ${singleErr.message}`);
            }
          }
        } else if (inserted) {
          created += inserted.length;
          for (const ins of inserted) {
            historyInserts.push({
              entry_id: ins.id,
              import_id: importId,
              diff_json: { action: 'created' },
              changed_fields: ['*'],
            });
          }
        }
        setProgress({ current: created, total: toInsert.length, phase: `Inserindo... ${created}/${toInsert.length}` });
        // Yield to UI
        await new Promise(r => setTimeout(r, 10));
      }

      // Batch UPDATE (one by one but fast — only changed rows)
      let updated = 0;
      for (let i = 0; i < toUpdate.length; i++) {
        const u = toUpdate[i];
        await supabase.from('fin_entries').update(u.data).eq('id', u.id);
        historyInserts.push({
          entry_id: u.id,
          import_id: importId,
          diff_json: u.diff,
          changed_fields: u.changedFields,
        });
        updated++;
        if (i % 20 === 0) {
          setProgress({ current: updated, total: toUpdate.length, phase: `Atualizando... ${updated}/${toUpdate.length}` });
          await new Promise(r => setTimeout(r, 5));
        }
      }

      // Batch insert history
      if (historyInserts.length > 0) {
        setProgress({ current: 0, total: 1, phase: 'Gravando histórico...' });
        for (let i = 0; i < historyInserts.length; i += INSERT_BATCH) {
          await supabase.from('fin_entry_history').insert(historyInserts.slice(i, i + INSERT_BATCH));
        }
      }

      // Update import log
      await supabase.from('fin_imports').update({
        parse_status: parseNotes.length > 0 ? 'WARNING' : 'OK',
        parse_notes: parseNotes.length > 0 ? parseNotes.join('\n') : null,
        row_count: totalRows,
      }).eq('id', importId);

      setProgress({ current: totalRows, total: totalRows, phase: 'Concluído!' });

      toast({
        title: '✅ Importação concluída',
        description: `Criados: ${created} | Atualizados: ${updated} | Sem alteração: ${unchanged + skippedParse}`,
      });

      setLastImport({ created, updated, skipped: unchanged + skippedParse, notes: parseNotes });
      loadEntries();
    } catch (err: any) {
      toast({ title: 'Erro na importação', description: err.message, variant: 'destructive' });
    } finally {
      setImporting(false);
      if (fileRef.current) fileRef.current.value = '';
    }
  }, [entryType, user, toast]);

  const statusColors: Record<string, string> = {
    PAGO: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20',
    ABERTO: 'bg-blue-500/10 text-blue-600 border-blue-500/20',
    ATRASADO: 'bg-red-500/10 text-red-600 border-red-500/20',
    CANCELADO: 'bg-muted text-muted-foreground',
    OUTRO: 'bg-muted text-muted-foreground',
  };

  const filteredEntries = entries.filter(e => {
    const matchSearch = !searchTerm ||
      (e.party_name || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (e.description || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (e.nf || '').toLowerCase().includes(searchTerm.toLowerCase());
    const matchStatus = statusFilter === 'ALL' || e.status_norm === statusFilter;
    return matchSearch && matchStatus;
  });

  const fmt = (v: number) => (v || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  const progressPercent = progress.total > 0 ? Math.round((progress.current / progress.total) * 100) : 0;

  return (
    <div className="space-y-6 mt-4">
      {/* Import area */}
      <Card>
        <CardContent className="p-5">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
            <div className="flex-1">
              <h3 className="text-sm font-semibold flex items-center gap-2">
                <FileSpreadsheet className="h-4 w-4 text-primary" />
                Importar {entryType === 'RECEBER' ? 'Contas a Receber' : 'Contas a Pagar'}
              </h3>
              <p className="text-xs text-muted-foreground mt-1">
                XLS, XLSX ou CSV. Colunas detectadas automaticamente.
              </p>
            </div>
            <div>
              <input
                ref={fileRef}
                type="file"
                accept=".xlsx,.xls,.csv"
                className="hidden"
                onChange={handleFileUpload}
              />
              <Button
                onClick={() => fileRef.current?.click()}
                disabled={importing}
                className="gap-2"
              >
                {importing ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}
                {importing ? 'Importando...' : 'Selecionar Arquivo'}
              </Button>
            </div>
          </div>

          {/* Progress bar */}
          {importing && (
            <div className="mt-4 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">{progress.phase}</span>
                <span className="font-mono font-medium">{progressPercent}%</span>
              </div>
              <Progress value={progressPercent} className="h-2" />
              {progress.total > 0 && (
                <p className="text-[10px] text-muted-foreground">
                  {progress.current} de {progress.total}
                </p>
              )}
            </div>
          )}

          {lastImport && !importing && (
            <div className="mt-3 p-3 rounded-lg bg-muted/30 text-xs space-y-1">
              <p className="font-medium">Resultado da última importação:</p>
              <p>✅ Criados: {lastImport.created} | 🔄 Atualizados: {lastImport.updated} | ⏭️ Sem alteração: {lastImport.skipped}</p>
              {lastImport.notes?.length > 0 && (
                <p className="text-amber-600">⚠️ {lastImport.notes.length} avisos</p>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Buscar por nome, descrição, NF..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-9"
          />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-44">
            <Filter className="h-3.5 w-3.5 mr-2" />
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL">Todos</SelectItem>
            <SelectItem value="ABERTO">Aberto</SelectItem>
            <SelectItem value="PAGO">Pago</SelectItem>
            <SelectItem value="ATRASADO">Atrasado</SelectItem>
            <SelectItem value="CANCELADO">Cancelado</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Entries table */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm flex items-center justify-between">
            <span>{entryType === 'RECEBER' ? 'Contas a Receber' : 'Contas a Pagar'}</span>
            <Badge variant="secondary">{filteredEntries.length} registros</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {loading ? (
            <div className="p-6 space-y-3">
              {Array.from({ length: 5 }).map((_, i) => (
                <div key={i} className="h-10 bg-muted/30 rounded animate-pulse" />
              ))}
            </div>
          ) : filteredEntries.length === 0 ? (
            <div className="p-10 text-center text-muted-foreground text-sm">
              Nenhum registro encontrado. Importe um arquivo acima.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b bg-muted/30">
                    <th className="text-left p-3 font-medium">Nome</th>
                    <th className="text-left p-3 font-medium">Descrição</th>
                    <th className="text-center p-3 font-medium">Vencimento</th>
                    <th className="text-right p-3 font-medium">Valor</th>
                    <th className="text-right p-3 font-medium">Aberto</th>
                    <th className="text-center p-3 font-medium">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredEntries.slice(0, 100).map((entry) => (
                    <tr key={entry.id} className="border-b hover:bg-muted/20 transition-colors">
                      <td className="p-3 max-w-[200px] truncate font-medium">{entry.party_name}</td>
                      <td className="p-3 max-w-[200px] truncate text-muted-foreground">{entry.description || '—'}</td>
                      <td className="p-3 text-center">
                        {entry.due_date ? format(new Date(entry.due_date + 'T12:00:00'), 'dd/MM/yyyy') : '—'}
                      </td>
                      <td className="p-3 text-right font-mono">{fmt(entry.amount_original)}</td>
                      <td className="p-3 text-right font-mono">{fmt(entry.amount_open)}</td>
                      <td className="p-3 text-center">
                        <Badge variant="outline" className={cn('text-[10px]', statusColors[entry.status_norm])}>
                          {entry.status_norm}
                        </Badge>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {filteredEntries.length > 100 && (
                <p className="p-3 text-xs text-center text-muted-foreground">
                  Mostrando 100 de {filteredEntries.length} registros
                </p>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
