import { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { Package, Star, Save, Loader2 } from 'lucide-react';
import { CATEGORY_CONFIGS, getCategoryKeys } from '@/lib/categoryConfig';

interface Seller {
  id: string;
  name: string;
}

interface CategoryGoalsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

// Generate month options
function getMonthOptions() {
  const options = [];
  const now = new Date();
  for (let i = -2; i <= 6; i++) {
    const date = new Date(now.getFullYear(), now.getMonth() + i, 1);
    const year = date.getFullYear();
    const month = date.getMonth() + 1;
    const label = date.toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' });
    options.push({ value: `${year}-${String(month).padStart(2, '0')}`, label });
  }
  return options;
}

export function CategoryGoalsModal({ isOpen, onClose }: CategoryGoalsModalProps) {
  const [sellers, setSellers] = useState<Seller[]>([]);
  const [selectedSellerId, setSelectedSellerId] = useState<string>('');
  const [selectedCompetencia, setSelectedCompetencia] = useState<string>('');
  const [goals, setGoals] = useState<Record<string, { meta: number; stars: number }>>({});
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  const monthOptions = getMonthOptions();

  // Set default competencia to current month
  useEffect(() => {
    if (!selectedCompetencia) {
      const now = new Date();
      const current = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
      setSelectedCompetencia(current);
    }
  }, []);

  // Fetch sellers on mount
  useEffect(() => {
    const fetchSellers = async () => {
      // Apenas vendedores ATIVOS
      const { data } = await supabase
        .from('sellers')
        .select('id, name')
        .eq('role', 'vendedor')
        .or('status.eq.ATIVO,status.is.null')
        .order('name');
      setSellers(data || []);
    };
    if (isOpen) {
      fetchSellers();
    }
  }, [isOpen]);

  // Fetch goals when seller or competencia changes
  useEffect(() => {
    const fetchGoals = async () => {
      if (!selectedSellerId || !selectedCompetencia) {
        // Initialize with default values
        const defaults: Record<string, { meta: number; stars: number }> = {};
        CATEGORY_CONFIGS.forEach(config => {
          defaults[config.key] = { meta: 0, stars: config.defaultStars };
        });
        setGoals(defaults);
        return;
      }

      setLoading(true);
      try {
        const { data } = await supabase
          .from('category_goals')
          .select('*')
          .eq('seller_id', selectedSellerId)
          .eq('competencia', selectedCompetencia);

        const goalsMap: Record<string, { meta: number; stars: number }> = {};
        CATEGORY_CONFIGS.forEach(config => {
          const existing = data?.find(g => g.category_key === config.key);
          goalsMap[config.key] = {
            meta: existing?.meta_valor || 0,
            stars: existing?.stars_reward || config.defaultStars,
          };
        });
        setGoals(goalsMap);
      } catch (error) {
        console.error('Error fetching goals:', error);
        toast.error('Erro ao carregar metas');
      } finally {
        setLoading(false);
      }
    };

    fetchGoals();
  }, [selectedSellerId, selectedCompetencia]);

  const handleGoalChange = (categoryKey: string, field: 'meta' | 'stars', value: number) => {
    setGoals(prev => ({
      ...prev,
      [categoryKey]: {
        ...prev[categoryKey],
        [field]: value,
      },
    }));
  };

  const handleSave = async () => {
    if (!selectedSellerId || !selectedCompetencia) {
      toast.error('Selecione vendedor e mês');
      return;
    }

    setSaving(true);
    try {
      // Prepare upsert data
      const upsertData = Object.entries(goals).map(([categoryKey, data]) => ({
        seller_id: selectedSellerId,
        competencia: selectedCompetencia,
        category_key: categoryKey,
        meta_valor: data.meta,
        stars_reward: data.stars,
        is_active: true,
      }));

      // Upsert all goals
      for (const goal of upsertData) {
        const { error } = await supabase
          .from('category_goals')
          .upsert(goal, {
            onConflict: 'seller_id,competencia,category_key',
          });
        if (error) throw error;
      }

      toast.success('Metas salvas com sucesso!');
      onClose();
    } catch (error: any) {
      console.error('Error saving goals:', error);
      toast.error(error.message || 'Erro ao salvar metas');
    } finally {
      setSaving(false);
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Package className="h-5 w-5" />
            Configurar Metas por Categoria
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Seller and Month Selection */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Vendedor</Label>
              <Select value={selectedSellerId} onValueChange={setSelectedSellerId}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione o vendedor" />
                </SelectTrigger>
                <SelectContent>
                  {sellers.map(seller => (
                    <SelectItem key={seller.id} value={seller.id}>
                      {seller.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Mês de Referência</Label>
              <Select value={selectedCompetencia} onValueChange={setSelectedCompetencia}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione o mês" />
                </SelectTrigger>
                <SelectContent>
                  {monthOptions.map(opt => (
                    <SelectItem key={opt.value} value={opt.value}>
                      {opt.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Category Goals */}
          {loading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
          ) : (
            <div className="space-y-4">
              <Label className="text-base font-semibold">Metas por Categoria</Label>
              
              {CATEGORY_CONFIGS.map((config) => (
                <div
                  key={config.key}
                  className="p-4 rounded-lg border bg-muted/30 space-y-3"
                >
                  <div className="flex items-center gap-2">
                    <span className="text-lg">{config.icon}</span>
                    <span className="font-medium">{config.label}</span>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <Label className="text-xs text-muted-foreground">Meta (R$)</Label>
                      <Input
                        type="number"
                        min={0}
                        step={1000}
                        value={goals[config.key]?.meta || 0}
                        onChange={(e) => handleGoalChange(config.key, 'meta', parseFloat(e.target.value) || 0)}
                        placeholder="0"
                      />
                      <p className="text-xs text-muted-foreground">
                        {formatCurrency(goals[config.key]?.meta || 0)}
                      </p>
                    </div>
                    
                    <div className="space-y-1">
                      <Label className="text-xs text-muted-foreground flex items-center gap-1">
                        <Star className="h-3 w-3 text-amber-500" />
                        Estrelas ao Bater
                      </Label>
                      <Select
                        value={String(goals[config.key]?.stars || 1)}
                        onValueChange={(v) => handleGoalChange(config.key, 'stars', parseInt(v))}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1">1 estrela</SelectItem>
                          <SelectItem value="2">2 estrelas</SelectItem>
                          <SelectItem value="3">3 estrelas</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>
              ))}

              {/* Total Summary */}
              <div className="p-4 rounded-lg border-2 border-primary/20 bg-primary/5">
                <div className="flex items-center justify-between">
                  <span className="font-medium">Total das Metas:</span>
                  <span className="text-lg font-bold text-primary">
                    {formatCurrency(Object.values(goals).reduce((sum, g) => sum + (g.meta || 0), 0))}
                  </span>
                </div>
                <div className="flex items-center justify-between mt-1">
                  <span className="text-sm text-muted-foreground">Estrelas potenciais:</span>
                  <span className="text-sm font-medium flex items-center gap-1">
                    {Object.values(goals).reduce((sum, g) => sum + (g.stars || 0), 0)}
                    <Star className="h-3 w-3 text-amber-500 fill-amber-500" />
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* Actions */}
          <div className="flex justify-end gap-3 pt-4 border-t">
            <Button variant="outline" onClick={onClose} disabled={saving}>
              Cancelar
            </Button>
            <Button 
              onClick={handleSave} 
              disabled={saving || !selectedSellerId || !selectedCompetencia}
            >
              {saving ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Salvando...
                </>
              ) : (
                <>
                  <Save className="h-4 w-4 mr-2" />
                  Salvar Metas
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
