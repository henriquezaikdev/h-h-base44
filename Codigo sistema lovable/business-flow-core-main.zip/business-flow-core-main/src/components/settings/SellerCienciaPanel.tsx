import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { toast } from 'sonner';
import { 
  Loader2, FileCheck, AlertTriangle, CheckCircle2, 
  XCircle, Calendar, Clock, Send, Eye
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from '@/components/ui/dialog';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

const sb = supabase as any;

interface AcceptanceRow {
  id: string;
  campaign_id: string;
  user_id: string;
  status: string;
  sent_at: string;
  accepted_at: string | null;
  declined_at: string | null;
  seller_name: string;
  campaign_title: string;
}

interface DocumentData {
  title: string;
  content: string;
}

export function SellerCienciaPanel() {
  const { seller } = useAuth();
  const [acceptances, setAcceptances] = useState<AcceptanceRow[]>([]);
  const [sellers, setSellers] = useState<any[]>([]);
  const [activeCampaigns, setActiveCampaigns] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState<string | null>(null);
  const [docModal, setDocModal] = useState<DocumentData | null>(null);

  useEffect(() => { fetchData(); }, []);

  const fetchData = async () => {
    setLoading(true);
    try {
      // Fetch active sellers (vendedores only)
      const { data: sellersData } = await supabase
        .from('sellers')
        .select('id, name')
        .eq('status', 'ATIVO')
        .eq('role', 'vendedor')
        .order('name');
      setSellers(sellersData || []);

      // Fetch active campaigns
      const { data: camps } = await sb
        .from('campanhas')
        .select('id, nome, status')
        .in('status', ['ATIVA', 'ENCERRADA']);
      setActiveCampaigns(camps || []);

      // Fetch all acceptance records with seller names
      const { data: accData } = await sb
        .from('campaign_acceptance')
        .select('*, sellers:user_id(name), campanhas:campaign_id(nome)');

      if (accData) {
        setAcceptances(accData.map((a: any) => ({
          ...a,
          seller_name: a.sellers?.name || 'N/A',
          campaign_title: a.campanhas?.nome || 'N/A',
        })));
      }
    } catch (err) {
      console.error('Error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleEnviarCiencia = async (campaignId: string, userId: string) => {
    setSending(`${campaignId}-${userId}`);
    try {
      await sb.from('campaign_acceptance').upsert({
        campaign_id: campaignId,
        user_id: userId,
        status: 'pendente',
        sent_at: new Date().toISOString(),
      }, { onConflict: 'campaign_id,user_id' });

      toast.success('Ciência enviada!');
      await fetchData();
    } catch (err: any) {
      toast.error('Erro: ' + err.message);
    } finally {
      setSending(null);
    }
  };

  const handleEnviarTodos = async (campaignId: string) => {
    setSending(`all-${campaignId}`);
    try {
      const rows = sellers.map(s => ({
        campaign_id: campaignId,
        user_id: s.id,
        status: 'pendente',
        sent_at: new Date().toISOString(),
      }));
      await sb.from('campaign_acceptance').upsert(rows, { onConflict: 'campaign_id,user_id' });
      toast.success('Ciência enviada para todos os vendedores!');
      await fetchData();
    } catch (err: any) {
      toast.error('Erro: ' + err.message);
    } finally {
      setSending(null);
    }
  };

  const handleViewDocument = async (campaignId: string) => {
    const { data: doc } = await sb
      .from('campaign_documents')
      .select('title, content')
      .eq('campaign_id', campaignId)
      .maybeSingle();

    if (doc) {
      setDocModal(doc);
    } else {
      // Build from campaign data
      const { data: camp } = await sb
        .from('campanhas')
        .select('nome, descricao, area, tipo, modo_validacao, percentual_minimo, configuracao_mensal_campanhas!campanhas_configuracao_mensal_id_fkey(foco_geral, descricao_foco, mes_referencia)')
        .eq('id', campaignId)
        .single();
      
      const { data: crits } = await sb
        .from('criterios_campanha')
        .select('nome, meta_objetiva, peso_percentual')
        .eq('campanha_id', campaignId);

      if (camp) {
        const config = camp.configuracao_mensal_campanhas;
        const content = [
          `CAMPANHA: ${camp.nome}`,
          `Período: ${config?.mes_referencia || '—'}`,
          `Foco: ${config?.foco_geral || '—'}`,
          camp.descricao ? `\nDescrição: ${camp.descricao}` : '',
          `\nÁrea: ${camp.area} | Tipo: ${camp.tipo}`,
          `Validação: ${camp.modo_validacao === 'RIGIDO_100' ? '100% Rígido' : `≥${camp.percentual_minimo}%`}`,
          '\n--- CRITÉRIOS ---',
          ...(crits || []).map((c: any) => `• ${c.nome} — Meta: ${c.meta_objetiva} (Peso: ${c.peso_percentual}%)`),
          '\n--- CONDIÇÃO JURÍDICA ---',
          'Esta campanha possui caráter exclusivamente eventual e não integra salário ou remuneração fixa, conforme legislação trabalhista vigente.',
        ].filter(Boolean).join('\n');

        setDocModal({ title: camp.nome, content });
      }
    }
  };

  const getAcceptance = (campaignId: string, userId: string) =>
    acceptances.find(a => a.campaign_id === campaignId && a.user_id === userId);

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'aceito':
        return <Badge className="bg-emerald-500/20 text-emerald-600 border-emerald-500/30"><CheckCircle2 className="h-3 w-3 mr-1" />Aceito</Badge>;
      case 'recusado':
        return <Badge variant="destructive" className="bg-red-500/20 text-red-600 border-red-500/30"><XCircle className="h-3 w-3 mr-1" />Recusado</Badge>;
      default:
        return <Badge variant="outline" className="text-amber-600 border-amber-300"><Clock className="h-3 w-3 mr-1" />Pendente</Badge>;
    }
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center py-12">
          <Loader2 className="animate-spin h-8 w-8 text-primary" />
        </CardContent>
      </Card>
    );
  }

  const acceptedCount = acceptances.filter(a => a.status === 'aceito').length;
  const pendingCount = acceptances.filter(a => a.status === 'pendente').length;

  return (
    <>
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <FileCheck className="h-5 w-5 text-primary" />
                Aceite de Campanhas e Premiações
              </CardTitle>
              <CardDescription className="mt-1">
                Gerencie o aceite dos vendedores nas campanhas de premiação.
                Apenas vendedores que aceitarem participam do cálculo.
              </CardDescription>
            </div>
            <div className="flex items-center gap-3">
              <Badge variant="default" className="bg-emerald-500">
                <CheckCircle2 className="h-3 w-3 mr-1" />
                {acceptedCount} aceito(s)
              </Badge>
              {pendingCount > 0 && (
                <Badge variant="outline" className="text-amber-600 border-amber-300">
                  <Clock className="h-3 w-3 mr-1" />
                  {pendingCount} pendente(s)
                </Badge>
              )}
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <Alert className="border-amber-500/50 bg-amber-500/10">
            <AlertTriangle className="h-4 w-4 text-amber-600" />
            <AlertTitle className="text-amber-700 dark:text-amber-400">Aviso Importante</AlertTitle>
            <AlertDescription className="text-amber-600 dark:text-amber-300">
              Premiações são eventuais, não garantidas e não possuem natureza salarial.
            </AlertDescription>
          </Alert>

          {activeCampaigns.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-8">
              Nenhuma campanha ativa. Crie campanhas em Meu Dia → Campanhas.
            </p>
          ) : (
            activeCampaigns.map(camp => (
              <div key={camp.id} className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <h4 className="font-semibold text-sm">{camp.nome}</h4>
                    <Badge variant="outline" className="text-[10px]">{camp.status}</Badge>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleViewDocument(camp.id)}
                      className="gap-1"
                    >
                      <Eye className="h-3.5 w-3.5" /> Ver documento
                    </Button>
                    <Button
                      size="sm"
                      onClick={() => handleEnviarTodos(camp.id)}
                      disabled={sending === `all-${camp.id}`}
                      className="gap-1"
                    >
                      {sending === `all-${camp.id}` ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Send className="h-3.5 w-3.5" />}
                      Enviar ciência para todos
                    </Button>
                  </div>
                </div>

                <div className="rounded-md border overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Vendedor</TableHead>
                        <TableHead>Campanha</TableHead>
                        <TableHead className="text-center">Status</TableHead>
                        <TableHead>Data do envio</TableHead>
                        <TableHead>Data da resposta</TableHead>
                        <TableHead className="text-center">Ações</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {sellers.map(s => {
                        const acc = getAcceptance(camp.id, s.id);
                        const isSending = sending === `${camp.id}-${s.id}`;
                        return (
                          <TableRow key={s.id}>
                            <TableCell className="font-medium">{s.name}</TableCell>
                            <TableCell className="text-sm text-muted-foreground">{camp.nome}</TableCell>
                            <TableCell className="text-center">
                              {acc ? getStatusBadge(acc.status) : (
                                <Badge variant="outline" className="text-muted-foreground">Não enviado</Badge>
                              )}
                            </TableCell>
                            <TableCell>
                              {acc?.sent_at ? (
                                <div className="flex items-center gap-1.5 text-sm">
                                  <Calendar className="h-3.5 w-3.5 text-muted-foreground" />
                                  {format(new Date(acc.sent_at), "dd/MM/yyyy HH:mm", { locale: ptBR })}
                                </div>
                              ) : (
                                <span className="text-muted-foreground text-sm">—</span>
                              )}
                            </TableCell>
                            <TableCell>
                              {acc?.accepted_at ? (
                                <div className="flex items-center gap-1.5 text-sm text-emerald-600">
                                  <Calendar className="h-3.5 w-3.5" />
                                  {format(new Date(acc.accepted_at), "dd/MM/yyyy HH:mm", { locale: ptBR })}
                                </div>
                              ) : acc?.declined_at ? (
                                <div className="flex items-center gap-1.5 text-sm text-destructive">
                                  <Calendar className="h-3.5 w-3.5" />
                                  {format(new Date(acc.declined_at), "dd/MM/yyyy HH:mm", { locale: ptBR })}
                                </div>
                              ) : (
                                <span className="text-muted-foreground text-sm">—</span>
                              )}
                            </TableCell>
                            <TableCell className="text-center">
                              <div className="flex items-center justify-center gap-1">
                                {!acc ? (
                                  <Button
                                    size="sm"
                                    onClick={() => handleEnviarCiencia(camp.id, s.id)}
                                    disabled={isSending}
                                    className="gap-1"
                                  >
                                    {isSending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Send className="h-3.5 w-3.5" />}
                                    Enviar ciência
                                  </Button>
                                ) : (
                                  <Button
                                    size="sm"
                                    variant="ghost"
                                    onClick={() => handleViewDocument(camp.id)}
                                  >
                                    <Eye className="h-3.5 w-3.5 mr-1" /> Ver documento
                                  </Button>
                                )}
                              </div>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
              </div>
            ))
          )}

          <div className="mt-4 p-3 bg-muted/50 rounded-lg">
            <p className="text-sm text-muted-foreground">
              <strong>⚠️ Importante:</strong> Apenas vendedores com status <strong className="text-emerald-600">Aceito</strong> participam 
              do cálculo e premiação das campanhas. Vendedores pendentes ou que recusaram são ignorados.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Document viewer modal */}
      <Dialog open={!!docModal} onOpenChange={(open) => !open && setDocModal(null)}>
        <DialogContent className="max-w-lg max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FileCheck className="h-5 w-5 text-primary" />
              {docModal?.title || 'Documento da Campanha'}
            </DialogTitle>
          </DialogHeader>
          <div className="whitespace-pre-wrap text-sm text-muted-foreground bg-muted/30 rounded-xl p-4 border">
            {docModal?.content}
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
