import { useState, useEffect } from 'react';
import { toast } from 'sonner';
import { Shield, Users, User, ChevronDown, ChevronRight, Check, X, Loader2, Lock } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { ScrollArea } from '@/components/ui/scroll-area';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { 
  usePermissionsAdmin, 
  PermissionAction, 
  PermissionScope,
  Resource,
  Role 
} from '@/hooks/usePermissions';
import { useSellersData } from '@/hooks/useSellersData';
import { supabase } from '@/integrations/supabase/client';

interface RolePermission {
  id: string;
  role_id: string;
  resource_key: string;
  action: PermissionAction;
  allowed: boolean;
  scope: PermissionScope;
}

interface UserPermission {
  id: string;
  user_id: string;
  resource_key: string;
  action: PermissionAction;
  allowed: boolean;
  scope: PermissionScope;
}

const ACTION_LABELS: Record<PermissionAction, string> = {
  view: 'Ver',
  create: 'Criar',
  edit: 'Editar',
  delete: 'Excluir',
  export: 'Exportar',
};

const SCOPE_LABELS: Record<PermissionScope, string> = {
  own_only: 'Próprio',
  team: 'Time',
  all: 'Todos',
};

// Recursos exclusivos por role
const EXCLUSIVE_RESOURCES: Record<string, { role: string; label: string }> = {
  'sellerEvolution.tab.overview': { role: 'vendedor', label: 'Exclusivo do Vendedor' },
  'gestor.page': { role: 'owner', label: 'Exclusivo do Owner' },
};

export function PermissionsTab() {
  const { roles, resources, loading, getRolePermissions, getUserPermissions, updateRolePermission, updateUserPermission, removeUserPermission, refetch } = usePermissionsAdmin();
  const { sellers } = useSellersData();
  const [activeTab, setActiveTab] = useState<'roles' | 'users'>('roles');
  const [selectedRoleId, setSelectedRoleId] = useState<string | null>(null);
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null);
  const [rolePermissions, setRolePermissions] = useState<RolePermission[]>([]);
  const [userPermissions, setUserPermissions] = useState<UserPermission[]>([]);
  const [expandedResources, setExpandedResources] = useState<string[]>([]);
  const [saving, setSaving] = useState(false);

  // Agrupar recursos por tipo
  const groupedResources = resources.reduce((acc, resource) => {
    const type = resource.resource_type;
    if (!acc[type]) acc[type] = [];
    acc[type].push(resource);
    return acc;
  }, {} as Record<string, Resource[]>);

  // Organizar recursos hierarquicamente (páginas com suas abas)
  const organizedResources = resources.filter(r => !r.parent_key).map(page => ({
    ...page,
    children: resources.filter(r => r.parent_key === page.key),
  }));

  // Carregar permissões do role selecionado
  useEffect(() => {
    if (selectedRoleId) {
      getRolePermissions(selectedRoleId)
        .then(perms => setRolePermissions(perms as RolePermission[]))
        .catch(err => console.error(err));
    }
  }, [selectedRoleId, getRolePermissions]);

  // Carregar permissões do usuário selecionado
  useEffect(() => {
    if (selectedUserId) {
      getUserPermissions(selectedUserId)
        .then(perms => setUserPermissions(perms as UserPermission[]))
        .catch(err => console.error(err));
    }
  }, [selectedUserId, getUserPermissions]);

  // Selecionar primeiro role ao carregar
  useEffect(() => {
    if (roles.length > 0 && !selectedRoleId) {
      setSelectedRoleId(roles[0].id);
    }
  }, [roles, selectedRoleId]);

  // Toggle expandir recurso
  const toggleExpand = (key: string) => {
    setExpandedResources(prev => 
      prev.includes(key) 
        ? prev.filter(k => k !== key) 
        : [...prev, key]
    );
  };

  // Verificar se role tem permissão
  const roleHasPermission = (resourceKey: string, action: PermissionAction): boolean => {
    const perm = rolePermissions.find(p => p.resource_key === resourceKey && p.action === action);
    return perm?.allowed ?? false;
  };

  // Obter escopo do role
  const getRoleScope = (resourceKey: string): PermissionScope => {
    const perm = rolePermissions.find(p => p.resource_key === resourceKey && p.action === 'view');
    return perm?.scope ?? 'own_only';
  };

  // Verificar se usuário tem permissão específica (sobrescrita)
  const userHasOverride = (resourceKey: string, action: PermissionAction): boolean | null => {
    const perm = userPermissions.find(p => p.resource_key === resourceKey && p.action === action);
    return perm ? perm.allowed : null;
  };

  // Obter escopo do usuário
  const getUserScope = (resourceKey: string): PermissionScope | null => {
    const perm = userPermissions.find(p => p.resource_key === resourceKey && p.action === 'view');
    return perm?.scope ?? null;
  };

  // Salvar permissão de role
  const handleRolePermissionChange = async (
    resourceKey: string, 
    action: PermissionAction, 
    allowed: boolean
  ) => {
    if (!selectedRoleId) return;
    
    setSaving(true);
    try {
      await updateRolePermission(
        selectedRoleId, 
        resourceKey, 
        action, 
        allowed,
        getRoleScope(resourceKey)
      );
      
      // Atualizar estado local
      setRolePermissions(prev => {
        const existing = prev.find(p => p.resource_key === resourceKey && p.action === action);
        if (existing) {
          return prev.map(p => 
            p.resource_key === resourceKey && p.action === action 
              ? { ...p, allowed }
              : p
          );
        }
        return [...prev, { 
          id: '', 
          role_id: selectedRoleId, 
          resource_key: resourceKey, 
          action, 
          allowed,
          scope: getRoleScope(resourceKey)
        }];
      });
      
      toast.success('Permissão atualizada');
    } catch (err) {
      toast.error('Erro ao atualizar permissão');
    } finally {
      setSaving(false);
    }
  };

  // Salvar escopo de role
  const handleRoleScopeChange = async (resourceKey: string, scope: PermissionScope) => {
    if (!selectedRoleId) return;
    
    setSaving(true);
    try {
      // Atualizar escopo para todas as ações do recurso
      const actions: PermissionAction[] = ['view', 'create', 'edit', 'delete', 'export'];
      
      for (const action of actions) {
        const perm = rolePermissions.find(p => p.resource_key === resourceKey && p.action === action);
        if (perm) {
          await updateRolePermission(selectedRoleId, resourceKey, action, perm.allowed, scope);
        }
      }
      
      // Atualizar estado local
      setRolePermissions(prev => 
        prev.map(p => p.resource_key === resourceKey ? { ...p, scope } : p)
      );
      
      toast.success('Escopo atualizado');
    } catch (err) {
      toast.error('Erro ao atualizar escopo');
    } finally {
      setSaving(false);
    }
  };

  // Salvar permissão de usuário
  const handleUserPermissionChange = async (
    resourceKey: string, 
    action: PermissionAction, 
    allowed: boolean | null
  ) => {
    if (!selectedUserId) return;
    
    setSaving(true);
    try {
      if (allowed === null) {
        // Remover override
        await removeUserPermission(selectedUserId, resourceKey, action);
        setUserPermissions(prev => 
          prev.filter(p => !(p.resource_key === resourceKey && p.action === action))
        );
      } else {
        // Adicionar/atualizar override
        await updateUserPermission(selectedUserId, resourceKey, action, allowed);
        setUserPermissions(prev => {
          const existing = prev.find(p => p.resource_key === resourceKey && p.action === action);
          if (existing) {
            return prev.map(p => 
              p.resource_key === resourceKey && p.action === action 
                ? { ...p, allowed }
                : p
            );
          }
          return [...prev, { 
            id: '', 
            user_id: selectedUserId, 
            resource_key: resourceKey, 
            action, 
            allowed,
            scope: 'own_only'
          }];
        });
      }
      
      toast.success('Permissão atualizada');
    } catch (err) {
      toast.error('Erro ao atualizar permissão');
    } finally {
      setSaving(false);
    }
  };

  // Renderizar card de permissões de um recurso
  const renderResourcePermissions = (resource: Resource & { children?: Resource[] }, isUserMode: boolean) => {
    const hasChildren = resource.children && resource.children.length > 0;
    const isExpanded = expandedResources.includes(resource.key);

    const exclusiveInfo = EXCLUSIVE_RESOURCES[resource.key];

    return (
      <div key={resource.key} className={`border rounded-lg overflow-hidden ${exclusiveInfo ? 'border-amber-500/50' : ''}`}>
        <Collapsible open={isExpanded} onOpenChange={() => hasChildren && toggleExpand(resource.key)}>
          <div className={`px-4 py-3 ${exclusiveInfo ? 'bg-amber-500/10' : 'bg-muted/30'}`}>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                {hasChildren && (
                  <CollapsibleTrigger asChild>
                    <Button variant="ghost" size="icon" className="h-6 w-6">
                      {isExpanded ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
                    </Button>
                  </CollapsibleTrigger>
                )}
                <div>
                  <div className="flex items-center gap-2">
                    <p className="font-medium text-sm">{resource.name}</p>
                    {exclusiveInfo && (
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger>
                            <Badge variant="outline" className="text-xs gap-1 bg-amber-500/20 border-amber-500/50 text-amber-700">
                              <Lock size={10} />
                              {exclusiveInfo.label}
                            </Badge>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p>Este recurso só é acessível por padrão para o perfil {exclusiveInfo.role}.</p>
                            <p className="text-xs text-muted-foreground">Outros perfis precisam de permissão explícita via "Por Usuário".</p>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    )}
                  </div>
                  {resource.description && (
                    <p className="text-xs text-muted-foreground">{resource.description}</p>
                  )}
                </div>
              </div>
              
              <Badge variant="outline" className="text-xs">
                {resource.resource_type === 'page' ? 'Página' : 'Aba'}
              </Badge>
            </div>

            {/* Ações */}
            <div className="flex items-center gap-4 mt-3 flex-wrap">
              {(['view', 'create', 'edit', 'delete', 'export'] as PermissionAction[]).map(action => {
                const isAllowed = isUserMode 
                  ? userHasOverride(resource.key, action) ?? roleHasPermission(resource.key, action)
                  : roleHasPermission(resource.key, action);
                
                const isOverride = isUserMode && userHasOverride(resource.key, action) !== null;

                return (
                  <div key={action} className="flex items-center gap-1.5">
                    <Checkbox
                      id={`${resource.key}-${action}`}
                      checked={isAllowed}
                      onCheckedChange={(checked) => {
                        if (isUserMode) {
                          handleUserPermissionChange(resource.key, action, checked as boolean);
                        } else {
                          handleRolePermissionChange(resource.key, action, checked as boolean);
                        }
                      }}
                      className={isOverride ? 'border-amber-500' : ''}
                    />
                    <Label 
                      htmlFor={`${resource.key}-${action}`} 
                      className={`text-xs cursor-pointer ${isOverride ? 'text-amber-600 font-medium' : ''}`}
                    >
                      {ACTION_LABELS[action]}
                    </Label>
                    {isOverride && (
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-4 w-4 text-muted-foreground hover:text-destructive"
                        onClick={() => handleUserPermissionChange(resource.key, action, null)}
                        title="Remover sobrescrita"
                      >
                        <X size={10} />
                      </Button>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Escopo */}
            {!isUserMode && (
              <div className="mt-3 flex items-center gap-2">
                <span className="text-xs text-muted-foreground">Escopo:</span>
                <RadioGroup
                  value={getRoleScope(resource.key)}
                  onValueChange={(value) => handleRoleScopeChange(resource.key, value as PermissionScope)}
                  className="flex gap-3"
                >
                  {(['own_only', 'team', 'all'] as PermissionScope[]).map(scope => (
                    <div key={scope} className="flex items-center gap-1">
                      <RadioGroupItem value={scope} id={`${resource.key}-scope-${scope}`} />
                      <Label htmlFor={`${resource.key}-scope-${scope}`} className="text-xs cursor-pointer">
                        {SCOPE_LABELS[scope]}
                      </Label>
                    </div>
                  ))}
                </RadioGroup>
              </div>
            )}
          </div>

          {/* Filhos (abas) */}
          {hasChildren && (
            <CollapsibleContent>
              <div className="border-t divide-y">
                {resource.children?.map(child => (
                  <div key={child.key} className="px-4 py-3 pl-10 bg-background">
                    <div className="flex items-center justify-between mb-2">
                      <p className="text-sm font-medium">{child.name}</p>
                      <Badge variant="secondary" className="text-xs">Aba</Badge>
                    </div>
                    
                    <div className="flex items-center gap-4 flex-wrap">
                      {(['view', 'create', 'edit', 'delete', 'export'] as PermissionAction[]).map(action => {
                        const isAllowed = isUserMode 
                          ? userHasOverride(child.key, action) ?? roleHasPermission(child.key, action)
                          : roleHasPermission(child.key, action);
                        
                        const isOverride = isUserMode && userHasOverride(child.key, action) !== null;

                        return (
                          <div key={action} className="flex items-center gap-1.5">
                            <Checkbox
                              id={`${child.key}-${action}`}
                              checked={isAllowed}
                              onCheckedChange={(checked) => {
                                if (isUserMode) {
                                  handleUserPermissionChange(child.key, action, checked as boolean);
                                } else {
                                  handleRolePermissionChange(child.key, action, checked as boolean);
                                }
                              }}
                              className={isOverride ? 'border-amber-500' : ''}
                            />
                            <Label 
                              htmlFor={`${child.key}-${action}`} 
                              className={`text-xs cursor-pointer ${isOverride ? 'text-amber-600 font-medium' : ''}`}
                            >
                              {ACTION_LABELS[action]}
                            </Label>
                            {isOverride && (
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-4 w-4 text-muted-foreground hover:text-destructive"
                                onClick={() => handleUserPermissionChange(child.key, action, null)}
                                title="Remover sobrescrita"
                              >
                                <X size={10} />
                              </Button>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            </CollapsibleContent>
          )}
        </Collapsible>
      </div>
    );
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="animate-spin h-8 w-8 text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <Shield className="h-5 w-5 text-primary" />
        <h2 className="text-lg font-semibold">Controle de Permissões</h2>
        {saving && <Loader2 className="animate-spin h-4 w-4 text-muted-foreground" />}
      </div>

      <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as 'roles' | 'users')}>
        <TabsList>
          <TabsTrigger value="roles" className="gap-2">
            <Users size={16} />
            Por Perfil
          </TabsTrigger>
          <TabsTrigger value="users" className="gap-2">
            <User size={16} />
            Por Usuário
          </TabsTrigger>
        </TabsList>

        <TabsContent value="roles" className="mt-4 space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Selecione um Perfil</CardTitle>
              <CardDescription>
                Configure as permissões padrão para cada perfil de usuário
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Select value={selectedRoleId || ''} onValueChange={setSelectedRoleId}>
                <SelectTrigger className="w-64">
                  <SelectValue placeholder="Selecione um perfil" />
                </SelectTrigger>
                <SelectContent>
                  {roles.map(role => (
                    <SelectItem key={role.id} value={role.id}>
                      <div className="flex items-center gap-2">
                        {role.name.charAt(0).toUpperCase() + role.name.slice(1)}
                        {role.is_system && (
                          <Badge variant="secondary" className="text-xs">Sistema</Badge>
                        )}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </CardContent>
          </Card>

          {selectedRoleId && (
            <>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Lock size={12} className="text-amber-600" />
                <span>Recursos com fundo amarelo são exclusivos de um perfil específico e não podem ser concedidos a outros perfis por padrão.</span>
              </div>

              <ScrollArea className="h-[500px] pr-4">
                <div className="space-y-3">
                  {organizedResources.map(resource => renderResourcePermissions(resource, false))}
                </div>
              </ScrollArea>
            </>
          )}
        </TabsContent>

        <TabsContent value="users" className="mt-4 space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Selecione um Usuário</CardTitle>
              <CardDescription>
                Configure permissões específicas que sobrescrevem o perfil do usuário
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Select value={selectedUserId || ''} onValueChange={setSelectedUserId}>
                <SelectTrigger className="w-64">
                  <SelectValue placeholder="Selecione um usuário" />
                </SelectTrigger>
                <SelectContent>
                  {sellers.map(seller => (
                    <SelectItem key={seller.user_id || seller.id} value={seller.user_id || seller.id}>
                      <div className="flex items-center gap-2">
                        {seller.name}
                        <Badge variant="outline" className="text-xs">
                          {seller.role === 'admin' ? 'Admin' : seller.role === 'logistica' ? 'Logística' : seller.role === 'comprador' ? 'Comprador' : seller.role === 'financeiro' ? 'Financeiro' : seller.role === 'owner' ? 'Owner' : 'Vendedor'}
                        </Badge>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </CardContent>
          </Card>

          {selectedUserId && (
            <>
              <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded border-2 border-amber-500" />
                  <span>Permissões sobrescritas para este usuário</span>
                </div>
                <div className="flex items-center gap-2">
                  <Lock size={12} className="text-amber-600" />
                  <span>Recursos exclusivos de um perfil específico</span>
                </div>
              </div>

              <ScrollArea className="h-[500px] pr-4">
                <div className="space-y-3">
                  {organizedResources.map(resource => renderResourcePermissions(resource, true))}
                </div>
              </ScrollArea>
            </>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
