import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { useAuth } from '@/hooks/useAuth';
import { useQueryClient } from '@tanstack/react-query';
import { Loader2, Save, AlertTriangle } from 'lucide-react';

interface RoleLimits {
  warn: number;
  block: number;
}

interface TaskLimitsConfig {
  vendedor: RoleLimits;
  financeiro_gestora: RoleLimits;
  logistica: RoleLimits;
  default: RoleLimits;
}

const ROLE_LABELS: Record<string, string> = {
  vendedor: 'Vendedor',
  financeiro_gestora: 'Financeiro / Gestora',
  logistica: 'Logística',
  default: 'Padrão (outros)',
};

const DEFAULT: TaskLimitsConfig = {
  vendedor: { warn: 20, block: 50 },
  financeiro_gestora: { warn: 30, block: 60 },
  logistica: { warn: 15, block: 50 },
  default: { warn: 20, block: 50 },
};

export function TaskLimitsConfig() {
  const { seller } = useAuth();
  const queryClient = useQueryClient();
  const [config, setConfig] = useState<TaskLimitsConfig>(DEFAULT);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from('app_config')
        .select('value')
        .eq('key', 'task_limits')
        .maybeSingle();
      if (data?.value) {
        setConfig({ ...DEFAULT, ...(data.value as any) });
      }
      setLoading(false);
    })();
  }, []);

  const handleSave = async () => {
    setSaving(true);
    const { error } = await supabase
      .from('app_config')
      .upsert({
        key: 'task_limits',
        value: config as any,
        updated_at: new Date().toISOString(),
        updated_by: seller?.id || null,
      });

    if (error) {
      toast.error('Erro ao salvar limites');
    } else {
      toast.success('Limites de tarefas atualizados!');
      queryClient.invalidateQueries({ queryKey: ['app_config', 'task_limits'] });
    }
    setSaving(false);
  };

  const updateRole = (role: keyof TaskLimitsConfig, field: 'warn' | 'block', value: number) => {
    setConfig(prev => ({
      ...prev,
      [role]: { ...prev[role], [field]: value },
    }));
  };

  if (loading) {
    return <div className="flex justify-center py-6"><Loader2 className="animate-spin h-6 w-6 text-primary" /></div>;
  }

  return (
    <Card className="border-border/50">
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2">
          <AlertTriangle className="h-4 w-4 text-amber-500" />
          Limites de Tarefas Abertas
        </CardTitle>
        <p className="text-xs text-muted-foreground">
          Configure quantas tarefas pendentes cada perfil pode ter antes de receber aviso ou bloqueio.
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        {(Object.keys(ROLE_LABELS) as (keyof TaskLimitsConfig)[]).map(role => (
          <div key={role} className="grid grid-cols-3 gap-3 items-end">
            <div>
              <Label className="text-xs font-medium">{ROLE_LABELS[role]}</Label>
            </div>
            <div>
              <Label className="text-[10px] text-muted-foreground">Aviso (warn)</Label>
              <Input
                type="number"
                min={1}
                max={999}
                value={config[role].warn}
                onChange={e => updateRole(role, 'warn', Number(e.target.value))}
                className="h-8"
              />
            </div>
            <div>
              <Label className="text-[10px] text-muted-foreground">Bloqueio (block)</Label>
              <Input
                type="number"
                min={1}
                max={999}
                value={config[role].block}
                onChange={e => updateRole(role, 'block', Number(e.target.value))}
                className="h-8"
              />
            </div>
          </div>
        ))}
        <Button onClick={handleSave} disabled={saving} className="gap-2 w-full">
          {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
          Salvar Limites
        </Button>
      </CardContent>
    </Card>
  );
}
