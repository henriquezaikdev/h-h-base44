import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Switch } from '@/components/ui/switch';
import { Plus, Pencil, Trash2, Loader2, Brain, BookOpen } from 'lucide-react';
import { toast } from 'sonner';

interface KnowledgeItem {
  id: string;
  title: string;
  content: string;
  category: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

const CATEGORIES = [
  { value: 'cultura', label: 'Cultura da Empresa' },
  { value: 'processos', label: 'Processos de Vendas' },
  { value: 'produtos', label: 'Produtos e Serviços' },
  { value: 'scripts', label: 'Scripts de Atendimento' },
  { value: 'objecoes', label: 'Tratamento de Objeções' },
  { value: 'geral', label: 'Geral' },
];

export function CompanyKnowledge() {
  const [items, setItems] = useState<KnowledgeItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [itemToDelete, setItemToDelete] = useState<KnowledgeItem | null>(null);
  const [editingItem, setEditingItem] = useState<KnowledgeItem | null>(null);
  const [formData, setFormData] = useState({
    title: '',
    content: '',
    category: 'geral',
    is_active: true,
  });

  useEffect(() => {
    fetchItems();
  }, []);

  const fetchItems = async () => {
    try {
      const { data, error } = await supabase
        .from('company_knowledge')
        .select('*')
        .order('category', { ascending: true })
        .order('title', { ascending: true });

      if (error) throw error;
      setItems(data || []);
    } catch (error) {
      console.error('Erro ao buscar conhecimento:', error);
      toast.error('Erro ao carregar conhecimento da empresa');
    } finally {
      setLoading(false);
    }
  };

  const handleOpenDialog = (item?: KnowledgeItem) => {
    if (item) {
      setEditingItem(item);
      setFormData({
        title: item.title,
        content: item.content,
        category: item.category,
        is_active: item.is_active,
      });
    } else {
      setEditingItem(null);
      setFormData({
        title: '',
        content: '',
        category: 'geral',
        is_active: true,
      });
    }
    setIsDialogOpen(true);
  };

  const handleSave = async () => {
    if (!formData.title.trim() || !formData.content.trim()) {
      toast.error('Preencha título e conteúdo');
      return;
    }

    setSaving(true);
    try {
      if (editingItem) {
        const { error } = await supabase
          .from('company_knowledge')
          .update({
            title: formData.title.trim(),
            content: formData.content.trim(),
            category: formData.category,
            is_active: formData.is_active,
          })
          .eq('id', editingItem.id);

        if (error) throw error;
        toast.success('Conhecimento atualizado!');
      } else {
        const { error } = await supabase
          .from('company_knowledge')
          .insert({
            title: formData.title.trim(),
            content: formData.content.trim(),
            category: formData.category,
            is_active: formData.is_active,
          });

        if (error) throw error;
        toast.success('Conhecimento adicionado!');
      }

      setIsDialogOpen(false);
      fetchItems();
    } catch (error: any) {
      console.error('Erro ao salvar:', error);
      toast.error(error.message || 'Erro ao salvar');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!itemToDelete) return;

    try {
      const { error } = await supabase
        .from('company_knowledge')
        .delete()
        .eq('id', itemToDelete.id);

      if (error) throw error;

      setDeleteConfirmOpen(false);
      setItemToDelete(null);
      toast.success('Conhecimento removido');
      fetchItems();
    } catch (error: any) {
      console.error('Erro ao remover:', error);
      toast.error(error.message || 'Erro ao remover');
    }
  };

  const handleToggleActive = async (item: KnowledgeItem) => {
    try {
      const { error } = await supabase
        .from('company_knowledge')
        .update({ is_active: !item.is_active })
        .eq('id', item.id);

      if (error) throw error;
      
      setItems(prev => prev.map(i => 
        i.id === item.id ? { ...i, is_active: !i.is_active } : i
      ));
      toast.success(item.is_active ? 'Desativado' : 'Ativado');
    } catch (error: any) {
      console.error('Erro ao alterar status:', error);
      toast.error('Erro ao alterar status');
    }
  };

  const getCategoryLabel = (value: string) => {
    return CATEGORIES.find(c => c.value === value)?.label || value;
  };

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      cultura: 'bg-purple-500/10 text-purple-600',
      processos: 'bg-blue-500/10 text-blue-600',
      produtos: 'bg-green-500/10 text-green-600',
      scripts: 'bg-orange-500/10 text-orange-600',
      objecoes: 'bg-red-500/10 text-red-600',
      geral: 'bg-gray-500/10 text-gray-600',
    };
    return colors[category] || colors.geral;
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="font-semibold text-foreground flex items-center gap-2">
            <Brain className="h-5 w-5 text-primary" />
            Base de Conhecimento da IA
          </h3>
          <p className="text-sm text-muted-foreground">
            Adicione informações sobre cultura, processos e scripts para a IA usar nas respostas
          </p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => handleOpenDialog()}>
              <Plus size={18} className="mr-2" />
              Novo Conhecimento
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>
                {editingItem ? 'Editar Conhecimento' : 'Adicionar Conhecimento'}
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Título *</Label>
                  <Input
                    placeholder="Ex: Regras de Negociação"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Categoria</Label>
                  <Select
                    value={formData.category}
                    onValueChange={(value) => setFormData({ ...formData, category: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {CATEGORIES.map((cat) => (
                        <SelectItem key={cat.value} value={cat.value}>
                          {cat.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label>Conteúdo *</Label>
                <Textarea
                  placeholder="Descreva as regras, processos, scripts ou informações que a IA deve seguir..."
                  value={formData.content}
                  onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                  rows={10}
                  className="resize-none"
                />
                <p className="text-xs text-muted-foreground">
                  Seja específico e detalhado. A IA usará este conteúdo para responder de acordo com a cultura da empresa.
                </p>
              </div>
              <div className="flex items-center gap-2">
                <Switch
                  checked={formData.is_active}
                  onCheckedChange={(checked) => setFormData({ ...formData, is_active: checked })}
                />
                <Label className="cursor-pointer">Ativo</Label>
              </div>
              <div className="flex justify-end gap-3 pt-4">
                <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancelar
                </Button>
                <Button onClick={handleSave} disabled={saving}>
                  {saving ? (
                    <>
                      <Loader2 className="animate-spin mr-2 h-4 w-4" />
                      Salvando...
                    </>
                  ) : (
                    'Salvar'
                  )}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="animate-spin h-8 w-8 text-primary" />
        </div>
      ) : items.length === 0 ? (
        <div className="card-section text-center py-12">
          <BookOpen className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
          <h4 className="font-medium mb-2">Nenhum conhecimento cadastrado</h4>
          <p className="text-sm text-muted-foreground mb-4">
            Adicione informações sobre a cultura e processos da empresa para a IA usar nas respostas.
          </p>
          <Button onClick={() => handleOpenDialog()}>
            <Plus size={18} className="mr-2" />
            Adicionar Primeiro Conhecimento
          </Button>
        </div>
      ) : (
        <div className="space-y-3">
          {items.map((item) => (
            <div
              key={item.id}
              className={`card-section ${!item.is_active ? 'opacity-60' : ''}`}
            >
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-2">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${getCategoryColor(item.category)}`}>
                      {getCategoryLabel(item.category)}
                    </span>
                    {!item.is_active && (
                      <span className="px-2 py-1 rounded-full text-xs bg-muted text-muted-foreground">
                        Desativado
                      </span>
                    )}
                  </div>
                  <h4 className="font-medium text-foreground">{item.title}</h4>
                  <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                    {item.content}
                  </p>
                </div>
                <div className="flex items-center gap-2 flex-shrink-0">
                  <Switch
                    checked={item.is_active}
                    onCheckedChange={() => handleToggleActive(item)}
                  />
                  <button
                    className="p-2 hover:bg-muted rounded-lg transition-colors"
                    onClick={() => handleOpenDialog(item)}
                  >
                    <Pencil size={16} className="text-muted-foreground" />
                  </button>
                  <button
                    className="p-2 hover:bg-destructive/10 rounded-lg transition-colors"
                    onClick={() => {
                      setItemToDelete(item);
                      setDeleteConfirmOpen(true);
                    }}
                  >
                    <Trash2 size={16} className="text-destructive" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Delete Confirmation */}
      <AlertDialog open={deleteConfirmOpen} onOpenChange={setDeleteConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmar exclusão</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja remover "{itemToDelete?.title}"? Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Excluir
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
