import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import { Loader2, Trash2, ArrowRightLeft } from 'lucide-react';

interface Equivalencia {
  id: string;
  produto_a_nome: string;
  produto_b_nome: string;
  ativo: boolean;
  confirmado_em: string | null;
}

export function EquivalenciasPanel() {
  const [loading, setLoading] = useState(true);
  const [items, setItems] = useState<Equivalencia[]>([]);

  const fetchEquivalencias = useCallback(async () => {
    setLoading(true);
    try {
      const { data: eqs, error } = await (supabase as any)
        .from('hh_produto_equivalencia')
        .select('id, produto_id_a, produto_id_b, ativo, confirmado_em')
        .eq('ativo', true)
        .order('confirmado_em', { ascending: false });

      if (error) throw error;
      if (!eqs || eqs.length === 0) {
        setItems([]);
        setLoading(false);
        return;
      }

      // Get product names
      const productIds = new Set<string>();
      eqs.forEach((eq: any) => {
        productIds.add(eq.produto_id_a);
        productIds.add(eq.produto_id_b);
      });

      const { data: products } = await supabase
        .from('products')
        .select('id, name')
        .in('id', Array.from(productIds)) as any;

      const nameMap: Record<string, string> = {};
      (products || []).forEach((p: any) => { nameMap[p.id] = p.name; });

      const result: Equivalencia[] = eqs.map((eq: any) => ({
        id: eq.id,
        produto_a_nome: nameMap[eq.produto_id_a] || 'Produto desconhecido',
        produto_b_nome: nameMap[eq.produto_id_b] || 'Produto desconhecido',
        ativo: eq.ativo,
        confirmado_em: eq.confirmado_em,
      }));

      setItems(result);
    } catch (err) {
      console.error('Error fetching equivalencias:', err);
      toast.error('Erro ao carregar equivalências.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchEquivalencias();
  }, [fetchEquivalencias]);

  const handleDeactivate = async (id: string) => {
    try {
      const { error } = await (supabase as any)
        .from('hh_produto_equivalencia')
        .update({ ativo: false })
        .eq('id', id);

      if (error) throw error;
      toast.success('Equivalência desfeita.');
      setItems((prev) => prev.filter((i) => i.id !== id));
    } catch (err) {
      console.error('Error deactivating:', err);
      toast.error('Erro ao desfazer equivalência.');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="text-center py-12">
        <ArrowRightLeft className="h-8 w-8 text-muted-foreground/40 mx-auto mb-3" />
        <p className="text-sm text-muted-foreground">
          Nenhuma equivalência cadastrada ainda.
        </p>
        <p className="text-xs text-muted-foreground mt-1">
          As equivalências são criadas na análise de recompra dos clientes.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <p className="text-sm text-muted-foreground mb-4">
        Produtos marcados como equivalentes são tratados como um único item nas análises de recompra.
      </p>

      <div className="rounded-xl border border-border bg-white overflow-hidden">
        <div className="grid grid-cols-[1fr_1fr_80px] gap-2 px-4 py-2.5 bg-muted/30 border-b border-border">
          <span className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">Produto A</span>
          <span className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">Produto B</span>
          <span className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground text-center">Ações</span>
        </div>

        {items.map((item, i) => (
          <div
            key={item.id}
            className={`grid grid-cols-[1fr_1fr_80px] gap-2 px-4 py-3 text-[13px] items-center ${
              i % 2 === 0 ? 'bg-white' : 'bg-muted/10'
            }`}
          >
            <span className="text-foreground font-medium truncate" title={item.produto_a_nome}>
              {item.produto_a_nome}
            </span>
            <span className="text-foreground font-medium truncate" title={item.produto_b_nome}>
              {item.produto_b_nome}
            </span>
            <div className="flex justify-center">
              <Button
                variant="ghost"
                size="sm"
                className="h-7 w-7 p-0 text-muted-foreground hover:text-destructive"
                onClick={() => handleDeactivate(item.id)}
                title="Desfazer equivalência"
              >
                <Trash2 className="h-3.5 w-3.5" />
              </Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
