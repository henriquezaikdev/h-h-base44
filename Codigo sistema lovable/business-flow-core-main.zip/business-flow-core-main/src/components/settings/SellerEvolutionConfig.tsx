import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { Loader2, TrendingUp, Egg, Feather, Bird, Save } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

interface SellerWithLevel {
  id: string;
  name: string;
  currentLevel: 'ovo' | 'pena' | 'aguia' | null;
  hasConfig: boolean;
}

const LEVEL_CONFIG = {
  ovo: { 
    label: 'Ovo (Aprendiz)', 
    icon: Egg, 
    color: 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300',
    bonus: '0%'
  },
  pena: { 
    label: 'Pena (Intermediário)', 
    icon: Feather, 
    color: 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300',
    bonus: '+0,5%'
  },
  aguia: { 
    label: 'Águia', 
    icon: Bird, 
    color: 'bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-300',
    bonus: '+1%'
  },
};

export function SellerEvolutionConfig() {
  const queryClient = useQueryClient();
  const [sellers, setSellers] = useState<SellerWithLevel[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState<string | null>(null);
  const [pendingChanges, setPendingChanges] = useState<Record<string, 'ovo' | 'pena' | 'aguia'>>({});

  useEffect(() => {
    fetchSellersWithLevels();
  }, []);

  const fetchSellersWithLevels = async () => {
    try {
      // Fetch active sellers (only vendedor role)
      const { data: sellersData, error: sellersError } = await supabase
        .from('sellers')
        .select('id, name')
        .eq('status', 'ATIVO')
        .eq('role', 'vendedor')
        .order('name');

      if (sellersError) throw sellersError;

      // Fetch seller_levels
      const { data: levelsData, error: levelsError } = await supabase
        .from('seller_levels')
        .select('seller_id, current_level');

      if (levelsError) throw levelsError;

      const levelsMap = new Map(
        (levelsData || []).map(level => [level.seller_id, level.current_level])
      );

      const combined: SellerWithLevel[] = (sellersData || []).map(seller => ({
        id: seller.id,
        name: seller.name || 'Vendedor',
        currentLevel: (levelsMap.get(seller.id) as 'ovo' | 'pena' | 'aguia') || null,
        hasConfig: levelsMap.has(seller.id),
      }));

      setSellers(combined);
    } catch (error) {
      console.error('Error fetching sellers with levels:', error);
      toast.error('Erro ao carregar níveis dos vendedores');
    } finally {
      setLoading(false);
    }
  };

  const handleLevelChange = (sellerId: string, newLevel: 'ovo' | 'pena' | 'aguia') => {
    setPendingChanges(prev => ({ ...prev, [sellerId]: newLevel }));
  };

  const handleSave = async (sellerId: string) => {
    const newLevel = pendingChanges[sellerId];
    if (!newLevel) return;

    setSaving(sellerId);
    try {
      const { error } = await supabase
        .from('seller_levels')
        .upsert({
          seller_id: sellerId,
          current_level: newLevel,
        }, { onConflict: 'seller_id' });

      if (error) throw error;

      // Update local state
      setSellers(prev => prev.map(seller => 
        seller.id === sellerId 
          ? { ...seller, currentLevel: newLevel, hasConfig: true }
          : seller
      ));

      // Clear pending change
      setPendingChanges(prev => {
        const { [sellerId]: _, ...rest } = prev;
        return rest;
      });

      // Invalidate related queries
      queryClient.invalidateQueries({ queryKey: ['evolution-data'] });
      queryClient.invalidateQueries({ queryKey: ['seller-metrics'] });

      toast.success('Nível atualizado com sucesso!');
    } catch (error: any) {
      console.error('Error saving level:', error);
      toast.error(error.message || 'Erro ao salvar nível');
    } finally {
      setSaving(null);
    }
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center py-12">
          <Loader2 className="animate-spin h-8 w-8 text-primary" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <TrendingUp className="h-5 w-5 text-primary" />
          Configurar Níveis de Evolução
        </CardTitle>
        <CardDescription>
          Defina o nível inicial de cada vendedor. Promoções e rebaixamentos ocorrem automaticamente 
          conforme o desempenho mensal.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="rounded-md border overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Vendedor</TableHead>
                <TableHead>Nível Atual</TableHead>
                <TableHead>Bônus Comissão</TableHead>
                <TableHead className="text-center">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sellers.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={4} className="text-center text-muted-foreground py-8">
                    Nenhum vendedor ativo encontrado
                  </TableCell>
                </TableRow>
              ) : (
                sellers.map((seller) => {
                  const currentLevel = pendingChanges[seller.id] || seller.currentLevel || 'ovo';
                  const levelConfig = LEVEL_CONFIG[currentLevel];
                  const hasPendingChange = pendingChanges[seller.id] !== undefined;
                  const isSaving = saving === seller.id;
                  const LevelIcon = levelConfig.icon;

                  return (
                    <TableRow key={seller.id}>
                      <TableCell className="font-medium">{seller.name}</TableCell>
                      <TableCell>
                        <Select
                          value={currentLevel}
                          onValueChange={(v: 'ovo' | 'pena' | 'aguia') => handleLevelChange(seller.id, v)}
                        >
                          <SelectTrigger className="w-48">
                            <SelectValue>
                              <div className="flex items-center gap-2">
                                <LevelIcon className="h-4 w-4" />
                                {levelConfig.label}
                              </div>
                            </SelectValue>
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="ovo">
                              <div className="flex items-center gap-2">
                                <Egg className="h-4 w-4 text-amber-500" />
                                Ovo (Aprendiz)
                              </div>
                            </SelectItem>
                            <SelectItem value="pena">
                              <div className="flex items-center gap-2">
                                <Feather className="h-4 w-4 text-blue-500" />
                                Pena (Intermediário)
                              </div>
                            </SelectItem>
                            <SelectItem value="aguia">
                              <div className="flex items-center gap-2">
                                <Bird className="h-4 w-4 text-purple-500" />
                                Águia
                              </div>
                            </SelectItem>
                          </SelectContent>
                        </Select>
                      </TableCell>
                      <TableCell>
                        <Badge className={levelConfig.color}>
                          {levelConfig.bonus} em margem ≥40%
                        </Badge>
                      </TableCell>
                      <TableCell className="text-center">
                        {hasPendingChange && (
                          <Button
                            variant="default"
                            size="sm"
                            onClick={() => handleSave(seller.id)}
                            disabled={isSaving}
                            className="gap-1"
                          >
                            {isSaving ? (
                              <Loader2 className="h-4 w-4 animate-spin" />
                            ) : (
                              <Save className="h-4 w-4" />
                            )}
                            Salvar
                          </Button>
                        )}
                        {!seller.hasConfig && !hasPendingChange && (
                          <span className="text-xs text-muted-foreground">
                            Não configurado
                          </span>
                        )}
                      </TableCell>
                    </TableRow>
                  );
                })
              )}
            </TableBody>
          </Table>
        </div>

        <div className="mt-4 p-3 bg-muted/50 rounded-lg">
          <p className="text-sm text-muted-foreground">
            <strong>📈 Regras de Evolução:</strong> Vendedores são promovidos após 2 meses consecutivos 
            batendo a meta e rebaixados após 2 meses consecutivos abaixo da meta. O bônus de comissão 
            é aplicado apenas em vendas com margem bruta ≥40%.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
