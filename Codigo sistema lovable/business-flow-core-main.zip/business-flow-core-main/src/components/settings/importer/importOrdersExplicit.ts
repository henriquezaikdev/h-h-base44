import { supabase } from "@/integrations/supabase/client";
import { normalizeProductKey, parseDecimal, toTrimmedString, type Row } from "./spreadsheet";
import type { TablesInsert } from "@/integrations/supabase/types";
import { startImportLog } from "@/lib/importAudit";

export type OrdersMapping = {
  clientName: string;
  orderNumber: string;
  seller: string;
  productName: string;
  category: string;
  // Optional
  orderDate?: string;
  total?: string;
  quantity?: string;
  unitPrice?: string;
  subtotal?: string;
  // Novos campos para prazo de pagamento
  paymentMethod?: string;
  dueDate?: string;
};

type ProgressCb = (processedGroups: number, totalGroups: number) => void;

export interface ImportResult {
  clientsCreated: number;
  clientsUpdated: number;
  ordersCreated: number;
  ordersUpdated: number;
  ordersSkippedDuplicate: number;
  productsCreated: number;
  productsUpdated: number;
  itemsCreated: number;
  itemsReplaced: number;
  linesIgnoredNoOrderNumber: number;
  inventedNumbers: number; // Always 0 - NEVER invent data
}

function pick(row: Row, col?: string): unknown {
  if (!col) return undefined;
  return row[col];
}

function findSellerId(
  rawSeller: string,
  sellersByEmail: Map<string, string>,
  sellersByName: Map<string, string>
): string | null {
  const v = rawSeller.trim();
  if (!v) return null;

  if (v.includes("@")) {
    return sellersByEmail.get(v.toLowerCase()) ?? null;
  }

  return sellersByName.get(v.toLowerCase()) ?? null;
}

// Calcular prazo de pagamento em dias
// REGRA MÃE: Se tem data de vencimento, calcula a partir dela
// Se não, usa fallback pela forma de pagamento
function calculatePaymentTermDays(
  orderDateRaw: string | null,
  dueDateRaw: string | null,
  paymentMethodRaw: string | null
): number | null {
  // PRIORIDADE 1: Calcular pela data de vencimento real
  if (dueDateRaw && orderDateRaw) {
    const orderDate = parseFlexibleDate(orderDateRaw);
    const dueDate = parseFlexibleDate(dueDateRaw);
    
    if (orderDate && dueDate) {
      const diffDays = Math.round((dueDate.getTime() - orderDate.getTime()) / (1000 * 60 * 60 * 24));
      return Math.max(0, diffDays);
    }
  }
  
  // PRIORIDADE 2: Fallback pela forma de pagamento
  if (paymentMethodRaw) {
    return getPaymentTermFallback(paymentMethodRaw);
  }
  
  return null;
}

// Parser flexível para datas
function parseFlexibleDate(dateStr: string): Date | null {
  if (!dateStr) return null;
  
  const clean = dateStr.trim();
  
  // Formato ISO: 2024-03-15
  if (/^\d{4}-\d{2}-\d{2}$/.test(clean)) {
    const d = new Date(clean);
    if (!isNaN(d.getTime())) return d;
  }
  
  // Formato BR: 15/03/2024 ou 15/03/24
  const brMatch = clean.match(/^(\d{1,2})\/(\d{1,2})\/(\d{2,4})$/);
  if (brMatch) {
    const day = parseInt(brMatch[1], 10);
    const month = parseInt(brMatch[2], 10) - 1;
    let year = parseInt(brMatch[3], 10);
    if (year < 100) year += 2000;
    const d = new Date(year, month, day);
    if (!isNaN(d.getTime())) return d;
  }
  
  return null;
}

// Fallback: prazo baseado na forma de pagamento
function getPaymentTermFallback(paymentMethod: string): number {
  const normalized = paymentMethod.toLowerCase().trim();
  
  // PIX, Dinheiro, À vista, Débito → 0 dias
  if (/pix|dinheiro|à vista|a vista|d[eé]bito|dep[oó]sito/i.test(normalized)) {
    return 0;
  }
  
  // Boleto com prazo específico: "Boleto 28 dias" → extrair 28
  const daysMatch = normalized.match(/(\d+)\s*dia/i);
  if (daysMatch) {
    return parseInt(daysMatch[1], 10);
  }
  
  // Boleto genérico → 30 dias
  if (/boleto/i.test(normalized)) {
    return 30;
  }
  
  // Cheque → 30 dias
  if (/cheque/i.test(normalized)) {
    return 30;
  }
  
  // Crédito → 30 dias
  if (/cr[eé]dito/i.test(normalized)) {
    return 30;
  }
  
  return 0;
}

export async function importOrdersExplicit(
  rows: Row[],
  mapping: OrdersMapping,
  onProgress?: ProgressCb
): Promise<ImportResult> {
  // AUDITORIA: Iniciar log persistente
  const importLog = await startImportLog({
    import_type: 'order_spreadsheet',
    source: 'xlsx',
    payload_summary: { 
      rowCount: rows.length,
      mappedFields: Object.keys(mapping).filter(k => (mapping as any)[k])
    }
  });

  const result: ImportResult = {
    clientsCreated: 0,
    clientsUpdated: 0,
    ordersCreated: 0,
    ordersUpdated: 0,
    ordersSkippedDuplicate: 0,
    productsCreated: 0,
    productsUpdated: 0,
    itemsCreated: 0,
    itemsReplaced: 0,
    linesIgnoredNoOrderNumber: 0,
    inventedNumbers: 0, // ALWAYS 0 - we never invent data
  };

  try {

  // Preload reference data
  const [{ data: sellers }, { data: clients }, { data: products }, { data: orders }] = await Promise.all([
    supabase.from("sellers").select("id, name, email"),
    supabase.from("clients").select("id, company_name, seller_id"),
    supabase.from("products").select("id, normalized_name, category, last_sold_at, cost_price"),
    supabase.from("orders").select("id, order_number, client_id, order_date, total, seller_id").eq('is_deleted', false),
  ]);

  const sellersByEmail = new Map<string, string>();
  const sellersByName = new Map<string, string>();
  (sellers ?? []).forEach((s) => {
    if (s.email) sellersByEmail.set(String(s.email).toLowerCase().trim(), s.id);
    sellersByName.set(String(s.name).toLowerCase().trim(), s.id);
  });

  const clientsByName = new Map<string, { id: string; seller_id: string | null }>();
  (clients ?? []).forEach((c) => {
    clientsByName.set(String(c.company_name).toLowerCase().trim(), { id: c.id, seller_id: c.seller_id });
  });

  const productsByNorm = new Map<
    string,
    { id: string; category: string | null; last_sold_at: string | null; cost_price: number | null }
  >();
  (products ?? []).forEach((p) => {
    productsByNorm.set(p.normalized_name, {
      id: p.id,
      category: p.category,
      last_sold_at: p.last_sold_at,
      cost_price: p.cost_price ?? null,
    });
  });

  const ordersByNumber = new Map<string, { id: string; client_id: string; order_date: string | null; total: number | null; seller_id: string | null }>();
  (orders ?? []).forEach((o) => {
    const n = o.order_number;
    if (n && String(n).trim()) {
      ordersByNumber.set(String(n).trim(), { 
        id: o.id, 
        client_id: o.client_id, 
        order_date: o.order_date, 
        total: o.total,
        seller_id: o.seller_id 
      });
    }
  });

  // Group strictly by the explicit order_number column (no fallback keys)
  const groups = new Map<string, Row[]>();
  for (const row of rows) {
    const orderNumber = toTrimmedString(pick(row, mapping.orderNumber));
    if (!orderNumber) {
      result.linesIgnoredNoOrderNumber++;
      continue;
    }

    if (!groups.has(orderNumber)) groups.set(orderNumber, []);
    groups.get(orderNumber)!.push(row);
  }

  const totalGroups = groups.size;
  let processedGroups = 0;

  // Track orders per client to determine last order date for seller update
  const clientOrderDates = new Map<string, { sellerId: string | null; orderDate: string | null }[]>();

  for (const [orderNumber, groupRows] of groups) {
    const first = groupRows[0] ?? {};

    const clientName = toTrimmedString(pick(first, mapping.clientName));
    const rawSeller = toTrimmedString(pick(first, mapping.seller));
    const sellerId = findSellerId(rawSeller, sellersByEmail, sellersByName);

    // UPSERT client by name
    let clientInfo = clientName ? clientsByName.get(clientName.toLowerCase()) ?? null : null;

    if (!clientInfo) {
      if (!clientName) {
        processedGroups++;
        onProgress?.(processedGroups, totalGroups);
        continue;
      }

      const insertPayload: TablesInsert<"clients"> = {
        company_name: clientName,
        ...(sellerId ? { seller_id: sellerId } : {}),
      };

      const { data: insertedClient, error: clientErr } = await supabase
        .from("clients")
        .insert(insertPayload)
        .select("id, seller_id")
        .single();

      if (clientErr || !insertedClient) {
        processedGroups++;
        onProgress?.(processedGroups, totalGroups);
        continue;
      }

      clientInfo = { id: insertedClient.id, seller_id: insertedClient.seller_id };
      clientsByName.set(clientName.toLowerCase(), clientInfo);
      result.clientsCreated++;
    }

    // Order date from spreadsheet ONLY - NEVER invent
    const orderDateRaw = mapping.orderDate ? toTrimmedString(pick(first, mapping.orderDate)) : null;
    
    // Payment method and due date from spreadsheet - for calculating payment term
    const paymentMethodRaw = mapping.paymentMethod ? toTrimmedString(pick(first, mapping.paymentMethod)) : null;
    const dueDateRaw = mapping.dueDate ? toTrimmedString(pick(first, mapping.dueDate)) : null;

    // Track for later seller update based on last order
    if (!clientOrderDates.has(clientInfo.id)) {
      clientOrderDates.set(clientInfo.id, []);
    }
    clientOrderDates.get(clientInfo.id)!.push({ sellerId, orderDate: orderDateRaw });

    // Calculate total from items - ONLY from spreadsheet data, NEVER invent
    let totalRaw = mapping.total ? parseDecimal(pick(first, mapping.total)) : null;

    // If total not mapped or is zero, calculate from item subtotals
    if (totalRaw === null || totalRaw === 0) {
      let calculatedTotal = 0;
      for (const r of groupRows) {
        const subtotal = mapping.subtotal ? parseDecimal(pick(r, mapping.subtotal)) : null;
        if (subtotal !== null && subtotal > 0) {
          calculatedTotal += subtotal;
        } else {
          // Try to calculate from quantity * unit price
          const qty = mapping.quantity ? parseDecimal(pick(r, mapping.quantity)) : null;
          const price = mapping.unitPrice ? parseDecimal(pick(r, mapping.unitPrice)) : null;
          if (qty !== null && price !== null) {
            calculatedTotal += qty * price;
          }
        }
      }
      if (calculatedTotal > 0) {
        totalRaw = calculatedTotal;
      }
    }

    // Check if order already exists
    const existingOrder = ordersByNumber.get(orderNumber);
    
    let orderId: string;
    
    if (existingOrder) {
      // ORDER EXISTS - UPDATE it (fix zeroed values) and replace items
      orderId = existingOrder.id;
      
      const updates: Record<string, unknown> = {};
      
      // Update total if current is null/zero and we have a value
      if ((existingOrder.total === null || existingOrder.total === 0) && totalRaw !== null && totalRaw > 0) {
        updates.total = totalRaw;
      }
      
      // Update order_date if current is null and we have a value
      if (existingOrder.order_date === null && orderDateRaw) {
        updates.order_date = orderDateRaw;
      }
      
      // Update seller if current is null and we have a value
      if (existingOrder.seller_id === null && sellerId) {
        updates.seller_id = sellerId;
      }
      
      // Calcular e atualizar prazo de pagamento se ainda não tiver
      const paymentTermDays = calculatePaymentTermDays(orderDateRaw, dueDateRaw, paymentMethodRaw);
      if (paymentMethodRaw) {
        updates.payment_method = paymentMethodRaw;
      }
      if (paymentTermDays !== null) {
        updates.payment_term_days = paymentTermDays;
      }
      if (dueDateRaw) {
        updates.due_dates = [dueDateRaw];
      }
      
      if (Object.keys(updates).length > 0) {
        const { error: updateErr } = await supabase
          .from("orders")
          .update(updates)
          .eq("id", orderId);
        
        if (!updateErr) {
          result.ordersUpdated++;
        }
      } else {
        result.ordersSkippedDuplicate++;
      }
      
      // DELETE existing order_items to replace them with correct values
      const { data: deletedItems, error: deleteErr } = await supabase
        .from("order_items")
        .delete()
        .eq("order_id", orderId)
        .select("id");
      
      if (!deleteErr && deletedItems) {
        result.itemsReplaced += deletedItems.length;
      }
      
    } else {
      // ORDER DOES NOT EXIST - CREATE it with UPSERT for idempotency
      
      // Calcular prazo de pagamento
      const paymentTermDays = calculatePaymentTermDays(orderDateRaw, dueDateRaw, paymentMethodRaw);
      
      const orderInsert: TablesInsert<"orders"> = {
        client_id: clientInfo.id,
        order_number: orderNumber,
        ...(sellerId ? { seller_id: sellerId } : {}),
        ...(orderDateRaw ? { order_date: orderDateRaw } : {}),
        ...(totalRaw !== null ? { total: totalRaw } : {}),
        ...(paymentMethodRaw ? { payment_method: paymentMethodRaw } : {}),
        ...(paymentTermDays !== null ? { payment_term_days: paymentTermDays } : {}),
        ...(dueDateRaw ? { due_dates: [dueDateRaw] } : {}),
      };

      const { data: newOrder, error: orderErr } = await supabase
        .from("orders")
        .upsert(orderInsert, {
          onConflict: 'order_number,client_id',
          ignoreDuplicates: false
        })
        .select("id")
        .single();

      if (orderErr || !newOrder) {
        // Se erro de conflito, tentar buscar o pedido existente
        if (orderErr?.code === '23505') {
          const { data: existingOrder } = await supabase
            .from("orders")
            .select("id")
            .eq("order_number", orderNumber)
            .eq("client_id", clientInfo.id)
            .maybeSingle();
          
          if (existingOrder) {
            orderId = existingOrder.id;
            result.ordersSkippedDuplicate++;
          } else {
            processedGroups++;
            onProgress?.(processedGroups, totalGroups);
            continue;
          }
        } else {
          processedGroups++;
          onProgress?.(processedGroups, totalGroups);
          continue;
        }
      } else {
        orderId = newOrder.id;
        result.ordersCreated++;
        ordersByNumber.set(orderNumber, { 
          id: newOrder.id, 
          client_id: clientInfo.id, 
          order_date: orderDateRaw, 
          total: totalRaw,
          seller_id: sellerId 
        });
      }
    }

    // Items - create for the order
    const itemsToInsert: Array<{
      order_id: string;
      product_name: string;
      product_id: string | null;
      quantity: number | null;
      unit_price: number | null;
      subtotal: number | null;
      cost_price: number | null;
      cost_subtotal: number | null;
    }> = [];

    for (const r of groupRows) {
      const productName = toTrimmedString(pick(r, mapping.productName));
      if (!productName) continue;

      const category = toTrimmedString(pick(r, mapping.category)) || null;
      const norm = normalizeProductKey(productName);

      let productInfo = productsByNorm.get(norm) ?? null;

      if (!productInfo) {
        const insertPayload: TablesInsert<"products"> = {
          name: productName,
          normalized_name: norm,
          ...(category ? { category } : {}),
          ...(orderDateRaw ? { last_sold_at: orderDateRaw } : {}),
          active: true,
        };

        const { data: newProduct, error: prodErr } = await supabase
          .from("products")
          .insert(insertPayload)
          .select("id, category, last_sold_at, cost_price")
          .single();

        if (!prodErr && newProduct) {
          productInfo = {
            id: newProduct.id,
            category: newProduct.category,
            last_sold_at: newProduct.last_sold_at,
            cost_price: newProduct.cost_price ?? null,
          };
          productsByNorm.set(norm, productInfo);
          result.productsCreated++;
        }
      } else {
        // Update category if missing, and update last_sold_at if newer
        const updates: Record<string, unknown> = {};
        if (category && !productInfo.category) {
          updates.category = category;
        }
        if (orderDateRaw && (!productInfo.last_sold_at || orderDateRaw > productInfo.last_sold_at)) {
          updates.last_sold_at = orderDateRaw;
        }

        if (Object.keys(updates).length > 0) {
          const { error: upProdErr } = await supabase.from("products").update(updates).eq("id", productInfo.id);
          if (!upProdErr) {
            productsByNorm.set(norm, { ...productInfo, ...updates } as typeof productInfo);
            result.productsUpdated++;
          }
        }
      }

      // Get values from spreadsheet ONLY - NEVER invent
      const quantity = mapping.quantity ? parseDecimal(pick(r, mapping.quantity)) : null;
      const unitPrice = mapping.unitPrice ? parseDecimal(pick(r, mapping.unitPrice)) : null;
      let subtotal = mapping.subtotal ? parseDecimal(pick(r, mapping.subtotal)) : null;
      
      // Calculate subtotal if not provided but quantity and unitPrice exist
      if ((subtotal === null || subtotal === 0) && quantity !== null && unitPrice !== null) {
        subtotal = quantity * unitPrice;
      }

      const costPrice = productInfo?.cost_price ?? null;
      const costSubtotal = costPrice !== null && quantity !== null ? costPrice * quantity : null;

      itemsToInsert.push({
        order_id: orderId,
        product_name: productName,
        product_id: productInfo?.id ?? null,
        quantity,
        unit_price: unitPrice,
        subtotal,
        cost_price: costPrice,
        cost_subtotal: costSubtotal,
      });
    }

    if (itemsToInsert.length > 0) {
      const { error: itemsErr } = await supabase.from("order_items").insert(itemsToInsert);
      if (!itemsErr) {
        result.itemsCreated += itemsToInsert.length;

        // Recalcula custo + margem do pedido com base no custo cadastrado do produto
        const totalFromItems = itemsToInsert.reduce((acc, it) => acc + (it.subtotal ?? 0), 0);
        const totalForCalc = totalRaw && totalRaw > 0 ? totalRaw : totalFromItems > 0 ? totalFromItems : null;

        const hasAnyCost = itemsToInsert.some((it) => it.cost_subtotal !== null);
        const totalCost = itemsToInsert.reduce((acc, it) => acc + (it.cost_subtotal ?? 0), 0);

        const orderUpdates: Record<string, unknown> = {};

        if (hasAnyCost) {
          orderUpdates.total_cost = totalCost;
        }

        // Mantém a regra: não inventar total — mas se o total veio do cálculo acima, é derivado das linhas da planilha.
        if ((!totalRaw || totalRaw === 0) && totalForCalc !== null) {
          orderUpdates.total = totalForCalc;
        }

        if (totalForCalc !== null && totalForCalc > 0 && hasAnyCost) {
          const profit = totalForCalc - totalCost;
          orderUpdates.profit = profit;
          orderUpdates.profit_margin = (profit / totalForCalc) * 100;
        }

        if (Object.keys(orderUpdates).length > 0) {
          await supabase.from("orders").update(orderUpdates).eq("id", orderId);
        }
      }
    }

    processedGroups++;
    onProgress?.(processedGroups, totalGroups);
  }

  // Update seller_id on clients based on the LATEST order (by order_date)
  for (const [clientId, ordersInfo] of clientOrderDates) {
    // Find the order with the latest date that has a seller
    const withSeller = ordersInfo.filter((o) => o.sellerId);
    if (withSeller.length === 0) continue;

    // Sort by date descending
    withSeller.sort((a, b) => {
      if (!a.orderDate && !b.orderDate) return 0;
      if (!a.orderDate) return 1;
      if (!b.orderDate) return -1;
      return b.orderDate.localeCompare(a.orderDate);
    });

    const latestSellerId = withSeller[0].sellerId;
    const latestOrderDate = withSeller[0].orderDate;

    if (latestSellerId) {
      const { error } = await supabase
        .from("clients")
        .update({
          seller_id: latestSellerId,
          ...(latestOrderDate ? { last_order_date: latestOrderDate } : {}),
        })
        .eq("id", clientId);

      if (!error) result.clientsUpdated++;
    }
  }

    // AUDITORIA: Completar log com sucesso
    await importLog.complete({
      status: 'success',
      records_created: result.ordersCreated + result.clientsCreated + result.productsCreated,
      records_updated: result.ordersUpdated + result.clientsUpdated + result.productsUpdated,
      records_skipped: result.ordersSkippedDuplicate + result.linesIgnoredNoOrderNumber,
    });

    return result;
  } catch (error: any) {
    // AUDITORIA: Registrar erro
    await importLog.complete({
      status: 'error',
      error_message: error.message,
      records_created: result.ordersCreated,
      records_failed: 1,
    });
    throw error;
  }
}
