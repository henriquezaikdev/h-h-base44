import { supabase } from "@/integrations/supabase/client";
import { toTrimmedString, type Row } from "./spreadsheet";
import type { TablesInsert } from "@/integrations/supabase/types";

export type ClientsMapping = {
  companyName: string;
  cnpj?: string;
  email?: string;
  phone?: string;
};

function pick(row: Row, col?: string): unknown {
  if (!col) return undefined;
  return row[col];
}

export async function importClientsExplicit(rows: Row[], mapping: ClientsMapping): Promise<number> {
  const payload: TablesInsert<"clients">[] = [];

  for (const r of rows) {
    const companyName = toTrimmedString(pick(r, mapping.companyName));
    if (!companyName) continue;

    const cnpj = mapping.cnpj ? toTrimmedString(pick(r, mapping.cnpj)) : undefined;
    const email = mapping.email ? toTrimmedString(pick(r, mapping.email)) : undefined;
    const phone = mapping.phone ? toTrimmedString(pick(r, mapping.phone)) : undefined;

    payload.push({
      company_name: companyName,
      ...(cnpj ? { cnpj } : {}),
      ...(email ? { email } : {}),
      ...(phone ? { phone } : {}),
    });
  }

  if (payload.length === 0) throw new Error('Nenhum cliente válido encontrado (campo "Nome do Cliente" vazio).');

  const { data, error } = await supabase.from("clients").insert(payload).select("id");
  if (error) throw new Error(`Erro ao salvar clientes: ${error.message}`);

  return data?.length ?? 0;
}
