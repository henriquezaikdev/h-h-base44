import { supabase } from "@/integrations/supabase/client";
import { normalizeProductKey, toTrimmedString, parseDecimal, type Row } from "./spreadsheet";

export type ProductsMapping = {
  productName: string;
  sku?: string;
  category?: string;
  unitOfMeasure?: string;
  costPrice?: string;
  salePrice?: string;
};

function pick(row: Row, col?: string): unknown {
  if (!col) return undefined;
  return row[col];
}

export async function importProductsExplicit(
  rows: Row[],
  mapping: ProductsMapping
): Promise<{ inserted: number; skippedExisting: number; updated: number; skippedInvalid: number }> {
  // Fetch existing products
  const { data: existing } = await supabase.from("products").select("id, normalized_name, category, category_id");
  const existingByNorm = new Map<string, { id: string; category: string | null; category_id: string | null }>();
  (existing ?? []).forEach((p) => existingByNorm.set(p.normalized_name, { id: p.id, category: p.category, category_id: p.category_id }));

  // Fetch categories for lookup
  const { data: categoriesData } = await supabase.from("categories").select("id, name");
  const categoriesByName = new Map<string, string>();
  (categoriesData ?? []).forEach((c) => categoriesByName.set(c.name.toLowerCase().trim(), c.id));

  const toInsert: Array<{
    name: string;
    normalized_name: string;
    sku?: string;
    category?: string;
    category_id?: string;
    unit_of_measure?: string;
    cost_price?: number;
    sale_price?: number;
    active: boolean;
  }> = [];
  let skippedExisting = 0;
  let updated = 0;
  let skippedInvalid = 0;

  const errors: string[] = [];

  for (const [rowIndex, r] of rows.entries()) {
    const name = toTrimmedString(pick(r, mapping.productName));
    if (!name) continue;

    const sku = mapping.sku ? toTrimmedString(pick(r, mapping.sku)) : "";
    const category = mapping.category ? toTrimmedString(pick(r, mapping.category)) : "";
    const unitOfMeasure = mapping.unitOfMeasure ? toTrimmedString(pick(r, mapping.unitOfMeasure)) : "";

    const rawCost = mapping.costPrice ? pick(r, mapping.costPrice) : undefined;
    const costRawText = toTrimmedString(rawCost).replace(/["']/g, "");
    const costPrice = mapping.costPrice ? parseDecimal(rawCost) : null;

    const rawSale = mapping.salePrice ? pick(r, mapping.salePrice) : undefined;
    const saleRawText = toTrimmedString(rawSale).replace(/["']/g, "");
    const salePrice = mapping.salePrice ? parseDecimal(rawSale) : null;

    // Validações (bloqueiam importação — sem "chutar" valores)
    if (!category) {
      errors.push(`Linha ${rowIndex + 1}: produto "${name}" sem Categoria do Item.`);
      continue;
    }

    if (!costRawText) {
      errors.push(`Linha ${rowIndex + 1}: produto "${name}" sem Custo Unitário.`);
      continue;
    }

    if (costPrice === null) {
      errors.push(
        `Linha ${rowIndex + 1}: produto "${name}" com Custo Unitário inválido: "${costRawText}" (use 55,23 ou 55.23).`
      );
      continue;
    }

    if (costPrice <= 0) {
      errors.push(`Linha ${rowIndex + 1}: produto "${name}" com Custo Unitário <= 0.`);
      continue;
    }

    if (saleRawText && salePrice === null) {
      errors.push(
        `Linha ${rowIndex + 1}: produto "${name}" com Preço de Venda inválido: "${saleRawText}" (use 55,23 ou 55.23).`
      );
      continue;
    }

    // Find category_id
    const categoryId = categoriesByName.get(category.toLowerCase().trim());

    // If category doesn't exist, create it
    let finalCategoryId = categoryId;
    if (!finalCategoryId) {
      const { data: newCat, error: catErr } = await supabase
        .from("categories")
        .insert({ name: category.trim(), active: true })
        .select("id")
        .single();
      if (!catErr && newCat) {
        finalCategoryId = newCat.id;
        categoriesByName.set(category.toLowerCase().trim(), newCat.id);
      }
    }

    const norm = normalizeProductKey(name);
    const ex = existingByNorm.get(norm);

    if (!ex) {
      toInsert.push({
        name,
        normalized_name: norm,
        ...(sku ? { sku } : {}),
        category: category || undefined,
        category_id: finalCategoryId || undefined,
        ...(unitOfMeasure ? { unit_of_measure: unitOfMeasure } : {}),
        cost_price: costPrice,
        ...(salePrice !== null ? { sale_price: salePrice } : {}),
        active: true,
      });
      existingByNorm.set(norm, { id: "", category: category || null, category_id: finalCategoryId || null });
    } else {
      skippedExisting++;
      // Update if missing data
      const updates: Record<string, unknown> = {};
      if (category && !ex.category) updates.category = category;
      if (finalCategoryId && !ex.category_id) updates.category_id = finalCategoryId;

      if (Object.keys(updates).length > 0 && ex.id) {
        const { error } = await supabase.from("products").update(updates).eq("id", ex.id);
        if (!error) updated++;
      }
    }
  }

  if (errors.length > 0) {
    const sample = errors.slice(0, 5).map((e) => `• ${e}`).join("\n");
    const more = errors.length > 5 ? `\n(+${errors.length - 5} outros)` : "";
    throw new Error(`Importação bloqueada: corrija a planilha antes de continuar.\n${sample}${more}`);
  }

  const safeToInsert = toInsert.filter((p) => typeof p.name === "string" && p.name.trim().length > 0);
  if (safeToInsert.length === 0) {
    return { inserted: 0, skippedExisting, updated, skippedInvalid };
  }

  const { data: inserted, error } = await supabase.from("products").insert(safeToInsert).select("id");
  if (error) throw new Error(`Erro ao salvar produtos: ${error.message}`);

  return { inserted: inserted?.length ?? 0, skippedExisting, updated, skippedInvalid };
}
