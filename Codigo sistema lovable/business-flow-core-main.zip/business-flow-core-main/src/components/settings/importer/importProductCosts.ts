import { supabase } from "@/integrations/supabase/client";
import { normalizeProductKey, toTrimmedString, parseDecimal, type Row } from "./spreadsheet";

export type ProductCostsMapping = {
  sku?: string;
  productName?: string;
  costPrice: string;
  category?: string;
};

function pick(row: Row, col?: string): unknown {
  if (!col) return undefined;
  return row[col];
}

function formatRowError(rowIndex: number, message: string) {
  return `Linha ${rowIndex + 1}: ${message}`;
}

export async function importProductCosts(
  rows: Row[],
  mapping: ProductCostsMapping,
  onProgress?: (processed: number, total: number) => void
): Promise<{ updated: number; notFound: number; invalid: number; categoryUpdated: number }> {
  // Fetch existing products with SKU/name so we can match without creating duplicates.
  const { data: existing, error: productsErr } = await supabase
    .from("products")
    .select("id, sku, name, normalized_name, category, category_id");

  if (productsErr) throw productsErr;

  // IMPORTANT: upsert requires NOT NULL columns even when using onConflict.
  // So we always include `name` + `normalized_name` from the existing row.
  type ProductEntry = {
    id: string;
    name: string;
    normalized_name: string;
    category: string | null;
    category_id: string | null;
  };

  const productsBySku = new Map<string, ProductEntry>();
  const productsByNorm = new Map<string, ProductEntry>();
  const productsByNameContains = new Map<string, ProductEntry>(); // For fuzzy matching

  (existing ?? []).forEach((p) => {
    const entry: ProductEntry = {
      id: p.id,
      name: p.name,
      normalized_name: p.normalized_name || (p.name ? normalizeProductKey(p.name) : ""),
      category: p.category,
      category_id: p.category_id,
    };

    if (p.sku && p.sku !== "null" && p.sku !== "não informado") {
      productsBySku.set(p.sku.toUpperCase().trim(), entry);
    }

    const norm = p.normalized_name || (p.name ? normalizeProductKey(p.name) : "");
    if (norm) {
      productsByNorm.set(norm, entry);
      // Also index without common prefixes like "PAPEL1 " for fuzzy matching
      const withoutPrefix = norm.replace(/^[a-z0-9]+\s+[-–]\s+/i, "").replace(/^[a-z0-9]+\s+/i, "");
      if (withoutPrefix && withoutPrefix !== norm) {
        productsByNameContains.set(withoutPrefix, entry);
      }
    }
  });

  // Fetch all categories to map names to IDs
  const { data: categoriesData, error: categoriesErr } = await supabase.from("categories").select("id, name");

  if (categoriesErr) throw categoriesErr;

  const categoryNameToId = new Map<string, string>();
  (categoriesData ?? []).forEach((c) => {
    categoryNameToId.set(c.name.toLowerCase().trim(), c.id);
  });

  let notFound = 0;
  let invalid = 0;

  // Collect updates to batch them
  const updates: Array<{
    id: string;
    name: string;
    normalized_name: string;
    cost_price?: number;
    category?: string;
    category_id?: string;
  }> = [];

  let plannedCostUpdates = 0;
  let plannedCategoryUpdates = 0;

  const skuCol = mapping.sku;
  const nameCol = mapping.productName;

  const errors: string[] = [];

  for (const [rowIndex, r] of rows.entries()) {
    const skuRaw = skuCol ? toTrimmedString(pick(r, skuCol)) : "";
    const nameRaw = nameCol ? toTrimmedString(pick(r, nameCol)) : "";

    // skip empty lines
    if (!skuRaw && !nameRaw) continue;

    // Skip header/total rows
    const skuLower = skuRaw.toLowerCase();
    const nameLower = nameRaw.toLowerCase();
    if (
      skuLower === "código do item" ||
      skuLower === "codigo do item" ||
      skuLower === "total geral" ||
      skuLower === "sku" ||
      nameLower === "nome do produto" ||
      nameLower === "produto"
    ) {
      continue;
    }

    let product: ProductEntry | undefined;

    // Strategy 1: Match by SKU (exact match)
    if (skuRaw) {
      const sku = skuRaw.toUpperCase().trim();
      product = productsBySku.get(sku);
    }

    // Strategy 2: Match by normalized name (exact match)
    if (!product && nameRaw) {
      const norm = normalizeProductKey(nameRaw);
      product = productsByNorm.get(norm);
    }

    // Strategy 3: Match by name without prefix (fuzzy match)
    if (!product && nameRaw) {
      const norm = normalizeProductKey(nameRaw);
      product = productsByNameContains.get(norm);
    }

    // Strategy 4: Try to find product where normalized name contains the search term
    if (!product && nameRaw) {
      const searchNorm = normalizeProductKey(nameRaw);
      for (const [key, entry] of productsByNorm.entries()) {
        if (key.includes(searchNorm) || searchNorm.includes(key)) {
          product = entry;
          break;
        }
      }
    }

    if (!product) {
      notFound++;
      continue;
    }

    const rawCost = pick(r, mapping.costPrice);
    const costText = toTrimmedString(rawCost).replace(/["']/g, "");
    const costPrice = parseDecimal(rawCost);

    // Bloqueia a importação se houver custo não conversível (sem "chutar" valores)
    if (costText && costPrice === null) {
      invalid++;
      errors.push(
        formatRowError(
          rowIndex,
          `produto "${product.name}" com Custo unitário inválido: "${costText}" (use 55,23 ou 55.23).`
        )
      );
      continue;
    }

    const updateData: {
      id: string;
      name: string;
      normalized_name: string;
      cost_price?: number;
      category?: string;
      category_id?: string;
    } = {
      id: product.id,
      name: product.name,
      normalized_name: product.normalized_name,
    };

    let hasUpdate = false;

    // Add cost price if valid
    if (costText && costPrice !== null && costPrice >= 0) {
      updateData.cost_price = costPrice;
      plannedCostUpdates++;
      hasUpdate = true;
    }

    // Handle category update if mapping provided
    if (mapping.category) {
      const categoryName = toTrimmedString(pick(r, mapping.category));
      if (categoryName) {
        updateData.category = categoryName;

        const categoryId = categoryNameToId.get(categoryName.toLowerCase().trim());
        if (categoryId) {
          updateData.category_id = categoryId;
        }

        plannedCategoryUpdates++;
        hasUpdate = true;
      }
    }

    if (hasUpdate) {
      updates.push(updateData);
    }
  }

  if (errors.length > 0) {
    const sample = errors.slice(0, 5).map((e) => `• ${e}`).join("\n");
    const more = errors.length > 5 ? `\n(+${errors.length - 5} outros)` : "";
    throw new Error(`Importação bloqueada: corrija a planilha antes de continuar.\n${sample}${more}`);
  }

  // Deduplicate updates by product id (keep last occurrence)
  const uniqueUpdates = Array.from(
    updates.reduce((map, update) => {
      map.set(update.id, update);
      return map;
    }, new Map<string, typeof updates[0]>()).values()
  );

  // Execute updates in batches (single request per batch using upsert)
  const total = uniqueUpdates.length;
  onProgress?.(0, total);

  const BATCH_SIZE = 200;
  for (let i = 0; i < uniqueUpdates.length; i += BATCH_SIZE) {
    const batch = uniqueUpdates.slice(i, i + BATCH_SIZE);

    const { error } = await supabase
      .from("products")
      .upsert(batch as any, { onConflict: "id" });
    if (error) throw error;

    onProgress?.(Math.min(i + batch.length, total), total);
  }

  return {
    updated: plannedCostUpdates,
    notFound,
    invalid,
    categoryUpdated: plannedCategoryUpdates,
  };
}
