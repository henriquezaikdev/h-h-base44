import * as XLSX from "xlsx";

export type Row = Record<string, unknown>;

export async function parseSpreadsheetFile(file: File): Promise<{ rows: Row[]; columns: string[] }>{
  const normalizeHeader = (key: string) =>
    key
      .replace(/^\uFEFF/, "") // strip BOM if present
      .trim()
      .replace(/\s+/g, " ");

  const rows = await new Promise<Row[]>((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = (e) => {
      try {
        const data = e.target?.result;
        const workbook = XLSX.read(data, { type: "binary" });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];

        // NOTE: We intentionally do NOT use `defval` (would fill empty cells).
        // We also do not attempt to infer/rename columns.
        // IMPORTANT: Use raw:false to preserve the *text* representation from CSV/XLSX.
        // This prevents PT-BR decimals like "7,99" from being coerced into 799 before parsing.
        const json = XLSX.utils.sheet_to_json<Row>(worksheet, {
          raw: false,
        });

        // Sanitize headers (common in CSV exports with BOM / extra spaces)
        const sanitized = (json ?? []).map((r) => {
          const out: Row = {};
          for (const [k, v] of Object.entries(r || {})) {
            out[normalizeHeader(k)] = v;
          }
          return out;
        });

        resolve(sanitized);
      } catch {
        reject(new Error("Erro ao processar arquivo"));
      }
    };

    reader.onerror = () => reject(new Error("Erro ao ler arquivo"));
    reader.readAsBinaryString(file);
  });

  const columnsSet = new Set<string>();
  for (const r of rows.slice(0, 50)) {
    Object.keys(r || {}).forEach((k) => columnsSet.add(k));
  }

  return { rows, columns: Array.from(columnsSet) };
}

export function toTrimmedString(value: unknown): string {
  if (value === null || value === undefined) return "";
  return String(value).trim();
}

export function parseDecimal(value: unknown): number | null {
  const s = toTrimmedString(value);
  if (!s) return null;

  // Remove currency symbols, spaces, and common CSV quoting
  let cleaned = s
    .replace(/R\$\s*/gi, "")
    .replace(/["']/g, "")
    .trim();

  // Detect Brazilian format: dot as thousand separator + comma as decimal
  // Examples: "5.523,00", "1.749,00", "800,00", "55,23"
  const hasBrazilianFormat =
    /^\d{1,3}(\.\d{3})*(,\d+)?$/.test(cleaned) || /^\d+(,\d+)$/.test(cleaned);

  if (hasBrazilianFormat) {
    // Brazilian format: remove thousand separators (dots), convert decimal comma to dot
    cleaned = cleaned.replace(/\./g, "").replace(",", ".");
  } else {
    // Standard format: remove non-numeric except dot and minus
    cleaned = cleaned.replace(/[^\d.-]/g, "");
  }

  const n = Number(cleaned);
  return Number.isFinite(n) && n >= 0 ? n : null;
}

export function normalizeProductKey(value: string): string {
  // Deterministic normalization for product identity (not similarity matching).
  return value
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]/g, "");
}
