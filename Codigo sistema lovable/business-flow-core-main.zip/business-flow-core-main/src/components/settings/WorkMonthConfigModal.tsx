import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { CalendarIcon, AlertTriangle } from 'lucide-react';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isWeekend } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { cn } from '@/lib/utils';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface WorkMonthConfigModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSaved?: () => void;
}

export function WorkMonthConfigModal({ open, onOpenChange, onSaved }: WorkMonthConfigModalProps) {
  const [workingDays, setWorkingDays] = useState(22);
  const [operationalStartDate, setOperationalStartDate] = useState<Date | undefined>();
  const [saving, setSaving] = useState(false);
  const [existingConfig, setExistingConfig] = useState<any>(null);

  const today = new Date();
  const yearMonth = format(today, 'yyyy-MM');
  const monthStart = startOfMonth(today);
  const monthEnd = endOfMonth(today);

  // Calcular dias úteis automaticamente
  const autoCalculatedDays = eachDayOfInterval({ start: monthStart, end: monthEnd })
    .filter(d => !isWeekend(d)).length;

  useEffect(() => {
    if (open) {
      fetchExisting();
    }
  }, [open]);

  const fetchExisting = async () => {
    const { data } = await supabase
      .from('work_month_config')
      .select('*')
      .eq('year_month', yearMonth)
      .maybeSingle();

    if (data) {
      setExistingConfig(data);
      setWorkingDays(data.working_days);
      setOperationalStartDate(data.operational_start_date ? new Date(data.operational_start_date) : undefined);
    } else {
      setWorkingDays(autoCalculatedDays);
      setOperationalStartDate(undefined);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const { data: seller } = await supabase.rpc('get_my_seller_id');
      
      const payload = {
        year_month: yearMonth,
        working_days: workingDays,
        operational_start_date: operationalStartDate ? format(operationalStartDate, 'yyyy-MM-dd') : null,
        updated_by: seller,
      };

      if (existingConfig) {
        const { error } = await supabase
          .from('work_month_config')
          .update(payload)
          .eq('id', existingConfig.id);

        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('work_month_config')
          .insert({ ...payload, created_by: seller });

        if (error) throw error;
      }

      toast.success('Configuração do mês salva com sucesso!');
      onSaved?.();
      onOpenChange(false);
    } catch (error) {
      console.error('Error saving work month config:', error);
      toast.error('Erro ao salvar configuração');
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <CalendarIcon className="h-5 w-5" />
            Configurar Dias Úteis - {format(today, 'MMMM yyyy', { locale: ptBR })}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6 py-4">
          <div className="bg-muted/50 p-3 rounded-lg">
            <p className="text-sm text-muted-foreground">
              <AlertTriangle className="h-4 w-4 inline mr-1 text-yellow-500" />
              Configurar os dias úteis do mês é essencial para o cálculo correto das metas diárias.
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="workingDays">Dias Úteis do Mês</Label>
            <div className="flex items-center gap-2">
              <Input
                id="workingDays"
                type="number"
                min={1}
                max={31}
                value={workingDays}
                onChange={(e) => setWorkingDays(parseInt(e.target.value) || 0)}
                className="w-24"
              />
              <span className="text-sm text-muted-foreground">
                (Automático: {autoCalculatedDays} seg-sex)
              </span>
            </div>
            <p className="text-xs text-muted-foreground">
              Ajuste se houver feriados que reduzem os dias de trabalho.
            </p>
          </div>

          <div className="space-y-2">
            <Label>Data de Início Operacional (opcional)</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    "w-full justify-start text-left font-normal",
                    !operationalStartDate && "text-muted-foreground"
                  )}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {operationalStartDate 
                    ? format(operationalStartDate, 'dd/MM/yyyy') 
                    : 'Selecionar data de início'}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={operationalStartDate}
                  onSelect={setOperationalStartDate}
                  disabled={(date) => date < monthStart || date > monthEnd}
                  initialFocus
                  locale={ptBR}
                />
              </PopoverContent>
            </Popover>
            <p className="text-xs text-muted-foreground">
              Se o mês começa operacionalmente em outra data (ex.: dia 05), configure aqui.
            </p>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancelar
          </Button>
          <Button onClick={handleSave} disabled={saving}>
            {saving ? 'Salvando...' : 'Salvar Configuração'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
