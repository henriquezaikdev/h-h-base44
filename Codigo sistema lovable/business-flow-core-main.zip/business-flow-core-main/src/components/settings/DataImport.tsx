import { useEffect, useMemo, useRef, useState } from "react";
import {
  AlertCircle,
  Check,
  Database,
  Download,
  FileSpreadsheet,
  Loader2,
  Package,
  ShoppingCart,
  Trash2,
  Upload,
  Users,
} from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Progress } from "@/components/ui/progress";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

import * as XLSX from "xlsx";
import { parseSpreadsheetFile, parseDecimal, type Row } from "./importer/spreadsheet";
import { importClientsExplicit, type ClientsMapping } from "./importer/importClientsExplicit";
import { importProductsExplicit, type ProductsMapping } from "./importer/importProductsExplicit";
import { importOrdersExplicit, type OrdersMapping } from "./importer/importOrdersExplicit";
import { importProductCosts, type ProductCostsMapping } from "./importer/importProductCosts";

type ImportType = "clients" | "orders" | "products" | "costs";

type Step = "idle" | "mapping" | "ready" | "processing" | "success" | "error";

interface ImportConfig {
  type: ImportType;
  label: string;
  icon: React.ElementType;
  description: string;
  sampleData: Record<string, string>[];
}

const importConfigs: ImportConfig[] = [
  {
    type: "clients",
    label: "Clientes",
    icon: Users,
    description: "Importar lista de clientes (mapeamento 100% manual)",
    sampleData: [
      {
        "Nome do Cliente": "Empresa Exemplo LTDA",
        CNPJ: "00.000.000/0001-00",
        Email: "contato@empresa.com",
        Telefone: "(11) 99999-9999",
      },
    ],
  },
  {
    type: "orders",
    label: "Pedidos",
    icon: ShoppingCart,
    description: "Importar pedidos (sem inferência, sem número inventado)",
    sampleData: [
      {
        "Nome do Cliente": "Empresa Exemplo LTDA",
        "Número do Pedido": "PED-001",
        Vendedor: "joao@empresa.com",
        Produto: "Caneta Azul",
        Categoria: "Papelaria",
      },
    ],
  },
  {
    type: "products",
    label: "Produtos",
    icon: Package,
    description: "Importar catálogo de produtos com custo e categoria obrigatórios",
    sampleData: [{ 
      "Nome do produto/serviço": "Caneta Azul", 
      "Código do item": "CAN-001", 
      "Categoria do item": "Papelaria",
      "Unidade de medida": "UN",
      "Custo unitário": "7,99"
    }],
  },
  {
    type: "costs",
    label: "Preços de Custo",
    icon: Database,
    description: "Atualizar custo e categoria de produtos via SKU ou Nome do Produto",
    sampleData: [
      {
        "Código do item": "CAN-001",
        "Nome do Produto": "Caneta Azul",
        "Custo unitário": "7,99",
        "Categoria do item": "Papelaria",
      },
    ],
  },
];

interface ImportStatus {
  step: Step;
  message?: string;
  total?: number;
  processed?: number;
}

type StoredImportFile = {
  path: string;
  name: string;
  updatedAt?: string;
};

const BUCKET = "imports";
const PREFIX = "data-import";

function getErrorMessage(err: unknown, fallback = "Erro desconhecido"): string {
  if (typeof err === "string") return err;
  if (err && typeof err === "object") {
    const anyErr = err as any;
    if (typeof anyErr.message === "string") return anyErr.message;
    if (typeof anyErr.error_description === "string") return anyErr.error_description;
  }
  return fallback;
}

function isRlsViolationMessage(message: string) {
  return message.toLowerCase().includes("row-level security") || message.toLowerCase().includes("rls");
}

function prettifyImportError(message: string) {
  const m = message.toLowerCase();
  if (m.includes('null value in column "name"') && m.includes('relation "products"')) {
    return "Sua planilha tem linhas com Produto/Nome do Produto vazio. Verifique a coluna mapeada e remova linhas em branco antes de importar.";
  }
  return message;
}

export function DataImport() {
  const [selectedType, setSelectedType] = useState<ImportType>("orders");
  const [status, setStatus] = useState<ImportStatus>({ step: "idle" });

  const fileInputRef = useRef<HTMLInputElement>(null);

  const [storedFiles, setStoredFiles] = useState<StoredImportFile[]>([]);
  const [selectedStoredPath, setSelectedStoredPath] = useState<string>("");
  const [storageWriteBlocked, setStorageWriteBlocked] = useState(false);

  const [rows, setRows] = useState<Row[] | null>(null);
  const [columns, setColumns] = useState<string[]>([]);

  const [clientsMapping, setClientsMapping] = useState<ClientsMapping>({ companyName: "" });
  const [productsMapping, setProductsMapping] = useState<ProductsMapping>({ 
    productName: "",
    sku: "",
    category: "",
    unitOfMeasure: "",
    costPrice: "",
    salePrice: "",
  });
  const [ordersMapping, setOrdersMapping] = useState<OrdersMapping>({
    clientName: "",
    orderNumber: "",
    seller: "",
    productName: "",
    category: "",
    orderDate: "",
    total: "",
    quantity: "",
    unitPrice: "",
    subtotal: "",
  });
  const [costsMapping, setCostsMapping] = useState<ProductCostsMapping>({
    sku: "",
    productName: "",
    costPrice: "",
    category: "",
  });

  const [mappingConfirmed, setMappingConfirmed] = useState(false);

  const currentConfig = useMemo(
    () => importConfigs.find((c) => c.type === selectedType)!,
    [selectedType]
  );

  const resetAll = () => {
    setStatus({ step: "idle" });
    setRows(null);
    setColumns([]);
    setMappingConfirmed(false);
    setSelectedStoredPath("");
    setClientsMapping({ companyName: "" });
    setProductsMapping({ productName: "", sku: "", category: "", unitOfMeasure: "", costPrice: "", salePrice: "" });
    setOrdersMapping({ clientName: "", orderNumber: "", seller: "", productName: "", category: "", orderDate: "", total: "", quantity: "", unitPrice: "", subtotal: "" });
    setCostsMapping({ sku: "", productName: "", costPrice: "", category: "" });

    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const downloadTemplate = () => {
    const ws = XLSX.utils.json_to_sheet(currentConfig.sampleData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, currentConfig.label);
    XLSX.writeFile(wb, `modelo_${currentConfig.type}.xlsx`);
    toast.success("Modelo baixado com sucesso!");
  };

  useEffect(() => {
    // List previously uploaded files (so user can reprocess the same spreadsheet)
    (async () => {
      const { data, error } = await supabase.storage.from(BUCKET).list(PREFIX, {
        limit: 50,
        offset: 0,
        sortBy: { column: "updated_at", order: "desc" },
      });

      if (error) return;

      const mapped: StoredImportFile[] = (data ?? [])
        .filter((o) => !!o.name)
        .map((o) => ({
          path: `${PREFIX}/${o.name}`,
          name: o.name,
          updatedAt: (o as any).updated_at,
        }));

      setStoredFiles(mapped);
    })();
  }, []);

  const loadRowsForMapping = async (file: File) => {
    const { rows: parsedRows, columns: parsedColumns } = await parseSpreadsheetFile(file);

    if (parsedRows.length === 0) throw new Error("Arquivo vazio ou formato inválido");

    setRows(parsedRows);
    setColumns(parsedColumns);
    setMappingConfirmed(false);

    // Reset mappings (we still require explicit confirmation before importing)
    setClientsMapping({ companyName: "" });
    setProductsMapping({ productName: "" });
    setOrdersMapping({ clientName: "", orderNumber: "", seller: "", productName: "", category: "", orderDate: "", total: "", quantity: "", unitPrice: "", subtotal: "" });

    // Suggest mappings for cost spreadsheets based on header names (user must review + confirm).
    if (selectedType === "costs") {
      const norm = (s: string) =>
        s
          .replace(/^\uFEFF/, "")
          .trim()
          .toLowerCase()
          .normalize("NFD")
          .replace(/[\u0300-\u036f]/g, "")
          .replace(/\s+/g, " ");

      const pick = (predicates: Array<(n: string) => boolean>) =>
        parsedColumns.find((c) => predicates.some((p) => p(norm(c)))) || "";

      const sku = pick([(n) => n === "codigo do item", (n) => n.includes("codigo do item"), (n) => n === "sku"]);
      const productName = pick([
        (n) => n === "nome do produto",
        (n) => n === "nome do produto/servico",
        (n) => n.includes("nome do produto/servico"),
        (n) => n.includes("nome do produto"),
      ]);
      const costPrice = pick([(n) => n === "custo unitario", (n) => n.includes("custo unit"), (n) => n.includes("custo")]);
      const category = pick([(n) => n === "categoria do item", (n) => n.includes("categoria do item"), (n) => n.includes("categoria")]);

      setCostsMapping({
        sku: sku || "",
        productName: productName || "",
        costPrice: costPrice || "",
        category: category || "",
      });
    } else {
      setCostsMapping({ sku: "", productName: "", costPrice: "", category: "" });
    }

    setStatus({ step: "mapping", message: "Mapeie as colunas e confirme antes de importar." });
  };

  const handleUploadNewFile = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const { data: sessionData } = await supabase.auth.getSession();
    if (!sessionData.session?.user) {
      const msg = "Sessão expirada. Faça login novamente para importar.";
      setStatus({ step: "error", message: msg });
      toast.error(msg);
      return;
    }

    setStatus({ step: "processing", message: "Carregando arquivo para mapeamento..." });

    try {
      // Tenta salvar no backend para reprocessar depois; se não tiver permissão, segue com import local.
      if (!storageWriteBlocked) {
        const path = `${PREFIX}/${Date.now()}_${file.name}`;
        const { error: upErr } = await supabase.storage
          .from(BUCKET)
          .upload(path, file, { upsert: false, contentType: file.type || undefined });

        if (upErr) {
          const upMsg = getErrorMessage(upErr, "Falha ao salvar o arquivo no backend");
          if (isRlsViolationMessage(upMsg)) setStorageWriteBlocked(true);
          toast.warning(`Não consegui salvar o arquivo no backend (permissão). Vou processar localmente.`);
        } else {
          setSelectedStoredPath(path);
          setStoredFiles((prev) => [{ path, name: path.split("/").pop() || path }, ...prev].slice(0, 50));
        }
      }

      await loadRowsForMapping(file);
    } catch (e) {
      const msg = getErrorMessage(e, "Erro ao processar arquivo");
      setStatus({ step: "error", message: msg });
      toast.error(msg);
    }
  };

  const handleSelectStoredFile = async (path: string) => {
    if (!path) return;

    setSelectedStoredPath(path);
    setStatus({ step: "processing", message: "Baixando arquivo salvo para mapeamento..." });

    try {
      const { data, error } = await supabase.storage.from(BUCKET).download(path);
      if (error || !data) throw new Error("Não foi possível baixar o arquivo salvo.");

      const file = new File([data], path.split("/").pop() || "import.xlsx", {
        type: data.type || "application/octet-stream",
      });

      await loadRowsForMapping(file);
    } catch (e) {
      const msg = getErrorMessage(e, "Erro ao baixar arquivo");
      setStatus({ step: "error", message: msg });
      toast.error(msg);
    }
  };

  const mappingSummary = useMemo(() => {
    if (selectedType === "orders") {
      return [
        { label: "Nome do Cliente", value: ordersMapping.clientName || "(não mapeado)" },
        { label: "Número do Pedido", value: ordersMapping.orderNumber || "(não mapeado)" },
        { label: "Vendedor Responsável", value: ordersMapping.seller || "(não mapeado)" },
        { label: "Produto", value: ordersMapping.productName || "(não mapeado)" },
        { label: "Categoria", value: ordersMapping.category || "(não mapeado)" },
        { label: "Data do Pedido", value: ordersMapping.orderDate || "(não mapeado)" },
        { label: "Total do Pedido", value: ordersMapping.total || "(não mapeado)" },
        { label: "Quantidade", value: ordersMapping.quantity || "(não mapeado)" },
        { label: "Valor Unitário", value: ordersMapping.unitPrice || "(não mapeado)" },
        { label: "Subtotal Item", value: ordersMapping.subtotal || "(não mapeado)" },
      ];
    }

    if (selectedType === "clients") {
      return [{ label: "Nome do Cliente", value: clientsMapping.companyName || "(não mapeado)" }];
    }

    if (selectedType === "costs") {
      return [
        { label: "SKU (Código do item)", value: costsMapping.sku || "(não mapeado)" },
        { label: "Nome do Produto", value: costsMapping.productName || "(não mapeado)" },
        { label: "Custo unitário", value: costsMapping.costPrice || "(não mapeado)" },
        { label: "Categoria", value: costsMapping.category || "(não mapeado)" },
      ];
    }

    return [{ label: "Nome do Produto", value: productsMapping.productName || "(não mapeado)" }];
  }, [selectedType, ordersMapping, clientsMapping, productsMapping, costsMapping]);

  const canProceed = useMemo(() => {
    if (!rows || rows.length === 0) return false;

    if (selectedType === "orders") {
      return (
        !!ordersMapping.clientName &&
        !!ordersMapping.orderNumber &&
        !!ordersMapping.seller &&
        !!ordersMapping.productName &&
        !!ordersMapping.category &&
        mappingConfirmed
      );
    }

    if (selectedType === "clients") {
      return !!clientsMapping.companyName && mappingConfirmed;
    }

    if (selectedType === "costs") {
      return !!costsMapping.costPrice && (!!costsMapping.sku || !!costsMapping.productName) && mappingConfirmed;
    }

    // Products: nome, categoria e custo são obrigatórios
    return !!productsMapping.productName && !!productsMapping.category && !!productsMapping.costPrice && mappingConfirmed;
  }, [rows, selectedType, ordersMapping, clientsMapping, productsMapping, costsMapping, mappingConfirmed]);

  const runImport = async () => {
    if (!rows) return;

    setStatus({ step: "processing", message: "Importando...", total: rows.length, processed: 0 });

    try {
      if (selectedType === "clients") {
        const count = await importClientsExplicit(rows, clientsMapping);
        setStatus({ step: "success", message: `${count} clientes importados.` });
        toast.success(`Importação concluída: ${count} clientes.`);
        return;
      }

      if (selectedType === "products") {
        const res = await importProductsExplicit(rows, productsMapping);
        const msg = `${res.inserted} produtos inseridos, ${res.updated} atualizados, ${res.skippedExisting} já existentes.`;
        setStatus({ step: "success", message: msg });
        toast.success(`Importação concluída: ${res.inserted} produtos inseridos.`);
        return;
      }

      if (selectedType === "costs") {
        // Show real progress (products being updated), not just "0 de N linhas"
        const res = await importProductCosts(rows, costsMapping, (processed, total) => {
          setStatus((prev) => ({
            ...prev,
            processed,
            total,
            message: `Atualizando produtos... ${processed}/${total}`,
          }));
        });

        const summary = [
          `${res.updated} custos atualizados`,
          `${res.categoryUpdated} categorias atualizadas`,
          `${res.notFound} SKUs não encontrados`,
          res.invalid > 0 ? `${res.invalid} valores inválidos` : null,
        ]
          .filter(Boolean)
          .join(" • ");
        setStatus({ step: "success", message: summary });
        toast.success(`Importação concluída: ${res.updated} custos atualizados.`);
        return;
      }

      // orders
      const res = await importOrdersExplicit(rows, ordersMapping, (processedGroups, totalGroups) => {
        setStatus((prev) => ({
          ...prev,
          processed: processedGroups,
          total: totalGroups,
          message: `Importando pedidos... ${processedGroups}/${totalGroups}`,
        }));
      });

      const summary = [
        `${res.clientsCreated} clientes criados`,
        `${res.clientsUpdated} clientes atualizados`,
        `${res.ordersCreated} pedidos criados`,
        `${res.ordersUpdated} pedidos atualizados`,
        `${res.ordersSkippedDuplicate} pedidos já existentes`,
        `${res.itemsReplaced} itens substituídos`,
        `${res.itemsCreated} itens criados`,
        `${res.productsCreated} produtos novos`,
        `${res.productsUpdated} produtos atualizados`,
        `${res.linesIgnoredNoOrderNumber} linhas ignoradas (sem número)`,
      ].join(" • ");

      setStatus({ step: "success", message: summary });
      toast.success("Importação concluída.");
    } catch (e) {
      const msg = prettifyImportError(getErrorMessage(e));
      setStatus({ step: "error", message: msg });
      toast.error(`Falha na importação: ${msg}`);
    }
  };

  return (
    <section className="space-y-6" aria-label="Importação de dados">
      {/* Import Type Selection */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {importConfigs.map((config) => {
          const Icon = config.icon;
          const isSelected = selectedType === config.type;

          return (
            <button
              key={config.type}
              type="button"
              onClick={() => {
                setSelectedType(config.type);
                resetAll();
              }}
              className={`p-4 rounded-xl border-2 text-left transition-all ${
                isSelected ? "border-primary bg-primary/5" : "border-border bg-card hover:border-primary/50"
              }`}
            >
              <div className="flex items-center gap-3 mb-2">
                <div className={`p-2 rounded-lg ${isSelected ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}>
                  <Icon size={20} />
                </div>
                <span className="font-semibold text-foreground">{config.label}</span>
              </div>
              <p className="text-sm text-muted-foreground">{config.description}</p>
            </button>
          );
        })}
      </div>

      <div className="card-section">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="font-semibold text-foreground flex items-center gap-2">
              <Database size={18} /> Importar {currentConfig.label}
            </h3>
            <p className="text-sm text-muted-foreground">
              Importação sem inferência: você escolhe exatamente quais colunas usar.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={downloadTemplate}>
              <Download size={16} className="mr-2" />
              Baixar modelo
            </Button>
            <Button variant="outline" size="sm" onClick={resetAll}>
              Resetar
            </Button>
          </div>
        </div>

        {/* File selection (stored or upload) */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="rounded-xl border border-border p-4 bg-card">
            <p className="text-sm font-medium text-foreground mb-2">Reprocessar planilha já enviada</p>
            <Select value={selectedStoredPath} onValueChange={handleSelectStoredFile}>
              <SelectTrigger>
                <SelectValue placeholder={storedFiles.length ? "Selecione um arquivo" : "Nenhum arquivo salvo"} />
              </SelectTrigger>
              <SelectContent>
                {storedFiles.map((f) => (
                  <SelectItem key={f.path} value={f.path}>
                    {f.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-xs text-muted-foreground mt-2">
              {storageWriteBlocked
                ? "Seu usuário não tem permissão para salvar arquivos no backend agora (o import ainda funciona normalmente)."
                : "Isso usa exatamente o arquivo salvo no backend (sem reupload)."}
            </p>
          </div>

          <div className="rounded-xl border border-border p-4 bg-card">
            <p className="text-sm font-medium text-foreground mb-2">Enviar nova planilha</p>
            <div className="relative border-2 border-dashed rounded-xl p-6 text-center bg-muted/30">
              <input
                ref={fileInputRef}
                type="file"
                accept=".csv,.xlsx,.xls"
                onChange={handleUploadNewFile}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                disabled={status.step === "processing"}
              />
              <FileSpreadsheet size={36} className="mx-auto text-muted-foreground mb-3" />
              <p className="text-foreground font-medium mb-1">Clique para selecionar</p>
              <p className="text-sm text-muted-foreground">CSV ou Excel</p>
            </div>
          </div>
        </div>

        {/* Mapping */}
        {(status.step === "mapping" || status.step === "ready") && rows && (
          <div className="mt-6 space-y-4">
            <div className="rounded-xl border border-border p-4 bg-card">
              <p className="font-medium text-foreground">Mapeamento de colunas (obrigatório)</p>
              <p className="text-sm text-muted-foreground">
                Para evitar erros de cabeçalho, eu pré-seleciono colunas quando o nome bate com sua planilha — revise e confirme antes de importar.
              </p>

              {selectedType === "orders" && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                  <MappingSelect
                    label="Nome do Cliente"
                    value={ordersMapping.clientName}
                    columns={columns}
                    onChange={(v) => setOrdersMapping((p) => ({ ...p, clientName: v }))}
                  />
                  <MappingSelect
                    label="Número do Pedido"
                    value={ordersMapping.orderNumber}
                    columns={columns}
                    onChange={(v) => setOrdersMapping((p) => ({ ...p, orderNumber: v }))}
                  />
                  <MappingSelect
                    label="Vendedor Responsável"
                    value={ordersMapping.seller}
                    columns={columns}
                    onChange={(v) => setOrdersMapping((p) => ({ ...p, seller: v }))}
                  />
                  <MappingSelect
                    label="Produto"
                    value={ordersMapping.productName}
                    columns={columns}
                    onChange={(v) => setOrdersMapping((p) => ({ ...p, productName: v }))}
                  />
                  <MappingSelect
                    label="Categoria"
                    value={ordersMapping.category}
                    columns={columns}
                    onChange={(v) => setOrdersMapping((p) => ({ ...p, category: v }))}
                  />
                  <MappingSelect
                    label="Data do Pedido (opcional)"
                    value={ordersMapping.orderDate || ""}
                    columns={columns}
                    allowEmpty
                    onChange={(v) => setOrdersMapping((p) => ({ ...p, orderDate: v || undefined }))}
                  />
                  <MappingSelect
                    label="Total do Pedido (opcional)"
                    value={ordersMapping.total || ""}
                    columns={columns}
                    allowEmpty
                    onChange={(v) => setOrdersMapping((p) => ({ ...p, total: v || undefined }))}
                  />
                  <MappingSelect
                    label="Quantidade (opcional)"
                    value={ordersMapping.quantity || ""}
                    columns={columns}
                    allowEmpty
                    onChange={(v) => setOrdersMapping((p) => ({ ...p, quantity: v || undefined }))}
                  />
                  <MappingSelect
                    label="Valor Unitário (opcional)"
                    value={ordersMapping.unitPrice || ""}
                    columns={columns}
                    allowEmpty
                    onChange={(v) => setOrdersMapping((p) => ({ ...p, unitPrice: v || undefined }))}
                  />
                  <MappingSelect
                    label="Subtotal Item (opcional)"
                    value={ordersMapping.subtotal || ""}
                    columns={columns}
                    allowEmpty
                    onChange={(v) => setOrdersMapping((p) => ({ ...p, subtotal: v || undefined }))}
                  />
                </div>
              )}

              {selectedType === "clients" && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                  <MappingSelect
                    label="Nome do Cliente"
                    value={clientsMapping.companyName}
                    columns={columns}
                    onChange={(v) => setClientsMapping((p) => ({ ...p, companyName: v }))}
                  />
                  <MappingSelect
                    label="CNPJ (opcional)"
                    value={clientsMapping.cnpj || ""}
                    columns={columns}
                    allowEmpty
                    onChange={(v) => setClientsMapping((p) => ({ ...p, cnpj: v || undefined }))}
                  />
                  <MappingSelect
                    label="Email (opcional)"
                    value={clientsMapping.email || ""}
                    columns={columns}
                    allowEmpty
                    onChange={(v) => setClientsMapping((p) => ({ ...p, email: v || undefined }))}
                  />
                  <MappingSelect
                    label="Telefone (opcional)"
                    value={clientsMapping.phone || ""}
                    columns={columns}
                    allowEmpty
                    onChange={(v) => setClientsMapping((p) => ({ ...p, phone: v || undefined }))}
                  />
                </div>
              )}

              {selectedType === "products" && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                  <MappingSelect
                    label="Nome do Produto *"
                    value={productsMapping.productName}
                    columns={columns}
                    onChange={(v) => setProductsMapping((p) => ({ ...p, productName: v }))}
                  />
                  <MappingSelect
                    label="Código do Item (SKU)"
                    value={productsMapping.sku || ""}
                    columns={columns}
                    allowEmpty
                    onChange={(v) => setProductsMapping((p) => ({ ...p, sku: v || undefined }))}
                  />
                  <MappingSelect
                    label="Categoria do Item *"
                    value={productsMapping.category || ""}
                    columns={columns}
                    onChange={(v) => setProductsMapping((p) => ({ ...p, category: v || undefined }))}
                  />
                  <MappingSelect
                    label="Unidade de Medida"
                    value={productsMapping.unitOfMeasure || ""}
                    columns={columns}
                    allowEmpty
                    onChange={(v) => setProductsMapping((p) => ({ ...p, unitOfMeasure: v || undefined }))}
                  />
                  <MappingSelect
                    label="Custo Unitário *"
                    value={productsMapping.costPrice || ""}
                    columns={columns}
                    onChange={(v) => setProductsMapping((p) => ({ ...p, costPrice: v || undefined }))}
                  />
                  <MappingSelect
                    label="Preço de Venda (opcional)"
                    value={productsMapping.salePrice || ""}
                    columns={columns}
                    allowEmpty
                    onChange={(v) => setProductsMapping((p) => ({ ...p, salePrice: v || undefined }))}
                  />

                  <div className="md:col-span-2">
                    <p className="text-xs text-muted-foreground mt-2">
                      * Campos obrigatórios. Se algum custo/categoria não puder ser convertido com segurança, a importação será bloqueada com erro.
                    </p>
                  </div>

                  {productsMapping.costPrice && (
                    <div className="md:col-span-2 mt-2">
                      <div className="rounded-lg border border-border bg-muted/30 p-3">
                        <p className="text-sm font-medium text-foreground">Prévia de conversão (5 linhas)</p>
                        <p className="text-xs text-muted-foreground">
                          Mostra o valor original e o número que será gravado em <span className="font-medium">Custo Unitário</span>.
                        </p>

                        <Table className="mt-2">
                          <TableHeader>
                            <TableRow>
                              <TableHead>#</TableHead>
                              <TableHead>Produto</TableHead>
                              <TableHead>SKU</TableHead>
                              <TableHead>Original</TableHead>
                              <TableHead>Convertido</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {rows.slice(0, 5).map((row, i) => {
                              const raw = (row as any)[productsMapping.costPrice!];
                              const rawText = raw === null || raw === undefined ? "" : String(raw).trim();
                              const parsed = parseDecimal(raw);
                              const ok = !!rawText && parsed !== null;

                              const nameCol = productsMapping.productName;
                              const productText = nameCol ? String((row as any)[nameCol] ?? "").trim() : "";
                              const skuCol = productsMapping.sku;
                              const skuText = skuCol ? String((row as any)[skuCol] ?? "").trim() : "";

                              return (
                                <TableRow key={i}>
                                  <TableCell className="text-muted-foreground">{i + 1}</TableCell>
                                  <TableCell className="max-w-[280px] truncate">{productText || "—"}</TableCell>
                                  <TableCell className="text-muted-foreground">{skuText || "—"}</TableCell>
                                  <TableCell className={ok ? "font-mono" : "font-mono text-destructive"}>
                                    {rawText || "—"}
                                  </TableCell>
                                  <TableCell className={ok ? "font-mono" : "font-mono text-destructive"}>
                                    {ok ? parsed!.toFixed(2) : "inválido"}
                                  </TableCell>
                                </TableRow>
                              );
                            })}
                          </TableBody>
                        </Table>

                        <p className="text-xs text-muted-foreground mt-2">
                          Aceita <span className="font-mono">55,23</span>, <span className="font-mono">55.23</span> e{" "}
                          <span className="font-mono">R$ 5.523,00</span>. Se aparecer “inválido”, a importação será bloqueada com um erro claro.
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {selectedType === "costs" && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                  <MappingSelect
                    label="SKU (Código do item) (opcional)"
                    value={costsMapping.sku || ""}
                    columns={columns}
                    allowEmpty
                    onChange={(v) => setCostsMapping((p) => ({ ...p, sku: v || undefined }))}
                  />
                  <MappingSelect
                    label="Nome do Produto (opcional)"
                    value={costsMapping.productName || ""}
                    columns={columns}
                    allowEmpty
                    onChange={(v) => setCostsMapping((p) => ({ ...p, productName: v || undefined }))}
                  />
                  <MappingSelect
                    label="Custo unitário"
                    value={costsMapping.costPrice}
                    columns={columns}
                    onChange={(v) => setCostsMapping((p) => ({ ...p, costPrice: v }))}
                  />
                  <MappingSelect
                    label="Categoria (opcional)"
                    value={costsMapping.category || ""}
                    columns={columns}
                    allowEmpty
                    onChange={(v) => setCostsMapping((p) => ({ ...p, category: v || undefined }))}
                  />
                </div>
              )}
            </div>

            {/* Mandatory confirmation + mapping summary */}
            <div className="rounded-xl border border-border p-4 bg-muted/30">
              <p className="font-medium text-foreground">Confirmação obrigatória</p>
              <p className="text-sm text-muted-foreground">Confira o mapeamento abaixo antes de executar.</p>

              <ul className="mt-3 space-y-1 text-sm">
                {mappingSummary.map((it) => (
                  <li key={it.label} className="flex items-center justify-between gap-4">
                    <span className="text-muted-foreground">{it.label}</span>
                    <span className="font-medium text-foreground">{it.value}</span>
                  </li>
                ))}
              </ul>

              <div className="flex items-center gap-2 mt-4">
                <Checkbox
                  checked={mappingConfirmed}
                  onCheckedChange={(v) => {
                    const checked = v === true;
                    setMappingConfirmed(checked);
                    setStatus((prev) => ({
                      ...prev,
                      step: checked ? "ready" : "mapping",
                    }));
                  }}
                  id="confirm-mapping"
                />
                <label htmlFor="confirm-mapping" className="text-sm text-foreground">
                  Confirmo que o mapeamento está correto e autorizo a importação.
                </label>
              </div>

              <div className="flex justify-end mt-4">
                <Button onClick={runImport} disabled={!canProceed}>
                  Executar importação
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Processing / results */}
        {status.step === "processing" && (
          <div className="mt-6 rounded-xl border border-border p-6 text-center bg-card">
            <Loader2 size={40} className="mx-auto text-primary mb-3 animate-spin" />
            <p className="text-foreground font-medium mb-2">{status.message}</p>
            {status.total && status.total > 0 && (
              <div className="max-w-sm mx-auto">
                <Progress value={((status.processed || 0) / status.total) * 100} />
                <p className="text-xs text-muted-foreground mt-2">
                  {status.processed || 0} de {status.total}
                </p>
              </div>
            )}
          </div>
        )}

        {status.step === "success" && (
          <div className="mt-6 rounded-xl border border-border p-6 text-center bg-card">
            <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-3">
              <Check size={22} className="text-primary" />
            </div>
            <p className="text-foreground font-medium">Importação concluída</p>
            <p className="text-sm text-muted-foreground mt-1">{status.message}</p>
            <div className="mt-4 flex justify-center gap-2">
              <Button variant="outline" onClick={resetAll}>
                Nova importação
              </Button>
            </div>
          </div>
        )}

        {status.step === "error" && (
          <div className="mt-6 rounded-xl border border-border p-6 text-center bg-card">
            <div className="w-12 h-12 rounded-full bg-destructive/10 flex items-center justify-center mx-auto mb-3">
              <AlertCircle size={22} className="text-destructive" />
            </div>
            <p className="text-foreground font-medium">Erro</p>
            <p className="text-sm text-muted-foreground mt-1">{status.message}</p>
            <div className="mt-4 flex justify-center gap-2">
              <Button variant="outline" onClick={resetAll}>
                Tentar novamente
              </Button>
            </div>
          </div>
        )}

        {status.step === "idle" && (
          <div className="mt-6 space-y-4">
            {/* Danger Zone - Delete all products */}
            <div className="rounded-xl border border-destructive/30 p-4 bg-destructive/5">
              <div className="flex items-start gap-3">
                <Trash2 className="text-destructive" size={18} />
                <div className="flex-1">
                  <p className="text-sm text-foreground font-medium">Deletar todos os produtos</p>
                  <p className="text-sm text-muted-foreground mt-1">
                    Remove todos os produtos da base. Pedidos e clientes são mantidos (os itens de pedido continuam com o nome do produto salvo).
                  </p>
                  <DeleteProductsButton />
                </div>
              </div>
            </div>

            {/* Danger Zone - Delete all orders */}
            <div className="rounded-xl border border-destructive/30 p-4 bg-destructive/5">
              <div className="flex items-start gap-3">
                <Trash2 className="text-destructive" size={18} />
                <div className="flex-1">
                  <p className="text-sm text-foreground font-medium">Limpar pedidos para reimportar do zero</p>
                  <p className="text-sm text-muted-foreground mt-1">
                    Deleta todos os pedidos e itens existentes. Clientes e produtos são mantidos.
                  </p>
                  <DeleteOrdersButton />
                </div>
              </div>
            </div>

            <div className="rounded-xl border border-border p-6 bg-muted/30">
              <div className="flex items-start gap-3">
                <Upload className="text-muted-foreground" size={18} />
                <div>
                  <p className="text-sm text-foreground font-medium">Como funciona</p>
                  <ul className="text-sm text-muted-foreground list-disc pl-5 mt-2 space-y-1">
                    <li>Você escolhe o arquivo (salvo ou novo).</li>
                    <li>Você mapeia manualmente as colunas.</li>
                    <li>A importação só roda após sua confirmação explícita.</li>
                    <li>Pedidos com número vazio não são criados.</li>
                    <li>Pedidos existentes são atualizados (não duplicados).</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}

function DeleteProductsButton() {
  const [loading, setLoading] = useState(false);
  const [confirmed, setConfirmed] = useState(false);

  const handleDelete = async () => {
    if (!confirmed) {
      setConfirmed(true);
      return;
    }

    setLoading(true);
    try {
      // First, set product_id to NULL in order_items (to break foreign key reference)
      const { error: nullifyErr } = await supabase
        .from("order_items")
        .update({ product_id: null })
        .neq("id", "00000000-0000-0000-0000-000000000000");
      if (nullifyErr) throw nullifyErr;

      // Now delete all products
      const { error } = await supabase.from("products").delete().neq("id", "00000000-0000-0000-0000-000000000000");
      if (error) throw error;

      toast.success("Todos os produtos foram deletados. Pronto para reimportar!");
      setConfirmed(false);
    } catch (e) {
      toast.error("Erro ao deletar: " + (e instanceof Error ? e.message : "Erro desconhecido"));
    } finally {
      setLoading(false);
    }
  };

  return (
    <Button
      variant={confirmed ? "destructive" : "outline"}
      size="sm"
      className="mt-3"
      onClick={handleDelete}
      disabled={loading}
    >
      {loading ? (
        <Loader2 size={14} className="mr-2 animate-spin" />
      ) : (
        <Trash2 size={14} className="mr-2" />
      )}
      {confirmed ? "Confirmar exclusão de produtos" : "Deletar todos os produtos"}
    </Button>
  );
}

function DeleteOrdersButton() {
  const [loading, setLoading] = useState(false);
  const [confirmed, setConfirmed] = useState(false);

  const handleDelete = async () => {
    if (!confirmed) {
      setConfirmed(true);
      return;
    }

    setLoading(true);
    try {
      // Delete order_items first (foreign key)
      const { error: itemsErr } = await supabase.from("order_items").delete().neq("id", "00000000-0000-0000-0000-000000000000");
      if (itemsErr) throw itemsErr;

      // Delete orders
      const { error: ordersErr } = await supabase.from("orders").delete().neq("id", "00000000-0000-0000-0000-000000000000");
      if (ordersErr) throw ordersErr;

      toast.success("Todos os pedidos e itens foram deletados. Pronto para reimportar!");
      setConfirmed(false);
    } catch (e) {
      toast.error("Erro ao deletar: " + (e instanceof Error ? e.message : "Erro desconhecido"));
    } finally {
      setLoading(false);
    }
  };

  return (
    <Button
      variant={confirmed ? "destructive" : "outline"}
      size="sm"
      className="mt-3"
      onClick={handleDelete}
      disabled={loading}
    >
      {loading ? (
        <Loader2 size={14} className="mr-2 animate-spin" />
      ) : (
        <Trash2 size={14} className="mr-2" />
      )}
      {confirmed ? "Confirmar exclusão" : "Deletar todos os pedidos"}
    </Button>
  );
}

function MappingSelect(props: {
  label: string;
  value: string;
  columns: string[];
  onChange: (value: string) => void;
  allowEmpty?: boolean;
}) {
  return (
    <div className="space-y-2">
      <p className="text-sm font-medium text-foreground">{props.label}</p>
      <Select value={props.value || "__empty__"} onValueChange={(v) => props.onChange(v === "__empty__" ? "" : v)}>
        <SelectTrigger>
          <SelectValue placeholder="Selecione uma coluna" />
        </SelectTrigger>
        <SelectContent>
          {props.allowEmpty && <SelectItem value="__empty__">(não mapeado)</SelectItem>}
          {props.columns.map((c) => (
            <SelectItem key={c} value={c}>
              {c}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}
