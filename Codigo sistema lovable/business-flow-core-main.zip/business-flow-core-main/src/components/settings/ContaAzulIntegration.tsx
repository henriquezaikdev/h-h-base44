import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import { ExternalLink, RefreshCw, Loader2, CheckCircle2, Clock, History, Banknote } from 'lucide-react';
import { FinSyncHistory } from '@/components/shared/FinSyncHistory';
import { CaixaSnapshotHistory } from '@/components/shared/CaixaSnapshotHistory';
import { AutoSyncStatus } from '@/components/shared/AutoSyncStatus';

const formatCurrency = (v: number) =>
  v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

export function ContaAzulIntegration() {
  const [lastSync, setLastSync] = useState<string | null>(null);
  const [syncing, setSyncing] = useState(false);
  const [syncingCaixa, setSyncingCaixa] = useState(false);
  const [loading, setLoading] = useState(true);
  const [isConnected, setIsConnected] = useState(false);
  const [syncRefreshKey, setSyncRefreshKey] = useState(0);
  const [lastSnapshot, setLastSnapshot] = useState<{ caixa_total: number; created_at: string } | null>(null);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const contaAzulStatus = params.get('conta_azul');
    if (contaAzulStatus === 'success') {
      toast.success('Conta Azul conectada com sucesso!');
      window.history.replaceState({}, '', window.location.pathname);
    } else if (contaAzulStatus === 'error') {
      toast.error('Erro ao conectar com Conta Azul. Tente novamente.');
      window.history.replaceState({}, '', window.location.pathname);
    }
    fetchStatus();
  }, []);

  const fetchStatus = async () => {
    try {
      const { data: syncData } = await supabase
        .from('app_config')
        .select('value')
        .eq('key', 'conta_azul_last_sync')
        .maybeSingle();

      if (syncData?.value) {
        const val = typeof syncData.value === 'string' ? syncData.value : JSON.parse(JSON.stringify(syncData.value));
        setLastSync(typeof val === 'string' ? val.replace(/\\\"/g, '') : String(val));
      }

      const { data: tokenData } = await supabase
        .from('app_config')
        .select('value')
        .eq('key', 'conta_azul_tokens')
        .maybeSingle();

      setIsConnected(!!tokenData);

      // Fetch last snapshot
      const { data: snap } = await supabase
        .from('fin_caixa_saldo_snapshot')
        .select('caixa_total, created_at')
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (snap) setLastSnapshot(snap as any);
    } catch (err) {
      console.error('Error fetching Conta Azul status:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleReconnect = () => {
    window.location.href = "https://auth.contaazul.com/login?response_type=code&client_id=2dndpag0bu77c5s12ntav0c5sp&redirect_uri=https://tzzbllhvpmpijbdidmtx.supabase.co/functions/v1/conta-azul-callback";
  };

  const handleSync = async () => {
    setSyncing(true);
    try {
      const { data, error } = await supabase.functions.invoke('conta-azul-sync?mode=financeiro');
      if (error) throw error;
      if (data?.error) throw new Error(data.error);

      toast.success(`Sincronização concluída! Receber: ${data.receber_synced ?? 0}, Pagar: ${data.pagar_synced ?? 0}`);
      setLastSync(data.synced_at);
      setSyncRefreshKey(k => k + 1);
    } catch (err: any) {
      console.error('Sync error:', err);
      toast.error(err.message || 'Erro ao sincronizar com Conta Azul');
    } finally {
      setSyncing(false);
    }
  };

  const handleSyncCaixa = async () => {
    setSyncingCaixa(true);
    try {
      const { data, error } = await supabase.functions.invoke('conta-azul-sync?mode=caixa');
      if (error) throw error;
      if (data?.error) throw new Error(data.error);

      toast.success(`Caixa atualizado! ${data.accounts_synced} contas, Total: ${formatCurrency(data.caixa_total)}`);
      setLastSnapshot({ caixa_total: data.caixa_total, created_at: new Date().toISOString() });
      setSyncRefreshKey(k => k + 1);
    } catch (err: any) {
      console.error('Sync caixa error:', err);
      toast.error(err.message || 'Erro ao atualizar caixa');
    } finally {
      setSyncingCaixa(false);
    }
  };

  const formatDate = (dateStr: string) => {
    try {
      return new Date(dateStr).toLocaleString('pt-BR');
    } catch {
      return dateStr;
    }
  };

  if (loading) {
    return (
      <div className="card-section">
        <div className="flex items-center gap-2">
          <Loader2 className="h-4 w-4 animate-spin" />
          <span className="text-sm text-muted-foreground">Carregando...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="card-section">
      <h3 className="font-semibold text-foreground mb-4">Integrações</h3>

      <div className="space-y-4">
        <div className="flex items-center justify-between p-4 border rounded-lg">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="font-medium">Conta Azul</span>
              {isConnected ? (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-green-100 text-green-700 rounded-full text-xs">
                  <CheckCircle2 size={12} />
                  Conectado
                </span>
              ) : (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-yellow-100 text-yellow-700 rounded-full text-xs">
                  Desconectado
                </span>
              )}
            </div>
            {lastSync && (
              <p className="text-xs text-muted-foreground flex items-center gap-1">
                <Clock size={12} />
                Última sincronização: {formatDate(lastSync)}
              </p>
            )}
          </div>

          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={handleReconnect}
            >
              <ExternalLink size={14} className="mr-1" />
              {isConnected ? 'Reconectar' : 'Conectar Conta Azul'}
            </Button>

            {isConnected && (
              <Button
                variant="default"
                size="sm"
                onClick={handleSync}
                disabled={syncing}
              >
                {syncing ? (
                  <Loader2 size={14} className="mr-1 animate-spin" />
                ) : (
                  <RefreshCw size={14} className="mr-1" />
                )}
                Sincronizar Agora
              </Button>
            )}
          </div>
        </div>

        {/* Caixa Snapshot */}
        {isConnected && (
          <div className="flex items-center justify-between p-4 border rounded-lg bg-card">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <Banknote size={16} className="text-primary" />
                <span className="font-medium text-sm">Caixa Atual (Conta Azul)</span>
              </div>
              {lastSnapshot ? (
                <>
                  <p className="text-lg font-semibold text-primary">
                    {formatCurrency(lastSnapshot.caixa_total)}
                  </p>
                  <p className="text-[11px] text-muted-foreground">
                    Atualizado em {formatDate(lastSnapshot.created_at)}
                  </p>
                </>
              ) : (
                <p className="text-xs text-muted-foreground">Nenhum snapshot disponível. Clique em "Atualizar Caixa".</p>
              )}
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={handleSyncCaixa}
              disabled={syncingCaixa}
            >
              {syncingCaixa ? (
                <Loader2 size={14} className="mr-1 animate-spin" />
              ) : (
                <Banknote size={14} className="mr-1" />
              )}
              Atualizar Caixa
            </Button>
          </div>
        )}

        {/* Caixa Snapshot History */}
        {isConnected && (
          <div className="border rounded-lg p-4">
            <h4 className="text-sm font-medium text-foreground flex items-center gap-2 mb-3">
              <Banknote size={14} />
              Histórico de Saldos (Caixa)
            </h4>
            <CaixaSnapshotHistory refreshKey={syncRefreshKey} />
          </div>
        )}
        {/* Auto Sync Status */}
        <div className="border rounded-lg p-4 space-y-3">
          <h4 className="text-sm font-medium text-foreground flex items-center gap-2">
            <Clock size={14} />
            Sincronização Automática
          </h4>
          <AutoSyncStatus refreshKey={syncRefreshKey} />
        </div>

        {/* Sync History */}
        <div className="border rounded-lg p-4">
          <h4 className="text-sm font-medium text-foreground flex items-center gap-2 mb-3">
            <History size={14} />
            Histórico de Sincronizações
          </h4>
          <FinSyncHistory refreshKey={syncRefreshKey} />
        </div>
      </div>
    </div>
  );
}
