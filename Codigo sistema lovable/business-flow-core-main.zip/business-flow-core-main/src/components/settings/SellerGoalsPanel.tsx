import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { Loader2, Pencil, Save, X, Target, Phone, MessageCircle, DollarSign, Info, UserPlus, RotateCcw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

interface SellerWithGoals {
  id: string;
  name: string;
  currentLevel: 'ovo' | 'pena' | 'aguia';
  monthlySalesTarget: number;
  baseDailyCalls: number;
  baseDailyWhatsapp: number;
  // Calculated based on working days
  monthlyCallsTarget?: number;
  monthlyWhatsappTarget?: number;
  // Client targets
  newClientsTarget: number;
  newClientsReward: number;
  reactivationsTarget: number;
  reactivationsReward: number;
}

interface EditFormData {
  monthlySalesTarget: string;
  monthlyCallsTarget: string;
  monthlyWhatsappTarget: string;
  newClientsTarget: string;
  reactivationsTarget: string;
}

const LEVEL_LABELS = {
  ovo: { label: 'Ovo', color: 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300' },
  pena: { label: 'Pena', color: 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300' },
  aguia: { label: 'Águia', color: 'bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-300' },
};

// Default values when no custom config exists
const DEFAULT_TARGETS = {
  ovo: { baseDailyCalls: 18, baseDailyWhatsapp: 15 },
  pena: { baseDailyCalls: 11, baseDailyWhatsapp: 17 },
  aguia: { baseDailyCalls: 11, baseDailyWhatsapp: 17 },
};

export function SellerGoalsPanel() {
  const queryClient = useQueryClient();
  const [sellers, setSellers] = useState<SellerWithGoals[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState<string | null>(null);
  const [editingSellerId, setEditingSellerId] = useState<string | null>(null);
  const [editForm, setEditForm] = useState<EditFormData>({
    monthlySalesTarget: '',
    monthlyCallsTarget: '',
    monthlyWhatsappTarget: '',
    newClientsTarget: '',
    reactivationsTarget: '',
  });
  const [workingDays, setWorkingDays] = useState(21);

  useEffect(() => {
    fetchSellersWithGoals();
    fetchWorkingDays();
  }, []);

  const fetchWorkingDays = async () => {
    try {
      const now = new Date();
      const yearMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
      
      const { data } = await supabase
        .from('work_month_config')
        .select('working_days')
        .eq('year_month', yearMonth)
        .maybeSingle();
      
      if (data?.working_days) {
        setWorkingDays(data.working_days);
      }
    } catch (error) {
      console.error('Error fetching working days:', error);
    }
  };

  const fetchSellersWithGoals = async () => {
    try {
      // Fetch active sellers (only role='vendedor', not admins)
      const { data: sellersData, error: sellersError } = await supabase
        .from('sellers')
        .select('id, name, status')
        .eq('status', 'ATIVO')
        .eq('role', 'vendedor')
        .order('name');

      if (sellersError) throw sellersError;

      // Fetch seller_levels for all sellers
      const { data: levelsData, error: levelsError } = await supabase
        .from('seller_levels')
        .select('seller_id, current_level, monthly_sales_target, base_daily_calls, base_daily_whatsapp, new_clients_target, new_clients_stars_reward, reactivations_target, reactivations_stars_reward');

      if (levelsError) throw levelsError;

      // Create a map for quick lookup
      const levelsMap = new Map(
        (levelsData || []).map(level => [level.seller_id, level])
      );

      // Combine data
      const combined: SellerWithGoals[] = (sellersData || []).map(seller => {
        const levelData = levelsMap.get(seller.id);
        const currentLevel = (levelData?.current_level as 'ovo' | 'pena' | 'aguia') || 'ovo';
        const defaults = DEFAULT_TARGETS[currentLevel];
        
        const baseDailyCalls = levelData?.base_daily_calls || defaults.baseDailyCalls;
        const baseDailyWhatsapp = levelData?.base_daily_whatsapp || defaults.baseDailyWhatsapp;
        
        return {
          id: seller.id,
          name: seller.name || 'Vendedor',
          currentLevel,
          monthlySalesTarget: levelData?.monthly_sales_target || 30000,
          baseDailyCalls,
          baseDailyWhatsapp,
          monthlyCallsTarget: baseDailyCalls * workingDays,
          monthlyWhatsappTarget: baseDailyWhatsapp * workingDays,
          newClientsTarget: levelData?.new_clients_target ?? 3,
          newClientsReward: levelData?.new_clients_stars_reward ?? 2,
          reactivationsTarget: levelData?.reactivations_target ?? 2,
          reactivationsReward: levelData?.reactivations_stars_reward ?? 1,
        };
      });

      setSellers(combined);
    } catch (error) {
      console.error('Error fetching sellers with goals:', error);
      toast.error('Erro ao carregar metas dos vendedores');
    } finally {
      setLoading(false);
    }
  };

  // Recalculate monthly targets when working days changes
  useEffect(() => {
    setSellers(prev => prev.map(seller => ({
      ...seller,
      monthlyCallsTarget: seller.baseDailyCalls * workingDays,
      monthlyWhatsappTarget: seller.baseDailyWhatsapp * workingDays,
    })));
  }, [workingDays]);

  const startEdit = (seller: SellerWithGoals) => {
    setEditingSellerId(seller.id);
    setEditForm({
      monthlySalesTarget: String(seller.monthlySalesTarget),
      monthlyCallsTarget: String(seller.monthlyCallsTarget || seller.baseDailyCalls * workingDays),
      monthlyWhatsappTarget: String(seller.monthlyWhatsappTarget || seller.baseDailyWhatsapp * workingDays),
      newClientsTarget: String(seller.newClientsTarget),
      reactivationsTarget: String(seller.reactivationsTarget),
    });
  };

  const cancelEdit = () => {
    setEditingSellerId(null);
    setEditForm({
      monthlySalesTarget: '',
      monthlyCallsTarget: '',
      monthlyWhatsappTarget: '',
      newClientsTarget: '',
      reactivationsTarget: '',
    });
  };

  const handleSave = async (sellerId: string) => {
    const monthlySalesTarget = parseFloat(editForm.monthlySalesTarget) || 30000;
    const monthlyCallsTarget = parseInt(editForm.monthlyCallsTarget) || 378;
    const monthlyWhatsappTarget = parseInt(editForm.monthlyWhatsappTarget) || 315;
    const newClientsTarget = parseInt(editForm.newClientsTarget) || 3;
    const reactivationsTarget = parseInt(editForm.reactivationsTarget) || 2;

    // Calculate daily targets from monthly
    const baseDailyCalls = Math.ceil(monthlyCallsTarget / workingDays);
    const baseDailyWhatsapp = Math.ceil(monthlyWhatsappTarget / workingDays);

    setSaving(sellerId);
    try {
      const { error } = await supabase
        .from('seller_levels')
        .upsert({
          seller_id: sellerId,
          monthly_sales_target: monthlySalesTarget,
          base_daily_calls: baseDailyCalls,
          base_daily_whatsapp: baseDailyWhatsapp,
          new_clients_target: newClientsTarget,
          reactivations_target: reactivationsTarget,
        }, { onConflict: 'seller_id' });

      if (error) throw error;

      // Update local state
      setSellers(prev => prev.map(seller => {
        if (seller.id === sellerId) {
          return {
            ...seller,
            monthlySalesTarget,
            baseDailyCalls,
            baseDailyWhatsapp,
            monthlyCallsTarget: baseDailyCalls * workingDays,
            monthlyWhatsappTarget: baseDailyWhatsapp * workingDays,
            newClientsTarget,
            reactivationsTarget,
          };
        }
        return seller;
      }));

      // Invalidate related queries
      queryClient.invalidateQueries({ queryKey: ['seller-metrics'] });
      queryClient.invalidateQueries({ queryKey: ['evolution-data'] });
      queryClient.invalidateQueries({ queryKey: ['action-center'] });
      queryClient.invalidateQueries({ queryKey: ['gestor-data'] });

      toast.success('Metas atualizadas com sucesso!');
      cancelEdit();
    } catch (error: any) {
      console.error('Error saving goals:', error);
      toast.error(error.message || 'Erro ao salvar metas');
    } finally {
      setSaving(null);
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center py-12">
          <Loader2 className="animate-spin h-8 w-8 text-primary" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Target className="h-5 w-5 text-primary" />
              Metas Individuais por Vendedor
            </CardTitle>
            <CardDescription className="mt-1">
              Configure vendas, ligações e WhatsApp para cada vendedor. 
              Estas metas são usadas em todo o sistema.
            </CardDescription>
          </div>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <div className="flex items-center gap-2 text-sm text-muted-foreground bg-muted px-3 py-1.5 rounded-md">
                  <Info className="h-4 w-4" />
                  {workingDays} dias úteis/mês
                </div>
              </TooltipTrigger>
              <TooltipContent>
                <p>Dias úteis configurados para o mês atual.</p>
                <p className="text-xs text-muted-foreground">
                  Configure em "Dias Úteis do Mês" acima.
                </p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
      </CardHeader>
      <CardContent>
        <div className="rounded-md border overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Vendedor</TableHead>
                <TableHead>Nível</TableHead>
                <TableHead className="text-right">
                  <div className="flex items-center justify-end gap-1">
                    <DollarSign className="h-4 w-4 text-emerald-600" />
                    Vendas/Mês
                  </div>
                </TableHead>
                <TableHead className="text-right">
                  <div className="flex items-center justify-end gap-1">
                    <Phone className="h-4 w-4 text-blue-600" />
                    Ligações/Mês
                  </div>
                </TableHead>
                <TableHead className="text-right">
                  <div className="flex items-center justify-end gap-1">
                    <MessageCircle className="h-4 w-4 text-green-600" />
                    WhatsApp/Mês
                  </div>
                </TableHead>
                <TableHead className="text-center">
                  <div className="flex items-center justify-center gap-1">
                    <UserPlus className="h-4 w-4 text-violet-600" />
                    <span className="text-xs">Novos</span>
                  </div>
                </TableHead>
                <TableHead className="text-center">
                  <div className="flex items-center justify-center gap-1">
                    <RotateCcw className="h-4 w-4 text-orange-600" />
                    <span className="text-xs">React.</span>
                  </div>
                </TableHead>
                <TableHead className="text-center">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sellers.length === 0 ? (
              <TableRow>
                  <TableCell colSpan={8} className="text-center text-muted-foreground py-8">
                    Nenhum vendedor ativo encontrado
                  </TableCell>
                </TableRow>
              ) : (
                sellers.map((seller) => {
                  const isEditing = editingSellerId === seller.id;
                  const isSaving = saving === seller.id;
                  const levelInfo = LEVEL_LABELS[seller.currentLevel];

                  return (
                    <TableRow key={seller.id}>
                      <TableCell className="font-medium">{seller.name}</TableCell>
                      <TableCell>
                        <Badge className={levelInfo.color}>
                          {levelInfo.label}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        {isEditing ? (
                          <Input
                            type="number"
                            value={editForm.monthlySalesTarget}
                            onChange={(e) => setEditForm(prev => ({ ...prev, monthlySalesTarget: e.target.value }))}
                            className="w-32 text-right ml-auto"
                            placeholder="50000"
                          />
                        ) : (
                          <span className="text-emerald-600 font-medium">
                            {formatCurrency(seller.monthlySalesTarget)}
                          </span>
                        )}
                      </TableCell>
                      <TableCell className="text-right">
                        {isEditing ? (
                          <div className="flex flex-col items-end gap-1">
                            <Input
                              type="number"
                              value={editForm.monthlyCallsTarget}
                              onChange={(e) => setEditForm(prev => ({ ...prev, monthlyCallsTarget: e.target.value }))}
                              className="w-24 text-right"
                              placeholder="378"
                            />
                            <span className="text-xs text-muted-foreground">
                              ≈ {Math.ceil(parseInt(editForm.monthlyCallsTarget || '0') / workingDays)}/dia
                            </span>
                          </div>
                        ) : (
                          <div className="flex flex-col items-end">
                            <span className="text-blue-600 font-medium">
                              {seller.monthlyCallsTarget}
                            </span>
                            <span className="text-xs text-muted-foreground">
                              {seller.baseDailyCalls}/dia
                            </span>
                          </div>
                        )}
                      </TableCell>
                      <TableCell className="text-right">
                        {isEditing ? (
                          <div className="flex flex-col items-end gap-1">
                            <Input
                              type="number"
                              value={editForm.monthlyWhatsappTarget}
                              onChange={(e) => setEditForm(prev => ({ ...prev, monthlyWhatsappTarget: e.target.value }))}
                              className="w-24 text-right"
                              placeholder="315"
                            />
                            <span className="text-xs text-muted-foreground">
                              ≈ {Math.ceil(parseInt(editForm.monthlyWhatsappTarget || '0') / workingDays)}/dia
                            </span>
                          </div>
                        ) : (
                          <div className="flex flex-col items-end">
                            <span className="text-green-600 font-medium">
                              {seller.monthlyWhatsappTarget}
                            </span>
                            <span className="text-xs text-muted-foreground">
                              {seller.baseDailyWhatsapp}/dia
                            </span>
                          </div>
                        )}
                      </TableCell>
                      {/* Clientes Novos */}
                      <TableCell className="text-center">
                        {isEditing ? (
                          <Input
                            type="number"
                            value={editForm.newClientsTarget}
                            onChange={(e) => setEditForm(prev => ({ ...prev, newClientsTarget: e.target.value }))}
                            className="w-16 text-center mx-auto"
                            placeholder="3"
                          />
                        ) : (
                          <span className="text-violet-600 font-medium">
                            {seller.newClientsTarget}
                          </span>
                        )}
                      </TableCell>
                      {/* Reativações */}
                      <TableCell className="text-center">
                        {isEditing ? (
                          <Input
                            type="number"
                            value={editForm.reactivationsTarget}
                            onChange={(e) => setEditForm(prev => ({ ...prev, reactivationsTarget: e.target.value }))}
                            className="w-16 text-center mx-auto"
                            placeholder="2"
                          />
                        ) : (
                          <span className="text-orange-600 font-medium">
                            {seller.reactivationsTarget}
                          </span>
                        )}
                      </TableCell>
                      {/* Ações */}
                      <TableCell className="text-center">
                        {isEditing ? (
                          <div className="flex items-center justify-center gap-1">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={cancelEdit}
                              disabled={isSaving}
                            >
                              <X className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="default"
                              size="sm"
                              onClick={() => handleSave(seller.id)}
                              disabled={isSaving}
                            >
                              {isSaving ? (
                                <Loader2 className="h-4 w-4 animate-spin" />
                              ) : (
                                <Save className="h-4 w-4" />
                              )}
                            </Button>
                          </div>
                        ) : (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => startEdit(seller)}
                          >
                            <Pencil className="h-4 w-4" />
                          </Button>
                        )}
                      </TableCell>
                    </TableRow>
                  );
                })
              )}
            </TableBody>
          </Table>
        </div>
        
        <div className="mt-4 p-3 bg-muted/50 rounded-lg">
          <p className="text-sm text-muted-foreground">
            <strong>💡 Dica:</strong> As metas de ligações e WhatsApp são armazenadas como valores diários 
            e multiplicadas pelos dias úteis do mês. Alterar aqui afeta imediatamente o <strong>Meu Dia</strong>, 
            <strong> Evolução do Vendedor</strong>, <strong>Gestor</strong> e todos os scoreboards.
          </p>
        </div>

      </CardContent>
    </Card>
  );
}
