import { useState } from 'react';
import { useCategoriesData, CategoryData } from '@/hooks/useCategoriesData';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Plus, Pencil, Trash2, Loader2 } from 'lucide-react';
import { toast } from 'sonner';

export function CategoriesTab() {
  const { categories, loading, createCategory, updateCategory, deleteCategory } = useCategoriesData();
  
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [newName, setNewName] = useState('');
  const [editingCategory, setEditingCategory] = useState<CategoryData | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const handleCreate = async () => {
    if (!newName.trim()) {
      toast.error('Nome da categoria é obrigatório');
      return;
    }
    setSubmitting(true);
    const result = await createCategory(newName);
    setSubmitting(false);
    if (result.success) {
      toast.success('Categoria criada');
      setNewName('');
      setCreateDialogOpen(false);
    } else {
      toast.error(result.error || 'Erro ao criar categoria');
    }
  };

  const handleRename = async () => {
    if (!editingCategory || !newName.trim()) return;
    setSubmitting(true);
    const result = await updateCategory(editingCategory.id, { name: newName.trim() });
    setSubmitting(false);
    if (result.success) {
      toast.success('Categoria renomeada');
      setEditDialogOpen(false);
      setEditingCategory(null);
      setNewName('');
    } else {
      toast.error(result.error || 'Erro ao renomear');
    }
  };

  const handleToggleActive = async (cat: CategoryData) => {
    const result = await updateCategory(cat.id, { active: !cat.active });
    if (result.success) {
      toast.success(cat.active ? 'Categoria inativada' : 'Categoria ativada');
    } else {
      toast.error(result.error || 'Erro ao atualizar');
    }
  };

  const handleDelete = async () => {
    if (!editingCategory) return;
    setSubmitting(true);
    const result = await deleteCategory(editingCategory.id);
    setSubmitting(false);
    if (result.success) {
      toast.success('Categoria excluída');
      setDeleteDialogOpen(false);
      setEditingCategory(null);
    } else {
      toast.error(result.error || 'Erro ao excluir');
    }
  };

  const openEdit = (cat: CategoryData) => {
    setEditingCategory(cat);
    setNewName(cat.name);
    setEditDialogOpen(true);
  };

  const openDelete = (cat: CategoryData) => {
    setEditingCategory(cat);
    setDeleteDialogOpen(true);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold">Categorias de Produtos</h3>
        <Button onClick={() => { setNewName(''); setCreateDialogOpen(true); }}>
          <Plus className="h-4 w-4 mr-2" />
          Nova Categoria
        </Button>
      </div>

      {categories.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground">
          Nenhuma categoria cadastrada
        </div>
      ) : (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Nome</TableHead>
              <TableHead className="w-[120px] text-center">Produtos</TableHead>
              <TableHead className="w-[100px] text-center">Ativa</TableHead>
              <TableHead className="w-[100px] text-right">Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {categories.map(cat => (
              <TableRow key={cat.id}>
                <TableCell className="font-medium">{cat.name}</TableCell>
                <TableCell className="text-center">{cat.productCount}</TableCell>
                <TableCell className="text-center">
                  <Switch
                    checked={cat.active}
                    onCheckedChange={() => handleToggleActive(cat)}
                  />
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end gap-1">
                    <Button variant="ghost" size="icon" onClick={() => openEdit(cat)}>
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => openDelete(cat)}
                      disabled={cat.productCount > 0}
                      title={cat.productCount > 0 ? 'Não é possível excluir categoria com produtos' : 'Excluir'}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      )}

      {/* Create Dialog */}
      <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Nova Categoria</DialogTitle>
          </DialogHeader>
          <Input
            placeholder="Nome da categoria"
            value={newName}
            onChange={e => setNewName(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleCreate()}
          />
          <DialogFooter>
            <Button variant="outline" onClick={() => setCreateDialogOpen(false)}>Cancelar</Button>
            <Button onClick={handleCreate} disabled={submitting}>
              {submitting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Criar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Dialog */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Renomear Categoria</DialogTitle>
          </DialogHeader>
          <Input
            placeholder="Nome da categoria"
            value={newName}
            onChange={e => setNewName(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleRename()}
          />
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditDialogOpen(false)}>Cancelar</Button>
            <Button onClick={handleRename} disabled={submitting}>
              {submitting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Salvar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Excluir categoria?</AlertDialogTitle>
            <AlertDialogDescription>
              {editingCategory?.productCount && editingCategory.productCount > 0 
                ? `Esta categoria possui ${editingCategory.productCount} produto(s) vinculado(s) e não pode ser excluída.`
                : `Tem certeza que deseja excluir a categoria "${editingCategory?.name}"?`
              }
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            {(!editingCategory?.productCount || editingCategory.productCount === 0) && (
              <AlertDialogAction onClick={handleDelete} disabled={submitting}>
                {submitting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                Excluir
              </AlertDialogAction>
            )}
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
