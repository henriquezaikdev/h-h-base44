import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Plus, Trash2, Loader2, Wand2 } from 'lucide-react';
import { toast } from 'sonner';
import { Progress } from '@/components/ui/progress';
import { queryClient } from '@/lib/queryClient';

interface Rule {
  id: string;
  palavra_chave: string;
  hh_categoria_id: string;
  categoria_nome?: string;
}

interface HHCategoria {
  id: string;
  name: string;
}

export function AutoCategorizeRulesTab() {
  const [rules, setRules] = useState<Rule[]>([]);
  const [categories, setCategories] = useState<HHCategoria[]>([]);
  const [loading, setLoading] = useState(true);
  const [addOpen, setAddOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<Rule | null>(null);
  const [newKeyword, setNewKeyword] = useState('');
  const [newCategoryId, setNewCategoryId] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [autoCatRunning, setAutoCatRunning] = useState(false);

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const [rulesRes, catsRes] = await Promise.all([
        supabase.from('hh_categoria_regras' as any).select('id, palavra_chave, hh_categoria_id').order('palavra_chave'),
        supabase.from('hh_categorias' as any).select('id, name').order('name'),
      ]);

      const catsData = (catsRes.data || []) as unknown as HHCategoria[];
      setCategories(catsData);

      const catMap = new Map(catsData.map(c => [c.id, c.name]));
      setRules(
        ((rulesRes.data || []) as any[]).map(r => ({
          ...r,
          categoria_nome: catMap.get(r.hh_categoria_id) || '?',
        }))
      );
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  const handleAdd = async () => {
    if (!newKeyword.trim() || !newCategoryId) {
      toast.error('Preencha a palavra-chave e selecione uma categoria');
      return;
    }
    setSubmitting(true);
    try {
      const { error } = await supabase
        .from('hh_categoria_regras' as any)
        .insert({ palavra_chave: newKeyword.trim().toUpperCase(), hh_categoria_id: newCategoryId } as any);
      if (error) throw error;
      toast.success('Regra adicionada');
      setNewKeyword('');
      setNewCategoryId('');
      setAddOpen(false);
      fetchData();
    } catch (err: any) {
      toast.error(err.message?.includes('unique') ? 'Essa palavra-chave já existe' : err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setSubmitting(true);
    try {
      const { error } = await supabase.from('hh_categoria_regras' as any).delete().eq('id', deleteTarget.id);
      if (error) throw error;
      toast.success('Regra removida');
      setDeleteTarget(null);
      fetchData();
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const handleAutoCategorize = async () => {
    setAutoCatRunning(true);
    try {
      const { data, error } = await supabase.functions.invoke('hh-auto-categorizar');
      if (error) throw error;
      if (data?.error) throw new Error(data.error);

      const { total_sem_categoria, matched, updated } = data;
      toast.success(`Auto-categorização concluída!`, {
        description: `${updated} produtos categorizados de ${total_sem_categoria} pendentes (${rules.length} regras aplicadas)`,
        duration: 8000,
      });

      // Invalidate product caches
      queryClient.invalidateQueries({ queryKey: ['produtos'] });
      queryClient.invalidateQueries({ queryKey: ['products'] });
      queryClient.invalidateQueries({ queryKey: ['productsPainel'] });
    } catch (err: any) {
      toast.error(err.message || 'Erro na auto-categorização');
    } finally {
      setAutoCatRunning(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center flex-wrap gap-2">
        <div>
          <h3 className="text-lg font-semibold">Regras Automáticas de Categorização</h3>
          <p className="text-sm text-muted-foreground">
            Se o nome do produto contém a palavra-chave, ele recebe a categoria automaticamente.
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => { setNewKeyword(''); setNewCategoryId(''); setAddOpen(true); }}>
            <Plus className="h-4 w-4 mr-2" />
            Nova Regra
          </Button>
          <Button onClick={handleAutoCategorize} disabled={autoCatRunning || rules.length === 0}>
            {autoCatRunning ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Wand2 className="h-4 w-4 mr-2" />}
            🪄 Auto-Categorizar Pendentes
          </Button>
        </div>
      </div>

      {rules.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground">
          Nenhuma regra cadastrada. Adicione palavras-chave para começar.
        </div>
      ) : (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Palavra-chave</TableHead>
              <TableHead>Categoria Destino</TableHead>
              <TableHead className="w-[80px] text-right">Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {rules.map(rule => (
              <TableRow key={rule.id}>
                <TableCell className="font-mono font-medium">{rule.palavra_chave}</TableCell>
                <TableCell>{rule.categoria_nome}</TableCell>
                <TableCell className="text-right">
                  <Button variant="ghost" size="icon" onClick={() => setDeleteTarget(rule)}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      )}

      {/* Add Dialog */}
      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Nova Regra</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium">Palavra-chave (será salva em MAIÚSCULO)</label>
              <Input
                placeholder="Ex: TONER"
                value={newKeyword}
                onChange={e => setNewKeyword(e.target.value)}
              />
            </div>
            <div>
              <label className="text-sm font-medium">Categoria destino</label>
              <Select value={newCategoryId} onValueChange={setNewCategoryId}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione a categoria" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map(cat => (
                    <SelectItem key={cat.id} value={cat.id}>{cat.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setAddOpen(false)}>Cancelar</Button>
            <Button onClick={handleAdd} disabled={submitting}>
              {submitting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Adicionar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={!!deleteTarget} onOpenChange={(open) => !open && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Excluir regra?</AlertDialogTitle>
            <AlertDialogDescription>
              Remover a regra para a palavra-chave "{deleteTarget?.palavra_chave}"?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} disabled={submitting}>
              {submitting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Excluir
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
