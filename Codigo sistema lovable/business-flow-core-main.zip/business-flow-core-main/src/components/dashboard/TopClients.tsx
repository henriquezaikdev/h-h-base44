import { Crown } from 'lucide-react';
import { TopClient } from '@/hooks/useDashboardData';

interface TopClientsProps {
  clients: TopClient[];
}

export function TopClients({ clients }: TopClientsProps) {
  if (clients.length === 0) {
    return (
      <div className="text-center py-4 text-muted-foreground text-sm">
        Nenhum cliente cadastrado
      </div>
    );
  }

  const maxRevenue = clients[0]?.totalRevenue || 1;

  return (
    <div className="space-y-3">
      {clients.map((client, index) => {
        const percentage = (client.totalRevenue / maxRevenue) * 100;
        const isTop = index === 0;
        
        return (
          <div key={client.id} className="group">
            <div className="flex items-center gap-3 p-3 rounded-lg hover:bg-muted/50 transition-colors">
              <div className={`w-8 h-8 rounded-lg flex items-center justify-center text-sm font-bold ${
                isTop 
                  ? 'bg-gradient-to-br from-primary to-hh-orange-dark text-primary-foreground' 
                  : 'bg-muted text-muted-foreground'
              }`}>
                {index + 1}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <p className="text-sm font-medium text-foreground truncate">
                    {client.companyName}
                  </p>
                  {isTop && <Crown size={14} className="text-primary flex-shrink-0" />}
                </div>
                <div className="flex items-center gap-2 mt-1">
                  <div className="flex-1 h-1.5 bg-muted rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-primary/60 rounded-full transition-all duration-500"
                      style={{ width: `${percentage}%` }}
                    />
                  </div>
                  <span className="text-xs text-muted-foreground whitespace-nowrap">
                    R$ {(client.totalRevenue / 1000).toFixed(0)}k
                  </span>
                </div>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
