import { Phone, MessageCircle, PhoneOff, CheckCircle } from 'lucide-react';
import { RecentAction } from '@/hooks/useDashboardData';

const actionIcons = {
  ligacao_realizada: { icon: Phone, color: 'text-status-active', bg: 'bg-status-active/10' },
  tentativa_ligacao: { icon: PhoneOff, color: 'text-muted-foreground', bg: 'bg-muted' },
  whatsapp_com_resposta: { icon: MessageCircle, color: 'text-status-prospect', bg: 'bg-status-prospect/10' },
  whatsapp_sem_resposta: { icon: MessageCircle, color: 'text-muted-foreground', bg: 'bg-muted' },
};

const actionLabels: Record<string, string> = {
  ligacao_realizada: 'Ligação realizada',
  tentativa_ligacao: 'Tentativa de ligação',
  whatsapp_com_resposta: 'WhatsApp respondido',
  whatsapp_sem_resposta: 'WhatsApp enviado',
};

interface RecentActivityProps {
  actions: RecentAction[];
}

export function RecentActivity({ actions }: RecentActivityProps) {
  if (actions.length === 0) {
    return (
      <div className="text-center py-4 text-muted-foreground text-sm">
        Nenhuma atividade recente
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {actions.map((action) => {
        const config = actionIcons[action.type as keyof typeof actionIcons];
        const IconComponent = config?.icon || CheckCircle;
        
        return (
          <div key={action.id} className="flex items-start gap-3 p-3 rounded-lg hover:bg-muted/50 transition-colors">
            <div className={`p-2 rounded-lg ${config?.bg || 'bg-muted'}`}>
              <IconComponent size={16} className={config?.color || 'text-muted-foreground'} />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-foreground truncate">
                {action.clientName}
              </p>
              <p className="text-xs text-muted-foreground">
                {actionLabels[action.type] || action.type} • {action.userName || 'Vendedor'}
              </p>
              {action.observation && (
                <p className="text-xs text-muted-foreground mt-1 italic">
                  "{action.observation}"
                </p>
              )}
            </div>
            <span className="text-xs text-muted-foreground whitespace-nowrap">
              {new Date(action.date).toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' })}
            </span>
          </div>
        );
      })}
    </div>
  );
}
