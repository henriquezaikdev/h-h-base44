import { Target, TrendingUp } from 'lucide-react';

export function GoalsSummary() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col items-center justify-center py-8 text-center">
        <div className="w-12 h-12 rounded-full bg-muted/50 flex items-center justify-center mb-4">
          <Target size={24} className="text-muted-foreground" />
        </div>
        <h4 className="text-sm font-medium text-foreground mb-1">Sem metas configuradas</h4>
        <p className="text-xs text-muted-foreground max-w-[200px]">
          As metas semanais aparecerão aqui quando forem configuradas.
        </p>
      </div>
    </div>
  );
}