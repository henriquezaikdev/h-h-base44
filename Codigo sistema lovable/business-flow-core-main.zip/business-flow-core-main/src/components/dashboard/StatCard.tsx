import { ReactNode } from 'react';
import { Link } from 'react-router-dom';

interface StatCardProps {
  value: number;
  label: string;
  icon?: ReactNode;
  variant?: 'default' | 'primary' | 'success' | 'warning' | 'muted';
  href?: string;
}

const variantStyles = {
  default: 'border-border',
  primary: 'border-primary/30 bg-accent',
  success: 'border-status-active/30 bg-[hsl(var(--status-active)/0.05)]',
  warning: 'border-hh-orange/30 bg-[hsl(var(--hh-orange)/0.05)]',
  muted: 'border-muted bg-muted/50',
};

const valueStyles = {
  default: 'text-foreground',
  primary: 'text-primary',
  success: 'text-status-active',
  warning: 'text-hh-orange',
  muted: 'text-muted-foreground',
};

export function StatCard({ value, label, icon, variant = 'default', href }: StatCardProps) {
  const content = (
    <div className={`stat-card ${variantStyles[variant]} animate-fade-in ${href ? 'cursor-pointer hover:scale-[1.02] transition-transform' : ''}`}>
      <div className="flex items-start justify-between">
        <div>
          <p className={`stat-value ${valueStyles[variant]}`}>{value}</p>
          <p className="stat-label">{label}</p>
        </div>
        {icon && (
          <div className="text-muted-foreground">{icon}</div>
        )}
      </div>
    </div>
  );

  if (href) {
    return <Link to={href}>{content}</Link>;
  }

  return content;
}
