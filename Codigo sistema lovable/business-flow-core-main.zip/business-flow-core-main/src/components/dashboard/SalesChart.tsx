import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { TrendingUp, Loader2 } from 'lucide-react';
import { startOfWeek, subWeeks, format } from 'date-fns';

interface WeeklyData {
  name: string;
  vendas: number;
}

interface SalesChartProps {
  sellerId?: string | null;
}

export function SalesChart({ sellerId }: SalesChartProps) {
  const [data, setData] = useState<WeeklyData[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchSalesData = useCallback(async () => {
    setLoading(true);
    try {
      const now = new Date();
      const weeks: WeeklyData[] = [];
      
      for (let i = 3; i >= 0; i--) {
        const weekStart = startOfWeek(subWeeks(now, i), { weekStartsOn: 1 });
        const weekEnd = startOfWeek(subWeeks(now, i - 1), { weekStartsOn: 1 });
        
        let ordersQuery = supabase
          .from('orders')
          .select('total, clients!inner(seller_id)')
          .eq('is_accountable', true)
          .gte('order_date', format(weekStart, 'yyyy-MM-dd'))
          .lt('order_date', format(weekEnd, 'yyyy-MM-dd'));
        
        if (sellerId) {
          ordersQuery = ordersQuery.eq('clients.seller_id', sellerId);
        }

        const { data: orders } = await ordersQuery;
        
        const total = orders?.reduce((sum, o) => sum + Number(o.total || 0), 0) || 0;
        
        weeks.push({
          name: `Sem ${4 - i}`,
          vendas: total,
        });
      }
      
      setData(weeks);
    } catch (error) {
      console.error('Error fetching sales data:', error);
    } finally {
      setLoading(false);
    }
  }, [sellerId]);

  useEffect(() => {
    fetchSalesData();
  }, [fetchSalesData]);

  if (loading) {
    return (
      <div className="h-[280px] w-full flex items-center justify-center">
        <Loader2 className="animate-spin h-6 w-6 text-primary" />
      </div>
    );
  }

  const hasData = data.some(d => d.vendas > 0);

  if (!hasData) {
    return (
      <div className="h-[280px] w-full flex flex-col items-center justify-center text-center">
        <div className="w-12 h-12 rounded-full bg-muted/50 flex items-center justify-center mb-4">
          <TrendingUp size={24} className="text-muted-foreground" />
        </div>
        <h4 className="text-sm font-medium text-foreground mb-1">Sem dados de vendas</h4>
        <p className="text-xs text-muted-foreground max-w-[200px]">
          Os dados de vendas aparecerão aqui quando houver pedidos registrados.
        </p>
      </div>
    );
  }

  return (
    <div className="h-[280px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
          <defs>
            <linearGradient id="colorVendas" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3} />
              <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
          <XAxis 
            dataKey="name" 
            axisLine={false} 
            tickLine={false}
            tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 12 }}
          />
          <YAxis 
            axisLine={false} 
            tickLine={false}
            tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 12 }}
            tickFormatter={(value) => `${(value / 1000).toFixed(0)}k`}
          />
          <Tooltip
            contentStyle={{
              backgroundColor: 'hsl(var(--card))',
              border: '1px solid hsl(var(--border))',
              borderRadius: '8px',
              boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
            }}
            formatter={(value: number) => [`R$ ${value.toLocaleString('pt-BR')}`, 'Vendas']}
            labelStyle={{ color: 'hsl(var(--foreground))' }}
          />
          <Area
            type="monotone"
            dataKey="vendas"
            stroke="hsl(var(--primary))"
            strokeWidth={3}
            fillOpacity={1}
            fill="url(#colorVendas)"
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}