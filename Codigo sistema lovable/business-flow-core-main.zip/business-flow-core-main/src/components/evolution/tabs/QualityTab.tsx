import { useState } from 'react';
import { motion } from 'framer-motion';
import { CheckCircle2, Target, TrendingUp, AlertCircle, Trash2, ExternalLink } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { SellerMetrics } from '@/hooks/useSellerMetrics';
import { useDeletedTasksCount } from '@/hooks/useDeletedTasksCount';
import { DeletedTasksModal } from '@/components/evolution/DeletedTasksModal';
import { cn } from '@/lib/utils';

interface QualityTabProps {
  metrics: SellerMetrics | null;
  qualityRanking: SellerMetrics[];
  sellerRank: number;
  isAdmin: boolean;
  selectedSellerName: string;
  periodLabel?: string;
  sellerId?: string | null;
  month?: number;
  year?: number;
}

export function QualityTab({ 
  metrics, 
  qualityRanking, 
  sellerRank, 
  isAdmin,
  selectedSellerName,
  periodLabel = 'este mês',
  sellerId = null,
  month = new Date().getMonth() + 1,
  year = new Date().getFullYear()
}: QualityTabProps) {
  const [showDeletedModal, setShowDeletedModal] = useState(false);
  
  // Buscar contagem de tarefas excluídas
  const { count: deletedTasksCount, loading: loadingDeleted } = useDeletedTasksCount(
    sellerId,
    month,
    year
  );

  if (!metrics) {
    return (
      <div className="text-center py-12 text-muted-foreground">
        Nenhum dado de qualidade disponível
      </div>
    );
  }

  const totalTarefas = metrics.tarefas_concluidas + metrics.tarefas_pendentes;
  
  // Calcular taxa de execução ajustada (exclusões prejudicam)
  // Cada exclusão conta como 0.5 tarefa não cumprida no denominador
  const totalAjustado = totalTarefas + (deletedTasksCount * 0.5);
  const taxaExecucaoAjustada = totalAjustado > 0 
    ? Math.max(0, (metrics.tarefas_concluidas / totalAjustado) * 100)
    : 0;
  
  const execucaoStatus = taxaExecucaoAjustada >= 80 ? 'excellent' :
                         taxaExecucaoAjustada >= 60 ? 'good' :
                         taxaExecucaoAjustada >= 40 ? 'warning' : 'danger';

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      {/* Main Quality Card */}
      <Card className="overflow-hidden">
        <div className={cn(
          "h-2",
          execucaoStatus === 'excellent' && "bg-green-500",
          execucaoStatus === 'good' && "bg-blue-500",
          execucaoStatus === 'warning' && "bg-amber-500",
          execucaoStatus === 'danger' && "bg-red-500"
        )} />
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-lg font-semibold">Taxa de Execução</h3>
              <p className="text-sm text-muted-foreground">
                {metrics.tarefas_concluidas} de {totalTarefas} tarefas concluídas
                {deletedTasksCount > 0 && (
                  <span className="text-red-500 ml-1">
                    ({deletedTasksCount} excluída{deletedTasksCount > 1 ? 's' : ''})
                  </span>
                )}
              </p>
            </div>
            <div className="text-right">
              <p className={cn(
                "text-4xl font-bold",
                execucaoStatus === 'excellent' && "text-green-600",
                execucaoStatus === 'good' && "text-blue-600",
                execucaoStatus === 'warning' && "text-amber-600",
                execucaoStatus === 'danger' && "text-red-600"
              )}>
                {taxaExecucaoAjustada.toFixed(0)}%
              </p>
              <Badge variant="outline" className={cn(
                execucaoStatus === 'excellent' && "bg-green-500/10 text-green-600 border-green-500/20",
                execucaoStatus === 'good' && "bg-blue-500/10 text-blue-600 border-blue-500/20",
                execucaoStatus === 'warning' && "bg-amber-500/10 text-amber-600 border-amber-500/20",
                execucaoStatus === 'danger' && "bg-red-500/10 text-red-600 border-red-500/20"
              )}>
                {execucaoStatus === 'excellent' && 'Excelente'}
                {execucaoStatus === 'good' && 'Bom'}
                {execucaoStatus === 'warning' && 'Atenção'}
                {execucaoStatus === 'danger' && 'Crítico'}
              </Badge>
            </div>
          </div>
          <Progress value={taxaExecucaoAjustada} className="h-3" />
        </CardContent>
      </Card>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-green-500/10 to-green-600/5 border-green-500/20">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-green-500/20">
                <CheckCircle2 className="h-5 w-5 text-green-500" />
              </div>
              <div>
                <p className="text-2xl font-bold text-green-600">{metrics.tarefas_concluidas}</p>
                <p className="text-xs text-muted-foreground">Tarefas Concluídas</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-amber-500/10 to-amber-600/5 border-amber-500/20">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-amber-500/20">
                <Target className="h-5 w-5 text-amber-500" />
              </div>
              <div>
                <p className="text-2xl font-bold text-amber-600">{metrics.tarefas_pendentes}</p>
                <p className="text-xs text-muted-foreground">Tarefas Pendentes</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Card de Tarefas Excluídas */}
        <Card className="bg-gradient-to-br from-red-500/10 to-red-600/5 border-red-500/20">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-red-500/20">
                  <Trash2 className="h-5 w-5 text-red-500" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-red-600">
                    {loadingDeleted ? '...' : deletedTasksCount}
                  </p>
                  <p className="text-xs text-muted-foreground">Tarefas Excluídas</p>
                </div>
              </div>
              {deletedTasksCount > 0 && (
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8"
                  onClick={() => setShowDeletedModal(true)}
                >
                  <ExternalLink className="h-4 w-4" />
                </Button>
              )}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-primary/10 to-primary/5 border-primary/20">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-primary/20">
                <TrendingUp className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold text-primary">{sellerRank}º</p>
                <p className="text-xs text-muted-foreground">Posição Ranking</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Info Card */}
      <Card className="bg-muted/30 border-dashed">
        <CardContent className="p-4 flex items-start gap-3">
          <AlertCircle className="h-5 w-5 text-muted-foreground mt-0.5" />
          <div className="text-sm text-muted-foreground">
            <p className="font-medium text-foreground mb-1">Sobre a Taxa de Execução</p>
            <p>
              A taxa de execução mede a consistência na conclusão de tarefas. 
              Uma taxa alta indica disciplina e organização.
              <strong className="text-red-600"> Tarefas excluídas prejudicam este indicador</strong>, 
              por isso é importante cumprir as tarefas agendadas ao invés de excluí-las.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Ranking List (Admin only) */}
      {isAdmin && qualityRanking.length > 0 && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Ranking de Qualidade/Execução</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {qualityRanking.slice(0, 10).map((seller, index) => (
              <div
                key={seller.seller_id}
                className={cn(
                  "flex items-center justify-between p-3 rounded-lg",
                  seller.seller_id === metrics.seller_id
                    ? "bg-primary/10 border border-primary/20"
                    : "bg-muted/30"
                )}
              >
                <div className="flex items-center gap-3">
                  <div className={cn(
                    "w-8 h-8 rounded-lg flex items-center justify-center font-bold text-sm",
                    index === 0 && "bg-amber-500 text-white",
                    index === 1 && "bg-slate-400 text-white",
                    index === 2 && "bg-orange-500 text-white",
                    index > 2 && "bg-muted text-muted-foreground"
                  )}>
                    {index + 1}º
                  </div>
                  <span className="font-medium">{seller.seller_name}</span>
                </div>
                <div className="flex items-center gap-4">
                  <span className="text-sm text-muted-foreground">
                    {seller.tarefas_concluidas}/{seller.tarefas_concluidas + seller.tarefas_pendentes} tarefas
                  </span>
                  <Badge variant="secondary" className={cn(
                    seller.perc_tarefas_concluidas >= 80 && "bg-green-500/20 text-green-600",
                    seller.perc_tarefas_concluidas >= 60 && seller.perc_tarefas_concluidas < 80 && "bg-blue-500/20 text-blue-600",
                    seller.perc_tarefas_concluidas < 60 && "bg-amber-500/20 text-amber-600"
                  )}>
                    {seller.perc_tarefas_concluidas.toFixed(0)}%
                  </Badge>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Modal de Tarefas Excluídas */}
      <DeletedTasksModal
        open={showDeletedModal}
        onOpenChange={setShowDeletedModal}
        sellerId={sellerId}
        month={month}
        year={year}
      />
    </motion.div>
  );
}
