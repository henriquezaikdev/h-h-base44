import { useState } from 'react';
import { motion } from 'framer-motion';
import { FileText, CheckCircle, Lock, Shield, Loader2, BookOpen, TrendingUp, TrendingDown, AlertTriangle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Checkbox } from '@/components/ui/checkbox';
import { toast } from 'sonner';
import { usePolicyAcceptance } from '@/hooks/usePolicyAcceptance';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export function RulesTab() {
  const {
    activePolicy,
    acceptance,
    hasAcceptedActivePolicy,
    loading,
    acceptPolicy,
    isAccepting,
  } = usePolicyAcceptance();

  const [hasRead, setHasRead] = useState(false);

  const handleAccept = async () => {
    try {
      await acceptPolicy();
      toast.success('Política aceita com sucesso!');
    } catch {
      toast.error('Erro ao registrar aceite. Tente novamente.');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-16">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      {/* Banner if not accepted */}
      {activePolicy && !hasAcceptedActivePolicy && (
        <Alert className="border-amber-500/50 bg-amber-500/10 text-amber-700">
          <Lock className="h-4 w-4" />
          <AlertTitle>Aceite pendente</AlertTitle>
          <AlertDescription>
            Você pode trabalhar normalmente, mas <strong>não participa de campanhas e bônus</strong> até aceitar a política comercial vigente.
          </AlertDescription>
        </Alert>
      )}

      {/* Accepted confirmation */}
      {hasAcceptedActivePolicy && acceptance && (
        <Alert className="border-emerald-500/50 bg-emerald-500/10 text-emerald-700">
          <CheckCircle className="h-4 w-4" />
          <AlertTitle>Política aceita</AlertTitle>
          <AlertDescription>
            Aceita em {format(new Date(acceptance.accepted_at), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}.
            Você está apto a participar de campanhas e bônus.
          </AlertDescription>
        </Alert>
      )}

      {/* No active policy */}
      {!activePolicy && (
        <Card className="border-dashed border-2 border-muted-foreground/20">
          <CardContent className="py-16 text-center space-y-4">
            <motion.div
              initial={{ scale: 0.8 }}
              animate={{ scale: 1 }}
              transition={{ type: 'spring', stiffness: 200 }}
              className="w-16 h-16 mx-auto rounded-2xl bg-primary/10 flex items-center justify-center"
            >
              <FileText className="h-8 w-8 text-primary/50" />
            </motion.div>
            <div>
              <h3 className="text-lg font-semibold">Nenhuma política vigente</h3>
              <p className="text-sm text-muted-foreground mt-1">
                A gestão ainda não publicou uma política comercial ativa.
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Regras do Jogo */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <BookOpen className="h-5 w-5 text-primary" />
            Regras do Jogo
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 text-sm text-muted-foreground">
          {/* Subida */}
          <div className="space-y-1">
            <p className="font-semibold text-foreground flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-emerald-500" />
              Como subir de nível (Ovo → Pena → Águia)
            </p>
            <p>Bater <strong>2 meses consecutivos</strong> todas as 3 metas:</p>
            <ul className="list-disc pl-6 space-y-0.5">
              <li>Meta mínima de <strong>Ligações</strong></li>
              <li>Meta mínima de <strong>WhatsApp</strong></li>
              <li>Meta de <strong>Vendas</strong> (R$)</li>
            </ul>
            <p className="text-xs">No fechamento do 2º mês consecutivo, a promoção é automática.</p>
          </div>

          <Separator />

          {/* Queda */}
          <div className="space-y-1">
            <p className="font-semibold text-foreground flex items-center gap-2">
              <TrendingDown className="h-4 w-4 text-red-500" />
              Como cai de nível (Pena → Ovo / Águia → Pena)
            </p>
            <p>Só cai se ocorrer <strong>por 2 meses consecutivos</strong> uma destas situações:</p>
            <ul className="list-disc pl-6 space-y-0.5">
              <li><strong>Vendas abaixo de 80%</strong> da meta por 2 meses seguidos</li>
              <li>Falhar metas mínimas de <strong>Ligações E WhatsApp</strong> (ambas) por 2 meses seguidos</li>
              <li>Estourar <strong>erros críticos (&gt;3)</strong> por 2 meses consecutivos</li>
            </ul>
            <p className="text-xs">Se estiver em fase ruim de vendas (&lt;80%), pode manter o nível mantendo disciplina de ligações + whatsapp.</p>
          </div>

          <Separator />

          {/* Erros */}
          <div className="space-y-1">
            <p className="font-semibold text-foreground flex items-center gap-2">
              <AlertTriangle className="h-4 w-4 text-amber-500" />
              Erros Críticos (limite: 3/mês)
            </p>
            <p><strong>Exemplos:</strong></p>
            <ul className="list-disc pl-6 space-y-0.5">
              <li>Cliente pediu X e o vendedor enviou Y (produto/itens errados)</li>
              <li>Cliente pediu retorno e o vendedor não retornou/não avisou</li>
              <li>Falha grave de atendimento que gere retrabalho, perda ou reclamação</li>
            </ul>
            <p className="mt-1"><strong>Consequências:</strong></p>
            <ul className="list-disc pl-6 space-y-0.5">
              <li>Mais de 3 erros no mês → <strong>perde bônus do nível</strong> (comissão base mantida)</li>
              <li>Se repetir no mês seguinte (&gt;3 em 2 meses) → bloqueia evolução e conta para queda</li>
            </ul>
          </div>

          <Separator />

          {/* Modelo B */}
          <div className="space-y-1">
            <p className="font-semibold text-foreground flex items-center gap-2">
              <Lock className="h-4 w-4 text-blue-500" />
              Modelo B (Política Comercial)
            </p>
            <p>Você pode trabalhar normalmente. Mas <strong>bônus e premiações ficam travados</strong> até aceitar a política comercial vigente.</p>
            <p className="text-xs">Ao aceitar, volta a participar de campanhas e bônus do seu nível.</p>
          </div>
        </CardContent>
      </Card>

      {/* Active Policy Content */}
      {activePolicy && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Shield className="h-5 w-5 text-primary" />
                <span>{activePolicy.title}</span>
              </div>
              <Badge variant="outline" className="text-xs">
                v{activePolicy.version}
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Policy content */}
            <div
              className="prose prose-sm dark:prose-invert max-w-none p-4 rounded-xl bg-muted/30 border border-border/50 max-h-[500px] overflow-y-auto"
              dangerouslySetInnerHTML={{ __html: activePolicy.content_html }}
            />

            {/* Acceptance section */}
            {!hasAcceptedActivePolicy && (
              <div className="pt-4 border-t border-border/50 space-y-4">
                <div className="flex items-start gap-3">
                  <Checkbox
                    id="read-policy"
                    checked={hasRead}
                    onCheckedChange={(v) => setHasRead(v === true)}
                  />
                  <label htmlFor="read-policy" className="text-sm text-muted-foreground cursor-pointer leading-relaxed">
                    Declaro que li e compreendi a Política Comercial vigente ({activePolicy.title} v{activePolicy.version}).
                  </label>
                </div>
                <Button
                  onClick={handleAccept}
                  disabled={!hasRead || isAccepting}
                  className="w-full gap-2"
                  size="lg"
                >
                  {isAccepting ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <CheckCircle className="h-4 w-4" />
                  )}
                  Li e Concordo
                </Button>
                <p className="text-xs text-muted-foreground text-center">
                  Seu aceite será registrado com data, hora e navegador.
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </motion.div>
  );
}
