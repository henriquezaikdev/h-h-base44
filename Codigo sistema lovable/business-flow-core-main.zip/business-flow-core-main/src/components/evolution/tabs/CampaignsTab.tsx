import { motion } from 'framer-motion';
import { Trophy } from 'lucide-react';
import { CampanhaSellerView } from '@/components/campanhas/CampanhaSellerView';

interface CampaignsTabProps {
  sellerId: string;
  sellerName: string;
}

export function CampaignsTab({ sellerId, sellerName }: CampaignsTabProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      <CampanhaSellerView sellerId={sellerId} />
    </motion.div>
  );
}
