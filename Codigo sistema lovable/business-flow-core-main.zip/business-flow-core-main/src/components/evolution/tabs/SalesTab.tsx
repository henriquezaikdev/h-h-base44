import { motion } from 'framer-motion';
import { TrendingUp, ShoppingCart, Receipt, Award } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { SellerMetrics } from '@/hooks/useSellerMetrics';
import { cn } from '@/lib/utils';

interface SalesTabProps {
  metrics: SellerMetrics | null;
  salesRanking: SellerMetrics[];
  sellerRank: number;
  isAdmin: boolean;
  selectedSellerName: string;
  salesTarget?: number;
  periodLabel?: string;
}

function formatCurrency(value: number): string {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  }).format(value);
}

export function SalesTab({ 
  metrics, 
  salesRanking, 
  sellerRank, 
  isAdmin,
  selectedSellerName,
  salesTarget = 30000,
  periodLabel = 'este mês'
}: SalesTabProps) {
  if (!metrics) {
    return (
      <div className="text-center py-12 text-muted-foreground">
        Nenhum dado de vendas disponível
      </div>
    );
  }

  const progressPercent = salesTarget > 0 ? (metrics.faturamento_total / salesTarget) * 100 : 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      {/* Main Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-gradient-to-br from-emerald-500/10 to-emerald-600/5 border-emerald-500/20">
          <CardContent className="p-6">
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2 rounded-lg bg-emerald-500/20">
                <TrendingUp className="h-6 w-6 text-emerald-500" />
              </div>
              <p className="text-sm text-muted-foreground">Faturamento Total</p>
            </div>
            <p className="text-3xl font-bold text-emerald-600">
              {formatCurrency(metrics.faturamento_total)}
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              {progressPercent.toFixed(0)}% da meta de {formatCurrency(salesTarget)}
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-blue-500/10 to-blue-600/5 border-blue-500/20">
          <CardContent className="p-6">
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2 rounded-lg bg-blue-500/20">
                <ShoppingCart className="h-6 w-6 text-blue-500" />
              </div>
              <p className="text-sm text-muted-foreground">Pedidos</p>
            </div>
            <p className="text-3xl font-bold text-blue-600">
              {metrics.total_pedidos}
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              pedidos no período
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-500/10 to-purple-600/5 border-purple-500/20">
          <CardContent className="p-6">
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2 rounded-lg bg-purple-500/20">
                <Receipt className="h-6 w-6 text-purple-500" />
              </div>
              <p className="text-sm text-muted-foreground">Ticket Médio</p>
            </div>
            <p className="text-3xl font-bold text-purple-600">
              {formatCurrency(metrics.ticket_medio)}
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              por pedido
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Position Card */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Award className="h-5 w-5 text-primary" />
              <span>Posição no Ranking de Vendas</span>
            </div>
            <Badge 
              variant="outline" 
              className={cn(
                "text-lg px-3 py-1",
                sellerRank === 1 && "bg-amber-500/20 text-amber-600 border-amber-500",
                sellerRank === 2 && "bg-slate-400/20 text-slate-600 border-slate-400",
                sellerRank === 3 && "bg-orange-500/20 text-orange-600 border-orange-500"
              )}
            >
              {sellerRank}º lugar
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">
            {selectedSellerName} está em <strong>{sellerRank}º lugar</strong> no ranking de vendas deste mês
            com <strong>{formatCurrency(metrics.faturamento_total)}</strong> em {metrics.total_pedidos} pedidos.
          </p>
        </CardContent>
      </Card>

      {/* Ranking List (Admin only) */}
      {isAdmin && salesRanking.length > 0 && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Ranking de Vendas</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {salesRanking.slice(0, 10).map((seller, index) => (
              <div
                key={seller.seller_id}
                className={cn(
                  "flex items-center justify-between p-3 rounded-lg",
                  seller.seller_id === metrics.seller_id
                    ? "bg-primary/10 border border-primary/20"
                    : "bg-muted/30"
                )}
              >
                <div className="flex items-center gap-3">
                  <div className={cn(
                    "w-8 h-8 rounded-lg flex items-center justify-center font-bold text-sm",
                    index === 0 && "bg-amber-500 text-white",
                    index === 1 && "bg-slate-400 text-white",
                    index === 2 && "bg-orange-500 text-white",
                    index > 2 && "bg-muted text-muted-foreground"
                  )}>
                    {index + 1}º
                  </div>
                  <span className="font-medium">{seller.seller_name}</span>
                </div>
                <div className="flex items-center gap-4">
                  <span className="text-sm text-muted-foreground">
                    {seller.total_pedidos} pedidos
                  </span>
                  <Badge variant="secondary" className="bg-emerald-500/20 text-emerald-600">
                    {formatCurrency(seller.faturamento_total)}
                  </Badge>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}
    </motion.div>
  );
}
