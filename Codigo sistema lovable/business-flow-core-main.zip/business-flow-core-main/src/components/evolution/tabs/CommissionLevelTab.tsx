import { motion } from 'framer-motion';
import { Egg, Feather, Bird, AlertTriangle, TrendingDown, ShieldAlert, Award, Calculator } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { cn } from '@/lib/utils';
import { CommissionCalculator } from '@/components/evolution/CommissionCalculator';
import { CommissionRulesExplainer } from '@/components/evolution/CommissionRulesExplainer';
import { ErrorsTracker } from '@/components/evolution/ErrorsTracker';


interface CommissionLevelTabProps {
  level: any;
  errors: any[];
  salesByMargin: any[];
  sellerId: string;
  sellerName: string;
  month: number;
  year: number;
  categoryEligibility: any[];
  isAdmin: boolean;
  onRefetch: () => void;
  monthlyTarget?: number;
  currentMonthSales?: number;
}

const levelDetails = {
  ovo: {
    icon: Egg,
    label: 'Ovo (Aprendiz)',
    color: 'text-amber-500',
    bg: 'bg-amber-500/10',
    border: 'border-amber-500/30',
    bonus: 0,
    description: 'Fase de aprendizado. Sem bônus adicional de comissão. Foco em disciplina e construção de carteira.',
    criteria: [
      'Bater meta de vendas por 2 meses consecutivos',
      'Manter disciplina de ligações/WhatsApp',
      'Máximo 3 erros por mês',
    ],
    nextLevel: 'Pena',
  },
  pena: {
    icon: Feather,
    label: 'Pena (Intermediário)',
    color: 'text-blue-500',
    bg: 'bg-blue-500/10',
    border: 'border-blue-500/30',
    bonus: 0.5,
    description: 'Vendedor em consolidação. Bônus de +0,5% sobre comissão base em categorias elegíveis.',
    criteria: [
      'Bater meta de vendas por 2 meses consecutivos para subir a Águia',
      'Manter margem média ≥40% nas categorias',
      'Máximo 3 erros por mês para manter bônus',
    ],
    nextLevel: 'Águia',
  },
  aguia: {
    icon: Bird,
    label: 'Águia (Consolidado)',
    color: 'text-emerald-500',
    bg: 'bg-emerald-500/10',
    border: 'border-emerald-500/30',
    bonus: 1.0,
    description: 'Alta performance. Bônus de +1% sobre comissão base em categorias elegíveis.',
    criteria: [
      'Manter meta de vendas mensal',
      'Margem média ≥40% para bônus por categoria',
      'Máximo 3 erros por mês',
    ],
    nextLevel: null,
  },
};

export function CommissionLevelTab({
  level,
  errors,
  salesByMargin,
  sellerId,
  sellerName,
  month,
  year,
  categoryEligibility,
  isAdmin,
  onRefetch,
  monthlyTarget = 0,
  currentMonthSales = 0,
}: CommissionLevelTabProps) {
  if (!level) return null;

  const config = levelDetails[level.current_level as keyof typeof levelDetails];
  const Icon = config.icon;
  const hasLostBonus = errors.length >= 4;
  const consecutiveMet = level.consecutive_months_met || 0;
  const consecutiveMissed = level.consecutive_months_missed || 0;
  const metaPercentage = monthlyTarget > 0 ? (currentMonthSales / monthlyTarget) * 100 : 0;
  const isSpecialRule = metaPercentage >= 130;

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      {/* Current Level Card */}
      <Card className={cn("border-2", config.border)}>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={cn("p-3 rounded-xl", config.bg)}>
                <Icon className={cn("h-7 w-7", config.color)} />
              </div>
              <div>
                <h3 className="text-lg font-bold">{config.label}</h3>
                <p className="text-sm text-muted-foreground">Nível Atual</p>
              </div>
            </div>
            <Badge className={cn("text-lg px-4 py-2", config.bg, config.color, config.border)}>
              {config.bonus > 0 ? `+${config.bonus}%` : 'Base'}
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-muted-foreground">{config.description}</p>

          {/* Progression info */}
          {config.nextLevel && (
            <div className="p-4 rounded-xl bg-muted/30 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Progresso para {config.nextLevel}</span>
                <span className="text-sm font-bold">{consecutiveMet}/2 meses</span>
              </div>
              <Progress value={(consecutiveMet / 2) * 100} className="h-3" />
              <p className="text-xs text-muted-foreground">
                Bata a meta por 2 meses consecutivos para ser promovido.
              </p>
            </div>
          )}

          {/* Criteria */}
          <div className="space-y-2">
            <p className="text-sm font-semibold">Critérios do Nível</p>
            {config.criteria.map((c, i) => (
              <div key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                <span className="mt-0.5">•</span>
                <span>{c}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Bonus by Level - All 3 */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <Award className="h-5 w-5 text-primary" />
            Bônus de Comissão por Nível
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {Object.entries(levelDetails).map(([key, cfg]) => {
            const LvlIcon = cfg.icon;
            const isCurrent = key === level.current_level;
            return (
              <div key={key} className={cn(
                "p-3 rounded-lg transition-all",
                isCurrent ? cn(cfg.bg, "border", cfg.border) : "bg-muted/30 opacity-60"
              )}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <LvlIcon className={cn("h-4 w-4", cfg.color)} />
                    <span className="font-medium text-sm">{cfg.label}</span>
                    {isCurrent && <Badge variant="secondary" className="text-xs">Atual</Badge>}
                  </div>
                  <span className="text-sm font-bold">{cfg.bonus > 0 ? `+${cfg.bonus}%` : 'Sem bônus'}</span>
                </div>
              </div>
            );
          })}
        </CardContent>
      </Card>

      {/* Commission Rules Explainer */}
      <CommissionRulesExplainer
        sellerLevel={level.current_level}
        categoryEligibility={categoryEligibility}
        hasLostBonus={hasLostBonus}
        month={month}
        year={year}
        isSpecialRule={isSpecialRule}
        metaPercentage={metaPercentage}
      />

      {/* Commission Calculator */}
      <CommissionCalculator
        salesByMargin={salesByMargin}
        bonusPercentage={level.commission_bonus}
        sellerLevel={level.current_level}
        hasLostBonus={hasLostBonus}
        sellerId={sellerId}
        sellerName={sellerName}
        month={month}
        year={year}
        categoryEligibility={categoryEligibility}
        monthlyTarget={monthlyTarget}
        currentMonthSales={currentMonthSales}
      />

      {/* Alerts */}
      <Card className="border-red-500/20 bg-red-500/5">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base text-red-600">
            <ShieldAlert className="h-5 w-5" />
            Alertas Importantes
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-start gap-3 p-3 rounded-lg bg-red-500/10">
            <AlertTriangle className="h-5 w-5 text-red-500 mt-0.5 shrink-0" />
            <div>
              <p className="text-sm font-semibold text-red-600">Margem 0% = Comissão 0%</p>
              <p className="text-xs text-red-500/80">Pedidos com margem bruta ≤0% não geram comissão.</p>
            </div>
          </div>
          <div className="flex items-start gap-3 p-3 rounded-lg bg-amber-500/10">
            <TrendingDown className="h-5 w-5 text-amber-500 mt-0.5 shrink-0" />
            <div>
              <p className="text-sm font-semibold text-amber-600">Rebaixamento</p>
              <p className="text-xs text-amber-500/80">
                Vendas abaixo de 80% da meta por 2 meses consecutivos, OU falha em ligações + WhatsApp por 2 meses, OU erros críticos &gt;3 por 2 meses → rebaixamento de nível.
              </p>
            </div>
          </div>
          {hasLostBonus && (
            <div className="flex items-start gap-3 p-3 rounded-lg bg-red-500/10 border border-red-500/20">
              <AlertTriangle className="h-5 w-5 text-red-600 mt-0.5 shrink-0" />
              <div>
                <p className="text-sm font-semibold text-red-600">Bônus Bloqueado</p>
                <p className="text-xs text-red-500/80">{errors.length} erros este mês. Bônus de nível perdido.</p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Errors Tracker */}
      <ErrorsTracker
        sellerId={sellerId}
        errors={errors}
        maxErrors={3}
        onErrorAdded={onRefetch}
        onErrorDeleted={onRefetch}
        isAdmin={isAdmin}
      />
    </motion.div>
  );
}
