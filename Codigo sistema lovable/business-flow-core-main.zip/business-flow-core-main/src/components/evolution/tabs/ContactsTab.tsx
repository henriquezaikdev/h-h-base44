import { motion } from 'framer-motion';
import { CheckCircle2, XCircle, Users, TrendingUp, MessageCircle, Phone } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { ContactStats } from '@/hooks/useSellerMetrics';
import { cn } from '@/lib/utils';

interface ContactsTabProps {
  contactStats: ContactStats | null;
  selectedSellerName: string;
  periodLabel?: string;
}

export function ContactsTab({ 
  contactStats, 
  selectedSellerName,
  periodLabel = 'este mês'
}: ContactsTabProps) {
  if (!contactStats) {
    return (
      <div className="text-center py-12 text-muted-foreground">
        Nenhum dado de contatos disponível
      </div>
    );
  }

  const rateStatus = contactStats.effectiveRate >= 70 ? 'excellent' :
                     contactStats.effectiveRate >= 40 ? 'good' : 'warning';

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      {/* Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-green-500/10 to-green-600/5 border-green-500/20">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <CheckCircle2 className="h-4 w-4 text-green-500" />
              <span className="text-xs text-muted-foreground">Contatos Efetivos</span>
            </div>
            <p className="text-3xl font-bold text-green-600">{contactStats.totalEffective}</p>
            <p className="text-xs text-muted-foreground mt-1">
              {contactStats.whatsappEffective} WhatsApp • {contactStats.callEffective} Ligações
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-amber-500/10 to-amber-600/5 border-amber-500/20">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <XCircle className="h-4 w-4 text-amber-500" />
              <span className="text-xs text-muted-foreground">Tentativas Sem Resposta</span>
            </div>
            <p className="text-3xl font-bold text-amber-600">{contactStats.totalAttempts}</p>
            <p className="text-xs text-muted-foreground mt-1">
              {contactStats.whatsappAttempts} WhatsApp • {contactStats.callAttempts} Ligações
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-primary/10 to-primary/5 border-primary/20">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <Users className="h-4 w-4 text-primary" />
              <span className="text-xs text-muted-foreground">Total de Contatos</span>
            </div>
            <p className="text-3xl font-bold text-primary">{contactStats.totalContacts}</p>
            <p className="text-xs text-muted-foreground mt-1">
              Efetivos + Tentativas
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-blue-500/10 to-blue-600/5 border-blue-500/20">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <TrendingUp className="h-4 w-4 text-blue-500" />
              <span className="text-xs text-muted-foreground">Taxa de Sucesso</span>
            </div>
            <p className={cn(
              "text-3xl font-bold",
              rateStatus === 'excellent' && "text-green-600",
              rateStatus === 'good' && "text-blue-600",
              rateStatus === 'warning' && "text-amber-600"
            )}>
              {contactStats.effectiveRate.toFixed(1)}%
            </p>
            <Progress value={contactStats.effectiveRate} className="mt-2 h-2" />
          </CardContent>
        </Card>
      </div>

      {/* Detailed Breakdown */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">Detalhamento por Canal - {selectedSellerName}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* WhatsApp */}
          <div className="p-4 rounded-lg bg-muted/30 border border-border">
            <div className="flex items-center gap-2 mb-3">
              <MessageCircle className="h-5 w-5 text-green-500" />
              <span className="font-medium">WhatsApp</span>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="flex items-center gap-2 p-2 rounded-lg bg-green-500/10 border border-green-500/20">
                <CheckCircle2 className="h-4 w-4 text-green-500" />
                <div>
                  <p className="text-xs text-muted-foreground">Efetivos</p>
                  <p className="font-semibold text-green-600">{contactStats.whatsappEffective}</p>
                </div>
              </div>
              <div className="flex items-center gap-2 p-2 rounded-lg bg-amber-500/10 border border-amber-500/20">
                <XCircle className="h-4 w-4 text-amber-500" />
                <div>
                  <p className="text-xs text-muted-foreground">Tentativas</p>
                  <p className="font-semibold text-amber-600">{contactStats.whatsappAttempts}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Ligações */}
          <div className="p-4 rounded-lg bg-muted/30 border border-border">
            <div className="flex items-center gap-2 mb-3">
              <Phone className="h-5 w-5 text-blue-500" />
              <span className="font-medium">Ligações</span>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="flex items-center gap-2 p-2 rounded-lg bg-green-500/10 border border-green-500/20">
                <CheckCircle2 className="h-4 w-4 text-green-500" />
                <div>
                  <p className="text-xs text-muted-foreground">Efetivas</p>
                  <p className="font-semibold text-green-600">{contactStats.callEffective}</p>
                </div>
              </div>
              <div className="flex items-center gap-2 p-2 rounded-lg bg-amber-500/10 border border-amber-500/20">
                <XCircle className="h-4 w-4 text-amber-500" />
                <div>
                  <p className="text-xs text-muted-foreground">Tentativas</p>
                  <p className="font-semibold text-amber-600">{contactStats.callAttempts}</p>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Status Card */}
      <Card className={cn(
        "border-2",
        rateStatus === 'excellent' && "border-green-500/30 bg-green-500/5",
        rateStatus === 'good' && "border-blue-500/30 bg-blue-500/5",
        rateStatus === 'warning' && "border-amber-500/30 bg-amber-500/5"
      )}>
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">Status da Taxa de Sucesso</p>
              <p className="text-sm text-muted-foreground">
                {rateStatus === 'excellent' && 'Excelente taxa de conversão de contatos!'}
                {rateStatus === 'good' && 'Taxa de conversão dentro do esperado.'}
                {rateStatus === 'warning' && 'Taxa de conversão abaixo do ideal. Foque em contatos mais qualificados.'}
              </p>
            </div>
            <Badge className={cn(
              rateStatus === 'excellent' && "bg-green-500",
              rateStatus === 'good' && "bg-blue-500",
              rateStatus === 'warning' && "bg-amber-500"
            )}>
              {rateStatus === 'excellent' && 'Excelente'}
              {rateStatus === 'good' && 'Bom'}
              {rateStatus === 'warning' && 'Atenção'}
            </Badge>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
