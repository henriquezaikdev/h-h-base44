import { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { Package, Star, TrendingUp, CheckCircle2 } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { format, startOfMonth, endOfMonth } from 'date-fns';
import { awardAdminXP, ADMIN_XP_TABLE } from '@/lib/adminXpUtils';
import { cn } from '@/lib/utils';
import { 
  CATEGORY_CONFIGS, 
  mapCategoryToKey, 
  getCategoryConfig,
  DEFAULT_GOALS_BY_PROFILE,
  getCategoryKeys 
} from '@/lib/categoryConfig';

interface CategoryGoal {
  category_key: string;
  meta_valor: number;
  realizado: number;
  stars_reward: number;
  margin: number;
  cost: number;
}

interface CategoriesTabProps {
  sellerId: string;
  selectedMonth: number;
  selectedYear: number;
  periodLabel?: string;
  sellerLevel?: 'ovo' | 'pena' | 'aguia';
}

export function CategoriesTab({ sellerId, selectedMonth, selectedYear, periodLabel, sellerLevel = 'ovo' }: CategoriesTabProps) {
  const [goals, setGoals] = useState<CategoryGoal[]>([]);
  const [salesByCategory, setSalesByCategory] = useState<Record<string, { revenue: number; cost: number }>>({});
  const [loading, setLoading] = useState(true);
  const [sellerCategory, setSellerCategory] = useState<string>('novato');

  useEffect(() => {
    if (sellerId) {
      fetchData();
    }
  }, [sellerId, selectedMonth, selectedYear]);

  const fetchData = async () => {
    setLoading(true);
    
    const competencia = `${selectedYear}-${String(selectedMonth).padStart(2, '0')}`;
    const monthStart = startOfMonth(new Date(selectedYear, selectedMonth - 1));
    const monthEnd = endOfMonth(new Date(selectedYear, selectedMonth - 1));

    try {
      // Buscar categoria do vendedor
      const { data: levelData } = await supabase
        .from('seller_levels')
        .select('seller_category')
        .eq('seller_id', sellerId)
        .maybeSingle();
      
      const category = levelData?.seller_category || 'novato';
      setSellerCategory(category);

      // Buscar metas configuradas
      const { data: goalsData } = await supabase
        .from('category_goals')
        .select('*')
        .eq('seller_id', sellerId)
        .eq('competencia', competencia);

      // Buscar vendas por categoria (através de order_items -> products -> categories)
      // FONTE ÚNICA: products.category_id -> categories.name
      // Inclui cost_subtotal para calcular margem
      const { data: ordersData } = await supabase
        .from('orders')
        .select(`
          id,
          total,
          order_items!inner (
            subtotal,
            cost_subtotal,
            product_id,
            is_deleted,
            products (
              category,
              category_id,
              categories:category_id (
                id,
                name
              )
            )
          )
        `)
        .eq('seller_id', sellerId)
        .gte('order_date', format(monthStart, 'yyyy-MM-dd'))
        .lte('order_date', format(monthEnd, 'yyyy-MM-dd'))
        .or('is_deleted.is.null,is_deleted.eq.false');

      // Agregar vendas e custos por categoria
      const salesMap: Record<string, { revenue: number; cost: number }> = {};
      let uncategorizedTotal = 0;
      
      ordersData?.forEach(order => {
        order.order_items?.forEach((item: any) => {
          // Ignorar itens deletados
          if (item.is_deleted) return;
          
          // PRIORIDADE 1: category_id -> categories.name (fonte oficial)
          const categoryFromId = item.products?.categories?.name;
          // PRIORIDADE 2: fallback para products.category (texto legado)
          const categoryFromText = item.products?.category;
          
          const categoryName = categoryFromId || categoryFromText || '';
          const categoryKey = mapCategoryToKey(categoryName);
          
          if (categoryKey) {
            if (!salesMap[categoryKey]) {
              salesMap[categoryKey] = { revenue: 0, cost: 0 };
            }
            salesMap[categoryKey].revenue += item.subtotal || 0;
            salesMap[categoryKey].cost += item.cost_subtotal || 0;
          } else if (item.subtotal > 0) {
            // Itens sem categoria válida - contabilizar separadamente
            uncategorizedTotal += item.subtotal || 0;
          }
        });
      });
      
      // Se houver vendas sem categoria, adicionar para debug
      if (uncategorizedTotal > 0) {
        console.warn(`[CategoriesTab] Vendas sem categoria: R$ ${uncategorizedTotal.toFixed(2)}`);
      }
      
      setSalesByCategory(salesMap);

      // Combinar metas com valores padrão
      const defaultGoals = DEFAULT_GOALS_BY_PROFILE[category] || DEFAULT_GOALS_BY_PROFILE.novato;
      const categoryKeys = getCategoryKeys();
      
      const combinedGoals: CategoryGoal[] = categoryKeys.map(key => {
        const config = getCategoryConfig(key);
        const configured = goalsData?.find(g => g.category_key === key);
        const defaultGoal = defaultGoals[key] || 0;
        const categoryData = salesMap[key] || { revenue: 0, cost: 0 };
        
        // Calcular margem: (receita - custo) / receita * 100
        const margin = categoryData.revenue > 0 
          ? ((categoryData.revenue - categoryData.cost) / categoryData.revenue) * 100 
          : 0;
        
        return {
          category_key: key,
          meta_valor: configured?.meta_valor || defaultGoal,
          realizado: categoryData.revenue,
          stars_reward: configured?.stars_reward || config?.defaultStars || 1,
          margin: Math.round(margin * 10) / 10,
          cost: categoryData.cost,
        };
      });
      
      setGoals(combinedGoals);

      // Auto-award 100 XP for each newly met category goal
      const metGoals = combinedGoals.filter(g => g.meta_valor > 0 && g.realizado >= g.meta_valor);
      if (metGoals.length > 0) {
        // Check which achievements already exist
        const { data: existingAchievements } = await supabase
          .from('category_achievements')
          .select('category_key')
          .eq('seller_id', sellerId)
          .eq('competencia', competencia);

        const existingKeys = new Set((existingAchievements || []).map(a => a.category_key));

        for (const goal of metGoals) {
          if (!existingKeys.has(goal.category_key)) {
            // Insert achievement record (idempotency guard)
            const { error: achError } = await supabase
              .from('category_achievements')
              .insert({
                seller_id: sellerId,
                competencia,
                category_key: goal.category_key,
                meta_valor: goal.meta_valor,
                realizado: goal.realizado,
                stars_awarded: goal.stars_reward,
              });

            if (!achError) {
              // Award 100 XP
              await awardAdminXP(
                sellerId,
                'CATEGORY_GOAL_MET',
                ADMIN_XP_TABLE.CATEGORY_GOAL_MET,
                undefined,
                { category_key: goal.category_key, competencia, realizado: goal.realizado, meta: goal.meta_valor }
              );
            }
          }
        }
      }
    } catch (error) {
      console.error('Error fetching category data:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
  };

  const totalMeta = goals.reduce((sum, g) => sum + g.meta_valor, 0);
  const totalRealizado = goals.reduce((sum, g) => sum + g.realizado, 0);
  const categoriesMet = goals.filter(g => g.realizado >= g.meta_valor).length;
  const potentialStars = goals
    .filter(g => g.realizado >= g.meta_valor)
    .reduce((sum, g) => sum + g.stars_reward, 0);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      {/* Header Summary */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <Package className="h-4 w-4 text-primary" />
              <span className="text-sm text-muted-foreground">Total Categorias</span>
            </div>
            <p className="text-xl font-bold">{formatCurrency(totalRealizado)}</p>
            <p className="text-xs text-muted-foreground">de {formatCurrency(totalMeta)}</p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <TrendingUp className="h-4 w-4 text-emerald-600" />
              <span className="text-sm text-muted-foreground">Progresso Geral</span>
            </div>
            <p className="text-xl font-bold">
              {totalMeta > 0 ? Math.round((totalRealizado / totalMeta) * 100) : 0}%
            </p>
            <Progress 
              value={totalMeta > 0 ? (totalRealizado / totalMeta) * 100 : 0} 
              className="h-1.5 mt-2" 
            />
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <CheckCircle2 className="h-4 w-4 text-blue-600" />
              <span className="text-sm text-muted-foreground">Metas Batidas</span>
            </div>
            <p className="text-xl font-bold">{categoriesMet}/{goals.length}</p>
            <p className="text-xs text-muted-foreground">categorias</p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <Star className="h-4 w-4 text-amber-500 fill-amber-500" />
              <span className="text-sm text-muted-foreground">Estrelas Conquistadas</span>
            </div>
            <p className="text-xl font-bold text-amber-600">{potentialStars}</p>
            <p className="text-xs text-muted-foreground">bronze</p>
          </CardContent>
        </Card>
      </div>

      {/* Category Cards */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center gap-2 text-base">
            <Package className="h-5 w-5 text-primary" />
            Metas por Categoria
            {periodLabel && (
              <span className="text-sm font-normal text-muted-foreground ml-2">
                • {periodLabel}
              </span>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {goals.map((goal) => {
            const config = getCategoryConfig(goal.category_key);
            if (!config) return null;
            
            const progress = goal.meta_valor > 0 
              ? Math.min(100, (goal.realizado / goal.meta_valor) * 100) 
              : 0;
            const isMet = goal.realizado >= goal.meta_valor;
            const hasBonus = isMet && goal.margin >= 40;
            
            return (
              <div 
                key={goal.category_key}
                className={cn(
                  "p-4 rounded-lg border transition-all",
                  isMet 
                    ? "bg-emerald-500/10 border-emerald-500/30" 
                    : "bg-muted/30 border-border/50"
                )}
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <span className="text-lg">{config.icon}</span>
                    <div>
                      <p className="font-medium text-sm">{config.label}</p>
                      <p className="text-xs text-muted-foreground">
                        {formatCurrency(goal.realizado)} / {formatCurrency(goal.meta_valor)}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {/* Margem de Lucro Badge */}
                    {goal.realizado > 0 && (
                      <Badge 
                        variant="outline" 
                        className={cn(
                          "text-xs font-mono",
                          goal.margin >= 50 ? "bg-emerald-500/10 text-emerald-600 border-emerald-500/30" :
                          goal.margin >= 40 ? "bg-blue-500/10 text-blue-600 border-blue-500/30" :
                          goal.margin >= 30 ? "bg-amber-500/10 text-amber-600 border-amber-500/30" :
                          "bg-red-500/10 text-red-600 border-red-500/30"
                        )}
                      >
                        {goal.margin.toFixed(1)}% margem
                      </Badge>
                    )}
                    {isMet ? (
                      <Badge className="bg-emerald-500/20 text-emerald-600 border-emerald-500/30">
                        <CheckCircle2 className="h-3 w-3 mr-1" />
                        Batida!
                      </Badge>
                    ) : (
                      <Badge variant="outline" className="text-muted-foreground">
                        {progress.toFixed(0)}%
                      </Badge>
                    )}
                    <div className="flex items-center gap-0.5">
                      {Array.from({ length: goal.stars_reward }).map((_, i) => (
                        <Star 
                          key={i}
                          className={cn(
                            "h-4 w-4",
                            isMet ? "text-amber-500 fill-amber-500" : "text-muted-foreground/30"
                          )}
                        />
                      ))}
                    </div>
                  </div>
                </div>
                <Progress 
                  value={progress} 
                  className={cn(
                    "h-2",
                    isMet ? "bg-emerald-200" : ""
                  )}
                />
                <div className="flex items-center justify-between mt-2">
                  {!isMet && goal.meta_valor > 0 ? (
                    <p className="text-xs text-muted-foreground">
                      Faltam {formatCurrency(goal.meta_valor - goal.realizado)} para bater a meta
                    </p>
                  ) : (
                    <div />
                  )}
                  {/* Indicador de bônus de comissão - Mostra valor do bônus por nível */}
                  {hasBonus && sellerLevel !== 'ovo' && (selectedYear > 2026 || (selectedYear === 2026 && selectedMonth >= 2)) && (
                    <p className="text-xs font-medium text-emerald-600">
                      ✨ Bônus ativo: +{sellerLevel === 'aguia' ? '1%' : '0,5%'} nas vendas desta categoria
                    </p>
                  )}
                </div>
              </div>
            );
          })}

          {/* Info sobre estrelas */}
          <div className="pt-4 border-t border-border/50 text-xs text-muted-foreground space-y-1">
            <p className="flex items-center gap-1">
              <Star className="h-3 w-3 text-amber-500 fill-amber-500" />
              <Star className="h-3 w-3 text-amber-500 fill-amber-500" />
              Toners: 2 estrelas bronze ao bater
            </p>
            <p className="flex items-center gap-1">
              <Star className="h-3 w-3 text-amber-500 fill-amber-500" />
              Demais categorias: 1 estrela bronze ao bater
            </p>
            <p className="mt-2 text-muted-foreground/70">
              • Perfil atual: {sellerCategory === 'antiga' ? 'Vendedor Experiente' : sellerCategory === 'sem_carteira' ? 'Novato (sem carteira)' : 'Novato'}
            </p>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
