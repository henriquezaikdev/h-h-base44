import { motion } from 'framer-motion';
import { Phone, MessageSquare, Mail, MapPin, Users } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { SellerMetrics } from '@/hooks/useSellerMetrics';
import { cn } from '@/lib/utils';

interface ActivityTabProps {
  metrics: SellerMetrics | null;
  activityRanking: SellerMetrics[];
  sellerRank: number;
  isAdmin: boolean;
  selectedSellerName: string;
  periodLabel?: string;
}

export function ActivityTab({ 
  metrics, 
  activityRanking, 
  sellerRank, 
  isAdmin,
  selectedSellerName,
  periodLabel = 'este mês'
}: ActivityTabProps) {
  if (!metrics) {
    return (
      <div className="text-center py-12 text-muted-foreground">
        Nenhum dado de atividade disponível
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      {/* Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <Card className="bg-gradient-to-br from-blue-500/10 to-blue-600/5 border-blue-500/20">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-blue-500/20">
                <Phone className="h-5 w-5 text-blue-500" />
              </div>
              <div>
                <p className="text-2xl font-bold text-blue-600">{metrics.ligacoes}</p>
                <p className="text-xs text-muted-foreground">Ligações</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-500/10 to-green-600/5 border-green-500/20">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-green-500/20">
                <MessageSquare className="h-5 w-5 text-green-500" />
              </div>
              <div>
                <p className="text-2xl font-bold text-green-600">{metrics.whatsapp}</p>
                <p className="text-xs text-muted-foreground">WhatsApp</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-orange-500/10 to-orange-600/5 border-orange-500/20">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-orange-500/20">
                <Mail className="h-5 w-5 text-orange-500" />
              </div>
              <div>
                <p className="text-2xl font-bold text-orange-600">{metrics.emails}</p>
                <p className="text-xs text-muted-foreground">E-mails</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-500/10 to-purple-600/5 border-purple-500/20">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-purple-500/20">
                <MapPin className="h-5 w-5 text-purple-500" />
              </div>
              <div>
                <p className="text-2xl font-bold text-purple-600">{metrics.visitas}</p>
                <p className="text-xs text-muted-foreground">Visitas</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-primary/10 to-primary/5 border-primary/20">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-primary/20">
                <Users className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold text-primary">{metrics.total_contatos}</p>
                <p className="text-xs text-muted-foreground">Total Contatos</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Seller Position */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center justify-between">
            <span>Posição no Ranking de Atividade - <span className="capitalize">{periodLabel}</span></span>
            <Badge variant="outline" className="text-lg px-3 py-1">
              {sellerRank}º lugar
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">
            {selectedSellerName} está em <strong>{sellerRank}º lugar</strong> no ranking de atividade de contatos em <span className="capitalize">{periodLabel}</span>.
          </p>
        </CardContent>
      </Card>

      {/* Ranking List (Admin only) */}
      {isAdmin && activityRanking.length > 0 && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Ranking Geral de Atividade</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {activityRanking.slice(0, 10).map((seller, index) => (
              <div
                key={seller.seller_id}
                className={cn(
                  "flex items-center justify-between p-3 rounded-lg",
                  seller.seller_id === metrics.seller_id
                    ? "bg-primary/10 border border-primary/20"
                    : "bg-muted/30"
                )}
              >
                <div className="flex items-center gap-3">
                  <div className={cn(
                    "w-8 h-8 rounded-lg flex items-center justify-center font-bold text-sm",
                    index === 0 && "bg-amber-500 text-white",
                    index === 1 && "bg-slate-400 text-white",
                    index === 2 && "bg-orange-500 text-white",
                    index > 2 && "bg-muted text-muted-foreground"
                  )}>
                    {index + 1}º
                  </div>
                  <span className="font-medium">{seller.seller_name}</span>
                </div>
                <div className="flex items-center gap-4 text-sm">
                  <span className="text-blue-600">{seller.ligacoes} lig</span>
                  <span className="text-green-600">{seller.whatsapp} wpp</span>
                  <Badge variant="secondary">{seller.total_contatos} total</Badge>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}
    </motion.div>
  );
}
