import { motion } from 'framer-motion';
import { EvolutionCard } from '@/components/evolution/EvolutionCard';
import { ProductivityPanel } from '@/components/evolution/ProductivityPanel';
import { EvolutionHistoryChart } from '@/components/evolution/EvolutionHistoryChart';
import { DailyTargetsCard } from '@/components/evolution/DailyTargetsCard';
import { AlertsPanel } from '@/components/evolution/AlertsPanel';
import { SalesTab } from '@/components/evolution/tabs/SalesTab';
import { CategoriesTab } from '@/components/evolution/tabs/CategoriesTab';
import { DistributionTab } from '@/components/evolution/tabs/DistributionTab';
import { NewClientsCard } from '@/components/evolution/NewClientsCard';
import { ReactivationsCard } from '@/components/evolution/ReactivationsCard';
import { LEVEL_MONTHLY_TARGETS } from '@/hooks/useComputeTargets';
import { SellerMetrics } from '@/hooks/useSellerMetrics';

interface PerformanceTabProps {
  selectedSeller: { id: string; name: string } | undefined;
  level: any;
  currentMonthSales: number;
  currentMonthCalls: number;
  currentMonthWhatsapp: number;
  workDaysInMonth: number;
  workDaysPassed: number;
  dailyActivities: any[];
  alerts: any[];
  evolutionStatus: 'rising' | 'stable' | 'falling';
  monthsToPromotion: number;
  monthsToDemotion: number;
  metrics: SellerMetrics | null;
  salesRanking: SellerMetrics[];
  sellerRank: number;
  isAdmin: boolean;
  selectedMonth?: number;
  selectedYear?: number;
}

export function PerformanceTab({
  selectedSeller,
  level,
  currentMonthSales,
  currentMonthCalls,
  currentMonthWhatsapp,
  workDaysInMonth,
  workDaysPassed,
  dailyActivities,
  alerts,
  evolutionStatus,
  monthsToPromotion,
  monthsToDemotion,
  metrics,
  salesRanking,
  sellerRank,
  isAdmin,
  selectedMonth,
  selectedYear,
}: PerformanceTabProps) {
  const month = selectedMonth ?? (new Date().getMonth() + 1);
  const year = selectedYear ?? new Date().getFullYear();
  if (!selectedSeller || !level) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      {/* Main evolution card */}
      <EvolutionCard
        sellerName={selectedSeller.name}
        level={level}
        currentMonthSales={currentMonthSales}
        currentMonthCalls={currentMonthCalls}
        currentMonthWhatsapp={currentMonthWhatsapp}
        workDaysInMonth={workDaysInMonth}
        workDaysPassed={workDaysPassed}
      />

      {/* Productivity */}
      <ProductivityPanel
        dailyActivities={dailyActivities}
        dailyCallsTarget={level.daily_calls_target}
        sellerLevel={level.current_level}
        workDaysInMonth={workDaysInMonth}
      />

      {/* Distribution - Clientes mais contatados */}
      <DistributionTab
        sellerId={selectedSeller.id}
        sellerName={selectedSeller.name}
        selectedMonth={month}
        selectedYear={year}
        isAdmin={isAdmin}
      />

      {/* Daily Targets */}
      <DailyTargetsCard
        monthlySalesTarget={level.monthly_sales_target}
        currentMonthSales={currentMonthSales}
        dailyCallsTarget={level.daily_calls_target}
        currentMonthCalls={currentMonthCalls}
        currentMonthWhatsapp={currentMonthWhatsapp}
        workDaysInMonth={workDaysInMonth}
        workDaysPassed={workDaysPassed}
        totalCallsMonth={LEVEL_MONTHLY_TARGETS[level.current_level]?.callsPerMonth ?? undefined}
        totalWhatsappMonth={LEVEL_MONTHLY_TARGETS[level.current_level]?.whatsappPerMonth ?? undefined}
        sellerId={selectedSeller.id}
      />

      {/* Sales ranking */}
      <SalesTab
        metrics={metrics}
        salesRanking={salesRanking}
        sellerRank={sellerRank}
        isAdmin={isAdmin}
        selectedSellerName={selectedSeller.name}
        salesTarget={level.monthly_sales_target}
      />

      {/* New Clients indicator */}
      <NewClientsCard
        sellerId={selectedSeller.id}
        sellerName={selectedSeller.name}
        isAdmin={isAdmin}
      />

      {/* Reactivations indicator */}
      <ReactivationsCard
        sellerId={selectedSeller.id}
        sellerName={selectedSeller.name}
        isAdmin={isAdmin}
      />

      {/* Category goals */}
      <CategoriesTab
        sellerId={selectedSeller.id}
        selectedMonth={month}
        selectedYear={year}
        sellerLevel={level.current_level}
      />

      {/* History chart */}
      <EvolutionHistoryChart sellerId={selectedSeller.id} />

      {/* Alerts */}
      <AlertsPanel
        alerts={alerts}
        evolutionStatus={evolutionStatus}
        monthsToPromotion={monthsToPromotion}
        monthsToDemotion={monthsToDemotion}
        currentLevel={level.current_level}
      />
    </motion.div>
  );
}
