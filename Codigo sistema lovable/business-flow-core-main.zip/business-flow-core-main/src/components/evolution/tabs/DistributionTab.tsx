import { useState, useEffect, useMemo, useCallback } from 'react';
import { motion } from 'framer-motion';
import { 
  Phone, MessageCircle, Users, AlertTriangle, TrendingUp, 
  Target, CheckCircle2, XCircle, BarChart3, AlertCircle, 
  MessageSquare, Pencil, Save, X, MousePointer
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { supabase } from '@/integrations/supabase/client';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import { ContactDrillDownDrawer } from '@/components/evolution/ContactDrillDownDrawer';

// Tier labels for display
const TIER_LABELS: Record<string, string> = {
  top20: 'TOP 20',
  top100: 'TOP 100',
  top200: 'TOP 200',
  eventual: 'EVENTUAL',
  geral: 'PROSPECTO'
};

const TIER_ORDER = ['top20', 'top100', 'top200', 'eventual', 'geral'];

interface TierStats {
  tier: string;
  contactsSuccess: number;
  attempts: number;
  uniqueClients: number;
}

interface ClientRepetition {
  clientId: string;
  clientName: string;
  tier: string;
  totalContacts: number;
  callContacts: number;
  whatsappContacts: number;
  lastContactDate: string;
  observation?: string;
}

interface DistributionData {
  callStats: TierStats[];
  whatsappStats: TierStats[];
  totalCallsSuccess: number;
  totalCallsAttempts: number;
  totalWhatsappSuccess: number;
  totalWhatsappAttempts: number;
  uniqueClientsContacted: number;
  repetitionAlerts: ClientRepetition[];
}

type DrillDownType = 'tier' | 'unique' | 'repetitions' | 'percent_top20' | 'percent_top100';

interface DrillDownState {
  open: boolean;
  type: DrillDownType;
  tierFilter?: string;
}

interface DistributionTabProps {
  sellerId: string;
  sellerName?: string;
  selectedMonth: number;
  selectedYear: number;
  periodLabel?: string;
  isAdmin: boolean;
}

export function DistributionTab({
  sellerId,
  sellerName,
  selectedMonth,
  selectedYear,
  periodLabel = 'este mês',
  isAdmin
}: DistributionTabProps) {
  const [data, setData] = useState<DistributionData | null>(null);
  const [loading, setLoading] = useState(true);
  const [repetitionFilter, setRepetitionFilter] = useState<'all' | 'calls' | 'whatsapp'>('all');
  const [editingObservation, setEditingObservation] = useState<string | null>(null);
  const [observationText, setObservationText] = useState('');
  const [savingObservation, setSavingObservation] = useState(false);
  
  // Drill-down state
  const [drillDown, setDrillDown] = useState<DrillDownState>({
    open: false,
    type: 'tier',
    tierFilter: undefined
  });
  
  const openDrillDown = (type: DrillDownType, tierFilter?: string) => {
    setDrillDown({ open: true, type, tierFilter });
  };
  
  const closeDrillDown = () => {
    setDrillDown(prev => ({ ...prev, open: false }));
  };

  const fetchDistributionData = useCallback(async () => {
    if (!sellerId) return;
    
    setLoading(true);
    try {
      // Build date range for the selected month
      const startDate = `${selectedYear}-${String(selectedMonth).padStart(2, '0')}-01`;
      const endDate = selectedMonth === 12 
        ? `${selectedYear + 1}-01-01`
        : `${selectedYear}-${String(selectedMonth + 1).padStart(2, '0')}-01`;

      // Fetch interactions AND completed tasks in parallel
      const [interactionsRes, tasksRes] = await Promise.all([
        supabase
          .from('interactions')
          .select('id, client_id, interaction_type, interaction_date')
          .eq('responsible_seller_id', sellerId)
          .gte('interaction_date', startDate)
          .lt('interaction_date', endDate),
        supabase
          .from('tasks')
          .select('id, client_id, contact_type, completed_at, created_by_seller_id, status')
          .eq('status', 'concluida')
          .gte('completed_at', `${startDate}T00:00:00-03:00`)
          .lt('completed_at', `${endDate}T00:00:00-03:00`)
      ]);

      if (interactionsRes.error) throw interactionsRes.error;
      const interactions = interactionsRes.data || [];

      // Filter tasks by seller ownership
      const sellerTasks = (tasksRes.data || []).filter(t => 
        t.created_by_seller_id === sellerId
      );

      // Collect all client IDs from both sources
      const interactionClientIds = interactions.map(i => i.client_id);
      const taskClientIds = sellerTasks.map(t => t.client_id).filter(Boolean) as string[];
      const clientIds = [...new Set([...interactionClientIds, ...taskClientIds])];
      
      let clientsMap: Record<string, { name: string; tier: string }> = {};
      
      if (clientIds.length > 0) {
        // Fetch in batches of 500 to avoid URL length limits
        const batchSize = 500;
        for (let i = 0; i < clientIds.length; i += batchSize) {
          const batch = clientIds.slice(i, i + batchSize);
          const { data: clients } = await supabase
            .from('clients')
            .select('id, company_name, ranking_tier')
            .in('id', batch);
          
          (clients || []).forEach(c => {
            clientsMap[c.id] = {
              name: c.company_name,
              tier: c.ranking_tier || 'geral'
            };
          });
        }
      }

      // Fetch existing observations for this period
      const { data: observations } = await supabase
        .from('repetition_observations')
        .select('client_id, observation')
        .eq('seller_id', sellerId)
        .eq('year', selectedYear)
        .eq('month', selectedMonth);

      const observationsMap: Record<string, string> = {};
      (observations || []).forEach(o => {
        observationsMap[o.client_id] = o.observation;
      });

      // Process data
      const callStatsMap: Record<string, TierStats> = {};
      const whatsappStatsMap: Record<string, TierStats> = {};
      const clientContactCount: Record<string, { 
        calls: number; 
        whatsapp: number; 
        lastDate: string;
        tier: string;
        name: string;
      }> = {};

      // Initialize stats for all tiers
      TIER_ORDER.forEach(tier => {
        callStatsMap[tier] = { tier, contactsSuccess: 0, attempts: 0, uniqueClients: new Set() as any };
        whatsappStatsMap[tier] = { tier, contactsSuccess: 0, attempts: 0, uniqueClients: new Set() as any };
      });

      const callUniqueClients: Record<string, Set<string>> = {};
      const whatsappUniqueClients: Record<string, Set<string>> = {};
      TIER_ORDER.forEach(tier => {
        callUniqueClients[tier] = new Set();
        whatsappUniqueClients[tier] = new Set();
      });

      let totalCallsSuccess = 0;
      let totalCallsAttempts = 0;
      let totalWhatsappSuccess = 0;
      let totalWhatsappAttempts = 0;
      const allContactedClients = new Set<string>();

      // Helper to track a contact
      const trackContact = (clientId: string, type: 'call' | 'whatsapp', isAttempt: boolean, dateStr: string) => {
        const clientInfo = clientsMap[clientId] || { name: 'Desconhecido', tier: 'geral' };
        const tier = clientInfo.tier || 'geral';

        if (type === 'call') {
          if (isAttempt) {
            if (callStatsMap[tier]) callStatsMap[tier].attempts++;
            totalCallsAttempts++;
          } else {
            if (callStatsMap[tier]) callStatsMap[tier].contactsSuccess++;
            totalCallsSuccess++;
            callUniqueClients[tier]?.add(clientId);
            allContactedClients.add(clientId);
          }
        } else {
          if (isAttempt) {
            if (whatsappStatsMap[tier]) whatsappStatsMap[tier].attempts++;
            totalWhatsappAttempts++;
          } else {
            if (whatsappStatsMap[tier]) whatsappStatsMap[tier].contactsSuccess++;
            totalWhatsappSuccess++;
            whatsappUniqueClients[tier]?.add(clientId);
            allContactedClients.add(clientId);
          }
        }

        // Track for repetition (only successful contacts)
        if (!isAttempt) {
          if (!clientContactCount[clientId]) {
            clientContactCount[clientId] = {
              calls: 0, whatsapp: 0, lastDate: dateStr, tier, name: clientInfo.name
            };
          }
          if (type === 'call') clientContactCount[clientId].calls++;
          else clientContactCount[clientId].whatsapp++;
          if (dateStr > clientContactCount[clientId].lastDate) {
            clientContactCount[clientId].lastDate = dateStr;
          }
        }
      };

      // Process interactions
      interactions.forEach(interaction => {
        const interactionType = interaction.interaction_type?.toLowerCase() || '';
        const isCall = interactionType.includes('ligação') || interactionType.includes('ligacao');
        const isWhatsapp = interactionType.includes('whatsapp');
        const isAttempt = interactionType.includes('tentativa');

        if (isCall) trackContact(interaction.client_id, 'call', isAttempt, interaction.interaction_date);
        else if (isWhatsapp) trackContact(interaction.client_id, 'whatsapp', false, interaction.interaction_date);
      });

      // Process completed tasks
      sellerTasks.forEach(task => {
        if (!task.client_id) return;
        const contactType = task.contact_type?.toLowerCase() || '';
        const dateStr = task.completed_at ? task.completed_at.split('T')[0] : startDate;
        const isAttempt = contactType.includes('tentativa');

        if (contactType.includes('ligacao') || contactType.includes('ligação')) {
          trackContact(task.client_id, 'call', isAttempt, dateStr);
        } else if (contactType.includes('whatsapp')) {
          trackContact(task.client_id, 'whatsapp', isAttempt, dateStr);
        }
      });
      // Convert to arrays with unique client counts
      const callStats: TierStats[] = TIER_ORDER.map(tier => ({
        tier,
        contactsSuccess: callStatsMap[tier]?.contactsSuccess || 0,
        attempts: callStatsMap[tier]?.attempts || 0,
        uniqueClients: callUniqueClients[tier]?.size || 0
      }));

      const whatsappStats: TierStats[] = TIER_ORDER.map(tier => ({
        tier,
        contactsSuccess: whatsappStatsMap[tier]?.contactsSuccess || 0,
        attempts: whatsappStatsMap[tier]?.attempts || 0,
        uniqueClients: whatsappUniqueClients[tier]?.size || 0
      }));

      // Find clients with repetition (3+ contacts)
      const repetitionAlerts: ClientRepetition[] = Object.entries(clientContactCount)
        .filter(([_, info]) => (info.calls + info.whatsapp) >= 3)
        .map(([clientId, info]) => ({
          clientId,
          clientName: info.name,
          tier: info.tier,
          totalContacts: info.calls + info.whatsapp,
          callContacts: info.calls,
          whatsappContacts: info.whatsapp,
          lastContactDate: info.lastDate,
          observation: observationsMap[clientId] || ''
        }))
        .sort((a, b) => b.totalContacts - a.totalContacts);

      setData({
        callStats,
        whatsappStats,
        totalCallsSuccess,
        totalCallsAttempts,
        totalWhatsappSuccess,
        totalWhatsappAttempts,
        uniqueClientsContacted: allContactedClients.size,
        repetitionAlerts
      });
    } catch (err) {
      console.error('Error fetching distribution data:', err);
    } finally {
      setLoading(false);
    }
  }, [sellerId, selectedMonth, selectedYear]);

  useEffect(() => {
    fetchDistributionData();
  }, [fetchDistributionData]);

  // Save observation
  const handleSaveObservation = async (clientId: string) => {
    if (!sellerId) return;
    
    const trimmedText = observationText.trim();
    if (trimmedText.length > 500) {
      toast.error('Observação muito longa (máx. 500 caracteres)');
      return;
    }

    setSavingObservation(true);
    try {
      const { error } = await supabase
        .from('repetition_observations')
        .upsert({
          client_id: clientId,
          seller_id: sellerId,
          year: selectedYear,
          month: selectedMonth,
          observation: trimmedText
        }, { onConflict: 'client_id,seller_id,year,month' });

      if (error) throw error;

      // Update local data
      setData(prev => {
        if (!prev) return prev;
        return {
          ...prev,
          repetitionAlerts: prev.repetitionAlerts.map(a => 
            a.clientId === clientId ? { ...a, observation: trimmedText } : a
          )
        };
      });

      toast.success('Observação salva');
      setEditingObservation(null);
      setObservationText('');
    } catch (err) {
      console.error('Error saving observation:', err);
      toast.error('Erro ao salvar observação');
    } finally {
      setSavingObservation(false);
    }
  };

  const startEditingObservation = (clientId: string, currentObs: string) => {
    setEditingObservation(clientId);
    setObservationText(currentObs || '');
  };

  const cancelEditingObservation = () => {
    setEditingObservation(null);
    setObservationText('');
  };

  // Calculate concentration alerts
  const concentrationAlerts = useMemo(() => {
    if (!data) return { top20Percent: 0, top100Percent: 0, alerts: [] };
    
    const totalSuccess = data.totalCallsSuccess + data.totalWhatsappSuccess;
    if (totalSuccess === 0) return { top20Percent: 0, top100Percent: 0, alerts: [] };

    const top20Success = (data.callStats.find(s => s.tier === 'top20')?.contactsSuccess || 0) +
                         (data.whatsappStats.find(s => s.tier === 'top20')?.contactsSuccess || 0);
    const top100Success = (data.callStats.find(s => s.tier === 'top100')?.contactsSuccess || 0) +
                          (data.whatsappStats.find(s => s.tier === 'top100')?.contactsSuccess || 0);

    const top20Percent = (top20Success / totalSuccess) * 100;
    const top100Percent = ((top20Success + top100Success) / totalSuccess) * 100;

    const alerts: string[] = [];
    if (top20Percent > 35) alerts.push('Foco excessivo em TOP 20');
    if (top100Percent > 55) alerts.push('Foco excessivo em TOP 100');

    return { top20Percent, top100Percent, alerts };
  }, [data]);

  // Filter repetition alerts based on selected filter
  const filteredRepetitionAlerts = useMemo(() => {
    if (!data) return [];
    
    return data.repetitionAlerts.filter(alert => {
      if (repetitionFilter === 'calls') return alert.callContacts >= 3;
      if (repetitionFilter === 'whatsapp') return alert.whatsappContacts >= 3;
      return true; // 'all' - total >= 3
    });
  }, [data, repetitionFilter]);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  if (!data) {
    return (
      <div className="text-center py-12 text-muted-foreground">
        Nenhum dado de distribuição disponível
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      {/* BLOCO 1 - Resumo por Faixa */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Card Ligações */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Phone className="h-5 w-5 text-blue-500" />
              Ligações por Faixa
            </CardTitle>
            <div className="flex flex-wrap gap-2 text-xs text-muted-foreground mt-2">
              <Badge variant="outline" className="bg-green-500/10 text-green-600 border-green-500/30">
                {data.totalCallsSuccess} contatos
              </Badge>
              <Badge variant="outline" className="bg-amber-500/10 text-amber-600 border-amber-500/30">
                {data.totalCallsAttempts} tentativas
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Faixa</TableHead>
                  <TableHead className="text-right">Contatos</TableHead>
                  <TableHead className="text-right">Tentativas</TableHead>
                  <TableHead className="text-right">%</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data.callStats.map(stat => (
                  <TableRow key={stat.tier}>
                    <TableCell className="font-medium">{TIER_LABELS[stat.tier]}</TableCell>
                    <TableCell className="text-right text-green-600 font-semibold">
                      {stat.contactsSuccess}
                    </TableCell>
                    <TableCell className="text-right text-amber-600">
                      {stat.attempts}
                    </TableCell>
                    <TableCell className="text-right">
                      {data.totalCallsSuccess > 0 
                        ? ((stat.contactsSuccess / data.totalCallsSuccess) * 100).toFixed(1)
                        : '0'}%
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {/* Card WhatsApp */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <MessageCircle className="h-5 w-5 text-green-500" />
              WhatsApp por Faixa
            </CardTitle>
            <div className="flex flex-wrap gap-2 text-xs text-muted-foreground mt-2">
              <Badge variant="outline" className="bg-green-500/10 text-green-600 border-green-500/30">
                {data.totalWhatsappSuccess} contatos
              </Badge>
              <Badge variant="outline" className="bg-amber-500/10 text-amber-600 border-amber-500/30">
                {data.totalWhatsappAttempts} tentativas
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Faixa</TableHead>
                  <TableHead className="text-right">Contatos</TableHead>
                  <TableHead className="text-right">Tentativas</TableHead>
                  <TableHead className="text-right">%</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data.whatsappStats.map(stat => (
                  <TableRow key={stat.tier}>
                    <TableCell className="font-medium">{TIER_LABELS[stat.tier]}</TableCell>
                    <TableCell className="text-right text-green-600 font-semibold">
                      {stat.contactsSuccess}
                    </TableCell>
                    <TableCell className="text-right text-amber-600">
                      {stat.attempts}
                    </TableCell>
                    <TableCell className="text-right">
                      {data.totalWhatsappSuccess > 0 
                        ? ((stat.contactsSuccess / data.totalWhatsappSuccess) * 100).toFixed(1)
                        : '0'}%
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>

      {/* BLOCO 2 - Alerta de Repetição */}
      <Card className={cn(
        "border-2",
        filteredRepetitionAlerts.length > 0 && "border-amber-500/30 bg-amber-500/5"
      )}>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-base flex items-center gap-2">
              <AlertTriangle className={cn(
                "h-5 w-5",
                filteredRepetitionAlerts.length > 0 ? "text-amber-500" : "text-muted-foreground"
              )} />
              Alerta de Repetição (3+ contatos/mês)
            </CardTitle>
            <Tabs value={repetitionFilter} onValueChange={(v) => setRepetitionFilter(v as any)}>
              <TabsList className="h-8">
                <TabsTrigger value="all" className="text-xs h-7 px-2">Somado</TabsTrigger>
                <TabsTrigger value="calls" className="text-xs h-7 px-2">Ligações</TabsTrigger>
                <TabsTrigger value="whatsapp" className="text-xs h-7 px-2">WhatsApp</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
        </CardHeader>
        <CardContent>
          {filteredRepetitionAlerts.length === 0 ? (
            <div className="flex items-center gap-2 py-4 text-muted-foreground">
              <CheckCircle2 className="h-5 w-5 text-green-500" />
              <span>Sem alertas de repetição no período</span>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="flex items-center gap-2 text-sm text-amber-600 bg-amber-500/10 p-2 rounded-lg">
                <AlertCircle className="h-4 w-4" />
                <span>
                  {filteredRepetitionAlerts.length} cliente(s) com repetição acima do normal
                </span>
              </div>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Cliente</TableHead>
                    <TableHead>Faixa</TableHead>
                    <TableHead className="text-right">Total</TableHead>
                    <TableHead className="text-right">Ligações</TableHead>
                    <TableHead className="text-right">WhatsApp</TableHead>
                    <TableHead className="text-right">Última Data</TableHead>
                    <TableHead>Observação</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredRepetitionAlerts.slice(0, 15).map(alert => (
                    <TableRow key={alert.clientId}>
                      <TableCell className="font-medium max-w-[180px] truncate">
                        {alert.clientName}
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className="text-xs">
                          {TIER_LABELS[alert.tier]}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right font-bold text-amber-600">
                        {alert.totalContacts}
                      </TableCell>
                      <TableCell className="text-right">{alert.callContacts}</TableCell>
                      <TableCell className="text-right">{alert.whatsappContacts}</TableCell>
                      <TableCell className="text-right text-muted-foreground text-sm">
                        {new Date(alert.lastContactDate).toLocaleDateString('pt-BR')}
                      </TableCell>
                      <TableCell className="min-w-[200px]">
                        {editingObservation === alert.clientId ? (
                          <div className="flex items-center gap-2">
                            <Textarea
                              value={observationText}
                              onChange={(e) => setObservationText(e.target.value)}
                              placeholder="Observação do gestor..."
                              className="min-h-[60px] text-xs resize-none"
                              maxLength={500}
                            />
                            <div className="flex flex-col gap-1">
                              <Button
                                size="icon"
                                variant="ghost"
                                className="h-7 w-7 text-green-600"
                                onClick={() => handleSaveObservation(alert.clientId)}
                                disabled={savingObservation}
                              >
                                <Save className="h-4 w-4" />
                              </Button>
                              <Button
                                size="icon"
                                variant="ghost"
                                className="h-7 w-7 text-muted-foreground"
                                onClick={cancelEditingObservation}
                                disabled={savingObservation}
                              >
                                <X className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>
                        ) : (
                          <div className="flex items-center gap-2">
                            {alert.observation ? (
                              <span className="text-xs text-muted-foreground line-clamp-2 flex-1">
                                {alert.observation}
                              </span>
                            ) : (
                              <span className="text-xs text-muted-foreground/50 italic flex-1">
                                {isAdmin ? 'Sem observação' : '—'}
                              </span>
                            )}
                            {isAdmin && (
                              <Button
                                size="icon"
                                variant="ghost"
                                className="h-7 w-7 text-muted-foreground hover:text-foreground"
                                onClick={() => startEditingObservation(alert.clientId, alert.observation || '')}
                              >
                                <Pencil className="h-3 w-3" />
                              </Button>
                            )}
                          </div>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              {filteredRepetitionAlerts.length > 15 && (
                <p className="text-xs text-muted-foreground text-center">
                  +{filteredRepetitionAlerts.length - 15} clientes não exibidos
                </p>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* BLOCO 3 - Concentração / Vício de Carteira */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <BarChart3 className="h-5 w-5 text-primary" />
            Diagnóstico de Concentração
            <Badge variant="outline" className="ml-2 text-xs font-normal">
              <MousePointer className="h-3 w-3 mr-1" />
              Clique nos números para detalhes
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Indicadores - CLICÁVEIS */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {/* % para TOP 20 */}
            <button
              onClick={() => openDrillDown('percent_top20')}
              className={cn(
                "p-4 rounded-lg bg-muted/30 border border-border text-left transition-all",
                "hover:border-primary/50 hover:bg-primary/5 cursor-pointer group"
              )}
            >
              <p className="text-xs text-muted-foreground mb-1 group-hover:text-primary transition-colors">
                % para TOP 20
              </p>
              <p className={cn(
                "text-2xl font-bold",
                concentrationAlerts.top20Percent > 35 ? "text-amber-600" : "text-foreground"
              )}>
                {concentrationAlerts.top20Percent.toFixed(1)}%
              </p>
              {concentrationAlerts.top20Percent > 35 && (
                <Badge className="mt-2 bg-amber-500 text-xs">Risco: foco excessivo</Badge>
              )}
            </button>
            
            {/* % para TOP 20+100 */}
            <button
              onClick={() => openDrillDown('percent_top100')}
              className={cn(
                "p-4 rounded-lg bg-muted/30 border border-border text-left transition-all",
                "hover:border-primary/50 hover:bg-primary/5 cursor-pointer group"
              )}
            >
              <p className="text-xs text-muted-foreground mb-1 group-hover:text-primary transition-colors">
                % para TOP 20+100
              </p>
              <p className={cn(
                "text-2xl font-bold",
                concentrationAlerts.top100Percent > 55 ? "text-amber-600" : "text-foreground"
              )}>
                {concentrationAlerts.top100Percent.toFixed(1)}%
              </p>
              {concentrationAlerts.top100Percent > 55 && (
                <Badge className="mt-2 bg-amber-500 text-xs">Risco: foco excessivo</Badge>
              )}
            </button>
            
            {/* Clientes Únicos */}
            <button
              onClick={() => openDrillDown('unique')}
              className={cn(
                "p-4 rounded-lg bg-muted/30 border border-border text-left transition-all",
                "hover:border-primary/50 hover:bg-primary/5 cursor-pointer group"
              )}
            >
              <p className="text-xs text-muted-foreground mb-1 group-hover:text-primary transition-colors">
                Clientes Únicos
              </p>
              <p className="text-2xl font-bold text-primary">
                {data.uniqueClientsContacted}
              </p>
            </button>
            
            {/* Repetições (3+) */}
            <button
              onClick={() => openDrillDown('repetitions')}
              className={cn(
                "p-4 rounded-lg bg-muted/30 border border-border text-left transition-all",
                "hover:border-primary/50 hover:bg-primary/5 cursor-pointer group"
              )}
            >
              <p className="text-xs text-muted-foreground mb-1 group-hover:text-primary transition-colors">
                Repetições (3+)
              </p>
              <p className={cn(
                "text-2xl font-bold",
                data.repetitionAlerts.length > 0 ? "text-amber-600" : "text-green-600"
              )}>
                {data.repetitionAlerts.length}
              </p>
            </button>
          </div>

          {/* Clientes únicos por faixa - CLICÁVEIS */}
          <div className="pt-4 border-t border-border">
            <p className="text-sm font-medium mb-3">Clientes únicos contatados por faixa</p>
            <div className="grid grid-cols-5 gap-2">
              {TIER_ORDER.map(tier => {
                const callUnique = data.callStats.find(s => s.tier === tier)?.uniqueClients || 0;
                const whatsappUnique = data.whatsappStats.find(s => s.tier === tier)?.uniqueClients || 0;
                const totalUnique = Math.max(callUnique, whatsappUnique);
                return (
                  <button
                    key={tier}
                    onClick={() => openDrillDown('tier', tier)}
                    className={cn(
                      "text-center p-2 rounded-lg bg-muted/20 border border-border transition-all",
                      "hover:border-primary/50 hover:bg-primary/5 cursor-pointer group"
                    )}
                  >
                    <p className="text-xs text-muted-foreground mb-1 group-hover:text-primary transition-colors">
                      {TIER_LABELS[tier]}
                    </p>
                    <p className="text-lg font-semibold">{totalUnique}</p>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Alertas gerais */}
          {concentrationAlerts.alerts.length > 0 && (
            <div className="p-4 rounded-lg bg-amber-500/10 border border-amber-500/30">
              <div className="flex items-center gap-2 mb-2">
                <AlertTriangle className="h-5 w-5 text-amber-500" />
                <span className="font-medium text-amber-700">Alertas de Concentração</span>
              </div>
              <ul className="list-disc list-inside text-sm text-amber-600 space-y-1">
                {concentrationAlerts.alerts.map((alert, i) => (
                  <li key={i}>{alert}</li>
                ))}
              </ul>
            </div>
          )}
        </CardContent>
      </Card>
      
      {/* Drill-Down Drawer */}
      <ContactDrillDownDrawer
        open={drillDown.open}
        onOpenChange={(open) => setDrillDown(prev => ({ ...prev, open }))}
        sellerId={sellerId}
        sellerName={sellerName}
        selectedMonth={selectedMonth}
        selectedYear={selectedYear}
        drillDownType={drillDown.type}
        tierFilter={drillDown.tierFilter}
        periodLabel={periodLabel}
      />
    </motion.div>
  );
}
