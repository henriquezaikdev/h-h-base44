import { useState, forwardRef } from "react";
import { useNavigate } from "react-router-dom";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { motion, AnimatePresence } from "framer-motion";
import { 
  Sheet, 
  SheetContent, 
  SheetHeader, 
  SheetTitle,
  SheetDescription 
} from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { 
  Building2, 
  Calendar, 
  Receipt, 
  Check, 
  X, 
  RotateCcw, 
  ExternalLink,
  UserCheck,
  Clock,
  CheckCircle2,
  XCircle,
  Loader2,
  Chrome,
  User
} from "lucide-react";
import { useNewClientsDetail, NewClientDetail } from "@/hooks/useNewClientsDetail";
import { cn } from "@/lib/utils";

interface NewClientsDetailSheetProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  sellerId: string;
  sellerName: string;
  month: number;
  year: number;
}

export function NewClientsDetailSheet({
  open,
  onOpenChange,
  sellerId,
  sellerName,
  month,
  year
}: NewClientsDetailSheetProps) {
  const navigate = useNavigate();
  const [verifyingId, setVerifyingId] = useState<string | null>(null);

  const {
    clients,
    loading,
    verifiedCount,
    confirmedCount,
    googleCount,
    deniedCount,
    pendingCount,
    totalCount,
    verifyClient,
    clearVerification
  } = useNewClientsDetail({ sellerId, month, year, enabled: open });

  const monthName = format(new Date(year, month - 1, 1), "MMMM 'de' yyyy", { locale: ptBR });

  const handleVerify = async (clientId: string, isNew: boolean, isFromGoogle: boolean | null = null) => {
    setVerifyingId(clientId);
    try {
      await verifyClient(clientId, isNew, isFromGoogle);
    } finally {
      setVerifyingId(null);
    }
  };

  const handleClear = async (clientId: string) => {
    setVerifyingId(clientId);
    try {
      await clearVerification(clientId);
    } finally {
      setVerifyingId(null);
    }
  };

  const handleViewClient = (clientId: string) => {
    onOpenChange(false);
    navigate(`/clients/${clientId}`);
  };

  const getStatusBadge = (verified: boolean | null, isFromGoogle: boolean | null) => {
    if (verified === true && isFromGoogle === true) {
      return (
        <Badge className="bg-blue-500/20 text-blue-400 border-blue-500/30">
          <Chrome className="h-3 w-3 mr-1" />
          Via Google
        </Badge>
      );
    }
    if (verified === true) {
      return (
        <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30">
          <User className="h-3 w-3 mr-1" />
          Conquistado
        </Badge>
      );
    }
    if (verified === false) {
      return (
        <Badge className="bg-red-500/20 text-red-400 border-red-500/30">
          <XCircle className="h-3 w-3 mr-1" />
          Não é novo
        </Badge>
      );
    }
    return (
      <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30">
        <Clock className="h-3 w-3 mr-1" />
        Pendente
      </Badge>
    );
  };

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="w-full sm:max-w-lg bg-background border-border h-screen max-h-screen overflow-hidden flex flex-col p-0">
        {/* Header - shrink-0, não rola */}
        <div className="shrink-0 px-6 pt-6">
          <SheetHeader className="space-y-1">
            <SheetTitle className="flex items-center gap-2 text-xl">
              <UserCheck className="h-5 w-5 text-primary" />
              Clientes Novos
            </SheetTitle>
            <SheetDescription className="capitalize">
              {monthName} • {sellerName}
            </SheetDescription>
          </SheetHeader>
        </div>

        {/* KPIs - shrink-0, não rola */}
        <div className="shrink-0 px-6">
          <div className="grid grid-cols-5 gap-2 mt-4 mb-4">
            <div className="bg-muted/50 rounded-lg p-2 text-center">
              <div className="text-lg font-bold text-foreground">{totalCount}</div>
              <div className="text-[10px] text-muted-foreground">Total</div>
            </div>
            <div className="bg-emerald-500/10 rounded-lg p-2 text-center border border-emerald-500/20">
              <div className="text-lg font-bold text-emerald-400">{confirmedCount}</div>
              <div className="text-[10px] text-emerald-400/70">Conquistados</div>
            </div>
            <div className="bg-blue-500/10 rounded-lg p-2 text-center border border-blue-500/20">
              <div className="text-lg font-bold text-blue-400">{googleCount}</div>
              <div className="text-[10px] text-blue-400/70">Google</div>
            </div>
            <div className="bg-red-500/10 rounded-lg p-2 text-center border border-red-500/20">
              <div className="text-lg font-bold text-red-400">{deniedCount}</div>
              <div className="text-[10px] text-red-400/70">Negados</div>
            </div>
            <div className="bg-amber-500/10 rounded-lg p-2 text-center border border-amber-500/20">
              <div className="text-lg font-bold text-amber-400">{pendingCount}</div>
              <div className="text-[10px] text-amber-400/70">Pendentes</div>
            </div>
          </div>

          <Separator />
        </div>

        {/* Lista de Clientes - ÚNICO com scroll */}
        <div className="flex-1 overflow-y-auto px-6 py-4">
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
            </div>
          ) : clients.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <UserCheck className="h-12 w-12 mx-auto mb-3 opacity-30" />
              <p>Nenhum cliente novo neste mês</p>
            </div>
          ) : (
            <AnimatePresence mode="popLayout">
              <div className="space-y-3">
                {clients.map((client, index) => (
                  <ClientCard
                    key={client.clientId}
                    client={client}
                    index={index}
                    isVerifying={verifyingId === client.clientId}
                    onVerify={handleVerify}
                    onClear={handleClear}
                    onViewClient={handleViewClient}
                    getStatusBadge={getStatusBadge}
                  />
                ))}
              </div>
            </AnimatePresence>
          )}
        </div>

        {/* Footer - shrink-0, não rola */}
        {!loading && clients.length > 0 && (
          <div className="shrink-0 px-6 pb-6 pt-3 border-t border-border bg-background">
            <div className="text-sm text-muted-foreground text-center">
              {verifiedCount} de {totalCount} clientes verificados
            </div>
          </div>
        )}
      </SheetContent>
    </Sheet>
  );
}

interface ClientCardProps {
  client: NewClientDetail;
  index: number;
  isVerifying: boolean;
  onVerify: (id: string, isNew: boolean, isFromGoogle?: boolean | null) => void;
  onClear: (id: string) => void;
  onViewClient: (id: string) => void;
  getStatusBadge: (verified: boolean | null, isFromGoogle: boolean | null) => React.ReactNode;
}

const ClientCard = forwardRef<HTMLDivElement, ClientCardProps>(function ClientCard(
  {
    client,
    index,
    isVerifying,
    onVerify,
    onClear,
    onViewClient,
    getStatusBadge,
  },
  ref
) {
  const formatCnpj = (cnpj: string | null) => {
    if (!cnpj) return 'Não informado';
    const cleaned = cnpj.replace(/\D/g, '');
    if (cleaned.length === 11) {
      return cleaned.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
    }
    if (cleaned.length === 14) {
      return cleaned.replace(/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/, '$1.$2.$3/$4-$5');
    }
    return cnpj;
  };

  const cardBgClass = client.verified === true && client.isFromGoogle
    ? 'bg-blue-500/5 border-blue-500/20'
    : client.verified === true 
      ? 'bg-emerald-500/5 border-emerald-500/20' 
      : client.verified === false 
        ? 'bg-red-500/5 border-red-500/20 opacity-60' 
        : 'bg-muted/30 border-border';

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ delay: index * 0.05 }}
      className={cn(
        "rounded-lg border p-3 transition-all",
        cardBgClass
      )}
    >
      {/* Header: Name + Actions */}
      <div className="flex items-start justify-between gap-2 mb-2">
        <div className="flex items-center gap-2 flex-1 min-w-0">
          <Building2 className="h-4 w-4 text-muted-foreground shrink-0" />
          <span className="font-medium text-sm truncate">
            {client.companyName}
          </span>
        </div>
        
        {/* Verification Actions */}
        <div className="flex items-center gap-1 shrink-0">
          {isVerifying ? (
            <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
          ) : (
            <>
              {/* Conquistado (vendedor) */}
              <Button
                size="icon"
                variant={client.verified === true && !client.isFromGoogle ? "default" : "ghost"}
                className={cn(
                  "h-7 w-7",
                  client.verified === true && !client.isFromGoogle 
                    ? "bg-emerald-500 hover:bg-emerald-600" 
                    : "hover:bg-emerald-500/20 hover:text-emerald-400"
                )}
                onClick={() => onVerify(client.clientId, true, false)}
                title="Novo - Conquistado pelo vendedor"
              >
                <User className="h-3.5 w-3.5" />
              </Button>
              {/* Via Google */}
              <Button
                size="icon"
                variant={client.verified === true && client.isFromGoogle ? "default" : "ghost"}
                className={cn(
                  "h-7 w-7",
                  client.verified === true && client.isFromGoogle 
                    ? "bg-blue-500 hover:bg-blue-600" 
                    : "hover:bg-blue-500/20 hover:text-blue-400"
                )}
                onClick={() => onVerify(client.clientId, true, true)}
                title="Novo - Veio do Google"
              >
                <Chrome className="h-3.5 w-3.5" />
              </Button>
              {/* Não é novo */}
              <Button
                size="icon"
                variant={client.verified === false ? "default" : "ghost"}
                className={cn(
                  "h-7 w-7",
                  client.verified === false 
                    ? "bg-red-500 hover:bg-red-600" 
                    : "hover:bg-red-500/20 hover:text-red-400"
                )}
                onClick={() => onVerify(client.clientId, false, null)}
                title="Não é cliente novo"
              >
                <X className="h-3.5 w-3.5" />
              </Button>
              {/* Limpar */}
              <Button
                size="icon"
                variant="ghost"
                className="h-7 w-7 hover:bg-muted"
                onClick={() => onClear(client.clientId)}
                disabled={client.verified === null}
                title="Limpar verificação"
              >
                <RotateCcw className="h-3.5 w-3.5" />
              </Button>
            </>
          )}
        </div>
      </div>

      {/* CNPJ */}
      <div className="text-xs text-muted-foreground mb-2">
        {formatCnpj(client.cnpj)}
      </div>

      <Separator className="my-2" />

      {/* Order Info */}
      <div className="flex items-center gap-4 text-xs text-muted-foreground mb-2">
        <div className="flex items-center gap-1">
          <Calendar className="h-3 w-3" />
          <span>
            {format(client.firstOrderDate, "dd/MM/yyyy")} 
            {client.daysSinceFirstOrder === 0 
              ? ' (hoje)' 
              : ` (${client.daysSinceFirstOrder} dias)`
            }
          </span>
        </div>
      </div>

      {client.orderNumber && (
        <div className="flex items-center gap-1 text-xs text-muted-foreground mb-2">
          <Receipt className="h-3 w-3" />
          <span>
            Pedido #{client.orderNumber} - R$ {(client.orderTotal || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
          </span>
        </div>
      )}

      {/* Footer: Status + View Button */}
      <div className="flex items-center justify-between mt-3">
        {getStatusBadge(client.verified, client.isFromGoogle)}
        
        <Button
          variant="ghost"
          size="sm"
          className="text-xs h-7 text-muted-foreground hover:text-foreground"
          onClick={() => onViewClient(client.clientId)}
        >
          Ver Cliente
          <ExternalLink className="h-3 w-3 ml-1" />
        </Button>
      </div>
    </motion.div>
  );
});
