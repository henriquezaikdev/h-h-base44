import { useState } from 'react';
import { motion } from 'framer-motion';
import { Calculator, TrendingUp, Info, CheckCircle2, XCircle, AlertTriangle, Zap } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { CommissionOrdersDrawer } from './CommissionOrdersDrawer';
import {
  COMMISSION_BANDS_NORMAL,
  COMMISSION_BANDS_SPECIAL,
  getCommissionBands,
  findCommissionBand,
  getCategoryBonusRate,
  getBandKeyForMargin,
  type CommissionBand,
  type MarginBandKey,
} from '@/lib/commissionConfig';

interface SalesBreakdown {
  margin: number;
  revenue: number;
  categoryKey?: string;
}

interface CategoryBonusEligibility {
  categoryKey: string;
  isMet: boolean;
  margin: number;
  isEligible: boolean;
}

interface CommissionCalculatorProps {
  salesByMargin: SalesBreakdown[];
  bonusPercentage: number;
  sellerLevel: 'ovo' | 'pena' | 'aguia';
  hasLostBonus: boolean;
  sellerId: string;
  sellerName: string;
  month: number;
  year: number;
  categoryEligibility?: CategoryBonusEligibility[];
  monthlyTarget?: number;
  currentMonthSales?: number;
}

export function CommissionCalculator({
  salesByMargin,
  bonusPercentage,
  sellerLevel,
  hasLostBonus,
  sellerId,
  sellerName,
  month,
  year,
  categoryEligibility = [],
  monthlyTarget = 0,
  currentMonthSales = 0,
}: CommissionCalculatorProps) {
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [selectedBand, setSelectedBand] = useState<MarginBandKey>('total');
  const [expectedRevenue, setExpectedRevenue] = useState(0);
  const [expectedCommission, setExpectedCommission] = useState(0);

  const isNewRuleActive = year > 2026 || (year === 2026 && month >= 2);

  // Determinar se regra especial 130% está ativa
  const metaPercentage = monthlyTarget > 0 ? (currentMonthSales / monthlyTarget) * 100 : 0;
  const isSpecialRule = metaPercentage >= 130;
  const activeBands = getCommissionBands(metaPercentage);

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
  };

  const calculateCommission = (revenue: number, marginDecimal: number, categoryKey?: string) => {
    const marginPercent = marginDecimal * 100;

    if (!isFinite(marginPercent)) {
      return { rate: 0, baseRate: 0, bonusRate: 0, commission: 0, band: activeBands[activeBands.length - 1], bonusApplied: false, bonusReason: '' };
    }

    const band = findCommissionBand(marginPercent, activeBands);
    let baseRate = band.baseRate;
    let bonusRate = 0;
    let bonusApplied = false;
    let bonusReason = '';

    if (!isNewRuleActive) {
      bonusReason = 'rule_not_active';
    } else if (hasLostBonus) {
      bonusReason = 'errors_blocked';
    } else if (!categoryKey) {
      bonusReason = 'no_category';
    } else {
      const categoryElig = categoryEligibility.find(c => c.categoryKey === categoryKey);
      if (!categoryElig) {
        bonusReason = 'no_category_data';
      } else if (!categoryElig.isMet) {
        bonusReason = 'goal_not_met';
      } else if (categoryElig.margin < 40) {
        bonusReason = 'category_margin_low';
      } else {
        // Bônus por categoria: ≥60% → +1,0%, ≥40% → +0,5%
        bonusRate = getCategoryBonusRate(categoryElig.margin, true);
        bonusApplied = true;
        bonusReason = 'eligible';
      }
    }

    const totalRate = baseRate + bonusRate;
    return {
      rate: totalRate,
      baseRate,
      bonusRate,
      commission: revenue * (totalRate / 100),
      band,
      bonusApplied,
      bonusReason,
    };
  };

  const commissionDetails = salesByMargin.map(sale => ({
    ...sale,
    ...calculateCommission(sale.revenue, sale.margin, sale.categoryKey),
    bandKey: getBandKeyForMargin(sale.margin * 100, isSpecialRule),
  }));

  const totalRevenue = salesByMargin.reduce((sum, s) => sum + s.revenue, 0);
  const totalCommission = commissionDetails.reduce((sum, d) => sum + d.commission, 0);
  const effectiveRate = totalRevenue > 0 ? (totalCommission / totalRevenue) * 100 : 0;

  const handleBandClick = (bandKey: MarginBandKey, revenue: number, commission: number) => {
    setSelectedBand(bandKey);
    setExpectedRevenue(revenue);
    setExpectedCommission(commission);
    setDrawerOpen(true);
  };

  const handleTotalClick = () => {
    setSelectedBand('total');
    setExpectedRevenue(totalRevenue);
    setExpectedCommission(totalCommission);
    setDrawerOpen(true);
  };

  const getBonusReasonText = (reason: string) => {
    switch (reason) {
      case 'errors_blocked': return 'Bloqueado — 4+ erros no mês';
      case 'goal_not_met': return 'Meta da categoria não batida';
      case 'category_margin_low': return 'Margem da categoria < 40%';
      case 'no_category': return 'Sem categoria vinculada';
      case 'no_category_data': return 'Categoria sem meta definida';
      case 'rule_not_active': return 'Regra ativa a partir de Fev/2026';
      case 'eligible': return '';
      default: return '';
    }
  };

  const getBonusReasonIcon = (reason: string, applied: boolean) => {
    if (applied) return <CheckCircle2 className="h-3.5 w-3.5 text-emerald-500 shrink-0" />;
    if (reason === 'errors_blocked') return <AlertTriangle className="h-3.5 w-3.5 text-destructive shrink-0" />;
    return <XCircle className="h-3.5 w-3.5 text-muted-foreground shrink-0" />;
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.1 } },
  };

  const itemVariants = {
    hidden: { opacity: 0, x: -20 },
    visible: { opacity: 1, x: 0 },
  };

  return (
    <>
      <motion.div initial="hidden" animate="visible" variants={containerVariants}>
        <Card className="border-border bg-card">
          <CardHeader className="pb-4">
            <CardTitle className="flex items-center gap-2 text-base">
              <Calculator className="h-5 w-5 text-primary" />
              Calculadora de Comissão
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Alerta regra especial 130% */}
            {isSpecialRule && (
              <div className="flex items-center gap-2 p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/30">
                <Zap className="h-5 w-5 text-emerald-600 shrink-0" />
                <div>
                  <p className="text-sm font-semibold text-emerald-700">Regra Especial Ativada!</p>
                  <p className="text-xs text-emerald-600">
                    Meta geral acima de 130% atingida ({metaPercentage.toFixed(0)}%). Faixas de comissão mais agressivas aplicadas.
                  </p>
                </div>
              </div>
            )}

            {/* Commission Bands Reference */}
            <div className="p-3 bg-muted/30 rounded-lg">
              <p className="text-xs text-muted-foreground mb-2 text-center">
                {isSpecialRule ? 'Regra especial (130%+ da meta)' : 'Regra base por margem real'}
              </p>
              <div className={cn("grid gap-2 text-xs", activeBands.length <= 4 ? "grid-cols-4" : "grid-cols-5")}>
                {activeBands.map((band) => (
                  <div key={band.label} className="text-center p-2 rounded bg-background/50">
                    <p className="text-sm font-bold text-primary">{band.baseRate}%</p>
                    <p className="text-muted-foreground text-[10px]">
                      {band.maxMargin !== null && band.maxMargin !== undefined && band.minMargin !== -Infinity
                        ? `${band.minMargin}–${band.maxMargin}%`
                        : band.minMargin === -Infinity
                          ? `<0,5%`
                          : `≥${band.minMargin}%`}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Sales Breakdown */}
            <div className="space-y-2">
              <p className="text-sm font-medium text-muted-foreground">Detalhamento por Faixa de Margem</p>
              {commissionDetails.length > 0 ? (
                <motion.div variants={containerVariants} className="space-y-3">
                  {commissionDetails.map((detail, index) => {
                    const marginPercent = detail.margin * 100;
                    const marginColor = marginPercent >= 45 ? 'text-emerald-600' : marginPercent >= 35 ? 'text-blue-600' : marginPercent >= 20 ? 'text-amber-600' : 'text-red-600';
                    const marginBg = marginPercent >= 45 ? 'bg-emerald-500/10' : marginPercent >= 35 ? 'bg-blue-500/10' : marginPercent >= 20 ? 'bg-amber-500/10' : 'bg-red-500/10';

                    return (
                      <Collapsible key={index}>
                        <motion.div variants={itemVariants} className="rounded-lg border border-border/30 overflow-hidden">
                          <div
                            className="flex items-center justify-between p-3 bg-muted/20 cursor-pointer hover:bg-muted/40 transition-colors"
                            onClick={() => handleBandClick(detail.bandKey, detail.revenue, detail.commission)}
                            role="button"
                            tabIndex={0}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter' || e.key === ' ') handleBandClick(detail.bandKey, detail.revenue, detail.commission);
                            }}
                          >
                            <div className="flex items-center gap-3">
                              <div className={cn("px-2 py-1 rounded text-xs font-medium", marginBg, marginColor)}>
                                {isFinite(marginPercent) ? `${marginPercent.toFixed(1)}%` : '<0,5%'}
                              </div>
                              <span className="text-sm font-medium">{formatCurrency(detail.revenue)}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <span className="text-xs text-muted-foreground">{detail.rate.toFixed(1)}%</span>
                              <span className="font-semibold text-emerald-600">{formatCurrency(detail.commission)}</span>
                            </div>
                          </div>

                          <div className="px-3 py-2 bg-background/50 border-t border-border/20 space-y-1.5">
                            <div className="flex items-center justify-between text-xs">
                              <span className="text-muted-foreground">
                                Base: {detail.baseRate.toFixed(1)}% <span className="opacity-70">({detail.band.label})</span>
                              </span>
                              <span className="text-muted-foreground">{formatCurrency(detail.revenue * (detail.baseRate / 100))}</span>
                            </div>

                            <div className="flex items-center justify-between text-xs">
                              <div className="flex items-center gap-1.5">
                                {getBonusReasonIcon(detail.bonusReason, detail.bonusApplied)}
                                {detail.bonusApplied ? (
                                  <span className="text-emerald-600 font-medium">
                                    +{detail.bonusRate.toFixed(1)}% bônus categoria
                                  </span>
                                ) : (
                                  <span className="text-muted-foreground">
                                    {getBonusReasonText(detail.bonusReason)}
                                  </span>
                                )}
                              </div>
                              {detail.bonusApplied && (
                                <span className="text-emerald-600 font-medium">
                                  +{formatCurrency(detail.revenue * (detail.bonusRate / 100))}
                                </span>
                              )}
                            </div>

                            {detail.categoryKey && isNewRuleActive && (
                              <div className="flex items-center gap-1.5 text-xs pt-0.5">
                                <Info className="h-3 w-3 text-muted-foreground shrink-0" />
                                <span className="text-muted-foreground">
                                  Categoria: <span className="font-medium text-foreground">{detail.categoryKey}</span>
                                </span>
                                {(() => {
                                  const catElig = categoryEligibility.find(c => c.categoryKey === detail.categoryKey);
                                  if (!catElig) return null;
                                  return catElig.isEligible ? (
                                    <Badge variant="default" className="text-[10px] py-0 px-1.5 h-4 bg-emerald-500/15 text-emerald-700 border-emerald-500/30">
                                      Elegível
                                    </Badge>
                                  ) : (
                                    <Badge variant="secondary" className="text-[10px] py-0 px-1.5 h-4">
                                      Não elegível
                                    </Badge>
                                  );
                                })()}
                              </div>
                            )}
                          </div>
                        </motion.div>
                      </Collapsible>
                    );
                  })}
                </motion.div>
              ) : (
                <p className="text-sm text-muted-foreground text-center py-4">
                  Nenhuma venda registrada
                </p>
              )}
            </div>

            {/* Bonus summary alerts */}
            {hasLostBonus && (
              <div className="flex items-center gap-2 p-3 rounded-lg bg-destructive/10 border border-destructive/20">
                <AlertTriangle className="h-4 w-4 text-destructive" />
                <span className="text-sm text-destructive">
                  Bônus bloqueado por excesso de erros (4+) neste mês
                </span>
              </div>
            )}

            {!hasLostBonus && !isNewRuleActive && (
              <div className="flex items-center gap-2 p-3 rounded-lg bg-amber-500/10 border border-amber-500/20">
                <span className="text-sm text-amber-700 dark:text-amber-400">
                  📅 Regra de bônus por categoria ativa a partir de Fevereiro/2026
                </span>
              </div>
            )}

            {/* Total */}
            <div
              className="pt-4 border-t border-border/50 cursor-pointer hover:bg-muted/20 -mx-6 px-6 pb-2 rounded-b-lg transition-colors"
              onClick={handleTotalClick}
              role="button"
              tabIndex={0}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') handleTotalClick();
              }}
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total do Período</p>
                  <p className="text-xs text-muted-foreground">
                    Taxa efetiva: {effectiveRate.toFixed(2)}%
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-2xl font-bold text-emerald-600 hover:underline">
                    {formatCurrency(totalCommission)}
                  </p>
                  <p className="text-xs text-muted-foreground hover:underline">
                    sobre {formatCurrency(totalRevenue)}
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      <CommissionOrdersDrawer
        open={drawerOpen}
        onOpenChange={setDrawerOpen}
        sellerId={sellerId}
        sellerName={sellerName}
        month={month}
        year={year}
        band={selectedBand}
        expectedRevenue={expectedRevenue}
        expectedCommission={expectedCommission}
        bonusPercentage={bonusPercentage}
        hasLostBonus={hasLostBonus}
        isSpecialRule={isSpecialRule}
      />
    </>
  );
}
