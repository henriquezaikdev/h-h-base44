import { useState } from 'react';
import { motion } from 'framer-motion';
import { UserPlus, Trophy, Star, Medal, RefreshCw, Award, ChevronRight, Clock, CheckCircle2, Target } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { useNewClientData } from '@/hooks/useNewClientData';
import { NewClientsDetailSheet } from './NewClientsDetailSheet';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

interface NewClientsCardProps {
  sellerId: string;
  sellerName: string;
  month?: number;
  year?: number;
  isAdmin?: boolean;
}

async function fetchSellerTarget(sellerId: string): Promise<{ target: number; reward: number }> {
  const { data } = await supabase
    .from('seller_levels')
    .select('new_clients_target, new_clients_stars_reward')
    .eq('seller_id', sellerId)
    .maybeSingle();
  
  return {
    target: data?.new_clients_target ?? 3,
    reward: data?.new_clients_stars_reward ?? 2,
  };
}

export function NewClientsCard({ 
  sellerId, 
  sellerName, 
  month, 
  year,
  isAdmin = false 
}: NewClientsCardProps) {
  const [isDetailOpen, setIsDetailOpen] = useState(false);
  const targetMonth = month ?? new Date().getMonth() + 1;
  const targetYear = year ?? new Date().getFullYear();

  const { data: targetData } = useQuery({
    queryKey: ['seller-new-clients-target', sellerId],
    queryFn: () => fetchSellerTarget(sellerId),
    staleTime: 1000 * 60 * 10,
  });

  const { 
    currentMonth, 
    ranking, 
    totalNewClientsThisMonth,
    verificationCounts,
    loading, 
    refetch,
    recalculateMonth,
    awardLeader 
  } = useNewClientData(sellerId, targetMonth, targetYear);

  const pendingCount = verificationCounts?.pending || 0;
  const totalToVerify = verificationCounts?.total || 0;
  const verifiedPercent = totalToVerify > 0 
    ? Math.round(((totalToVerify - pendingCount) / totalToVerify) * 100) 
    : 100;

  const handleRecalculate = async () => {
    try {
      await recalculateMonth();
      toast.success('Clientes novos recalculados com sucesso');
    } catch {
      toast.error('Erro ao recalcular');
    }
  };

  const handleAwardLeader = async () => {
    const result = await awardLeader(targetMonth, targetYear);
    if (result.success) {
      toast.success('Prêmio de 2 estrelas bronze concedido ao líder!');
    } else {
      toast.error(result.message || 'Erro ao conceder prêmio');
    }
  };

  const isLeader = currentMonth?.isLeader && currentMonth.newClientsCount > 0;
  const rank = currentMonth?.rank || '-';
  const count = currentMonth?.newClientsCount || 0;
  const target = targetData?.target ?? 3;
  const reward = targetData?.reward ?? 2;
  const isGoalMet = count >= target;
  const progressPercent = Math.min((count / target) * 100, 100);

  const monthLabel = format(new Date(targetYear, targetMonth - 1, 1), "MMMM 'de' yyyy", { locale: ptBR });

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        onClick={() => setIsDetailOpen(true)}
        className="cursor-pointer"
      >
        <Card className={cn(
          "relative overflow-hidden transition-all hover:shadow-lg hover:scale-[1.01]",
          isLeader && "bg-gradient-to-br from-amber-500/10 via-yellow-500/5 to-orange-500/5 border-amber-500/30",
          isGoalMet && !isLeader && "bg-gradient-to-br from-emerald-500/10 to-background border-emerald-500/30"
        )}>
        {/* Leader Badge */}
        {isLeader && (
          <motion.div
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: 1 }}
            className="absolute top-3 right-3"
          >
            <Badge className="bg-gradient-to-r from-amber-500 to-yellow-500 text-white gap-1">
              <Trophy className="h-3 w-3" />
              Líder do Mês
            </Badge>
          </motion.div>
          )}

          {/* Goal Met Badge */}
          {isGoalMet && !isLeader && (
            <motion.div
              initial={{ opacity: 0, scale: 0 }}
              animate={{ opacity: 1, scale: 1 }}
              className="absolute top-3 right-3"
            >
              <Badge className="bg-emerald-500 text-white gap-1 border-0">
                <Target className="h-3 w-3" />
                Meta Batida
              </Badge>
            </motion.div>
          )}
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <div className={cn(
              "w-8 h-8 rounded-lg flex items-center justify-center",
              isLeader 
                ? "bg-gradient-to-br from-amber-500 to-yellow-500" 
                : "bg-gradient-to-br from-violet-500 to-purple-500"
            )}>
              <UserPlus className="h-4 w-4 text-white" />
            </div>
            <span>Clientes Novos</span>
            {isAdmin && (
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="h-6 w-6 ml-auto"
                      onClick={handleRecalculate}
                      disabled={loading}
                    >
                      <RefreshCw className={cn("h-3.5 w-3.5", loading && "animate-spin")} />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>Recalcular clientes novos</TooltipContent>
                </Tooltip>
              </TooltipProvider>
            )}
          </CardTitle>
          <p className="text-xs text-muted-foreground capitalize">{monthLabel}</p>
        </CardHeader>

        <CardContent className="space-y-4">
          {/* Main Stats */}
          <div className="grid grid-cols-3 gap-3">
            <div className="text-center">
              <motion.p 
                key={count}
                initial={{ scale: 0.8 }}
                animate={{ scale: 1 }}
                className={cn(
                  "text-3xl font-bold",
                  isGoalMet ? "text-emerald-600" : isLeader ? "text-amber-600" : "text-violet-600"
                )}
              >
                {count}
              </motion.p>
              <p className="text-xs text-muted-foreground">Conquistados</p>
            </div>
            <div className="text-center">
              <p className="text-3xl font-bold text-muted-foreground">{target}</p>
              <p className="text-xs text-muted-foreground">Meta</p>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center gap-1">
                <Medal className={cn(
                  "h-5 w-5",
                  rank === 1 && "text-amber-500",
                  rank === 2 && "text-slate-400",
                  rank === 3 && "text-orange-500",
                  typeof rank === 'number' && rank > 3 && "text-muted-foreground"
                )} />
                <span className="text-3xl font-bold">{rank}º</span>
              </div>
              <p className="text-xs text-muted-foreground">Ranking</p>
            </div>
          </div>

          {/* Goal Progress */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-muted-foreground">Progresso da Meta</span>
              <span className={cn(
                "font-medium",
                isGoalMet ? "text-emerald-600" : "text-muted-foreground"
              )}>
                {count}/{target} {isGoalMet && `(+${reward} ⭐)`}
              </span>
            </div>
            <Progress 
              value={progressPercent} 
              className={cn("h-2", isGoalMet && "[&>div]:bg-emerald-500")}
            />
          </div>

          {/* Verification Status Indicator */}
          {totalToVerify > 0 && (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground flex items-center gap-1">
                  {pendingCount > 0 ? (
                    <>
                      <Clock className="h-3 w-3 text-amber-500" />
                      <span className="text-amber-500 font-medium">{pendingCount} pendente(s)</span>
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="h-3 w-3 text-emerald-500" />
                      <span className="text-emerald-500 font-medium">Todos verificados</span>
                    </>
                  )}
                </span>
                <span className="text-muted-foreground">
                  {verificationCounts?.confirmed || 0} ✓ / {verificationCounts?.denied || 0} ✗
                </span>
              </div>
              <Progress 
                value={verifiedPercent} 
                className="h-1.5"
              />
            </div>
          )}

          {/* Info Text */}
          <div className="text-sm text-muted-foreground bg-muted/30 rounded-lg p-3">
            <p>
              {sellerName} conquistou <strong className="text-foreground">{count}</strong> cliente(s) novo(s) 
              em <span className="capitalize">{monthLabel}</span>.
              {isLeader && (
                <span className="text-amber-600 font-medium"> 🏆 Líder do mês!</span>
              )}
            </p>
          </div>

          {/* Leader Award Button (Admin only) */}
          {isAdmin && isLeader && !currentMonth?.leaderAwardGiven && (
            <Button 
              onClick={handleAwardLeader}
              className="w-full gap-2 bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-600 hover:to-yellow-600"
            >
              <Award className="h-4 w-4" />
              Conceder 2 Estrelas Bronze
            </Button>
          )}

          {currentMonth?.leaderAwardGiven && (
            <div className="flex items-center justify-center gap-2 text-sm text-amber-600 bg-amber-500/10 rounded-lg p-2">
              <Star className="h-4 w-4 fill-amber-500" />
              <span>Prêmio já concedido!</span>
              <Star className="h-4 w-4 fill-amber-500" />
            </div>
          )}

          {/* Mini Ranking (Admin only) */}
          {isAdmin && ranking.length > 0 && (
            <div className="space-y-2 pt-2 border-t border-border/50">
              <p className="text-xs font-medium text-muted-foreground">Ranking do Mês</p>
              {ranking.slice(0, 5).map((seller, index) => (
                <div 
                  key={seller.sellerId}
                  className={cn(
                    "flex items-center justify-between text-sm p-2 rounded-lg",
                    seller.sellerId === sellerId && "bg-primary/10"
                  )}
                >
                  <div className="flex items-center gap-2">
                    <span className={cn(
                      "w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold",
                      index === 0 && "bg-amber-500 text-white",
                      index === 1 && "bg-slate-400 text-white",
                      index === 2 && "bg-orange-500 text-white",
                      index > 2 && "bg-muted text-muted-foreground"
                    )}>
                      {index + 1}
                    </span>
                    <span className={cn(
                      "font-medium",
                      seller.sellerId === sellerId && "text-primary"
                    )}>
                      {seller.sellerName}
                    </span>
                  </div>
                  <Badge variant="secondary">{seller.newClientsCount}</Badge>
                </div>
              ))}
            </div>
          )}
        </CardContent>

        {/* Click indicator */}
        <div className="absolute bottom-3 right-3 text-muted-foreground/50">
          <ChevronRight className="h-4 w-4" />
        </div>
      </Card>
    </motion.div>

    <NewClientsDetailSheet
      open={isDetailOpen}
      onOpenChange={setIsDetailOpen}
      sellerId={sellerId}
      sellerName={sellerName}
      month={targetMonth}
      year={targetYear}
    />
  </>
  );
}
