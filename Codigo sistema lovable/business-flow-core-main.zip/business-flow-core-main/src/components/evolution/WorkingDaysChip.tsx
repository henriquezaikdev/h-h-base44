import { useState, useEffect } from 'react';
import { Calendar, Settings2, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar as CalendarComponent } from '@/components/ui/calendar';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isWeekend } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { cn } from '@/lib/utils';

interface WorkingDaysChipProps {
  isAdmin: boolean;
  onConfigSaved?: () => void;
}

interface WorkMonthConfig {
  id?: string;
  yearMonth: string;
  workingDays: number;
  operationalStartDate: Date | null;
  isConfigured: boolean;
}

export function WorkingDaysChip({ isAdmin, onConfigSaved }: WorkingDaysChipProps) {
  const [config, setConfig] = useState<WorkMonthConfig | null>(null);
  const [editOpen, setEditOpen] = useState(false);
  const [workingDays, setWorkingDays] = useState(22);
  const [operationalStartDate, setOperationalStartDate] = useState<Date | undefined>();
  const [saving, setSaving] = useState(false);

  const today = new Date();
  const yearMonth = format(today, 'yyyy-MM');
  const monthStart = startOfMonth(today);
  const monthEnd = endOfMonth(today);

  // Calcular dias úteis automaticamente
  const autoCalculatedDays = eachDayOfInterval({ start: monthStart, end: monthEnd })
    .filter(d => !isWeekend(d)).length;

  useEffect(() => {
    fetchConfig();
  }, []);

  const fetchConfig = async () => {
    const { data } = await supabase
      .from('work_month_config')
      .select('*')
      .eq('year_month', yearMonth)
      .maybeSingle();

    if (data) {
      setConfig({
        id: data.id,
        yearMonth: data.year_month,
        workingDays: data.working_days,
        operationalStartDate: data.operational_start_date ? new Date(data.operational_start_date) : null,
        isConfigured: true,
      });
      setWorkingDays(data.working_days);
      setOperationalStartDate(data.operational_start_date ? new Date(data.operational_start_date) : undefined);
    } else {
      setConfig({
        yearMonth,
        workingDays: autoCalculatedDays,
        operationalStartDate: null,
        isConfigured: false,
      });
      setWorkingDays(autoCalculatedDays);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const { data: seller } = await supabase.rpc('get_my_seller_id');
      
      const payload = {
        year_month: yearMonth,
        working_days: workingDays,
        operational_start_date: operationalStartDate ? format(operationalStartDate, 'yyyy-MM-dd') : null,
        updated_by: seller,
      };

      if (config?.id) {
        const { error } = await supabase
          .from('work_month_config')
          .update(payload)
          .eq('id', config.id);

        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('work_month_config')
          .insert({ ...payload, created_by: seller });

        if (error) throw error;
      }

      toast.success('Dias úteis atualizados!');
      setEditOpen(false);
      fetchConfig();
      onConfigSaved?.();
    } catch (error) {
      console.error('Error saving work month config:', error);
      toast.error('Erro ao salvar configuração');
    } finally {
      setSaving(false);
    }
  };

  const displayDays = config?.workingDays || autoCalculatedDays;
  const isConfigured = config?.isConfigured;

  // Vendedor: apenas visualiza
  if (!isAdmin) {
    return (
      <div className="flex items-center gap-2">
        <Badge 
          variant="outline" 
          className={cn(
            "gap-1.5 px-3 py-1.5",
            !isConfigured && "border-amber-500/50 bg-amber-500/10 text-amber-600"
          )}
        >
          <Calendar className="h-3.5 w-3.5" />
          <span>{displayDays} dias úteis</span>
        </Badge>
        {!isConfigured && (
          <span className="text-xs text-amber-600">(padrão)</span>
        )}
      </div>
    );
  }

  // Admin: pode configurar
  return (
    <Popover open={editOpen} onOpenChange={setEditOpen}>
      <PopoverTrigger asChild>
        <Button 
          variant="outline" 
          size="sm"
          className={cn(
            "gap-2",
            !isConfigured && "border-amber-500/50 bg-amber-500/10 text-amber-600 hover:bg-amber-500/20"
          )}
        >
          <Calendar className="h-4 w-4" />
          <span>{displayDays} dias úteis</span>
          <Settings2 className="h-3.5 w-3.5" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80" align="end">
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="font-medium text-sm">
              Configurar Dias Úteis
            </h4>
            <span className="text-xs text-muted-foreground">
              {format(today, 'MMMM yyyy', { locale: ptBR })}
            </span>
          </div>

          {!isConfigured && (
            <div className="flex items-start gap-2 p-2 bg-amber-500/10 rounded-md">
              <AlertTriangle className="h-4 w-4 text-amber-500 mt-0.5" />
              <p className="text-xs text-amber-700">
                Dias úteis não configurados. Usando cálculo automático ({autoCalculatedDays} seg-sex).
              </p>
            </div>
          )}

          <div className="space-y-2">
            <label className="text-sm font-medium">Dias Úteis do Mês</label>
            <div className="flex items-center gap-2">
              <Input
                type="number"
                min={1}
                max={31}
                value={workingDays}
                onChange={(e) => setWorkingDays(parseInt(e.target.value) || 0)}
                className="w-20"
              />
              <span className="text-xs text-muted-foreground">
                (Auto: {autoCalculatedDays})
              </span>
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Início Operacional (opcional)</label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  size="sm"
                  className={cn(
                    "w-full justify-start text-left font-normal",
                    !operationalStartDate && "text-muted-foreground"
                  )}
                >
                  <Calendar className="mr-2 h-4 w-4" />
                  {operationalStartDate 
                    ? format(operationalStartDate, 'dd/MM/yyyy') 
                    : 'Selecionar'}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <CalendarComponent
                  mode="single"
                  selected={operationalStartDate}
                  onSelect={setOperationalStartDate}
                  disabled={(date) => date < monthStart || date > monthEnd}
                  initialFocus
                  locale={ptBR}
                />
              </PopoverContent>
            </Popover>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <Button variant="ghost" size="sm" onClick={() => setEditOpen(false)}>
              Cancelar
            </Button>
            <Button size="sm" onClick={handleSave} disabled={saving}>
              {saving ? 'Salvando...' : 'Salvar'}
            </Button>
          </div>
        </div>
      </PopoverContent>
    </Popover>
  );
}
