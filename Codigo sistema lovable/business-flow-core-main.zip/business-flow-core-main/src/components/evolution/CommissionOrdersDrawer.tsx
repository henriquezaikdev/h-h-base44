import { useState, useMemo } from 'react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { 
  X, 
  ChevronDown, 
  ChevronRight, 
  Download, 
  Search, 
  AlertTriangle,
  Package,
  FileText
} from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { 
  Drawer, 
  DrawerContent, 
  DrawerHeader, 
  DrawerTitle,
  DrawerClose 
} from '@/components/ui/drawer';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';
import { Skeleton } from '@/components/ui/skeleton';
import { cn } from '@/lib/utils';
import {
  COMMISSION_BANDS_NORMAL,
  COMMISSION_BANDS_SPECIAL,
  findCommissionBand,
  getBandKeyForMargin,
  type MarginBandKey,
  type CommissionBand,
} from '@/lib/commissionConfig';

interface CommissionOrdersDrawerProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  sellerId: string;
  sellerName: string;
  month: number;
  year: number;
  band: MarginBandKey;
  expectedRevenue: number;
  expectedCommission: number;
  bonusPercentage: number;
  hasLostBonus: boolean;
  isSpecialRule?: boolean;
}

interface OrderWithItems {
  id: string;
  order_number: string | null;
  order_date: string | null;
  total: number | null;
  profit_margin: number | null;
  profit: number | null;
  client: {
    id: string;
    company_name: string;
  } | null;
  items: OrderItem[];
}

interface OrderItem {
  id: string;
  product_name: string;
  quantity: number | null;
  unit_price: number | null;
  subtotal: number | null;
  cost_price: number | null;
  cost_subtotal: number | null;
  missing_cost: boolean | null;
}

function formatCurrency(value: number) {
  return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
}

export function CommissionOrdersDrawer({
  open,
  onOpenChange,
  sellerId,
  sellerName,
  month,
  year,
  band,
  expectedRevenue,
  expectedCommission,
  bonusPercentage,
  hasLostBonus,
  isSpecialRule = false,
}: CommissionOrdersDrawerProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [onlyMissingCost, setOnlyMissingCost] = useState(false);
  const [sortBy, setSortBy] = useState<'date' | 'value' | 'commission'>('date');
  const [expandedOrders, setExpandedOrders] = useState<Set<string>>(new Set());

  const activeBands = isSpecialRule ? COMMISSION_BANDS_SPECIAL : COMMISSION_BANDS_NORMAL;
  const periodLabel = format(new Date(year, month - 1, 1), "MMMM 'de' yyyy", { locale: ptBR });

  // Build BAND_CONFIG from active bands for filtering
  const getBandConfig = (bk: MarginBandKey) => {
    if (bk === 'total') return { label: 'Total do Período', minMargin: -Infinity, maxMargin: null as number | null, rate: 0 };
    if (isSpecialRule) {
      switch (bk) {
        case 'premium': return { label: 'Alta (≥30%)', minMargin: 30, maxMargin: null as number | null, rate: 2.0 };
        case 'alta': return { label: 'Alta (≥30%)', minMargin: 30, maxMargin: null as number | null, rate: 2.0 };
        case 'padrao': return { label: 'Média (15–29,99%)', minMargin: 15, maxMargin: 29.99, rate: 1.0 };
        case 'baixa': return { label: 'Baixa (<15%)', minMargin: -Infinity, maxMargin: 14.99, rate: 0.5 };
      }
    }
    switch (bk) {
      case 'premium': return { label: 'Premium (≥45%)', minMargin: 45, maxMargin: null as number | null, rate: 2.0 };
      case 'alta': return { label: 'Alta (35–44,99%)', minMargin: 35, maxMargin: 44.99, rate: 1.3 };
      case 'padrao': return { label: 'Média (20–34,99%)', minMargin: 20, maxMargin: 34.99, rate: 1.0 };
      case 'baixa': return { label: 'Baixa (<20%)', minMargin: -Infinity, maxMargin: 19.99, rate: 0.5 };
    }
  };

  const bandConfig = getBandConfig(band)!;

  // Fetch orders with items
  const { data: orders, isLoading } = useQuery({
    queryKey: ['commission-orders', sellerId, month, year, band, isSpecialRule],
    queryFn: async () => {
      const startDate = `${year}-${String(month).padStart(2, '0')}-01`;
      const endDate = `${year}-${String(month).padStart(2, '0')}-${new Date(year, month, 0).getDate()}`;

      const { data: ordersData, error } = await supabase
        .from('orders')
        .select(`
          id,
          order_number,
          order_date,
          total,
          profit_margin,
          margem_real,
          profit,
          client:clients!orders_client_id_fkey (
            id,
            company_name
          )
        `)
        .eq('seller_id', sellerId)
        .eq('is_accountable', true)
        .gte('order_date', startDate)
        .lte('order_date', endDate)
        .order('order_date', { ascending: false });

      if (error) throw error;

      let filteredOrders = ordersData || [];
      if (band !== 'total') {
        filteredOrders = filteredOrders.filter(order => {
          let margin: number;
          const margemReal = (order as any).margem_real;
          if (margemReal !== null && margemReal !== undefined) {
            margin = Number(margemReal) * 100;
          } else {
            margin = order.profit_margin || 0;
          }
          const orderBand = getBandKeyForMargin(margin, isSpecialRule);
          return orderBand === band || (band === 'alta' && orderBand === 'premium');
        });
      }

      const ordersWithItems: OrderWithItems[] = await Promise.all(
        filteredOrders.map(async (order) => {
          const { data: items } = await supabase
            .from('order_items')
            .select('id, product_name, quantity, unit_price, subtotal, cost_price, cost_subtotal, missing_cost')
            .eq('order_id', order.id);

          return {
            ...order,
            client: order.client as { id: string; company_name: string } | null,
            items: (items || []) as OrderItem[],
          };
        })
      );

      return ordersWithItems;
    },
    enabled: open && !!sellerId,
  });

  const calculateOrderCommission = (order: OrderWithItems) => {
    const margemReal = (order as any).margem_real;
    let margin: number;
    if (margemReal !== null && margemReal !== undefined) {
      margin = Number(margemReal) * 100;
    } else {
      margin = order.profit_margin || 0;
    }
    if (!isFinite(margin)) margin = 0;
    const revenue = order.total || 0;
    const commBand = findCommissionBand(margin, activeBands);
    const rate = commBand.baseRate;

    return {
      band: getBandKeyForMargin(margin, isSpecialRule),
      rate,
      margin,
      commission: revenue * (rate / 100),
    };
  };

  const filteredOrders = useMemo(() => {
    if (!orders) return [];
    let result = [...orders];

    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      result = result.filter(order =>
        order.client?.company_name.toLowerCase().includes(term) ||
        order.order_number?.toLowerCase().includes(term)
      );
    }

    if (onlyMissingCost) {
      result = result.filter(order =>
        order.items.some(item => item.missing_cost)
      );
    }

    result.sort((a, b) => {
      switch (sortBy) {
        case 'value':
          return (b.total || 0) - (a.total || 0);
        case 'commission':
          return calculateOrderCommission(b).commission - calculateOrderCommission(a).commission;
        case 'date':
        default:
          return (b.order_date || '').localeCompare(a.order_date || '');
      }
    });

    return result;
  }, [orders, searchTerm, onlyMissingCost, sortBy]);

  const totals = useMemo(() => {
    if (!filteredOrders.length) return { revenue: 0, commission: 0, count: 0 };
    return filteredOrders.reduce(
      (acc, order) => {
        const { commission } = calculateOrderCommission(order);
        return {
          revenue: acc.revenue + (order.total || 0),
          commission: acc.commission + commission,
          count: acc.count + 1,
        };
      },
      { revenue: 0, commission: 0, count: 0 }
    );
  }, [filteredOrders]);

  const hasInconsistency = band !== 'total' && (
    Math.abs(totals.revenue - expectedRevenue) > 0.01 ||
    Math.abs(totals.commission - expectedCommission) > 0.01
  );

  if (hasInconsistency) {
    console.warn('[CommissionOrdersDrawer] Inconsistência detectada:', {
      band,
      expectedRevenue,
      actualRevenue: totals.revenue,
      expectedCommission,
      actualCommission: totals.commission,
    });
  }

  const toggleOrderExpand = (orderId: string) => {
    setExpandedOrders(prev => {
      const next = new Set(prev);
      if (next.has(orderId)) {
        next.delete(orderId);
      } else {
        next.add(orderId);
      }
      return next;
    });
  };

  const exportCSV = () => {
    if (!filteredOrders.length) return;
    const headers = ['Data', 'Nº Pedido', 'Cliente', 'Valor', 'Margem %', 'Faixa', 'Comissão'];
    const rows = filteredOrders.map(order => {
      const { band: orderBand, commission, margin } = calculateOrderCommission(order);
      const orderBandConfig = getBandConfig(orderBand)!;
      return [
        order.order_date ? format(new Date(order.order_date), 'dd/MM/yyyy') : '',
        order.order_number || order.id.slice(0, 8),
        order.client?.company_name || 'N/A',
        (order.total || 0).toFixed(2),
        margin.toFixed(1),
        orderBandConfig.label,
        commission.toFixed(2),
      ];
    });

    const csvContent = [
      headers.join(';'),
      ...rows.map(row => row.join(';')),
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `comissao_${sellerName}_${month}_${year}_${band}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <Drawer open={open} onOpenChange={onOpenChange}>
      <DrawerContent className="max-h-[90vh]">
        <DrawerHeader className="border-b">
          <div className="flex items-center justify-between">
            <div>
              <DrawerTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5 text-primary" />
                Pedidos usados no cálculo
              </DrawerTitle>
              <p className="text-sm text-muted-foreground mt-1">
                Vendedor: {sellerName} | Período: {periodLabel} | Filtro: {bandConfig.label}
              </p>
            </div>
            <DrawerClose asChild>
              <Button variant="ghost" size="icon">
                <X className="h-4 w-4" />
              </Button>
            </DrawerClose>
          </div>
        </DrawerHeader>

        <div className="p-4 space-y-4">
          {/* Summary */}
          <div className="grid grid-cols-3 gap-4">
            <div className="p-4 rounded-lg bg-muted/30 border">
              <p className="text-sm text-muted-foreground">Total de Pedidos</p>
              <p className="text-2xl font-bold">{totals.count}</p>
            </div>
            <div className="p-4 rounded-lg bg-muted/30 border">
              <p className="text-sm text-muted-foreground">Valor Total</p>
              <p className="text-2xl font-bold text-foreground">{formatCurrency(totals.revenue)}</p>
              {band !== 'total' && Math.abs(totals.revenue - expectedRevenue) > 0.01 && (
                <p className="text-xs text-destructive flex items-center gap-1">
                  <AlertTriangle className="h-3 w-3" />
                  Esperado: {formatCurrency(expectedRevenue)}
                </p>
              )}
            </div>
            <div className="p-4 rounded-lg bg-emerald-500/10 border border-emerald-500/20">
              <p className="text-sm text-muted-foreground">Comissão Total</p>
              <p className="text-2xl font-bold text-emerald-600">{formatCurrency(totals.commission)}</p>
              {band !== 'total' && Math.abs(totals.commission - expectedCommission) > 0.01 && (
                <p className="text-xs text-destructive flex items-center gap-1">
                  <AlertTriangle className="h-3 w-3" />
                  Esperado: {formatCurrency(expectedCommission)}
                </p>
              )}
            </div>
          </div>

          {hasInconsistency && (
            <div className="p-3 rounded-lg bg-destructive/10 border border-destructive/20 flex items-center gap-2">
              <AlertTriangle className="h-4 w-4 text-destructive" />
              <span className="text-sm text-destructive">
                Inconsistência detectada entre valores calculados e exibidos.
              </span>
            </div>
          )}

          {/* Filters */}
          <div className="flex flex-wrap items-center gap-3">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Buscar por cliente ou nº pedido..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="flex items-center gap-2">
              <Checkbox
                id="missing-cost"
                checked={onlyMissingCost}
                onCheckedChange={(checked) => setOnlyMissingCost(checked as boolean)}
              />
              <label htmlFor="missing-cost" className="text-sm text-muted-foreground cursor-pointer">
                Somente sem custo
              </label>
            </div>
            <Select value={sortBy} onValueChange={(v) => setSortBy(v as typeof sortBy)}>
              <SelectTrigger className="w-[160px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="date">Data (recente)</SelectItem>
                <SelectItem value="value">Maior valor</SelectItem>
                <SelectItem value="commission">Maior comissão</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" size="sm" onClick={exportCSV} disabled={!filteredOrders.length}>
              <Download className="h-4 w-4 mr-2" />
              Exportar CSV
            </Button>
          </div>

          {/* Orders Table */}
          <ScrollArea className="h-[400px] border rounded-lg">
            {isLoading ? (
              <div className="p-4 space-y-3">
                {[1, 2, 3, 4, 5].map(i => (
                  <Skeleton key={i} className="h-16 w-full" />
                ))}
              </div>
            ) : filteredOrders.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-muted-foreground">
                <Package className="h-12 w-12 mb-2 opacity-30" />
                <p>Nenhum pedido encontrado</p>
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-10"></TableHead>
                    <TableHead>Data</TableHead>
                    <TableHead>Nº Pedido</TableHead>
                    <TableHead>Cliente</TableHead>
                    <TableHead className="text-right">Valor</TableHead>
                    <TableHead className="text-center">Margem</TableHead>
                    <TableHead>Faixa</TableHead>
                    <TableHead className="text-right">Comissão</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredOrders.map(order => {
                    const { band: orderBand, rate, margin, commission } = calculateOrderCommission(order);
                    const isExpanded = expandedOrders.has(order.id);
                    const hasMissingCost = order.items.some(item => item.missing_cost);
                    const orderBandConfig = getBandConfig(orderBand)!;

                    return (
                      <Collapsible key={order.id} open={isExpanded}>
                        <TableRow
                          className={cn(
                            "cursor-pointer hover:bg-muted/50",
                            isExpanded && "bg-muted/30"
                          )}
                          onClick={() => toggleOrderExpand(order.id)}
                        >
                          <TableCell>
                            <CollapsibleTrigger asChild>
                              <Button variant="ghost" size="icon" className="h-6 w-6">
                                {isExpanded ? (
                                  <ChevronDown className="h-4 w-4" />
                                ) : (
                                  <ChevronRight className="h-4 w-4" />
                                )}
                              </Button>
                            </CollapsibleTrigger>
                          </TableCell>
                          <TableCell>
                            {order.order_date
                              ? format(new Date(order.order_date), 'dd/MM/yyyy')
                              : '-'
                            }
                          </TableCell>
                          <TableCell className="font-mono text-xs">
                            {order.order_number || order.id.slice(0, 8)}
                          </TableCell>
                          <TableCell className="max-w-[200px] truncate">
                            {order.client?.company_name || 'N/A'}
                          </TableCell>
                          <TableCell className="text-right font-medium">
                            {formatCurrency(order.total || 0)}
                          </TableCell>
                          <TableCell className="text-center">
                            <Badge variant="outline" className={cn(
                              "text-xs",
                              orderBand === 'premium' && "bg-emerald-500/10 text-emerald-600 border-emerald-500/30",
                              orderBand === 'alta' && "bg-blue-500/10 text-blue-600 border-blue-500/30",
                              orderBand === 'padrao' && "bg-amber-500/10 text-amber-600 border-amber-500/30",
                              orderBand === 'baixa' && "bg-red-500/10 text-red-600 border-red-500/30"
                            )}>
                              {margin.toFixed(1)}%
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <span className="text-xs text-muted-foreground">
                                {orderBandConfig.label.split(' ')[0]}
                              </span>
                              {hasMissingCost && (
                                <Badge variant="destructive" className="text-xs">
                                  Custo ausente
                                </Badge>
                              )}
                            </div>
                          </TableCell>
                          <TableCell className="text-right font-semibold text-emerald-600">
                            {formatCurrency(commission)}
                            <span className="text-xs text-muted-foreground ml-1">
                              ({rate.toFixed(1)}%)
                            </span>
                          </TableCell>
                        </TableRow>
                        <CollapsibleContent asChild>
                          <tr>
                            <td colSpan={8} className="p-0">
                              <div className="bg-muted/20 p-4 border-t">
                                <p className="text-sm font-medium mb-2">Itens do Pedido</p>
                                <Table>
                                  <TableHeader>
                                    <TableRow>
                                      <TableHead>Produto</TableHead>
                                      <TableHead className="text-center">Qtd</TableHead>
                                      <TableHead className="text-right">Preço Unit.</TableHead>
                                      <TableHead className="text-right">Custo Unit.</TableHead>
                                      <TableHead className="text-right">Subtotal</TableHead>
                                      <TableHead className="text-center">Status</TableHead>
                                    </TableRow>
                                  </TableHeader>
                                  <TableBody>
                                    {order.items.map(item => (
                                      <TableRow key={item.id}>
                                        <TableCell className="max-w-[250px] truncate">
                                          {item.product_name}
                                        </TableCell>
                                        <TableCell className="text-center">
                                          {item.quantity || 0}
                                        </TableCell>
                                        <TableCell className="text-right">
                                          {formatCurrency(item.unit_price || 0)}
                                        </TableCell>
                                        <TableCell className="text-right">
                                          {item.cost_price
                                            ? formatCurrency(item.cost_price)
                                            : <span className="text-muted-foreground">-</span>
                                          }
                                        </TableCell>
                                        <TableCell className="text-right font-medium">
                                          {formatCurrency(item.subtotal || 0)}
                                        </TableCell>
                                        <TableCell className="text-center">
                                          {item.missing_cost ? (
                                            <Badge variant="destructive" className="text-xs">
                                              Sem custo
                                            </Badge>
                                          ) : (
                                            <Badge variant="secondary" className="text-xs">
                                              OK
                                            </Badge>
                                          )}
                                        </TableCell>
                                      </TableRow>
                                    ))}
                                  </TableBody>
                                </Table>
                                <div className="flex justify-end mt-3 pt-3 border-t gap-6 text-sm">
                                  <div>
                                    <span className="text-muted-foreground">Total do Pedido:</span>
                                    <span className="font-bold ml-2">{formatCurrency(order.total || 0)}</span>
                                  </div>
                                  <div>
                                    <span className="text-muted-foreground">Comissão:</span>
                                    <span className="font-bold text-emerald-600 ml-2">{formatCurrency(commission)}</span>
                                  </div>
                                </div>
                              </div>
                            </td>
                          </tr>
                        </CollapsibleContent>
                      </Collapsible>
                    );
                  })}
                </TableBody>
              </Table>
            )}
          </ScrollArea>
        </div>
      </DrawerContent>
    </Drawer>
  );
}
