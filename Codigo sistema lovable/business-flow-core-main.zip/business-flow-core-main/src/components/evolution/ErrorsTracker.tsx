import { useState } from 'react';
import { motion } from 'framer-motion';
import { AlertOctagon, Plus, Trash2, Calendar } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface Error {
  id: string;
  error_type: string;
  description: string | null;
  error_date: string;
  created_at: string;
}

interface ErrorsTrackerProps {
  sellerId: string;
  errors: Error[];
  maxErrors: number;
  onErrorAdded: () => void;
  onErrorDeleted: () => void;
  isAdmin: boolean;
}

export function ErrorsTracker({
  sellerId,
  errors,
  maxErrors,
  onErrorAdded,
  onErrorDeleted,
  isAdmin
}: ErrorsTrackerProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [errorType, setErrorType] = useState('');
  const [description, setDescription] = useState('');
  const [loading, setLoading] = useState(false);

  const errorsCount = errors.length;
  const errorsRemaining = Math.max(0, maxErrors - errorsCount);
  const hasLostBonus = errorsCount >= 4;

  const handleAddError = async () => {
    if (!errorType.trim()) {
      toast.error('Informe o tipo do erro');
      return;
    }

    setLoading(true);
    try {
      const now = new Date();
      const { error } = await supabase
        .from('seller_errors')
        .insert({
          seller_id: sellerId,
          error_type: errorType.trim(),
          description: description.trim() || null,
          error_date: format(now, 'yyyy-MM-dd'),
          month: now.getMonth() + 1,
          year: now.getFullYear()
        });

      if (error) throw error;

      toast.success('Erro registrado');
      setIsOpen(false);
      setErrorType('');
      setDescription('');
      onErrorAdded();
    } catch (err) {
      console.error('Error adding seller error:', err);
      toast.error('Erro ao registrar');
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteError = async (errorId: string) => {
    try {
      const { error } = await supabase
        .from('seller_errors')
        .delete()
        .eq('id', errorId);

      if (error) throw error;

      toast.success('Erro removido');
      onErrorDeleted();
    } catch (err) {
      console.error('Error deleting seller error:', err);
      toast.error('Erro ao remover');
    }
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 10 },
    visible: { opacity: 1, y: 0 }
  };

  return (
    <motion.div
      initial="hidden"
      animate="visible"
      variants={containerVariants}
    >
      <Card className="border-border/50 bg-gradient-to-br from-card to-transparent">
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2 text-base">
              <AlertOctagon className="h-5 w-5 text-primary" />
              Erros Operacionais
            </CardTitle>
            {isAdmin && (
              <Dialog open={isOpen} onOpenChange={setIsOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm" className="gap-1">
                    <Plus className="h-4 w-4" />
                    Registrar
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Registrar Erro Operacional</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 pt-4">
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Tipo do Erro *</label>
                      <Input
                        value={errorType}
                        onChange={(e) => setErrorType(e.target.value)}
                        placeholder="Ex: Pedido sem conferência"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Descrição</label>
                      <Textarea
                        value={description}
                        onChange={(e) => setDescription(e.target.value)}
                        placeholder="Detalhes do erro (opcional)"
                        rows={3}
                      />
                    </div>
                    <Button 
                      onClick={handleAddError} 
                      className="w-full"
                      disabled={loading}
                    >
                      {loading ? 'Registrando...' : 'Registrar Erro'}
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            )}
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Status Summary */}
          <div className={cn(
            "p-4 rounded-lg border text-center",
            hasLostBonus 
              ? "bg-red-500/10 border-red-500/20" 
              : errorsRemaining <= 1 
                ? "bg-amber-500/10 border-amber-500/20"
                : "bg-muted/30 border-border/30"
          )}>
            <div className="flex items-center justify-center gap-3 mb-2">
              {[1, 2, 3].map((num) => (
                <div
                  key={num}
                  className={cn(
                    "w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium",
                    num <= errorsCount
                      ? "bg-red-500 text-white"
                      : "bg-muted border border-border"
                  )}
                >
                  {num}
                </div>
              ))}
              <div
                className={cn(
                  "w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium",
                  errorsCount >= 4
                    ? "bg-red-600 text-white"
                    : "bg-muted border border-border border-dashed"
                )}
              >
                4+
              </div>
            </div>
            <p className={cn(
              "text-sm font-medium",
              hasLostBonus ? "text-red-600" : errorsRemaining <= 1 ? "text-amber-600" : "text-muted-foreground"
            )}>
              {hasLostBonus 
                ? "Premiação bloqueada por excesso de erros"
                : `${errorsRemaining} erro(s) restante(s) antes de perder premiação`
              }
            </p>
          </div>

          {/* Error List */}
          {errors.length > 0 ? (
            <motion.div variants={containerVariants} className="space-y-2">
              {errors.map((error) => (
                <motion.div
                  key={error.id}
                  variants={itemVariants}
                  className="flex items-start justify-between p-3 rounded-lg bg-red-500/5 border border-red-500/10"
                >
                  <div className="flex items-start gap-3">
                    <div className="p-1.5 rounded bg-red-500/10">
                      <AlertOctagon className="h-4 w-4 text-red-600" />
                    </div>
                    <div>
                      <p className="text-sm font-medium">{error.error_type}</p>
                      {error.description && (
                        <p className="text-xs text-muted-foreground mt-0.5">{error.description}</p>
                      )}
                      <p className="text-xs text-muted-foreground mt-1 flex items-center gap-1">
                        <Calendar className="h-3 w-3" />
                        {format(new Date(error.error_date), 'dd/MM/yyyy', { locale: ptBR })}
                      </p>
                    </div>
                  </div>
                  {isAdmin && (
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 text-muted-foreground hover:text-red-600"
                      onClick={() => handleDeleteError(error.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  )}
                </motion.div>
              ))}
            </motion.div>
          ) : (
            <div className="text-center py-6 text-muted-foreground">
              <AlertOctagon className="h-8 w-8 mx-auto mb-2 opacity-30" />
              <p className="text-sm">Nenhum erro registrado este mês</p>
            </div>
          )}

          {/* Rules */}
          <div className="pt-4 border-t border-border/50 text-xs text-muted-foreground space-y-1">
            <p>• Até 3 erros: mantém direito à premiação</p>
            <p>• 4º erro: perde premiação (comissão normal mantida)</p>
            <p>• Contagem reinicia no próximo mês</p>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
