import { useState } from 'react';
import { 
  RotateCcw, Building2, Calendar, CheckCircle2, Clock, 
  XCircle, AlertTriangle, Trophy, Award, Timer
} from 'lucide-react';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Textarea } from '@/components/ui/textarea';
import { 
  Reactivation, 
  ReactivationStatus, 
  ReactivationStats,
  MonthlyRanking 
} from '@/hooks/useReactivationsData';
import { cn } from '@/lib/utils';

interface ReactivationsDetailSheetProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  reactivations: Reactivation[];
  stats: ReactivationStats;
  ranking: MonthlyRanking[];
  sellerId: string;
  sellerName: string;
  monthLabel: string;
  isAdmin: boolean;
  onVerify: (id: string, status: ReactivationStatus, note?: string) => Promise<boolean>;
}

function formatDate(dateStr: string): string {
  if (!dateStr) return '-';
  return new Date(dateStr).toLocaleDateString('pt-BR');
}

function getStatusBadge(status: ReactivationStatus) {
  switch (status) {
    case 'confirmed':
      return (
        <Badge className="bg-status-success/10 text-status-success border-status-success/20 gap-1">
          <CheckCircle2 className="h-3 w-3" />
          Confirmada
        </Badge>
      );
    case 'pending':
      return (
        <Badge className="bg-amber-500/10 text-amber-500 border-amber-500/20 gap-1">
          <Clock className="h-3 w-3" />
          Pendente
        </Badge>
      );
    case 'long_window':
      return (
        <Badge className="bg-blue-500/10 text-blue-500 border-blue-500/20 gap-1">
          <Calendar className="h-3 w-3" />
          Janela Longa
        </Badge>
      );
    case 'cancelled':
      return (
        <Badge className="bg-muted text-muted-foreground border-border gap-1">
          <XCircle className="h-3 w-3" />
          Cancelada
        </Badge>
      );
    default:
      return null;
  }
}

interface ReactivationCardProps {
  reactivation: Reactivation;
  isAdmin: boolean;
  onVerify: (id: string, status: ReactivationStatus, note?: string) => Promise<boolean>;
}

function ReactivationCard({ reactivation, isAdmin, onVerify }: ReactivationCardProps) {
  const [isVerifying, setIsVerifying] = useState(false);
  const [showNote, setShowNote] = useState(false);
  const [note, setNote] = useState('');

  const handleVerify = async (status: ReactivationStatus) => {
    setIsVerifying(true);
    await onVerify(reactivation.id, status, note || undefined);
    setIsVerifying(false);
    setShowNote(false);
    setNote('');
  };

  const isPending = reactivation.status === 'pending';

  return (
    <div className={cn(
      "p-4 rounded-lg border transition-all",
      isPending 
        ? "border-amber-500/30 bg-amber-500/5" 
        : "border-border/50 bg-card"
    )}>
      {/* Header */}
      <div className="flex items-start justify-between gap-3 mb-3">
        <div className="flex items-center gap-2">
          <Building2 className="h-4 w-4 text-muted-foreground" />
          <div>
            <p className="font-medium text-foreground">{reactivation.clientName}</p>
            <p className="text-xs text-muted-foreground">
              Vendedor: {reactivation.sellerName}
            </p>
          </div>
        </div>
        {getStatusBadge(reactivation.status)}
      </div>

      {/* Details */}
      <div className="grid grid-cols-2 gap-3 text-sm mb-3">
        <div>
          <p className="text-xs text-muted-foreground">Último pedido anterior</p>
          <p className="font-medium">{formatDate(reactivation.previousOrderDate)}</p>
        </div>
        <div>
          <p className="text-xs text-muted-foreground">Pedido de reativação</p>
          <p className="font-medium">{formatDate(reactivation.reactivationOrderDate)}</p>
        </div>
      </div>

      {/* Days inactive highlight */}
      <div className="flex items-center gap-2 p-2 rounded-lg bg-orange-500/10 mb-3">
        <Timer className="h-4 w-4 text-orange-500" />
        <span className="text-sm font-semibold text-orange-600 dark:text-orange-400">
          {reactivation.daysInactive} dias inativo
        </span>
      </div>

      {/* Star awarded */}
      {reactivation.starsAwarded > 0 && (
        <div className="flex items-center gap-2 p-2 rounded-lg bg-amber-500/10 mb-3">
          <Award className="h-4 w-4 text-amber-500" />
          <span className="text-sm text-amber-600 dark:text-amber-400">
            +{reactivation.starsAwarded} estrela concedida
          </span>
        </div>
      )}

      {/* Verification Actions (for pending) */}
      {isPending && (
        <div className="space-y-3 pt-3 border-t border-border/50">
          <div className="flex items-start gap-2 p-2 rounded-lg bg-muted/50">
            <AlertTriangle className="h-4 w-4 text-amber-500 mt-0.5 shrink-0" />
            <div className="text-xs text-muted-foreground">
              <p className="font-medium text-foreground mb-1">Verificação Anti-Fraude</p>
              <p>Esse cliente estava realmente inativo (perdido) ou é um cliente com janela de compra mais longa?</p>
            </div>
          </div>

          {showNote && (
            <Textarea
              placeholder="Observação (opcional)"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              className="text-sm"
              rows={2}
            />
          )}

          <div className="flex flex-wrap gap-2">
            <Button
              size="sm"
              variant="default"
              className="bg-status-success hover:bg-status-success/90 gap-1 flex-1"
              onClick={() => handleVerify('confirmed')}
              disabled={isVerifying}
            >
              <CheckCircle2 className="h-3.5 w-3.5" />
              Confirmar Inativo
            </Button>
            
            <Button
              size="sm"
              variant="outline"
              className="border-blue-500/50 text-blue-500 hover:bg-blue-500/10 gap-1 flex-1"
              onClick={() => handleVerify('long_window')}
              disabled={isVerifying}
            >
              <Calendar className="h-3.5 w-3.5" />
              Janela Longa
            </Button>
          </div>

          {!showNote && (
            <Button
              size="sm"
              variant="ghost"
              className="w-full text-xs"
              onClick={() => setShowNote(true)}
            >
              + Adicionar observação
            </Button>
          )}
        </div>
      )}
    </div>
  );
}

export function ReactivationsDetailSheet({
  open,
  onOpenChange,
  reactivations,
  stats,
  ranking,
  sellerId,
  sellerName,
  monthLabel,
  isAdmin,
  onVerify,
}: ReactivationsDetailSheetProps) {
  const pendingReactivations = reactivations.filter(r => r.status === 'pending');
  const confirmedReactivations = reactivations.filter(r => r.status === 'confirmed');
  const longWindowReactivations = reactivations.filter(r => r.status === 'long_window');

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="sm:max-w-lg overflow-y-auto">
        <SheetHeader className="pb-4">
          <SheetTitle className="flex items-center gap-2">
            <RotateCcw className="h-5 w-5 text-orange-500" />
            Reativações de Inativos
          </SheetTitle>
          <p className="text-sm text-muted-foreground">
            {sellerName} • {monthLabel}
          </p>
        </SheetHeader>

        {/* Summary Cards */}
        <div className="grid grid-cols-3 gap-2 mb-6">
          <div className="p-3 rounded-lg bg-status-success/10 text-center">
            <p className="text-2xl font-bold text-status-success">{stats.confirmed}</p>
            <p className="text-xs text-muted-foreground">Confirmadas</p>
          </div>
          <div className="p-3 rounded-lg bg-amber-500/10 text-center">
            <p className="text-2xl font-bold text-amber-500">{stats.pending}</p>
            <p className="text-xs text-muted-foreground">Pendentes</p>
          </div>
          <div className="p-3 rounded-lg bg-blue-500/10 text-center">
            <p className="text-2xl font-bold text-blue-500">{stats.longWindow}</p>
            <p className="text-xs text-muted-foreground">Janela Longa</p>
          </div>
        </div>

        {/* Tabs */}
        <Tabs defaultValue={stats.pending > 0 ? 'pending' : 'confirmed'} className="space-y-4">
          <TabsList className="w-full grid grid-cols-3">
            <TabsTrigger value="pending" className="gap-1 text-xs">
              <Clock className="h-3 w-3" />
              Pendentes ({stats.pending})
            </TabsTrigger>
            <TabsTrigger value="confirmed" className="gap-1 text-xs">
              <CheckCircle2 className="h-3 w-3" />
              Confirmadas ({stats.confirmed})
            </TabsTrigger>
            <TabsTrigger value="ranking" className="gap-1 text-xs">
              <Trophy className="h-3 w-3" />
              Ranking
            </TabsTrigger>
          </TabsList>

          <TabsContent value="pending" className="space-y-3">
            {pendingReactivations.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <CheckCircle2 className="h-12 w-12 mx-auto mb-3 opacity-30" />
                <p>Todas as reativações foram verificadas!</p>
              </div>
            ) : (
              pendingReactivations.map(r => (
                <ReactivationCard 
                  key={r.id} 
                  reactivation={r} 
                  isAdmin={isAdmin}
                  onVerify={onVerify}
                />
              ))
            )}
          </TabsContent>

          <TabsContent value="confirmed" className="space-y-3">
            {confirmedReactivations.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <RotateCcw className="h-12 w-12 mx-auto mb-3 opacity-30" />
                <p>Nenhuma reativação confirmada ainda</p>
              </div>
            ) : (
              confirmedReactivations.map(r => (
                <ReactivationCard 
                  key={r.id} 
                  reactivation={r} 
                  isAdmin={isAdmin}
                  onVerify={onVerify}
                />
              ))
            )}
          </TabsContent>

          <TabsContent value="ranking" className="space-y-3">
            {ranking.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <Trophy className="h-12 w-12 mx-auto mb-3 opacity-30" />
                <p>Nenhuma reativação no mês</p>
              </div>
            ) : (
              <div className="space-y-2">
                {ranking.map((r, idx) => (
                  <div 
                    key={r.sellerId}
                    className={cn(
                      "flex items-center justify-between p-3 rounded-lg border",
                      r.sellerId === sellerId 
                        ? "border-primary/50 bg-primary/5" 
                        : "border-border/50"
                    )}
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-lg">
                        {idx === 0 ? '🥇' : idx === 1 ? '🥈' : idx === 2 ? '🥉' : `#${idx + 1}`}
                      </span>
                      <div>
                        <p className={cn(
                          "font-medium",
                          r.sellerId === sellerId && "text-primary"
                        )}>
                          {r.sellerName}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {r.pendingCount > 0 && `${r.pendingCount} pendente${r.pendingCount > 1 ? 's' : ''}`}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-xl font-bold text-foreground">{r.confirmedCount}</p>
                      <p className="text-xs text-muted-foreground">confirmadas</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </SheetContent>
    </Sheet>
  );
}
