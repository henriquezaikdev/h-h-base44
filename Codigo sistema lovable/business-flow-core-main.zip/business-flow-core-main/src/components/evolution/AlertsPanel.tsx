import { motion, AnimatePresence } from 'framer-motion';
import { AlertTriangle, TrendingDown, XCircle, Clock, ArrowUp, ArrowDown, Info, Bell, Shield, Zap, CheckCircle2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface Alert {
  id: string;
  type: 'warning' | 'danger' | 'info' | 'success';
  title: string;
  description: string;
  action?: string;
}

interface AlertsPanelProps {
  alerts: Alert[];
  evolutionStatus: 'rising' | 'stable' | 'falling';
  monthsToPromotion: number;
  monthsToDemotion: number;
  currentLevel: 'ovo' | 'pena' | 'aguia';
  eligibleForEffortReward?: boolean;
}

const alertStyles = {
  warning: {
    bg: 'bg-gradient-to-r from-amber-500/15 via-amber-500/10 to-transparent',
    border: 'border-amber-500/25',
    icon: AlertTriangle,
    iconBg: 'bg-amber-500/20',
    iconColor: 'text-amber-600'
  },
  danger: {
    bg: 'bg-gradient-to-r from-red-500/15 via-red-500/10 to-transparent',
    border: 'border-red-500/25',
    icon: XCircle,
    iconBg: 'bg-red-500/20',
    iconColor: 'text-red-600'
  },
  info: {
    bg: 'bg-gradient-to-r from-blue-500/15 via-blue-500/10 to-transparent',
    border: 'border-blue-500/25',
    icon: Info,
    iconBg: 'bg-blue-500/20',
    iconColor: 'text-blue-600'
  },
  success: {
    bg: 'bg-gradient-to-r from-emerald-500/15 via-emerald-500/10 to-transparent',
    border: 'border-emerald-500/25',
    icon: CheckCircle2,
    iconBg: 'bg-emerald-500/20',
    iconColor: 'text-emerald-600'
  }
};

export function AlertsPanel({
  alerts,
  evolutionStatus,
  monthsToPromotion,
  monthsToDemotion,
  currentLevel,
  eligibleForEffortReward = false
}: AlertsPanelProps) {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.08 }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, x: -20, scale: 0.95 },
    visible: { 
      opacity: 1, 
      x: 0, 
      scale: 1,
      transition: { type: "spring" as const, stiffness: 300, damping: 25 }
    }
  };

  const getLevelLabel = (level: string) => {
    const labels = { ovo: 'Aprendiz', pena: 'Intermediário', aguia: 'Águia' };
    return labels[level as keyof typeof labels] || level;
  };

  const getEvolutionMessage = () => {
    if (currentLevel === 'aguia') {
      if (evolutionStatus === 'falling') {
        return {
          type: 'danger' as const,
          message: 'Risco de perder benefícios Alta Performance',
          detail: `${monthsToDemotion} mês(es) sem bater meta ou queda de 20%+ resulta em regressão`
        };
      }
      return {
        type: 'success' as const,
        message: 'Alta Performance atingido',
        detail: 'Mantenha a constância para preservar os benefícios. No 3º mês consecutivo, a bonificação dobra.'
      };
    }

    if (evolutionStatus === 'rising') {
      return {
        type: 'success' as const,
        message: `Promoção em ${monthsToPromotion} mês(es)`,
        detail: 'Continue batendo a meta para evoluir de nível. 2 meses consecutivos = promoção.'
      };
    }

    if (evolutionStatus === 'falling') {
      return {
        type: 'danger' as const,
        message: 'Alerta de regressão',
        detail: `${monthsToDemotion} mês(es) consecutivos sem meta ou queda de 20%+ pode rebaixar para ${getLevelLabel(currentLevel === 'pena' ? 'ovo' : 'pena')}`
      };
    }

    return {
      type: 'info' as const,
      message: 'Evolução estável',
      detail: 'Bata a meta por 2 meses consecutivos para promoção'
    };
  };

  const evolution = getEvolutionMessage();

  return (
    <motion.div
      initial="hidden"
      animate="visible"
      variants={containerVariants}
    >
      <Card className="relative overflow-hidden border-border bg-card shadow-lg">
        {/* Decorative background */}
        <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-primary/5 to-transparent rounded-full blur-2xl" />
        
        <CardHeader className="pb-4 relative">
          <CardTitle className="flex items-center gap-2.5 text-base">
            <div className="p-1.5 rounded-lg bg-primary/10">
              <Bell className="h-4 w-4 text-primary" />
            </div>
            Alertas e Status
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 relative">
          {/* Evolution Status */}
          <motion.div
            variants={itemVariants}
            whileHover={{ scale: 1.01 }}
            className={cn(
              "p-4 rounded-xl border shadow-sm",
              alertStyles[evolution.type].bg,
              alertStyles[evolution.type].border
            )}
          >
            <div className="flex items-start gap-3">
              <div className={cn(
                "p-2.5 rounded-xl",
                alertStyles[evolution.type].iconBg
              )}>
                {evolutionStatus === 'rising' ? (
                  <ArrowUp className={cn("h-5 w-5", alertStyles[evolution.type].iconColor)} />
                ) : evolutionStatus === 'falling' ? (
                  <ArrowDown className={cn("h-5 w-5", alertStyles[evolution.type].iconColor)} />
                ) : (
                  <Info className={cn("h-5 w-5", alertStyles[evolution.type].iconColor)} />
                )}
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-sm">{evolution.message}</p>
                <p className="text-xs text-muted-foreground mt-1 leading-relaxed">{evolution.detail}</p>
              </div>
            </div>
          </motion.div>

          {/* Alert List */}
          <AnimatePresence>
            {alerts.length > 0 ? (
              <motion.div variants={containerVariants} className="space-y-2.5">
                {alerts.map((alert) => {
                  const style = alertStyles[alert.type];
                  const Icon = style.icon;

                  return (
                    <motion.div
                      key={alert.id}
                      variants={itemVariants}
                      whileHover={{ scale: 1.01, x: 2 }}
                      className={cn(
                        "p-3.5 rounded-xl border flex items-start gap-3 shadow-sm",
                        style.bg,
                        style.border
                      )}
                    >
                      <div className={cn("p-1.5 rounded-lg shrink-0", style.iconBg)}>
                        <Icon className={cn("h-4 w-4", style.iconColor)} />
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="text-sm font-semibold">{alert.title}</p>
                        <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">{alert.description}</p>
                        {alert.action && (
                          <p className="text-xs text-primary mt-1.5 font-semibold flex items-center gap-1">
                            <Zap className="h-3 w-3" />
                            {alert.action}
                          </p>
                        )}
                      </div>
                    </motion.div>
                  );
                })}
              </motion.div>
            ) : (
              <motion.div 
                variants={itemVariants}
                className="text-center py-8 rounded-xl bg-muted/30 border border-dashed border-border"
              >
                <div className="p-3 rounded-full bg-muted/50 w-fit mx-auto mb-3">
                  <Shield className="h-6 w-6 text-muted-foreground/50" />
                </div>
                <p className="text-sm font-medium text-muted-foreground">Nenhum alerta no momento</p>
                <p className="text-xs text-muted-foreground/70 mt-1">Continue assim!</p>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Rules Reminder */}
          <div className="pt-4 border-t border-border/50">
            <div className="p-3 rounded-xl bg-muted/30 space-y-1.5">
              <p className="text-xs font-medium text-muted-foreground mb-2 flex items-center gap-1.5">
                <Info className="h-3.5 w-3.5" />
                Regras de Evolução
              </p>
              <div className="text-[11px] text-muted-foreground/80 space-y-1">
                <p className="flex items-center gap-1.5">
                  <span className="w-1 h-1 rounded-full bg-emerald-500" />
                  2 meses consecutivos batendo meta = promoção
                </p>
                <p className="flex items-center gap-1.5">
                  <span className="w-1 h-1 rounded-full bg-yellow-500" />
                  3º mês consecutivo = bonificação dobrada
                </p>
                <p className="flex items-center gap-1.5">
                  <span className="w-1 h-1 rounded-full bg-red-500" />
                  2 meses sem bater OU queda de 20%+ = perde benefícios
                </p>
                {currentLevel === 'ovo' && (
                  <p className="flex items-center gap-1.5 text-purple-600">
                    <span className="w-1 h-1 rounded-full bg-purple-500" />
                    Aprendiz com ≥85% + disciplina = premiação por esforço
                  </p>
                )}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
