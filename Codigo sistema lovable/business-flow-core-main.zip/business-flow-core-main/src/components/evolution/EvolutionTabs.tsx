import { motion } from 'framer-motion';
import { BarChart3, Calculator, Trophy, FileText } from 'lucide-react';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { cn } from '@/lib/utils';

interface EvolutionTabsProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
  canAccessTab: (tab: string) => boolean;
  hasPolicyPending?: boolean;
}

const tabConfig = [
  { value: 'performance', label: 'Performance', icon: BarChart3, gradient: 'from-violet-500 to-purple-500' },
  { value: 'commission', label: 'Comissão & Nível', icon: Calculator, gradient: 'from-emerald-500 to-teal-500' },
  { value: 'campaigns', label: 'Campanhas', icon: Trophy, gradient: 'from-amber-500 to-orange-500' },
  { value: 'rules', label: 'Regras', icon: FileText, gradient: 'from-blue-500 to-cyan-500' },
];

export function EvolutionTabs({ activeTab, onTabChange, canAccessTab, hasPolicyPending }: EvolutionTabsProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.2 }}
    >
      <TabsList className="bg-muted/50 p-1.5 rounded-xl border border-border/50 flex-wrap h-auto gap-1">
        {tabConfig.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.value;
          const showDot = (tab.value === 'rules' || tab.value === 'campaigns') && hasPolicyPending;
          
          return (
            <TabsTrigger
              key={tab.value}
              value={tab.value}
              onClick={() => onTabChange(tab.value)}
              className={cn(
                "relative gap-2 rounded-lg px-4 py-2 transition-all duration-300",
                "data-[state=active]:bg-background data-[state=active]:shadow-md",
                "hover:bg-background/50"
              )}
            >
              <div className={cn(
                "w-6 h-6 rounded-md flex items-center justify-center transition-all",
                isActive 
                  ? `bg-gradient-to-br ${tab.gradient} shadow-sm` 
                  : "bg-muted"
              )}>
                <Icon className={cn(
                  "h-3.5 w-3.5 transition-colors",
                  isActive ? "text-white" : "text-muted-foreground"
                )} />
              </div>
              <span className={cn(
                "font-medium transition-colors",
                isActive ? "text-foreground" : "text-muted-foreground"
              )}>
                {tab.label}
              </span>
              {showDot && (
                <span className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-amber-500 border-2 border-background" />
              )}
            </TabsTrigger>
          );
        })}
      </TabsList>
    </motion.div>
  );
}
