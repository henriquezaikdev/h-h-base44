import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { supabase } from '@/integrations/supabase/client';
import { format, subMonths, startOfMonth, endOfMonth } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend, Line, ComposedChart, Bar } from 'recharts';
import { TrendingUp, Loader2 } from 'lucide-react';

interface MonthlyData {
  month: string;
  monthLabel: string;
  sales: number;
  calls: number;
  orders: number;
  avgTicket: number;
}

interface EvolutionHistoryChartProps {
  sellerId: string;
}

export function EvolutionHistoryChart({ sellerId }: EvolutionHistoryChartProps) {
  const [data, setData] = useState<MonthlyData[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchHistoricalData = async () => {
      if (!sellerId) return;
      
      setLoading(true);
      const months: MonthlyData[] = [];
      const now = new Date();

      // Fetch data for last 6 months
      for (let i = 5; i >= 0; i--) {
        const targetDate = subMonths(now, i);
        const monthStart = startOfMonth(targetDate);
        const monthEnd = endOfMonth(targetDate);
        const monthKey = format(targetDate, 'yyyy-MM');
        const monthLabel = format(targetDate, 'MMM', { locale: ptBR });

        // Fetch orders for this month
        const { data: ordersData } = await supabase
          .from('orders')
          .select('total')
          .eq('seller_id', sellerId)
          .eq('is_accountable', true)
          .gte('order_date', format(monthStart, 'yyyy-MM-dd'))
          .lte('order_date', format(monthEnd, 'yyyy-MM-dd'));

        // Fetch interactions (calls) for this month
        const { data: interactionsData } = await supabase
          .from('interactions')
          .select('interaction_type')
          .eq('responsible_seller_id', sellerId)
          .gte('interaction_date', format(monthStart, 'yyyy-MM-dd'))
          .lte('interaction_date', format(monthEnd, 'yyyy-MM-dd'));

        const totalSales = ordersData?.reduce((sum, o) => sum + (o.total || 0), 0) || 0;
        const ordersCount = ordersData?.length || 0;
        const callsCount = interactionsData?.filter(i => 
          i.interaction_type === 'ligação' || i.interaction_type === 'ligacao'
        ).length || 0;

        months.push({
          month: monthKey,
          monthLabel: monthLabel.charAt(0).toUpperCase() + monthLabel.slice(1),
          sales: totalSales,
          calls: callsCount,
          orders: ordersCount,
          avgTicket: ordersCount > 0 ? totalSales / ordersCount : 0
        });
      }

      setData(months);
      setLoading(false);
    };

    fetchHistoricalData();
  }, [sellerId]);

  const formatCurrency = (value: number) => {
    if (value >= 1000) {
      return `R$ ${(value / 1000).toFixed(1)}k`;
    }
    return `R$ ${value.toFixed(0)}`;
  };

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-background/95 backdrop-blur-sm border border-border rounded-lg shadow-lg p-3">
          <p className="font-medium text-sm mb-2">{label}</p>
          {payload.map((entry: any, index: number) => (
            <div key={index} className="flex items-center gap-2 text-xs">
              <div 
                className="w-2 h-2 rounded-full" 
                style={{ backgroundColor: entry.color }}
              />
              <span className="text-muted-foreground">{entry.name}:</span>
              <span className="font-medium">
                {entry.name === 'Vendas' 
                  ? `R$ ${entry.value.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`
                  : entry.name === 'Ticket Médio'
                    ? `R$ ${entry.value.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`
                    : entry.value
                }
              </span>
            </div>
          ))}
        </div>
      );
    }
    return null;
  };

  if (loading) {
    return (
      <Card className="bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800">
        <CardContent className="flex items-center justify-center h-[300px]">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800 border-0 shadow-lg">
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center gap-2 text-lg">
          <TrendingUp className="h-5 w-5 text-primary" />
          Evolução dos Últimos 6 Meses
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-[300px]">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={data} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
              <defs>
                <linearGradient id="salesGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.4}/>
                  <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                </linearGradient>
                <linearGradient id="callsGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(217 91% 60%)" stopOpacity={0.4}/>
                  <stop offset="95%" stopColor="hsl(217 91% 60%)" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.5} />
              <XAxis 
                dataKey="monthLabel" 
                tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 12 }}
                tickLine={false}
                axisLine={{ stroke: 'hsl(var(--border))' }}
              />
              <YAxis 
                yAxisId="left"
                tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 12 }}
                tickLine={false}
                axisLine={{ stroke: 'hsl(var(--border))' }}
                tickFormatter={formatCurrency}
              />
              <YAxis 
                yAxisId="right"
                orientation="right"
                tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 12 }}
                tickLine={false}
                axisLine={{ stroke: 'hsl(var(--border))' }}
              />
              <Tooltip content={<CustomTooltip />} />
              <Legend 
                wrapperStyle={{ paddingTop: '20px' }}
                formatter={(value) => <span className="text-sm text-muted-foreground">{value}</span>}
              />
              <Area
                yAxisId="left"
                type="monotone"
                dataKey="sales"
                name="Vendas"
                stroke="hsl(var(--primary))"
                strokeWidth={2}
                fill="url(#salesGradient)"
              />
              <Bar
                yAxisId="right"
                dataKey="calls"
                name="Ligações"
                fill="hsl(217 91% 60%)"
                radius={[4, 4, 0, 0]}
                opacity={0.8}
              />
              <Line
                yAxisId="right"
                type="monotone"
                dataKey="orders"
                name="Pedidos"
                stroke="hsl(142 71% 45%)"
                strokeWidth={2}
                dot={{ fill: 'hsl(142 71% 45%)', strokeWidth: 0, r: 4 }}
              />
            </ComposedChart>
          </ResponsiveContainer>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-4 gap-3 mt-4 pt-4 border-t border-border">
          <div className="text-center">
            <p className="text-xs text-muted-foreground">Total Vendas (6m)</p>
            <p className="text-lg font-bold text-primary">
              R$ {data.reduce((sum, d) => sum + d.sales, 0).toLocaleString('pt-BR', { minimumFractionDigits: 0 })}
            </p>
          </div>
          <div className="text-center">
            <p className="text-xs text-muted-foreground">Total Ligações</p>
            <p className="text-lg font-bold text-blue-500">
              {data.reduce((sum, d) => sum + d.calls, 0)}
            </p>
          </div>
          <div className="text-center">
            <p className="text-xs text-muted-foreground">Total Pedidos</p>
            <p className="text-lg font-bold text-green-500">
              {data.reduce((sum, d) => sum + d.orders, 0)}
            </p>
          </div>
          <div className="text-center">
            <p className="text-xs text-muted-foreground">Média Mensal</p>
            <p className="text-lg font-bold text-amber-500">
              R$ {(data.reduce((sum, d) => sum + d.sales, 0) / 6).toLocaleString('pt-BR', { minimumFractionDigits: 0 })}
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
