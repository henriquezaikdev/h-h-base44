import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Trophy, Star, Gift, Target, TrendingUp, 
  CheckCircle2, XCircle, Package, Users, RotateCcw,
  Sparkles, Award, Loader2, AlertTriangle, ShieldAlert
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useSellerAwards, PendingAward } from '@/hooks/useSellerAwards';
import { CATEGORY_CONFIGS } from '@/lib/categoryConfig';
import { cn } from '@/lib/utils';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface MonthlyAwardsPanelProps {
  sellerId: string;
  sellerName: string;
  month: number;
  year: number;
  isAdmin: boolean;
  categoryEligibility: Array<{ categoryKey: string; isMet: boolean; isEligible: boolean; revenue: number; target: number }>;
  newClientsCount: number;
  reactivationsCount: number;
}

const MONTH_NAMES = [
  'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
  'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
];

function AwardItem({ award, onGrant, isAdmin }: { 
  award: PendingAward; 
  onGrant: (award: PendingAward) => void;
  isAdmin: boolean;
}) {
  const getIcon = () => {
    switch (award.type) {
      case 'category_goal': return <Package className="h-4 w-4" />;
      case 'high_margin_sales': return <TrendingUp className="h-4 w-4" />;
      case 'new_clients_goal': return <Users className="h-4 w-4" />;
      case 'reactivations_goal': return <RotateCcw className="h-4 w-4" />;
    }
  };

  const getCategoryColor = () => {
    if (award.type !== 'category_goal' || !award.key) return 'text-muted-foreground';
    const config = CATEGORY_CONFIGS.find(c => c.key === award.key);
    return config?.color || 'text-muted-foreground';
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: -10 }}
      animate={{ opacity: 1, x: 0 }}
      className={cn(
        "flex items-center justify-between p-3 rounded-lg border transition-all",
        award.isMet 
          ? "bg-emerald-500/10 border-emerald-500/30" 
          : "bg-muted/30 border-border/50"
      )}
    >
      <div className="flex items-center gap-3">
        <div className={cn(
          "w-8 h-8 rounded-lg flex items-center justify-center",
          award.isMet ? "bg-emerald-500/20 text-emerald-600" : "bg-muted text-muted-foreground",
          award.type === 'category_goal' && getCategoryColor()
        )}>
          {getIcon()}
        </div>
        <div>
          <p className={cn(
            "text-sm font-medium",
            award.isMet ? "text-foreground" : "text-muted-foreground"
          )}>
            {award.label}
          </p>
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <span>{award.current}/{award.target}</span>
            {award.isMet ? (
              <Badge variant="default" className="text-[10px] px-1.5 py-0 bg-emerald-500">
                <CheckCircle2 className="h-3 w-3 mr-0.5" />
                Meta
              </Badge>
            ) : (
              <Badge variant="secondary" className="text-[10px] px-1.5 py-0">
                Pendente
              </Badge>
            )}
          </div>
        </div>
      </div>

      <div className="flex items-center gap-2">
        <div className={cn(
          "flex items-center gap-1 px-2 py-1 rounded-md text-sm font-semibold",
          award.isMet ? "bg-amber-500/20 text-amber-600" : "bg-muted text-muted-foreground"
        )}>
          <Star className="h-3.5 w-3.5" />
          +{award.stars}
        </div>
        
        {isAdmin && award.isMet && (
          <Button
            size="sm"
            variant="ghost"
            className="h-7 px-2 text-emerald-600 hover:text-emerald-700 hover:bg-emerald-500/10"
            onClick={() => onGrant(award)}
          >
            <Gift className="h-3.5 w-3.5" />
          </Button>
        )}
      </div>
    </motion.div>
  );
}

export function MonthlyAwardsPanel({
  sellerId,
  sellerName,
  month,
  year,
  isAdmin,
  categoryEligibility,
  newClientsCount,
  reactivationsCount,
}: MonthlyAwardsPanelProps) {
  const [isGranting, setIsGranting] = useState(false);
  const [hasCiencia, setHasCiencia] = useState<boolean | null>(null);
  const [loadingCiencia, setLoadingCiencia] = useState(true);

  const {
    existingAwards,
    pendingAwards,
    highMarginStats,
    targets,
    totalPendingStars,
    totalAwardedStars,
    loading,
    grantAward,
    grantAllPendingAwards,
  } = useSellerAwards(
    sellerId,
    month,
    year,
    categoryEligibility,
    newClientsCount,
    reactivationsCount
  );

  // Verificar ciência do vendedor
  useEffect(() => {
    async function checkCiencia() {
      if (!sellerId) return;
      setLoadingCiencia(true);
      try {
        const { data, error } = await supabase
          .from('sellers')
          .select('ciencia_regulamento_premiacao')
          .eq('id', sellerId)
          .maybeSingle();
        
        if (error) throw error;
        setHasCiencia(data?.ciencia_regulamento_premiacao ?? false);
      } catch (err) {
        console.error('Error checking ciencia:', err);
        setHasCiencia(false);
      } finally {
        setLoadingCiencia(false);
      }
    }
    checkCiencia();
  }, [sellerId]);

  const handleGrantAll = async () => {
    if (!hasCiencia) {
      toast.error('Premiação não pode ser aprovada. Vendedor não possui ciência do Regulamento de Premiações.');
      return;
    }
    setIsGranting(true);
    await grantAllPendingAwards();
    setIsGranting(false);
  };

  const handleGrantSingle = async (award: PendingAward) => {
    if (!hasCiencia) {
      toast.error('Premiação não pode ser aprovada. Vendedor não possui ciência do Regulamento de Premiações.');
      return;
    }
    setIsGranting(true);
    await grantAward(award);
    setIsGranting(false);
  };

  const metCount = pendingAwards.filter(a => a.isMet).length;
  const totalCount = pendingAwards.length;

  if (loading) {
    return (
      <Card className="border-amber-500/20 bg-gradient-to-br from-amber-500/5 to-background">
        <CardContent className="flex items-center justify-center py-12">
          <Loader2 className="h-8 w-8 animate-spin text-amber-500" />
        </CardContent>
      </Card>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.2 }}
    >
      <Card className="border-amber-500/20 bg-gradient-to-br from-amber-500/5 via-yellow-500/5 to-orange-500/5 relative overflow-hidden">
        {/* Decorative sparkles */}
        <div className="absolute top-4 right-4 opacity-20">
          <Sparkles className="h-16 w-16 text-amber-500" />
        </div>

        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <div className="w-8 h-8 bg-gradient-to-br from-amber-500 to-yellow-500 rounded-lg flex items-center justify-center">
              <Trophy className="h-4 w-4 text-white" />
            </div>
            <div className="flex-1">
              <span>Premiações do Mês</span>
              <p className="text-xs text-muted-foreground font-normal mt-0.5">
                {MONTH_NAMES[month - 1]} {year}
              </p>
            </div>
          </CardTitle>
        </CardHeader>

        <CardContent className="space-y-4">
          {/* Aviso fixo obrigatório */}
          <Alert className="border-amber-500/50 bg-amber-500/10">
            <AlertTriangle className="h-4 w-4 text-amber-600" />
            <AlertDescription className="text-amber-600 dark:text-amber-300 text-sm">
              Premiações são eventuais, não garantidas e não possuem natureza salarial.
            </AlertDescription>
          </Alert>

          {/* Alerta de ciência pendente */}
          {!loadingCiencia && hasCiencia === false && (
            <Alert variant="destructive" className="border-red-500/50 bg-red-500/10">
              <ShieldAlert className="h-4 w-4" />
              <AlertDescription className="text-red-600 dark:text-red-300 text-sm">
                <strong>Bloqueado:</strong> Vendedor não possui ciência do Regulamento de Premiações.
                Registre a ciência nas Configurações antes de aprovar premiações.
              </AlertDescription>
            </Alert>
          )}

          {/* Summary Stats */}
          <div className="grid grid-cols-3 gap-3">
            <div className="text-center p-3 rounded-lg bg-background/50">
              <div className="flex items-center justify-center gap-1 text-2xl font-bold text-amber-600">
                <Star className="h-5 w-5 fill-amber-500" />
                {totalAwardedStars}
              </div>
              <p className="text-xs text-muted-foreground">Concedidas</p>
            </div>
            <div className="text-center p-3 rounded-lg bg-background/50">
              <div className="flex items-center justify-center gap-1 text-2xl font-bold text-emerald-600">
                <Gift className="h-5 w-5" />
                {totalPendingStars}
              </div>
              <p className="text-xs text-muted-foreground">Pendentes</p>
            </div>
            <div className="text-center p-3 rounded-lg bg-background/50">
              <div className="flex items-center justify-center gap-1 text-2xl font-bold text-primary">
                <Target className="h-5 w-5" />
                {metCount}/{totalCount}
              </div>
              <p className="text-xs text-muted-foreground">Metas Batidas</p>
            </div>
          </div>

          {/* Progress */}
          <div className="space-y-1">
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>Progresso das Metas</span>
              <span>{Math.round((metCount / Math.max(totalCount, 1)) * 100)}%</span>
            </div>
            <Progress 
              value={(metCount / Math.max(totalCount, 1)) * 100} 
              className="h-2"
            />
          </div>

          <Separator />

          {/* High Margin Sales Highlight */}
          {highMarginStats.qualifyingOrders > 0 && (
            <div className="p-3 rounded-lg bg-gradient-to-r from-emerald-500/10 to-teal-500/10 border border-emerald-500/20">
              <div className="flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-emerald-500" />
                <span className="text-sm font-medium text-emerald-600">
                  {highMarginStats.qualifyingOrders} venda(s) com margem líquida &gt;35%
                </span>
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Total: {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(highMarginStats.totalHighMarginRevenue)}
              </p>
            </div>
          )}

          {/* Pending Awards List */}
          <div className="space-y-2">
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
              Metas do Mês
            </p>
            {pendingAwards.map((award, idx) => (
              <AwardItem
                key={`${award.type}-${award.key || idx}`}
                award={award}
                onGrant={handleGrantSingle}
                isAdmin={isAdmin}
              />
            ))}
          </div>

          {/* Already Awarded */}
          {existingAwards.length > 0 && (
            <>
              <Separator />
              <div className="space-y-2">
                <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                  Já Concedidas
                </p>
                {existingAwards.map(award => (
                  <div 
                    key={award.id}
                    className="flex items-center justify-between p-2 rounded-lg bg-muted/30"
                  >
                    <div className="flex items-center gap-2">
                      <Award className="h-4 w-4 text-amber-500" />
                      <span className="text-sm text-muted-foreground">
                        {award.awardKey || award.awardType.replace(/_/g, ' ')}
                      </span>
                    </div>
                    <Badge className="bg-amber-500/20 text-amber-600 border-0">
                      +{award.starsAwarded} ⭐
                    </Badge>
                  </div>
                ))}
              </div>
            </>
          )}

          {/* Grant All Button */}
          {isAdmin && metCount > 0 && (
            <Button
              onClick={handleGrantAll}
              disabled={isGranting || !hasCiencia}
              className={cn(
                "w-full gap-2 text-white",
                hasCiencia 
                  ? "bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-600 hover:to-yellow-600" 
                  : "bg-gray-400 cursor-not-allowed"
              )}
              title={!hasCiencia ? 'Vendedor não possui ciência do regulamento' : undefined}
            >
              {isGranting ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : !hasCiencia ? (
                <ShieldAlert className="h-4 w-4" />
              ) : (
                <Gift className="h-4 w-4" />
              )}
              {!hasCiencia ? 'Ciência Pendente' : `Conceder Todos os Prêmios (+${totalPendingStars} ⭐)`}
            </Button>
          )}

          {/* Info for non-admins */}
          {!isAdmin && metCount > 0 && (
            <div className="text-center p-3 rounded-lg bg-amber-500/10 border border-amber-500/20">
              <p className="text-sm text-amber-600">
                🎉 Você tem {totalPendingStars} estrelas pendentes para receber!
              </p>
              <p className="text-xs text-muted-foreground mt-1">
                O gestor irá conceder suas premiações em breve.
              </p>
            </div>
          )}

          {metCount === 0 && totalCount > 0 && (
            <div className="text-center py-4 text-muted-foreground">
              <Target className="h-8 w-8 mx-auto mb-2 opacity-30" />
              <p className="text-sm">Nenhuma meta batida ainda</p>
              <p className="text-xs mt-1">Continue trabalhando para conquistar suas premiações!</p>
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
}
