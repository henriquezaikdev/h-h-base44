import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Star, RefreshCw, CheckCircle2, XCircle, Loader2, Sparkles, Flame, Trophy, Medal } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Button } from '@/components/ui/button';
import { useStarsCalculation } from '@/hooks/useStarsCalculation';
import { toast } from 'sonner';

interface SellerStars {
  bronze_stars: number;
  silver_stars: number;
  gold_stars: number;
  current_streak: number;
}

interface DailyTarget {
  date: string;
  salesMet: boolean;
  callsMet: boolean;
  whatsappMet: boolean;
  hasErrors: boolean;
  allMet: boolean;
}

interface StarsDisplayProps {
  stars: SellerStars | null;
  compact?: boolean;
  sellerId?: string;
  dailySalesTarget?: number;
  dailyCallsTarget?: number;
  onStarsUpdated?: () => void;
}

export function StarsDisplay({ 
  stars, 
  compact = false, 
  sellerId,
  dailySalesTarget = 1500,
  dailyCallsTarget = 18,
  onStarsUpdated
}: StarsDisplayProps) {
  const [isCalculating, setIsCalculating] = useState(false);
  const [dailyTargets, setDailyTargets] = useState<DailyTarget[]>([]);
  const { updateSellerStars } = useStarsCalculation();

  const handleRecalculate = async () => {
    if (!sellerId) return;
    
    setIsCalculating(true);
    try {
      const result = await updateSellerStars(sellerId, dailySalesTarget, dailyCallsTarget);
      if (result) {
        setDailyTargets(result.dailyTargets || []);
        if (result.newBronzeStars > 0) {
          toast.success(`🌟 Parabéns! Você ganhou ${result.newBronzeStars} estrela(s) bronze!`);
        }
        onStarsUpdated?.();
      }
    } catch (error) {
      console.error('Error recalculating stars:', error);
      toast.error('Erro ao calcular estrelas');
    } finally {
      setIsCalculating(false);
    }
  };

  const displayStars = stars || { bronze_stars: 0, silver_stars: 0, gold_stars: 0, current_streak: 0 };
  const { bronze_stars, silver_stars, gold_stars, current_streak } = displayStars;
  const totalBronze = bronze_stars + (silver_stars * 5) + (gold_stars * 25);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.08 }
    }
  };

  const starVariants = {
    hidden: { opacity: 0, scale: 0, rotate: -180 },
    visible: { 
      opacity: 1, 
      scale: 1, 
      rotate: 0,
      transition: { type: "spring" as const, stiffness: 300, damping: 20 }
    }
  };

  if (compact) {
    return (
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <motion.div 
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500/10 via-yellow-500/10 to-orange-500/10 border border-amber-500/20 shadow-sm"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              whileHover={{ scale: 1.02 }}
            >
              {gold_stars > 0 && (
                <div className="flex items-center gap-0.5">
                  <Star className="h-4 w-4 text-yellow-500 fill-yellow-500 drop-shadow-sm" />
                  <span className="text-xs font-bold text-yellow-600">{gold_stars}</span>
                </div>
              )}
              {silver_stars > 0 && (
                <div className="flex items-center gap-0.5">
                  <Star className="h-4 w-4 text-slate-400 fill-slate-400 drop-shadow-sm" />
                  <span className="text-xs font-bold text-slate-500">{silver_stars}</span>
                </div>
              )}
              {bronze_stars > 0 && (
                <div className="flex items-center gap-0.5">
                  <Star className="h-4 w-4 text-amber-600 fill-amber-600 drop-shadow-sm" />
                  <span className="text-xs font-bold text-amber-700">{bronze_stars}</span>
                </div>
              )}
              {current_streak > 0 && (
                <div className="flex items-center gap-0.5 ml-1.5 pl-1.5 border-l border-amber-500/30">
                  <Flame className="h-3.5 w-3.5 text-orange-500" />
                  <span className="text-xs font-bold text-orange-600">{current_streak}</span>
                </div>
              )}
            </motion.div>
          </TooltipTrigger>
          <TooltipContent side="bottom" className="max-w-xs">
            <div className="text-sm space-y-1.5">
              <p className="font-semibold flex items-center gap-2">
                <Trophy className="h-4 w-4 text-yellow-500" />
                Sistema de Estrelas
              </p>
              <p className="text-xs text-muted-foreground">
                3 dias consecutivos com todas as metas = 1 ⭐ bronze
              </p>
              <p className="text-xs text-muted-foreground">5 bronze = 1 prata | 5 prata = 1 ouro</p>
              <p className="text-xs text-muted-foreground mt-1 pt-1 border-t border-border/50">
                Total equivalente: <span className="font-bold text-amber-600">{totalBronze}</span> estrelas bronze
              </p>
            </div>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    );
  }

  return (
    <motion.div
      initial="hidden"
      animate="visible"
      variants={containerVariants}
      className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-card via-card to-amber-500/5 border border-border shadow-lg"
    >
      {/* Decorative background elements */}
      <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-yellow-500/10 to-transparent rounded-full blur-2xl" />
      <div className="absolute bottom-0 left-0 w-24 h-24 bg-gradient-to-tr from-amber-500/10 to-transparent rounded-full blur-2xl" />
      
      <div className="relative p-5">
        <div className="flex items-center justify-between mb-4">
          <h4 className="text-sm font-semibold flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-amber-500/15">
              <Trophy className="h-4 w-4 text-amber-500" />
            </div>
            Conquistas
          </h4>
          <div className="flex items-center gap-2">
            <AnimatePresence>
              {current_streak > 0 && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.8 }}
                  className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-gradient-to-r from-orange-500/15 to-red-500/15 border border-orange-500/20"
                >
                  <Flame className="h-3.5 w-3.5 text-orange-500" />
                  <span className="text-xs font-bold text-orange-600">{current_streak} dias</span>
                </motion.div>
              )}
            </AnimatePresence>
            {sellerId && (
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 rounded-lg hover:bg-amber-500/10"
                onClick={handleRecalculate}
                disabled={isCalculating}
              >
                {isCalculating ? (
                  <Loader2 className="h-4 w-4 animate-spin text-amber-600" />
                ) : (
                  <RefreshCw className="h-4 w-4 text-muted-foreground" />
                )}
              </Button>
            )}
          </div>
        </div>

        <div className="grid grid-cols-3 gap-3">
          {/* Gold Stars */}
          <motion.div 
            variants={starVariants}
            whileHover={{ scale: 1.03, y: -2 }}
            className="relative text-center p-4 rounded-xl bg-gradient-to-br from-yellow-500/10 via-amber-500/5 to-transparent border border-yellow-500/20 shadow-sm overflow-hidden"
          >
            {gold_stars > 0 && (
              <motion.div
                animate={{ opacity: [0.3, 0.6, 0.3] }}
                transition={{ duration: 2, repeat: Infinity }}
                className="absolute inset-0 bg-yellow-500/10"
              />
            )}
            <div className="relative flex justify-center mb-2">
              <motion.div
                animate={gold_stars > 0 ? { rotate: [0, 5, -5, 0] } : {}}
                transition={{ duration: 2, repeat: Infinity }}
              >
                <Star className="h-7 w-7 text-yellow-500 fill-yellow-500 drop-shadow-md" />
              </motion.div>
              {gold_stars > 0 && (
                <Sparkles className="absolute -top-1 -right-1 h-3 w-3 text-yellow-400" />
              )}
            </div>
            <p className="text-xl font-bold text-yellow-600">{gold_stars}</p>
            <p className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider">Ouro</p>
          </motion.div>

          {/* Silver Stars */}
          <motion.div 
            variants={starVariants}
            whileHover={{ scale: 1.03, y: -2 }}
            className="relative text-center p-4 rounded-xl bg-gradient-to-br from-slate-400/10 via-slate-300/5 to-transparent border border-slate-400/20 shadow-sm"
          >
            <div className="flex justify-center mb-2">
              <Star className="h-7 w-7 text-slate-400 fill-slate-400 drop-shadow-md" />
            </div>
            <p className="text-xl font-bold text-slate-500">{silver_stars}</p>
            <p className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider">Prata</p>
          </motion.div>

          {/* Bronze Stars */}
          <motion.div 
            variants={starVariants}
            whileHover={{ scale: 1.03, y: -2 }}
            className="relative text-center p-4 rounded-xl bg-gradient-to-br from-amber-600/10 via-orange-500/5 to-transparent border border-amber-600/20 shadow-sm"
          >
            <div className="flex justify-center mb-2">
              <Star className="h-7 w-7 text-amber-600 fill-amber-600 drop-shadow-md" />
            </div>
            <p className="text-xl font-bold text-amber-700">{bronze_stars}</p>
            <p className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider">Bronze</p>
          </motion.div>
        </div>

        {/* Progress to next star */}
        <AnimatePresence>
          {current_streak > 0 && current_streak < 3 && (
            <motion.div 
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="mt-4 p-3 bg-gradient-to-r from-amber-500/10 via-orange-500/5 to-transparent rounded-xl border border-amber-500/15"
            >
              <div className="flex items-center justify-between text-xs mb-2">
                <span className="text-muted-foreground font-medium">Próxima estrela bronze</span>
                <span className="font-bold text-amber-600">{current_streak}/3 dias</span>
              </div>
              <div className="h-2 bg-muted/50 rounded-full overflow-hidden">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: `${(current_streak / 3) * 100}%` }}
                  transition={{ duration: 0.8, ease: "easeOut" }}
                  className="h-full bg-gradient-to-r from-amber-500 to-orange-500 rounded-full shadow-sm"
                />
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Daily targets status */}
        {dailyTargets.length > 0 && (
          <div className="mt-4 pt-4 border-t border-border/30">
            <p className="text-xs text-muted-foreground mb-2.5 font-medium">Últimos dias:</p>
            <div className="flex gap-1.5 flex-wrap">
              {dailyTargets.slice(0, 5).map((day, idx) => (
                <TooltipProvider key={day.date}>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <motion.div 
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: idx * 0.05 }}
                        whileHover={{ scale: 1.1 }}
                        className={cn(
                          "w-9 h-9 rounded-lg flex items-center justify-center cursor-pointer transition-colors",
                          day.allMet 
                            ? "bg-gradient-to-br from-emerald-500/20 to-green-500/10 border border-emerald-500/30 shadow-sm" 
                            : "bg-red-500/10 border border-red-500/20"
                        )}
                      >
                        {day.allMet ? (
                          <CheckCircle2 className="h-4 w-4 text-emerald-600" />
                        ) : (
                          <XCircle className="h-4 w-4 text-red-500" />
                        )}
                      </motion.div>
                    </TooltipTrigger>
                    <TooltipContent side="bottom" className="text-xs">
                      <p className="font-semibold mb-1">{day.date}</p>
                      <div className="space-y-0.5">
                        <p className={day.salesMet ? "text-emerald-600" : "text-red-500"}>
                          Vendas: {day.salesMet ? "✓" : "✗"}
                        </p>
                        <p className={day.callsMet ? "text-emerald-600" : "text-red-500"}>
                          Ligações: {day.callsMet ? "✓" : "✗"}
                        </p>
                        <p className={day.whatsappMet ? "text-emerald-600" : "text-red-500"}>
                          WhatsApp: {day.whatsappMet ? "✓" : "✗"}
                        </p>
                        <p className={!day.hasErrors ? "text-emerald-600" : "text-red-500"}>
                          Sem erros: {!day.hasErrors ? "✓" : "✗"}
                        </p>
                      </div>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              ))}
            </div>
          </div>
        )}

        {/* Conversion info */}
        <div className="mt-4 pt-4 border-t border-border/30">
          <div className="flex items-center justify-center gap-2 text-xs text-muted-foreground">
            <Medal className="h-3.5 w-3.5" />
            <span>3 dias = 1 bronze • 5 bronze = 1 prata • 5 prata = 1 ouro</span>
          </div>
          <AnimatePresence>
            {bronze_stars >= 5 && (
              <motion.p 
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-xs text-amber-600 text-center mt-2 font-medium flex items-center justify-center gap-1"
              >
                <Sparkles className="h-3 w-3" />
                Conversão automática ao atingir 5 estrelas!
              </motion.p>
            )}
          </AnimatePresence>
        </div>
      </div>
    </motion.div>
  );
}

