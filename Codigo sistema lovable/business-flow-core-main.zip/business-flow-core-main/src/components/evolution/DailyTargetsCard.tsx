import { Card, CardContent } from '@/components/ui/card';
import { DollarSign, Phone, MessageCircle, TrendingUp, Zap, CheckCircle2 } from 'lucide-react';
import { useMemo, useEffect, useState, useCallback } from 'react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';
import { BASE_CALLS_PER_DAY, BASE_WHATSAPP_PER_DAY } from '@/hooks/useComputeTargets';
import { GoalCelebrationOverlay } from '@/components/ui/goal-celebration-overlay';
import { supabase } from '@/integrations/supabase/client';

interface DailyTargetsCardProps {
  monthlySalesTarget: number;
  currentMonthSales: number;
  dailyCallsTarget?: number;
  currentMonthCalls: number;
  currentMonthWhatsapp: number;
  workDaysInMonth: number;
  workDaysPassed: number;
  baseCallsPerDay?: number;
  baseWhatsappPerDay?: number;
  totalCallsMonth?: number;
  totalWhatsappMonth?: number;
  sellerId?: string;
}

export function DailyTargetsCard({
  monthlySalesTarget,
  currentMonthSales,
  dailyCallsTarget,
  currentMonthCalls,
  currentMonthWhatsapp,
  workDaysInMonth,
  workDaysPassed,
  baseCallsPerDay = BASE_CALLS_PER_DAY,
  baseWhatsappPerDay = BASE_WHATSAPP_PER_DAY,
  totalCallsMonth,
  totalWhatsappMonth,
  sellerId,
}: DailyTargetsCardProps) {
  const [showCelebration, setShowCelebration] = useState(false);
  const [lovedOnePhotoUrl, setLovedOnePhotoUrl] = useState<string | null>(null);
  const [lovedOneName, setLovedOneName] = useState<string | null>(null);

  const handleCloseCelebration = useCallback(() => setShowCelebration(false), []);

  // Fetch loved one data
  useEffect(() => {
    if (!sellerId) return;
    (supabase as any)
      .from('sellers')
      .select('loved_one_photo_url, loved_one_name')
      .eq('id', sellerId)
      .maybeSingle()
      .then(({ data }: any) => {
        if (data) {
          setLovedOnePhotoUrl(data.loved_one_photo_url);
          setLovedOneName(data.loved_one_name);
        }
      });
  }, [sellerId]);
  
  const diasUteisRestantes = Math.max(1, workDaysInMonth - workDaysPassed);
  
  const totalLigacoesMes = totalCallsMonth ?? (baseCallsPerDay * workDaysInMonth);
  const totalWhatsMes = totalWhatsappMonth ?? (baseWhatsappPerDay * workDaysInMonth);
  
  const ligDiaBaseExibicao = Math.ceil(totalLigacoesMes / workDaysInMonth);
  const whatsDiaBaseExibicao = Math.ceil(totalWhatsMes / workDaysInMonth);
  
  const salesTarget = useMemo(() => {
    const remainingSales = monthlySalesTarget - currentMonthSales;
    
    if (remainingSales <= 0) {
      return { daily: 0, remaining: remainingSales, isAhead: true, total: monthlySalesTarget };
    }
    
    const adjustedDaily = remainingSales / diasUteisRestantes;
    
    return {
      daily: adjustedDaily,
      remaining: remainingSales,
      isAhead: false,
      total: monthlySalesTarget
    };
  }, [monthlySalesTarget, currentMonthSales, diasUteisRestantes]);

  // Trigger celebration once per day when sales goal is hit
  useEffect(() => {
    if (!salesTarget.isAhead || !sellerId) return;
    const today = new Date().toISOString().split('T')[0];
    const key = `celebration_${sellerId}_${today}`;
    if (localStorage.getItem(key)) return;
    localStorage.setItem(key, '1');
    setShowCelebration(true);
  }, [salesTarget.isAhead, sellerId]);

  const callsTarget = useMemo(() => {
    const ligacoesFaltando = Math.max(0, totalLigacoesMes - currentMonthCalls);
    const ligDiaNecessarias = Math.ceil(ligacoesFaltando / diasUteisRestantes);
    
    return {
      daily: ligDiaNecessarias,
      original: ligDiaBaseExibicao,
      remaining: ligacoesFaltando,
      total: totalLigacoesMes,
      isAhead: ligacoesFaltando <= 0
    };
  }, [currentMonthCalls, totalLigacoesMes, diasUteisRestantes, ligDiaBaseExibicao]);

  const whatsappTarget = useMemo(() => {
    const whatsFaltando = Math.max(0, totalWhatsMes - currentMonthWhatsapp);
    const whatsDiaNecessarios = Math.ceil(whatsFaltando / diasUteisRestantes);
    
    return {
      daily: whatsDiaNecessarios,
      original: whatsDiaBaseExibicao,
      remaining: whatsFaltando,
      total: totalWhatsMes,
      isAhead: whatsFaltando <= 0
    };
  }, [currentMonthWhatsapp, totalWhatsMes, diasUteisRestantes, whatsDiaBaseExibicao]);

  const formatCurrency = (value: number) => {
    if (value >= 1000) {
      return `R$ ${(value / 1000).toFixed(1)}k`;
    }
    return `R$ ${value.toFixed(0)}`;
  };

  const cardVariants = {
    hidden: { opacity: 0, y: 10 },
    visible: (i: number) => ({
      opacity: 1,
      y: 0,
      transition: { delay: i * 0.1, duration: 0.3 }
    })
  };

  return (
    <>
    <GoalCelebrationOverlay
      show={showCelebration}
      onClose={handleCloseCelebration}
      lovedOnePhotoUrl={lovedOnePhotoUrl}
      lovedOneName={lovedOneName}
    />
    <div className="grid grid-cols-1 gap-3">
      {/* Header */}
      <div className="flex items-center gap-2 mb-1">
        <div className="p-1.5 rounded-lg bg-primary/10">
          <TrendingUp className="h-4 w-4 text-primary" />
        </div>
        <h4 className="text-sm font-semibold">Metas Diárias Ajustadas</h4>
      </div>

      <div className="grid grid-cols-3 gap-3">
        {/* Meta de Venda do Dia */}
        <motion.div
          custom={0}
          initial="hidden"
          animate="visible"
          variants={cardVariants}
          whileHover={{ scale: 1.02, y: -2 }}
        >
          <Card className={cn(
            "relative overflow-hidden border transition-all duration-300",
            salesTarget.isAhead 
              ? "bg-gradient-to-br from-emerald-500/10 via-card to-card border-emerald-500/30" 
              : "bg-card border-border hover:border-emerald-500/30"
          )}>
            {salesTarget.isAhead && (
              <div className="absolute top-0 right-0 w-16 h-16 bg-emerald-500/10 rounded-full blur-xl" />
            )}
            <CardContent className="relative p-4">
              <div className="flex items-center gap-2 mb-3">
                <div className={cn(
                  "p-2 rounded-xl transition-colors",
                  salesTarget.isAhead 
                    ? "bg-emerald-500/20" 
                    : "bg-emerald-500/10"
                )}>
                  <DollarSign className="h-4 w-4 text-emerald-600" />
                </div>
                <span className="text-xs font-medium text-muted-foreground">Venda/Dia</span>
              </div>
              
              {salesTarget.isAhead ? (
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5">
                    <CheckCircle2 className="h-4 w-4 text-emerald-500" />
                    <p className="text-sm font-bold text-emerald-600">Meta batida!</p>
                  </div>
                  <p className="text-xs text-emerald-600/80 font-medium">
                    +{formatCurrency(Math.abs(salesTarget.remaining))} acima
                  </p>
                </div>
              ) : (
                <div className="space-y-1">
                  <p className="text-xl font-bold tracking-tight">
                    {formatCurrency(salesTarget.daily)}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    Faltam {formatCurrency(salesTarget.remaining)}
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>

        {/* Meta de Ligações do Dia */}
        <motion.div
          custom={1}
          initial="hidden"
          animate="visible"
          variants={cardVariants}
          whileHover={{ scale: 1.02, y: -2 }}
        >
          <Card className={cn(
            "relative overflow-hidden border transition-all duration-300",
            callsTarget.isAhead 
              ? "bg-gradient-to-br from-blue-500/10 via-card to-card border-blue-500/30" 
              : "bg-card border-border hover:border-blue-500/30"
          )}>
            {callsTarget.isAhead && (
              <div className="absolute top-0 right-0 w-16 h-16 bg-blue-500/10 rounded-full blur-xl" />
            )}
            <CardContent className="relative p-4">
              <div className="flex items-center gap-2 mb-3">
                <div className={cn(
                  "p-2 rounded-xl transition-colors",
                  callsTarget.isAhead 
                    ? "bg-blue-500/20" 
                    : "bg-blue-500/10"
                )}>
                  <Phone className="h-4 w-4 text-blue-600" />
                </div>
                <div className="flex flex-col">
                  <span className="text-xs font-medium text-muted-foreground">Ligações</span>
                  <span className="text-[10px] text-muted-foreground/70">
                    {totalLigacoesMes}/mês • {ligDiaBaseExibicao}/dia
                  </span>
                </div>
              </div>
              
              {callsTarget.isAhead ? (
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5">
                    <CheckCircle2 className="h-4 w-4 text-blue-500" />
                    <p className="text-sm font-bold text-blue-600">Meta batida!</p>
                  </div>
                  <p className="text-xs text-blue-600/80 font-medium">
                    {currentMonthCalls}/{callsTarget.total}
                  </p>
                </div>
              ) : (
                <div className="space-y-1">
                  <div className="flex items-baseline gap-1">
                    <p className="text-xl font-bold tracking-tight">{callsTarget.daily}</p>
                    <span className="text-xs text-muted-foreground">por dia</span>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Faltam {callsTarget.remaining} de {callsTarget.total}
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>

        {/* Meta de WhatsApp do Dia */}
        <motion.div
          custom={2}
          initial="hidden"
          animate="visible"
          variants={cardVariants}
          whileHover={{ scale: 1.02, y: -2 }}
        >
          <Card className={cn(
            "relative overflow-hidden border transition-all duration-300",
            whatsappTarget.isAhead 
              ? "bg-gradient-to-br from-green-500/10 via-card to-card border-green-500/30" 
              : "bg-card border-border hover:border-green-500/30"
          )}>
            {whatsappTarget.isAhead && (
              <div className="absolute top-0 right-0 w-16 h-16 bg-green-500/10 rounded-full blur-xl" />
            )}
            <CardContent className="relative p-4">
              <div className="flex items-center gap-2 mb-3">
                <div className={cn(
                  "p-2 rounded-xl transition-colors",
                  whatsappTarget.isAhead 
                    ? "bg-green-500/20" 
                    : "bg-green-500/10"
                )}>
                  <MessageCircle className="h-4 w-4 text-green-600" />
                </div>
                <div className="flex flex-col">
                  <span className="text-xs font-medium text-muted-foreground">WhatsApp</span>
                  <span className="text-[10px] text-muted-foreground/70">
                    {totalWhatsMes}/mês • {whatsDiaBaseExibicao}/dia
                  </span>
                </div>
              </div>
              
              {whatsappTarget.isAhead ? (
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5">
                    <CheckCircle2 className="h-4 w-4 text-green-500" />
                    <p className="text-sm font-bold text-green-600">Meta batida!</p>
                  </div>
                  <p className="text-xs text-green-600/80 font-medium">
                    {currentMonthWhatsapp}/{whatsappTarget.total}
                  </p>
                </div>
              ) : (
                <div className="space-y-1">
                  <div className="flex items-baseline gap-1">
                    <p className="text-xl font-bold tracking-tight">{whatsappTarget.daily}</p>
                    <span className="text-xs text-muted-foreground">por dia</span>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Faltam {whatsappTarget.remaining} de {whatsappTarget.total}
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
    </>
  );
}
