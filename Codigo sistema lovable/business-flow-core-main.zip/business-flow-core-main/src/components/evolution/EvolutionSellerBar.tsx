import { motion, AnimatePresence } from 'framer-motion';
import { Users, ChevronLeft, ChevronRight, Calendar, Plus } from 'lucide-react';
import { SystemClock } from '@/components/ui/SystemClock';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { WorkingDaysChip } from './WorkingDaysChip';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface Seller {
  id: string;
  name: string;
  role: string;
}

interface EvolutionSellerBarProps {
  sellers: Seller[];
  selectedSellerId: string | null;
  onSellerChange: (id: string) => void;
  isAdmin: boolean;
  showSetup?: boolean;
  onSetupClick?: () => void;
  onRefetch?: () => void;
  // Period navigation
  selectedDate?: Date;
  onPreviousMonth?: () => void;
  onNextMonth?: () => void;
  onCurrentMonth?: () => void;
  isCurrentMonth?: boolean;
  showPeriodSelector?: boolean;
}

export function EvolutionSellerBar({
  sellers,
  selectedSellerId,
  onSellerChange,
  isAdmin,
  showSetup = false,
  onSetupClick,
  onRefetch,
  selectedDate,
  onPreviousMonth,
  onNextMonth,
  onCurrentMonth,
  isCurrentMonth = true,
  showPeriodSelector = false,
}: EvolutionSellerBarProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.1 }}
      className="sticky top-0 z-40 -mx-6 px-6 py-4 bg-background/80 backdrop-blur-xl border-b border-border/50"
    >
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3 flex-wrap">
          {/* System Clock */}
          <SystemClock />
          
          {/* Working Days Chip */}
          <WorkingDaysChip isAdmin={isAdmin} onConfigSaved={onRefetch} />

          {/* Seller Selector (Admin only) */}
          {isAdmin && (
            <div className="flex items-center gap-2">
              <Users className="h-4 w-4 text-muted-foreground" />
              <Select value={selectedSellerId || ''} onValueChange={onSellerChange}>
                <SelectTrigger className="w-[200px] bg-muted/30 border-border/50 rounded-xl">
                  <SelectValue placeholder="Selecionar vendedor" />
                </SelectTrigger>
                <SelectContent>
                  {sellers.map(seller => (
                    <SelectItem key={seller.id} value={seller.id}>
                      {seller.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          {/* Setup Button (Admin only, when no level) */}
          <AnimatePresence>
            {showSetup && isAdmin && onSetupClick && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
              >
                <Button 
                  onClick={onSetupClick} 
                  size="sm" 
                  className="gap-2 bg-gradient-to-r from-violet-500 to-purple-600 hover:from-violet-600 hover:to-purple-700"
                >
                  <Plus className="h-4 w-4" />
                  Configurar Vendedor
                </Button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Period Selector */}
        <AnimatePresence>
          {showPeriodSelector && selectedDate && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="flex items-center gap-2"
            >
              <div className="flex items-center gap-1 bg-muted/50 rounded-xl p-1 border border-border/50">
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="h-8 w-8 rounded-lg hover:bg-background"
                  onClick={onPreviousMonth}
                >
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                
                <div className="flex items-center gap-2 px-3 min-w-[160px] justify-center">
                  <Calendar className="h-4 w-4 text-violet-500" />
                  <span className="font-medium capitalize text-sm">
                    {format(selectedDate, "MMMM yyyy", { locale: ptBR })}
                  </span>
                </div>
                
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="h-8 w-8 rounded-lg hover:bg-background"
                  onClick={onNextMonth}
                  disabled={isCurrentMonth}
                >
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>

              <AnimatePresence>
                {!isCurrentMonth && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.9 }}
                  >
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={onCurrentMonth}
                      className="rounded-xl"
                    >
                      Mês Atual
                    </Button>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}
