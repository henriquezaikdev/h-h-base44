import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Phone, MessageCircle, Users, ChevronDown, ChevronRight, 
  ExternalLink, Search, Filter, SortAsc, X, Loader2,
  Calendar, Clock
} from 'lucide-react';
import {
  Drawer,
  DrawerContent,
  DrawerHeader,
  DrawerTitle,
  DrawerDescription,
  DrawerClose
} from '@/components/ui/drawer';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
  SheetClose
} from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger
} from '@/components/ui/collapsible';
import { supabase } from '@/integrations/supabase/client';
import { cn } from '@/lib/utils';

// Tier labels
const TIER_LABELS: Record<string, string> = {
  top20: 'TOP 20',
  top100: 'TOP 100',
  top200: 'TOP 200',
  eventual: 'EVENTUAL',
  geral: 'PROSPECTO',
  all: 'TODOS',
  repetitions: 'REPETIÇÕES (3+)'
};

type DrillDownType = 'tier' | 'unique' | 'repetitions' | 'percent_top20' | 'percent_top100';
type ChannelFilter = 'all' | 'ligacao' | 'whatsapp';
type SortOrder = 'contacts_desc' | 'contacts_asc' | 'recent' | 'alpha';

interface ClientContact {
  clientId: string;
  clientName: string;
  tier: string;
  totalContacts: number;
  callContacts: number;
  whatsappContacts: number;
  lastContactDate: string;
  interactions: InteractionDetail[];
}

interface InteractionDetail {
  id: string;
  date: string;
  time: string;
  type: string;
  notes: string;
  channel: 'ligacao' | 'whatsapp' | 'outro';
}

interface ContactDrillDownDrawerProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  sellerId: string;
  sellerName?: string;
  selectedMonth: number;
  selectedYear: number;
  drillDownType: DrillDownType;
  tierFilter?: string; // e.g., 'top20', 'top100', etc.
  periodLabel?: string;
}

export function ContactDrillDownDrawer({
  open,
  onOpenChange,
  sellerId,
  sellerName,
  selectedMonth,
  selectedYear,
  drillDownType,
  tierFilter,
  periodLabel
}: ContactDrillDownDrawerProps) {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [clients, setClients] = useState<ClientContact[]>([]);
  const [expandedClient, setExpandedClient] = useState<string | null>(null);
  const [loadingDetails, setLoadingDetails] = useState<string | null>(null);
  
  // Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [channelFilter, setChannelFilter] = useState<ChannelFilter>('all');
  const [sortOrder, setSortOrder] = useState<SortOrder>('contacts_desc');
  const [onlyRepetitions, setOnlyRepetitions] = useState(drillDownType === 'repetitions');

  // Computed title
  const getTitle = () => {
    if (drillDownType === 'unique') return 'Clientes Únicos Contatados';
    if (drillDownType === 'repetitions') return 'Clientes com 3+ Contatos';
    if (drillDownType === 'percent_top20') return 'Contatos — TOP 20';
    if (drillDownType === 'percent_top100') return 'Contatos — TOP 20 + TOP 100';
    if (tierFilter) return `Contatos — ${TIER_LABELS[tierFilter] || tierFilter.toUpperCase()}`;
    return 'Detalhes de Contatos';
  };

  // Fetch aggregated data
  const fetchData = useCallback(async () => {
    if (!sellerId || !open) return;
    
    setLoading(true);
    try {
      const startDate = `${selectedYear}-${String(selectedMonth).padStart(2, '0')}-01`;
      const endDate = selectedMonth === 12
        ? `${selectedYear + 1}-01-01`
        : `${selectedYear}-${String(selectedMonth + 1).padStart(2, '0')}-01`;

      // Fetch interactions
      const { data: interactions, error } = await supabase
        .from('interactions')
        .select(`
          id,
          client_id,
          interaction_type,
          interaction_date,
          interaction_time,
          interaction_notes
        `)
        .eq('responsible_seller_id', sellerId)
        .gte('interaction_date', startDate)
        .lt('interaction_date', endDate)
        .or('is_deleted.is.null,is_deleted.eq.false');

      if (error) throw error;

      // Get unique client IDs
      const clientIds = [...new Set((interactions || []).map(i => i.client_id))];
      
      if (clientIds.length === 0) {
        setClients([]);
        setLoading(false);
        return;
      }

      // Fetch client data
      const { data: clientsData } = await supabase
        .from('clients')
        .select('id, company_name, ranking_tier')
        .in('id', clientIds);

      const clientsMap: Record<string, { name: string; tier: string }> = {};
      (clientsData || []).forEach(c => {
        clientsMap[c.id] = {
          name: c.company_name,
          tier: c.ranking_tier || 'geral'
        };
      });

      // Aggregate by client
      const clientAggregates: Record<string, ClientContact> = {};

      (interactions || []).forEach(interaction => {
        const clientInfo = clientsMap[interaction.client_id];
        if (!clientInfo) return;

        const interactionType = interaction.interaction_type?.toLowerCase() || '';
        const isCall = interactionType.includes('ligação') || interactionType.includes('ligacao');
        const isWhatsapp = interactionType.includes('whatsapp');
        const isAttempt = interactionType.includes('tentativa');

        // Only count successful contacts
        if (isAttempt) return;
        if (!isCall && !isWhatsapp) return;

        const channel: 'ligacao' | 'whatsapp' | 'outro' = isCall ? 'ligacao' : isWhatsapp ? 'whatsapp' : 'outro';

        if (!clientAggregates[interaction.client_id]) {
          clientAggregates[interaction.client_id] = {
            clientId: interaction.client_id,
            clientName: clientInfo.name,
            tier: clientInfo.tier,
            totalContacts: 0,
            callContacts: 0,
            whatsappContacts: 0,
            lastContactDate: interaction.interaction_date,
            interactions: []
          };
        }

        const agg = clientAggregates[interaction.client_id];
        agg.totalContacts++;
        if (isCall) agg.callContacts++;
        if (isWhatsapp) agg.whatsappContacts++;
        
        if (interaction.interaction_date > agg.lastContactDate) {
          agg.lastContactDate = interaction.interaction_date;
        }

        // Store interaction details for later expansion
        agg.interactions.push({
          id: interaction.id,
          date: interaction.interaction_date,
          time: interaction.interaction_time || '',
          type: interaction.interaction_type || '',
          notes: interaction.interaction_notes || '',
          channel
        });
      });

      // Apply tier filter based on drillDownType
      let filteredClients = Object.values(clientAggregates);

      if (drillDownType === 'tier' && tierFilter) {
        filteredClients = filteredClients.filter(c => c.tier === tierFilter);
      } else if (drillDownType === 'percent_top20') {
        filteredClients = filteredClients.filter(c => c.tier === 'top20');
      } else if (drillDownType === 'percent_top100') {
        filteredClients = filteredClients.filter(c => c.tier === 'top20' || c.tier === 'top100');
      } else if (drillDownType === 'repetitions') {
        filteredClients = filteredClients.filter(c => c.totalContacts >= 3);
      }
      // 'unique' shows all clients

      setClients(filteredClients);
    } catch (err) {
      console.error('Error fetching drill-down data:', err);
    } finally {
      setLoading(false);
    }
  }, [sellerId, selectedMonth, selectedYear, drillDownType, tierFilter, open]);

  useEffect(() => {
    if (open) {
      setSearchQuery('');
      setChannelFilter('all');
      setSortOrder('contacts_desc');
      setOnlyRepetitions(drillDownType === 'repetitions');
      setExpandedClient(null);
      fetchData();
    }
  }, [open, fetchData, drillDownType]);

  // Filtered and sorted clients
  const displayedClients = clients
    .filter(c => {
      // Search filter
      if (searchQuery && !c.clientName.toLowerCase().includes(searchQuery.toLowerCase())) {
        return false;
      }
      // Channel filter
      if (channelFilter === 'ligacao' && c.callContacts === 0) return false;
      if (channelFilter === 'whatsapp' && c.whatsappContacts === 0) return false;
      // Repetitions filter
      if (onlyRepetitions && c.totalContacts < 3) return false;
      return true;
    })
    .sort((a, b) => {
      switch (sortOrder) {
        case 'contacts_desc':
          return b.totalContacts - a.totalContacts;
        case 'contacts_asc':
          return a.totalContacts - b.totalContacts;
        case 'recent':
          return b.lastContactDate.localeCompare(a.lastContactDate);
        case 'alpha':
          return a.clientName.localeCompare(b.clientName);
        default:
          return 0;
      }
    });

  const totalContacts = displayedClients.reduce((sum, c) => sum + c.totalContacts, 0);

  const toggleClientExpand = (clientId: string) => {
    if (expandedClient === clientId) {
      setExpandedClient(null);
    } else {
      setExpandedClient(clientId);
    }
  };

  const handleOpenClient = (clientId: string) => {
    onOpenChange(false);
    navigate(`/clients/${clientId}?from=%2Faction-center`);
  };

  const getChannelIcon = (channel: string) => {
    if (channel === 'ligacao') return <Phone className="h-3 w-3 text-blue-500" />;
    if (channel === 'whatsapp') return <MessageCircle className="h-3 w-3 text-green-500" />;
    return null;
  };

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit'
    });
  };

  const formatDateTime = (dateStr: string, timeStr?: string) => {
    const date = new Date(dateStr);
    const formatted = date.toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    });
    if (timeStr) {
      return `${formatted} às ${timeStr.slice(0, 5)}`;
    }
    return formatted;
  };

  const drawerContent = (
    <div className="flex flex-col h-full">
      {/* Subtitle with counts */}
      <div className="px-4 pb-4 border-b border-border">
        <p className="text-sm text-muted-foreground">
          {sellerName && <span>Vendedor: <strong>{sellerName}</strong> • </span>}
          Período: <strong>{periodLabel || `${String(selectedMonth).padStart(2, '0')}/${selectedYear}`}</strong>
        </p>
        {!loading && (
          <div className="flex gap-3 mt-2">
            <Badge variant="outline" className="bg-primary/10 text-primary border-primary/30">
              <Users className="h-3 w-3 mr-1" />
              {displayedClients.length} clientes
            </Badge>
            <Badge variant="outline" className="bg-green-500/10 text-green-600 border-green-500/30">
              {totalContacts} contatos
            </Badge>
          </div>
        )}
      </div>

      {/* Filters */}
      <div className="p-4 border-b border-border space-y-3">
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Buscar cliente..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9"
            />
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          <Select value={channelFilter} onValueChange={(v) => setChannelFilter(v as ChannelFilter)}>
            <SelectTrigger className="w-[130px] h-8 text-xs">
              <Filter className="h-3 w-3 mr-1" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos canais</SelectItem>
              <SelectItem value="ligacao">Ligações</SelectItem>
              <SelectItem value="whatsapp">WhatsApp</SelectItem>
            </SelectContent>
          </Select>
          <Select value={sortOrder} onValueChange={(v) => setSortOrder(v as SortOrder)}>
            <SelectTrigger className="w-[150px] h-8 text-xs">
              <SortAsc className="h-3 w-3 mr-1" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="contacts_desc">Mais contatos</SelectItem>
              <SelectItem value="contacts_asc">Menos contatos</SelectItem>
              <SelectItem value="recent">Mais recente</SelectItem>
              <SelectItem value="alpha">Alfabético</SelectItem>
            </SelectContent>
          </Select>
          {drillDownType !== 'repetitions' && (
            <Button
              variant={onlyRepetitions ? 'default' : 'outline'}
              size="sm"
              className="h-8 text-xs"
              onClick={() => setOnlyRepetitions(!onlyRepetitions)}
            >
              Só repetidos (3+)
            </Button>
          )}
        </div>
      </div>

      {/* Client list */}
      <ScrollArea className="flex-1">
        <div className="p-4 space-y-2">
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="h-6 w-6 animate-spin text-primary" />
            </div>
          ) : displayedClients.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              Nenhum cliente encontrado
            </div>
          ) : (
            displayedClients.map((client) => (
              <Collapsible
                key={client.clientId}
                open={expandedClient === client.clientId}
                onOpenChange={() => toggleClientExpand(client.clientId)}
              >
                <div className={cn(
                  "border rounded-lg transition-colors",
                  expandedClient === client.clientId ? "border-primary/50 bg-primary/5" : "border-border bg-card"
                )}>
                  <CollapsibleTrigger asChild>
                    <button className="w-full p-3 flex items-center gap-3 text-left hover:bg-muted/50 rounded-t-lg">
                      {expandedClient === client.clientId ? (
                        <ChevronDown className="h-4 w-4 text-muted-foreground shrink-0" />
                      ) : (
                        <ChevronRight className="h-4 w-4 text-muted-foreground shrink-0" />
                      )}
                      <div className="flex-1 min-w-0">
                        <p className="font-medium truncate">{client.clientName}</p>
                        <div className="flex items-center gap-2 mt-1">
                          <Badge variant="outline" className="text-xs px-1.5 py-0">
                            {TIER_LABELS[client.tier]}
                          </Badge>
                          <span className="text-xs text-muted-foreground">
                            Último: {formatDate(client.lastContactDate)}
                          </span>
                        </div>
                      </div>
                      <div className="flex items-center gap-3 shrink-0">
                        <div className="flex items-center gap-1 text-sm">
                          <Phone className="h-3 w-3 text-blue-500" />
                          <span>{client.callContacts}</span>
                        </div>
                        <div className="flex items-center gap-1 text-sm">
                          <MessageCircle className="h-3 w-3 text-green-500" />
                          <span>{client.whatsappContacts}</span>
                        </div>
                        <Badge 
                          variant="secondary" 
                          className={cn(
                            "text-xs font-bold",
                            client.totalContacts >= 3 && "bg-amber-500/20 text-amber-600"
                          )}
                        >
                          {client.totalContacts}
                        </Badge>
                      </div>
                    </button>
                  </CollapsibleTrigger>
                  <CollapsibleContent>
                    <div className="px-3 pb-3 pt-0 border-t border-border/50">
                      {/* Interaction history */}
                      <div className="space-y-2 mt-3">
                        <p className="text-xs font-medium text-muted-foreground mb-2">
                          Histórico de contatos no período:
                        </p>
                        {client.interactions
                          .sort((a, b) => b.date.localeCompare(a.date))
                          .map((interaction) => (
                            <div 
                              key={interaction.id}
                              className="flex items-start gap-2 p-2 rounded bg-muted/30 text-sm"
                            >
                              <div className="shrink-0 mt-0.5">
                                {getChannelIcon(interaction.channel)}
                              </div>
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                                  <Calendar className="h-3 w-3" />
                                  <span>{formatDateTime(interaction.date, interaction.time)}</span>
                                </div>
                                {interaction.notes && (
                                  <p className="text-xs mt-1 text-foreground/80 line-clamp-2">
                                    {interaction.notes}
                                  </p>
                                )}
                              </div>
                            </div>
                          ))}
                      </div>
                      {/* Open client button */}
                      <Button
                        variant="outline"
                        size="sm"
                        className="w-full mt-3"
                        onClick={() => handleOpenClient(client.clientId)}
                      >
                        <ExternalLink className="h-3 w-3 mr-2" />
                        Abrir cadastro do cliente
                      </Button>
                    </div>
                  </CollapsibleContent>
                </div>
              </Collapsible>
            ))
          )}
        </div>
      </ScrollArea>
    </div>
  );

  // Use Sheet for desktop, could use Drawer for mobile
  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="right" className="w-full sm:max-w-lg p-0 flex flex-col">
        <SheetHeader className="p-4 pb-2 border-b border-border shrink-0">
          <SheetTitle className="flex items-center gap-2">
            <Users className="h-5 w-5 text-primary" />
            {getTitle()}
          </SheetTitle>
        </SheetHeader>
        {drawerContent}
      </SheetContent>
    </Sheet>
  );
}
