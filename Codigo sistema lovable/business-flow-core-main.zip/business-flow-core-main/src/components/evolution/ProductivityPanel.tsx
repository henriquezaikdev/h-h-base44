import { motion } from 'framer-motion';
import { Phone, MessageCircle, Activity, CheckCircle, XCircle, Calendar } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { BASE_CALLS_PER_DAY, LEVEL_MONTHLY_TARGETS } from '@/hooks/useComputeTargets';

interface DailyActivity {
  date: string;
  calls: number;
  whatsapp: number;
  total: number;
}

interface ProductivityPanelProps {
  dailyActivities: DailyActivity[];
  dailyCallsTarget: number;
  sellerLevel: 'ovo' | 'pena' | 'aguia';
  workDaysInMonth?: number;
}

export function ProductivityPanel({
  dailyActivities,
  dailyCallsTarget,
  sellerLevel,
  workDaysInMonth = 21
}: ProductivityPanelProps) {
  // Metas por nível - PENA/ÁGUIA usam valores fixos mensais
  const levelTargets = LEVEL_MONTHLY_TARGETS[sellerLevel] || LEVEL_MONTHLY_TARGETS.ovo;
  const totalLigacoesMes = levelTargets.callsPerMonth ?? (BASE_CALLS_PER_DAY * workDaysInMonth);
  
  // Meta diária = ceil(total_mes / dias_uteis)
  const ligDiaExibicao = Math.ceil(totalLigacoesMes / workDaysInMonth);
  
  const totalDays = dailyActivities.length;
  const daysWithActivity = dailyActivities.filter(d => d.total > 0).length;
  const daysMetTarget = dailyActivities.filter(d => d.calls >= ligDiaExibicao).length;
  const emptyDays = dailyActivities.filter(d => d.total === 0).length;

  const totalCalls = dailyActivities.reduce((sum, d) => sum + d.calls, 0);
  const totalWhatsapp = dailyActivities.reduce((sum, d) => sum + d.whatsapp, 0);
  const avgCallsPerDay = totalDays > 0 ? totalCalls / totalDays : 0;

  const regularityRate = totalDays > 0 ? (daysWithActivity / totalDays) * 100 : 0;
  const targetMetRate = totalDays > 0 ? (daysMetTarget / totalDays) * 100 : 0;

  const isCritical = emptyDays >= 3;
  const isInsufficient = targetMetRate < 70;

  const getStatusLabel = () => {
    if (isCritical) return { label: 'Execução Crítica', color: 'text-red-600', bg: 'bg-red-500/10' };
    if (isInsufficient) return { label: 'Execução Insuficiente', color: 'text-amber-600', bg: 'bg-amber-500/10' };
    return { label: 'Dentro da Régua', color: 'text-emerald-600', bg: 'bg-emerald-500/10' };
  };

  const status = getStatusLabel();

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.05 }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, scale: 0.8 },
    visible: { opacity: 1, scale: 1 }
  };

  return (
    <motion.div
      initial="hidden"
      animate="visible"
      variants={containerVariants}
    >
      <Card className="border-border bg-card">
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2 text-base">
              <Activity className="h-5 w-5 text-primary" />
              Produtividade
            </CardTitle>
            <div className={cn("px-3 py-1 rounded-full text-xs font-medium", status.bg, status.color)}>
              {status.label}
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Summary Stats */}
          <div className="grid grid-cols-4 gap-2">
            <div className="text-center p-2.5 rounded-lg bg-card border border-blue-500/30">
              <Phone className="h-4 w-4 mx-auto text-blue-600 mb-1" />
              <p className="text-base font-semibold">{totalCalls}</p>
              <p className="text-[10px] text-muted-foreground">Ligações</p>
            </div>
            <div className="text-center p-2.5 rounded-lg bg-card border border-green-500/30">
              <MessageCircle className="h-4 w-4 mx-auto text-green-600 mb-1" />
              <p className="text-base font-semibold">{totalWhatsapp}</p>
              <p className="text-[10px] text-muted-foreground">WhatsApp</p>
            </div>
            <div className="text-center p-2.5 rounded-lg bg-card border border-emerald-500/30">
              <CheckCircle className="h-4 w-4 mx-auto text-emerald-600 mb-1" />
              <p className="text-base font-semibold">{daysMetTarget}</p>
              <p className="text-[10px] text-muted-foreground">Dias OK</p>
            </div>
            <div className="text-center p-2.5 rounded-lg bg-card border border-red-500/30">
              <XCircle className="h-4 w-4 mx-auto text-red-600 mb-1" />
              <p className="text-base font-semibold">{emptyDays}</p>
              <p className="text-[10px] text-muted-foreground">Dias Vazios</p>
            </div>
          </div>

          {/* Progress Bars */}
          <div className="space-y-4">
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Taxa de Regularidade</span>
                <span className="font-medium">{regularityRate.toFixed(0)}%</span>
              </div>
              <Progress value={regularityRate} className="h-2" />
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Dias com Meta Atingida ({totalLigacoesMes}/mês | {ligDiaExibicao} lig/dia)</span>
                <span className="font-medium">{targetMetRate.toFixed(0)}%</span>
              </div>
              <Progress 
                value={targetMetRate} 
                className={cn("h-2", targetMetRate < 70 && "bg-amber-100")} 
              />
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Média de Ligações/Dia</span>
                <span className={cn(
                  "font-medium",
                  avgCallsPerDay >= ligDiaExibicao ? "text-emerald-600" : "text-amber-600"
                )}>
                  {avgCallsPerDay.toFixed(1)} / {ligDiaExibicao}
                </span>
              </div>
            </div>
          </div>

          {/* Daily Activity Grid */}
          <div className="space-y-2">
            <div className="space-y-1">
              <p className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <Calendar className="h-4 w-4" />
                Atividade Diária
              </p>
              <p className="text-xs text-muted-foreground">
                Cada número = ligações efetivas do dia (fonte: interações + tarefas)
              </p>
            </div>
            <motion.div 
              variants={containerVariants}
              className="grid grid-cols-7 gap-1"
            >
              {dailyActivities.slice(-28).map((day, index) => {
                const metTarget = day.calls >= ligDiaExibicao;
                
                return (
                  <motion.div
                    key={index}
                    variants={itemVariants}
                    className={cn(
                      "aspect-square rounded border flex items-center justify-center text-[10px] font-medium cursor-default",
                      day.total === 0 
                        ? "bg-muted/30 border-border text-muted-foreground"
                        : metTarget
                          ? "bg-card border-emerald-500/50 text-emerald-700"
                          : "bg-card border-amber-500/50 text-amber-700"
                    )}
                    style={{
                      opacity: day.total === 0 ? 0.5 : 1
                    }}
                    title={`${new Date(day.date).toLocaleDateString('pt-BR')}: ${day.calls} lig, ${day.whatsapp} wpp`}
                  >
                    {day.calls > 0 ? day.calls : '—'}
                  </motion.div>
                );
              })}
            </motion.div>
            <div className="flex items-center justify-center gap-4 text-xs text-muted-foreground mt-2">
              <span className="flex items-center gap-1">
                <div className="w-3 h-3 rounded-sm bg-muted/50" /> Sem atividade
              </span>
              <span className="flex items-center gap-1">
                <div className="w-3 h-3 rounded-sm bg-amber-500/30" /> Abaixo da meta
              </span>
              <span className="flex items-center gap-1">
                <div className="w-3 h-3 rounded-sm bg-emerald-500/30" /> Meta atingida
              </span>
            </div>
          </div>

          {/* Critical Warning */}
          {isCritical && (
            <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/20">
              <p className="text-sm text-red-700 font-medium">
                ⚠️ Execução crítica detectada: {emptyDays} dias sem atividade
              </p>
              <p className="text-xs text-red-600 mt-1">
                Isso bloqueia qualquer benefício, mesmo com meta batida.
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
}
