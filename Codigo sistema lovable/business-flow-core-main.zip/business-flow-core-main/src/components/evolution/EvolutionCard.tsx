import { motion } from 'framer-motion';
import { Egg, Feather, Bird, TrendingUp, TrendingDown, Target, AlertTriangle, Award, Star, Sparkles, Zap, Trophy, ChevronUp } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { BASE_CALLS_PER_DAY, BASE_WHATSAPP_PER_DAY, LEVEL_MONTHLY_TARGETS } from '@/hooks/useComputeTargets';

interface SellerLevel {
  seller_id: string;
  current_level: 'ovo' | 'pena' | 'aguia';
  monthly_sales_target: number;
  daily_calls_target: number;
  consecutive_months_met: number;
  consecutive_months_missed: number;
  commission_bonus: number;
  errors_this_month: number;
}

interface EvolutionCardProps {
  sellerName: string;
  level: SellerLevel;
  currentMonthSales: number;
  currentMonthCalls: number;
  currentMonthWhatsapp?: number;
  workDaysInMonth: number;
  workDaysPassed: number;
}

const levelConfig = {
  ovo: {
    icon: Egg,
    label: 'Aprendiz',
    sublabel: 'Nível OVO',
    gradient: 'from-amber-500/20 via-orange-500/10 to-yellow-500/5',
    border: 'border-amber-500/30',
    glow: 'shadow-amber-500/20',
    iconBg: 'bg-gradient-to-br from-amber-500/20 to-orange-500/10',
    iconColor: 'text-amber-500',
    accentColor: 'amber',
    description: 'Fase de aprendizado e adaptação',
    progressColor: 'bg-amber-500'
  },
  pena: {
    icon: Feather,
    label: 'Intermediário',
    sublabel: 'Nível PENA',
    gradient: 'from-blue-500/20 via-indigo-500/10 to-purple-500/5',
    border: 'border-blue-500/30',
    glow: 'shadow-blue-500/20',
    iconBg: 'bg-gradient-to-br from-blue-500/20 to-indigo-500/10',
    iconColor: 'text-blue-500',
    accentColor: 'blue',
    description: 'Vendedor em fase de consolidação',
    progressColor: 'bg-blue-500'
  },
  aguia: {
    icon: Bird,
    label: 'Águia',
    sublabel: 'Nível ÁGUIA',
    gradient: 'from-emerald-500/20 via-teal-500/10 to-cyan-500/5',
    border: 'border-emerald-500/30',
    glow: 'shadow-emerald-500/20',
    iconBg: 'bg-gradient-to-br from-emerald-500/20 to-teal-500/10',
    iconColor: 'text-emerald-500',
    accentColor: 'emerald',
    description: 'Vendedor consolidado de alta performance',
    progressColor: 'bg-emerald-500'
  }
};

export function EvolutionCard({
  sellerName,
  level,
  currentMonthSales,
  currentMonthCalls,
  currentMonthWhatsapp = 0,
  workDaysInMonth,
  workDaysPassed
}: EvolutionCardProps) {
  const config = levelConfig[level.current_level];
  const Icon = config.icon;

  // Vendas
  const salesProgress = Math.min((currentMonthSales / level.monthly_sales_target) * 100, 100);
  const expectedSalesProgress = (workDaysPassed / workDaysInMonth) * 100;
  const isOnTrackSales = salesProgress >= expectedSalesProgress * 0.85;

  // Metas por nível - PENA/ÁGUIA usam valores fixos mensais
  const levelTargets = LEVEL_MONTHLY_TARGETS[level.current_level] || LEVEL_MONTHLY_TARGETS.ovo;
  
  // Total do mês: usa valor fixo do nível ou calcula baseado em dias úteis
  const totalLigacoesMes = levelTargets.callsPerMonth ?? (BASE_CALLS_PER_DAY * workDaysInMonth);
  const totalWhatsMes = levelTargets.whatsappPerMonth ?? (BASE_WHATSAPP_PER_DAY * workDaysInMonth);
  
  // Meta diária calculada = ceil(total_mes / dias_uteis)
  const ligDiaExibicao = Math.ceil(totalLigacoesMes / workDaysInMonth);
  const whatsDiaExibicao = Math.ceil(totalWhatsMes / workDaysInMonth);
  
  // Esperado até agora
  const expectedCalls = workDaysPassed * ligDiaExibicao;
  const expectedWhatsapp = workDaysPassed * whatsDiaExibicao;
  
  const callsProgress = Math.min((currentMonthCalls / totalLigacoesMes) * 100, 100);
  const isOnTrackCalls = currentMonthCalls >= expectedCalls * 0.85;

  const whatsappProgress = totalWhatsMes > 0 ? Math.min((currentMonthWhatsapp / totalWhatsMes) * 100, 100) : 100;
  const isOnTrackWhatsapp = currentMonthWhatsapp >= expectedWhatsapp * 0.85;

  const monthsToPromotion = Math.max(0, 2 - level.consecutive_months_met);
  const errorsRemaining = Math.max(0, 3 - level.errors_this_month);
  const hasLostBonus = level.errors_this_month >= 4;

  // Regra especial para Aprendiz (OVO): 85% da meta + disciplina + sem excesso de erros
  const isAprendiz = level.current_level === 'ovo';
  const has85PercentOfGoal = salesProgress >= 85;
  const hasDiscipline = isOnTrackCalls && isOnTrackWhatsapp;
  const hasNoExcessErrors = level.errors_this_month <= 3;
  const eligibleForEffortReward = isAprendiz && has85PercentOfGoal && hasDiscipline && hasNoExcessErrors && salesProgress < 100;

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
  };

  // Calculate overall health score
  const healthScore = Math.round((salesProgress + callsProgress + whatsappProgress) / 3);
  const isExcellent = healthScore >= 90;
  const isGood = healthScore >= 70 && healthScore < 90;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20, scale: 0.98 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ duration: 0.4, ease: "easeOut" }}
      className={cn(
        "relative overflow-hidden rounded-2xl border bg-card",
        config.border,
        "shadow-lg hover:shadow-xl transition-all duration-300"
      )}
    >
      {/* Background gradient overlay */}
      <div className={cn(
        "absolute inset-0 bg-gradient-to-br opacity-50",
        config.gradient
      )} />
      
      {/* Animated glow effect for high performers */}
      {isExcellent && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: [0.3, 0.6, 0.3] }}
          transition={{ duration: 3, repeat: Infinity }}
          className={cn(
            "absolute inset-0 blur-3xl",
            `bg-${config.accentColor}-500/10`
          )}
        />
      )}

      <div className="relative p-6">
        {/* Header */}
        <div className="flex items-start justify-between mb-6">
          <div className="flex items-center gap-4">
            <motion.div 
              whileHover={{ scale: 1.05, rotate: 5 }}
              transition={{ type: "spring", stiffness: 400 }}
              className={cn(
                "relative p-3 rounded-xl",
                config.iconBg,
                "shadow-inner"
              )}
            >
              <Icon className={cn("h-7 w-7", config.iconColor)} />
              {isExcellent && (
                <motion.div
                  animate={{ scale: [1, 1.2, 1] }}
                  transition={{ duration: 2, repeat: Infinity }}
                  className="absolute -top-1 -right-1"
                >
                  <Sparkles className="h-4 w-4 text-yellow-500" />
                </motion.div>
              )}
            </motion.div>
            <div>
              <h3 className="text-lg font-bold tracking-tight">{sellerName}</h3>
              <div className="flex items-center gap-2 mt-0.5">
                <span className={cn("text-sm font-semibold", config.iconColor)}>
                  {config.label}
                </span>
                <span className="text-xs text-muted-foreground/70 font-medium">
                  {config.sublabel}
                </span>
              </div>
            </div>
          </div>

          <div className="flex flex-col items-end gap-2">
            {eligibleForEffortReward && (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
              >
                <Badge className="bg-purple-500/15 text-purple-500 border-purple-500/30 hover:bg-purple-500/20">
                  <Award className="h-3.5 w-3.5 mr-1.5" />
                  Elegível Premiação
                </Badge>
              </motion.div>
            )}
            
            {level.consecutive_months_met > 0 && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-500/15 border border-emerald-500/20"
              >
                <TrendingUp className="h-3.5 w-3.5 text-emerald-500" />
                <span className="text-xs font-semibold text-emerald-600">
                  {level.consecutive_months_met} mês{level.consecutive_months_met > 1 ? 'es' : ''} consecutivo{level.consecutive_months_met > 1 ? 's' : ''}
                </span>
              </motion.div>
            )}

            {level.consecutive_months_missed > 0 && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-red-500/15 border border-red-500/20"
              >
                <TrendingDown className="h-3.5 w-3.5 text-red-500" />
                <span className="text-xs font-semibold text-red-600">
                  {level.consecutive_months_missed} mês{level.consecutive_months_missed > 1 ? 'es' : ''} abaixo
                </span>
              </motion.div>
            )}
          </div>
        </div>

        {/* Effort Reward Notice for Aprendiz */}
        {eligibleForEffortReward && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            className="mb-6 p-4 rounded-xl bg-gradient-to-r from-purple-500/10 via-violet-500/10 to-fuchsia-500/10 border border-purple-500/20"
          >
            <div className="flex items-start gap-3">
              <div className="p-1.5 rounded-lg bg-purple-500/20">
                <Star className="h-4 w-4 text-purple-500" />
              </div>
              <div>
                <p className="text-sm font-semibold text-purple-600">Premiação por Esforço</p>
                <p className="text-xs text-purple-500/80 mt-1 leading-relaxed">
                  Atingiu ≥85% da meta com disciplina e sem erros em excesso. 
                  Elegível para premiação especial, mas <strong>não conta para promoção</strong>.
                </p>
              </div>
            </div>
          </motion.div>
        )}

        {/* Progress Metrics */}
        <div className="space-y-5">
          {/* Sales Progress */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className={cn("p-1.5 rounded-lg", config.iconBg)}>
                  <Target className={cn("h-4 w-4", config.iconColor)} />
                </div>
                <span className="text-sm font-medium">Meta de Vendas</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-base font-bold">{formatCurrency(currentMonthSales)}</span>
                <span className="text-sm text-muted-foreground">/ {formatCurrency(level.monthly_sales_target)}</span>
              </div>
            </div>
            <div className="relative h-3 bg-muted/50 rounded-full overflow-hidden">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${salesProgress}%` }}
                transition={{ duration: 1, ease: "easeOut" }}
                className={cn(
                  "absolute inset-y-0 left-0 rounded-full",
                  config.progressColor,
                  "shadow-sm"
                )}
              />
              {/* Expected marker */}
              <div 
                className="absolute top-0 bottom-0 w-0.5 bg-foreground/40 z-10"
                style={{ left: `${Math.min(expectedSalesProgress, 100)}%` }}
              >
                <div className="absolute -top-1 left-1/2 -translate-x-1/2 w-2 h-2 rounded-full bg-foreground/60" />
              </div>
            </div>
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center gap-1.5">
                {isOnTrackSales ? (
                  <Zap className="h-3.5 w-3.5 text-emerald-500" />
                ) : (
                  <AlertTriangle className="h-3.5 w-3.5 text-amber-500" />
                )}
                <span className={cn(
                  "font-medium",
                  isOnTrackSales ? "text-emerald-600" : "text-amber-600"
                )}>
                  {salesProgress.toFixed(0)}% atingido
                </span>
              </div>
              <span className="text-muted-foreground">
                Esperado: {expectedSalesProgress.toFixed(0)}%
              </span>
            </div>
          </div>

          {/* Calls Progress */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="p-1.5 rounded-lg bg-blue-500/10">
                  <span className="text-sm">📞</span>
                </div>
                <span className="text-sm font-medium">
                  Ligações
                  <span className="text-muted-foreground ml-1.5 text-xs">
                    ({totalLigacoesMes}/mês • {ligDiaExibicao}/dia)
                  </span>
                </span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-base font-bold">{currentMonthCalls}</span>
                <span className="text-sm text-muted-foreground">/ {totalLigacoesMes}</span>
              </div>
            </div>
            <div className="relative h-3 bg-muted/50 rounded-full overflow-hidden">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${callsProgress}%` }}
                transition={{ duration: 1, ease: "easeOut", delay: 0.2 }}
                className={cn(
                  "absolute inset-y-0 left-0 rounded-full",
                  isOnTrackCalls ? "bg-blue-500" : "bg-amber-500",
                  "shadow-sm"
                )}
              />
            </div>
            <div className="flex items-center gap-1.5 text-xs">
              {isOnTrackCalls ? (
                <>
                  <ChevronUp className="h-3.5 w-3.5 text-emerald-500" />
                  <span className="font-medium text-emerald-600">Produtividade dentro da régua</span>
                </>
              ) : (
                <>
                  <AlertTriangle className="h-3.5 w-3.5 text-amber-500" />
                  <span className="font-medium text-amber-600">Produtividade abaixo da régua</span>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Footer Status */}
        <div className="grid grid-cols-3 gap-4 mt-6 pt-5 border-t border-border/50">
          <motion.div 
            whileHover={{ scale: 1.02 }}
            className="text-center p-3 rounded-xl bg-muted/30 hover:bg-muted/50 transition-colors"
          >
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium mb-1">
              Promoção em
            </p>
            <p className="text-lg font-bold">
              {level.current_level === 'aguia' ? (
                <Trophy className="h-5 w-5 mx-auto text-emerald-500" />
              ) : (
                <span className={monthsToPromotion <= 1 ? "text-emerald-600" : ""}>
                  {monthsToPromotion} mês{monthsToPromotion !== 1 ? 'es' : ''}
                </span>
              )}
            </p>
          </motion.div>
          
          <motion.div 
            whileHover={{ scale: 1.02 }}
            className="text-center p-3 rounded-xl bg-emerald-500/10 hover:bg-emerald-500/15 transition-colors"
          >
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium mb-1">
              Bônus Comissão
            </p>
            <p className="text-lg font-bold text-emerald-600">
              +{level.commission_bonus.toFixed(1)}%
            </p>
          </motion.div>
          
          <motion.div 
            whileHover={{ scale: 1.02 }}
            className={cn(
              "text-center p-3 rounded-xl transition-colors",
              hasLostBonus 
                ? "bg-red-500/10 hover:bg-red-500/15" 
                : errorsRemaining <= 1 
                  ? "bg-amber-500/10 hover:bg-amber-500/15"
                  : "bg-muted/30 hover:bg-muted/50"
            )}
          >
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium mb-1">
              Erros Restantes
            </p>
            <p className={cn(
              "text-lg font-bold",
              hasLostBonus ? "text-red-600" : errorsRemaining <= 1 ? "text-amber-600" : ""
            )}>
              {hasLostBonus ? (
                <span className="flex items-center justify-center gap-1.5 text-sm">
                  <AlertTriangle className="h-4 w-4" />
                  Bloqueado
                </span>
              ) : (
                errorsRemaining
              )}
            </p>
          </motion.div>
        </div>
      </div>
    </motion.div>
  );
}
