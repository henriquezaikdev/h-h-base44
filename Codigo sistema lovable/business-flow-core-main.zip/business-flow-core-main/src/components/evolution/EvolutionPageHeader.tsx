import { motion } from 'framer-motion';
import { Bird, TrendingUp, Sparkles, Calendar } from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface EvolutionPageHeaderProps {
  sellerName?: string;
  isAdmin: boolean;
}

export function EvolutionPageHeader({ sellerName, isAdmin }: EvolutionPageHeaderProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-violet-500/15 via-purple-500/10 to-fuchsia-500/5 border border-violet-500/20 p-6"
    >
      {/* Decorative blur spheres */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute -top-20 -right-20 w-60 h-60 bg-violet-500/20 rounded-full blur-3xl" />
        <div className="absolute -bottom-20 -left-20 w-40 h-40 bg-fuchsia-500/15 rounded-full blur-3xl" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-32 h-32 bg-purple-400/10 rounded-full blur-2xl" />
      </div>

      {/* Sparkles decoration */}
      <motion.div
        initial={{ opacity: 0, scale: 0 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.3, duration: 0.4 }}
        className="absolute top-4 right-6"
      >
        <Sparkles className="h-6 w-6 text-violet-400/50" />
      </motion.div>

      <div className="relative flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <motion.div
            initial={{ scale: 0.5, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.2, type: 'spring', stiffness: 200 }}
            className="w-14 h-14 rounded-2xl bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center shadow-lg shadow-violet-500/25"
          >
            <Bird className="h-7 w-7 text-white" />
          </motion.div>

          <div>
            <motion.h1
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.15 }}
              className="text-2xl md:text-3xl font-bold text-foreground"
            >
              Evolução de Vendedor
            </motion.h1>
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.25 }}
              className="text-muted-foreground flex items-center gap-2 mt-1"
            >
              <TrendingUp className="h-4 w-4 text-violet-500" />
              {sellerName ? (
                <span>Acompanhamento de <span className="font-medium text-foreground">{sellerName}</span></span>
              ) : (
                <span>Gerencie a evolução e performance da equipe</span>
              )}
            </motion.p>
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3 }}
          className="flex items-center gap-2 text-sm text-muted-foreground bg-background/50 backdrop-blur-sm rounded-lg px-3 py-2 border border-border/50"
        >
          <Calendar className="h-4 w-4 text-violet-500" />
          <span className="capitalize font-medium">
            {format(new Date(), "MMMM 'de' yyyy", { locale: ptBR })}
          </span>
        </motion.div>
      </div>
    </motion.div>
  );
}
