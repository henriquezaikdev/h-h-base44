import { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  RotateCcw, Trophy, Clock, CheckCircle2, Target, 
  ChevronRight, RefreshCw, Calendar, Award
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { useReactivationsData, ReactivationStatus } from '@/hooks/useReactivationsData';
import { ReactivationsDetailSheet } from './ReactivationsDetailSheet';
import { cn } from '@/lib/utils';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

async function fetchSellerTarget(sellerId: string): Promise<{ target: number; reward: number }> {
  const { data } = await supabase
    .from('seller_levels')
    .select('reactivations_target, reactivations_stars_reward')
    .eq('seller_id', sellerId)
    .maybeSingle();
  
  return {
    target: data?.reactivations_target ?? 2,
    reward: data?.reactivations_stars_reward ?? 1,
  };
}

interface ReactivationsCardProps {
  sellerId: string;
  sellerName: string;
  month?: number;
  year?: number;
  isAdmin?: boolean;
}

const MONTH_NAMES = [
  'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
  'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
];

export function ReactivationsCard({ 
  sellerId, 
  sellerName, 
  month, 
  year, 
  isAdmin = false 
}: ReactivationsCardProps) {
  const [isDetailOpen, setIsDetailOpen] = useState(false);
  
  const targetMonth = month ?? new Date().getMonth() + 1;
  const targetYear = year ?? new Date().getFullYear();
  const monthLabel = `${MONTH_NAMES[targetMonth - 1]} ${targetYear}`;

  const { data: targetData } = useQuery({
    queryKey: ['seller-reactivations-target', sellerId],
    queryFn: () => fetchSellerTarget(sellerId),
    staleTime: 1000 * 60 * 10,
  });

  const { 
    reactivations,
    stats,
    ranking,
    loading,
    verifyReactivation,
    recalculateMonth,
    refetch
  } = useReactivationsData(sellerId, isAdmin, targetMonth, targetYear);

  // Encontrar posição do vendedor no ranking
  const sellerRanking = ranking.find(r => r.sellerId === sellerId);
  const rank = sellerRanking?.rank ?? 0;
  const isLeader = sellerRanking?.isLeader ?? false;

  // Meta e progresso
  const target = targetData?.target ?? 2;
  const reward = targetData?.reward ?? 1;
  const isGoalMet = stats.confirmed >= target;
  const progressPercent = Math.min((stats.confirmed / target) * 100, 100);

  // Calcular progresso de verificação
  const verifiedCount = stats.confirmed + stats.longWindow;
  const verifiedPercent = stats.total > 0 ? (verifiedCount / stats.total) * 100 : 0;

  const handleRecalculate = async () => {
    await recalculateMonth();
    await refetch();
  };

  if (loading) {
    return (
      <Card className="border-border/60 animate-pulse">
        <CardHeader className="pb-3">
          <div className="h-6 bg-muted rounded w-1/2" />
        </CardHeader>
        <CardContent>
          <div className="h-24 bg-muted rounded" />
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.15 }}
      >
        <Card className={cn(
          "border-border/60 relative overflow-hidden transition-all",
          isLeader && "border-amber-500/50 bg-gradient-to-br from-amber-500/5 to-background",
          isGoalMet && !isLeader && "border-emerald-500/30 bg-gradient-to-br from-emerald-500/5 to-background"
        )}>
          {/* Leader badge */}
          {isLeader && stats.confirmed > 0 && (
            <div className="absolute top-3 right-3">
              <Badge className="bg-gradient-to-r from-amber-500 to-orange-500 text-white border-0 gap-1">
                <Trophy className="h-3 w-3" />
                Líder
              </Badge>
            </div>
          )}

          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base">
              <div className="w-8 h-8 bg-orange-500/10 rounded-lg flex items-center justify-center">
                <RotateCcw className="h-4 w-4 text-orange-500" />
              </div>
              <div className="flex-1">
                <span>Reativações (Inativos)</span>
                <p className="text-xs text-muted-foreground font-normal mt-0.5">
                  {monthLabel}
                </p>
              </div>
              {isAdmin && (
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="h-7 w-7"
                  onClick={handleRecalculate}
                >
                  <RefreshCw className="h-3.5 w-3.5" />
                </Button>
              )}
            </CardTitle>
          </CardHeader>

          <CardContent className="space-y-4">
          {/* Main Stats */}
          <div className="grid grid-cols-3 gap-3">
            <div className="text-center">
              <span className={cn(
                "text-3xl font-bold",
                isGoalMet ? "text-emerald-600" : "text-foreground"
              )}>
                {stats.confirmed}
              </span>
              <p className="text-xs text-muted-foreground">Confirmadas</p>
            </div>
            <div className="text-center">
              <span className="text-3xl font-bold text-muted-foreground">{target}</span>
              <p className="text-xs text-muted-foreground">Meta</p>
            </div>
            <div className="text-center">
              {rank > 0 ? (
                <span className="text-3xl font-bold">{rank}º</span>
              ) : (
                <span className="text-3xl font-bold text-muted-foreground">-</span>
              )}
              <p className="text-xs text-muted-foreground">Ranking</p>
            </div>
          </div>

          {/* Goal Progress */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-muted-foreground">Progresso da Meta</span>
              <span className={cn(
                "font-medium",
                isGoalMet ? "text-emerald-600" : "text-muted-foreground"
              )}>
                {stats.confirmed}/{target} {isGoalMet && `(+${reward} ⭐)`}
              </span>
            </div>
            <Progress 
              value={progressPercent} 
              className={cn("h-2", isGoalMet && "[&>div]:bg-emerald-500")}
            />
          </div>

            {/* Status breakdown */}
            <div className="grid grid-cols-3 gap-2 text-center">
              <div className="p-2 rounded-lg bg-status-success/10">
                <div className="flex items-center justify-center gap-1 text-status-success">
                  <CheckCircle2 className="h-3.5 w-3.5" />
                  <span className="text-sm font-semibold">{stats.confirmed}</span>
                </div>
                <p className="text-xs text-muted-foreground mt-0.5">Confirmadas</p>
              </div>
              
              <div className="p-2 rounded-lg bg-amber-500/10">
                <div className="flex items-center justify-center gap-1 text-amber-500">
                  <Clock className="h-3.5 w-3.5" />
                  <span className="text-sm font-semibold">{stats.pending}</span>
                </div>
                <p className="text-xs text-muted-foreground mt-0.5">Pendentes</p>
              </div>
              
              <div className="p-2 rounded-lg bg-blue-500/10">
                <div className="flex items-center justify-center gap-1 text-blue-500">
                  <Calendar className="h-3.5 w-3.5" />
                  <span className="text-sm font-semibold">{stats.longWindow}</span>
                </div>
                <p className="text-xs text-muted-foreground mt-0.5">Janela Longa</p>
              </div>
            </div>

            {/* Verification progress */}
            {stats.total > 0 && (
              <div className="space-y-1">
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>Verificação</span>
                  <span>{verifiedCount}/{stats.total}</span>
                </div>
                <Progress 
                  value={verifiedPercent} 
                  className="h-1.5"
                />
              </div>
            )}

            {/* Pending alert */}
            {stats.pending > 0 && (
              <div className="flex items-center gap-2 p-2 rounded-lg bg-amber-500/10 border border-amber-500/20">
                <Clock className="h-4 w-4 text-amber-500 shrink-0" />
                <p className="text-xs text-amber-600 dark:text-amber-400">
                  {stats.pending} reativaç{stats.pending > 1 ? 'ões aguardam' : 'ão aguarda'} verificação
                </p>
              </div>
            )}

            {/* Empty state */}
            {stats.total === 0 && (
              <div className="text-center py-4 text-muted-foreground">
                <RotateCcw className="h-8 w-8 mx-auto mb-2 opacity-30" />
                <p className="text-sm">Nenhuma reativação detectada</p>
                <p className="text-xs mt-1">
                  Clientes &gt;120 dias sem comprar que voltarem aparecerão aqui
                </p>
              </div>
            )}

            {/* View details button */}
            {stats.total > 0 && (
              <Button
                variant="ghost"
                className="w-full justify-between text-sm"
                onClick={() => setIsDetailOpen(true)}
              >
                <span>Ver detalhes e verificar</span>
                <ChevronRight className="h-4 w-4" />
              </Button>
            )}

            {/* Mini ranking for admins */}
            {isAdmin && ranking.length > 0 && (
              <div className="pt-3 border-t border-border/50 space-y-2">
                <p className="text-xs font-medium text-muted-foreground">
                  Top Reativadores do Mês
                </p>
                {ranking.slice(0, 3).map((r, idx) => (
                  <div 
                    key={r.sellerId}
                    className={cn(
                      "flex items-center justify-between text-sm p-2 rounded-lg",
                      r.sellerId === sellerId && "bg-primary/10"
                    )}
                  >
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-muted-foreground w-4">
                        {idx === 0 ? '🥇' : idx === 1 ? '🥈' : '🥉'}
                      </span>
                      <span className={cn(
                        r.sellerId === sellerId && "font-semibold"
                      )}>
                        {r.sellerName}
                      </span>
                    </div>
                    <Badge variant="secondary" className="text-xs">
                      {r.confirmedCount}
                    </Badge>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>

      {/* Detail Sheet */}
      <ReactivationsDetailSheet
        open={isDetailOpen}
        onOpenChange={setIsDetailOpen}
        reactivations={reactivations}
        stats={stats}
        ranking={ranking}
        sellerId={sellerId}
        sellerName={sellerName}
        monthLabel={monthLabel}
        isAdmin={isAdmin}
        onVerify={verifyReactivation}
      />
    </>
  );
}
