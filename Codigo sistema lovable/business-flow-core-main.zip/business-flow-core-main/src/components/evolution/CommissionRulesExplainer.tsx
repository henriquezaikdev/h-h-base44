import { BookOpen, CheckCircle2, XCircle, AlertTriangle, Lightbulb, Zap } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { COMMISSION_TIERS_NORMAL, COMMISSION_TIERS_SPECIAL } from '@/lib/commissionConfig';

interface CategoryBonusEligibility {
  categoryKey: string;
  isMet: boolean;
  margin: number;
  isEligible: boolean;
}

interface CommissionRulesExplainerProps {
  sellerLevel: 'ovo' | 'pena' | 'aguia';
  categoryEligibility: CategoryBonusEligibility[];
  hasLostBonus: boolean;
  month: number;
  year: number;
  isSpecialRule?: boolean;
  metaPercentage?: number;
}

export function CommissionRulesExplainer({
  sellerLevel,
  categoryEligibility,
  hasLostBonus,
  month,
  year,
  isSpecialRule = false,
  metaPercentage = 0,
}: CommissionRulesExplainerProps) {
  const isNewRuleActive = year > 2026 || (year === 2026 && month >= 2);
  const activeTiers = isSpecialRule ? COMMISSION_TIERS_SPECIAL : COMMISSION_TIERS_NORMAL;

  return (
    <Card className="border-primary/20">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-base">
          <BookOpen className="h-5 w-5 text-primary" />
          Como Funciona a Comissão
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Accordion type="multiple" className="w-full" defaultValue={["base"]}>
          {/* Seção 1 — Comissão Base */}
          <AccordionItem value="base">
            <AccordionTrigger className="text-sm font-semibold hover:no-underline">
              1. Comissão Base (por Margem Real)
            </AccordionTrigger>
            <AccordionContent className="space-y-3">
              {isSpecialRule && (
                <div className="flex items-center gap-2 p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/30 mb-2">
                  <Zap className="h-4 w-4 text-emerald-600 shrink-0" />
                  <span className="text-xs text-emerald-700 font-medium">
                    Regra especial ativada! Meta geral acima de 130% ({metaPercentage.toFixed(0)}%).
                  </span>
                </div>
              )}
              <p className="text-xs text-muted-foreground">
                Cada pedido gera comissão conforme a <strong>margem real</strong> da venda:
              </p>
              <div className="grid gap-1.5">
                {activeTiers.map((t) => (
                  <div key={t.range} className={cn("flex items-center justify-between px-3 py-2 rounded-lg text-sm", t.bg)}>
                    <span className="text-muted-foreground">Margem {t.range}</span>
                    <span className={cn("font-bold", t.color)}>{t.rate}</span>
                  </div>
                ))}
              </div>
              <p className="text-[11px] text-muted-foreground italic">
                * A margem real já inclui o desconto de 15% de taxa de faturamento sobre o valor bruto.
                {!isSpecialRule && ' Ao atingir 130% da meta geral, faixas mais agressivas são ativadas automaticamente.'}
              </p>
            </AccordionContent>
          </AccordionItem>

          {/* Seção 2 — Bônus por Categoria */}
          <AccordionItem value="bonus">
            <AccordionTrigger className="text-sm font-semibold hover:no-underline">
              2. Bônus por Categoria {!isNewRuleActive && <Badge variant="outline" className="ml-2 text-[10px]">a partir de Fev/2026</Badge>}
            </AccordionTrigger>
            <AccordionContent className="space-y-4">
              <p className="text-xs text-muted-foreground">
                Vendedores podem ganhar bônus <strong>por categoria</strong>, desde que atendam <strong>ambas</strong> as condições:
              </p>

              <div className="space-y-2">
                <div className="flex items-start gap-2 text-sm">
                  <CheckCircle2 className="h-4 w-4 text-emerald-500 mt-0.5 shrink-0" />
                  <span>Bater a <strong>meta de vendas</strong> da categoria (realizado ≥ meta)</span>
                </div>
                <div className="flex items-start gap-2 text-sm">
                  <CheckCircle2 className="h-4 w-4 text-emerald-500 mt-0.5 shrink-0" />
                  <span><strong>Margem média</strong> da categoria ≥ 40%</span>
                </div>
              </div>

              {/* Bônus por faixa de margem */}
              <div className="rounded-lg border border-border overflow-hidden">
                <div className="grid grid-cols-3 text-xs font-semibold text-center bg-muted/50">
                  <div className="p-2 border-r border-border">Condição</div>
                  <div className="p-2 border-r border-border">Bônus</div>
                  <div className="p-2">Aplicação</div>
                </div>
                <div className="grid grid-cols-3 text-xs text-center border-t border-border">
                  <div className="p-2 border-r border-border text-amber-600 font-medium">Meta + Margem ≥ 40%</div>
                  <div className="p-2 border-r border-border font-bold text-blue-600">+0,5%</div>
                  <div className="p-2 text-muted-foreground">Sobre vendas da categoria</div>
                </div>
                <div className="grid grid-cols-3 text-xs text-center border-t border-border">
                  <div className="p-2 border-r border-border text-emerald-600 font-medium">Meta + Margem ≥ 60%</div>
                  <div className="p-2 border-r border-border font-bold text-emerald-600">+1,0%</div>
                  <div className="p-2 text-muted-foreground">Sobre vendas da categoria</div>
                </div>
              </div>

              {/* Bloqueio */}
              <div className="flex items-start gap-2 p-3 rounded-lg bg-red-500/10 text-sm">
                <AlertTriangle className="h-4 w-4 text-red-500 mt-0.5 shrink-0" />
                <span className="text-red-600">
                  <strong>4+ erros no mês</strong> = bônus de categoria bloqueado para todas as categorias.
                </span>
              </div>

              {/* Status por categoria */}
              {isNewRuleActive && categoryEligibility.length > 0 && (
                <div className="space-y-2">
                  <p className="text-xs font-semibold text-muted-foreground">Suas categorias este mês:</p>
                  <div className="grid gap-1.5">
                    {categoryEligibility.map((cat) => {
                      const eligible = cat.isEligible && !hasLostBonus;
                      const bonusLabel = cat.margin >= 60 ? '+1,0%' : cat.margin >= 40 ? '+0,5%' : '—';
                      return (
                        <div key={cat.categoryKey} className={cn(
                          "flex items-center justify-between px-3 py-2 rounded-lg text-sm",
                          eligible ? "bg-emerald-500/10" : "bg-muted/30"
                        )}>
                          <div className="flex items-center gap-2">
                            {eligible
                              ? <CheckCircle2 className="h-4 w-4 text-emerald-500" />
                              : <XCircle className="h-4 w-4 text-muted-foreground" />}
                            <span className="font-medium">{cat.categoryKey}</span>
                          </div>
                          <div className="flex items-center gap-3 text-xs text-muted-foreground">
                            <span>Meta: {cat.isMet ? '✅' : '❌'}</span>
                            <span>Margem: {typeof cat.margin === 'number' ? cat.margin.toFixed(0) : cat.margin}%</span>
                            {eligible && (
                              <Badge className="bg-emerald-500/20 text-emerald-700 text-[10px]">
                                {bonusLabel}
                              </Badge>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </AccordionContent>
          </AccordionItem>

          {/* Seção 3 — Regra Especial 130% */}
          <AccordionItem value="especial">
            <AccordionTrigger className="text-sm font-semibold hover:no-underline">
              3. Regra Especial — 130% da Meta
            </AccordionTrigger>
            <AccordionContent className="space-y-3">
              <p className="text-xs text-muted-foreground">
                Quando o vendedor atinge <strong>130% ou mais da meta geral</strong> do mês, as faixas de comissão base são automaticamente substituídas por faixas mais agressivas:
              </p>
              <div className="grid gap-1.5">
                {COMMISSION_TIERS_SPECIAL.map((t) => (
                  <div key={t.range} className={cn("flex items-center justify-between px-3 py-2 rounded-lg text-sm", t.bg)}>
                    <span className="text-muted-foreground">Margem {t.range}</span>
                    <span className={cn("font-bold", t.color)}>{t.rate}</span>
                  </div>
                ))}
              </div>
              <p className="text-[11px] text-muted-foreground italic">
                Esta regra especial se aplica a <strong>todos</strong> os pedidos do mês quando ativada.
              </p>
            </AccordionContent>
          </AccordionItem>

          {/* Seção 4 — Exemplo Prático */}
          <AccordionItem value="exemplo">
            <AccordionTrigger className="text-sm font-semibold hover:no-underline">
              4. Exemplo Prático
            </AccordionTrigger>
            <AccordionContent className="space-y-3">
              <div className="p-3 rounded-lg bg-muted/30 space-y-2 text-sm">
                <div className="flex items-center gap-2">
                  <Lightbulb className="h-4 w-4 text-amber-500 shrink-0" />
                  <span className="font-semibold">Venda de R$ 10.000 com margem real de 46%</span>
                </div>
                <div className="pl-6 space-y-1 text-muted-foreground">
                  <p>→ Faixa ≥45% → Comissão base: <strong className="text-foreground">2,0%</strong></p>
                  <p>→ Comissão base = R$ 10.000 × 2,0% = <strong className="text-foreground">R$ 200,00</strong></p>
                </div>
              </div>

              <div className="p-3 rounded-lg bg-emerald-500/10 space-y-2 text-sm">
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-emerald-700">Se categoria elegível com margem ≥ 60%:</span>
                </div>
                <div className="pl-2 space-y-1 text-muted-foreground">
                  <p>→ Base 2,0% + Bônus 1,0% = <strong className="text-emerald-700">3,0%</strong></p>
                  <p>→ R$ 10.000 × 3,0% = <strong className="text-emerald-700">R$ 300,00</strong></p>
                </div>
              </div>

              <p className="text-[11px] text-muted-foreground italic">
                O bônus é aplicado somente nas categorias onde ambas as condições foram atingidas.
              </p>
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      </CardContent>
    </Card>
  );
}
