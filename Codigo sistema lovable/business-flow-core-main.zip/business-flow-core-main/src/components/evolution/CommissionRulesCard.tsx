import { Egg, Feather, Bird, Award } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

interface CommissionRulesCardProps {
  currentLevel: 'ovo' | 'pena' | 'aguia';
}

export function CommissionRulesCard({ currentLevel }: CommissionRulesCardProps) {
  return (
    <Card className="border-primary/20 bg-primary/5">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-base">
          <Award className="h-5 w-5 text-primary" />
          Bônus de Comissão por Nível
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {/* Nível OVO */}
        <div className={cn(
          "p-3 rounded-lg transition-all",
          currentLevel === 'ovo' 
            ? "bg-amber-500/10 border border-amber-500/30" 
            : "bg-muted/30 opacity-60"
        )}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Egg className="h-4 w-4 text-amber-500" />
              <span className="font-medium text-sm">Ovo (Aprendiz)</span>
              {currentLevel === 'ovo' && (
                <Badge variant="secondary" className="text-xs">Seu Nível</Badge>
              )}
            </div>
            <span className="text-xs text-muted-foreground">Sem bônus</span>
          </div>
          <p className="text-xs text-muted-foreground mt-1">
            Comissão padrão. Foco em aprendizado e disciplina.
          </p>
        </div>
        
        {/* Nível PENA */}
        <div className={cn(
          "p-3 rounded-lg transition-all",
          currentLevel === 'pena' 
            ? "bg-blue-500/10 border border-blue-500/30" 
            : "bg-muted/30 opacity-60"
        )}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Feather className="h-4 w-4 text-blue-500" />
              <span className="font-medium text-sm">Pena (Intermediário)</span>
              {currentLevel === 'pena' && (
                <Badge variant="secondary" className="text-xs">Seu Nível</Badge>
              )}
            </div>
            <Badge className="bg-emerald-500/10 text-emerald-700 border-emerald-500/20 text-xs">
              +0,5%
            </Badge>
          </div>
          <p className="text-xs text-emerald-600 dark:text-emerald-400 mt-1 font-medium">
            ✨ Bônus de +0,5% em vendas com margem ≥40%
          </p>
        </div>
        
        {/* Nível ÁGUIA */}
        <div className={cn(
          "p-3 rounded-lg transition-all",
          currentLevel === 'aguia' 
            ? "bg-purple-500/10 border border-purple-500/30" 
            : "bg-muted/30 opacity-60"
        )}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Bird className="h-4 w-4 text-purple-500" />
              <span className="font-medium text-sm">Águia</span>
              {currentLevel === 'aguia' && (
                <Badge variant="secondary" className="text-xs">Seu Nível</Badge>
              )}
            </div>
            <Badge className="bg-emerald-500/10 text-emerald-700 border-emerald-500/20 text-xs">
              +1%
            </Badge>
          </div>
          <p className="text-xs text-emerald-600 dark:text-emerald-400 mt-1 font-medium">
            ✨ Bônus de +1% em vendas com margem ≥40%
          </p>
        </div>
        
        {/* Regra geral */}
        <div className="pt-2 border-t border-border/50">
          <p className="text-xs text-muted-foreground">
            ⚠️ O bônus só é aplicado em vendas com margem bruta ≥40%.
            4+ erros no mês = bônus bloqueado.
          </p>
        </div>

        {/* Nova regra a partir de Fev/2026 */}
        <div className="mt-3 p-3 bg-amber-500/10 rounded-lg border border-amber-500/20">
          <p className="text-sm text-amber-700 dark:text-amber-400 font-medium">
            📅 Nova regra a partir de Fevereiro de 2026
          </p>
          <p className="text-xs text-muted-foreground mt-1">
            O bônus de comissão será aplicado <strong>por categoria</strong>: apenas em categorias 
            onde a meta foi batida E a margem ficou ≥40%.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
