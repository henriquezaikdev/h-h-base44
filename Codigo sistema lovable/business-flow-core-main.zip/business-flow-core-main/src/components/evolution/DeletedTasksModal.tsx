import { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Loader2 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface DeletedTask {
  id: string;
  task_id: string;
  client_name: string | null;
  contact_type: string | null;
  contact_reason: string | null;
  due_date_original: string | null;
  deleted_at: string;
  task_notes: string | null;
}

interface DeletedTasksModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  sellerId: string | null;
  month: number;
  year: number;
}

export function DeletedTasksModal({
  open,
  onOpenChange,
  sellerId,
  month,
  year,
}: DeletedTasksModalProps) {
  const [loading, setLoading] = useState(false);
  const [tasks, setTasks] = useState<DeletedTask[]>([]);

  useEffect(() => {
    if (open && sellerId) {
      fetchDeletedTasks();
    }
  }, [open, sellerId, month, year]);

  const fetchDeletedTasks = async () => {
    if (!sellerId) return;
    
    setLoading(true);
    try {
      const startDate = new Date(year, month - 1, 1);
      const endDate = new Date(year, month, 0, 23, 59, 59);

      const { data, error } = await supabase
        .from('task_deletions_log')
        .select('*')
        .eq('vendor_id', sellerId)
        .gte('deleted_at', startDate.toISOString())
        .lte('deleted_at', endDate.toISOString())
        .order('deleted_at', { ascending: false });

      if (error) throw error;
      setTasks(data || []);
    } catch (error) {
      console.error('Error fetching deleted tasks:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatContactType = (type: string | null) => {
    if (!type) return '-';
    return type === 'ligacao' ? 'Ligação' : 'WhatsApp';
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Tarefas Excluídas no Período</DialogTitle>
        </DialogHeader>

        {loading ? (
          <div className="flex justify-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : tasks.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            Nenhuma tarefa excluída neste período.
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Cliente</TableHead>
                <TableHead>Tipo</TableHead>
                <TableHead>Data Original</TableHead>
                <TableHead>Excluída em</TableHead>
                <TableHead>Observações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {tasks.map((task) => (
                <TableRow key={task.id}>
                  <TableCell className="font-medium">
                    {task.client_name || 'Cliente não identificado'}
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline" className="text-xs">
                      {formatContactType(task.contact_type)}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    {task.due_date_original
                      ? format(new Date(task.due_date_original), 'dd/MM/yyyy', { locale: ptBR })
                      : '-'}
                  </TableCell>
                  <TableCell>
                    {format(new Date(task.deleted_at), 'dd/MM/yyyy HH:mm', { locale: ptBR })}
                  </TableCell>
                  <TableCell className="max-w-[200px] truncate text-muted-foreground text-sm">
                    {task.task_notes || '-'}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </DialogContent>
    </Dialog>
  );
}