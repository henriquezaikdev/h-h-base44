import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { AlertTriangle, Package, FileText, Loader2, Pencil, Trash2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { ProductEditModal } from './ProductEditModal';

interface ProductWithoutCost {
  id: string;
  name: string;
  sku: string | null;
  orderItemsCount: number;
  ordersCount: number;
  totalValue: number;
}

interface ReportData {
  productsWithoutCost: ProductWithoutCost[];
  totalProducts: number;
  totalOrdersAffected: number;
  totalValueAffected: number;
}

interface CategoryOption {
  id: string;
  name: string;
  active: boolean;
  createdAt: string;
  productCount: number;
}

export function NoCostReport() {
  const [data, setData] = useState<ReportData | null>(null);
  const [loading, setLoading] = useState(true);
  const [editProductId, setEditProductId] = useState<string | null>(null);
  const [deleteProductId, setDeleteProductId] = useState<string | null>(null);
  const [categories, setCategories] = useState<CategoryOption[]>([]);

  const fetchData = async () => {
    setLoading(true);
    try {
      // Buscar categorias
      const { data: categoriesData } = await supabase
        .from('categories')
        .select('id, name, active, created_at')
        .eq('active', true)
        .order('name');
      
      setCategories((categoriesData || []).map(c => ({
        id: c.id,
        name: c.name,
        active: c.active ?? true,
        createdAt: c.created_at ?? '',
        productCount: 0
      })));

      // Buscar produtos sem preço de custo
      const { data: productsNoCost, error: productsError } = await supabase
        .from('products')
        .select('id, name, sku')
        .is('cost_price', null)
        .eq('active', true)
        .order('name');

        if (productsError) throw productsError;

        if (!productsNoCost || productsNoCost.length === 0) {
          setData({
            productsWithoutCost: [],
            totalProducts: 0,
            totalOrdersAffected: 0,
            totalValueAffected: 0,
          });
          setLoading(false);
          return;
        }

        const productIds = productsNoCost.map(p => p.id);

        // Buscar order_items desses produtos
        const { data: orderItems, error: itemsError } = await supabase
          .from('order_items')
          .select('product_id, order_id, subtotal')
          .in('product_id', productIds);

        if (itemsError) throw itemsError;

        // Agrupar por produto
        const productStats = new Map<string, { orderIds: Set<string>; itemsCount: number; totalValue: number }>();
        
        productIds.forEach(id => {
          productStats.set(id, { orderIds: new Set(), itemsCount: 0, totalValue: 0 });
        });

        (orderItems || []).forEach(item => {
          if (item.product_id) {
            const stat = productStats.get(item.product_id);
            if (stat) {
              stat.orderIds.add(item.order_id);
              stat.itemsCount++;
              stat.totalValue += item.subtotal || 0;
            }
          }
        });

        // Montar dados finais
        const productsWithDetails: ProductWithoutCost[] = productsNoCost.map(p => {
          const stat = productStats.get(p.id);
          return {
            id: p.id,
            name: p.name,
            sku: p.sku,
            orderItemsCount: stat?.itemsCount || 0,
            ordersCount: stat?.orderIds.size || 0,
            totalValue: stat?.totalValue || 0,
          };
        }).sort((a, b) => b.ordersCount - a.ordersCount);

        // Totais
        const allOrderIds = new Set<string>();
        let totalValue = 0;
        productStats.forEach(stat => {
          stat.orderIds.forEach(id => allOrderIds.add(id));
          totalValue += stat.totalValue;
        });

        setData({
          productsWithoutCost: productsWithDetails,
          totalProducts: productsNoCost.length,
          totalOrdersAffected: allOrderIds.size,
          totalValueAffected: totalValue,
        });
    } catch (error) {
      console.error('Error fetching no-cost report:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);
  const handleDelete = async () => {
    if (!deleteProductId) return;
    
    try {
      const { error } = await supabase
        .from('products')
        .delete()
        .eq('id', deleteProductId);

      if (error) throw error;
      
      toast.success('Produto excluído com sucesso');
      setDeleteProductId(null);
      fetchData();
    } catch (error: any) {
      console.error('Error deleting product:', error);
      toast.error(error.message || 'Erro ao excluir produto');
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!data || data.totalProducts === 0) {
    return (
      <Card className="border-green-200 bg-green-50">
        <CardContent className="py-8">
          <div className="flex flex-col items-center text-center gap-3">
            <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center">
              <Package className="text-green-600" size={24} />
            </div>
            <h3 className="font-semibold text-green-800">Todos os produtos possuem custo cadastrado!</h3>
            <p className="text-sm text-green-600">
              Nenhum produto ativo está sem preço de custo.
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="border-amber-200 bg-amber-50">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-amber-700 flex items-center gap-2">
              <AlertTriangle size={16} />
              Produtos sem Custo
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold text-amber-800">{data.totalProducts}</p>
            <p className="text-xs text-amber-600 mt-1">produtos ativos</p>
          </CardContent>
        </Card>

        <Card className="border-red-200 bg-red-50">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-red-700 flex items-center gap-2">
              <FileText size={16} />
              Pedidos Afetados
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold text-red-800">{data.totalOrdersAffected}</p>
            <p className="text-xs text-red-600 mt-1">pedidos sem margem completa</p>
          </CardContent>
        </Card>

        <Card className="border-orange-200 bg-orange-50">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-orange-700 flex items-center gap-2">
              <Package size={16} />
              Valor Total Afetado
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold text-orange-800">{formatCurrency(data.totalValueAffected)}</p>
            <p className="text-xs text-orange-600 mt-1">em itens vendidos</p>
          </CardContent>
        </Card>
      </div>

      {/* Products Table */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Produtos sem Preço de Custo</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-muted text-muted-foreground text-sm">
                <tr>
                  <th className="text-left px-4 py-3 font-medium">Produto</th>
                  <th className="text-left px-4 py-3 font-medium">SKU</th>
                  <th className="text-right px-4 py-3 font-medium">Pedidos</th>
                  <th className="text-right px-4 py-3 font-medium">Itens Vendidos</th>
                  <th className="text-right px-4 py-3 font-medium">Valor Total</th>
                  <th className="text-right px-4 py-3 font-medium">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {data.productsWithoutCost.slice(0, 50).map((product) => (
                  <tr key={product.id} className="hover:bg-muted/30 transition-colors">
                    <td className="px-4 py-3">
                      <span className="font-medium text-foreground">{product.name}</span>
                    </td>
                    <td className="px-4 py-3 text-muted-foreground">
                      {product.sku || '-'}
                    </td>
                    <td className="px-4 py-3 text-right">
                      {product.ordersCount > 0 ? (
                        <span className="font-medium text-red-600">{product.ordersCount}</span>
                      ) : (
                        <span className="text-muted-foreground">0</span>
                      )}
                    </td>
                    <td className="px-4 py-3 text-right text-muted-foreground">
                      {product.orderItemsCount}
                    </td>
                    <td className="px-4 py-3 text-right font-medium">
                      {product.totalValue > 0 ? formatCurrency(product.totalValue) : '-'}
                    </td>
                    <td className="px-4 py-3 text-right">
                      <div className="flex items-center justify-end gap-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8"
                          onClick={() => setEditProductId(product.id)}
                        >
                          <Pencil size={14} />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-destructive hover:text-destructive"
                          onClick={() => setDeleteProductId(product.id)}
                        >
                          <Trash2 size={14} />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          
          {data.productsWithoutCost.length > 50 && (
            <div className="p-4 text-center text-sm text-muted-foreground border-t">
              Exibindo 50 de {data.productsWithoutCost.length} produtos
            </div>
          )}
        </CardContent>
      </Card>

      {/* Actions */}
      <div className="flex gap-4">
        <Button asChild variant="outline">
          <Link to="/orders?margem=sem">
            <FileText size={16} className="mr-2" />
            Ver Pedidos sem Margem
          </Link>
        </Button>
      </div>

      {/* Edit Modal */}
      <ProductEditModal
        open={!!editProductId}
        onOpenChange={(open) => !open && setEditProductId(null)}
        productId={editProductId}
        categories={categories}
        onSaved={() => {
          setEditProductId(null);
          fetchData();
        }}
      />

      {/* Delete Confirmation */}
      <AlertDialog open={!!deleteProductId} onOpenChange={(open) => !open && setDeleteProductId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Excluir Produto</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja excluir este produto? Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Excluir
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
