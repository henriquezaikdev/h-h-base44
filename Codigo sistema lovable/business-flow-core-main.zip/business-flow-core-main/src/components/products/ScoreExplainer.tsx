import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { HelpCircle } from 'lucide-react';

export function ScoreExplainer() {
  const [open, setOpen] = useState(false);

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <button
          type="button"
          className="inline-flex items-center justify-center rounded-full p-0.5 text-muted-foreground hover:text-primary transition-colors"
          aria-label="O que é o Score?"
        >
          <HelpCircle className="h-4 w-4" />
        </button>
      </DialogTrigger>
      <DialogContent className="max-w-lg max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-lg">📊 O que é o Score do Produto?</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 text-sm text-foreground leading-relaxed">
          <p>
            O Score é um indicador estratégico que mede a <strong>prioridade operacional</strong> do produto.
          </p>
          <p>Ele é calculado com base em três fatores:</p>

          <div className="space-y-3">
            <div className="rounded-md border border-border p-3">
              <h4 className="font-semibold text-primary mb-1">1) Margem Total (últimos 90 dias)</h4>
              <p className="text-muted-foreground">
                Representa quanto lucro o produto gerou. Produtos que geram mais lucro recebem maior pontuação.
              </p>
            </div>

            <div className="rounded-md border border-border p-3">
              <h4 className="font-semibold text-primary mb-1">2) Giro Ponderado</h4>
              <p className="text-muted-foreground">
                Mede a quantidade vendida dando mais peso para vendas recentes.
              </p>
              <ul className="list-disc list-inside text-muted-foreground mt-1 space-y-0.5">
                <li>Últimos 30 dias — maior peso</li>
                <li>31–60 dias — peso intermediário</li>
                <li>61–90 dias — menor peso</li>
              </ul>
            </div>

            <div className="rounded-md border border-border p-3">
              <h4 className="font-semibold text-primary mb-1">3) Capital Parado</h4>
              <p className="text-muted-foreground">
                Representa quanto dinheiro está investido no estoque atual. Quanto maior o capital parado, menor o Score.
              </p>
            </div>
          </div>

          <div className="rounded-md bg-muted/50 p-3">
            <h4 className="font-semibold mb-1">Fórmula utilizada:</h4>
            <p className="font-mono text-xs">
              Score = (Margem Normalizada × 0.5) + (Giro Normalizado × 0.3) − (Capital Parado Normalizado × 0.2)
            </p>
          </div>

          <p className="text-muted-foreground">
            O Score <strong>NÃO</strong> altera automaticamente preços ou compras. Ele serve como ferramenta de apoio para decisões estratégicas de estoque e capital.
          </p>

          <div className="grid grid-cols-2 gap-3">
            <div className="rounded-md border border-primary/30 p-3">
              <h4 className="font-semibold text-primary mb-1">Score Alto ✅</h4>
              <ul className="text-muted-foreground space-y-0.5 text-xs">
                <li>• Geram lucro</li>
                <li>• Estão vendendo</li>
                <li>• Sem excesso de estoque</li>
              </ul>
            </div>
            <div className="rounded-md border border-destructive/30 p-3">
              <h4 className="font-semibold text-destructive mb-1">Score Baixo ⚠️</h4>
              <ul className="text-muted-foreground space-y-0.5 text-xs">
                <li>• Vendem pouco</li>
                <li>• Margem fraca</li>
                <li>• Capital travado</li>
              </ul>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
