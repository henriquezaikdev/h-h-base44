import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { queryClient } from '@/lib/queryClient';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Upload, Eye, Play, Loader2, AlertTriangle, CheckCircle2, Copy } from 'lucide-react';
import { toast } from 'sonner';
import { SyncLogHistory } from '@/components/shared/SyncLogHistory';

const CHUNK_SIZE = 200;

interface ImportSummary {
  ok: boolean;
  dry_run: boolean;
  total_rows: number;
  matched_skus: number;
  updated_products: number;
  missing_sku_rows: number;
  missing_category_rows: number;
  unknown_skus: number;
  categories_count: number;
  sample_unknown_skus: string[];
  sample_updates: { sku: string; categoria: string }[];
}

interface CsvItem {
  sku: string;
  category: string;
}

interface ChunkProgress {
  current: number;
  total: number;
  itemsProcessed: number;
  itemsTotal: number;
}

function formatRawError(err: unknown): string {
  if (err instanceof Error) {
    return err.stack ? `${err.message}\n${err.stack}` : err.message;
  }
  if (typeof err === 'string') return err;
  try {
    return JSON.stringify(err, null, 2);
  } catch {
    return 'Erro desconhecido';
  }
}

function detectDelimiter(header: string): string {
  const semicolons = (header.match(/;/g) || []).length;
  const commas = (header.match(/,/g) || []).length;
  return semicolons > commas ? ';' : ',';
}

function parseCSVLine(line: string, delimiter: string): string[] {
  const result: string[] = [];
  let current = '';
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (inQuotes) {
      if (ch === '"' && line[i + 1] === '"') { current += '"'; i++; }
      else if (ch === '"') { inQuotes = false; }
      else { current += ch; }
    } else {
      if (ch === '"') { inQuotes = true; }
      else if (ch === delimiter) { result.push(current); current = ''; }
      else { current += ch; }
    }
  }
  result.push(current);
  return result;
}

function parseCsvInBrowser(text: string): { items: CsvItem[]; totalRows: number; missingSkuRows: number; missingCategoryRows: number } {
  const lines = text.split(/\r?\n/).filter(l => l.trim());
  if (lines.length < 2) throw new Error('CSV vazio ou sem linhas suficientes');

  const delimiter = detectDelimiter(lines[0]);
  const headers = parseCSVLine(lines[0], delimiter).map(h => h.replace(/^\uFEFF/, '').trim());

  const norm = (s: string) => s.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');

  const skuIdx = headers.findIndex(h => norm(h).includes('codigo') && norm(h).includes('item'));
  const catIdx = headers.findIndex(h => norm(h).includes('categoria'));

  if (skuIdx === -1 || catIdx === -1) {
    throw new Error(`Colunas obrigatórias não encontradas. Esperado: "Código do item" e "Categoria do item". Headers: ${headers.join(' | ')}`);
  }

  const items: CsvItem[] = [];
  let missingSkuRows = 0;
  let missingCategoryRows = 0;

  for (let i = 1; i < lines.length; i++) {
    const cols = parseCSVLine(lines[i], delimiter);
    const sku = (cols[skuIdx] || '').trim();
    const category = (cols[catIdx] || '').trim();

    if (!sku) { missingSkuRows++; continue; }
    if (!category) { missingCategoryRows++; continue; }

    items.push({ sku, category });
  }

  return { items, totalRows: lines.length - 1, missingSkuRows, missingCategoryRows };
}

function readFileAsLatin1(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const text = reader.result as string;
      resolve(text);
    };
    reader.onerror = () => reject(new Error('Falha ao ler arquivo'));
    reader.readAsText(file, 'iso-8859-1');
  });
}

export function ImportarCategoriasTab() {
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [summary, setSummary] = useState<ImportSummary | null>(null);
  const [progress, setProgress] = useState<ChunkProgress | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (f) { setFile(f); setSummary(null); setProgress(null); }
  };

  const runImport = async (dryRun: boolean) => {
    if (!file) { toast.error('Selecione um arquivo CSV'); return; }
    setLoading(true);
    setSummary(null);
    setProgress(null);

    try {
      const text = await readFileAsLatin1(file);
      const parsed = parseCsvInBrowser(text);

      if (parsed.items.length === 0) {
        toast.error(`Nenhum item válido encontrado. Total: ${parsed.totalRows}, Sem SKU: ${parsed.missingSkuRows}, Sem Categoria: ${parsed.missingCategoryRows}`);
        setLoading(false);
        return;
      }

      // Chunk the items array
      const chunks: CsvItem[][] = [];
      for (let i = 0; i < parsed.items.length; i += CHUNK_SIZE) {
        chunks.push(parsed.items.slice(i, i + CHUNK_SIZE));
      }

      toast.info(`CSV lido: ${parsed.items.length} itens válidos. Enviando em ${chunks.length} lote(s)...`);

      // Accumulators
      let totalMatched = 0;
      let totalUpdated = 0;
      let totalUnknown = 0;
      let totalCategories = 0;
      const allUnknownSkus: string[] = [];
      const allSampleUpdates: { sku: string; categoria: string }[] = [];

      for (let i = 0; i < chunks.length; i++) {
        setProgress({ current: i + 1, total: chunks.length, itemsProcessed: i * CHUNK_SIZE, itemsTotal: parsed.items.length });

        const isFirstChunk = i === 0;
        const { data, error } = await supabase.functions.invoke('hh-importar-categorias', {
          body: {
            items: chunks[i],
            dry_run: dryRun,
            trigger: 'manual',
            filename: file.name,
            chunk_index: i,
            total_chunks: chunks.length,
            frontend_stats: isFirstChunk ? {
              total_rows: parsed.totalRows,
              missing_sku_rows: parsed.missingSkuRows,
              missing_category_rows: parsed.missingCategoryRows,
            } : undefined,
          },
        });

        if (error) throw new Error(`Lote ${i + 1}/${chunks.length}: ${error.message}`);
        if (!data) throw new Error(`Lote ${i + 1}: Resposta vazia`);
        if (data?.ok === false) throw new Error(`Lote ${i + 1}: ${data?.error || 'Erro desconhecido'}`);

        const r = (data.summary ?? data);
        totalMatched += r.matched_skus ?? 0;
        totalUpdated += r.updated_products ?? 0;
        totalUnknown += r.unknown_skus ?? 0;
        totalCategories += r.categories_count ?? 0;
        if (r.sample_unknown_skus) allUnknownSkus.push(...r.sample_unknown_skus);
        if (r.sample_updates && allSampleUpdates.length < 20) {
          allSampleUpdates.push(...r.sample_updates.slice(0, 20 - allSampleUpdates.length));
        }
      }

      setProgress({ current: chunks.length, total: chunks.length, itemsProcessed: parsed.items.length, itemsTotal: parsed.items.length });

      const finalSummary: ImportSummary = {
        ok: true,
        dry_run: dryRun,
        total_rows: parsed.totalRows,
        matched_skus: totalMatched,
        updated_products: totalUpdated,
        missing_sku_rows: parsed.missingSkuRows,
        missing_category_rows: parsed.missingCategoryRows,
        unknown_skus: totalUnknown,
        categories_count: totalCategories,
        sample_unknown_skus: allUnknownSkus.slice(0, 20),
        sample_updates: allSampleUpdates.slice(0, 20),
      };
      setSummary(finalSummary);

      // Invalidate product caches so the table refreshes immediately
      if (!dryRun && totalUpdated > 0) {
        queryClient.invalidateQueries({ queryKey: ['produtos'] });
        queryClient.invalidateQueries({ queryKey: ['products'] });
        queryClient.invalidateQueries({ queryKey: ['productsPainel'] });
      }
    } catch (err: unknown) {
      toast.error(formatRawError(err));
    } finally {
      setLoading(false);
      setProgress(null);
    }
  };

  const copyJson = () => {
    navigator.clipboard.writeText(JSON.stringify(summary, null, 2));
    toast.success('JSON copiado');
  };

  return (
    <div className="space-y-6">
      {/* Upload */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium">Arquivo CSV</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-4">
            <label className="flex items-center gap-2 px-4 py-2 border border-dashed rounded-lg cursor-pointer hover:bg-muted/50 transition-colors">
              <Upload className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm">{file ? file.name : 'Selecionar CSV'}</span>
              <input type="file" accept=".csv,.txt" onChange={handleFileChange} className="hidden" />
            </label>
          </div>
          <p className="text-xs text-muted-foreground">
            Colunas esperadas: "Código do item" (SKU), "Categoria do item" (Categoria)
          </p>
          <div className="flex gap-3">
            <Button variant="outline" onClick={() => runImport(true)} disabled={!file || loading} className="gap-2">
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Eye className="h-4 w-4" />}
              Pré-visualizar (Dry-run)
            </Button>
            <Button onClick={() => runImport(false)} disabled={!file || loading} className="gap-2">
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Play className="h-4 w-4" />}
              Aplicar Categorias
            </Button>
          </div>

          <SyncLogHistory
            module="importacao_categorias_csv"
            title="Histórico de Importação de Categorias"
          />

          {/* Chunk progress */}
          {progress && (
            <div className="space-y-2 p-3 rounded-lg border bg-muted/30">
              <div className="flex items-center gap-2">
                <Loader2 className="h-4 w-4 animate-spin text-primary" />
                <span className="text-sm font-medium">
                  Processando lote {progress.current} de {progress.total}… ({progress.itemsProcessed} de {progress.itemsTotal} itens)
                </span>
              </div>
              <Progress value={(progress.current / progress.total) * 100} className="h-2" />
            </div>
          )}
        </CardContent>
      </Card>

      {/* Summary */}
      {summary && (
        <>
          <div className="grid grid-cols-2 md:grid-cols-6 gap-3">
            <Card><CardContent className="p-4 text-center"><p className="text-2xl font-bold">{summary.total_rows}</p><p className="text-xs text-muted-foreground">Total lido</p></CardContent></Card>
            <Card><CardContent className="p-4 text-center"><p className="text-2xl font-bold">{summary.matched_skus}</p><p className="text-xs text-muted-foreground">Matches SKU</p></CardContent></Card>
            <Card><CardContent className="p-4 text-center"><p className="text-2xl font-bold text-status-active">{summary.updated_products}</p><p className="text-xs text-muted-foreground">{summary.dry_run ? 'Serão atualizados' : 'Atualizados'}</p></CardContent></Card>
            <Card><CardContent className="p-4 text-center"><p className="text-2xl font-bold text-warning">{summary.unknown_skus}</p><p className="text-xs text-muted-foreground">SKUs não encontrados</p></CardContent></Card>
            <Card><CardContent className="p-4 text-center"><p className="text-2xl font-bold text-muted-foreground">{summary.missing_sku_rows}</p><p className="text-xs text-muted-foreground">Sem SKU</p></CardContent></Card>
            <Card><CardContent className="p-4 text-center"><p className="text-2xl font-bold text-muted-foreground">{summary.missing_category_rows}</p><p className="text-xs text-muted-foreground">Sem Categoria</p></CardContent></Card>
          </div>

          {summary.dry_run && (
            <div className="flex items-center gap-2 p-3 rounded-lg bg-warning/10 border border-warning/20">
              <AlertTriangle className="h-4 w-4 text-warning" />
              <span className="text-sm font-medium">Modo pré-visualização — nenhuma alteração foi gravada.</span>
            </div>
          )}

          {!summary.dry_run && (
            <div className="flex items-center gap-2 p-3 rounded-lg bg-status-active/10 border border-status-active/20">
              <CheckCircle2 className="h-4 w-4 text-status-active" />
              <span className="text-sm font-medium">Categorias aplicadas com sucesso!</span>
            </div>
          )}

          {summary.sample_unknown_skus.length > 0 && (
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <AlertTriangle className="h-4 w-4 text-warning" />
                  SKUs não encontrados (amostra de {summary.sample_unknown_skus.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {summary.sample_unknown_skus.map((sku) => (
                    <Badge key={sku} variant="outline" className="font-mono text-xs">{sku}</Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {summary.sample_updates.length > 0 && (
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-status-active" />
                  Atualizações {summary.dry_run ? '(serão aplicadas)' : 'aplicadas'} — amostra
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead><tr className="border-b bg-muted/40"><th className="text-left p-2 font-medium">SKU</th><th className="text-left p-2 font-medium">Categoria</th></tr></thead>
                    <tbody>
                      {summary.sample_updates.map((u, i) => (
                        <tr key={i} className="border-b last:border-0"><td className="p-2 font-mono text-xs">{u.sku}</td><td className="p-2">{u.categoria}</td></tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          )}

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center justify-between">
                <span>JSON completo</span>
                <Button variant="ghost" size="sm" onClick={copyJson} className="gap-1"><Copy className="h-3 w-3" /> Copiar</Button>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <pre className="text-xs bg-muted/50 p-3 rounded-lg overflow-auto max-h-60">{JSON.stringify(summary, null, 2)}</pre>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}
