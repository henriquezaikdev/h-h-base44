import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Loader2 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { useAuth } from '@/hooks/useAuth';

interface Pendencia {
  id: string;
  conta_azul_id: string | null;
  sku: string | null;
  nome: string | null;
  preco: number | null;
  custo: number | null;
  ativo: boolean | null;
}

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  pendencia: Pendencia;
  onSuccess: () => void;
}

export function CriarProdutoPendenciaModal({ open, onOpenChange, pendencia, onSuccess }: Props) {
  const { seller } = useAuth();
  const [sku, setSku] = useState(pendencia.sku || '');
  const [nome, setNome] = useState(pendencia.nome || '');
  const [saving, setSaving] = useState(false);

  const handleCriar = async () => {
    if (!sku.trim()) {
      toast.error('SKU é obrigatório');
      return;
    }

    setSaving(true);
    try {
      const trimmedName = nome.trim() || sku.trim();
      const { data: newProduct, error: insertErr } = await supabase
        .from('products')
        .insert([{
          sku: sku.trim(),
          name: trimmedName,
          normalized_name: trimmedName.toLowerCase(),
          active: pendencia.ativo ?? true,
          cost_price: pendencia.custo != null ? Number(pendencia.custo) : null,
          sale_price: pendencia.preco != null ? Number(pendencia.preco) : null,
          conta_azul_id: pendencia.conta_azul_id || null,
        }])
        .select('id')
        .single();

      if (insertErr) throw insertErr;

      // Mark pendência resolved
      const { error: pendErr } = await supabase
        .from('hh_produtos_pendencias')
        .update({
          status: 'resolvido' as string,
          action_taken: 'criado_novo' as string,
          linked_product_id: newProduct?.id,
          resolved_at: new Date().toISOString(),
          resolved_by_user_id: seller?.id || null,
        })
        .eq('id', pendencia.id);

      if (pendErr) throw pendErr;

      toast.success(`Produto "${trimmedName}" criado com sucesso`);
      onSuccess();
    } catch (err: any) {
      if (err.code === '23505') {
        toast.error('Já existe um produto com este SKU');
      } else {
        toast.error(err.message || 'Erro ao criar produto');
      }
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Criar Novo Produto</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Label>SKU *</Label>
            <Input value={sku} onChange={e => setSku(e.target.value)} placeholder="SKU obrigatório" />
          </div>
          <div>
            <Label>Nome</Label>
            <Input value={nome} onChange={e => setNome(e.target.value)} placeholder="Nome do produto" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Custo</Label>
              <Input value={pendencia.custo != null ? Number(pendencia.custo).toFixed(2) : '-'} disabled />
            </div>
            <div>
              <Label>Preço</Label>
              <Input value={pendencia.preco != null ? Number(pendencia.preco).toFixed(2) : '-'} disabled />
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
          <Button onClick={handleCriar} disabled={saving || !sku.trim()}>
            {saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
            Criar Produto
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
