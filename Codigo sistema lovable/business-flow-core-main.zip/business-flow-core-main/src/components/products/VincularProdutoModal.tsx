import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Search, Loader2 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { useAuth } from '@/hooks/useAuth';

interface Pendencia {
  id: string;
  conta_azul_id: string | null;
  sku: string | null;
  nome: string | null;
  preco: number | null;
  custo: number | null;
  ativo: boolean | null;
}

interface ProductResult {
  id: string;
  name: string;
  sku: string | null;
  conta_azul_id: string | null;
}

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  pendencia: Pendencia;
  onSuccess: () => void;
}

export function VincularProdutoModal({ open, onOpenChange, pendencia, onSuccess }: Props) {
  const { seller } = useAuth();
  const [search, setSearch] = useState('');
  const [results, setResults] = useState<ProductResult[]>([]);
  const [searching, setSearching] = useState(false);
  const [saving, setSaving] = useState(false);

  const handleSearch = async () => {
    if (!search.trim()) return;
    setSearching(true);
    try {
      const { data } = await supabase
        .from('products')
        .select('id, name, sku, conta_azul_id')
        .or(`name.ilike.%${search}%,sku.ilike.%${search}%`)
        .order('name')
        .limit(20);
      setResults(data || []);
    } finally {
      setSearching(false);
    }
  };

  const handleVincular = async (product: ProductResult) => {
    setSaving(true);
    try {
      const updates: Record<string, unknown> = {};
      if (pendencia.conta_azul_id && !product.conta_azul_id) {
        updates.conta_azul_id = pendencia.conta_azul_id;
      }
      if (pendencia.nome) updates.name = pendencia.nome;
      if (pendencia.custo != null) {
        updates.cost_price = Number(pendencia.custo);
        updates.cost_updated_at = new Date().toISOString();
      }
      if (pendencia.preco != null) updates.sale_price = Number(pendencia.preco);
      if (pendencia.ativo != null) updates.active = pendencia.ativo;

      const { error: prodErr } = await (supabase
        .from('products')
        .update(updates as any)
        .eq('id', product.id) as any);

      if (prodErr) throw prodErr;

      const { error: pendErr } = await (supabase
        .from('hh_produtos_pendencias')
        .update({
          status: 'resolvido',
          action_taken: 'vinculado',
          linked_product_id: product.id,
          resolved_at: new Date().toISOString(),
          resolved_by_user_id: seller?.id || null,
        } as any)
        .eq('id', pendencia.id) as any);

      if (pendErr) throw pendErr;

      toast.success(`Produto vinculado a "${product.name}"`);
      onSuccess();
    } catch (err: any) {
      toast.error(err.message || 'Erro ao vincular');
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>Vincular a Produto Existente</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="p-3 bg-muted rounded-lg text-sm">
            <p><strong>Pendência:</strong> {pendencia.nome || 'Sem nome'}</p>
            {pendencia.sku && <p><strong>SKU:</strong> {pendencia.sku}</p>}
            {pendencia.conta_azul_id && <p><strong>CA ID:</strong> {pendencia.conta_azul_id}</p>}
          </div>

          <div className="flex gap-2">
            <Input
              placeholder="Buscar por nome ou SKU..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleSearch()}
            />
            <Button onClick={handleSearch} disabled={searching}>
              {searching ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
            </Button>
          </div>

          <div className="max-h-[300px] overflow-y-auto space-y-1">
            {results.map(p => (
              <div
                key={p.id}
                className="flex items-center justify-between p-2 hover:bg-muted rounded cursor-pointer"
                onClick={() => !saving && handleVincular(p)}
              >
                <div>
                  <p className="font-medium text-sm">{p.name}</p>
                  <p className="text-xs text-muted-foreground">SKU: {p.sku || '-'}</p>
                </div>
                <Button size="sm" variant="outline" disabled={saving}>
                  {saving ? <Loader2 className="h-3 w-3 animate-spin" /> : 'Vincular'}
                </Button>
              </div>
            ))}
            {results.length === 0 && search && !searching && (
              <p className="text-sm text-muted-foreground text-center py-4">Nenhum produto encontrado</p>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
