import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Loader2, Lock } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { CategoryData } from '@/hooks/useCategoriesData';
import { Textarea } from '@/components/ui/textarea';
import { ProductPriceHistoryTab } from './ProductPriceHistoryTab';

interface ProductEditModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  productId: string | null;
  categories: CategoryData[];
  onSaved: () => void;
}

interface ProductFormData {
  name: string;
  sku: string;
  unit_of_measure: string;
  category_id: string;
  cost_price: string;
  sale_price: string;
  active: boolean;
  codigo_conta_azul: string;
  source_system: string | null;
  hh_ativo_interno: boolean;
  lead_time_dias: string;
  observacao_interna: string;
}

export function ProductEditModal({ open, onOpenChange, productId, categories, onSaved }: ProductEditModalProps) {
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [activeTab, setActiveTab] = useState<'dados' | 'precos'>('dados');
  const [formData, setFormData] = useState<ProductFormData>({
    name: '',
    sku: '',
    unit_of_measure: '',
    category_id: '',
    cost_price: '',
    sale_price: '',
    active: true,
    codigo_conta_azul: '',
    source_system: null,
    hh_ativo_interno: true,
    lead_time_dias: '7',
    observacao_interna: '',
  });

  const isSynced = formData.source_system === 'conta_azul_sync';

  useEffect(() => {
    if (open && productId) {
      loadProduct();
    } else if (!open) {
      setFormData({
        name: '', sku: '', unit_of_measure: '', category_id: '',
        cost_price: '', sale_price: '', active: true, codigo_conta_azul: '',
        source_system: null, hh_ativo_interno: true, lead_time_dias: '7', observacao_interna: '',
      });
      setActiveTab('dados');
    }
  }, [open, productId]);

  const loadProduct = async () => {
    if (!productId) return;
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .eq('id', productId)
        .maybeSingle();

      if (error) throw error;
      if (data) {
        setFormData({
          name: data.name || '',
          sku: data.sku || '',
          unit_of_measure: data.unit_of_measure || '',
          category_id: data.category_id || '',
          cost_price: data.cost_price != null ? String(data.cost_price) : '',
          sale_price: data.sale_price != null ? String(data.sale_price) : '',
          active: data.active !== false,
          codigo_conta_azul: data.codigo_conta_azul || '',
          source_system: data.source_system || null,
          hh_ativo_interno: (data as any).hh_ativo_interno !== false,
          lead_time_dias: String((data as any).lead_time_dias ?? 7),
          observacao_interna: (data as any).observacao_interna || '',
        });
      }
    } catch (err) {
      console.error('Error loading product:', err);
      toast.error('Erro ao carregar produto');
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    if (!productId) return;

    if (isSynced) {
      // Only save internal fields
      setSaving(true);
      try {
        const { error } = await supabase
          .from('products')
          .update({
            hh_ativo_interno: formData.hh_ativo_interno,
            lead_time_dias: parseInt(formData.lead_time_dias) || 7,
            observacao_interna: formData.observacao_interna.trim() || null,
          } as any)
          .eq('id', productId);

        if (error) throw error;
        toast.success('Campos internos atualizados');
        onSaved();
        onOpenChange(false);
      } catch (err: any) {
        console.error('Error saving product:', err);
        toast.error(err.message || 'Erro ao salvar produto');
      } finally {
        setSaving(false);
      }
      return;
    }

    // Manual product — full edit
    if (!formData.name.trim()) {
      toast.error('Nome do produto é obrigatório');
      return;
    }
    if (!formData.category_id) {
      toast.error('Categoria é obrigatória');
      return;
    }
    if (!formData.cost_price || parseFloat(formData.cost_price.replace(',', '.')) <= 0) {
      toast.error('Custo unitário é obrigatório e deve ser maior que zero');
      return;
    }

    setSaving(true);
    try {
      const codigoCA = formData.codigo_conta_azul.trim().toUpperCase() || null;
      
      if (codigoCA) {
        const { data: existingProduct } = await supabase
          .from('products')
          .select('id, name')
          .eq('codigo_conta_azul', codigoCA)
          .eq('active', true)
          .neq('id', productId)
          .maybeSingle();

        if (existingProduct) {
          toast.error(`Código Conta Azul já está em uso pelo produto: ${existingProduct.name}`);
          setSaving(false);
          return;
        }
      }

      const costPrice = parseFloat(formData.cost_price.replace(',', '.'));
      const salePrice = formData.sale_price ? parseFloat(formData.sale_price.replace(',', '.')) : null;
      const selectedCategory = categories.find(c => c.id === formData.category_id);
      const shouldUnblock = codigoCA && costPrice > 0;

      const { error } = await supabase
        .from('products')
        .update({
          name: formData.name.trim(),
          sku: formData.sku.trim() || null,
          unit_of_measure: formData.unit_of_measure.trim() || null,
          category_id: formData.category_id || null,
          category: selectedCategory?.name || null,
          cost_price: costPrice,
          sale_price: salePrice,
          active: formData.active,
          codigo_conta_azul: codigoCA,
          is_cost_blocked: shouldUnblock ? false : undefined,
          cost_updated_at: new Date().toISOString(),
          hh_ativo_interno: formData.hh_ativo_interno,
          lead_time_dias: parseInt(formData.lead_time_dias) || 7,
          observacao_interna: formData.observacao_interna.trim() || null,
        } as any)
        .eq('id', productId);

      if (error) throw error;

      toast.success('Produto atualizado com sucesso');
      onSaved();
      onOpenChange(false);
    } catch (err: any) {
      console.error('Error saving product:', err);
      toast.error(err.message || 'Erro ao salvar produto');
    } finally {
      setSaving(false);
    }
  };

  const calculateMargin = (): string => {
    const cost = parseFloat(formData.cost_price.replace(',', '.'));
    const sale = parseFloat(formData.sale_price.replace(',', '.'));
    if (isNaN(cost) || isNaN(sale) || cost <= 0) return '-';
    const margin = ((sale - cost) / cost) * 100;
    return `${margin.toFixed(1)}%`;
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            Editar Produto
            {isSynced && (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-blue-500/10 text-blue-600 rounded-full text-xs">
                <Lock className="h-3 w-3" />
                Conta Azul
              </span>
            )}
          </DialogTitle>
        </DialogHeader>

        {loading ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : (
          <>
            {/* Tabs */}
            {productId && (
              <div className="flex gap-1 border-b mb-2">
                <button
                  onClick={() => setActiveTab('dados')}
                  className={`px-3 py-2 text-sm font-medium transition-colors border-b-2 -mb-px ${
                    activeTab === 'dados'
                      ? 'border-primary text-primary'
                      : 'border-transparent text-muted-foreground hover:text-foreground'
                  }`}
                >
                  Dados
                </button>
                <button
                  onClick={() => setActiveTab('precos')}
                  className={`px-3 py-2 text-sm font-medium transition-colors border-b-2 -mb-px ${
                    activeTab === 'precos'
                      ? 'border-primary text-primary'
                      : 'border-transparent text-muted-foreground hover:text-foreground'
                  }`}
                >
                  Histórico de Preços
                </button>
              </div>
            )}

            {activeTab === 'precos' && productId ? (
              <div className="py-2 max-h-[60vh] overflow-auto">
                <ProductPriceHistoryTab productId={productId} />
              </div>
            ) : (
              <div className="grid gap-4 py-4 max-h-[60vh] overflow-y-auto pr-1">
              {isSynced && (
              <div className="p-3 bg-muted rounded-lg text-sm text-muted-foreground">
                <Lock className="h-4 w-4 inline mr-1" />
                Campos do cadastro bloqueados (sincronizado com Conta Azul). Apenas campos internos do H&H podem ser editados.
              </div>
            )}

            {/* Nome do Produto */}
            <div className="grid gap-2">
              <Label htmlFor="name">Nome do Produto *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                placeholder="Nome do produto"
                disabled={isSynced}
              />
            </div>

            {/* SKU */}
            <div className="grid gap-2">
              <Label htmlFor="sku">Código do Item (SKU)</Label>
              <Input
                id="sku"
                value={formData.sku}
                onChange={(e) => setFormData(prev => ({ ...prev, sku: e.target.value }))}
                placeholder="Ex: PROD-001"
                disabled={isSynced}
              />
            </div>

            {/* Código Conta Azul */}
            <div className="grid gap-2">
              <Label htmlFor="codigo_ca">Código Conta Azul</Label>
              <Input
                id="codigo_ca"
                value={formData.codigo_conta_azul}
                onChange={(e) => setFormData(prev => ({ ...prev, codigo_conta_azul: e.target.value.toUpperCase() }))}
                placeholder="Ex: REFIL5, PAPEL1"
                className="font-mono"
                disabled={isSynced}
              />
            </div>

            {/* Unidade de Medida */}
            <div className="grid gap-2">
              <Label htmlFor="unit">Unidade de Medida</Label>
              <Input
                id="unit"
                value={formData.unit_of_measure}
                onChange={(e) => setFormData(prev => ({ ...prev, unit_of_measure: e.target.value }))}
                placeholder="Ex: UN, KG, CX, MT"
                disabled={isSynced}
              />
            </div>

            {/* Categoria */}
            <div className="grid gap-2">
              <Label>Categoria *</Label>
              <Select 
                value={formData.category_id} 
                onValueChange={(value) => setFormData(prev => ({ ...prev, category_id: value }))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecione uma categoria" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map(cat => (
                    <SelectItem key={cat.id} value={cat.id}>
                      {cat.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Custo e Preço */}
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="cost">Custo Unitário (R$) *</Label>
                <Input
                  id="cost"
                  value={formData.cost_price}
                  onChange={(e) => setFormData(prev => ({ ...prev, cost_price: e.target.value }))}
                  placeholder="0,00"
                  disabled={isSynced}
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="sale">Preço de Venda (R$)</Label>
                <Input
                  id="sale"
                  value={formData.sale_price}
                  onChange={(e) => setFormData(prev => ({ ...prev, sale_price: e.target.value }))}
                  placeholder="0,00"
                  disabled={isSynced}
                />
              </div>
            </div>

            {/* Margem */}
            {formData.cost_price && formData.sale_price && (
              <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                <span className="text-sm text-muted-foreground">Margem de Lucro:</span>
                <span className="font-semibold text-foreground">{calculateMargin()}</span>
              </div>
            )}

            {/* Status Ativo (Conta Azul) */}
            <div className="flex items-center justify-between">
              <Label htmlFor="active">Produto Ativo (Conta Azul)</Label>
              <Switch
                id="active"
                checked={formData.active}
                onCheckedChange={(checked) => setFormData(prev => ({ ...prev, active: checked }))}
                disabled={isSynced}
              />
            </div>

            {/* Separator for internal fields */}
            <div className="border-t pt-4 mt-2">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">
                Campos internos H&H
              </p>
            </div>

            {/* Ativo Interno */}
            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="hh_ativo">Ativo no H&H</Label>
                <p className="text-xs text-muted-foreground">Ocultar/exibir no sistema sem afetar o Conta Azul</p>
              </div>
              <Switch
                id="hh_ativo"
                checked={formData.hh_ativo_interno}
                onCheckedChange={(checked) => setFormData(prev => ({ ...prev, hh_ativo_interno: checked }))}
              />
            </div>

            {/* Lead Time */}
            <div className="grid gap-2">
              <Label htmlFor="lead_time">Lead Time (dias)</Label>
              <Input
                id="lead_time"
                type="number"
                min="1"
                value={formData.lead_time_dias}
                onChange={(e) => setFormData(prev => ({ ...prev, lead_time_dias: e.target.value }))}
                placeholder="7"
                className="w-32"
              />
              <p className="text-xs text-muted-foreground">Prazo de reposição para planejamento de compras</p>
            </div>

            {/* Observação Interna */}
            <div className="grid gap-2">
              <Label htmlFor="obs_interna">Observação Interna</Label>
              <Textarea
                id="obs_interna"
                value={formData.observacao_interna}
                onChange={(e) => setFormData(prev => ({ ...prev, observacao_interna: e.target.value }))}
                placeholder="Anotações internas sobre este produto..."
                rows={3}
              />
            </div>
            </div>
            )}
          </>
        )}

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancelar
          </Button>
          <Button onClick={handleSave} disabled={saving || loading}>
            {saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
            Salvar
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
