import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { RefreshCw, Loader2, Tag, ListChecks } from 'lucide-react';
import { toast } from 'sonner';
import { SetCategoryModal } from './SetCategoryModal';

interface PendingProduct {
  product_id: string;
  sku: string;
  nome: string;
  preco_de_custo: number | null;
  sale_price: number | null;
  conta_azul_id: string | null;
}

interface HHCategoria {
  id: string;
  name: string;
}

interface CategoriasPendentesTabProps {
  onCountChange?: () => void;
}

export function CategoriasPendentesTab({ onCountChange }: CategoriasPendentesTabProps) {
  const [products, setProducts] = useState<PendingProduct[]>([]);
  const [categorias, setCategorias] = useState<HHCategoria[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState<string | null>(null);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [modalOpen, setModalOpen] = useState(false);

  const fetchData = useCallback(async () => {
    setLoading(true);
    setSelectedIds(new Set());
    const [prodRes, catRes] = await Promise.all([
      supabase.from('v_hh_produtos_categoria_pendente' as any).select('*').order('sku').limit(500),
      supabase.from('hh_categorias' as any).select('id, name').eq('kind', 'PRODUTO').eq('is_active', true).order('name'),
    ]);
    if (prodRes.data) setProducts(prodRes.data as any);
    if (catRes.data) setCategorias(catRes.data as any);
    setLoading(false);
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  const handleCategoryChange = async (productId: string, categoriaId: string) => {
    setSaving(productId);
    try {
      const { error } = await supabase
        .from('products')
        .update({ hh_categoria_id: categoriaId, categoria_updated_at: new Date().toISOString() } as any)
        .eq('id', productId);
      if (error) throw error;
      setProducts((prev) => prev.filter((p) => p.product_id !== productId));
      setSelectedIds((prev) => { const next = new Set(prev); next.delete(productId); return next; });
      toast.success('Categoria atribuída');
      onCountChange?.();
    } catch (err: any) {
      toast.error(`Erro: ${err.message}`);
    } finally {
      setSaving(null);
    }
  };

  const handleBulkApply = async (categoriaId: string) => {
    const ids = Array.from(selectedIds);
    const chunkSize = 50;
    let updated = 0;
    for (let i = 0; i < ids.length; i += chunkSize) {
      const batch = ids.slice(i, i + chunkSize);
      const { error } = await supabase
        .from('products')
        .update({ hh_categoria_id: categoriaId, categoria_updated_at: new Date().toISOString() } as any)
        .in('id', batch);
      if (error) throw error;
      updated += batch.length;
    }
    setProducts((prev) => prev.filter((p) => !selectedIds.has(p.product_id)));
    setSelectedIds(new Set());
    toast.success(`${updated} produto(s) categorizado(s)`);
    onCountChange?.();
  };

  const toggleSelect = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const toggleAll = () => {
    if (selectedIds.size === products.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(products.map((p) => p.product_id)));
    }
  };

  const fmt = (n: number | null) =>
    n != null ? n.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }) : '—';

  const allSelected = products.length > 0 && selectedIds.size === products.length;
  const someSelected = selectedIds.size > 0 && selectedIds.size < products.length;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">
          {products.length} produtos sem categoria
        </p>
        <div className="flex gap-2">
          {selectedIds.size > 0 && (
            <Button variant="default" size="sm" onClick={() => setModalOpen(true)} className="gap-2">
              <ListChecks className="h-4 w-4" />
              Definir Categoria ({selectedIds.size})
            </Button>
          )}
          <Button variant="outline" size="sm" onClick={fetchData} disabled={loading} className="gap-2">
            <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
            Atualizar
          </Button>
        </div>
      </div>

      <Card>
        <CardContent className="p-0">
          {loading ? (
            <div className="flex justify-center py-12">
              <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
          ) : products.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <Tag className="h-10 w-10 mx-auto mb-3 opacity-40" />
              <p className="font-medium">Nenhum produto pendente!</p>
              <p className="text-xs mt-1">Todos os produtos ativos com SKU têm categoria atribuída.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b bg-muted/40">
                    <th className="p-3 w-10">
                      <Checkbox
                        checked={allSelected}
                        ref={(el) => {
                          if (el) (el as any).indeterminate = someSelected;
                        }}
                        onCheckedChange={toggleAll}
                      />
                    </th>
                    <th className="text-left p-3 font-medium">SKU</th>
                    <th className="text-left p-3 font-medium">Produto</th>
                    <th className="text-left p-3 font-medium min-w-[220px]">Categoria</th>
                    <th className="text-right p-3 font-medium">Custo</th>
                    <th className="text-right p-3 font-medium">Preço</th>
                  </tr>
                </thead>
                <tbody>
                  {products.map((p) => (
                    <tr key={p.product_id} className={`border-b last:border-0 hover:bg-muted/20 ${selectedIds.has(p.product_id) ? 'bg-muted/30' : ''}`}>
                      <td className="p-3">
                        <Checkbox
                          checked={selectedIds.has(p.product_id)}
                          onCheckedChange={() => toggleSelect(p.product_id)}
                        />
                      </td>
                      <td className="p-3 font-mono text-xs">{p.sku}</td>
                      <td className="p-3 max-w-[300px] truncate">{p.nome}</td>
                      <td className="p-3">
                        <Select onValueChange={(val) => handleCategoryChange(p.product_id, val)} disabled={saving === p.product_id}>
                          <SelectTrigger className="h-8 text-xs">
                            <SelectValue placeholder="Selecionar categoria..." />
                          </SelectTrigger>
                          <SelectContent>
                            {categorias.map((c) => (
                              <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </td>
                      <td className="p-3 text-right text-xs text-muted-foreground">{fmt(p.preco_de_custo)}</td>
                      <td className="p-3 text-right text-xs">{fmt(p.sale_price)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      <SetCategoryModal
        open={modalOpen}
        onOpenChange={setModalOpen}
        categories={categorias.map((c) => ({ id: c.id, name: c.name, active: true, createdAt: '', productCount: 0 }))}
        selectedCount={selectedIds.size}
        onApply={handleBulkApply}
      />
    </div>
  );
}
