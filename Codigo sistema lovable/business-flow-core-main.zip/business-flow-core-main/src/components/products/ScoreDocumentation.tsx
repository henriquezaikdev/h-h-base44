import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

export function ScoreDocumentation() {
  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base font-semibold">📊 Como o Score do Produto é Calculado</CardTitle>
      </CardHeader>
      <CardContent className="space-y-5 text-[13px] leading-relaxed">
        <div className="space-y-1">
          <p className="text-foreground">
            O Score do Produto é um cálculo matemático que define a <strong>prioridade do produto</strong> dentro do estoque.
          </p>
          <p className="text-muted-foreground">Ele <strong>NÃO</strong> altera automaticamente compras. Serve para orientar decisões.</p>
        </div>

        <p className="text-foreground font-medium">O cálculo considera 3 fatores:</p>

        {/* Factor 1 */}
        <div className="rounded-md border border-border p-4 space-y-2">
          <div className="flex items-center justify-between">
            <h4 className="font-semibold text-foreground">1) Margem Total <span className="text-muted-foreground font-normal">(últimos 90 dias)</span></h4>
            <Badge variant="secondary" className="font-mono text-[11px]">Peso: 50%</Badge>
          </div>
          <p className="text-muted-foreground">Representa quanto lucro o produto gerou.</p>
          <div className="bg-muted/50 rounded p-2 font-mono text-[11px] space-y-1">
            <p>Margem = Soma de (Receita − Custo) nos últimos 90 dias</p>
            <p>Margem Normalizada = Margem do Produto ÷ Maior Margem da Base</p>
          </div>
          <p className="text-muted-foreground text-xs">Produtos que geram mais lucro recebem maior pontuação.</p>
        </div>

        {/* Factor 2 */}
        <div className="rounded-md border border-border p-4 space-y-2">
          <div className="flex items-center justify-between">
            <h4 className="font-semibold text-foreground">2) Giro Ponderado</h4>
            <Badge variant="secondary" className="font-mono text-[11px]">Peso: 30%</Badge>
          </div>
          <p className="text-muted-foreground">Mede quanto o produto está vendendo, dando mais peso para vendas recentes.</p>
          <div className="grid grid-cols-3 gap-2 text-xs text-center">
            <div className="rounded border border-border p-2">
              <p className="font-semibold text-foreground">Últimos 30d</p>
              <p className="text-muted-foreground font-mono">peso 0.5</p>
            </div>
            <div className="rounded border border-border p-2">
              <p className="font-semibold text-foreground">31–60d</p>
              <p className="text-muted-foreground font-mono">peso 0.3</p>
            </div>
            <div className="rounded border border-border p-2">
              <p className="font-semibold text-foreground">61–90d</p>
              <p className="text-muted-foreground font-mono">peso 0.2</p>
            </div>
          </div>
          <div className="bg-muted/50 rounded p-2 font-mono text-[11px] space-y-1">
            <p>Giro = (Qtd_30d × 0.5) + (Qtd_60d × 0.3) + (Qtd_90d × 0.2)</p>
            <p>Giro Normalizado = Giro do Produto ÷ Maior Giro da Base</p>
          </div>
          <p className="text-muted-foreground text-xs">Produtos que estão vendendo agora recebem maior pontuação.</p>
        </div>

        {/* Factor 3 */}
        <div className="rounded-md border border-border p-4 space-y-2">
          <div className="flex items-center justify-between">
            <h4 className="font-semibold text-foreground">3) Capital Parado</h4>
            <Badge variant="destructive" className="font-mono text-[11px]">Peso: −20%</Badge>
          </div>
          <p className="text-muted-foreground">Representa o dinheiro investido no estoque atual.</p>
          <div className="bg-muted/50 rounded p-2 font-mono text-[11px] space-y-1">
            <p>Capital Parado = Saldo Atual × Custo Unitário</p>
            <p>Capital Normalizado = Capital do Produto ÷ Maior Capital da Base</p>
          </div>
          <p className="text-muted-foreground text-xs">Quanto maior o capital parado, <strong>menor</strong> a pontuação.</p>
        </div>

        {/* Formula */}
        <div className="rounded-md bg-muted/50 border border-border p-4">
          <h4 className="font-semibold text-foreground mb-2 text-xs uppercase tracking-wide">Fórmula Final</h4>
          <p className="font-mono text-[12px] text-foreground text-center">
            Score = (Margem Norm. × <strong>0.5</strong>) + (Giro Norm. × <strong>0.3</strong>) − (Capital Norm. × <strong>0.2</strong>)
          </p>
        </div>

        {/* Interpretation */}
        <div className="grid grid-cols-3 gap-3">
          <div className="rounded-md border border-primary/30 p-3">
            <h4 className="font-semibold text-primary mb-1 text-xs">Score Alto ✅</h4>
            <ul className="text-muted-foreground space-y-0.5 text-[11px]">
              <li>• Gera lucro</li>
              <li>• Está vendendo</li>
              <li>• Sem excesso de estoque</li>
            </ul>
          </div>
          <div className="rounded-md border border-border p-3">
            <h4 className="font-semibold text-foreground mb-1 text-xs">Score Baixo ⚠️</h4>
            <ul className="text-muted-foreground space-y-0.5 text-[11px]">
              <li>• Vende pouco</li>
              <li>• Margem fraca</li>
              <li>• Capital travado</li>
            </ul>
          </div>
          <div className="rounded-md border border-destructive/30 p-3">
            <h4 className="font-semibold text-destructive mb-1 text-xs">Score Negativo ❌</h4>
            <ul className="text-muted-foreground space-y-0.5 text-[11px]">
              <li>• Alto capital parado</li>
              <li>• Baixa geração de lucro</li>
            </ul>
          </div>
        </div>

        <p className="text-muted-foreground text-xs border-t border-border pt-3">
          <strong>Importante:</strong> O Score é apenas um indicador. A decisão final de compra é sempre humana.
        </p>
      </CardContent>
    </Card>
  );
}
