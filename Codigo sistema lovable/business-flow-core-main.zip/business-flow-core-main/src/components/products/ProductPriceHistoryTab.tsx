import { useState } from 'react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { BarChart3, Loader2, PackageSearch } from 'lucide-react';
import { useHistoricoPrecoProduto } from '@/hooks/useHistoricoPrecos';
import { formatCurrency } from '@/lib/utils';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface ProductPriceHistoryTabProps {
  productId: string;
}

export function ProductPriceHistoryTab({ productId }: ProductPriceHistoryTabProps) {
  const { data: history = [], isLoading } = useHistoricoPrecoProduto(productId);

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center py-12 gap-2">
        <Loader2 className="h-6 w-6 animate-spin text-primary" />
        <p className="text-sm text-muted-foreground">Carregando...</p>
      </div>
    );
  }

  if (history.length === 0) {
    return (
      <div className="text-center py-12">
        <PackageSearch className="h-10 w-10 mx-auto text-muted-foreground/30 mb-2" />
        <p className="text-sm text-muted-foreground">Nenhum histórico de preço registrado para este produto</p>
      </div>
    );
  }

  // Group by fornecedor
  const byFornecedor: Record<string, any[]> = {};
  for (const h of history) {
    const key = h.fornecedor_id || h.fornecedor_nome;
    if (!byFornecedor[key]) byFornecedor[key] = [];
    byFornecedor[key].push(h);
  }

  // Chart data (all entries)
  const chartData = [...history]
    .sort((a: any, b: any) => new Date(a.data_compra).getTime() - new Date(b.data_compra).getTime())
    .map((h: any) => ({
      date: format(new Date(h.data_compra + 'T00:00:00'), 'dd/MM/yy', { locale: ptBR }),
      preco: Number(h.preco_unitario),
      fornecedor: h.fornecedor_nome,
    }));

  const fornecedorEntries = Object.entries(byFornecedor).map(([key, records]) => {
    const sorted = records.sort((a: any, b: any) =>
      new Date(b.data_compra).getTime() - new Date(a.data_compra).getTime()
    );
    const latest = sorted[0];
    return {
      key,
      nome: latest.fornecedor_nome,
      ultimo_preco: Number(latest.preco_unitario),
      data_ultima: latest.data_compra,
      total: sorted.length,
      records: sorted,
    };
  }).sort((a, b) => a.ultimo_preco - b.ultimo_preco);

  return (
    <div className="space-y-4">
      {/* Chart */}
      {chartData.length > 1 && (
        <div className="bg-muted/30 rounded-lg p-3">
          <p className="text-[11px] uppercase tracking-wider font-semibold text-muted-foreground mb-2">
            Evolução do Preço
          </p>
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="date" tick={{ fontSize: 10 }} stroke="hsl(var(--muted-foreground))" />
              <YAxis
                tick={{ fontSize: 10 }}
                stroke="hsl(var(--muted-foreground))"
                tickFormatter={(v: number) => `R$${v.toFixed(0)}`}
              />
              <Tooltip
                formatter={(value: number) => [formatCurrency(value), 'Preço']}
                contentStyle={{
                  fontSize: 12,
                  background: 'hsl(var(--background))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: 8,
                }}
              />
              <Line
                type="monotone"
                dataKey="preco"
                stroke="hsl(var(--primary))"
                strokeWidth={2}
                dot={{ r: 3, fill: 'hsl(var(--primary))' }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* Fornecedores table */}
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="text-[11px] uppercase tracking-wider font-semibold">Fornecedor</TableHead>
            <TableHead className="text-[11px] uppercase tracking-wider font-semibold text-right">Último Preço</TableHead>
            <TableHead className="text-[11px] uppercase tracking-wider font-semibold text-right">Data</TableHead>
            <TableHead className="text-[11px] uppercase tracking-wider font-semibold text-right">Compras</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {fornecedorEntries.map((f, idx) => (
            <TableRow key={f.key}>
              <TableCell className="text-sm font-medium">
                <div className="flex items-center gap-2">
                  {f.nome}
                  {idx === 0 && fornecedorEntries.length > 1 && (
                    <Badge className="bg-emerald-500/10 text-emerald-700 border-emerald-500/20 text-[10px] h-5">
                      Melhor Preço
                    </Badge>
                  )}
                </div>
              </TableCell>
              <TableCell className="text-sm font-bold text-right font-mono">
                {formatCurrency(f.ultimo_preco)}
              </TableCell>
              <TableCell className="text-sm text-right text-muted-foreground">
                {format(new Date(f.data_ultima + 'T00:00:00'), 'dd/MM/yyyy', { locale: ptBR })}
              </TableCell>
              <TableCell className="text-sm text-right text-muted-foreground">
                {f.total}
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}
