import { useState, useRef, useMemo, useCallback } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import {
  Upload,
  FileSpreadsheet,
  AlertTriangle,
  Check,
  X,
  Loader2,
  Download,
  Lock,
  Unlock,
  Info,
} from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import * as XLSX from 'xlsx';
import { parseSpreadsheetFile, parseDecimal, toTrimmedString, type Row } from '@/components/settings/importer/spreadsheet';

interface CostImportModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess: () => void;
}

interface PreviewItem {
  codigo: string;
  productId: string | null;
  productName: string;
  currentCost: number | null;
  newCost: number;
  currentCategory: string | null;
  newCategory: string | null;
  status: 'update' | 'ignored' | 'not_found' | 'invalid';
  reason?: string;
}

type Step = 'upload' | 'mapping' | 'preview' | 'processing' | 'result';

interface CategoryLookup {
  id: string;
  name: string;
}

export function CostImportModal({ open, onOpenChange, onSuccess }: CostImportModalProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [step, setStep] = useState<Step>('upload');
  const [loading, setLoading] = useState(false);
  
  // File data
  const [rows, setRows] = useState<Row[]>([]);
  const [columns, setColumns] = useState<string[]>([]);
  
  // Mapping
  const [codigoColumn, setCodigoColumn] = useState('');
  const [custoColumn, setCustoColumn] = useState('');
  const [categoriaColumn, setCategoriaColumn] = useState('');
  
  // Categories lookup
  const [categoriesMap, setCategoriesMap] = useState<Map<string, string>>(new Map());
  
  // Preview
  const [previewItems, setPreviewItems] = useState<PreviewItem[]>([]);
  const [productsToBlock, setProductsToBlock] = useState<number>(0);
  
  // Progress
  const [progress, setProgress] = useState(0);
  const [progressMessage, setProgressMessage] = useState('');
  
  // Result
  const [result, setResult] = useState<{
    updated: number;
    ignored: number;
    blocked: number;
    notFound: number;
    categoriesUpdated: number;
  } | null>(null);

  const resetState = () => {
    setStep('upload');
    setLoading(false);
    setRows([]);
    setColumns([]);
    setCodigoColumn('');
    setCustoColumn('');
    setCategoriaColumn('');
    setPreviewItems([]);
    setProductsToBlock(0);
    setProgress(0);
    setProgressMessage('');
    setResult(null);
    setCategoriesMap(new Map());
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setLoading(true);
    try {
      const { rows: parsedRows, columns: parsedColumns } = await parseSpreadsheetFile(file);
      
      if (parsedRows.length === 0) {
        toast.error('Arquivo vazio ou formato inválido');
        return;
      }

      setRows(parsedRows);
      setColumns(parsedColumns);
      
      // Auto-detect columns
      const norm = (s: string) =>
        s.replace(/^\uFEFF/, '').trim().toLowerCase()
          .normalize('NFD').replace(/[\u0300-\u036f]/g, '');

      const codigoCol = parsedColumns.find(c => {
        const n = norm(c);
        return n === 'codigo_produto' || n === 'codigo do item' || n === 'codigo' || n === 'sku';
      });
      const custoCol = parsedColumns.find(c => {
        const n = norm(c);
        return n === 'custo' || n === 'custo unitario' || n.includes('custo medio') || n.includes('custo');
      });
      const categoriaCol = parsedColumns.find(c => {
        const n = norm(c);
        return n === 'categoria' || n === 'categoria do item';
      });

      if (codigoCol) setCodigoColumn(codigoCol);
      if (custoCol) setCustoColumn(custoCol);
      if (categoriaCol) setCategoriaColumn(categoriaCol);

      // Fetch categories for lookup
      const { data: cats } = await supabase
        .from('categories')
        .select('id, name')
        .eq('active', true);
      
      const catMap = new Map<string, string>();
      (cats || []).forEach(c => {
        catMap.set(c.name.toLowerCase().trim(), c.id);
      });
      setCategoriesMap(catMap);

      setStep('mapping');
    } catch (err) {
      console.error('Error parsing file:', err);
      toast.error('Erro ao ler arquivo');
    } finally {
      setLoading(false);
    }
  };

  const generatePreview = async () => {
    if (!codigoColumn || !custoColumn) {
      toast.error('Selecione as colunas de código e custo');
      return;
    }

    setLoading(true);
    setProgressMessage('Carregando produtos do banco...');
    
    try {
      // Fetch all products with codigo_conta_azul
      const { data: products, error } = await supabase
        .from('products')
        .select('id, name, codigo_conta_azul, cost_price, is_cost_blocked, category, category_id')
        .eq('active', true);

      if (error) throw error;

      // Create lookup map by codigo_conta_azul
      const productMap = new Map<string, typeof products[0]>();
      (products || []).forEach(p => {
        if (p.codigo_conta_azul) {
          productMap.set(p.codigo_conta_azul.toUpperCase().trim(), p);
        }
      });

      // Build preview items
      const preview: PreviewItem[] = [];
      const codigosInFile = new Set<string>();

      for (const row of rows) {
        const codigoRaw = toTrimmedString(row[codigoColumn]);
        const custoRaw = row[custoColumn];
        const categoriaRaw = categoriaColumn ? toTrimmedString(row[categoriaColumn]) : null;
        
        // Skip empty lines
        if (!codigoRaw) continue;
        
        // Skip header rows
        const codigoLower = codigoRaw.toLowerCase();
        if (codigoLower === 'codigo_produto' || codigoLower === 'codigo do item' || codigoLower === 'sku') {
          continue;
        }
        
        // Skip "categoria padrão" as requested
        if (categoriaRaw && categoriaRaw.toLowerCase().includes('categoria padrão')) {
          continue;
        }

        const codigo = codigoRaw.toUpperCase().trim();
        codigosInFile.add(codigo);

        const custoText = toTrimmedString(custoRaw);
        const custoValue = parseDecimal(custoRaw);
        
        // Normalize category - merge Locações/Manutenções to Serviços
        let normalizedCategory = categoriaRaw;
        if (normalizedCategory) {
          const catLower = normalizedCategory.toLowerCase().trim();
          if (catLower === 'locações' || catLower === 'manutenções' || catLower === 'locacao' || catLower === 'manutencao') {
            normalizedCategory = 'Serviços';
          }
        }

        // Validate cost
        if (!custoText || custoValue === null || custoValue < 0) {
          preview.push({
            codigo,
            productId: null,
            productName: '-',
            currentCost: null,
            newCost: 0,
            currentCategory: null,
            newCategory: normalizedCategory,
            status: 'invalid',
            reason: custoText ? `Custo inválido: "${custoText}"` : 'Custo vazio',
          });
          continue;
        }

        // Find product
        const product = productMap.get(codigo);
        
        if (!product) {
          preview.push({
            codigo,
            productId: null,
            productName: '-',
            currentCost: null,
            newCost: custoValue,
            currentCategory: null,
            newCategory: normalizedCategory,
            status: 'not_found',
            reason: 'Código não encontrado no sistema',
          });
          continue;
        }

        preview.push({
          codigo,
          productId: product.id,
          productName: product.name,
          currentCost: product.cost_price,
          newCost: custoValue,
          currentCategory: product.category,
          newCategory: normalizedCategory,
          status: 'update',
        });
      }

      // Calculate products to block (products not in file)
      const productsNotInFile = (products || []).filter(p => 
        p.codigo_conta_azul && 
        !codigosInFile.has(p.codigo_conta_azul.toUpperCase().trim()) &&
        !p.is_cost_blocked
      );

      // Also count products without codigo_conta_azul
      const productsWithoutCode = (products || []).filter(p => 
        !p.codigo_conta_azul && 
        !p.is_cost_blocked
      );

      setPreviewItems(preview);
      setProductsToBlock(productsNotInFile.length + productsWithoutCode.length);
      setStep('preview');
    } catch (err) {
      console.error('Error generating preview:', err);
      toast.error('Erro ao gerar prévia');
    } finally {
      setLoading(false);
    }
  };

  const executeImport = async () => {
    setStep('processing');
    setProgress(0);
    
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        toast.error('Sessão expirada');
        return;
      }

      // Get user name from sellers
      const { data: seller } = await supabase
        .from('sellers')
        .select('name')
        .eq('user_id', user.id)
        .maybeSingle();

      const userName = seller?.name || user.email || 'Usuário';

      // Items to update
      const itemsToUpdate = previewItems.filter(i => i.status === 'update' && i.productId);
      const total = itemsToUpdate.length;
      
      setProgressMessage(`Atualizando custos e categorias... 0/${total}`);

      // Batch update products
      const BATCH_SIZE = 50;
      let updated = 0;
      let categoriesUpdated = 0;
      const now = new Date().toISOString();

      for (let i = 0; i < itemsToUpdate.length; i += BATCH_SIZE) {
        const batch = itemsToUpdate.slice(i, i + BATCH_SIZE);
        
        // Update each product in batch
        for (const item of batch) {
          const updateData: Record<string, any> = {
            cost_price: item.newCost,
            cost_updated_at: now,
            is_cost_blocked: false,
          };
          
          // Also update category if provided and different
          if (item.newCategory && item.newCategory !== item.currentCategory) {
            updateData.category = item.newCategory;
            
            // Find category_id
            const catId = categoriesMap.get(item.newCategory.toLowerCase().trim());
            if (catId) {
              updateData.category_id = catId;
            }
            categoriesUpdated++;
          }
          
          const { error } = await supabase
            .from('products')
            .update(updateData)
            .eq('id', item.productId!);

          if (error) {
            console.error('Error updating product:', item.codigo, error);
          } else {
            updated++;
          }
        }

        setProgress(Math.round((i + batch.length) / total * 70));
        setProgressMessage(`Atualizando custos e categorias... ${i + batch.length}/${total}`);
      }

      // Block products not in file
      setProgressMessage('Bloqueando produtos não atualizados...');
      
      const codigosUpdated = new Set(itemsToUpdate.map(i => i.codigo));
      
      // Fetch products to block
      const { data: allProducts } = await supabase
        .from('products')
        .select('id, codigo_conta_azul')
        .eq('active', true)
        .eq('is_cost_blocked', false);

      const productsToBlockIds = (allProducts || [])
        .filter(p => {
          if (!p.codigo_conta_azul) return true; // No code = block
          return !codigosUpdated.has(p.codigo_conta_azul.toUpperCase().trim());
        })
        .map(p => p.id);

      let blocked = 0;
      if (productsToBlockIds.length > 0) {
        const { error } = await supabase
          .from('products')
          .update({ is_cost_blocked: true })
          .in('id', productsToBlockIds);

        if (!error) {
          blocked = productsToBlockIds.length;
        }
      }

      setProgress(90);
      setProgressMessage('Registrando auditoria...');

      // Log import
      const ignored = previewItems.filter(i => i.status === 'invalid').length;
      const notFound = previewItems.filter(i => i.status === 'not_found').length;

      await supabase.from('product_cost_import_logs').insert({
        user_id: user.id,
        user_name: userName,
        products_updated: updated,
        products_ignored: ignored + notFound,
        products_blocked: blocked,
        details: {
          not_found: previewItems.filter(i => i.status === 'not_found').map(i => i.codigo),
          invalid: previewItems.filter(i => i.status === 'invalid').map(i => ({ codigo: i.codigo, reason: i.reason })),
          categories_updated: categoriesUpdated,
        },
      });

      setProgress(100);
      setResult({ updated, ignored, blocked, notFound, categoriesUpdated });
      setStep('result');
      
      toast.success(`${updated} produtos atualizados, ${categoriesUpdated} categorias, ${blocked} bloqueados`);
    } catch (err) {
      console.error('Error executing import:', err);
      toast.error('Erro ao executar importação');
      setStep('preview');
    }
  };

  const handleClose = () => {
    resetState();
    if (result) {
      onSuccess();
    }
    onOpenChange(false);
  };

  const downloadTemplate = () => {
    const data = [
      { codigo_produto: 'REFIL5', custo: '25.90' },
      { codigo_produto: 'PAPEL1', custo: '12.50' },
      { codigo_produto: 'CANETA01', custo: '3.75' },
    ];
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Custos');
    XLSX.writeFile(wb, 'modelo_atualizacao_custos.xlsx');
    toast.success('Modelo baixado');
  };

  const stats = useMemo(() => {
    const toUpdate = previewItems.filter(i => i.status === 'update').length;
    const invalid = previewItems.filter(i => i.status === 'invalid').length;
    const notFound = previewItems.filter(i => i.status === 'not_found').length;
    return { toUpdate, invalid, notFound };
  }, [previewItems]);

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileSpreadsheet className="h-5 w-5 text-primary" />
            Atualização de Custos por Importação
          </DialogTitle>
          <DialogDescription>
            Atualize custos de produtos em massa usando o código do produto (codigo_conta_azul).
            Produtos não incluídos na planilha serão bloqueados para venda.
          </DialogDescription>
        </DialogHeader>

        <div className="flex-1 overflow-hidden">
          {/* Step: Upload */}
          {step === 'upload' && (
            <div className="space-y-6 py-4">
              <Alert>
                <Info className="h-4 w-4" />
                <AlertTitle>Regras de importação</AlertTitle>
                <AlertDescription className="text-sm space-y-1">
                  <p>• O match é feito EXCLUSIVAMENTE pelo campo <strong>codigo_produto</strong></p>
                  <p>• Produtos sem código ou não encontrados serão ignorados</p>
                  <p>• Produtos NÃO atualizados serão bloqueados para venda</p>
                  <p>• Pedidos existentes NÃO serão alterados</p>
                </AlertDescription>
              </Alert>

              <div className="flex items-center gap-4">
                <Button variant="outline" onClick={downloadTemplate}>
                  <Download className="h-4 w-4 mr-2" />
                  Baixar Modelo
                </Button>
              </div>

              <div 
                className="border-2 border-dashed rounded-lg p-8 text-center hover:border-primary/50 transition-colors cursor-pointer"
                onClick={() => fileInputRef.current?.click()}
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".csv,.xlsx,.xls"
                  onChange={handleFileUpload}
                  className="hidden"
                />
                <Upload className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <p className="text-muted-foreground">
                  Clique para selecionar ou arraste um arquivo CSV/XLSX
                </p>
                <p className="text-xs text-muted-foreground mt-2">
                  Colunas esperadas: codigo_produto (obrigatório), custo (obrigatório)
                </p>
              </div>

              {loading && (
                <div className="flex items-center justify-center py-4">
                  <Loader2 className="h-6 w-6 animate-spin text-primary" />
                  <span className="ml-2 text-muted-foreground">Processando arquivo...</span>
                </div>
              )}
            </div>
          )}

          {/* Step: Mapping */}
          {step === 'mapping' && (
            <div className="space-y-6 py-4">
              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label>Coluna do Código do Produto *</Label>
                  <Select value={codigoColumn} onValueChange={setCodigoColumn}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione a coluna" />
                    </SelectTrigger>
                    <SelectContent>
                      {columns.map(col => (
                        <SelectItem key={col} value={col}>{col}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground">
                    Match com codigo_conta_azul
                  </p>
                </div>

                <div className="space-y-2">
                  <Label>Coluna do Custo *</Label>
                  <Select value={custoColumn} onValueChange={setCustoColumn}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione a coluna" />
                    </SelectTrigger>
                    <SelectContent>
                      {columns.map(col => (
                        <SelectItem key={col} value={col}>{col}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground">
                    Novo valor de custo unitário
                  </p>
                </div>

                <div className="space-y-2">
                  <Label>Coluna da Categoria (opcional)</Label>
                  <Select value={categoriaColumn} onValueChange={setCategoriaColumn}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione a coluna" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">Não atualizar categorias</SelectItem>
                      {columns.map(col => (
                        <SelectItem key={col} value={col}>{col}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground">
                    Atualiza categoria do produto
                  </p>
                </div>
              </div>

              <div className="bg-muted/50 rounded-lg p-4">
                <h4 className="font-medium mb-2">Prévia das primeiras linhas:</h4>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        {columns.slice(0, 5).map(col => (
                          <TableHead key={col} className="text-xs">{col}</TableHead>
                        ))}
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {rows.slice(0, 3).map((row, i) => (
                        <TableRow key={i}>
                          {columns.slice(0, 5).map(col => (
                            <TableCell key={col} className="text-xs">
                              {String(row[col] ?? '-').substring(0, 30)}
                            </TableCell>
                          ))}
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
                <p className="text-xs text-muted-foreground mt-2">
                  {rows.length} linhas no arquivo
                </p>
              </div>
            </div>
          )}

          {/* Step: Preview */}
          {step === 'preview' && (
            <div className="space-y-4 py-4 flex flex-col h-full">
              {/* Stats */}
              <div className="grid grid-cols-4 gap-4">
                <div className="bg-green-500/10 rounded-lg p-3 text-center">
                  <p className="text-2xl font-bold text-green-600">{stats.toUpdate}</p>
                  <p className="text-xs text-muted-foreground">Serão atualizados</p>
                </div>
                <div className="bg-amber-500/10 rounded-lg p-3 text-center">
                  <p className="text-2xl font-bold text-amber-600">{stats.notFound}</p>
                  <p className="text-xs text-muted-foreground">Não encontrados</p>
                </div>
                <div className="bg-red-500/10 rounded-lg p-3 text-center">
                  <p className="text-2xl font-bold text-red-600">{stats.invalid}</p>
                  <p className="text-xs text-muted-foreground">Custo inválido</p>
                </div>
                <div className="bg-orange-500/10 rounded-lg p-3 text-center">
                  <p className="text-2xl font-bold text-orange-600">{productsToBlock}</p>
                  <p className="text-xs text-muted-foreground">Serão bloqueados</p>
                </div>
              </div>

              {productsToBlock > 0 && (
                <Alert variant="destructive">
                  <Lock className="h-4 w-4" />
                  <AlertTitle>Atenção: Produtos serão bloqueados</AlertTitle>
                  <AlertDescription>
                    {productsToBlock} produtos ativos não estão na planilha e serão bloqueados para venda.
                    Para evitar isso, inclua-os na próxima importação.
                  </AlertDescription>
                </Alert>
              )}

              {/* Preview table */}
              <ScrollArea className="flex-1 border rounded-lg">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Código</TableHead>
                      <TableHead>Produto</TableHead>
                      <TableHead className="text-right">Custo Atual</TableHead>
                      <TableHead className="text-right">Novo Custo</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {previewItems.map((item, i) => (
                      <TableRow key={i}>
                        <TableCell className="font-mono text-sm">{item.codigo}</TableCell>
                        <TableCell className="max-w-[200px] truncate">{item.productName}</TableCell>
                        <TableCell className="text-right">
                          {item.currentCost != null 
                            ? `R$ ${item.currentCost.toFixed(2)}`
                            : '-'}
                        </TableCell>
                        <TableCell className="text-right font-medium">
                          {item.status === 'update' 
                            ? `R$ ${item.newCost.toFixed(2)}`
                            : '-'}
                        </TableCell>
                        <TableCell>
                          {item.status === 'update' && (
                            <Badge variant="default" className="bg-green-500">
                              <Check className="h-3 w-3 mr-1" />
                              Atualizar
                            </Badge>
                          )}
                          {item.status === 'not_found' && (
                            <Badge variant="secondary" className="bg-amber-500/10 text-amber-600">
                              <AlertTriangle className="h-3 w-3 mr-1" />
                              Não encontrado
                            </Badge>
                          )}
                          {item.status === 'invalid' && (
                            <Badge variant="destructive">
                              <X className="h-3 w-3 mr-1" />
                              {item.reason}
                            </Badge>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </ScrollArea>
            </div>
          )}

          {/* Step: Processing */}
          {step === 'processing' && (
            <div className="py-8 space-y-6">
              <div className="text-center">
                <Loader2 className="h-12 w-12 animate-spin text-primary mx-auto mb-4" />
                <p className="text-lg font-medium">{progressMessage}</p>
              </div>
              <Progress value={progress} className="h-3" />
            </div>
          )}

          {/* Step: Result */}
          {step === 'result' && result && (
            <div className="py-8 space-y-6">
              <div className="text-center">
                <Check className="h-16 w-16 text-green-500 mx-auto mb-4" />
                <h3 className="text-xl font-bold mb-2">Importação Concluída</h3>
              </div>

              <div className="grid grid-cols-2 gap-4 max-w-lg mx-auto">
                <div className="bg-emerald-500/10 rounded-lg p-4 text-center">
                  <p className="text-3xl font-bold text-emerald-600">{result.updated}</p>
                  <p className="text-sm text-muted-foreground">Custos atualizados</p>
                </div>
                <div className="bg-blue-500/10 rounded-lg p-4 text-center">
                  <p className="text-3xl font-bold text-blue-600">{result.categoriesUpdated}</p>
                  <p className="text-sm text-muted-foreground">Categorias atualizadas</p>
                </div>
                <div className="bg-orange-500/10 rounded-lg p-4 text-center">
                  <p className="text-3xl font-bold text-orange-600">{result.blocked}</p>
                  <p className="text-sm text-muted-foreground">Produtos bloqueados</p>
                </div>
                <div className="bg-amber-500/10 rounded-lg p-4 text-center">
                  <p className="text-3xl font-bold text-amber-600">{result.notFound}</p>
                  <p className="text-sm text-muted-foreground">Não encontrados</p>
                </div>
              </div>

              <Alert>
                <Unlock className="h-4 w-4" />
                <AlertTitle>Como desbloquear produtos?</AlertTitle>
                <AlertDescription>
                  Para desbloquear um produto, edite-o manualmente e preencha o código e custo,
                  ou inclua-o na próxima importação.
                </AlertDescription>
              </Alert>
            </div>
          )}
        </div>

        <DialogFooter className="border-t pt-4">
          {step === 'upload' && (
            <Button variant="outline" onClick={handleClose}>
              Cancelar
            </Button>
          )}

          {step === 'mapping' && (
            <>
              <Button variant="outline" onClick={() => setStep('upload')}>
                Voltar
              </Button>
              <Button 
                onClick={generatePreview} 
                disabled={!codigoColumn || !custoColumn || loading}
              >
                {loading && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                Gerar Prévia
              </Button>
            </>
          )}

          {step === 'preview' && (
            <>
              <Button variant="outline" onClick={() => setStep('mapping')}>
                Voltar
              </Button>
              <Button 
                onClick={executeImport}
                disabled={stats.toUpdate === 0}
                variant="default"
              >
                <Check className="h-4 w-4 mr-2" />
                Confirmar Importação ({stats.toUpdate} produtos)
              </Button>
            </>
          )}

          {step === 'result' && (
            <Button onClick={handleClose}>
              Fechar
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
