import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2 } from 'lucide-react';
import { CategoryData } from '@/hooks/useCategoriesData';

interface SetCategoryModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  categories: CategoryData[];
  selectedCount: number;
  onApply: (categoryId: string) => Promise<void>;
}

export function SetCategoryModal({ open, onOpenChange, categories, selectedCount, onApply }: SetCategoryModalProps) {
  const [selectedCategoryId, setSelectedCategoryId] = useState<string>('');
  const [submitting, setSubmitting] = useState(false);

  const handleApply = async () => {
    if (!selectedCategoryId) return;
    setSubmitting(true);
    await onApply(selectedCategoryId);
    setSubmitting(false);
    setSelectedCategoryId('');
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Definir Categoria</DialogTitle>
        </DialogHeader>
        <p className="text-sm text-muted-foreground">
          {selectedCount} produto(s) selecionado(s)
        </p>
        <Select value={selectedCategoryId} onValueChange={setSelectedCategoryId}>
          <SelectTrigger>
            <SelectValue placeholder="Selecione uma categoria" />
          </SelectTrigger>
          <SelectContent>
            {categories.map(cat => (
              <SelectItem key={cat.id} value={cat.id}>
                {cat.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
          <Button onClick={handleApply} disabled={!selectedCategoryId || submitting}>
            {submitting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
            Aplicar
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
