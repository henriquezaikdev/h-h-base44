import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { AlertCircle, Clock, CheckCircle2 } from 'lucide-react';
import { cn } from '@/lib/utils';

interface AutoSyncStatusProps {
  compact?: boolean;
  refreshKey?: number;
}

export function AutoSyncStatus({ compact = false, refreshKey = 0 }: AutoSyncStatusProps) {
  const [lastAutoSync, setLastAutoSync] = useState<{ started_at: string; status: string; mode: string } | null>(null);
  const [consecutiveFailures, setConsecutiveFailures] = useState(0);
  const [nextEstimated, setNextEstimated] = useState<string | null>(null);

  useEffect(() => {
    fetchAutoSyncStatus();
  }, [refreshKey]);

  async function fetchAutoSyncStatus() {
    // Get last 5 sync logs to detect consecutive failures
    const { data: logs } = await supabase
      .from('fin_sync_logs')
      .select('started_at, status, mode')
      .order('started_at', { ascending: false })
      .limit(5);

    if (!logs || logs.length === 0) return;

    // Last sync overall
    setLastAutoSync(logs[0] as any);

    // Count consecutive failures from most recent
    let failures = 0;
    for (const log of logs) {
      if (log.status === 'error') failures++;
      else break;
    }
    setConsecutiveFailures(failures);

    // Estimate next execution based on last sync time
    const lastTime = new Date(logs[0].started_at).getTime();
    const now = Date.now();
    
    // Caixa runs hourly, financeiro every 4h
    // Next execution is the next full hour
    const nextHour = new Date(now);
    nextHour.setMinutes(0, 0, 0);
    nextHour.setHours(nextHour.getHours() + 1);
    setNextEstimated(nextHour.toISOString());
  }

  const formatDateTime = (dt: string) => {
    try {
      return new Date(dt).toLocaleString('pt-BR', {
        day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit'
      });
    } catch {
      return dt;
    }
  };

  if (!lastAutoSync) return null;

  return (
    <div className="space-y-2">
      {/* Consecutive failure alert */}
      {consecutiveFailures >= 2 && (
        <div className="flex items-center gap-2 rounded-lg border border-destructive/30 bg-destructive/5 p-3 text-destructive">
          <AlertCircle className="h-4 w-4 flex-shrink-0" />
          <span className="text-[12px] font-medium">
            Sync falhando ({consecutiveFailures}x seguidas) — verifique os logs ou reconecte a Conta Azul.
          </span>
        </div>
      )}

      {/* Status info */}
      <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-[11px] text-muted-foreground">
        <span className="flex items-center gap-1">
          {lastAutoSync.status === 'success' ? (
            <CheckCircle2 size={11} className="text-[hsl(var(--status-success))]" />
          ) : lastAutoSync.status === 'error' ? (
            <AlertCircle size={11} className="text-destructive" />
          ) : (
            <Clock size={11} />
          )}
          Última sync: {formatDateTime(lastAutoSync.started_at)}
          {lastAutoSync.mode && <span className="text-muted-foreground/60">({lastAutoSync.mode})</span>}
        </span>
        {nextEstimated && !compact && (
          <span className="flex items-center gap-1">
            <Clock size={11} />
            Próxima estimada: {formatDateTime(nextEstimated)}
          </span>
        )}
        {!compact && (
          <span className="text-muted-foreground/60">
            Caixa: a cada 1h · Financeiro: a cada 4h
          </span>
        )}
      </div>
    </div>
  );
}
