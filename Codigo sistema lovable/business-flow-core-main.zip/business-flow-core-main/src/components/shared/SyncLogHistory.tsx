import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import {
  CheckCircle2, XCircle, Clock, RefreshCw, ChevronDown, ChevronUp,
} from "lucide-react";

interface SyncLogHistoryProps {
  /** Filter logs by module name (e.g. "produtos", "vendas", "rotina_produtos") */
  module?: string;
  /** Multiple modules filter */
  modules?: string[];
  /** Max logs to show */
  limit?: number;
  /** Title override */
  title?: string;
  /** Auto-refresh interval in ms (0 = disabled) */
  refetchInterval?: number;
  /** External refresh key */
  refreshKey?: number;
}

type LogRow = {
  id: string;
  module: string;
  trigger: string;
  started_at: string;
  finished_at: string | null;
  status: string;
  records_fetched: number;
  records_created: number;
  records_updated: number;
  records_skipped: number;
  pendencias_criadas: number;
  error_message: string | null;
  details: any;
};

const statusConfig: Record<string, { label: string; variant: "default" | "destructive" | "secondary"; icon: typeof CheckCircle2 }> = {
  success: { label: "Sucesso", variant: "default", icon: CheckCircle2 },
  error: { label: "Erro", variant: "destructive", icon: XCircle },
  running: { label: "Executando", variant: "secondary", icon: Clock },
};

export function SyncLogHistory({
  module,
  modules,
  limit = 3,
  title = "Histórico de Sincronizações",
  refetchInterval = 15000,
  refreshKey = 0,
}: SyncLogHistoryProps) {
  const [detailLog, setDetailLog] = useState<LogRow | null>(null);
  const [expanded, setExpanded] = useState(true);

  const effectiveModules = modules || (module ? [module] : []);

  const { data: logs = [], isLoading, refetch } = useQuery({
    queryKey: ["sync-log-history", effectiveModules, limit, refreshKey],
    queryFn: async () => {
      let query = supabase
        .from("hh_sync_logs")
        .select("*")
        .order("started_at", { ascending: false })
        .limit(limit);

      if (effectiveModules.length === 1) {
        query = query.eq("module", effectiveModules[0]);
      } else if (effectiveModules.length > 1) {
        query = query.in("module", effectiveModules);
      }

      const { data, error } = await query;
      if (error) throw error;
      return (data || []) as LogRow[];
    },
    refetchInterval: refetchInterval > 0 ? refetchInterval : false,
    refetchOnWindowFocus: true,
    refetchOnReconnect: true,
    staleTime: 0,
  });

  const successCount = logs.filter(l => l.status === "success").length;
  const errorCount = logs.filter(l => l.status === "error").length;

  return (
    <>
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-base flex items-center gap-2">
              {title}
              {successCount > 0 && (
                <Badge variant="default" className="text-xs gap-1">
                  <CheckCircle2 className="h-3 w-3" /> {successCount}
                </Badge>
              )}
              {errorCount > 0 && (
                <Badge variant="destructive" className="text-xs gap-1">
                  <XCircle className="h-3 w-3" /> {errorCount}
                </Badge>
              )}
            </CardTitle>
            <div className="flex items-center gap-1">
              <Button variant="ghost" size="sm" onClick={() => refetch()}>
                <RefreshCw className="h-3.5 w-3.5" />
              </Button>
              <Button variant="ghost" size="sm" onClick={() => setExpanded(!expanded)}>
                {expanded ? <ChevronUp className="h-3.5 w-3.5" /> : <ChevronDown className="h-3.5 w-3.5" />}
              </Button>
            </div>
          </div>
        </CardHeader>
        {expanded && (
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Data/Hora</TableHead>
                  <TableHead>Módulo</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Lidos</TableHead>
                  <TableHead className="text-right">Criados</TableHead>
                  <TableHead className="text-right">Atualizados</TableHead>
                  <TableHead>Erro</TableHead>
                  <TableHead></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center py-6 text-muted-foreground text-sm">
                      Carregando...
                    </TableCell>
                  </TableRow>
                ) : logs.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center py-6 text-muted-foreground text-sm">
                      Nenhum log encontrado
                    </TableCell>
                  </TableRow>
                ) : (
                  logs.map(log => {
                    const cfg = statusConfig[log.status] || statusConfig.running;
                    const Icon = cfg.icon;
                    return (
                      <TableRow key={log.id}>
                        <TableCell className="whitespace-nowrap text-xs">
                          {format(new Date(log.started_at), "dd/MM HH:mm:ss", { locale: ptBR })}
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline" className="capitalize text-xs">{log.module}</Badge>
                        </TableCell>
                        <TableCell>
                          <Badge variant={cfg.variant} className="gap-1 text-xs">
                            <Icon className="h-3 w-3" /> {cfg.label}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right font-mono text-xs">{log.records_fetched}</TableCell>
                        <TableCell className="text-right font-mono text-xs">{log.records_created}</TableCell>
                        <TableCell className="text-right font-mono text-xs">{log.records_updated}</TableCell>
                        <TableCell className="text-xs text-destructive max-w-32 truncate">
                          {log.error_message || "—"}
                        </TableCell>
                        <TableCell>
                          <Button variant="ghost" size="sm" className="text-xs h-7" onClick={() => setDetailLog(log)}>
                            Ver
                          </Button>
                        </TableCell>
                      </TableRow>
                    );
                  })
                )}
              </TableBody>
            </Table>
          </CardContent>
        )}
      </Card>

      {/* Detail modal */}
      <Dialog open={!!detailLog} onOpenChange={() => setDetailLog(null)}>
        <DialogContent className="max-w-lg max-h-[80vh] overflow-auto">
          <DialogHeader>
            <DialogTitle>Detalhes da Execução</DialogTitle>
          </DialogHeader>
          {detailLog && (
            <div className="space-y-4 text-sm">
              <div className="grid grid-cols-2 gap-2">
                <div><span className="text-muted-foreground">Módulo:</span> <strong className="capitalize">{detailLog.module}</strong></div>
                <div><span className="text-muted-foreground">Trigger:</span> <strong className="capitalize">{detailLog.trigger}</strong></div>
                <div><span className="text-muted-foreground">Início:</span> <strong>{format(new Date(detailLog.started_at), "dd/MM/yyyy HH:mm:ss")}</strong></div>
                <div><span className="text-muted-foreground">Fim:</span> <strong>{detailLog.finished_at ? format(new Date(detailLog.finished_at), "dd/MM/yyyy HH:mm:ss") : "—"}</strong></div>
                <div><span className="text-muted-foreground">Status:</span> <strong>{detailLog.status}</strong></div>
              </div>

              <div className="grid grid-cols-2 gap-2 border-t pt-3">
                <div>Lidos: <strong>{detailLog.records_fetched}</strong></div>
                <div>Criados: <strong>{detailLog.records_created}</strong></div>
                <div>Atualizados: <strong>{detailLog.records_updated}</strong></div>
                <div>Pulados: <strong>{detailLog.records_skipped}</strong></div>
                {detailLog.pendencias_criadas > 0 && (
                  <div>Pendências: <strong>{detailLog.pendencias_criadas}</strong></div>
                )}
              </div>

              {detailLog.error_message && (
                <div className="border-t pt-3">
                  <p className="text-muted-foreground mb-1">Erro:</p>
                  <pre className="bg-destructive/10 text-destructive p-3 rounded text-xs whitespace-pre-wrap">{detailLog.error_message}</pre>
                </div>
              )}

              {detailLog.details && (
                <div className="border-t pt-3">
                  <p className="text-muted-foreground mb-1">Detalhes (JSON):</p>
                  <pre className="bg-muted p-3 rounded text-xs whitespace-pre-wrap overflow-auto max-h-60">
                    {JSON.stringify(detailLog.details, null, 2)}
                  </pre>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
