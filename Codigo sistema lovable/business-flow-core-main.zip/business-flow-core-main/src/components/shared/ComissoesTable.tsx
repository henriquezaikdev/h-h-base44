import { DollarSign } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableFooter,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { formatCurrency } from '@/lib/utils';
import { cn } from '@/lib/utils';

export interface ComissaoItem {
  name: string;
  revenue: number;
  marginBruta: number;
  comissaoReal: number;
  comissaoPercentual: number;
}

interface ComissoesTableProps {
  items: ComissaoItem[];
  title?: string;
}

function getMarginColor(margin: number): string {
  if (margin >= 15) return 'text-emerald-600';
  if (margin >= 0) return 'text-amber-600';
  return 'text-destructive';
}

export function ComissoesTable({ items, title = 'Comissões a Pagar' }: ComissoesTableProps) {
  const totalReceita = items.reduce((sum, i) => sum + i.revenue, 0);
  const totalComissao = items.reduce((sum, i) => sum + i.comissaoReal, 0);
  const avgMargin = totalReceita > 0
    ? items.reduce((sum, i) => sum + i.marginBruta * i.revenue, 0) / totalReceita
    : 0;
  const avgComissaoPerc = totalReceita > 0 ? (totalComissao / totalReceita) * 100 : 0;

  const sorted = [...items].sort((a, b) => b.comissaoReal - a.comissaoReal);

  if (items.length === 0) {
    return null;
  }

  return (
    <Card className="border-border/50 shadow-sm">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm flex items-center gap-2">
          <DollarSign className="h-4 w-4 text-primary" />
          {title}
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="text-xs">Vendedor</TableHead>
              <TableHead className="text-xs text-right">Receita</TableHead>
              <TableHead className="text-xs text-right">Margem %</TableHead>
              <TableHead className="text-xs text-right">Comissão (R$)</TableHead>
              <TableHead className="text-xs text-right">Comissão %</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {sorted.map((item) => (
              <TableRow key={item.name}>
                <TableCell className="text-sm font-medium py-2">{item.name}</TableCell>
                <TableCell className="text-sm text-right py-2 tabular-nums">
                  {formatCurrency(item.revenue)}
                </TableCell>
                <TableCell className={cn('text-sm text-right py-2 tabular-nums font-medium', getMarginColor(item.marginBruta))}>
                  {item.marginBruta.toFixed(1)}%
                </TableCell>
                <TableCell className="text-sm text-right py-2 tabular-nums font-semibold">
                  {formatCurrency(item.comissaoReal)}
                </TableCell>
                <TableCell className="text-sm text-right py-2 tabular-nums text-muted-foreground">
                  {item.comissaoPercentual.toFixed(2)}%
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
          <TableFooter>
            <TableRow className="bg-muted/50 font-semibold">
              <TableCell className="text-sm py-2">Total</TableCell>
              <TableCell className="text-sm text-right py-2 tabular-nums">
                {formatCurrency(totalReceita)}
              </TableCell>
              <TableCell className={cn('text-sm text-right py-2 tabular-nums', getMarginColor(avgMargin))}>
                {avgMargin.toFixed(1)}%
              </TableCell>
              <TableCell className="text-sm text-right py-2 tabular-nums">
                {formatCurrency(totalComissao)}
              </TableCell>
              <TableCell className="text-sm text-right py-2 tabular-nums text-muted-foreground">
                {avgComissaoPerc.toFixed(2)}%
              </TableCell>
            </TableRow>
          </TableFooter>
        </Table>
      </CardContent>
    </Card>
  );
}
