import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Loader2, Banknote } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

interface Snapshot {
  id: string;
  conta_id: string | null;
  conta_nome: string | null;
  saldo: number | null;
  caixa_total: number | null;
  synced_at: string | null;
  created_at: string;
}

const formatCurrency = (v: number) =>
  v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

function formatDateTime(dt: string): string {
  try {
    return new Date(dt).toLocaleString('pt-BR', {
      day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit',
    });
  } catch {
    return dt;
  }
}

export function CaixaSnapshotHistory({ refreshKey = 0 }: { refreshKey?: number }) {
  const [snapshots, setSnapshots] = useState<Snapshot[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetch() {
      const { data } = await supabase
        .from('fin_caixa_saldo_snapshot')
        .select('id, conta_id, conta_nome, saldo, caixa_total, synced_at, created_at')
        .order('created_at', { ascending: false })
        .limit(20);
      setSnapshots((data as Snapshot[]) || []);
      setLoading(false);
    }
    fetch();
  }, [refreshKey]);

  if (loading) {
    return (
      <div className="flex items-center gap-2 text-sm text-muted-foreground">
        <Loader2 className="h-4 w-4 animate-spin" />
        Carregando histórico de caixa...
      </div>
    );
  }

  if (snapshots.length === 0) {
    return <p className="text-[12px] text-muted-foreground">Nenhum snapshot de caixa registrado.</p>;
  }

  return (
    <div className="space-y-1.5 max-h-64 overflow-y-auto">
      {snapshots.map(snap => (
        <div key={snap.id} className="flex items-center justify-between p-2 rounded border bg-muted/30 text-[12px]">
          <div className="flex items-center gap-2">
            <Banknote size={12} className="text-primary shrink-0" />
            <span className="font-medium truncate max-w-[160px]">
              {snap.conta_nome || 'Consolidado'}
            </span>
            <span className="text-muted-foreground">
              {formatDateTime(snap.synced_at || snap.created_at)}
            </span>
          </div>
          <Badge variant="outline" className="text-[11px] px-2 py-0 font-semibold">
            {formatCurrency(snap.saldo ?? snap.caixa_total ?? 0)}
          </Badge>
        </div>
      ))}
    </div>
  );
}
