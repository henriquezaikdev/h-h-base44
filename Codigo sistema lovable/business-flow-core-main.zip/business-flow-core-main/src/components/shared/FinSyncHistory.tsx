import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Clock, CheckCircle2, AlertCircle, Loader2, AlertTriangle } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

interface FinSyncLog {
  id: string;
  started_at: string;
  finished_at: string | null;
  status: string;
  mode: string | null;
  receber_synced: number;
  pagar_synced: number;
  caixa_accounts_synced: number;
  duration_ms: number | null;
  error_message: string | null;
}

const statusConfig: Record<string, { label: string; color: string; icon: React.ReactNode }> = {
  running: { label: 'Executando', color: 'bg-blue-100 text-blue-700 border-blue-200', icon: <Loader2 size={10} className="animate-spin" /> },
  success: { label: 'Sucesso', color: 'bg-green-100 text-green-700 border-green-200', icon: <CheckCircle2 size={10} /> },
  partial: { label: 'Parcial', color: 'bg-yellow-100 text-yellow-700 border-yellow-200', icon: <AlertTriangle size={10} /> },
  error: { label: 'Erro', color: 'bg-red-100 text-red-700 border-red-200', icon: <AlertCircle size={10} /> },
};

function formatDuration(ms: number | null): string {
  if (!ms) return '—';
  if (ms < 1000) return `${ms}ms`;
  return `${(ms / 1000).toFixed(1)}s`;
}

function formatDateTime(dt: string): string {
  try {
    return new Date(dt).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
  } catch {
    return dt;
  }
}

export function FinSyncHistory({ compact = false, refreshKey = 0, modeFilter }: { compact?: boolean; refreshKey?: number; modeFilter?: string }) {
  const [logs, setLogs] = useState<FinSyncLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [queryError, setQueryError] = useState<string | null>(null);

  useEffect(() => {
    fetchLogs();

    const intervalId = window.setInterval(() => {
      fetchLogs();
    }, 15000);

    const onVisible = () => {
      if (document.visibilityState === 'visible') fetchLogs();
    };

    const onFocus = () => fetchLogs();

    document.addEventListener('visibilitychange', onVisible);
    window.addEventListener('focus', onFocus);

    return () => {
      window.clearInterval(intervalId);
      document.removeEventListener('visibilitychange', onVisible);
      window.removeEventListener('focus', onFocus);
    };
  }, [refreshKey, modeFilter]);

  async function fetchLogs() {
    let query = supabase
      .from('fin_sync_logs')
      .select('id, started_at, finished_at, status, mode, receber_synced, pagar_synced, caixa_accounts_synced, duration_ms, error_message')
      .order('started_at', { ascending: false })
      .limit(3);
    if (modeFilter) {
      query = query.eq('mode', modeFilter);
    }
    const { data, error } = await query;
    if (error) {
      console.error('[FinSyncHistory] query error:', error);
      setQueryError(error.message);
    }
    setLogs((data as FinSyncLog[]) || []);
    setLoading(false);
  }

  if (loading) {
    return (
      <div className="flex items-center gap-2 text-sm text-muted-foreground">
        <Loader2 className="h-4 w-4 animate-spin" />
        Carregando histórico...
      </div>
    );
  }

  if (queryError) {
    return (
      <div className="text-[12px] text-destructive bg-destructive/10 rounded p-2">
        <strong>DEBUG:</strong> Erro ao consultar fin_sync_logs: {queryError}
      </div>
    );
  }

  if (logs.length === 0) {
    return <p className="text-[12px] text-muted-foreground">Nenhuma sincronização registrada na tabela fin_sync_logs.</p>;
  }

  const lastLog = logs[0];
  const lastStatus = statusConfig[lastLog.status] || statusConfig.error;

  return (
    <div className="space-y-3">
      {/* Last sync summary */}
      <div className="flex items-center gap-2 text-[12px] text-muted-foreground">
        <Clock size={12} />
        <span>Última: {formatDateTime(lastLog.started_at)}</span>
        <Badge variant="outline" className={cn('text-[10px] px-1.5 py-0 gap-1', lastStatus.color)}>
          {lastStatus.icon}
          {lastStatus.label}
        </Badge>
        <span>{formatDuration(lastLog.duration_ms)}</span>
      </div>

      {/* Full table */}
      {!compact && (
        <div className="space-y-1.5 max-h-64 overflow-y-auto">
          {logs.map(log => {
            const cfg = statusConfig[log.status] || statusConfig.error;
            return (
              <div key={log.id} className="flex flex-col gap-1 p-2 rounded border bg-muted/30 text-[12px]">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-muted-foreground">{formatDateTime(log.started_at)}</span>
                    {log.mode && <Badge variant="secondary" className="text-[10px] px-1.5 py-0">{log.mode}</Badge>}
                    <span className="text-muted-foreground">{formatDuration(log.duration_ms)}</span>
                  </div>
                  <Badge variant="outline" className={cn('text-[10px] px-1.5 py-0 gap-1', cfg.color)}>
                    {cfg.icon}
                    {cfg.label}
                  </Badge>
                </div>
                <div className="flex items-center gap-3 text-muted-foreground">
                  {log.mode === 'entregador_online' ? (
                    <>
                      <span>Novas: {log.receber_synced}</span>
                      <span>Já registradas: {log.pagar_synced}</span>
                    </>
                  ) : (
                    <>
                      <span>Receber: {log.receber_synced}</span>
                      <span>Pagar: {log.pagar_synced}</span>
                      {log.caixa_accounts_synced > 0 && <span>Caixa: {log.caixa_accounts_synced}</span>}
                    </>
                  )}
                </div>
                {log.error_message && (
                  <p className="text-destructive bg-destructive/10 rounded px-2 py-1 text-[11px]">
                    {log.error_message}
                  </p>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
